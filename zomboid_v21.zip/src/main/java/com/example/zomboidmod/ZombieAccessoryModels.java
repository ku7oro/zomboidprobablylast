package com.example.zomboidmod;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;

/** Сгенерировано gen_accessories.py: 3D-детали одежды зомби. */
public final class ZombieAccessoryModels {
    public static final String[][] PARTS = {{"police_cap", "head"}, {"security_cap", "head"}, {"fire_helmet", "head"}, {"hard_hat", "head"}, {"army_helmet", "head"}, {"chef_hat", "head"}, {"straw_hat", "head"}, {"nurse_cap", "head"}, {"surgical_mask", "head"}, {"hazmat_hood", "head"}, {"bandana", "head"}, {"baseball_cap", "head"}, {"backpack", "body"}, {"bedroll", "body"}, {"rag_body", "body"}, {"rag_arm_r", "right_arm"}, {"rag_arm_l", "left_arm"}};

    private ZombieAccessoryModels() {
    }

    public static TexturedModelData create() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("police_cap", ModelPartBuilder.create().uv(0, 0).cuboid(-4f, -10f, -4f, 8, 2, 8, new Dilation(0.5f)).uv(33, 0).cuboid(-4f, -8f, -4f, 8, 1, 8, new Dilation(0.55f)).uv(66, 0).cuboid(-4f, -8f, -7f, 8, 1, 3, new Dilation(0f)).uv(89, 0).cuboid(-1f, -10f, -5f, 2, 2, 1, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("security_cap", ModelPartBuilder.create().uv(96, 0).cuboid(-4f, -10f, -4f, 8, 2, 8, new Dilation(0.5f)).uv(0, 11).cuboid(-4f, -8f, -4f, 8, 1, 8, new Dilation(0.55f)).uv(33, 11).cuboid(-4f, -8f, -7f, 8, 1, 3, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("fire_helmet", ModelPartBuilder.create().uv(56, 11).cuboid(-5f, -11f, -5f, 10, 3, 10, new Dilation(0f)).uv(0, 25).cuboid(-4f, -12f, -4f, 8, 1, 8, new Dilation(0f)).uv(33, 25).cuboid(-6f, -8f, -6f, 12, 1, 13, new Dilation(0f)).uv(84, 25).cuboid(-2f, -11f, -6f, 4, 3, 1, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("hard_hat", ModelPartBuilder.create().uv(95, 25).cuboid(-4f, -10f, -4f, 8, 2, 8, new Dilation(0.5f)).uv(0, 40).cuboid(-3f, -11f, -3f, 6, 1, 6, new Dilation(0.3f)).uv(25, 40).cuboid(-5f, -8f, -7f, 10, 1, 12, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("army_helmet", ModelPartBuilder.create().uv(70, 40).cuboid(-5f, -10f, -5f, 10, 3, 10, new Dilation(0f)).uv(0, 54).cuboid(-4f, -11f, -4f, 8, 1, 8, new Dilation(0f)).uv(33, 54).cuboid(-5f, -7f, -5f, 1, 4, 1, new Dilation(0f)).uv(38, 54).cuboid(4f, -7f, -5f, 1, 4, 1, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("chef_hat", ModelPartBuilder.create().uv(43, 54).cuboid(-4f, -9f, -4f, 8, 1, 8, new Dilation(0.6f)).uv(76, 54).cuboid(-4f, -13f, -4f, 8, 4, 8, new Dilation(0.9f)), ModelTransform.NONE);
        root.addChild("straw_hat", ModelPartBuilder.create().uv(0, 67).cuboid(-7f, -8f, -7f, 14, 1, 14, new Dilation(0f)).uv(57, 67).cuboid(-4f, -11f, -4f, 8, 3, 8, new Dilation(0.3f)).uv(90, 67).cuboid(-4f, -9f, -4f, 8, 1, 8, new Dilation(0.45f)), ModelTransform.NONE);
        root.addChild("nurse_cap", ModelPartBuilder.create().uv(0, 83).cuboid(-3f, -9f, -3f, 6, 1, 5, new Dilation(0.3f)), ModelTransform.NONE);
        root.addChild("surgical_mask", ModelPartBuilder.create().uv(23, 83).cuboid(-4f, -4f, -5f, 8, 3, 1, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("hazmat_hood", ModelPartBuilder.create().uv(42, 83).cuboid(-4f, -8f, -4f, 8, 8, 8, new Dilation(0.7f)).uv(75, 83).cuboid(-3f, -6f, -5f, 6, 3, 1, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("bandana", ModelPartBuilder.create().uv(90, 83).cuboid(-4f, -7f, -4f, 8, 2, 8, new Dilation(0.4f)).uv(0, 100).cuboid(-1f, -6f, 4f, 2, 3, 1, new Dilation(0.2f)), ModelTransform.NONE);
        root.addChild("baseball_cap", ModelPartBuilder.create().uv(7, 100).cuboid(-4f, -9f, -4f, 8, 2, 8, new Dilation(0.5f)).uv(40, 100).cuboid(-4f, -8f, -7f, 8, 1, 3, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("backpack", ModelPartBuilder.create().uv(63, 100).cuboid(-3f, 1f, 2f, 6, 8, 3, new Dilation(0f)).uv(82, 100).cuboid(-3f, 1f, 2f, 6, 2, 3, new Dilation(0.2f)).uv(101, 100).cuboid(-4f, 4f, 2f, 1, 4, 2, new Dilation(0f)).uv(108, 100).cuboid(3f, 4f, 2f, 1, 4, 2, new Dilation(0f)).uv(115, 100).cuboid(-3f, 0f, -2f, 1, 6, 1, new Dilation(0.1f)).uv(120, 100).cuboid(2f, 0f, -2f, 1, 6, 1, new Dilation(0.1f)), ModelTransform.NONE);
        root.addChild("bedroll", ModelPartBuilder.create().uv(0, 112).cuboid(-4f, -1f, 3f, 8, 2, 2, new Dilation(0.2f)), ModelTransform.NONE);
        root.addChild("rag_body", ModelPartBuilder.create().uv(21, 112).cuboid(-4f, 10f, -2f, 8, 5, 1, new Dilation(0.3f)), ModelTransform.NONE);
        root.addChild("rag_arm_r", ModelPartBuilder.create().uv(40, 112).cuboid(-3f, 5f, -2f, 4, 5, 1, new Dilation(0.3f)), ModelTransform.NONE);
        root.addChild("rag_arm_l", ModelPartBuilder.create().uv(51, 112).cuboid(-1f, 5f, 1f, 4, 5, 1, new Dilation(0.3f)), ModelTransform.NONE);
        return TexturedModelData.of(md, 128, 128);
    }
}
