package com.example.zomboidmod.gun;

import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Пистолет, дробовик, охотничья винтовка и патроны к ним. */
public final class Guns {
    public static Item AMMO_9MM, SHOTGUN_SHELLS, RIFLE_ROUNDS;
    public static GunItem PISTOL, SHOTGUN, HUNTING_RIFLE;
    public static SoundEvent PISTOL_SHOT, SHOTGUN_SHOT, RIFLE_SHOT, DRY, RELOAD;

    private Guns() {
    }

    public record ReloadPayload() implements CustomPayload {
        public static final CustomPayload.Id<ReloadPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "reload"));
        public static final PacketCodec<RegistryByteBuf, ReloadPayload> CODEC = PacketCodec.unit(new ReloadPayload());

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    private static SoundEvent sound(String id) {
        Identifier i = Identifier.of(ZomboidMod.MOD_ID, id);
        return Registry.register(Registries.SOUND_EVENT, i, SoundEvent.of(i));
    }

    private static <T extends Item> T item(String id, T it) {
        return Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), it);
    }

    public static void register() {
        PISTOL_SHOT = sound("gun_pistol");
        SHOTGUN_SHOT = sound("gun_shotgun");
        RIFLE_SHOT = sound("gun_rifle");
        DRY = sound("gun_dry");
        RELOAD = sound("gun_reload");
        AMMO_9MM = item("ammo_9mm", new Item(new Item.Settings()));
        SHOTGUN_SHELLS = item("shotgun_shells", new Item(new Item.Settings()));
        RIFLE_ROUNDS = item("rifle_rounds", new Item(new Item.Settings()));
        //                         id               патрон            ёмк урон  даль дроб разб  кд  перез шум
        PISTOL = item("pistol", new GunItem("pistol", () -> AMMO_9MM, 15, 9f, 40f, 1, 1.6f, 5, 30, 70, () -> PISTOL_SHOT, new Item.Settings()));
        SHOTGUN = item("shotgun", new GunItem("shotgun", () -> SHOTGUN_SHELLS, 6, 5.5f, 22f, 8, 5.5f, 18, 50, 90, () -> SHOTGUN_SHOT, new Item.Settings()));
        HUNTING_RIFLE = item("hunting_rifle", new GunItem("hunting_rifle", () -> RIFLE_ROUNDS, 5, 28f, 90f, 1, 0.5f, 30, 60, 110, () -> RIFLE_SHOT, new Item.Settings()));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> {
            e.add(PISTOL);
            e.add(SHOTGUN);
            e.add(HUNTING_RIFLE);
            e.add(AMMO_9MM);
            e.add(SHOTGUN_SHELLS);
            e.add(RIFLE_ROUNDS);
        });

        PayloadTypeRegistry.playC2S().register(ReloadPayload.ID, ReloadPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ReloadPayload.ID, (payload, ctx) -> ctx.server().execute(() -> {
            var p = ctx.player();
            if (p.getMainHandStack().getItem() instanceof GunItem g && !p.getItemCooldownManager().isCoolingDown(g)) g.reload(p, p.getMainHandStack());
        }));
    }
}
