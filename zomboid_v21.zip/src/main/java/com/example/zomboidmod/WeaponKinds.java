package com.example.zomboidmod;

import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.Map;

/** Тип удара для анимации и длительность взмаха (в тиках). Общий код: нужен и серверу, и клиенту. */
public final class WeaponKinds {
    public enum Kind { HEAVY, SLASH, LIGHT, STAB, PISTOL, LONG_GUN }

    private static final Map<String, Kind> KINDS = Map.ofEntries(
            Map.entry("baseball_bat", Kind.HEAVY), Map.entry("spiked_bat", Kind.HEAVY), Map.entry("fire_axe", Kind.HEAVY),
            Map.entry("crowbar", Kind.HEAVY), Map.entry("sledgehammer", Kind.HEAVY), Map.entry("shovel", Kind.HEAVY),
            Map.entry("golf_club", Kind.HEAVY), Map.entry("katana", Kind.SLASH), Map.entry("machete", Kind.SLASH),
            Map.entry("hammer", Kind.LIGHT), Map.entry("frying_pan", Kind.LIGHT), Map.entry("hand_axe", Kind.LIGHT),
            Map.entry("pipe_wrench", Kind.LIGHT), Map.entry("nightstick", Kind.LIGHT), Map.entry("meat_cleaver", Kind.LIGHT),
            Map.entry("kitchen_knife", Kind.STAB), Map.entry("hunting_knife", Kind.STAB),
            Map.entry("pistol", Kind.PISTOL), Map.entry("shotgun", Kind.LONG_GUN), Map.entry("hunting_rifle", Kind.LONG_GUN));

    private WeaponKinds() {
    }

    public static Kind kind(ItemStack st) {
        if (st == null || st.isEmpty()) return null;
        Identifier id = Registries.ITEM.getId(st.getItem());
        if (!id.getNamespace().equals(ZomboidMod.MOD_ID)) return null;
        return KINDS.get(id.getPath());
    }

    /** Тяжёлым оружием замахиваются дольше. */
    public static int swingTicks(ItemStack st) {
        Kind k = kind(st);
        if (k == null) return -1;
        if (st.isOf(ZomboidMod.SLEDGEHAMMER)) return 16;
        return switch (k) {
            case HEAVY -> 12;
            case SLASH -> 9;
            case LIGHT -> 8;
            case STAB -> 6;
            case PISTOL, LONG_GUN -> 5;
        };
    }
}
