package com.example.zomboidmod;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.ZombieBaseEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Зомби: скин по одежде, своя анимация, ползун лежит на животе, 3D-детали одежды. */
public class PzZombieRenderer extends ZombieBaseEntityRenderer<ZombieEntity, PzZombieModel> {
    private static final Identifier ACC_TEX = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/zombie/accessories.png");

    public PzZombieRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PzZombieModel(ctx.getPart(EntityModelLayers.ZOMBIE)),
                new PzZombieModel(ctx.getPart(EntityModelLayers.ZOMBIE_INNER_ARMOR)),
                new PzZombieModel(ctx.getPart(EntityModelLayers.ZOMBIE_OUTER_ARMOR)));
        this.addFeature(new Accessories(this));
    }

    @Override
    public Identifier getTexture(ZombieEntity entity) {
        if (entity instanceof PzZombieEntity z) return ZombieOutfit.texture(z.outfit(), z.tone(), z.kind());
        return super.getTexture(entity);
    }

    @Override
    protected void setupTransforms(ZombieEntity entity, MatrixStack matrices, float animationProgress, float bodyYaw, float tickDelta, float scale) {
        super.setupTransforms(entity, matrices, animationProgress, bodyYaw, tickDelta, scale);
        if (entity instanceof PzZombieEntity z && z.isCrawler() && entity.deathTime <= 0) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90f));
            matrices.translate(0f, -1.0f, 0.3f);
        }
    }

    /** Каски, фуражки, маски, рюкзаки и лохмотья — по одежде и случайно. */
    static final class Accessories extends FeatureRenderer<ZombieEntity, PzZombieModel> {
        private static final int[] TINTS = {0xFF7A2A24, 0xFF2E3E66, 0xFF3C5A34, 0xFF5A4A3A, 0xFF2A2A2C, 0xFF8A7A50, 0xFF6A6A70};
        private final Map<String, ModelPart> parts = new HashMap<>();
        private final Map<String, String> attach = new HashMap<>();

        Accessories(FeatureRendererContext<ZombieEntity, PzZombieModel> ctx) {
            super(ctx);
            ModelPart root = ZombieAccessoryModels.create().createModel();
            for (String[] p : ZombieAccessoryModels.PARTS) {
                parts.put(p[0], root.getChild(p[0]));
                attach.put(p[0], p[1]);
            }
        }

        static List<String> pick(PzZombieEntity z) {
            java.util.Random r = new java.util.Random(z.getUuid().getLeastSignificantBits() ^ 0x5DEECE66DL);
            List<String> out = new ArrayList<>();
            switch (z.outfit()) {
                case POLICE -> { if (r.nextFloat() < 0.7f) out.add("police_cap"); }
                case SECURITY -> { if (r.nextFloat() < 0.7f) out.add("security_cap"); }
                case FIREFIGHTER -> out.add("fire_helmet");
                case CONSTRUCTION -> { if (r.nextFloat() < 0.8f) out.add("hard_hat"); }
                case SOLDIER -> {
                    out.add("army_helmet");
                    if (r.nextFloat() < 0.5f) out.add("backpack");
                    if (r.nextFloat() < 0.3f) out.add("bedroll");
                }
                case CHEF -> out.add("chef_hat");
                case FARMER -> out.add(r.nextFloat() < 0.6f ? "straw_hat" : "baseball_cap");
                case NURSE -> {
                    if (r.nextFloat() < 0.5f) out.add("nurse_cap");
                    if (r.nextFloat() < 0.3f) out.add("surgical_mask");
                }
                case DOCTOR -> { if (r.nextFloat() < 0.6f) out.add("surgical_mask"); }
                case HAZMAT -> out.add("hazmat_hood");
                case BIKER -> { if (r.nextFloat() < 0.6f) out.add("bandana"); }
                case SURVIVOR -> {
                    out.add("backpack");
                    if (r.nextFloat() < 0.5f) out.add("bedroll");
                    if (r.nextFloat() < 0.4f) out.add("baseball_cap");
                }
                case STUDENT -> { if (r.nextFloat() < 0.7f) out.add("backpack"); }
                case MECHANIC -> { if (r.nextFloat() < 0.4f) out.add("baseball_cap"); }
                default -> {
                    if (r.nextFloat() < 0.18f) out.add("baseball_cap");
                    if (r.nextFloat() < 0.1f) out.add("backpack");
                }
            }
            if (z.outfit() != ZombieOutfit.HAZMAT) {
                if (r.nextFloat() < 0.3f) out.add("rag_body");
                if (r.nextFloat() < 0.25f) out.add("rag_arm_r");
                if (r.nextFloat() < 0.25f) out.add("rag_arm_l");
            }
            return out;
        }

        @Override
        public void render(MatrixStack matrices, VertexConsumerProvider vcp, int light, ZombieEntity entity, float limbAngle, float limbDistance,
                           float tickDelta, float animationProgress, float headYaw, float headPitch) {
            if (!(entity instanceof PzZombieEntity z) || entity.isInvisible()) return;
            List<String> list = pick(z);
            if (list.isEmpty()) return;
            PzZombieModel m = getContextModel();
            VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(ACC_TEX));
            int overlay = LivingEntityRenderer.getOverlay(entity, 0f);
            int tint = TINTS[Math.floorMod(entity.getUuid().hashCode(), TINTS.length)];
            for (String id : list) {
                ModelPart p = parts.get(id);
                if (p == null) continue;
                ModelPart src = switch (attach.get(id)) {
                    case "body" -> m.body;
                    case "right_arm" -> m.rightArm;
                    case "left_arm" -> m.leftArm;
                    default -> m.head;
                };
                p.copyTransform(src);
                p.render(matrices, vc, light, overlay, id.equals("baseball_cap") || id.equals("backpack") ? tint : 0xFFFFFFFF);
            }
        }
    }
}
