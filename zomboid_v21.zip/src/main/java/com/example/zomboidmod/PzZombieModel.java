package com.example.zomboidmod;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.ZombieEntityModel;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Анимации зомби в духе PZ: у каждого своя манера — руки вперёд, руки болтаются, одна рука поднята;
 * хромота и подволакивание ноги, наклон и раскачивание корпуса, подёргивание головы,
 * рывок с вытянутыми руками при атаке; ползун тянется на руках.
 */
public class PzZombieModel extends ZombieEntityModel<ZombieEntity> {
    public PzZombieModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setAngles(ZombieEntity e, float limbAngle, float limbDistance, float age, float headYaw, float headPitch) {
        super.setAngles(e, limbAngle, limbDistance, age, headYaw, headPitch);
        int seed = e.getUuid().hashCode() * 0x9E3779B1;
        float ph = ((seed >>> 8) & 1023) / 1023f * MathHelper.TAU;
        boolean crawl = e instanceof PzZombieEntity z && z.isCrawler();
        if (crawl) {
            crawl(limbAngle, limbDistance, age, ph);
            hat.copyTransform(head);
            return;
        }
        float sw = MathHelper.cos(limbAngle * 0.6662f);
        float sw2 = MathHelper.sin(limbAngle * 0.6662f);
        int style = (seed >>> 3) & 3;
        boolean lunge = e.isAttacking();

        // голова: свешена набок, вздрагивает
        float twitch = (float) Math.pow(Math.max(0f, MathHelper.sin(age * 0.37f + ph * 3f)), 24) * 0.35f;
        head.roll = 0.2f * MathHelper.sin(ph) + 0.05f * MathHelper.sin(age * 0.09f + ph) + twitch;
        head.pitch += 0.15f + 0.04f * MathHelper.sin(age * 0.07f + ph);

        // корпус наклонён вперёд и качается с шагом
        float lean = 0.14f + 0.05f * Math.abs(sw) * limbDistance + (lunge ? 0.2f : 0f);
        body.pitch = lean;
        body.roll = 0.1f * sw2 * limbDistance + 0.03f * MathHelper.sin(age * 0.05f + ph);
        body.yaw = 0.06f * sw * limbDistance;
        float fwd = 12f * MathHelper.sin(lean);
        rightLeg.pivotZ = fwd;
        leftLeg.pivotZ = fwd;
        rightLeg.pivotY = 12f * MathHelper.cos(lean);
        leftLeg.pivotY = rightLeg.pivotY;

        // ноги: одна шагает нормально, другая короче и волочится
        float limp = 0.45f + 0.15f * ((seed >>> 5) % 3);
        boolean leftBad = ((seed >>> 7) & 1) == 0;
        rightLeg.pitch = sw * 1.1f * limbDistance * (leftBad ? 1f : limp);
        leftLeg.pitch = -sw * 1.1f * limbDistance * (leftBad ? limp : 1f);
        (leftBad ? leftLeg : rightLeg).yaw = (leftBad ? -0.18f : 0.18f);
        (leftBad ? leftLeg : rightLeg).roll = (leftBad ? -0.05f : 0.05f);

        // руки
        float drift = MathHelper.sin(age * 0.067f + ph) * 0.08f;
        if (lunge) {
            rightArm.pitch = -1.75f + MathHelper.sin(age * 0.6f) * 0.25f;
            leftArm.pitch = -1.65f + MathHelper.cos(age * 0.6f) * 0.25f;
            rightArm.yaw = -0.15f;
            leftArm.yaw = 0.15f;
            head.pitch = 0.05f;
        } else {
            switch (style) {
                case 1 -> {   // руки висят и болтаются
                    rightArm.pitch = -sw * 0.45f * limbDistance + 0.1f + drift;
                    leftArm.pitch = sw * 0.45f * limbDistance + 0.05f - drift;
                    rightArm.roll = 0.08f;
                    leftArm.roll = -0.08f;
                    rightArm.yaw = 0f;
                    leftArm.yaw = 0f;
                }
                case 2 -> {   // одна рука тянется вперёд
                    rightArm.pitch = -1.45f + drift;
                    leftArm.pitch = sw * 0.4f * limbDistance + 0.08f;
                    leftArm.roll = -0.1f;
                    leftArm.yaw = 0f;
                }
                case 3 -> {   // руки полуподняты
                    rightArm.pitch = -0.85f + drift + sw * 0.15f * limbDistance;
                    leftArm.pitch = -0.75f - drift - sw * 0.15f * limbDistance;
                }
                default -> {  // классика: руки вперёд, чуть вразнобой
                    rightArm.pitch += drift;
                    leftArm.pitch -= drift * 0.8f;
                }
            }
        }
        if (handSwingProgress > 0f) {
            float s = MathHelper.sin(handSwingProgress * MathHelper.PI);
            rightArm.pitch -= s * 0.9f;
            leftArm.pitch -= s * 0.6f;
            body.pitch += s * 0.15f;
        }
        hat.copyTransform(head);
    }

    /** Модель уже повёрнута лицом вниз (см. рендерер): руки тянутся вперёд и подтягивают тело. */
    private void crawl(float limbAngle, float limbDistance, float age, float ph) {
        float c = MathHelper.cos(limbAngle * 0.5f), s = MathHelper.sin(limbAngle * 0.5f);
        float k = 0.3f + Math.min(1f, limbDistance * 3f) * 0.7f;
        rightArm.pitch = MathHelper.PI + 0.35f + c * 0.65f * k;
        leftArm.pitch = MathHelper.PI + 0.35f - c * 0.65f * k;
        rightArm.yaw = -0.25f + s * 0.2f * k;
        leftArm.yaw = 0.25f + s * 0.2f * k;
        rightArm.roll = 0.1f;
        leftArm.roll = -0.1f;
        head.pitch = -1.05f + 0.06f * MathHelper.sin(age * 0.08f + ph);
        head.roll = 0.15f * MathHelper.sin(ph);
        head.yaw *= 0.5f;
        body.pitch = 0f;
        body.roll = 0.06f * c * k;
        rightLeg.pitch = 0.08f + s * 0.12f * k;
        leftLeg.pitch = 0.08f - s * 0.12f * k;
        rightLeg.roll = 0.12f;
        leftLeg.roll = -0.12f;
    }
}
