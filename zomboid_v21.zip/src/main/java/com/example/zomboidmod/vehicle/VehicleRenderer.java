package com.example.zomboidmod.vehicle;

import com.example.zomboidmod.ZomboidMod;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

import java.util.ArrayList;
import java.util.List;

/** Рисует транспорт: кузов в цвет машины, колёса крутятся, передние поворачиваются, мотоцикл наклоняется в повороте. */
public class VehicleRenderer extends EntityRenderer<VehicleEntity> {
    private final VehicleType type;
    private final Identifier texture;
    private final List<ModelPart> paint = new ArrayList<>(), trim = new ArrayList<>(), steerParts = new ArrayList<>();
    private final List<ModelPart> frontWheels = new ArrayList<>(), wheels = new ArrayList<>();
    private ModelPart steeringWheel;

    public VehicleRenderer(EntityRendererFactory.Context ctx, VehicleType type) {
        super(ctx);
        this.type = type;
        this.texture = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/vehicle/" + type.id + ".png");
        this.shadowRadius = type.width * 0.45f;
        ModelPart root = VehicleModels.create(type.id).createModel();
        for (String[] p : VehicleModels.parts(type.id)) {
            ModelPart part = root.getChild(p[0]);
            switch (p[2]) {
                case "wheel" -> {
                    wheels.add(part);
                    if (part.pivotZ < 0) frontWheels.add(part);   // перед модели — отрицательный z
                }
                case "steer" -> {
                    steerParts.add(part);
                    if (p[1].equals("trim")) {
                        try {
                            wheels.add(part.getChild("w0"));
                        } catch (Exception ignored) {
                        }
                    }
                }
                default -> {
                    if (p[0].equals("t3")) steeringWheel = part;
                    if (p[1].equals("paint")) paint.add(part);
                    else trim.add(part);
                }
            }
            if (p[2].equals("steer")) {
                if (p[1].equals("paint")) paint.add(part);
                else trim.add(part);
            }
            if (p[2].equals("wheel")) trim.add(part);
        }
    }

    @Override
    public void render(VehicleEntity e, float yaw, float tickDelta, MatrixStack m, VertexConsumerProvider vcp, int light) {
        m.push();
        float steer = MathHelper.lerp(tickDelta, e.prevSteer, e.steer);
        float wheel = MathHelper.lerp(tickDelta, e.prevWheelAngle, e.wheelAngle);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - yaw));
        if (type.bike()) {
            float sp = MathHelper.clamp(e.clientSpeed / 0.5f, 0f, 1f);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(steer * 16f * sp));
        }
        if (e.broken()) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(2.5f));
        m.scale(-0.5f, -0.5f, 0.5f);

        for (ModelPart w : wheels) w.pitch = wheel;
        for (ModelPart w : frontWheels) w.yaw = -steer * 0.5f;
        for (ModelPart s : steerParts) s.yaw = -steer * 0.45f;
        if (steeringWheel != null) steeringWheel.roll = steer * 1.2f;

        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityTranslucent(texture));
        int overlay = OverlayTexture.DEFAULT_UV;
        int c = e.color();
        float dmg = MathHelper.clamp(e.health() / type.maxHealth, 0f, 1f);
        float k = 0.55f + 0.45f * dmg;   // побитая машина темнее
        int r = (int) (((c >> 16) & 255) * k), g = (int) (((c >> 8) & 255) * k), b = (int) ((c & 255) * k);
        int paintColor = 0xFF000000 | (r << 16) | (g << 8) | b;
        int kk = (int) (255 * (0.75f + 0.25f * dmg));
        int trimColor = 0xFF000000 | (kk << 16) | (kk << 8) | kk;
        for (ModelPart p : paint) p.render(m, vc, light, overlay, paintColor);
        for (ModelPart p : trim) p.render(m, vc, light, overlay, trimColor);
        m.pop();
        super.render(e, yaw, tickDelta, m, vcp, light);
    }

    @Override
    public Identifier getTexture(VehicleEntity entity) {
        return texture;
    }
}
