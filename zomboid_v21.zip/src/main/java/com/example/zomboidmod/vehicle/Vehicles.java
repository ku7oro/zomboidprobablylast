package com.example.zomboidmod.vehicle;

import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

/** Регистрация транспорта: сущности, предметы, звуки, гудок. */
public final class Vehicles {
    public static final Map<VehicleType, Item> ITEMS = new EnumMap<>(VehicleType.class);
    public static Item GAS_CAN;
    public static SoundEvent ENGINE_CAR, ENGINE_BIKE, HORN, CRASH, ENGINE_START, REFUEL;

    private Vehicles() {
    }

    private static SoundEvent sound(String id) {
        Identifier i = Identifier.of(ZomboidMod.MOD_ID, id);
        return Registry.register(Registries.SOUND_EVENT, i, SoundEvent.of(i));
    }

    public static void register() {
        ENGINE_CAR = sound("engine_car");
        ENGINE_BIKE = sound("engine_bike");
        HORN = sound("horn");
        CRASH = sound("crash");
        ENGINE_START = sound("engine_start");
        REFUEL = sound("refuel");

        for (VehicleType t : VehicleType.values()) {
            EntityType<VehicleEntity> et = Registry.register(Registries.ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, t.id),
                    EntityType.Builder.<VehicleEntity>create(VehicleEntity::new, SpawnGroup.MISC)
                            .dimensions(t.width, t.height)
                            .maxTrackingRange(10)
                            .build(t.id));
            VehicleType.bind(t, et);
            ITEMS.put(t, Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, t.id), new VehicleItem(t, new Item.Settings())));
        }
        GAS_CAN = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, "gas_can"), new GasCanItem(new Item.Settings()));

        ItemGroup group = FabricItemGroup.builder()
                .icon(() -> new ItemStack(ITEMS.get(VehicleType.SEDAN)))
                .displayName(Text.translatable("itemGroup.zomboidmod.vehicles"))
                .entries((ctx, entries) -> {
                    ITEMS.values().forEach(entries::add);
                    entries.add(GAS_CAN);
                })
                .build();
        Registry.register(Registries.ITEM_GROUP, Identifier.of(ZomboidMod.MOD_ID, "vehicles"), group);

        PayloadTypeRegistry.playC2S().register(HornPayload.ID, HornPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(HornPayload.ID, (payload, context) -> context.server().execute(() -> {
            if (context.player().getVehicle() instanceof VehicleEntity v && v.getControllingPassenger() == context.player()) v.honk();
        }));
    }
}
