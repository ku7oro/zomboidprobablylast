package com.example.zomboidmod.vehicle;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;

/** Поставить машину (для творческого режима): полный бак, случайный цвет. */
public class VehicleItem extends Item {
    private final VehicleType type;

    public VehicleItem(VehicleType type, Settings settings) {
        super(settings.maxCount(1));
        this.type = type;
    }

    @Override
    public Text getName(ItemStack stack) {
        return Text.literal(type.ru);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        if (!(ctx.getWorld() instanceof ServerWorld w)) return ActionResult.SUCCESS;
        BlockPos pos = ctx.getBlockPos().offset(ctx.getSide());
        VehicleEntity v = type.entityType.create(w);
        if (v == null) return ActionResult.FAIL;
        PlayerEntity p = ctx.getPlayer();
        v.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, p != null ? p.getYaw() : 0f, 0f);
        v.randomize(w.getRandom(), false);
        v.setFuel(type.fuelCap);
        v.setHealth(type.maxHealth);
        if (!w.isSpaceEmpty(v, v.getBoundingBox().contract(0.05))) return ActionResult.FAIL;
        w.spawnEntity(v);
        ctx.getStack().decrementUnlessCreative(1, p);
        return ActionResult.CONSUME;
    }
}
