package com.example.zomboidmod.vehicle;

import com.example.zomboidmod.ZomboidMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record HornPayload() implements CustomPayload {
    public static final CustomPayload.Id<HornPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "horn"));
    public static final PacketCodec<RegistryByteBuf, HornPayload> CODEC = PacketCodec.unit(new HornPayload());

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
