package com.example.zomboidmod.vehicle;

import net.minecraft.entity.EntityType;

import java.util.HashMap;
import java.util.Map;

/** Виды транспорта: размеры, скорость, бак, прочность, места (x влево, y, z вперёд — в блоках), багажник. */
public enum VehicleType {
    SEDAN("sedan", "Седан", 2.3f, 1.55f, 0.95f, 0.014f, 4.0f, 50f, 100f, 18, false, 10,
            new float[][]{{0.42f, 0.35f, 0.15f}, {-0.42f, 0.35f, 0.15f}, {0.4f, 0.32f, -0.72f}, {-0.4f, 0.32f, -0.72f}}),
    POLICE("police", "Полицейская машина", 2.3f, 1.6f, 1.1f, 0.018f, 4.2f, 60f, 130f, 9, false, 10,
            new float[][]{{0.42f, 0.35f, 0.15f}, {-0.42f, 0.35f, 0.15f}, {0.4f, 0.32f, -0.72f}, {-0.4f, 0.32f, -0.72f}}),
    PICKUP("pickup", "Пикап", 2.4f, 1.85f, 0.9f, 0.013f, 3.6f, 70f, 140f, 27, true, 12,
            new float[][]{{0.42f, 0.41f, 0.3f}, {-0.42f, 0.41f, 0.3f}}),
    VAN("van", "Фургон", 2.5f, 2.15f, 0.8f, 0.011f, 3.3f, 75f, 150f, 36, false, 10.5f,
            new float[][]{{0.47f, 0.47f, 1.2f}, {-0.47f, 0.47f, 1.2f}}),
    AMBULANCE("ambulance", "Скорая помощь", 2.5f, 2.25f, 0.9f, 0.013f, 3.4f, 75f, 160f, 27, false, 10.5f,
            new float[][]{{0.47f, 0.47f, 1.2f}, {-0.47f, 0.47f, 1.2f}}),
    MOTORCYCLE("motorcycle", "Мотоцикл", 1.1f, 1.4f, 1.15f, 0.022f, 5.5f, 16f, 45f, 0, false, 11,
            new float[][]{{0f, 0.76f, -0.3f}, {0f, 0.82f, -0.72f}}),
    DIRT_BIKE("dirt_bike", "Кроссовый мотоцикл", 1.0f, 1.45f, 1.0f, 0.021f, 5.8f, 9f, 35f, 0, true, 12,
            new float[][]{{0f, 0.94f, -0.3f}});

    public final String id, ru;
    public final float width, height, maxSpeed, accel, turn, fuelCap, maxHealth, wheelRadius;
    public final int trunk;
    public final boolean offroad;
    public final float[][] seats;
    public EntityType<VehicleEntity> entityType;

    private static final Map<EntityType<?>, VehicleType> BY_ENTITY = new HashMap<>();

    VehicleType(String id, String ru, float width, float height, float maxSpeed, float accel, float turn, float fuelCap, float maxHealth,
                int trunk, boolean offroad, float wheelRadius, float[][] seats) {
        this.id = id;
        this.ru = ru;
        this.width = width;
        this.height = height;
        this.maxSpeed = maxSpeed;
        this.accel = accel;
        this.turn = turn;
        this.fuelCap = fuelCap;
        this.maxHealth = maxHealth;
        this.trunk = trunk;
        this.offroad = offroad;
        this.wheelRadius = wheelRadius;
        this.seats = seats;
    }

    public boolean bike() {
        return this == MOTORCYCLE || this == DIRT_BIKE;
    }

    /** Расход: литров на блок пути. Полного бака хватает примерно на 2500-3500 блоков. */
    public float fuelPerBlock() {
        return fuelCap / (bike() ? 2600f : 3200f);
    }

    static void bind(VehicleType t, EntityType<VehicleEntity> et) {
        t.entityType = et;
        BY_ENTITY.put(et, t);
    }

    public static VehicleType of(EntityType<?> et) {
        VehicleType t = BY_ENTITY.get(et);
        return t == null ? SEDAN : t;
    }

    public static VehicleType byId(String id) {
        for (VehicleType t : values()) if (t.id.equals(id)) return t;
        return SEDAN;
    }

    /** Гражданские машины для парковок и улиц. */
    public static VehicleType randomCivil(net.minecraft.util.math.random.Random r) {
        float k = r.nextFloat();
        if (k < 0.48f) return SEDAN;
        if (k < 0.72f) return PICKUP;
        if (k < 0.86f) return VAN;
        if (k < 0.95f) return MOTORCYCLE;
        return DIRT_BIKE;
    }
}
