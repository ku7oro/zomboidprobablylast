package com.example.zomboidmod.block;

import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.LinkedHashMap;
import java.util.Map;

/** Сгенерировано gen_building_blocks.py: сайдинг, кирпич, черепица, обои, полы и отделка для домов. */
public final class BuildingBlocks {
    public static final Map<String, Block> ALL = new LinkedHashMap<>();

    private BuildingBlocks() {
    }

    public static Block get(String id) {
        return ALL.get(id);
    }

    private static Block reg(String id, Block b) {
        Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, id), b);
        Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), new BlockItem(b, new Item.Settings()));
        ALL.put(id, b);
        return b;
    }

    private static AbstractBlock.Settings settings(String snd) {
        BlockSoundGroup g = switch (snd) {
            case "STONE" -> BlockSoundGroup.STONE;
            case "WOOL" -> BlockSoundGroup.WOOL;
            default -> BlockSoundGroup.WOOD;
        };
        return AbstractBlock.Settings.create().strength(snd.equals("STONE") ? 2.0f : 1.5f).sounds(g);
    }

    private static void block(String id, String snd) {
        reg(id, new Block(settings(snd)));
    }

    private static void stairs(String id) {
        Block base = ALL.get(id);
        reg(id + "_stairs", new StairsBlock(base.getDefaultState(), AbstractBlock.Settings.copy(base)));
        reg(id + "_slab", new SlabBlock(AbstractBlock.Settings.copy(base)));
    }

    public static void register() {
        block("siding_white", "WOOD");
        block("siding_beige", "WOOD");
        block("siding_blue", "WOOD");
        block("siding_green", "WOOD");
        block("siding_yellow", "WOOD");
        block("siding_gray", "WOOD");
        block("siding_red", "WOOD");
        block("brick_old", "STONE");
        block("brick_tan", "STONE");
        block("shingles_dark", "WOOD");
        stairs("shingles_dark");
        block("shingles_brown", "WOOD");
        stairs("shingles_brown");
        block("shingles_red", "WOOD");
        stairs("shingles_red");
        block("shingles_green", "WOOD");
        stairs("shingles_green");
        block("wallpaper_floral", "WOOD");
        block("wallpaper_stripes", "WOOD");
        block("wallpaper_beige", "WOOD");
        block("wallpaper_green", "WOOD");
        block("wallpaper_blue", "WOOD");
        block("drywall", "WOOD");
        block("floor_hardwood", "WOOD");
        block("floor_hardwood_dark", "WOOD");
        block("floor_linoleum", "WOOD");
        block("floor_tile", "STONE");
        block("floor_carpet_beige", "WOOL");
        block("floor_carpet_blue", "WOOL");
        block("trim_white", "WOOD");
        block("foundation", "STONE");
        ItemGroup group = FabricItemGroup.builder()
                .icon(() -> new ItemStack(ALL.get("siding_white")))
                .displayName(Text.translatable("itemGroup.zomboidmod.building"))
                .entries((ctx, entries) -> ALL.values().forEach(entries::add))
                .build();
        Registry.register(Registries.ITEM_GROUP, Identifier.of(ZomboidMod.MOD_ID, "building"), group);
    }
}
