package com.example.zomboidmod.world;

import com.example.zomboidmod.ZombieOutfit;
import com.example.zomboidmod.block.BuildingBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;

/**
 * Большие дома с двойными стенами (снаружи сайдинг или кирпич, внутри обои), разными полами по комнатам,
 * настоящими лестницами, крыльцом и черепичной крышей. Участок: улица с севера (z = 0).
 */
final class Houses {
    private Houses() {
    }

    record HS(BlockState ext, BlockState inner, Block roofStairs, Block roofSlab, BlockState roof, BlockState trim, Block door,
              BlockState floor, BlockState kitchen, BlockState bath, BlockState bedroom, BlockState found, Block stairs) {}

    static Block B(String id) {
        return BuildingBlocks.get(id);
    }

    static BlockState S(String id) {
        return B(id).getDefaultState();
    }

    static HS style(Random r, boolean brick) {
        String[] sid = {"siding_white", "siding_beige", "siding_blue", "siding_green", "siding_yellow", "siding_gray", "siding_red"};
        String[] wp = {"wallpaper_floral", "wallpaper_stripes", "wallpaper_beige", "wallpaper_green", "wallpaper_blue", "drywall"};
        String[] sh = {"shingles_dark", "shingles_brown", "shingles_red", "shingles_green"};
        String ext = brick ? (r.nextBoolean() ? "brick_old" : "brick_tan") : sid[r.nextInt(sid.length)];
        String roof = sh[r.nextInt(sh.length)];
        Block[] doors = {Blocks.OAK_DOOR, Blocks.SPRUCE_DOOR, Blocks.DARK_OAK_DOOR, Blocks.BIRCH_DOOR};
        Block[] st = {Blocks.OAK_STAIRS, Blocks.SPRUCE_STAIRS, Blocks.DARK_OAK_STAIRS};
        return new HS(S(ext), S(wp[r.nextInt(wp.length)]), B(roof + "_stairs"), B(roof + "_slab"), S(roof), S("trim_white"),
                doors[r.nextInt(doors.length)], S(r.nextBoolean() ? "floor_hardwood" : "floor_hardwood_dark"), S("floor_linoleum"),
                S("floor_tile"), S(r.nextBoolean() ? "floor_carpet_beige" : "floor_carpet_blue"), S("foundation"), st[r.nextInt(st.length)]);
    }

    // ===================== конструктор =====================

    /** Этаж с двойными стенами: пол на y0, стены y0+1..y0+h, полоса отделки между этажами. */
    static void shell(Plan p, int x1, int z1, int x2, int z2, int y0, int h, HS s, BlockState floor) {
        p.fill(x1, y0, z1, x2, y0, z2, y0 == 0 ? s.found() : s.trim());
        p.fill(x1 + 2, y0, z1 + 2, x2 - 2, y0, z2 - 2, floor);
        p.walls(x1, y0 + 1, z1, x2, y0 + h, z2, s.ext());
        p.walls(x1 + 1, y0 + 1, z1 + 1, x2 - 1, y0 + h, z2 - 1, s.inner());
        p.air(x1 + 2, y0 + 1, z1 + 2, x2 - 2, y0 + h, z2 - 2);
    }

    /** Окно сквозь двойную стену: стекло снаружи, ниша внутри, подоконник и перемычка белые. */
    static void window(Plan p, int x, int y, int z, Direction out, HS s) {
        p.set(x, y, z, Buildings.GLASS);
        p.set(x, y + 1, z, s.trim());
        p.set(x, y - 1, z, s.trim());
        p.set(x - out.getOffsetX(), y, z - out.getOffsetZ(), Blocks.AIR);
    }

    static void door(Plan p, int x, int y, int z, Direction out, Block door) {
        p.door(x, y, z, door, out);
        p.air(x - out.getOffsetX(), y, z - out.getOffsetZ(), x - out.getOffsetX(), y + 1, z - out.getOffsetZ());
    }

    static void wallX(Plan p, int x, int z1, int z2, int y, int h, BlockState b) {
        p.fill(x, y, z1, x, y + h - 1, z2, b);
    }

    static void wallZ(Plan p, int z, int x1, int x2, int y, int h, BlockState b) {
        p.fill(x1, y, z, x2, y + h - 1, z, b);
    }

    static void opening(Plan p, int x, int y, int z) {
        p.air(x, y, z, x, y + 1, z);
    }

    /** Двускатная крыша из черепицы с коньком вдоль x. */
    static void gable(Plan p, int x1, int z1, int x2, int z2, int yr, HS s) {
        p.fill(x1, yr, z1, x2, yr, z2, s.trim());
        int a = z1 - 1, b = z2 + 1, k = 0;
        while (a + k < b - k) {
            for (int x = x1 - 1; x <= x2 + 1; x++) {
                p.set(x, yr + k, a + k, p.stair(s.roofStairs(), Direction.SOUTH, false));
                p.set(x, yr + k, b - k, p.stair(s.roofStairs(), Direction.NORTH, false));
            }
            for (int z = a + k + 1; z <= b - k - 1; z++) {
                if (z >= z1 && z <= z2) {
                    p.set(x1, yr + k, z, s.ext());
                    p.set(x2, yr + k, z, s.ext());
                }
                if (k > 0) for (int x = x1 + 1; x < x2; x++) if (z > a + k && z < b - k) p.set(x, yr + k, z, Blocks.AIR.getDefaultState());
            }
            k++;
        }
        if (a + k == b - k) for (int x = x1 - 1; x <= x2 + 1; x++) p.set(x, yr + k, a + k, p.slab(s.roofSlab(), false));
        // слуховое окно во фронтоне
        int zm = (z1 + z2) / 2;
        p.set(x1, yr + 1, zm, Buildings.GLASS);
        p.set(x2, yr + 1, zm, Buildings.GLASS);
    }

    /** Прямая лестница вверх на h+1 ступеней в сторону dir, с проёмом в перекрытии над ней. */
    static void staircase(Plan p, int x, int y0, int z, int h, Direction dir, Block stairs) {
        int dx = dir.getOffsetX(), dz = dir.getOffsetZ();
        for (int k = 0; k <= h; k++) {
            int sx = x + dx * k, sz = z + dz * k;
            p.set(sx, y0 + 1 + k, sz, p.stair(stairs, dir, false));
            p.air(sx, y0 + 2 + k, sz, sx, y0 + 3 + k, sz);
        }
        // под лестницей — кладовка
        for (int k = 1; k <= h; k++) p.fill(x + dx * k, y0 + 1, z + dz * k, x + dx * k, y0 + k, z + dz * k, Blocks.SPRUCE_PLANKS);
    }

    static void ceilingLamp(Plan p, int x, int y, int z) {
        Buildings.lamp(p, x, y, z);
    }

    static Block bed(Random r) {
        Block[] beds = {Blocks.RED_BED, Blocks.BLUE_BED, Blocks.WHITE_BED, Blocks.GREEN_BED, Blocks.BROWN_BED, Blocks.GRAY_BED, Blocks.CYAN_BED};
        return beds[r.nextInt(beds.length)];
    }

    static Block rug(Random r) {
        Block[] rugs = {Blocks.RED_CARPET, Blocks.BROWN_CARPET, Blocks.GREEN_CARPET, Blocks.BLUE_CARPET, Blocks.GRAY_CARPET, Blocks.LIGHT_GRAY_CARPET};
        return rugs[r.nextInt(rugs.length)];
    }

    static void porch(Plan p, int x1, int x2, int z1, int z2, int roofY, int doorX, HS s) {
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.SPRUCE_PLANKS);
        for (int x = x1; x <= x2; x++) {
            if (Math.abs(x - doorX) <= 1) continue;
            p.set(x, 1, z1, Blocks.BIRCH_FENCE);
        }
        for (int x : new int[]{x1, x2, (x1 + doorX) / 2, (x2 + doorX) / 2}) p.fill(x, 1, z1, x, roofY - 1, z1, Blocks.BIRCH_FENCE);
        p.fill(x1 - 1, roofY, z1 - 1, x2 + 1, roofY, z2, p.slab(s.roofSlab(), false));
        p.set(doorX, 0, z1 - 1, Blocks.DIRT_PATH);
        p.furn(x2 - 2, 1, z1 + 1, "chair", Direction.NORTH);
        if (p.r.nextBoolean()) p.set(x1 + 1, 1, z1 + 1, Blocks.POTTED_POPPY);
    }

    // ===================== одноэтажный дом с крыльцом (16x16) =====================
    static void bungalow(Plan p) {
        HS s = style(p.r, p.r.nextFloat() < 0.25f);
        Direction N = Direction.NORTH, S = Direction.SOUTH, E = Direction.EAST, W = Direction.WEST;
        int x1 = 1, x2 = 14, z1 = 4, z2 = 14, h = 3;
        shell(p, x1, z1, x2, z2, 0, h, s, s.floor());
        p.fill(9, 0, 6, 12, 0, 8, s.kitchen());
        p.fill(9, 0, 10, 12, 0, 12, s.bedroom());
        p.fill(3, 0, 11, 7, 0, 12, s.bath());
        wallX(p, 8, 6, 12, 1, h, s.inner());
        wallZ(p, 9, 9, 12, 1, h, s.inner());
        wallZ(p, 10, 3, 7, 1, h, s.inner());
        opening(p, 8, 1, 7);
        opening(p, 4, 1, 10);
        opening(p, 10, 1, 9);
        door(p, 5, 1, z1, N, s.door());
        door(p, 10, 1, z2, S, s.door());
        for (int x : new int[]{3, 11}) window(p, x, 2, z1, N, s);
        for (int x : new int[]{4, 12}) window(p, x, 2, z2, S, s);
        for (int z : new int[]{7, 12}) window(p, x1, 2, z, W, s);
        for (int z : new int[]{7, 11}) window(p, x2, 2, z, E, s);
        gable(p, x1, z1, x2, z2, h + 1, s);
        porch(p, 2, 13, 1, 3, h + 1, 5, s);
        // гостиная
        p.furn(5, 1, 9, "sofa", N);
        p.furn(6, 1, 9, "sofa", N);
        p.furn(7, 1, 8, "armchair", W);
        p.furn(6, 1, 6, "tv", S);
        p.furn(3, 1, 6, "floor_lamp", S);
        p.furn(7, 1, 6, "radio", S);
        p.set(5, 1, 7, rug(p.r));
        p.set(6, 1, 7, rug(p.r));
        if (p.r.nextFloat() < 0.6f) p.pile(3, 1, 8, Loot.LIVING);
        // кухня
        p.furnLoot(12, 1, 6, "fridge", W, Loot.FRIDGE);
        p.furnLoot(12, 1, 7, "stove", W, Loot.KITCHEN);
        p.furnLoot(12, 1, 8, "kitchen_sink", W, Loot.KITCHEN);
        p.furnLoot(11, 1, 6, "kitchen_counter", S, Loot.KITCHEN);
        p.furn(11, 1, 7, "kitchen_table", N);
        p.furn(11, 1, 8, "chair", N);
        if (p.r.nextFloat() < 0.7f) p.pile(11, 2, 7, Loot.KITCHEN);
        // спальня
        p.bed(12, 1, 11, bed(p.r), S);
        p.furnLoot(11, 1, 12, "nightstand", N, Loot.BEDROOM);
        p.furnLoot(9, 1, 12, "wardrobe", N, Loot.BEDROOM);
        p.furnLoot(9, 1, 10, "dresser", E, Loot.BEDROOM);
        // ванная
        p.furn(3, 1, 12, "toilet", E);
        p.furnLoot(5, 1, 12, "bathroom_sink", N, Loot.BATHROOM);
        p.furn(7, 1, 12, "bathtub", N);
        p.furn(7, 1, 11, "washing_machine", W);
        for (int[] l : new int[][]{{5, 7}, {10, 7}, {11, 11}, {5, 11}}) ceilingLamp(p, l[0], h, l[1]);
        if (p.r.nextFloat() < 0.6f) p.tree(1 + p.r.nextInt(2), 0, 15, p.r.nextInt(3));
        p.zombie(5, 1, 7, null);
        if (p.r.nextFloat() < 0.5f) p.zombie(10, 1, 11, null);
    }

    // ===================== двухэтажный дом: фермерский с крыльцом или колониальный кирпичный =====================
    static void twoFloor(Plan p, boolean farmhouse) {
        HS s = style(p.r, !farmhouse && p.r.nextFloat() < 0.7f);
        Direction N = Direction.NORTH, S = Direction.SOUTH, E = Direction.EAST, W = Direction.WEST;
        int x1 = 2, x2 = 17, z1 = farmhouse ? 5 : 3, z2 = z1 + 11, h = 3;
        int Z = z1 + 2;        // первая клетка внутри
        int zi2 = z2 - 2;
        // первый этаж
        shell(p, x1, z1, x2, z2, 0, h, s, s.floor());
        p.fill(11, 0, Z, 15, 0, Z + 3, s.kitchen());
        p.fill(11, 0, Z + 5, 15, 0, zi2, s.bath());
        wallX(p, 10, Z, zi2, 1, h, s.inner());
        wallZ(p, Z + 4, 11, 15, 1, h, s.inner());
        opening(p, 10, 1, Z + 1);
        opening(p, 13, 1, Z + 4);
        door(p, 7, 1, z1, N, s.door());
        door(p, 8, 1, z2, S, s.door());
        // второй этаж
        shell(p, x1, z1, x2, z2, h + 1, h, s, s.bedroom());
        int y2 = h + 2;
        wallX(p, 10, Z, zi2, y2, h, s.inner());
        wallZ(p, Z + 3, 5, 9, y2, h, s.inner());
        wallZ(p, Z + 4, 11, 15, y2, h, s.inner());
        opening(p, 7, y2, Z + 3);
        opening(p, 10, y2, Z + 6);
        opening(p, 13, y2, Z + 4);
        // лестница вдоль западной стены
        staircase(p, 4, 0, Z + 3, h, S, s.stairs());
        p.set(5, y2, Z + 4, Blocks.OAK_FENCE);
        p.set(5, y2, Z + 5, Blocks.OAK_FENCE);
        // окна
        for (int y : new int[]{2, h + 3}) {
            for (int x : new int[]{5, 12, 14}) window(p, x, y, z1, N, s);
            for (int x : new int[]{5, 12, 14}) window(p, x, y, z2, S, s);
            for (int z : new int[]{Z + 1, Z + 6}) {
                window(p, x1, y, z, W, s);
                window(p, x2, y, z, E, s);
            }
        }
        gable(p, x1, z1, x2, z2, 2 * h + 2, s);
        if (farmhouse) porch(p, x1 - 1, x2 + 1, 1, 4, h + 1, 7, s);
        else {   // портик с колоннами
            p.fill(6, 0, 1, 8, 0, 2, s.trim());
            for (int x : new int[]{5, 9}) p.fill(x, 1, 1, x, h, 1, Blocks.QUARTZ_PILLAR);
            p.fill(5, h + 1, 0, 9, h + 1, 2, p.slab(Blocks.SMOOTH_QUARTZ_SLAB, false));
            p.set(7, 0, 0, Blocks.DIRT_PATH);
            for (int x : new int[]{3, 11}) Buildings.hedge(p, x, 1, x + 2);
        }
        // гостиная (запад, 1 этаж)
        p.furn(5, 1, Z, "tv", S);
        p.furn(4, 1, Z, "floor_lamp", S);
        p.furn(5, 1, Z + 2, "sofa", N);
        p.furn(6, 1, Z + 2, "sofa", N);
        p.furn(8, 1, Z + 3, "armchair", N);
        p.set(5, 1, Z + 1, rug(p.r));
        p.set(6, 1, Z + 1, rug(p.r));
        p.set(9, 1, Z + 5, Blocks.BOOKSHELF);
        p.set(9, 1, Z + 6, Blocks.BOOKSHELF);
        p.furn(6, 1, Z + 6, "kitchen_table", N);
        p.furn(6, 1, Z + 5, "chair", S);
        p.furn(6, 1, Z + 7, "chair", N);
        if (p.r.nextFloat() < 0.6f) p.pile(6, 2, Z + 6, Loot.LIVING);
        // кухня
        p.furnLoot(15, 1, Z, "fridge", W, Loot.FRIDGE);
        p.furnLoot(15, 1, Z + 1, "stove", W, Loot.KITCHEN);
        p.furnLoot(15, 1, Z + 2, "kitchen_sink", W, Loot.KITCHEN);
        p.furnLoot(15, 1, Z + 3, "kitchen_counter", W, Loot.KITCHEN);
        for (int x = 12; x <= 14; x++) p.furnLoot(x, 1, Z, "kitchen_counter", S, Loot.KITCHEN);
        p.furn(12, 1, Z + 2, "kitchen_table", N);
        p.furn(12, 1, Z + 3, "chair", N);
        p.furn(11, 1, Z + 2, "chair", E);
        if (p.r.nextFloat() < 0.6f) p.pile(12, 2, Z + 2, Loot.KITCHEN);
        // ванная внизу
        p.furn(11, 1, zi2, "toilet", E);
        p.furnLoot(12, 1, zi2, "bathroom_sink", N, Loot.BATHROOM);
        p.furn(15, 1, zi2, "bathtub", N);
        p.furn(15, 1, Z + 5, "washing_machine", W);
        // спальни наверху
        p.bed(5, y2, Z + 1, bed(p.r), N);
        p.furnLoot(4, y2, Z, "nightstand", S, Loot.BEDROOM);
        p.furnLoot(9, y2, Z, "wardrobe", S, Loot.BEDROOM);
        p.furnLoot(9, y2, Z + 2, "dresser", W, Loot.BEDROOM);
        p.bed(12, y2, Z + 1, bed(p.r), N);
        p.furnLoot(11, y2, Z, "nightstand", S, Loot.BEDROOM);
        p.furnLoot(15, y2, Z, "wardrobe", S, Loot.BEDROOM);
        p.furnLoot(15, y2, Z + 2, "dresser", W, Loot.BEDROOM);
        p.bed(14, y2, Z + 6, bed(p.r), E);
        p.furnLoot(15, y2, zi2, "nightstand", N, Loot.BEDROOM);
        p.furnLoot(12, y2, zi2, "desk", N, Loot.OFFICE);
        p.furnLoot(11, y2, Z + 5, "cardboard_box", E, Loot.BEDROOM);
        p.set(9, y2, zi2, Blocks.BOOKSHELF);
        if (p.r.nextFloat() < 0.6f) p.pile(7, y2, Z + 1, Loot.BEDROOM);
        if (p.r.nextFloat() < 0.5f) p.pile(13, y2, Z + 2, Loot.BEDROOM);
        for (int[] l : new int[][]{{6, Z + 1}, {13, Z + 1}, {13, Z + 6}, {7, Z + 5}}) {
            ceilingLamp(p, l[0], h, l[1]);
            ceilingLamp(p, l[0], 2 * h + 1, l[1]);
        }
        p.zombie(7, 1, Z + 2, null);
        if (p.r.nextFloat() < 0.6f) p.zombie(13, y2, Z + 2, null);
        if (p.r.nextFloat() < 0.4f) p.zombie(13, 1, Z + 6, null);
        if (farmhouse && p.r.nextFloat() < 0.5f) p.tree(18, 0, z2 + 1, p.r.nextInt(3));
    }

    // ===================== трёхэтажный кирпичный дом на 6 квартир (25x20) =====================
    static void apartment(Plan p) {
        HS s = style(p.r, true);
        Direction N = Direction.NORTH, S = Direction.SOUTH, E = Direction.EAST, W = Direction.WEST;
        int x1 = 1, x2 = 23, z1 = 3, z2 = 18, h = 3;
        for (int f = 0; f < 3; f++) {
            int yb = f * (h + 1);
            shell(p, x1, z1, x2, z2, yb, h, s, s.floor());
            int y = yb + 1;
            p.fill(11, yb, 5, 13, yb, 16, S("floor_linoleum"));
            wallX(p, 10, 5, 16, y, h, s.inner());
            wallX(p, 14, 5, 16, y, h, s.inner());
            for (int side = 0; side < 2; side++) {
                boolean east = side == 1;
                // зеркалим по x для восточной квартиры
                int ax1 = east ? 15 : 3, ax2 = east ? 21 : 9;
                wallZ(p, 10, ax1, ax2, y, h, s.inner());
                int bx = east ? 18 : 6;
                wallX(p, bx, 11, 16, y, h, s.inner());
                opening(p, mx(8, east), y, 10);
                opening(p, bx, y, 13);
                p.door(east ? 14 : 10, y, 7, Blocks.OAK_DOOR, east ? E : W);
                p.fill(mx(3, east), yb, 11, mx(5, east), yb, 16, s.bath());
                p.fill(ax1, yb, 5, ax2, yb, 9, s.floor());
                p.fill(mx(7, east), yb, 11, mx(9, east), yb, 16, s.bedroom());
                Direction in = east ? W : E, out = east ? E : W;
                // кухня-гостиная
                p.furnLoot(mx(3, east), y, 5, "fridge", in, Loot.FRIDGE);
                p.furnLoot(mx(3, east), y, 6, "stove", in, Loot.KITCHEN);
                p.furnLoot(mx(3, east), y, 7, "kitchen_sink", in, Loot.KITCHEN);
                p.furn(mx(5, east), y, 7, "kitchen_table", N);
                p.furn(mx(5, east), y, 8, "chair", N);
                p.furn(mx(6, east), y, 9, "sofa", N);
                p.furn(mx(7, east), y, 9, "sofa", N);
                p.furn(mx(7, east), y, 5, "tv", S);
                if (p.r.nextFloat() < 0.5f) p.pile(mx(5, east), y + 1, 7, Loot.KITCHEN);
                // спальня
                p.bed(mx(8, east), y, 15, bed(p.r), S);
                p.furnLoot(mx(9, east), y, 16, "nightstand", N, Loot.BEDROOM);
                p.furnLoot(mx(7, east), y, 16, "wardrobe", N, Loot.BEDROOM);
                if (p.r.nextFloat() < 0.5f) p.pile(mx(9, east), y, 12, Loot.BEDROOM);
                // ванная
                p.furn(mx(3, east), y, 16, "toilet", in);
                p.furnLoot(mx(4, east), y, 16, "bathroom_sink", N, Loot.BATHROOM);
                p.furn(mx(3, east), y, 11, "bathtub", N);
                ceilingLamp(p, mx(6, east), yb + h, 7);
                ceilingLamp(p, mx(8, east), yb + h, 13);
                if (p.r.nextFloat() < 0.6f) p.zombie(mx(6, east), y, 7, null);
                if (p.r.nextFloat() < 0.3f) p.zombie(mx(8, east), y, 13, null);
                // окна
                for (int x : new int[]{mx(4, east), mx(7, east)}) window(p, x, yb + 2, z1, N, s);
                for (int x : new int[]{mx(4, east), mx(8, east)}) window(p, x, yb + 2, z2, S, s);
                for (int z : new int[]{7, 13}) window(p, east ? x2 : x1, yb + 2, z, out, s);
            }
            ceilingLamp(p, 12, yb + h, 8);
            ceilingLamp(p, 12, yb + h, 13);
            window(p, 12, yb + 2, z2, S, s);
        }
        // лестница в подъезде (между этажами)
        for (int f = 0; f < 2; f++) {
            int yb = f * (h + 1);
            for (int k = 0; k <= h; k++) {
                p.set(13, yb + 1 + k, 15 - k, p.stair(Blocks.STONE_BRICK_STAIRS, N, false));
                p.air(13, yb + 2 + k, 15 - k, 13, yb + 3 + k, 15 - k);
            }
            p.set(12, yb + h + 2, 14, Blocks.IRON_BARS);
            p.set(12, yb + h + 2, 13, Blocks.IRON_BARS);
        }
        door(p, 12, 1, z1, N, Blocks.BIRCH_DOOR);
        p.set(11, 2, z1 - 1, Blocks.LANTERN);
        p.fill(10, 0, 0, 14, 0, z1 - 1, Blocks.SMOOTH_STONE);
        for (int x = 15; x <= 17; x++) p.furn(x, 1, 1, "mailbox", N);
        p.furnLoot(4, 1, 1, "dumpster", E, Loot.TRASH);
        // плоская крыша с парапетом
        int yr = 3 * (h + 1);
        p.fill(x1, yr, z1, x2, yr, z2, Blocks.GRAY_CONCRETE);
        p.walls(x1, yr + 1, z1, x2, yr + 1, z2, s.ext());
        p.set(20, yr + 1, 15, Blocks.IRON_BLOCK);
        p.zombie(12, 1, 8, null);
        if (p.r.nextBoolean()) p.zombie(12, h + 2, 10, null);
    }

    private static int mx(int x, boolean east) {
        return east ? 24 - x : x;
    }
}
