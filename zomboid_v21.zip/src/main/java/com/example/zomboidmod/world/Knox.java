package com.example.zomboidmod.world;

import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.ZombieOutfit;
import com.example.zomboidmod.ZomboidEntities;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FenceBlock;
import net.minecraft.block.PaneBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.WallBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.PersistentState;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Свой округ в духе Project Zomboid: мир поделён на регионы 512x512, в каждом - город, деревня,
 * фермы или лес, а между ними шоссе. Поселение строится, когда игрок подходит ближе 160 блоков.
 * Стройка идёт порциями, чтобы игра не подвисала.
 */
public final class Knox {
    public static final int REGION = 512;
    private static final int CELL = 36, STREET = 7;
    private static final int TRIGGER = 160, ROAD_TRIGGER = 112;
    public static int BLOCKS_PER_TICK = 6000;
    private static final int FLAGS = Block.NOTIFY_LISTENERS | Block.FORCE_STATE;

    enum Type { FOREST, FARMS, VILLAGE, TOWN }

    /** Описание поселения в регионе (детерминировано от сида мира). */
    record Settlement(long key, int rx, int rz, Type type, String name, int cx, int cz, List<int[]> rects, long seed, int size) {}

    private static final ArrayDeque<Job> QUEUE = new ArrayDeque<>();
    private static final Set<Long> QUEUED = new HashSet<>();
    private static final Map<UUID, Long> WHERE = new HashMap<>();

    private Knox() {
    }

    // ===================== раскладка =====================

    static long regionKey(int rx, int rz) {
        return ((long) rx << 32) | (rz & 0xffffffffL);
    }

    private static final String[] PRE = {"Эш", "Сидар", "Милл", "Грин", "Пайн", "Стоун", "Уиллоу", "Фэйр", "Элк", "Коппер",
            "Ред", "Блэк", "Оук", "Мэйпл", "Ривер", "Хэй", "Брайар", "Холлоу", "Дир", "Клэй"};
    private static final String[] SUF = {"форд", "-Холлоу", "брук", "филд", "-Ридж", "бридж", "-Крик", "вью", "-Ран", "-Спрингс",
            "вуд", "-Фоллс", "вилл", "-Джанкшен", "-Пойнт", "тон", "-Миллс", "дейл"};

    static Settlement settlement(long worldSeed, int rx, int rz) {
        java.util.Random r = new java.util.Random(worldSeed * 341873128712L + rx * 132897987541L + rz * 42317861L + 7);
        double roll = r.nextDouble();
        Type type = roll < 0.25 ? Type.TOWN : (roll < 0.55 ? Type.VILLAGE : (roll < 0.8 ? Type.FARMS : Type.FOREST));
        if (rx == 0 && rz == 0) type = Type.TOWN;   // у точки появления - город, как старт в PZ
        int cx = rx * REGION + REGION / 2 + r.nextInt(161) - 80;
        int cz = rz * REGION + REGION / 2 + r.nextInt(161) - 80;
        String name = PRE[r.nextInt(PRE.length)] + SUF[r.nextInt(SUF.length)];
        List<int[]> rects = new ArrayList<>();
        int size = 0;
        switch (type) {
            case TOWN -> {
                size = 192 + r.nextInt(5) * 16;
                rects.add(new int[]{cx - size / 2, cz - size / 2, cx - size / 2 + size - 1, cz - size / 2 + size - 1});
            }
            case VILLAGE -> {
                size = 120 + r.nextInt(4) * 12;
                rects.add(new int[]{cx - size / 2, cz - 46, cx - size / 2 + size - 1, cz + 46});
            }
            case FARMS -> {
                int n = 2 + r.nextInt(2);
                int[][] q = {{1, 1}, {-1, 1}, {1, -1}, {-1, -1}};
                for (int i = 0; i < n; i++) {
                    int fx = cx + (q[i][0] > 0 ? 14 + r.nextInt(40) : -14 - 56 - r.nextInt(40));
                    int fz = cz + (q[i][1] > 0 ? 14 + r.nextInt(40) : -14 - 56 - r.nextInt(40));
                    rects.add(new int[]{fx, fz, fx + 55, fz + 55});
                }
            }
            case FOREST -> {
                size = 50 + r.nextInt(30);
                rects.add(new int[]{cx + 20, cz + 20, cx + 31, cz + 31});  // хижина
            }
        }
        return new Settlement(regionKey(rx, rz), rx, rz, type, name, cx, cz, rects, r.nextLong(), size);
    }

    static boolean inside(Settlement s, int x, int z, int margin) {
        for (int[] q : s.rects()) if (x >= q[0] - margin && x <= q[2] + margin && z >= q[1] - margin && z <= q[3] + margin) return true;
        return false;
    }

    static double distTo(Settlement s, double x, double z) {
        double best = Double.MAX_VALUE;
        for (int[] q : s.rects()) {
            double dx = Math.max(Math.max(q[0] - x, 0), x - q[2]);
            double dz = Math.max(Math.max(q[1] - z, 0), z - q[3]);
            best = Math.min(best, Math.hypot(dx, dz));
        }
        if (s.type() == Type.FOREST) best = Math.min(best, Math.max(0, Math.hypot(x - s.cx(), z - s.cz()) - s.size()));
        return best;
    }

    // ===================== высоты =====================

    /** Уровень земли (без деревьев и травы). Вода считается поверхностью. */
    static int ground(ServerWorld w, int x, int z) {
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
        BlockPos.Mutable m = new BlockPos.Mutable(x, y, z);
        for (int i = 0; i < 40 && y > w.getBottomY(); i++) {
            BlockState s = w.getBlockState(m.setY(y));
            boolean soft = s.isIn(BlockTags.LOGS) || s.isIn(BlockTags.LEAVES) || s.isAir()
                    || (s.isReplaceable() && s.getFluidState().isEmpty());
            if (!soft) break;
            y--;
        }
        return y;
    }

    static boolean water(ServerWorld w, int x, int y, int z) {
        return !w.getBlockState(new BlockPos(x, y, z)).getFluidState().isEmpty();
    }

    // ===================== работы =====================

    interface Job {
        /** Делает часть работы, возвращает потраченный бюджет. */
        int run(ServerWorld w, int budget);

        boolean done();
    }

    /** Разведка: выбирает высоту поселения и ставит в очередь остальное. */
    static final class SurveyJob implements Job {
        final Settlement s;
        boolean finished;

        SurveyJob(Settlement s) {
            this.s = s;
        }

        public int run(ServerWorld w, int budget) {
            finished = true;
            MapState st = MapState.get(w.getServer());
            if (s.type() == Type.FOREST) {
                QUEUE.addLast(new ForestJob(s));
                int[] c = s.rects().get(0);
                int base = ground(w, c[0] + 6, c[1] + 6);
                if (!water(w, c[0] + 6, base, c[1] + 6)) {
                    QUEUE.addLast(new FlattenJob(c[0], c[1], c[2], c[3], base, 4));
                    Plan p = new Plan(12, 12, Random.create(s.seed()));
                    Buildings.cabin(p);
                    QUEUE.addLast(new PlaceJob(p, c[0], base, c[1], BlockRotation.NONE));
                }
                QUEUE.addLast(new DoneJob(s));
                return 40;
            }
            List<Integer> hs = new ArrayList<>();
            int wet = 0, n = 0;
            for (int[] q : s.rects()) {
                for (int i = 0; i <= 4; i++)
                    for (int j = 0; j <= 4; j++) {
                        int x = q[0] + (q[2] - q[0]) * i / 4, z = q[1] + (q[3] - q[1]) * j / 4;
                        int g = ground(w, x, z);
                        if (water(w, x, g, z)) wet++;
                        hs.add(g);
                        n++;
                    }
            }
            if (wet > n * 0.35) {   // слишком много воды - не строим
                st.done.add(s.key());
                st.markDirty();
                QUEUED.remove(s.key());
                return 100;
            }
            hs.sort(Integer::compare);
            int base = Math.max(w.getSeaLevel() + 1, hs.get(hs.size() / 2));
            Random r = Random.create(s.seed());
            switch (s.type()) {
                case TOWN -> town(s, base, r);
                case VILLAGE -> village(s, base, r);
                case FARMS -> farms(s, base, r);
                default -> {
                }
            }
            QUEUE.addLast(new DoneJob(s));
            return 200;
        }

        public boolean done() {
            return finished;
        }
    }

    static final class DoneJob implements Job {
        final Settlement s;
        boolean finished;

        DoneJob(Settlement s) {
            this.s = s;
        }

        public int run(ServerWorld w, int budget) {
            MapState st = MapState.get(w.getServer());
            st.done.add(s.key());
            st.markDirty();
            QUEUED.remove(s.key());
            finished = true;
            return 1;
        }

        public boolean done() {
            return finished;
        }
    }

    /** Выравнивание площадки: внутри - ровно на base, по краям - плавный переход к рельефу. */
    static final class FlattenJob implements Job {
        final int x1, z1, x2, z2, base, margin;
        int cx, cz;

        FlattenJob(int x1, int z1, int x2, int z2, int base, int margin) {
            this.x1 = x1 - margin;
            this.z1 = z1 - margin;
            this.x2 = x2 + margin;
            this.z2 = z2 + margin;
            this.base = base;
            this.margin = margin;
            cx = this.x1;
            cz = this.z1;
        }

        public int run(ServerWorld w, int budget) {
            int used = 0;
            BlockPos.Mutable m = new BlockPos.Mutable();
            while (used < budget && cz <= z2) {
                int g = ground(w, cx, cz);
                int dx = Math.max(Math.max(x1 + margin - cx, 0), cx - (x2 - margin));
                int dz = Math.max(Math.max(z1 + margin - cz, 0), cz - (z2 - margin));
                double t = margin == 0 ? 0 : Math.min(1.0, Math.max(dx, dz) / (double) margin);
                int h = (int) Math.round(base * (1 - t) + g * t);
                int top = Math.max(g, h) + (t < 1 ? 24 : 0);
                for (int y = h + 1; y <= top; y++) {
                    BlockState s = w.getBlockState(m.set(cx, y, cz));
                    if (!s.isAir()) {
                        w.setBlockState(m, Blocks.AIR.getDefaultState(), FLAGS);
                        used++;
                    }
                }
                w.setBlockState(m.set(cx, h, cz), Blocks.GRASS_BLOCK.getDefaultState(), FLAGS);
                for (int y = h - 1; y > h - 12; y--) {
                    BlockState s = w.getBlockState(m.set(cx, y, cz));
                    if (s.isSolidBlock(w, m) && s.getFluidState().isEmpty()) break;
                    w.setBlockState(m, Blocks.DIRT.getDefaultState(), FLAGS);
                    used++;
                }
                used += 4;
                if (++cx > x2) {
                    cx = x1;
                    cz++;
                }
            }
            return used;
        }

        public boolean done() {
            return cz > z2;
        }
    }

    /** Постройка плана: блоки, затем обновление форм (заборы, стёкла), затем лут, зомби и животные. */
    static final class PlaceJob implements Job {
        final Plan p;
        final int ox, oy, oz;
        final BlockRotation rot;
        final List<Map.Entry<Long, BlockState>> list;
        final List<BlockPos> post = new ArrayList<>();
        int i = 0, phase = 0;

        PlaceJob(Plan p, int ox, int oy, int oz, BlockRotation rot) {
            this.p = p;
            this.ox = ox;
            this.oy = oy;
            this.oz = oz;
            this.rot = rot;
            this.list = new ArrayList<>(p.blocks.entrySet());
        }

        BlockPos world(long local) {
            int x = BlockPos.unpackLongX(local), y = BlockPos.unpackLongY(local), z = BlockPos.unpackLongZ(local);
            int wx, wz;
            switch (rot) {
                case CLOCKWISE_90 -> {
                    wx = p.d - 1 - z;
                    wz = x;
                }
                case CLOCKWISE_180 -> {
                    wx = p.w - 1 - x;
                    wz = p.d - 1 - z;
                }
                case COUNTERCLOCKWISE_90 -> {
                    wx = z;
                    wz = p.w - 1 - x;
                }
                default -> {
                    wx = x;
                    wz = z;
                }
            }
            return new BlockPos(ox + wx, oy + y, oz + wz);
        }

        /** Дробная точка плана (центр машины) в мировые координаты с учётом поворота. */
        double[] worldD(double x, double z) {
            double wx, wz;
            switch (rot) {
                case CLOCKWISE_90 -> {
                    wx = p.d - z;
                    wz = x;
                }
                case CLOCKWISE_180 -> {
                    wx = p.w - x;
                    wz = p.d - z;
                }
                case COUNTERCLOCKWISE_90 -> {
                    wx = z;
                    wz = p.w - x;
                }
                default -> {
                    wx = x;
                    wz = z;
                }
            }
            return new double[]{ox + wx, oz + wz};
        }

        public int run(ServerWorld w, int budget) {
            int used = 0;
            if (phase == 0) {
                while (used < budget && i < list.size()) {
                    Map.Entry<Long, BlockState> e = list.get(i++);
                    BlockPos pos = world(e.getKey());
                    BlockState st = e.getValue().rotate(rot);
                    w.setBlockState(pos, st, FLAGS);
                    Block b = st.getBlock();
                    if (b instanceof FenceBlock || b instanceof PaneBlock || b instanceof WallBlock || b instanceof StairsBlock) post.add(pos);
                    used++;
                }
                if (i >= list.size()) {
                    phase = 1;
                    i = 0;
                }
            } else if (phase == 1) {
                while (used < budget && i < post.size()) {
                    BlockPos pos = post.get(i++);
                    BlockState cur = w.getBlockState(pos);
                    BlockState upd = Block.postProcessState(cur, w, pos);
                    if (upd != cur) w.setBlockState(pos, upd, FLAGS);
                    used += 2;
                }
                if (i >= post.size()) phase = 2;
            } else if (phase == 2) {
                for (long[] l : p.loot) {
                    BlockEntity be = w.getBlockEntity(world(l[0]));
                    if (be instanceof com.example.zomboidmod.block.LootPileBlockEntity pile) {
                        net.minecraft.item.ItemStack st = Loot.values()[(int) l[1]].randomItem(p.r);
                        if (st.isEmpty()) w.removeBlock(world(l[0]), false);
                        else pile.set(st, p.r.nextFloat() * 360f);
                    } else if (be instanceof Inventory inv) Loot.values()[(int) l[1]].fill(inv, p.r);
                    used += 3;
                }
                for (Object[] z : p.zombies) {
                    PzZombieEntity zombie = ZomboidEntities.PZ_ZOMBIE.create(w);
                    if (zombie == null) continue;
                    BlockPos pos = world((Long) z[0]);
                    zombie.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, p.r.nextFloat() * 360f, 0f);
                    zombie.setup((ZombieOutfit) z[1]);
                    zombie.setPersistent();
                    w.spawnEntity(zombie);
                    if (p.r.nextFloat() < 0.2f && w.getBlockState(pos).isAir() && w.getBlockState(pos.down()).isOpaqueFullCube(w, pos.down())) {
                        w.setBlockState(pos, com.example.zomboidmod.block.ZomboidBlocks.BLOOD.getDefaultState()
                                .with(com.example.zomboidmod.block.DecalBlock.VARIANT, p.r.nextInt(4)), FLAGS);
                    }
                    used += 20;
                }
                for (Object[] v : p.vehicles) {
                    com.example.zomboidmod.vehicle.VehicleType t = com.example.zomboidmod.vehicle.VehicleType.byId((String) v[3]);
                    com.example.zomboidmod.vehicle.VehicleEntity car = t.entityType.create(w);
                    if (car == null) continue;
                    double[] wp = worldD((Double) v[0], (Double) v[2]);
                    float yaw = (Float) v[4] + switch (rot) {
                        case CLOCKWISE_90 -> 90f;
                        case CLOCKWISE_180 -> 180f;
                        case COUNTERCLOCKWISE_90 -> 270f;
                        default -> 0f;
                    };
                    car.refreshPositionAndAngles(wp[0], oy + (Integer) v[1], wp[1], yaw, 0f);
                    car.randomize(p.r, (Boolean) v[5]);
                    if (p.r.nextFloat() < 0.45f) Loot.values()[p.r.nextBoolean() ? Loot.GARAGE.ordinal() : Loot.TRASH.ordinal()].fill(car.trunk(), p.r);
                    w.spawnEntity(car);
                    used += 20;
                }
                for (long a : p.animals) {
                    CowEntity cow = EntityType.COW.create(w);
                    if (cow == null) continue;
                    BlockPos pos = world(a);
                    cow.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, p.r.nextFloat() * 360f, 0f);
                    w.spawnEntity(cow);
                }
                phase = 3;
            }
            return Math.max(1, used);
        }

        public boolean done() {
            return phase == 3;
        }
    }

    /** Лес: деревья по кругу на рельефе. */
    static final class ForestJob implements Job {
        final Settlement s;
        final Random r;
        int planted = 0;
        final int total;

        ForestJob(Settlement s) {
            this.s = s;
            this.r = Random.create(s.seed() ^ 0x5DEECE66DL);
            this.total = s.size() * s.size() / 12;
        }

        public int run(ServerWorld w, int budget) {
            int used = 0;
            while (used < budget && planted < total) {
                planted++;
                double a = r.nextDouble() * Math.PI * 2, d = Math.sqrt(r.nextDouble()) * s.size();
                int x = s.cx() + (int) (Math.cos(a) * d), z = s.cz() + (int) (Math.sin(a) * d);
                if (inside(s, x, z, 3)) continue;
                int g = ground(w, x, z);
                BlockState top = w.getBlockState(new BlockPos(x, g, z));
                if (!top.isOf(Blocks.GRASS_BLOCK) && !top.isOf(Blocks.DIRT) && !top.isOf(Blocks.PODZOL)) continue;
                Plan p = new Plan(1, 1, r);
                int kind = r.nextFloat() < 0.5f ? 0 : (r.nextFloat() < 0.5f ? 1 : 2);
                p.tree(0, 0, 0, kind);
                if (r.nextFloat() < 0.3f) p.set(1, 1, 0, Blocks.FERN);
                for (Map.Entry<Long, BlockState> e : p.blocks.entrySet()) {
                    BlockPos pos = BlockPos.fromLong(e.getKey()).add(x, g, z);
                    if (w.getBlockState(pos).isAir() || w.getBlockState(pos).isReplaceable()) w.setBlockState(pos, e.getValue(), FLAGS);
                    used++;
                }
                used += 10;
            }
            return Math.max(1, used);
        }

        public boolean done() {
            return planted >= total;
        }
    }

    // ===================== поселения =====================

    private static Plan plan(int w, int d, Random r) {
        return new Plan(w, d, Random.create(r.nextLong()));
    }

    static void lot(Plan p, int x, int y, int z, BlockRotation rot) {
        QUEUE.addLast(new PlaceJob(p, x, y, z, rot));
    }

    /** Город: улицы разной длины без сетки (см. TownGen). Главная улица продолжает шоссе. */
    private static void town(Settlement s, int base, Random r) {
        int[] q = s.rects().get(0);
        QUEUE.addLast(new FlattenJob(q[0], q[1], q[2], q[3], base, 12));
        int rcx = s.rx() * REGION + REGION / 2;
        new TownGen(q[0], q[1], q[2] - q[0] + 1, q[3] - q[1] + 1, base, r, false).generate(s.cz() - q[1], rcx - q[0]);
    }

    /** Деревня: дорога насквозь, пара переулков, редкие дома, магазинчик, часовня, поля. */
    private static void village(Settlement s, int base, Random r) {
        int[] q = s.rects().get(0);
        QUEUE.addLast(new FlattenJob(q[0], q[1], q[2], q[3], base, 12));
        int rcx = s.rx() * REGION + REGION / 2;
        new TownGen(q[0], q[1], q[2] - q[0] + 1, q[3] - q[1] + 1, base, r, true).generate(s.cz() - q[1], rcx - q[0]);
    }

    /** Фермы: дом, амбар, силос, поля, пастбище с коровами. */
    private static void farms(Settlement s, int base, Random r) {
        for (int[] q : s.rects()) {
            QUEUE.addLast(new FlattenJob(q[0], q[1], q[2], q[3], base, 10));
            Plan f = plan(56, 56, r);
            Plan h = plan(12, 12, r);
            if (r.nextBoolean()) Buildings.house(h);
            else Buildings.twoStory(h);
            f.embed(h, 2, 2);
            Buildings.barn(f, 18, 2);
            Buildings.silo(f, 42, 8);
            for (int k = 0; k < 2; k++) Buildings.field(f, 26, 22 + k * 16, 53, 35 + k * 16);
            for (int x = 2; x <= 22; x++) {
                f.set(x, 1, 22, Blocks.OAK_FENCE);
                f.set(x, 1, 53, Blocks.OAK_FENCE);
            }
            for (int z = 22; z <= 53; z++) {
                f.set(2, 1, z, Blocks.OAK_FENCE);
                f.set(22, 1, z, Blocks.OAK_FENCE);
            }
            f.set(12, 1, 22, Blocks.OAK_FENCE_GATE);
            for (int k = 0; k < 3 + r.nextInt(3); k++) f.animal(5 + r.nextInt(15), 1, 25 + r.nextInt(25));
            f.zombie(30, 1, 30, ZombieOutfit.FARMER);
            lot(f, q[0], base, q[1], BlockRotation.NONE);
        }
    }

    // ===================== шоссе =====================

    /** Кусок дороги длиной 16 вдоль оси. */
    record RoadPiece(long key, int x, int z, boolean alongX, int len) {}

    private static List<RoadPiece> roadPieces(Settlement s) {
        List<RoadPiece> out = new ArrayList<>();
        int rcx = s.rx() * REGION + REGION / 2, rcz = s.rz() * REGION + REGION / 2;
        int[][] mids = {{rcx, s.rz() * REGION}, {rcx, s.rz() * REGION + REGION}, {s.rx() * REGION, rcz}, {s.rx() * REGION + REGION, rcz}};
        int road = 0;
        for (int[] m : mids) {
            int idx = 0;
            // сначала вдоль x (z = центр поселения), потом вдоль z
            int a = s.cx(), b = m[0];
            for (int x = Math.min(a, b); x < Math.max(a, b); x += 16)
                out.add(new RoadPiece(s.key() * 1000003L + road * 128 + idx++, x, s.cz(), true, Math.min(16, Math.max(a, b) - x)));
            a = s.cz();
            b = m[1];
            for (int z = Math.min(a, b); z < Math.max(a, b); z += 16)
                out.add(new RoadPiece(s.key() * 1000003L + road * 128 + idx++, m[0], z, false, Math.min(16, Math.max(a, b) - z)));
            road++;
        }
        return out;
    }

    static final class RoadJob implements Job {
        final RoadPiece rp;
        final Settlement s;
        int t = 0;
        final Map<Long, Integer> cache = new HashMap<>();

        RoadJob(RoadPiece rp, Settlement s) {
            this.rp = rp;
            this.s = s;
        }

        int g(ServerWorld w, int x, int z) {
            return cache.computeIfAbsent(BlockPos.asLong(x, 0, z), k -> ground(w, x, z));
        }

        public int run(ServerWorld w, int budget) {
            int used = 0;
            BlockPos.Mutable m = new BlockPos.Mutable();
            while (used < budget && t < rp.len()) {
                int x = rp.alongX() ? rp.x() + t : rp.x(), z = rp.alongX() ? rp.z() : rp.z() + t;
                t++;
                if (inside(s, x, z, 0)) continue;
                int sum = 0;
                for (int k = -8; k <= 8; k += 4) sum += g(w, rp.alongX() ? x + k : x, rp.alongX() ? z : z + k);
                int y = Math.max(w.getSeaLevel() - 1, Math.round(sum / 5f));
                boolean bridge = water(w, x, g(w, x, z), z);
                for (int o = -4; o <= 4; o++) {
                    int bx = rp.alongX() ? x : x + o, bz = rp.alongX() ? z + o : z;
                    for (int dy = 1; dy <= 5; dy++) {
                        if (!w.getBlockState(m.set(bx, y + dy, bz)).isAir()) {
                            w.setBlockState(m, Blocks.AIR.getDefaultState(), FLAGS);
                            used++;
                        }
                    }
                    if (Math.abs(o) == 4) continue;
                    BlockState surf;
                    if (Math.abs(o) == 3) surf = bridge ? Blocks.STONE_BRICK_SLAB.getDefaultState() : Blocks.GRAVEL.getDefaultState();
                    else if (o == 0 && (t % 4) < 2) surf = Blocks.YELLOW_CONCRETE.getDefaultState();
                    else surf = (bx * 31 + bz * 17) % 9 == 0 ? Blocks.GRAY_CONCRETE.getDefaultState() : Blocks.BLACK_CONCRETE.getDefaultState();
                    w.setBlockState(m.set(bx, y, bz), surf, FLAGS);
                    used++;
                    if (!bridge) {
                        for (int dy = 1; dy <= 6; dy++) {
                            BlockState below = w.getBlockState(m.set(bx, y - dy, bz));
                            if (below.isSolidBlock(w, m) && below.getFluidState().isEmpty()) break;
                            w.setBlockState(m, Blocks.DIRT.getDefaultState(), FLAGS);
                            used++;
                        }
                    } else if ((x + z) % 8 == 0 && Math.abs(o) == 3) {
                        for (int dy = 1; dy <= 20; dy++) {
                            BlockState below = w.getBlockState(m.set(bx, y - dy, bz));
                            if (below.isSolidBlock(w, m) && below.getFluidState().isEmpty()) break;
                            w.setBlockState(m, Blocks.STONE_BRICKS.getDefaultState(), FLAGS);
                            used++;
                        }
                    }
                }
                used += 20;
            }
            if (t >= rp.len()) {
                MapState st = MapState.get(w.getServer());
                st.roads.add(rp.key());
                st.markDirty();
                QUEUED.remove(rp.key());
            }
            return Math.max(1, used);
        }

        public boolean done() {
            return t >= rp.len();
        }
    }

    // ===================== тик сервера =====================

    public static void tick(MinecraftServer server) {
        ServerWorld w = server.getOverworld();
        int budget = BLOCKS_PER_TICK;
        while (budget > 0 && !QUEUE.isEmpty()) {
            Job j = QUEUE.peekFirst();
            budget -= j.run(w, budget);
            if (j.done()) QUEUE.pollFirst();
        }
        if (server.getTicks() % 40 != 0) return;

        MapState st = MapState.get(server);
        long seed = w.getSeed();
        for (ServerPlayerEntity p : w.getPlayers()) {
            int prx = Math.floorDiv(p.getBlockX(), REGION), prz = Math.floorDiv(p.getBlockZ(), REGION);
            Settlement here = null;
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++) {
                    Settlement s = settlement(seed, prx + dx, prz + dz);
                    double dist = distTo(s, p.getX(), p.getZ());
                    if (dist <= 0 && s.type() != Type.FOREST) here = s;
                    if (dist < TRIGGER && !st.done.contains(s.key()) && QUEUED.add(s.key())) {
                        QUEUE.addLast(new SurveyJob(s));
                    }
                    for (RoadPiece rp : roadPieces(s)) {
                        double cx = rp.alongX() ? rp.x() + rp.len() / 2.0 : rp.x();
                        double cz = rp.alongX() ? rp.z() : rp.z() + rp.len() / 2.0;
                        if (Math.hypot(cx - p.getX(), cz - p.getZ()) < ROAD_TRIGGER && !st.roads.contains(rp.key()) && QUEUED.add(rp.key())) {
                            QUEUE.addLast(new RoadJob(rp, s));
                        }
                    }
                }
            // название места, как при входе в город
            Long prev = WHERE.get(p.getUuid());
            Long now = here == null ? null : here.key();
            if (now != null && !now.equals(prev)) {
                String kind = switch (here.type()) {
                    case TOWN -> "город";
                    case VILLAGE -> "деревня";
                    default -> "фермы";
                };
                p.sendMessage(Text.literal("— " + here.name() + " (" + kind + ") —"), true);
            }
            if (now == null) WHERE.remove(p.getUuid());
            else WHERE.put(p.getUuid(), now);
        }
    }

    public static void stop() {
        QUEUE.clear();
        QUEUED.clear();
        WHERE.clear();
    }

    /** Информация для команды. */
    public static String info(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        int prx = Math.floorDiv(p.getBlockX(), REGION), prz = Math.floorDiv(p.getBlockZ(), REGION);
        StringBuilder sb = new StringBuilder("Ближайшие места:");
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++) {
                Settlement s = settlement(w.getSeed(), prx + dx, prz + dz);
                String kind = switch (s.type()) {
                    case TOWN -> "город";
                    case VILLAGE -> "деревня";
                    case FARMS -> "фермы";
                    default -> "лес";
                };
                sb.append("\n").append(s.name()).append(" - ").append(kind).append(" (").append(s.cx()).append(", ").append(s.cz())
                        .append("), ").append((int) Math.hypot(s.cx() - p.getX(), s.cz() - p.getZ())).append(" бл.");
            }
        sb.append("\nВ очереди стройки: ").append(QUEUE.size());
        return sb.toString();
    }

    // ===================== сохранение =====================

    public static final class MapState extends PersistentState {
        final Set<Long> done = new HashSet<>();
        final Set<Long> roads = new HashSet<>();

        private static final PersistentState.Type<MapState> TYPE =
                new PersistentState.Type<>(MapState::new, MapState::fromNbt, null);

        static MapState get(MinecraftServer server) {
            return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, "zomboidmod_map");
        }

        @Override
        public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
            nbt.putLongArray("done", done.stream().mapToLong(Long::longValue).toArray());
            nbt.putLongArray("roads", roads.stream().mapToLong(Long::longValue).toArray());
            return nbt;
        }

        static MapState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
            MapState s = new MapState();
            for (long l : nbt.getLongArray("done")) s.done.add(l);
            for (long l : nbt.getLongArray("roads")) s.roads.add(l);
            return s;
        }
    }
}
