package com.example.zomboidmod.world;

import com.example.zomboidmod.ZombieOutfit;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.CropBlock;
import net.minecraft.block.FarmlandBlock;
import net.minecraft.block.LanternBlock;
import net.minecraft.util.math.Direction;

/**
 * Здания. Все планы - в локальных координатах участка (улица с севера, z = 0 - край у тротуара).
 * Дизайн свой, в духе американской глубинки 90-х.
 */
public final class Buildings {
    private Buildings() {
    }

    // ===== стили домов =====
    record Style(BlockState wall, BlockState trim, Block stairs, Block slab, BlockState roof, Block door, BlockState floor) {}

    static final Style[] HOUSE_STYLES = buildStyles();

    private static BlockState bb(String id) {
        return com.example.zomboidmod.block.BuildingBlocks.get(id).getDefaultState();
    }

    private static Block bk(String id) {
        return com.example.zomboidmod.block.BuildingBlocks.get(id);
    }

    /** Стили маленьких домов: в основном сайдинг и черепица, немного кирпича и дерева. */
    private static Style[] buildStyles() {
        java.util.List<Style> l = new java.util.ArrayList<>();
        String[] sid = {"siding_white", "siding_beige", "siding_blue", "siding_green", "siding_yellow", "siding_gray", "siding_red"};
        String[] sh = {"shingles_dark", "shingles_brown", "shingles_red", "shingles_green"};
        Block[] doors = {Blocks.OAK_DOOR, Blocks.SPRUCE_DOOR, Blocks.DARK_OAK_DOOR, Blocks.BIRCH_DOOR};
        for (int i = 0; i < sid.length; i++) {
            String r = sh[i % sh.length];
            l.add(new Style(bb(sid[i]), bb("trim_white"), bk(r + "_stairs"), bk(r + "_slab"), bb(r), doors[i % doors.length],
                    bb(i % 2 == 0 ? "floor_hardwood" : "floor_hardwood_dark")));
        }
        l.add(new Style(bb("brick_old"), bb("trim_white"), bk("shingles_dark_stairs"), bk("shingles_dark_slab"), bb("shingles_dark"),
                Blocks.DARK_OAK_DOOR, bb("floor_hardwood")));
        l.add(new Style(bb("brick_tan"), bb("trim_white"), bk("shingles_brown_stairs"), bk("shingles_brown_slab"), bb("shingles_brown"),
                Blocks.OAK_DOOR, bb("floor_hardwood_dark")));
        l.add(new Style(Blocks.SPRUCE_PLANKS.getDefaultState(), Blocks.STRIPPED_SPRUCE_LOG.getDefaultState(), bk("shingles_green_stairs"),
                bk("shingles_green_slab"), bb("shingles_green"), Blocks.SPRUCE_DOOR, bb("floor_hardwood")));
        return l.toArray(new Style[0]);
    }

    static final BlockState GLASS = Blocks.GLASS_PANE.getDefaultState();
    static final BlockState BARREL = Blocks.BARREL.getDefaultState();
    static final BlockState FRIDGE = Blocks.WHITE_SHULKER_BOX.getDefaultState();

    static BlockState chest(Direction f) {
        return Blocks.CHEST.getDefaultState().with(ChestBlock.FACING, f);
    }

    static Style style(Plan p) {
        return HOUSE_STYLES[p.r.nextInt(HOUSE_STYLES.length)];
    }

    // ===== общие детали =====

    /** Двускатная крыша с коньком вдоль x. yr - уровень потолка (низ крыши). */
    static void gableRoof(Plan p, int x1, int z1, int x2, int z2, int yr, Style s, BlockState gable) {
        int a = z1 - 1, b = z2 + 1, k = 0;
        while (a + k < b - k) {
            for (int x = x1 - 1; x <= x2 + 1; x++) {
                p.set(x, yr + k, a + k, p.stair(s.stairs(), Direction.SOUTH, false));
                p.set(x, yr + k, b - k, p.stair(s.stairs(), Direction.NORTH, false));
            }
            for (int z = a + k + 1; z <= b - k - 1; z++) {   // фронтоны
                if (z >= z1 && z <= z2) {
                    p.set(x1, yr + k, z, gable);
                    p.set(x2, yr + k, z, gable);
                }
            }
            k++;
        }
        if (a + k == b - k) for (int x = x1 - 1; x <= x2 + 1; x++) p.set(x, yr + k, a + k, p.slab(s.slab(), false));
    }

    static void flatRoof(Plan p, int x1, int z1, int x2, int z2, int yr, BlockState roof, BlockState parapet) {
        p.fill(x1, yr, z1, x2, yr, z2, roof);
        p.walls(x1, yr + 1, z1, x2, yr + 1, z2, parapet);
    }

    static void path(Plan p, int x, int z1, int z2) {
        for (int z = z1; z <= z2; z++) p.set(x, 0, z, Blocks.DIRT_PATH);
    }

    static void hedge(Plan p, int x1, int z, int x2) {
        for (int x = x1; x <= x2; x++) if (p.r.nextFloat() < 0.8f) p.set(x, 1, z, Blocks.OAK_LEAVES.getDefaultState().with(net.minecraft.block.LeavesBlock.PERSISTENT, true));
    }

    static void lamp(Plan p, int x, int y, int z) {
        p.set(x, y, z, Blocks.LANTERN.getDefaultState().with(LanternBlock.HANGING, true));
    }

    /** Брошенная машина на месте 2x4 клеток (настоящая, можно сесть и уехать, если есть бензин). */
    static void car(Plan p, int x, int z, boolean alongZ) {
        car(p, x, z, alongZ, com.example.zomboidmod.vehicle.VehicleType.randomCivil(p.r).id);
    }

    static void car(Plan p, int x, int z, boolean alongZ, String type) {
        float yaw = alongZ ? (p.r.nextBoolean() ? 0f : 180f) : (p.r.nextBoolean() ? 90f : 270f);
        yaw += p.r.nextFloat() * 8f - 4f;
        p.vehicle(alongZ ? x + 1.0 : x + 2.0, 1, alongZ ? z + 2.0 : z + 1.0, type, yaw, p.r.nextFloat() < 0.15f);
    }

    // ===== жилые дома (участок 12x12) =====

    /** Одноэтажный дом: гостиная и кухня спереди, спальня и ванная сзади. */
    public static void house(Plan p) {
        house(p, style(p));
    }

    /** Одноэтажный дом с пристроенным гаражом и подъездной дорожкой (участок 18x12). */
    public static void ranch(Plan p) {
        Style s = style(p);
        house(p, s);
        int x1 = 11, x2 = 17, z1 = 3, z2 = 10, h = 3;
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.GRAY_CONCRETE);
        p.walls(x1, 1, z1, x2, h, z2, s.wall());
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, h, z2 - 1);
        p.air(x1 + 1, 1, z1, x2 - 1, 2, z1);                 // открытые ворота
        for (int x = x1 + 1; x <= x2 - 1; x++) p.set(x, 3, z1, Blocks.WHITE_CONCRETE);
        p.fill(x1, h + 1, z1, x2, h + 1, z2, s.roof());
        gableRoof(p, x1, z1, x2, z2, h + 1, s, s.wall());
        for (int z = 0; z < z1; z++) for (int x = x1 + 1; x <= x2 - 1; x++) p.set(x, 0, z, Blocks.LIGHT_GRAY_CONCRETE);
        p.furnLoot(x2 - 1, 1, z2 - 1, "shelf_tools", Direction.NORTH, Loot.GARAGE);
        p.furnLoot(x1 + 1, 1, z2 - 1, "cardboard_box", Direction.NORTH, Loot.GARAGE);
        p.set(x2 - 1, 1, z2 - 2, Blocks.CRAFTING_TABLE);
        if (p.r.nextFloat() < 0.4f) p.furnLoot(x1 + 1, 1, z2 - 2, "cardboard_box", Direction.EAST, Loot.GARAGE);
        lamp(p, 14, 3, 7);
        if (p.r.nextFloat() < 0.6f) car(p, 13, 5, true);
        else if (p.r.nextFloat() < 0.5f) car(p, 13, 0, false);
        if (p.r.nextFloat() < 0.35f) p.zombie(15, 1, 6, ZombieOutfit.MECHANIC);
    }

    /** Парковка у магазинов: разметка, машины, тележки. */
    public static void parkingLot(Plan p) {
        for (int x = 0; x < p.w; x++) for (int z = 0; z < p.d; z++)
            p.set(x, 0, z, p.r.nextFloat() < 0.08f ? Blocks.GRAY_CONCRETE.getDefaultState() : Blocks.BLACK_CONCRETE.getDefaultState());
        for (int x = 0; x < p.w; x += 3) for (int z = 6; z <= 10; z++) p.set(x, 0, z, Blocks.WHITE_CONCRETE);
        for (int x = 0; x + 2 < p.w; x += 3) {
            float k = p.r.nextFloat();
            if (k < 0.4f) car(p, x, 7, true);
            else if (k < 0.5f) p.furn(x + 1, 1, 8, "shopping_cart", Direction.Type.HORIZONTAL.random(p.r));
        }
        if (p.r.nextBoolean()) p.furn(1, 1, 1, "shopping_cart", Direction.EAST);
        p.set(p.w - 1, 1, 11, Blocks.IRON_BARS);
        p.furn(p.w - 1, 2, 11, "street_lamp", Direction.NORTH);
        if (p.r.nextBoolean()) p.zombie(p.w / 2, 1, 4, null);
    }

    static void house(Plan p, Style s) {
        int x1 = 1, x2 = 10, z1 = 3, z2 = 10, h = 3;
        p.fill(x1, 0, z1, x2, 0, z2, s.floor());
        p.walls(x1, 1, z1, x2, h, z2, s.wall());
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, h, z2 - 1);
        p.windows(x1, z1, x2, z2, 2, GLASS, 5);
        p.door(5, 1, z1, s.door(), Direction.NORTH);
        p.fill(x1, h + 1, z1, x2, h + 1, z2, s.roof());
        if (p.r.nextFloat() < 0.75f) gableRoof(p, x1, z1, x2, z2, h + 1, s, s.wall());
        else flatRoof(p, x1, z1, x2, z2, h + 1, s.roof(), p.slab(s.slab(), false));
        // крыльцо и дорожка
        p.fill(4, 0, 2, 6, 0, 2, s.trim());
        path(p, 5, 0, 1);
        if (p.r.nextBoolean()) hedge(p, 0, 0, 3);
        if (p.r.nextBoolean()) hedge(p, 7, 0, 11);
        // перегородки
        for (int x = x1 + 1; x <= x2 - 1; x++) p.fill(x, 1, 7, x, h, 7, s.wall());
        p.air(5, 1, 7, 5, 2, 7);
        p.air(8, 1, 7, 8, 2, 7);
        p.fill(6, 1, 8, 6, h, 9, s.wall());
        interiorGround(p, s);
        // задний двор
        if (p.r.nextFloat() < 0.6f) p.tree(1 + p.r.nextInt(2), 0, 11, p.r.nextInt(3));
        p.zombie(3, 1, 5, null);
        if (p.r.nextFloat() < 0.4f) p.zombie(7, 1, 8, null);
    }

    private static void interiorGround(Plan p, Style s) {
        Direction N = Direction.NORTH, S = Direction.SOUTH, W = Direction.WEST;
        // гостиная: диван, телевизор, торшер, радио, ковёр
        p.fill(2, 1, 4, 4, 1, 6, Blocks.AIR);
        Block[] rugs = {Blocks.RED_CARPET, Blocks.BROWN_CARPET, Blocks.GREEN_CARPET, Blocks.BLUE_CARPET, Blocks.GRAY_CARPET};
        Block rug = rugs[p.r.nextInt(rugs.length)];
        p.furn(2, 1, 6, "sofa", N);
        p.furn(3, 1, 6, "sofa", N);
        p.furn(4, 1, 6, "armchair", N);
        p.furn(3, 1, 4, "tv", S);
        p.furn(2, 1, 4, "floor_lamp", S);
        if (p.r.nextBoolean()) p.furn(4, 1, 4, "radio", S);
        else p.pile(4, 1, 4, Loot.LIVING);
        p.set(3, 1, 5, rug);
        if (p.r.nextFloat() < 0.6f) p.pile(2, 1, 5, Loot.LIVING);
        // кухня у восточной стены: холодильник, плита, мойка; стол со стульями
        p.furnLoot(9, 1, 4, "fridge", W, Loot.FRIDGE);
        p.furnLoot(9, 1, 5, "stove", W, Loot.KITCHEN);
        p.furnLoot(9, 1, 6, "kitchen_sink", W, Loot.KITCHEN);
        p.furn(7, 1, 5, "kitchen_table", N);
        p.furn(7, 1, 4, "chair", S);
        p.furn(7, 1, 6, "chair", N);
        if (p.r.nextFloat() < 0.7f) p.pile(7, 2, 5, Loot.KITCHEN);
        if (p.r.nextFloat() < 0.3f) p.pile(6, 1, 6, Loot.KITCHEN);
        // спальня: кровать, тумбочка с лампой, платяной шкаф
        Block[] beds = {Blocks.RED_BED, Blocks.BLUE_BED, Blocks.WHITE_BED, Blocks.GREEN_BED, Blocks.BROWN_BED};
        p.bed(2, 1, 8, beds[p.r.nextInt(beds.length)], Direction.SOUTH);
        p.furnLoot(3, 1, 9, "nightstand", N, Loot.BEDROOM);
        p.furnLoot(5, 1, 9, "wardrobe", N, Loot.BEDROOM);
        p.set(4, 0, 8, Blocks.LIGHT_GRAY_WOOL);
        if (p.r.nextFloat() < 0.5f) p.pile(4, 1, 8, Loot.BEDROOM);
        // ванная: раковина с зеркалом, ванна, унитаз, плитка
        p.fill(7, 0, 8, 9, 0, 9, Blocks.WHITE_CONCRETE);
        p.furnLoot(7, 1, 9, "bathroom_sink", N, Loot.BATHROOM);
        p.furn(8, 1, 9, "bathtub", N);
        p.furn(9, 1, 8, "toilet", W);
        if (p.r.nextFloat() < 0.3f) p.pile(8, 1, 8, Loot.BATHROOM);
        lamp(p, 3, 3, 5);
        // мусорка у крыльца
        if (p.r.nextBoolean()) p.furnLoot(8, 1, 2, "trash_can", N, Loot.TRASH);
    }

    /** Двухэтажный дом с лестницей (стремянкой) и двумя спальнями наверху. */
    public static void twoStory(Plan p) {
        Style s = style(p);
        int x1 = 1, x2 = 10, z1 = 3, z2 = 10;
        p.fill(x1, 0, z1, x2, 0, z2, s.floor());
        p.walls(x1, 1, z1, x2, 7, z2, s.wall());
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, 7, z2 - 1);
        p.fill(x1 + 1, 4, z1 + 1, x2 - 1, 4, z2 - 1, s.floor());
        p.fill(x1, 4, z1, x2, 4, z2, s.trim());
        p.fill(x1 + 1, 4, z1 + 1, x2 - 1, 4, z2 - 1, s.floor());
        p.windows(x1, z1, x2, z2, 2, GLASS, 5);
        p.windows(x1, z1, x2, z2, 6, GLASS, -10);
        p.door(5, 1, z1, s.door(), Direction.NORTH);
        p.fill(x1, 8, z1, x2, 8, z2, s.roof());
        gableRoof(p, x1, z1, x2, z2, 8, s, s.wall());
        p.fill(3, 0, 1, 7, 0, 2, s.trim());
        path(p, 5, 0, 0);
        // первый этаж
        for (int x = x1 + 1; x <= x2 - 1; x++) p.fill(x, 1, 7, x, 3, 7, s.wall());
        p.air(5, 1, 7, 5, 2, 7);
        p.air(8, 1, 7, 8, 2, 7);
        p.fill(6, 1, 8, 6, 3, 9, s.wall());
        interiorGround(p, s);
        // лестница в углу гостиной
        p.set(2, 1, 4, Blocks.AIR);
        p.ladder(2, 1, 5, 4, Direction.SOUTH);
        p.set(2, 4, 4, Blocks.AIR);
        // второй этаж: две спальни
        for (int z = z1 + 1; z <= z2 - 1; z++) p.fill(6, 5, z, 6, 7, z, s.wall());
        p.air(6, 5, 5, 6, 6, 5);
        Block[] beds = {Blocks.RED_BED, Blocks.BLUE_BED, Blocks.WHITE_BED, Blocks.YELLOW_BED, Blocks.CYAN_BED};
        p.bed(3, 5, 8, beds[p.r.nextInt(beds.length)], Direction.SOUTH);
        p.furnLoot(5, 5, 9, "nightstand", Direction.NORTH, Loot.BEDROOM);
        p.bed(8, 5, 8, beds[p.r.nextInt(beds.length)], Direction.SOUTH);
        p.furnLoot(9, 5, 4, "dresser", Direction.SOUTH, Loot.BEDROOM);
        p.furnLoot(7, 5, 4, "wardrobe", Direction.SOUTH, Loot.BEDROOM);
        p.furn(4, 5, 4, "desk", Direction.SOUTH);
        if (p.r.nextFloat() < 0.6f) p.pile(3, 5, 6, Loot.BEDROOM);
        lamp(p, 4, 7, 6);
        lamp(p, 8, 7, 6);
        if (p.r.nextBoolean()) p.tree(10, 0, 11, p.r.nextInt(3));
        p.zombie(4, 1, 5, null);
        if (p.r.nextFloat() < 0.5f) p.zombie(8, 5, 6, null);
    }

    /** Трейлер (передвижной дом). */
    public static void trailer(Plan p) {
        Block[] stripes = {Blocks.LIGHT_BLUE_CONCRETE, Blocks.BROWN_TERRACOTTA, Blocks.GREEN_TERRACOTTA, Blocks.ORANGE_TERRACOTTA};
        BlockState wall = Blocks.WHITE_CONCRETE.getDefaultState();
        BlockState stripe = stripes[p.r.nextInt(stripes.length)].getDefaultState();
        int x1 = 1, x2 = 10, z1 = 4, z2 = 8;
        for (int x = x1; x <= x2; x += 3) p.set(x, 0, z1, Blocks.COBBLESTONE_WALL);
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.OAK_PLANKS);
        p.walls(x1, 1, z1, x2, 3, z2, wall);
        for (int x = x1; x <= x2; x++) {
            p.set(x, 1, z1, stripe);
            p.set(x, 1, z2, stripe);
        }
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, 3, z2 - 1);
        p.windows(x1, z1, x2, z2, 2, GLASS, 3);
        p.door(3, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.set(3, 0, z1 - 1, Blocks.SPRUCE_SLAB);
        flatRoof(p, x1, z1, x2, z2, 4, Blocks.LIGHT_GRAY_CONCRETE.getDefaultState(), Blocks.AIR.getDefaultState());
        p.bed(8, 1, 5, Blocks.BROWN_BED, Direction.EAST);
        p.furnLoot(9, 1, 7, "nightstand", Direction.WEST, Loot.BEDROOM);
        p.furnLoot(2, 1, 7, "stove", Direction.EAST, Loot.KITCHEN);
        p.furnLoot(2, 1, 6, "fridge", Direction.EAST, Loot.FRIDGE);
        p.furnLoot(2, 1, 5, "kitchen_counter", Direction.EAST, Loot.KITCHEN);
        p.furn(5, 1, 7, "toilet", Direction.NORTH);
        p.furn(6, 1, 5, "tv", Direction.EAST);
        p.furn(4, 1, 5, "armchair", Direction.EAST);
        if (p.r.nextFloat() < 0.7f) p.pile(4, 1, 6, Loot.LIVING);
        p.furnLoot(1, 1, 2, "trash_can", Direction.NORTH, Loot.TRASH);
        if (p.r.nextBoolean()) car(p, 1, 10, false);
        p.zombie(5, 1, 6, ZombieOutfit.TRAILER);
    }

    /** Пустырь или сквер. */
    public static void park(Plan p) {
        boolean big = p.w > 14;
        int cx = p.w / 2, cz = p.d / 2;
        for (int x = 1; x < p.w - 1; x++) p.set(x, 0, cz, Blocks.GRAVEL);
        for (int z = 0; z < p.d - 1; z++) p.set(cx, 0, z, Blocks.GRAVEL);
        if (big) {
            p.fill(cx - 2, 0, cz - 2, cx + 2, 1, cz + 2, Blocks.STONE_BRICKS);
            p.fill(cx - 1, 1, cz - 1, cx + 1, 1, cz + 1, Blocks.WATER);
            p.set(cx, 2, cz, Blocks.STONE_BRICK_WALL);
        }
        int trees = big ? 8 : 2;
        for (int i = 0; i < trees; i++) {
            int x = 1 + p.r.nextInt(p.w - 2), z = 1 + p.r.nextInt(p.d - 2);
            if (Math.abs(x - cx) > 2 && Math.abs(z - cz) > 2) p.tree(x, 0, z, p.r.nextInt(2));
        }
        p.set(cx - 2, 1, 1, p.stair(Blocks.OAK_STAIRS, Direction.SOUTH, false));
        p.set(cx + 2, 1, 1, p.stair(Blocks.OAK_STAIRS, Direction.SOUTH, false));
        if (p.r.nextFloat() < 0.5f) p.zombie(cx, 1, cz + 3, null);
    }

    public static void emptyLot(Plan p) {
        for (int i = 0; i < 6; i++) {
            int x = 1 + p.r.nextInt(p.w - 2), z = 1 + p.r.nextInt(p.d - 2);
            p.set(x, 0, z, p.r.nextBoolean() ? Blocks.COARSE_DIRT : Blocks.GRAVEL);
            if (p.r.nextFloat() < 0.3f) p.set(x, 1, z, Blocks.COBBLESTONE);
        }
        if (p.r.nextFloat() < 0.5f) car(p, 3, 4, true);
    }

    // ===== коммерция: коробка с витриной =====

    /** Магазин с витриной: стены, стекло спереди, дверь, вывеска цветной полосой, плоская крыша. */
    static void shop(Plan p, int x1, int z1, int x2, int z2, int h, BlockState wall, BlockState band, BlockState floor) {
        p.fill(x1, 0, z1, x2, 0, z2, floor);
        p.walls(x1, 1, z1, x2, h, z2, wall);
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, h, z2 - 1);
        int cx = (x1 + x2) / 2;
        for (int x = x1 + 1; x <= x2 - 1; x++) p.fill(x, 1, z1, x, h - 1, z1, GLASS);
        p.door(cx, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.door(cx, 1, z2, Blocks.OAK_DOOR, Direction.SOUTH);
        for (int x = x1; x <= x2; x++) p.set(x, h, z1, band);
        for (int z = z1 + 2; z <= z2 - 2; z += 3) {
            p.set(x1, 2, z, GLASS);
            p.set(x2, 2, z, GLASS);
        }
        flatRoof(p, x1, z1, x2, z2, h + 1, Blocks.GRAY_CONCRETE.getDefaultState(), wall);
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.SMOOTH_STONE);
    }

    /** Ряды стеллажей (бочки) поперёк магазина. */
    static void aisles(Plan p, int x1, int x2, int z1, int z2, Loot loot, int gapX) {
        String shelf = loot == Loot.PHARMACY ? "shelf_meds" : (loot == Loot.HARDWARE ? "shelf_tools" : "shelf_food");
        for (int z = z1; z <= z2; z += 3)
            for (int x = x1; x <= x2; x++) {
                if (Math.abs(x - gapX) <= 1) continue;
                if (p.r.nextFloat() < 0.5f) p.furnLoot(x, 1, z, shelf, Direction.NORTH, loot);
                else p.furn(x, 1, z, shelf, Direction.NORTH);
                if (p.r.nextFloat() < 0.12f) p.pile(x, 1, z - 1, loot);   // упало с полки
            }
    }

    static void counter(Plan p, int x1, int x2, int z) {
        for (int x = x1; x <= x2; x++) p.set(x, 1, z, Blocks.POLISHED_ANDESITE);
    }

    /** Продуктовый (25x12). */
    public static void grocery(Plan p) {
        shop(p, 1, 2, 23, 11, 4, Blocks.WHITE_TERRACOTTA.getDefaultState(), Blocks.GREEN_CONCRETE.getDefaultState(), Blocks.POLISHED_DIORITE.getDefaultState());
        aisles(p, 4, 20, 5, 8, Loot.GROCERY, 12);
        for (int x = 3; x <= 21; x++) if (x != 12) p.furnLoot(x, 1, 10, "fridge", Direction.NORTH, x % 2 == 0 ? Loot.FRIDGE : Loot.GROCERY);
        p.furnLoot(2, 1, 3, "trash_can", Direction.SOUTH, Loot.TRASH);
        counter(p, 2, 4, 4);
        lamp(p, 6, 4, 6);
        lamp(p, 18, 4, 6);
        p.zombie(8, 1, 6, null);
        p.zombie(16, 1, 9, null);
        if (p.r.nextBoolean()) car(p, 3, 0, false);
    }

    /** Аптека (15x12) и проезд сбоку. */
    public static void pharmacy(Plan p) {
        shop(p, 1, 2, 15, 11, 4, Blocks.WHITE_CONCRETE.getDefaultState(), Blocks.LIME_CONCRETE.getDefaultState(), Blocks.WHITE_CONCRETE.getDefaultState());
        p.set(8, 5, 2, Blocks.RED_CONCRETE);
        p.set(7, 5, 1, Blocks.RED_CONCRETE);
        p.set(9, 5, 1, Blocks.RED_CONCRETE);
        p.set(8, 6, 1, Blocks.RED_CONCRETE);
        p.set(8, 4, 1, Blocks.RED_CONCRETE);
        p.set(8, 5, 1, Blocks.RED_CONCRETE);
        aisles(p, 3, 13, 5, 5, Loot.PHARMACY, 8);
        counter(p, 3, 13, 8);
        for (int x = 3; x <= 13; x++) if (x != 8) p.furnLoot(x, 1, 10, "shelf_meds", Direction.NORTH, Loot.PHARMACY);
        lamp(p, 8, 4, 6);
        p.zombie(6, 1, 6, ZombieOutfit.NURSE);
        if (p.r.nextBoolean()) p.zombie(11, 1, 9, ZombieOutfit.DOCTOR);
        for (int x = 17; x <= 23; x++) for (int z = 0; z <= 11; z++) p.set(x, 0, z, Blocks.GRAY_CONCRETE);
        car(p, 19, 4, true);
    }

    /** Хозяйственный магазин (25x12). */
    public static void hardware(Plan p) {
        shop(p, 1, 2, 23, 11, 4, Blocks.ORANGE_TERRACOTTA.getDefaultState(), Blocks.ORANGE_CONCRETE.getDefaultState(), Blocks.SPRUCE_PLANKS.getDefaultState());
        aisles(p, 4, 20, 5, 8, Loot.HARDWARE, 12);
        for (int x = 3; x <= 21; x += 2) p.fill(x, 1, 10, x, 2, 10, Blocks.OAK_PLANKS);
        for (int x = 4; x <= 20; x += 4) p.furnLoot(x, 1, 10, "shelf_tools", Direction.NORTH, Loot.HARDWARE);
        for (int x = 5; x <= 19; x += 7) p.furnLoot(x, 1, 9, "cardboard_box", Direction.NORTH, Loot.HARDWARE);
        counter(p, 2, 4, 4);
        p.zombie(10, 1, 6, ZombieOutfit.CONSTRUCTION);
        if (p.r.nextBoolean()) p.zombie(18, 1, 9, null);
    }

    /** Закусочная: кабинки у окон, стойка, кухня сзади. */
    public static void diner(Plan p) {
        shop(p, 1, 2, 23, 11, 4, Blocks.WHITE_CONCRETE.getDefaultState(), Blocks.RED_CONCRETE.getDefaultState(), Blocks.BLACK_CONCRETE.getDefaultState());
        for (int x = 2; x <= 22; x++) if ((x + 2) % 2 == 0) p.set(x, 0, 4, Blocks.WHITE_CONCRETE);
        for (int x = 3; x <= 21; x += 4) {
            if (Math.abs(x - 12) <= 1) continue;
            p.set(x, 1, 3, p.stair(Blocks.OAK_STAIRS, Direction.SOUTH, false));
            p.table(x, 1, 4);
            p.set(x, 1, 5, p.stair(Blocks.OAK_STAIRS, Direction.NORTH, false));
        }
        counter(p, 3, 21, 7);
        for (int x = 4; x <= 20; x += 3) p.set(x, 1, 6, Blocks.OAK_FENCE);
        p.fill(2, 1, 8, 22, 3, 8, Blocks.WHITE_CONCRETE);
        p.air(12, 1, 8, 12, 2, 8);
        p.furnLoot(3, 1, 10, "stove", Direction.NORTH, Loot.DINER);
        p.furnLoot(4, 1, 10, "stove", Direction.NORTH, Loot.DINER);
        p.furnLoot(6, 1, 10, "kitchen_counter", Direction.NORTH, Loot.DINER);
        p.furnLoot(8, 1, 10, "fridge", Direction.NORTH, Loot.FRIDGE);
        p.furnLoot(9, 1, 10, "fridge", Direction.NORTH, Loot.FRIDGE);
        p.furnLoot(15, 1, 10, "kitchen_counter", Direction.NORTH, Loot.DINER);
        p.furnLoot(16, 1, 10, "kitchen_sink", Direction.NORTH, Loot.KITCHEN);
        p.furnLoot(17, 1, 10, "kitchen_counter", Direction.NORTH, Loot.DINER);
        p.furnLoot(21, 1, 9, "trash_can", Direction.WEST, Loot.TRASH);
        for (int x = 3; x <= 21; x += 8) if (p.r.nextFloat() < 0.5f) p.pile(x, 2, 4, Loot.DINER);
        lamp(p, 6, 4, 5);
        lamp(p, 18, 4, 5);
        p.zombie(14, 1, 9, ZombieOutfit.CHEF);
        p.zombie(8, 1, 5, null);
    }

    /** Заправка: навес над колонками и маленький магазин. */
    public static void gasStation(Plan p) {
        for (int x = 1; x <= 23; x++) for (int z = 0; z <= 11; z++) p.set(x, 0, z, Blocks.GRAY_CONCRETE);
        for (int[] c : new int[][]{{3, 2}, {3, 6}, {11, 2}, {11, 6}}) p.fill(c[0], 1, c[1], c[0], 4, c[1], Blocks.WHITE_CONCRETE);
        p.fill(2, 5, 1, 12, 5, 7, Blocks.SMOOTH_STONE_SLAB);
        for (int x = 2; x <= 12; x++) p.set(x, 5, 1, Blocks.RED_CONCRETE);
        p.fill(5, 0, 3, 9, 0, 5, Blocks.SMOOTH_STONE);
        for (int x : new int[]{6, 8}) p.furn(x, 1, 4, "gas_pump", Direction.NORTH);
        shop(p, 14, 3, 23, 11, 3, Blocks.WHITE_TERRACOTTA.getDefaultState(), Blocks.RED_CONCRETE.getDefaultState(), Blocks.POLISHED_DIORITE.getDefaultState());
        counter(p, 15, 17, 6);
        for (int x = 15; x <= 22; x++) if (x != 18) p.furnLoot(x, 1, 10, "shelf_food", Direction.NORTH, Loot.GAS);
        p.furnLoot(22, 1, 5, "fridge", Direction.WEST, Loot.FRIDGE);
        p.furnLoot(22, 1, 7, "fridge", Direction.WEST, Loot.FRIDGE);
        p.furnLoot(13, 1, 2, "trash_can", Direction.NORTH, Loot.TRASH);
        if (p.r.nextBoolean()) car(p, 5, 6, false);
        p.zombie(19, 1, 7, ZombieOutfit.MECHANIC);
        p.zombie(7, 1, 2, null);
    }

    /** Бар: тёмный кирпич, стойка, бочки. */
    public static void bar(Plan p) {
        shop(p, 3, 2, 21, 11, 4, Blocks.NETHER_BRICKS.getDefaultState(), Blocks.PURPLE_CONCRETE.getDefaultState(), Blocks.DARK_OAK_PLANKS.getDefaultState());
        for (int x = 4; x <= 20; x++) p.set(x, 1, 2, x == 12 ? Blocks.AIR.getDefaultState() : Blocks.NETHER_BRICKS.getDefaultState());
        counter(p, 5, 19, 8);
        for (int x = 5; x <= 19; x++) if (x != 12) p.furnLoot(x, 1, 10, x % 3 == 0 ? "fridge" : "kitchen_counter", Direction.NORTH, Loot.BAR);
        p.furn(20, 1, 4, "tv", Direction.WEST);
        for (int x = 6; x <= 18; x += 4) p.table(x, 1, 5);
        lamp(p, 8, 4, 6);
        lamp(p, 16, 4, 6);
        p.zombie(12, 1, 9, ZombieOutfit.BIKER);
        p.zombie(7, 1, 4, ZombieOutfit.BIKER);
    }

    /** Офис в 2 этажа. */
    public static void office(Plan p) {
        BlockState wall = Blocks.LIGHT_GRAY_CONCRETE.getDefaultState();
        p.fill(2, 0, 2, 22, 0, 11, Blocks.GRAY_CARPET);
        p.walls(2, 1, 2, 22, 8, 11, wall);
        p.air(3, 1, 3, 21, 8, 10);
        p.fill(3, 4, 3, 21, 4, 10, Blocks.SMOOTH_STONE);
        for (int y : new int[]{2, 3, 6, 7}) for (int x = 3; x <= 21; x++) if (x % 2 == 1) {
            p.set(x, y, 2, Blocks.LIGHT_BLUE_STAINED_GLASS_PANE);
            p.set(x, y, 11, Blocks.LIGHT_BLUE_STAINED_GLASS_PANE);
        }
        p.door(12, 1, 2, Blocks.BIRCH_DOOR, Direction.NORTH);
        flatRoof(p, 2, 2, 22, 11, 9, Blocks.GRAY_CONCRETE.getDefaultState(), wall);
        p.ladder(21, 1, 5, 10, Direction.NORTH);
        p.set(21, 4, 10, Blocks.AIR);
        for (int fl : new int[]{1, 5}) for (int x = 4; x <= 19; x += 5) {
            p.furnLoot(x, fl, 6, "desk", Direction.SOUTH, Loot.OFFICE);
            p.furn(x, fl, 7, "chair", Direction.NORTH);
            if (p.r.nextFloat() < 0.5f) p.furnLoot(x + 2, fl, 9, "cardboard_box", Direction.NORTH, Loot.OFFICE);
            if (p.r.nextFloat() < 0.4f) p.pile(x + 1, fl, 7, Loot.OFFICE);
        }
        p.furnLoot(3, 1, 3, "trash_can", Direction.SOUTH, Loot.TRASH);
        p.fill(2, 0, 0, 22, 0, 1, Blocks.SMOOTH_STONE);
        p.zombie(8, 1, 5, ZombieOutfit.BUSINESS);
        p.zombie(15, 5, 6, ZombieOutfit.BUSINESS);
    }

    /** Магазин одежды. */
    public static void clothes(Plan p) {
        shop(p, 1, 2, 23, 11, 4, Blocks.PINK_TERRACOTTA.getDefaultState(), Blocks.MAGENTA_CONCRETE.getDefaultState(), Blocks.BIRCH_PLANKS.getDefaultState());
        for (int x = 4; x <= 20; x += 4) {
            p.set(x, 1, 6, Blocks.OAK_FENCE);
            p.loot(x + 1, 1, 6, chest(Direction.NORTH), Loot.CLOTHES);
        }
        for (int x = 3; x <= 21; x++) if (x != 12 && x % 2 == 0) p.loot(x, 1, 10, BARREL, Loot.CLOTHES);
        counter(p, 2, 4, 4);
        p.zombie(10, 1, 7, null);
    }

    /** Сельский магазинчик (12x12) для деревни. */
    public static void generalStore(Plan p) {
        BlockState wall = Blocks.SPRUCE_PLANKS.getDefaultState();
        p.fill(1, 0, 3, 10, 0, 10, Blocks.OAK_PLANKS);
        p.walls(1, 1, 3, 10, 4, 10, wall);
        p.air(2, 1, 4, 9, 4, 9);
        p.windows(1, 3, 10, 10, 2, GLASS, 5);
        p.door(5, 1, 3, Blocks.SPRUCE_DOOR, Direction.NORTH);
        for (int x = 1; x <= 10; x++) p.set(x, 4, 3, Blocks.RED_TERRACOTTA);
        p.fill(1, 5, 3, 10, 5, 10, Blocks.SPRUCE_PLANKS);
        gableRoof(p, 1, 3, 10, 10, 5, HOUSE_STYLES[5], wall);
        p.fill(1, 0, 1, 10, 0, 2, Blocks.SPRUCE_PLANKS);
        p.set(1, 1, 1, Blocks.SPRUCE_FENCE);
        p.set(10, 1, 1, Blocks.SPRUCE_FENCE);
        for (int x = 2; x <= 9; x++) {
            if (x == 5) continue;
            p.furnLoot(x, 1, 9, x % 2 == 0 ? "shelf_food" : "shelf_tools", Direction.NORTH, x % 2 == 0 ? Loot.GROCERY : Loot.HARDWARE);
        }
        counter(p, 7, 9, 5);
        p.furnLoot(2, 1, 5, "fridge", Direction.EAST, Loot.FRIDGE);
        p.zombie(5, 1, 7, null);
    }

    /** Часовня (12x12) для деревни. */
    public static void chapel(Plan p) {
        BlockState wall = Blocks.WHITE_TERRACOTTA.getDefaultState();
        p.fill(2, 0, 2, 9, 0, 11, Blocks.SPRUCE_PLANKS);
        p.walls(2, 1, 2, 9, 4, 11, wall);
        p.air(3, 1, 3, 8, 4, 10);
        for (int z = 4; z <= 9; z += 2) {
            p.set(2, 2, z, Blocks.YELLOW_STAINED_GLASS_PANE);
            p.set(9, 2, z, Blocks.YELLOW_STAINED_GLASS_PANE);
        }
        p.door(5, 1, 2, Blocks.SPRUCE_DOOR, Direction.NORTH);
        p.fill(2, 5, 2, 9, 5, 11, Blocks.SPRUCE_PLANKS);
        gableRoof(p, 2, 2, 9, 11, 5, HOUSE_STYLES[0], wall);
        p.fill(5, 6, 1, 6, 11, 2, wall.getBlock());
        p.set(5, 12, 1, Blocks.BELL);
        for (int z = 5; z <= 8; z++) {
            p.set(3, 1, z, p.stair(Blocks.SPRUCE_STAIRS, Direction.SOUTH, false));
            p.set(4, 1, z, p.stair(Blocks.SPRUCE_STAIRS, Direction.SOUTH, false));
            p.set(7, 1, z, p.stair(Blocks.SPRUCE_STAIRS, Direction.SOUTH, false));
            p.set(8, 1, z, p.stair(Blocks.SPRUCE_STAIRS, Direction.SOUTH, false));
        }
        p.set(5, 1, 10, Blocks.QUARTZ_BLOCK);
        p.set(6, 1, 10, Blocks.QUARTZ_BLOCK);
        p.loot(8, 1, 10, chest(Direction.WEST), Loot.CHURCH);
        p.zombie(5, 1, 8, ZombieOutfit.PRIEST);
    }

    // ===== большие участки (25x25) =====

    /** Полицейский участок: приёмная, кабинеты, оружейная, камеры, парковка. */
    public static void police(Plan p) {
        BlockState wall = Blocks.STONE_BRICKS.getDefaultState();
        int x1 = 2, x2 = 22, z1 = 3, z2 = 19, h = 4;
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.POLISHED_ANDESITE);
        p.walls(x1, 1, z1, x2, h, z2, wall);
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, h, z2 - 1);
        p.windows(x1, z1, x2, z2, 2, Blocks.IRON_BARS.getDefaultState(), 12);
        for (int x = x1; x <= x2; x++) p.set(x, h, z1, Blocks.BLUE_CONCRETE);
        p.door(12, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.door(12, 1, z2, Blocks.BIRCH_DOOR, Direction.SOUTH);
        flatRoof(p, x1, z1, x2, z2, h + 1, Blocks.GRAY_CONCRETE.getDefaultState(), wall);
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.SMOOTH_STONE);
        p.set(9, 1, 1, Blocks.STONE_BRICK_WALL);
        p.set(15, 1, 1, Blocks.STONE_BRICK_WALL);
        lamp(p, 12, 4, 5);
        // стойка дежурного
        for (int x = 5; x <= 19; x++) if (x != 12) p.set(x, 1, 7, Blocks.POLISHED_ANDESITE);
        // перегородка между кабинетами и камерами
        for (int z = 8; z <= 18; z++) p.fill(12, 1, z, 12, h, z, wall);
        p.air(12, 1, 9, 12, 2, 9);
        // кабинеты слева
        for (int z = 10; z <= 17; z += 4) {
            p.furnLoot(5, 1, z, "desk", Direction.SOUTH, Loot.OFFICE);
            p.furn(5, 1, z + 1, "chair", Direction.NORTH);
            p.furnLoot(3, 1, z, "wardrobe", Direction.EAST, Loot.POLICE);
        }
        for (int z = 9; z <= 18; z++) if (z % 2 == 0) p.loot(11, 1, z, BARREL, Loot.POLICE);
        // оружейная и камеры справа
        p.loot(14, 1, 8, BARREL, Loot.POLICE);
        p.loot(15, 1, 8, BARREL, Loot.POLICE);
        p.loot(16, 1, 8, chest(Direction.SOUTH), Loot.POLICE);
        for (int x = 13; x <= 21; x++) p.fill(x, 1, 12, x, h, 12, Blocks.IRON_BARS);
        for (int x : new int[]{16, 19}) for (int z = 13; z <= 18; z++) p.fill(x, 1, z, x, h, z, Blocks.IRON_BARS);
        p.air(14, 1, 12, 14, 2, 12);
        p.air(18, 1, 12, 18, 2, 12);
        p.bed(14, 1, 16, Blocks.WHITE_BED, Direction.SOUTH);
        p.bed(20, 1, 16, Blocks.WHITE_BED, Direction.SOUTH);
        // парковка
        for (int x = 1; x <= 23; x++) for (int z = 20; z <= 24; z++) p.set(x, 0, z, Blocks.BLACK_CONCRETE);
        for (int x = 4; x <= 20; x += 4) p.set(x, 0, 22, Blocks.WHITE_CONCRETE);
        car(p, 2, 21, false, "police");
        if (p.r.nextBoolean()) car(p, 8, 21, false, "police");
        p.zombie(10, 1, 5, ZombieOutfit.POLICE);
        p.zombie(7, 1, 12, ZombieOutfit.POLICE);
        p.zombie(15, 1, 15, ZombieOutfit.PRISONER);
        if (p.r.nextBoolean()) p.zombie(20, 1, 22, ZombieOutfit.POLICE);
    }

    /** Пожарная часть: гараж с машиной, шкафчики. */
    public static void fireStation(Plan p) {
        BlockState wall = Blocks.BRICKS.getDefaultState();
        int x1 = 2, x2 = 22, z1 = 3, z2 = 20, h = 6;
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.GRAY_CONCRETE);
        p.walls(x1, 1, z1, x2, h, z2, wall);
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, h, z2 - 1);
        p.air(4, 1, z1, 12, 4, z1);
        for (int x = 4; x <= 12; x++) p.set(x, 5, z1, Blocks.RED_CONCRETE);
        p.windows(x1, z1, x2, z2, 3, GLASS, 8);
        p.door(17, 1, z1, Blocks.OAK_DOOR, Direction.NORTH);
        flatRoof(p, x1, z1, x2, z2, h + 1, Blocks.GRAY_CONCRETE.getDefaultState(), wall);
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.SMOOTH_STONE);
        // пожарная машина
        p.fill(6, 1, 6, 10, 2, 16, Blocks.RED_CONCRETE);
        p.fill(6, 3, 6, 10, 3, 8, Blocks.RED_CONCRETE);
        p.fill(7, 2, 5, 9, 2, 5, Blocks.TINTED_GLASS);
        p.fill(7, 3, 9, 9, 3, 15, Blocks.LIGHT_GRAY_CONCRETE);
        for (int z : new int[]{7, 14}) {
            p.set(5, 1, z, Blocks.BLACK_CONCRETE);
            p.set(11, 1, z, Blocks.BLACK_CONCRETE);
        }
        for (int z = 5; z <= 18; z += 2) p.loot(21, 1, z, BARREL, Loot.FIRE);
        p.set(21, 2, 6, Blocks.CAULDRON);
        p.bed(15, 1, 15, Blocks.RED_BED, Direction.SOUTH);
        p.bed(17, 1, 15, Blocks.RED_BED, Direction.SOUTH);
        p.table(16, 1, 9);
        lamp(p, 8, 6, 11);
        lamp(p, 17, 6, 11);
        p.zombie(14, 1, 8, ZombieOutfit.FIREFIGHTER);
        p.zombie(18, 1, 12, ZombieOutfit.FIREFIGHTER);
    }

    /** Клиника: приёмная, коридор, палаты. */
    public static void clinic(Plan p) {
        BlockState wall = Blocks.WHITE_CONCRETE.getDefaultState();
        int x1 = 2, x2 = 22, z1 = 3, z2 = 20, h = 4;
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.WHITE_CONCRETE);
        p.walls(x1, 1, z1, x2, h, z2, wall);
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, h, z2 - 1);
        p.windows(x1, z1, x2, z2, 2, GLASS, 12);
        p.door(12, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        for (int x = x1; x <= x2; x++) p.set(x, h, z1, Blocks.LIGHT_BLUE_CONCRETE);
        p.fill(11, 5, 2, 13, 5, 2, Blocks.RED_CONCRETE);
        p.fill(12, 4, 2, 12, 6, 2, Blocks.RED_CONCRETE);
        flatRoof(p, x1, z1, x2, z2, h + 1, Blocks.GRAY_CONCRETE.getDefaultState(), wall);
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.SMOOTH_STONE);
        if (p.r.nextFloat() < 0.7f) car(p, 15, 0, false, "ambulance");
        counter(p, 8, 16, 7);
        // палаты по сторонам коридора (x = 11..13)
        for (int z = 8; z <= 19; z++) {
            p.fill(10, 1, z, 10, h, z, wall);
            p.fill(14, 1, z, 14, h, z, wall);
        }
        for (int z = 8; z <= 19; z += 4) {
            p.fill(x1 + 1, 1, z, 9, h, z, wall);
            p.fill(15, 1, z, x2 - 1, h, z, wall);
            p.air(10, 1, z + 2, 10, 2, z + 2);
            p.air(14, 1, z + 2, 14, 2, z + 2);
            p.bed(4, 1, z + 1, Blocks.WHITE_BED, Direction.EAST);
            p.bed(19, 1, z + 1, Blocks.WHITE_BED, Direction.WEST);
            p.furnLoot(4, 1, z + 3, "nightstand", Direction.NORTH, Loot.CLINIC);
            p.furnLoot(19, 1, z + 3, "nightstand", Direction.NORTH, Loot.CLINIC);
            p.furnLoot(8, 1, z + 3, "shelf_meds", Direction.WEST, Loot.CLINIC);
            if (p.r.nextFloat() < 0.4f) p.pile(6, 1, z + 2, Loot.CLINIC);
        }
        lamp(p, 12, 4, 10);
        lamp(p, 12, 4, 17);
        p.zombie(12, 1, 6, ZombieOutfit.NURSE);
        p.zombie(6, 1, 14, ZombieOutfit.DOCTOR);
        p.zombie(18, 1, 10, null);
    }

    /** Школа: коридор и 4 класса с партами. */
    public static void school(Plan p) {
        BlockState wall = Blocks.BRICKS.getDefaultState();
        int x1 = 1, x2 = 23, z1 = 3, z2 = 22, h = 5;
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.OAK_PLANKS);
        p.walls(x1, 1, z1, x2, h, z2, wall);
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, h, z2 - 1);
        p.windows(x1, z1, x2, z2, 3, GLASS, 12);
        p.windows(x1, z1, x2, z2, 2, GLASS, 12);
        p.door(12, 1, z1, Blocks.OAK_DOOR, Direction.NORTH);
        flatRoof(p, x1, z1, x2, z2, h + 1, Blocks.GRAY_CONCRETE.getDefaultState(), wall);
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.SMOOTH_STONE);
        p.fill(11, 6, 1, 13, 9, 3, Blocks.BRICKS);
        p.set(12, 10, 2, Blocks.BELL);
        for (int z = z1 + 1; z <= z2 - 1; z++) {
            p.fill(10, 1, z, 10, h, z, wall);
            p.fill(14, 1, z, 14, h, z, wall);
        }
        p.fill(x1 + 1, 1, 12, 9, h, 12, wall);
        p.fill(15, 1, 12, x2 - 1, h, 12, wall);
        for (int[] room : new int[][]{{2, 4, 9, 11}, {2, 13, 9, 21}, {15, 4, 22, 11}, {15, 13, 22, 21}}) {
            boolean left = room[0] == 2;
            p.air(left ? 10 : 14, 1, room[1] + 2, left ? 10 : 14, 2, room[1] + 2);
            for (int z = room[1] + 2; z <= room[3] - 1; z += 2)
                for (int x = room[0] + 1; x <= room[2] - 1; x += 2) {
                    p.set(x, 1, z, Blocks.SPRUCE_SLAB);
                    p.set(x, 1, z + 1, p.stair(Blocks.OAK_STAIRS, Direction.SOUTH, false));
                }
            p.loot(left ? room[0] : room[2], 1, room[3], chest(left ? Direction.EAST : Direction.WEST), Loot.SCHOOL);
            lamp(p, (room[0] + room[2]) / 2, h, (room[1] + room[3]) / 2);
        }
        p.zombie(6, 1, 7, ZombieOutfit.STUDENT);
        p.zombie(18, 1, 17, ZombieOutfit.STUDENT);
        p.zombie(12, 1, 15, null);
    }

    /** Церковь: каменная, высокая двускатная крыша, скамьи, колокольня. */
    public static void church(Plan p) {
        BlockState wall = Blocks.STONE_BRICKS.getDefaultState();
        int x1 = 6, x2 = 18, z1 = 4, z2 = 22, h = 6;
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.POLISHED_ANDESITE);
        p.walls(x1, 1, z1, x2, h, z2, wall);
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, h, z2 - 1);
        for (int z = z1 + 2; z <= z2 - 2; z += 3) {
            p.fill(x1, 2, z, x1, 4, z, Blocks.YELLOW_STAINED_GLASS_PANE);
            p.fill(x2, 2, z, x2, 4, z, Blocks.YELLOW_STAINED_GLASS_PANE);
        }
        p.door(12, 1, z1, Blocks.DARK_OAK_DOOR, Direction.NORTH);
        p.fill(x1, h + 1, z1, x2, h + 1, z2, Blocks.STONE_BRICKS);
        Style roofStyle = new Style(wall, wall, Blocks.DEEPSLATE_TILE_STAIRS, Blocks.DEEPSLATE_TILE_SLAB, Blocks.DEEPSLATE_TILES.getDefaultState(), Blocks.DARK_OAK_DOOR, wall);
        // крыша вдоль z: строим «повёрнутую» двускатную вручную
        for (int k = 0; x1 - 1 + k < x2 + 1 - k; k++) {
            for (int z = z1 - 1; z <= z2 + 1; z++) {
                p.set(x1 - 1 + k, h + 1 + k, z, p.stair(roofStyle.stairs(), Direction.EAST, false));
                p.set(x2 + 1 - k, h + 1 + k, z, p.stair(roofStyle.stairs(), Direction.WEST, false));
            }
            for (int x = x1 + k; x <= x2 - k; x++) {
                if (x > x1 - 1 + k && x < x2 + 1 - k) {
                    p.set(x, h + 1 + k, z1, wall);
                    p.set(x, h + 1 + k, z2, wall);
                }
            }
        }
        for (int z = z1 - 1; z <= z2 + 1; z++) p.set(12, h + 8, z, Blocks.DEEPSLATE_TILE_SLAB);
        // колокольня
        p.fill(10, 1, 1, 14, 14, 3, wall);
        p.air(11, 1, 2, 13, 13, 2);
        p.air(12, 1, 1, 12, 2, 3);
        p.set(12, 12, 2, Blocks.BELL);
        p.air(11, 12, 1, 13, 13, 1);
        p.fill(9, 15, 0, 15, 15, 4, Blocks.DEEPSLATE_TILES);
        p.set(12, 16, 2, Blocks.DEEPSLATE_TILES);
        p.set(12, 17, 2, Blocks.STONE_BRICK_WALL);
        // скамьи и алтарь
        for (int z = z1 + 3; z <= z2 - 5; z += 2)
            for (int x = x1 + 1; x <= x2 - 1; x++) {
                if (Math.abs(x - 12) <= 1) continue;
                p.set(x, 1, z, p.stair(Blocks.DARK_OAK_STAIRS, Direction.SOUTH, false));
            }
        p.fill(10, 1, z2 - 2, 14, 1, z2 - 2, Blocks.QUARTZ_BLOCK);
        p.set(12, 2, z2 - 2, Blocks.CANDLE);
        p.loot(x2 - 1, 1, z2 - 1, chest(Direction.WEST), Loot.CHURCH);
        lamp(p, 12, h, 12);
        p.fill(x1, 0, 0, x2, 0, 0, Blocks.GRAVEL);
        for (int i = 0; i < 4; i++) p.tree(i % 2 == 0 ? 2 : 22, 0, 6 + i * 5, 2);
        p.zombie(12, 1, z2 - 4, ZombieOutfit.PRIEST);
        p.zombie(8, 1, 12, null);
    }

    /** Склад: высокая коробка, стеллажи, погрузочные ворота. */
    public static void warehouse(Plan p) {
        BlockState wall = Blocks.LIGHT_GRAY_CONCRETE.getDefaultState();
        int x1 = 1, x2 = 23, z1 = 2, z2 = 23, h = 7;
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.GRAY_CONCRETE);
        p.walls(x1, 1, z1, x2, h, z2, wall);
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, h, z2 - 1);
        for (int x = x1; x <= x2; x += 2) p.set(x, 1, z1, Blocks.IRON_BLOCK);
        p.air(16, 1, z1, 20, 5, z1);
        p.door(6, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        for (int x = x1; x <= x2; x++) p.set(x, h, z1, Blocks.YELLOW_CONCRETE);
        flatRoof(p, x1, z1, x2, z2, h + 1, Blocks.IRON_BLOCK.getDefaultState(), wall);
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.GRAY_CONCRETE);
        for (int z = 6; z <= 20; z += 4)
            for (int x = 3; x <= 21; x++) {
                if (x >= 11 && x <= 13) continue;
                for (int y = 1; y <= 3; y++) {
                    if (p.r.nextFloat() < 0.75f) {
                        if (p.r.nextFloat() < 0.15f) p.loot(x, y, z, BARREL, Loot.WAREHOUSE);
                        else if (y == 1 && p.r.nextFloat() < 0.4f) p.furn(x, y, z, "cardboard_box", Direction.NORTH);
                        else p.set(x, y, z, p.r.nextFloat() < 0.3f ? Blocks.HAY_BLOCK.getDefaultState() : BARREL);
                    }
                }
            }
        lamp(p, 6, h, 10);
        lamp(p, 18, h, 10);
        lamp(p, 12, h, 18);
        p.zombie(12, 1, 9, ZombieOutfit.CONSTRUCTION);
        p.zombie(12, 1, 17, ZombieOutfit.MECHANIC);
    }

    /** Мотель: ряд номеров и офис, парковка спереди. */
    public static void motel(Plan p) {
        BlockState wall = Blocks.WHITE_TERRACOTTA.getDefaultState();
        BlockState doorWall = Blocks.LIGHT_BLUE_TERRACOTTA.getDefaultState();
        for (int x = 1; x <= 23; x++) for (int z = 0; z <= 11; z++) p.set(x, 0, z, Blocks.BLACK_CONCRETE);
        for (int x = 4; x <= 22; x += 4) p.set(x, 0, 6, Blocks.WHITE_CONCRETE);
        int z1 = 13, z2 = 21;
        p.fill(1, 0, z1, 23, 0, z2, Blocks.OAK_PLANKS);
        p.walls(1, 1, z1, 23, 4, z2, wall);
        p.air(2, 1, z1 + 1, 22, 4, z2 - 1);
        p.fill(1, 5, z1, 23, 5, z2, Blocks.GRAY_CONCRETE);
        p.fill(1, 4, 12, 23, 4, 12, Blocks.SMOOTH_STONE_SLAB);
        for (int x = 1; x <= 23; x += 4) p.fill(x, 1, 12, x, 3, 12, Blocks.SPRUCE_FENCE);
        int room = 0;
        for (int x = 1; x + 4 <= 23; x += 4, room++) {
            if (x > 1) p.fill(x, 1, z1 + 1, x, 4, z2 - 1, wall);
            for (int y = 1; y <= 3; y++) p.set(x + 1, y, z1, doorWall);
            p.door(x + 2, 1, z1, Blocks.OAK_DOOR, Direction.NORTH);
            p.set(x + 3, 2, z1, GLASS);
            p.bed(x + 1, 1, z1 + 3, Blocks.WHITE_BED, Direction.SOUTH);
            p.furnLoot(x + 3, 1, z2 - 1, "nightstand", Direction.NORTH, Loot.BEDROOM);
            p.furn(x + 3, 1, z1 + 2, "tv", Direction.WEST);
            p.furn(x + 1, 1, z2 - 1, "toilet", Direction.NORTH);
            if (p.r.nextFloat() < 0.5f) p.pile(x + 2, 1, z1 + 6, Loot.BEDROOM);
            if (p.r.nextFloat() < 0.4f) p.zombie(x + 2, 1, z1 + 4, null);
        }
        car(p, 3, 3, true);
        if (p.r.nextBoolean()) car(p, 15, 3, true);
    }

    // ===== ферма =====

    /** Красный амбар (16x14) с сеном и инструментами. */
    public static void barn(Plan p, int ox, int oz) {
        BlockState wall = Blocks.RED_TERRACOTTA.getDefaultState();
        int x1 = ox, x2 = ox + 15, z1 = oz, z2 = oz + 13, h = 5;
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.COARSE_DIRT);
        p.walls(x1, 1, z1, x2, h, z2, wall);
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, h, z2 - 1);
        for (int y = 1; y <= h; y++) {
            p.set(x1, y, z1, Blocks.WHITE_TERRACOTTA);
            p.set(x2, y, z1, Blocks.WHITE_TERRACOTTA);
        }
        p.air(x1 + 6, 1, z1, x1 + 9, 4, z1);
        Style rs = new Style(wall, wall, Blocks.DARK_OAK_STAIRS, Blocks.DARK_OAK_SLAB, Blocks.DARK_OAK_PLANKS.getDefaultState(), Blocks.SPRUCE_DOOR, wall);
        p.fill(x1, h + 1, z1, x2, h + 1, z2, Blocks.SPRUCE_PLANKS);
        gableRoof(p, x1, z1, x2, z2, h + 1, rs, wall);
        for (int i = 0; i < 14; i++) {
            int x = x1 + 1 + p.r.nextInt(14), z = z1 + 7 + p.r.nextInt(6);
            int y = 1;
            while (p.get(x, y, z) != null && p.get(x, y, z).isOf(Blocks.HAY_BLOCK) && y < 3) y++;
            p.set(x, y, z, Blocks.HAY_BLOCK);
        }
        p.loot(x1 + 1, 1, z1 + 2, BARREL, Loot.BARN);
        p.loot(x1 + 1, 1, z1 + 4, chest(Direction.EAST), Loot.BARN);
        p.loot(x2 - 1, 1, z1 + 2, BARREL, Loot.GARAGE);
        lamp(p, x1 + 8, h, z1 + 6);
        p.zombie(x1 + 8, 1, z1 + 4, ZombieOutfit.FARMER);
    }

    /** Силос: «цилиндр» радиуса 3. */
    public static void silo(Plan p, int cx, int cz) {
        for (int y = 0; y <= 13; y++)
            for (int dx = -3; dx <= 3; dx++)
                for (int dz = -3; dz <= 3; dz++) {
                    double dd = Math.sqrt(dx * dx + dz * dz);
                    if (dd <= 3.3 && dd >= 2.3) p.set(cx + dx, y, cz + dz, y % 4 == 0 ? Blocks.STONE.getDefaultState() : Blocks.SMOOTH_STONE.getDefaultState());
                    else if (dd < 2.3 && (y == 0 || y == 13)) p.set(cx + dx, y, cz + dz, Blocks.SMOOTH_STONE.getDefaultState());
                }
        p.set(cx, 14, cz, Blocks.IRON_BLOCK);
    }

    /** Грядки с культурой и канавкой воды посередине. */
    public static void field(Plan p, int x1, int z1, int x2, int z2) {
        Block[] crops = {Blocks.WHEAT, Blocks.CARROTS, Blocks.POTATOES, Blocks.BEETROOTS};
        Block crop = crops[p.r.nextInt(crops.length)];
        int mid = (z1 + z2) / 2;
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                if (z == mid) {
                    p.set(x, 0, z, Blocks.WATER);
                    continue;
                }
                p.set(x, 0, z, Blocks.FARMLAND.getDefaultState().with(FarmlandBlock.MOISTURE, 7));
                if (p.r.nextFloat() < 0.85f && crop instanceof CropBlock cb) {
                    p.set(x, 1, z, cb.withAge(p.r.nextInt(cb.getMaxAge() + 1)));
                }
            }
    }

    /** Охотничья хижина в лесу. */
    public static void cabin(Plan p) {
        Style s = new Style(Blocks.SPRUCE_LOG.getDefaultState(), Blocks.SPRUCE_PLANKS.getDefaultState(), Blocks.SPRUCE_STAIRS, Blocks.SPRUCE_SLAB, Blocks.SPRUCE_PLANKS.getDefaultState(), Blocks.SPRUCE_DOOR, Blocks.SPRUCE_PLANKS.getDefaultState());
        int x1 = 2, x2 = 9, z1 = 3, z2 = 9;
        p.fill(x1, 0, z1, x2, 0, z2, s.floor());
        p.walls(x1, 1, z1, x2, 3, z2, s.wall());
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, 3, z2 - 1);
        p.windows(x1, z1, x2, z2, 2, GLASS, 5);
        p.door(5, 1, z1, s.door(), Direction.NORTH);
        p.fill(x1, 4, z1, x2, 4, z2, s.roof());
        gableRoof(p, x1, z1, x2, z2, 4, s, s.trim());
        p.bed(3, 1, 6, Blocks.BROWN_BED, Direction.SOUTH);
        p.loot(8, 1, 8, chest(Direction.WEST), Loot.CABIN);
        p.furnLoot(8, 1, 4, "kitchen_counter", Direction.WEST, Loot.CABIN);
        p.furn(5, 1, 7, "kitchen_table", Direction.NORTH);
        p.furn(6, 1, 7, "chair", Direction.WEST);
        if (p.r.nextFloat() < 0.8f) p.pile(5, 2, 7, Loot.CABIN);
        p.furn(8, 1, 6, "radio", Direction.WEST);
        p.set(3, 1, 4, Blocks.CAMPFIRE.getDefaultState().with(net.minecraft.block.CampfireBlock.LIT, false));
        p.fill(10, 1, 5, 10, 1, 7, Blocks.OAK_LOG);
        p.zombie(5, 1, 6, ZombieOutfit.SURVIVOR);
    }
}
