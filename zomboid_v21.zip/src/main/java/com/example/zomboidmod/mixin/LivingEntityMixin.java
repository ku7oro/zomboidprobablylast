package com.example.zomboidmod.mixin;

import com.example.zomboidmod.WeaponKinds;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Длительность взмаха зависит от оружия: кувалдой замахиваются вдвое дольше, чем ножом. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true)
    private void zomboid$swingDuration(CallbackInfoReturnable<Integer> cir) {
        int t = WeaponKinds.swingTicks(((LivingEntity) (Object) this).getMainHandStack());
        if (t > 0) cir.setReturnValue(t);
    }
}
