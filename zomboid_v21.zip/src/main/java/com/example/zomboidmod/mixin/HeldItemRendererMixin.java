package com.example.zomboidmod.mixin;

import com.example.zomboidmod.WeaponAnim;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Свой взмах оружием от первого лица (замах, укол, рубящий удар). */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Unique
    private static ItemStack zomboid$current = ItemStack.EMPTY;

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void zomboid$remember(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand, float swingProgress,
                                  ItemStack item, float equipProgress, MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                  int light, CallbackInfo ci) {
        zomboid$current = item;
    }

    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true)
    private void zomboid$swing(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        com.example.zomboidmod.WeaponKinds.Kind kind = WeaponAnim.kind(zomboid$current);
        if (kind == null) return;
        WeaponAnim.firstPerson(kind, matrices, arm, swingProgress);
        ci.cancel();
    }
}
