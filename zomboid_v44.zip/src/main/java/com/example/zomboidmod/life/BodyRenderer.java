package com.example.zomboidmod.life;

import com.example.zomboidmod.PzZombieRenderer;
import com.example.zomboidmod.ZombieKind;
import com.example.zomboidmod.ZombieOutfit;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.survivors.SurvivorSkins;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Тело лежит на спине или ничком в одной из поз (руки раскинуты, вытянуты над головой, голова набок).
 * Та же модель и текстуры, что у живого мертвеца (или у выжившего); гниющее — темнеет и зеленеет.
 */
public class BodyRenderer extends EntityRenderer<BodyEntity> {
    private final BipedEntityModel<LivingEntity> zombie;
    private final PlayerEntityModel<LivingEntity> human;
    private static final Identifier[] SKINS = new Identifier[SurvivorSkins.COUNT];

    static {
        for (int i = 0; i < SKINS.length; i++) SKINS[i] = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/survivor/survivor_" + i + ".png");
    }

    public BodyRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        zombie = new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE));
        human = new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false);
        this.shadowRadius = 0.6f;
    }

    /** Поза: 0-1 на спине, 2-3 ничком. Углы выставляются заново каждый кадр. */
    public static void pose(BipedEntityModel<?> m, int pose, long seed, boolean noLegs) {
        m.head.resetTransform();
        m.body.resetTransform();
        m.rightArm.resetTransform();
        m.leftArm.resetTransform();
        m.rightLeg.resetTransform();
        m.leftLeg.resetTransform();
        float a = ((seed >>> 8) & 255) / 255f, b = ((seed >>> 16) & 255) / 255f;
        float turn = (a - 0.5f) * 2.2f;                       // голова повёрнута набок
        switch (pose) {
            case 0 -> {   // на спине, руки раскинуты
                m.head.yaw = turn;
                m.rightArm.roll = 0.9f + 0.6f * b;
                m.leftArm.roll = -0.7f - 0.6f * a;
                m.rightLeg.roll = 0.12f;
                m.leftLeg.roll = -0.18f;
            }
            case 1 -> {   // на спине, одна рука на груди, ноги скрещены
                m.head.yaw = turn * 0.6f;
                m.head.pitch = -0.25f;
                m.rightArm.pitch = -0.5f;
                m.rightArm.yaw = 0.9f;
                m.rightArm.roll = -0.3f;
                m.leftArm.roll = -0.35f * b;
                m.rightLeg.roll = -0.12f;
                m.leftLeg.roll = 0.1f;
            }
            case 2 -> {   // ничком, руки вытянуты над головой
                m.head.yaw = turn;
                m.rightArm.pitch = -2.85f - 0.2f * a;
                m.leftArm.pitch = -2.95f + 0.15f * b;
                m.rightArm.roll = 0.15f;
                m.leftArm.roll = -0.15f;
                m.leftLeg.roll = -0.3f * b;
            }
            default -> {  // ничком, руки вдоль тела, нога подогнута в сторону
                m.head.yaw = turn;
                m.rightArm.roll = 0.15f;
                m.leftArm.roll = -0.35f;
                m.rightLeg.roll = 0.55f * a;
                m.rightLeg.yaw = 0.3f;
            }
        }
        m.rightLeg.visible = !noLegs;
        m.leftLeg.visible = !noLegs;
        m.hat.copyTransform(m.head);
        if (m instanceof PlayerEntityModel<?> p) {
            p.jacket.copyTransform(m.body);
            p.rightSleeve.copyTransform(m.rightArm);
            p.leftSleeve.copyTransform(m.leftArm);
            p.rightPants.copyTransform(m.rightLeg);
            p.leftPants.copyTransform(m.leftLeg);
            p.rightPants.visible = !noLegs;
            p.leftPants.visible = !noLegs;
        }
    }

    @Override
    public void render(BodyEntity e, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vcp, int light) {
        int look = e.look();
        boolean humanBody = look < 0;
        java.util.UUID skin = e.skin();
        ZombieKind kind = ZombieKind.SHAMBLER;
        ZombieOutfit outfit = null;
        Identifier body;
        float scale = 1f, wide = 1f;
        if (humanBody) {
            body = SKINS[Math.floorMod(-look - 1, SKINS.length)];
        } else {
            ZombieKind[] ks = ZombieKind.values();
            ZombieOutfit[] os = ZombieOutfit.values();
            kind = ks[Math.min((look >> 16) & 255, ks.length - 1)];
            outfit = os[Math.min(look & 255, os.length - 1)];
            int tone = (look >> 8) & 255;
            body = PzZombieRenderer.bodyTex(skin, tone, kind);
            switch (kind) {
                case BRUTE -> scale = 1.3f;
                case CARRIER -> {
                    scale = 1.65f;
                    wide = 1.12f;
                }
                case BLOATER -> {
                    scale = 1.12f;
                    wide = 1.34f;
                }
                case ARMORED -> scale = 1.05f;
                default -> {
                }
            }
        }
        BipedEntityModel<?> m = humanBody ? human : zombie;
        int pose = e.pose();
        boolean faceDown = pose >= 2;
        pose(m, pose, skin.getLeastSignificantBits(), kind == ZombieKind.CRAWLER);

        float rot = e.rot();
        int r = (int) MathHelper.lerp(rot, 255, 112), g = (int) MathHelper.lerp(rot, 255, 120), bl = (int) MathHelper.lerp(rot, 255, 92);
        int color = 0xFF000000 | (r << 16) | (g << 8) | bl;

        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - e.getYaw()));
        float len = 0.92f * scale, lift = 0.2f * scale * wide;
        matrices.translate(0f, lift, faceDown ? len : -len);                       // середина тела — над точкой сущности
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(faceDown ? -90f : 90f));
        matrices.scale(scale * wide, scale, scale * wide);
        matrices.scale(-1f, -1f, 1f);
        matrices.translate(0f, -1.501f, 0f);
        m.render(matrices, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(body)), light, OverlayTexture.DEFAULT_UV, color);
        if (outfit != null && kind != ZombieKind.CARRIER)
            m.render(matrices, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(outfit.outfitTexture(skin))), light, OverlayTexture.DEFAULT_UV, color);
        matrices.pop();
        super.render(e, yaw, tickDelta, matrices, vcp, light);
    }

    @Override
    public Identifier getTexture(BodyEntity e) {
        return SKINS[0];
    }
}
