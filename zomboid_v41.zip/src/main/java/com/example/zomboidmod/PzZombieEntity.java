package com.example.zomboidmod;

import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** Зомби в духе Project Zomboid: одежда, повадки (шатун, бегун, ползун), шум, вещи в карманах. */
public class PzZombieEntity extends ZombieEntity {
    private static final TrackedData<Integer> VARIANT =
            DataTracker.registerData(PzZombieEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private BlockPos noisePos;
    private int noiseTicks;
    private boolean lootRolled;

    public PzZombieEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(VARIANT, -1);
    }

    // ----- вариант: одежда | тон << 8 | повадки << 16 -----
    public int rawVariant() {
        return this.getDataTracker().get(VARIANT);
    }

    public ZombieOutfit outfit() {
        int v = rawVariant();
        ZombieOutfit[] a = ZombieOutfit.values();
        return v < 0 ? a[0] : a[Math.min(v & 255, a.length - 1)];
    }

    public int tone() {
        int v = rawVariant();
        return v < 0 ? 0 : (v >> 8) & 255;
    }

    public ZombieKind kind() {
        int v = rawVariant();
        ZombieKind[] a = ZombieKind.values();
        return v < 0 ? a[0] : a[Math.min((v >> 16) & 255, a.length - 1)];
    }

    public boolean isCrawler() {
        return this.getDataTracker() != null && kind() == ZombieKind.CRAWLER;
    }

    private int tier;
    /** Повадки, заданные при спавне (особые зомби опасных зон); null — случайные. */
    private ZombieKind forced;

    private void assign() {
        Random r = this.getRandom();
        ZombieKind kind = forced != null ? forced : ZombieKind.pick(r, tier);
        ZombieOutfit outfit = switch (kind) {
            case BRUTE -> ZombieOutfit.bruteOutfit(r);
            case ARMORED -> r.nextFloat() < 0.6f ? ZombieOutfit.RIOT : ZombieOutfit.SOLDIER;
            case CARRIER -> ZombieOutfit.HAZMAT;
            default -> ZombieOutfit.random(r);
        };
        int tone = kind == ZombieKind.FERAL ? 0 : r.nextInt(3);   // ярые — обратились недавно
        this.getDataTracker().set(VARIANT, outfit.ordinal() | (tone << 8) | (kind.ordinal() << 16));
        applyStats();
    }

    /** Характеристики по повадкам, одежде, опасности места и настройкам песочницы. */
    private void applyStats() {
        ZombieKind kind = kind();
        ZombieOutfit outfit = outfit();
        boolean brute = kind == ZombieKind.BRUTE, boss = kind == ZombieKind.CARRIER;
        double hp = (kind.health + outfit.bonusHealth) * (1.0 + 0.1 * tier) * com.example.zomboidmod.sandbox.Sandbox.healthMult();
        setAttr(EntityAttributes.GENERIC_MAX_HEALTH, Math.min(1000.0, hp));
        this.setHealth(this.getMaxHealth());
        setAttr(EntityAttributes.GENERIC_MOVEMENT_SPEED, kind.idleSpeed);
        setAttr(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0 * com.example.zomboidmod.sandbox.Sandbox.senses());   // зрение у мертвецов плохое — их ведёт слух
        double dmg = switch (kind) {   // опасны укусом и толпой, а не силой удара
            case BRUTE -> 7.0;
            case CARRIER -> 10.0;
            case FERAL, ARMORED -> 4.0;
            default -> 3.0;
        };
        setAttr(EntityAttributes.GENERIC_ATTACK_DAMAGE, (dmg + tier * 0.5) * com.example.zomboidmod.sandbox.Sandbox.damageMult());
        setAttr(EntityAttributes.GENERIC_ARMOR, Math.min(30, outfit.armor() + (brute ? 4 : 0) + (kind == ZombieKind.ARMORED ? 6 : 0) + (boss ? 6 : 0)));
        setAttr(EntityAttributes.GENERIC_ARMOR_TOUGHNESS, kind == ZombieKind.ARMORED ? 6 : boss ? 4 : 0);
        setAttr(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, brute ? 0.95 : boss ? 1.0 : kind == ZombieKind.ARMORED ? 0.7
                : kind == ZombieKind.BLOATER ? 0.6 : 0.35);
        setAttr(EntityAttributes.GENERIC_SCALE, brute ? 1.3 : boss ? 1.65 : kind == ZombieKind.BLOATER ? 1.12 : kind == ZombieKind.ARMORED ? 1.05 : 1.0);
        if (kind == ZombieKind.CRAWLER) this.calculateDimensions();
    }

    public boolean isBrute() {
        return kind() == ZombieKind.BRUTE;
    }

    /** Настроить зомби при спавне в здании: одежда по месту (полицейский в участке и т.п.), остальное случайно. */
    public void setup(ZombieOutfit outfit) {
        setup(outfit, 0);
    }

    /** То же с учётом опасности места: возле хорошего лута зомби сильнее. */
    public void setup(ZombieOutfit outfit, int tier) {
        this.tier = Math.max(0, Math.min(3, tier));
        assign();
        this.setCanBreakDoors(true);
        ZombieKind k = kind();
        if (outfit == null || isBrute() || k == ZombieKind.CARRIER
                || (k == ZombieKind.ARMORED && outfit != ZombieOutfit.SOLDIER && outfit != ZombieOutfit.RIOT)) return;
        int v = rawVariant();
        this.getDataTracker().set(VARIANT, (v & ~255) | outfit.ordinal());
        applyStats();
    }

    /** То же, но с заданными повадками (особые зомби опасных зон, поднятые Носителем). */
    public void setupKind(ZombieOutfit outfit, int tier, ZombieKind kind) {
        this.forced = kind;
        setup(outfit, tier);
        this.forced = null;
    }

    // громила рычит ниже
    public float getSoundPitch() {
        ZombieKind k = kind();
        if (k == ZombieKind.CARRIER) return 0.4f + this.getRandom().nextFloat() * 0.08f;
        if (k == ZombieKind.SCREAMER) return 1.25f + this.getRandom().nextFloat() * 0.2f;
        if (k == ZombieKind.BLOATER) return 0.6f + this.getRandom().nextFloat() * 0.1f;
        return isBrute() ? 0.55f + this.getRandom().nextFloat() * 0.1f : 0.9f + this.getRandom().nextFloat() * 0.2f;
    }

    private void setAttr(RegistryEntry<EntityAttribute> attr, double value) {
        EntityAttributeInstance inst = this.getAttributeInstance(attr);
        if (inst != null) inst.setBaseValue(value);
    }

    /** Зомби услышал шум в этой точке. */
    public void hear(BlockPos pos) {
        hear(pos, null);
    }

    /** Шум от игрока: если тот близко и на виду — сразу бросается на него. */
    public void hear(BlockPos pos, net.minecraft.entity.player.PlayerEntity source) {
        this.noisePos = pos.toImmutable();
        this.noiseTicks = 300;
        if (source != null && this.getTarget() == null && !source.isCreative() && !source.isSpectator()
                && this.squaredDistanceTo(source) < 14 * 14 && this.canSee(source)) {
            this.setTarget(source);
        }
    }

    private int lastHit = -100;
    private int unseen;

    /**
     * Как в PZ: мертвец медленный и неуклюжий — тянется, хватает, промахивается. Между укусами пауза,
     * от отходящей назад жертвы часто промахивается.
     */
    @Override
    public boolean tryAttack(net.minecraft.entity.Entity target) {
        ZombieKind kk = kind();
        int cd = kk == ZombieKind.FERAL ? 22 : kk == ZombieKind.CARRIER ? 34 : isBrute() ? 36 : 30;
        if (this.age - lastHit < cd) return false;           // не чаще раза в полторы секунды (ярый — быстрее)
        lastHit = this.age;
        if (target instanceof net.minecraft.entity.player.PlayerEntity pl) {
            double back = pl.getVelocity().horizontalLengthSquared();
            float base = kk == ZombieKind.FERAL || kk == ZombieKind.CARRIER ? 0.08f : 0.2f;
            float miss = base + (back > 0.004 ? 0.2f : 0f) + (isCrawler() ? 0.1f : 0f);
            if (this.getRandom().nextFloat() < miss) {                               // промах: хватает воздух
                this.swingHand(net.minecraft.util.Hand.MAIN_HAND);
                this.playSound(net.minecraft.sound.SoundEvents.ENTITY_PLAYER_ATTACK_WEAK, 0.6f, 0.7f);
                return false;
            }
        }
        boolean ok = super.tryAttack(target);
        if (ok && target instanceof net.minecraft.entity.LivingEntity le) {   // хватает и держит
            le.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 15, kind() == ZombieKind.CRAWLER ? 1 : 0, false, false));
            if (isBrute() || kk == ZombieKind.CARRIER) {   // громила и Носитель отшвыривают
                double rad = Math.toRadians(this.getYaw());
                le.takeKnockback(1.3, Math.sin(rad), -Math.cos(rad));
                le.velocityModified = true;
                this.playSound(net.minecraft.sound.SoundEvents.ENTITY_RAVAGER_ATTACK, 1.0f, 0.8f);
            }
        }
        return ok;
    }

    // ===== выбивание дверей и окон, как в PZ =====
    private static final java.util.Map<Long, Integer> THUMPS = new java.util.HashMap<>();
    private net.minecraft.entity.LivingEntity lastTarget;

    private static int thumpLimit(net.minecraft.block.BlockState st) {
        net.minecraft.block.Block b = st.getBlock();
        if (st.isOf(net.minecraft.block.Blocks.IRON_BARS)) return -1;   // решётки зомби не выбить
        if (b instanceof net.minecraft.block.PaneBlock || b instanceof net.minecraft.block.TransparentBlock) return 3;
        if (b instanceof net.minecraft.block.DoorBlock) return st.isOf(net.minecraft.block.Blocks.IRON_DOOR) ? 40 : 14;
        if (b instanceof net.minecraft.block.TrapdoorBlock) return 9;
        if (b instanceof net.minecraft.block.FenceGateBlock || b instanceof net.minecraft.block.FenceBlock) return 12;
        return -1;
    }

    private void thump() {
        double rad = Math.toRadians(this.getYaw());
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        for (int dy = 0; dy <= 1; dy++) {
            BlockPos pos = BlockPos.ofFloored(this.getX() + fx * 0.9, this.getY() + 0.5 + dy, this.getZ() + fz * 0.9);
            if (bash(pos)) return;
        }
    }

    /** Удар по двери/окну в этой клетке. false — бить тут нечего. */
    public boolean bash(BlockPos pos) {
        if (pos == null) return false;
        net.minecraft.block.BlockState st = this.getWorld().getBlockState(pos);
        // постройки игроков и баррикады: у них своя прочность (как в PZ)
        if (this.getWorld() instanceof net.minecraft.server.world.ServerWorld bw) {
            int r = com.example.zomboidmod.build.Carpentry.zombieHit(bw, pos, st, isBrute() ? 4 : 1);
            if (r >= 0) {
                this.swingHand(net.minecraft.util.Hand.MAIN_HAND);
                this.getWorld().setBlockBreakingInfo(this.getId(), pos, r >= 10 ? -1 : r);
                Noise.emitAt(bw, pos, 14);
                return true;
            }
        }
        int limit = thumpLimit(st);
        if (limit < 0) return false;
        if (st.getBlock() instanceof net.minecraft.block.DoorBlock && st.get(net.minecraft.block.DoorBlock.OPEN)) return false;
        long key = pos.asLong();
        int n = THUMPS.merge(key, isBrute() ? 4 : 1, Integer::sum);   // громила выносит двери в разы быстрее
        this.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        boolean glass = limit <= 3;
        this.getWorld().playSound(null, pos, glass ? net.minecraft.sound.SoundEvents.BLOCK_GLASS_HIT
                        : net.minecraft.sound.SoundEvents.ENTITY_ZOMBIE_ATTACK_WOODEN_DOOR, net.minecraft.sound.SoundCategory.HOSTILE, 1.0f,
                0.8f + this.getRandom().nextFloat() * 0.3f);
        this.getWorld().setBlockBreakingInfo(this.getId(), pos, Math.min(9, n * 10 / limit));
        if (this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) Noise.emitAt(sw, pos, 14);
        if (n >= limit) {
            THUMPS.remove(key);
            this.getWorld().setBlockBreakingInfo(this.getId(), pos, -1);
            this.getWorld().syncWorldEvent(glass ? 2001 : net.minecraft.world.WorldEvents.ZOMBIE_BREAKS_WOODEN_DOOR, pos,
                    glass ? net.minecraft.block.Block.getRawIdFromState(st) : 0);
            this.getWorld().breakBlock(pos, false);
            com.example.zomboidmod.parkour.Parkour.shatter(this.getWorld(), pos, st);   // в раме остаются осколки
        }
        return true;
    }

    // ===== паркур: лезет в окно / через забор =====
    public com.example.zomboidmod.parkour.Parkour.Active climb;
    public BlockPos winGoal;
    public net.minecraft.util.math.Direction winDir;
    public int winUntil;
    public net.minecraft.util.math.Vec3d pushTo;
    public int pushUntil;

    @Override
    public void tick() {
        super.tick();

        if (!this.getWorld().isClient && climb != null) {   // лезет по маршруту — ни ИИ, ни физики
            com.example.zomboidmod.parkour.Parkour.tickZombie(this);
            return;
        }

        if (!this.getWorld().isClient) {
            if (rawVariant() < 0) {
                assign();
                this.setCanBreakDoors(true);
            }
            ZombieKind kind = kind();

            // в тумане видят хуже (как в PZ)
            if (this.age % 40 == 0) {   // днём видят метров на 24, ночью и в тумане — гораздо хуже
                long tod = Math.floorMod(this.getWorld().getTimeOfDay(), 24000L);
                double sight = (tod > 13000 && tod < 23000) ? 14.0 : 24.0;
                sight *= com.example.zomboidmod.sandbox.Sandbox.senses() * (kind == ZombieKind.FERAL ? 1.3 : kind == ZombieKind.CARRIER ? 1.4 : 1.0);
                setAttr(EntityAttributes.GENERIC_FOLLOW_RANGE, sight * (1.0 - 0.5 * com.example.zomboidmod.survival.WorldEvents.fog));
            }
            // потерял жертву из виду — идёт туда, где видел её в последний раз, а потом теряет интерес
            if (this.age % 10 == 3 && this.getTarget() != null) {
                if (this.canSee(this.getTarget())) unseen = 0;
                else if ((unseen += 10) > 160) {
                    noisePos = this.getTarget().getBlockPos();
                    noiseTicks = 200;
                    this.setTarget(null);
                    unseen = 0;
                }
            }
            // в погоне ускоряются; бегун несётся и иногда спотыкается
            if (this.age % 10 == 0) {
                boolean chasing = this.getTarget() != null;
                boolean rage = kind == ZombieKind.CARRIER && this.getHealth() < this.getMaxHealth() * 0.5f;   // раненый Носитель звереет
                setAttr(EntityAttributes.GENERIC_MOVEMENT_SPEED, (chasing ? kind.chaseSpeed : kind.idleSpeed) * (rage ? 1.25 : 1.0));
                if (kind == ZombieKind.SPRINTER && chasing && this.getRandom().nextInt(80) == 0) {
                    this.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 6, false, false));
                }
            }

            // заметив жертву, зовёт остальных (стон слышат в радиусе 18 блоков)
            net.minecraft.entity.LivingEntity tgt = this.getTarget();
            if (tgt != null && tgt != lastTarget && this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) {
                this.playSound(net.minecraft.sound.SoundEvents.ENTITY_ZOMBIE_AMBIENT, 1.5f, 0.7f);
                for (PzZombieEntity o : sw.getEntitiesByClass(PzZombieEntity.class, this.getBoundingBox().expand(12), e -> e != this && e.isAlive())) {
                    o.noisePos = tgt.getBlockPos();
                    o.noiseTicks = 240;
                    if (o.getTarget() == null && o.squaredDistanceTo(tgt) < 16 * 16 && o.canSee(tgt)) o.setTarget(tgt);
                }
            }
            lastTarget = tgt;
            if (kind.special() && this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw2) specialTick(sw2, kind, tgt);

            // упёрся в дверь или окно — колотит, пока не выбьет
            if ((tgt != null || noiseTicks > 0) && this.age % 20 == (this.getId() & 15) && this.horizontalCollision) thump();
            // заборы и окна: переваливается, бьёт стёкла, ищет окно, если к жертве иначе не пройти
            if ((tgt != null || noiseTicks > 0) && this.age % 5 == (this.getId() & 0x7fffffff) % 5)
                com.example.zomboidmod.parkour.Parkour.zombieThink(this, tgt, tgt == null ? noisePos : null);
            if (winGoal != null || pushTo != null) com.example.zomboidmod.parkour.Parkour.steer(this);

            // скрытность: крадущегося игрока замечают только вблизи
            if (this.age % 10 == 0 && this.getTarget() instanceof net.minecraft.server.network.ServerPlayerEntity sp
                    && sp.isSneaking() && this.getAttacker() != sp
                    && this.squaredDistanceTo(sp) > Math.pow(Skills.sneakDetectRange(sp), 2)) {
                this.setTarget(null);
            }
            if (this.age % 10 == 5 && this.getTarget() instanceof net.minecraft.server.network.ServerPlayerEntity sp2
                    && this.getAttacker() != sp2
                    && this.squaredDistanceTo(sp2) > Math.pow(Skills.inconspicuousRange(sp2), 2)) {
                this.setTarget(null);
            }

            // идёт на шум, если жертвы не видно
            if (noiseTicks > 0) {
                noiseTicks--;
                if (this.getTarget() == null && noisePos != null && this.age % 20 == 0) {
                    double nx = noisePos.getX() + 0.5, ny = noisePos.getY(), nz = noisePos.getZ() + 0.5;
                    if (this.squaredDistanceTo(nx, ny, nz) > 4.0) {
                        this.getNavigation().startMovingTo(nx, ny, nz, 1.0);
                    } else {
                        noiseTicks = 0;
                    }
                }
            }
        }

        // ползун ползёт по земле
        if (isCrawler()) this.setPose(EntityPose.SWIMMING);
    }

    @Override
    public EntityDimensions getBaseDimensions(EntityPose pose) {
        if (this.getDataTracker() != null && isCrawler()) return EntityDimensions.changing(0.7f, 0.6f);
        return super.getBaseDimensions(pose);
    }

    // Зомби не горят на солнце (как в PZ). Без @Override: сработает, если такие методы есть у родителя.
    public boolean isAffectedByDaylight() {
        return false;
    }

    public boolean burnsInDaylight() {
        return false;
    }

    public boolean shouldBurnInDay() {
        return false;
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        if (bar != null) bar.clearPlayers();
        if (!this.getWorld().isClient && !lootRolled) {
            lootRolled = true;
            ZombieLoot.drop(this, outfit(), this.getRandom());
            ZombieLoot.special(this, kind(), this.getRandom());
            if (kind() == ZombieKind.BLOATER && this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) burst(sw);
        }
    }

    // ===================== особые зомби =====================
    private net.minecraft.entity.boss.ServerBossBar bar;
    private int screamCd, roarCd = 60, raiseCd = 200, leapCd;

    private void specialTick(net.minecraft.server.world.ServerWorld sw, ZombieKind kind, net.minecraft.entity.LivingEntity tgt) {
        switch (kind) {
            case SCREAMER -> {
                if (screamCd > 0) screamCd--;
                if (tgt != null && screamCd <= 0 && this.canSee(tgt)) scream(sw, tgt);
            }
            case FERAL -> {
                if (leapCd > 0) leapCd--;
                if (tgt != null && leapCd <= 0 && this.isOnGround() && climb == null) {
                    double d2 = this.squaredDistanceTo(tgt);
                    if (d2 < 7 * 7 && d2 > 2.2 * 2.2 && this.canSee(tgt)) {   // бросок в прыжке
                        net.minecraft.util.math.Vec3d d = tgt.getPos().subtract(this.getPos()).multiply(1, 0, 1).normalize();
                        this.setVelocity(d.x * 0.72, 0.36, d.z * 0.72);
                        this.velocityModified = true;
                        this.playSound(net.minecraft.sound.SoundEvents.ENTITY_ZOMBIE_AMBIENT, 1.4f, 1.5f);
                        leapCd = 50 + this.getRandom().nextInt(40);
                    }
                }
            }
            case CARRIER -> carrierTick(sw, tgt);
            default -> {
            }
        }
    }

    /** Крикун: визг слышно далеко — мертвецы со всей округи идут на звук, а ближние сразу бросаются на жертву. */
    private void scream(net.minecraft.server.world.ServerWorld sw, net.minecraft.entity.LivingEntity tgt) {
        screamCd = 170 + this.getRandom().nextInt(90);
        BlockPos at = this.getBlockPos();
        sw.playSound(null, at, net.minecraft.sound.SoundEvents.ENTITY_GHAST_SCREAM, net.minecraft.sound.SoundCategory.HOSTILE, 3.5f, 0.55f + this.getRandom().nextFloat() * 0.1f);
        sw.playSound(null, at, net.minecraft.sound.SoundEvents.ENTITY_FOX_SCREECH, net.minecraft.sound.SoundCategory.HOSTILE, 3.5f, 0.5f);
        sw.spawnParticles(net.minecraft.particle.ParticleTypes.POOF, this.getX(), this.getEyeY(), this.getZ(), 12, 0.3, 0.2, 0.3, 0.05);
        this.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        Noise.emitAt(sw, at, 48);
        for (PzZombieEntity o : sw.getEntitiesByClass(PzZombieEntity.class, this.getBoundingBox().expand(22), e -> e != this && e.isAlive())) {
            if (o.getTarget() == null) o.setTarget(tgt);
        }
        if (tgt instanceof net.minecraft.server.network.ServerPlayerEntity sp) {
            sp.sendMessage(net.minecraft.text.Text.literal("Пронзительный визг! На крик сбегаются мертвецы").formatted(net.minecraft.util.Formatting.RED), true);
            com.example.zomboidmod.survival.Mood m = com.example.zomboidmod.survival.Survival.mood(sp);
            m.panic = Math.min(100f, m.panic + 20f);
        }
    }

    /** Раздутый лопается: облако трупного газа (тошнота, отравление, голод) и брызги гнили. */
    private void burst(net.minecraft.server.world.ServerWorld sw) {
        net.minecraft.entity.AreaEffectCloudEntity c = new net.minecraft.entity.AreaEffectCloudEntity(sw, this.getX(), this.getY() + 0.2, this.getZ());
        c.setRadius(3.4f);
        c.setWaitTime(4);
        c.setDuration(260);
        c.setRadiusGrowth(-3.4f / 520f);
        c.setParticleType(net.minecraft.particle.ParticleTypes.SNEEZE);
        c.addEffect(new StatusEffectInstance(StatusEffects.POISON, 120, 0));
        c.addEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 240, 0));
        c.addEffect(new StatusEffectInstance(StatusEffects.HUNGER, 300, 1));
        sw.spawnEntity(c);
        sw.spawnParticles(new net.minecraft.particle.BlockStateParticleEffect(net.minecraft.particle.ParticleTypes.BLOCK, net.minecraft.block.Blocks.MOSS_BLOCK.getDefaultState()),
                this.getX(), this.getY() + 1.0, this.getZ(), 60, 0.6, 0.5, 0.6, 0.2);
        sw.spawnParticles(new net.minecraft.particle.BlockStateParticleEffect(net.minecraft.particle.ParticleTypes.BLOCK, net.minecraft.block.Blocks.REDSTONE_BLOCK.getDefaultState()),
                this.getX(), this.getY() + 1.0, this.getZ(), 30, 0.5, 0.5, 0.5, 0.2);
        sw.playSound(null, this.getBlockPos(), net.minecraft.sound.SoundEvents.ENTITY_SLIME_SQUISH, net.minecraft.sound.SoundCategory.HOSTILE, 2f, 0.5f);
        sw.playSound(null, this.getBlockPos(), net.minecraft.sound.SoundEvents.ENTITY_PUFFER_FISH_BLOW_UP, net.minecraft.sound.SoundCategory.HOSTILE, 2f, 0.6f);
        Noise.emitAt(sw, this.getBlockPos(), 16);
    }

    /** Носитель — босс: полоса здоровья, рёв (оглушает и отбрасывает), поднимает мертвецов из-под земли. */
    private void carrierTick(net.minecraft.server.world.ServerWorld sw, net.minecraft.entity.LivingEntity tgt) {
        if (bar == null) {
            bar = new net.minecraft.entity.boss.ServerBossBar(net.minecraft.text.Text.literal(ZombieKind.CARRIER.title),
                    net.minecraft.entity.boss.BossBar.Color.RED, net.minecraft.entity.boss.BossBar.Style.NOTCHED_10);
            bar.setDarkenSky(true);
        }
        bar.setPercent(Math.max(0f, this.getHealth() / this.getMaxHealth()));
        boolean rage = this.getHealth() < this.getMaxHealth() * 0.5f;
        if (this.age % 20 == 0) {
            for (net.minecraft.server.network.ServerPlayerEntity p : sw.getPlayers()) {
                double d = this.squaredDistanceTo(p);
                if (p.isAlive() && !p.isSpectator() && d < 48 * 48) bar.addPlayer(p);
                else if (d > 64 * 64 || !p.isAlive()) bar.removePlayer(p);
            }
            if (tgt == null && this.getHealth() < this.getMaxHealth()) this.heal(2f);   // без жертвы затягивает раны
        }
        if (rage && this.age % 8 == 0)
            sw.spawnParticles(net.minecraft.particle.ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + this.getHeight() * 0.8, this.getZ(), 2, 0.3, 0.2, 0.3, 0.01);
        if (tgt == null) return;
        if (roarCd > 0) roarCd--;
        if (raiseCd > 0) raiseCd--;
        if (roarCd <= 0 && this.squaredDistanceTo(tgt) < 18 * 18) {
            roarCd = rage ? 140 : 220;
            sw.playSound(null, this.getBlockPos(), net.minecraft.sound.SoundEvents.ENTITY_RAVAGER_ROAR, net.minecraft.sound.SoundCategory.HOSTILE, 4f, 0.6f);
            Noise.emitAt(sw, this.getBlockPos(), 64);
            for (net.minecraft.server.network.ServerPlayerEntity p : sw.getEntitiesByClass(net.minecraft.server.network.ServerPlayerEntity.class,
                    this.getBoundingBox().expand(10), pl -> pl.isAlive() && !pl.isCreative() && !pl.isSpectator())) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 50, 1, false, true));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 90, 0, false, true));
                net.minecraft.util.math.Vec3d d = p.getPos().subtract(this.getPos()).normalize();
                p.takeKnockback(0.9, -d.x, -d.z);
                p.velocityModified = true;
            }
        }
        if (raiseCd <= 0) {
            raiseCd = rage ? 260 : 400;
            int around = sw.getEntitiesByClass(PzZombieEntity.class, this.getBoundingBox().expand(16), e -> e.isAlive()).size();
            if (around < 14 && com.example.zomboidmod.sandbox.Sandbox.pop() > 0) {
                int n = 2 + this.getRandom().nextInt(2) + (rage ? 1 : 0), made = 0;
                for (int i = 0; i < n; i++) {
                    double a = this.getRandom().nextDouble() * Math.PI * 2, dist = 3 + this.getRandom().nextDouble() * 4;
                    int x = net.minecraft.util.math.MathHelper.floor(this.getX() + Math.cos(a) * dist);
                    int z = net.minecraft.util.math.MathHelper.floor(this.getZ() + Math.sin(a) * dist);
                    int y = sw.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
                    if (Math.abs(y - this.getY()) > 4) continue;
                    PzZombieEntity zb = ZomboidEntities.PZ_ZOMBIE.create(sw);
                    if (zb == null) continue;
                    zb.refreshPositionAndAngles(x + 0.5, y, z + 0.5, this.getRandom().nextFloat() * 360f, 0f);
                    zb.setupKind(null, 2, this.getRandom().nextFloat() < 0.3f ? ZombieKind.FAST_SHAMBLER : ZombieKind.SHAMBLER);
                    zb.setPersistent();
                    sw.spawnEntity(zb);
                    zb.setTarget(tgt);
                    sw.spawnParticles(new net.minecraft.particle.BlockStateParticleEffect(net.minecraft.particle.ParticleTypes.BLOCK,
                            sw.getBlockState(new BlockPos(x, y - 1, z))), x + 0.5, y + 0.1, z + 0.5, 30, 0.3, 0.1, 0.3, 0.1);
                    made++;
                }
                if (made > 0) {
                    sw.playSound(null, this.getBlockPos(), net.minecraft.sound.SoundEvents.ENTITY_WARDEN_EMERGE, net.minecraft.sound.SoundCategory.HOSTILE, 2f, 0.8f);
                    if (tgt instanceof net.minecraft.server.network.ServerPlayerEntity sp)
                        sp.sendMessage(net.minecraft.text.Text.literal("Носитель ревёт — из-под земли лезут мертвецы!").formatted(net.minecraft.util.Formatting.DARK_RED), true);
                }
            }
        }
    }

    @Override
    public void onStoppedTrackingBy(net.minecraft.server.network.ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        if (bar != null) bar.removePlayer(player);
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        if (kind() == ZombieKind.CARRIER) return false;   // босса не убить, сбросив с крыши
        return super.handleFallDamage(fallDistance, damageMultiplier, damageSource);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("PzVariant", rawVariant());
        nbt.putBoolean("PzLootRolled", lootRolled);
        nbt.putInt("PzTier", tier);
        if (climb != null) {   // сохранение посреди перелезания: не оставить зомби замороженным
            nbt.putBoolean("NoAI", false);
            nbt.remove("NoGravity");
        }
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("PzVariant")) this.getDataTracker().set(VARIANT, nbt.getInt("PzVariant"));
        lootRolled = nbt.getBoolean("PzLootRolled");
        tier = nbt.getInt("PzTier");
        if (isCrawler()) this.calculateDimensions();
    }
}
