package com.example.zomboidmod.sandbox;

import com.example.zomboidmod.Skills;
import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.PersistentState;

/**
 * Настройки мира, как «Песочница» в Project Zomboid: сколько зомби и какие они, сколько лута,
 * когда отключат воду и свет, сколько выживших и бандитов, как часто попадаются опасные зоны.
 * Хранятся в мире; меняет их хозяин одиночной игры или оператор сервера (команда /sandbox).
 */
public final class Sandbox {
    private Sandbox() {
    }

    /** Один параметр: ключ, название, подсказка, варианты, вариант по умолчанию. */
    public record Opt(String key, String title, String hint, String[] values, int def) {}

    public static final int POP = 0, SPEED = 1, STRENGTH = 2, TOUGH = 3, SENSES = 4, INFECTION = 5, SPECIAL = 6, LOOT = 7,
            UTILS = 8, SURVIVORS = 9, BANDITS = 10, ZONES = 11;

    public static final Opt[] OPTS = {
            new Opt("pop", "Количество зомби", "Сколько мертвецов в домах, на улицах и в ордах",
                    new String[]{"Нет", "Мало", "Нормально", "Много", "Безумие"}, 2),
            new Opt("speed", "Скорость зомби", "Шатуны бредут, бегуны догоняют бегущего человека",
                    new String[]{"Только шатуны", "Как в PZ", "Больше бегунов", "Все бегуны"}, 1),
            new Opt("strength", "Сила зомби", "Насколько больно бьют и кусают",
                    new String[]{"Слабые", "Обычные", "Сильные", "Беспощадные"}, 1),
            new Opt("tough", "Живучесть зомби", "Сколько ударов выдерживают",
                    new String[]{"Хрупкие", "Обычные", "Крепкие", "Очень крепкие"}, 1),
            new Opt("senses", "Зрение и слух", "Как далеко зомби замечают и слышат",
                    new String[]{"Плохие", "Обычные", "Острые"}, 1),
            new Opt("infection", "Заражение", "Шанс подхватить вирус от царапин и укусов",
                    new String[]{"Нет", "Обычное", "Высокое"}, 1),
            new Opt("special", "Особые зомби", "Крикуны, раздутые, ярые и бронированные среди обычных",
                    new String[]{"Нет", "Редко", "Часто"}, 1),
            new Opt("loot", "Количество лута", "Сколько вещей в шкафах, на полках и в ящиках",
                    new String[]{"Крайне мало", "Мало", "Нормально", "Много", "Изобилие"}, 2),
            new Opt("utils", "Вода и свет", "Когда отключат водопровод и электричество",
                    new String[]{"Сразу", "Через неделю", "Через месяц", "Через полгода", "Никогда"}, 2),
            new Opt("survivors", "Выжившие", "Как часто встречаются другие люди",
                    new String[]{"Нет", "Редко", "Обычно", "Часто"}, 2),
            new Opt("bandits", "Бандиты", "Доля бандитов среди выживших",
                    new String[]{"Нет", "Меньше", "Обычно", "Больше"}, 2),
            new Opt("zones", "Опасные зоны", "Карантинные лагеря и места крушений: элитные зомби и лучший лут",
                    new String[]{"Нет", "Редко", "Обычно", "Часто"}, 2),
    };

    public record Preset(String name, String desc, int[] v) {}

    public static final Preset[] PRESETS = {
            new Preset("Новичок", "Мало медленных и хрупких зомби, без заражения, много лута. Чтобы освоиться.",
                    new int[]{1, 0, 0, 0, 0, 0, 0, 3, 3, 2, 1, 1}),
            new Preset("Выживание", "Как задумано: шатуны с редкими бегунами, заражение, вода и свет — около месяца.",
                    new int[]{2, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2}),
            new Preset("Апокалипсис", "Зомби больше и они крепче, лута меньше, коммуналки отключат через неделю.",
                    new int[]{3, 1, 1, 2, 1, 1, 1, 1, 1, 2, 2, 2}),
            new Preset("Кошмар", "Толпы бегунов, острые чувства, высокое заражение, почти нет лута, света нет с первого дня.",
                    new int[]{4, 2, 2, 2, 2, 2, 2, 0, 0, 3, 3, 3}),
            new Preset("Строитель", "Мало медленных зомби, лута с избытком, вода и свет не отключаются. Для стройки базы.",
                    new int[]{1, 0, 1, 1, 0, 0, 0, 4, 4, 1, 0, 1}),
    };

    public static int[] defaults() {
        int[] v = new int[OPTS.length];
        for (int i = 0; i < v.length; i++) v[i] = OPTS[i].def();
        return v;
    }

    /** Текущие настройки (на сервере — из мира; по умолчанию — «Выживание»). */
    private static int[] cur = defaults();

    public static int get(int opt) {
        return cur[opt];
    }

    /** Название набора, если настройки с ним совпадают, иначе «Свой». */
    public static String presetName(int[] v) {
        for (Preset p : PRESETS) if (java.util.Arrays.equals(p.v(), v)) return p.name();
        return "Свой";
    }

    // ===================== множители для игры =====================
    private static final float[] POP_M = {0f, 0.45f, 1f, 1.6f, 2.5f};
    private static final float[] HIT_M = {0.6f, 1f, 1.5f, 2.2f};
    private static final float[] SENSE_M = {0.7f, 1f, 1.35f};
    private static final float[] INF_M = {0f, 1f, 1.8f};
    private static final float[] SPECIAL_M = {0f, 1f, 3f};
    private static final float[] LOOT_M = {0.3f, 0.6f, 1f, 1.6f, 2.5f};
    private static final float[] SURV_M = {0f, 0.45f, 1f, 2f};
    private static final float[] BANDIT_M = {0f, 0.5f, 1f, 1.7f};
    private static final float[] ZONE_M = {0f, 0.04f, 0.08f, 0.15f};

    /** Множитель количества зомби. */
    public static float pop() {
        return POP_M[cur[POP]];
    }

    /** Сколько зомби поставить вместо одного запланированного (0, 1, 2 или 3) — по количеству зомби. */
    public static int copies(Random r) {
        float p = pop();
        int n = (int) p;
        if (r.nextFloat() < p - n) n++;
        return n;
    }

    public static int copies(java.util.Random r) {
        float p = pop();
        int n = (int) p;
        if (r.nextFloat() < p - n) n++;
        return n;
    }

    /** 0 — только шатуны, 1 — как в PZ, 2 — больше бегунов, 3 — все бегуны. */
    public static int speedMode() {
        return cur[SPEED];
    }

    public static float damageMult() {
        return HIT_M[cur[STRENGTH]];
    }

    public static float healthMult() {
        return HIT_M[cur[TOUGH]];
    }

    /** Множитель зрения и слуха зомби. */
    public static float senses() {
        return SENSE_M[cur[SENSES]];
    }

    /** Множитель шанса заражения (0 — вируса нет). */
    public static float infection() {
        return INF_M[cur[INFECTION]];
    }

    /** Множитель шанса особых зомби среди обычных. */
    public static float special() {
        return SPECIAL_M[cur[SPECIAL]];
    }

    public static float lootMult() {
        return LOOT_M[cur[LOOT]];
    }

    public static float survivorsMult() {
        return SURV_M[cur[SURVIVORS]];
    }

    public static float banditMult() {
        return BANDIT_M[cur[BANDITS]];
    }

    /** Шанс, что регион с фермами или лесом окажется опасной зоной. */
    public static float zoneChance() {
        return ZONE_M[cur[ZONES]];
    }

    // ===================== хранение в мире =====================
    public static final class State extends PersistentState {
        int[] v = defaults();
        boolean configured;

        private static final PersistentState.Type<State> TYPE = new PersistentState.Type<>(State::new, State::fromNbt, null);

        static State get(MinecraftServer server) {
            return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, "zomboidmod_sandbox");
        }

        @Override
        public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
            nbt.putIntArray("v", v);
            nbt.putBoolean("configured", configured);
            return nbt;
        }

        static State fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
            State s = new State();
            s.v = sanitize(nbt.getIntArray("v"));
            s.configured = nbt.getBoolean("configured");
            return s;
        }
    }

    /** Подрезает неверные значения (и дополняет недостающие, если в новой версии появились параметры). */
    static int[] sanitize(int[] in) {
        int[] v = defaults();
        if (in == null) return v;
        for (int i = 0; i < Math.min(in.length, v.length); i++) v[i] = Math.max(0, Math.min(OPTS[i].values().length - 1, in[i]));
        return v;
    }

    // ===================== пакеты =====================
    /** Сервер → клиент: открыть окно настроек. v — значения, edit — можно ли менять, first — первый запуск мира. */
    public record OpenPayload(NbtCompound data) implements CustomPayload {
        public static final CustomPayload.Id<OpenPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "sandbox_open"));
        public static final PacketCodec<RegistryByteBuf, OpenPayload> CODEC = PacketCodec.tuple(PacketCodecs.NBT_COMPOUND, OpenPayload::data, OpenPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Клиент → сервер: новые значения (apply = false — закрыли без изменений). */
    public record ApplyPayload(NbtCompound data) implements CustomPayload {
        public static final CustomPayload.Id<ApplyPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "sandbox_apply"));
        public static final PacketCodec<RegistryByteBuf, ApplyPayload> CODEC = PacketCodec.tuple(PacketCodecs.NBT_COMPOUND, ApplyPayload::data, ApplyPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Может ли игрок менять настройки: хозяин одиночной игры или оператор. */
    public static boolean canEdit(ServerPlayerEntity p) {
        return p.hasPermissionLevel(2) || p.getServer().isHost(p.getGameProfile());
    }

    public static void open(ServerPlayerEntity p, boolean first) {
        NbtCompound n = new NbtCompound();
        n.putIntArray("v", cur.clone());
        n.putBoolean("edit", canEdit(p));
        n.putBoolean("first", first);
        ServerPlayNetworking.send(p, new OpenPayload(n));
    }

    /**
     * При входе: если мир ещё не настроен и игрок может это сделать — показать настройки (выбор профессии — после).
     * true — окно настроек показано.
     */
    public static boolean onJoin(ServerPlayerEntity p) {
        State st = State.get(p.getServer());
        if (st.configured || !canEdit(p)) return false;
        open(p, true);
        return true;
    }

    private static void apply(ServerPlayerEntity p, NbtCompound data) {
        MinecraftServer server = p.getServer();
        State st = State.get(server);
        boolean first = !st.configured;
        if (data.getBoolean("apply") && canEdit(p)) {
            int[] v = sanitize(data.getIntArray("v"));
            boolean utilsChanged = v[UTILS] != cur[UTILS];   // «через месяц» — как было при создании мира
            cur = v;
            st.v = v.clone();
            if (utilsChanged) com.example.zomboidmod.survival.SurvivalState.get(server).setUtilities(v[UTILS], server.getOverworld().getSeed());
            String name = presetName(v);
            server.getPlayerManager().broadcast(Text.literal("Настройки мира: " + name + (first ? "" : " (изменены)")).formatted(Formatting.GOLD), false);
        }
        if (canEdit(p) && !st.configured) st.configured = true;
        st.markDirty();
        if (first) Skills.prompt(p);   // теперь — выбор профессии
    }

    // ===================== регистрация =====================
    public static void register() {
        PayloadTypeRegistry.playS2C().register(OpenPayload.ID, OpenPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ApplyPayload.ID, ApplyPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ApplyPayload.ID, (pl, ctx) -> apply(ctx.player(), pl.data()));
        ServerLifecycleEvents.SERVER_STARTED.register(server -> cur = State.get(server).v.clone());
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> cur = defaults());
        CommandRegistrationCallback.EVENT.register((dispatcher, access, env) ->
                dispatcher.register(CommandManager.literal("sandbox").executes(ctx -> {
                    open(ctx.getSource().getPlayerOrThrow(), false);
                    return 1;
                })));
    }
}
