package com.example.zomboidmod.survivors;

import com.example.zomboidmod.ZomboidMod;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Выживший рисуется как человек (модель игрока) со своим скином; со стволом в бою — целится. */
public class SurvivorRenderer extends BipedEntityRenderer<SurvivorEntity, PlayerEntityModel<SurvivorEntity>> {
    private static final Identifier[] TEX = new Identifier[SurvivorSkins.COUNT];

    static {
        for (int i = 0; i < TEX.length; i++) TEX[i] = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/survivor/survivor_" + i + ".png");
    }

    public SurvivorRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public void render(SurvivorEntity e, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vcp, int light) {
        PlayerEntityModel<SurvivorEntity> m = getModel();
        m.rightArmPose = e.aiming() ? BipedEntityModel.ArmPose.BOW_AND_ARROW
                : (e.getMainHandStack().isEmpty() ? BipedEntityModel.ArmPose.EMPTY : BipedEntityModel.ArmPose.ITEM);
        m.leftArmPose = BipedEntityModel.ArmPose.EMPTY;
        super.render(e, yaw, tickDelta, matrices, vcp, light);
    }

    @Override
    public Identifier getTexture(SurvivorEntity e) {
        return TEX[Math.floorMod(e.skin(), TEX.length)];
    }
}
