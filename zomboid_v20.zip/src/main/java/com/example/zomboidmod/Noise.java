package com.example.zomboidmod;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

/** Шум привлекает зомби: бег, ломание блоков, драка. Крадущийся игрок шумит вдвое тише. */
public final class Noise {
    private Noise() {
    }

    /** Шаги: тише с навыками Лёгкая походка и (когда крадёшься) Скрытность. */
    public static void emitSteps(ServerPlayerEntity p, int radius) {
        double m = Skills.stepNoiseMult(p);
        if (p.isSneaking()) m *= Math.max(0.5, 1.0 - 0.04 * Skills.level(p, PzSkill.SNEAKING));
        emitFrom(p, (int) Math.round(radius * m));
    }

    /** Шум в точке (машина, гудок, удар). */
    public static void emitAt(ServerWorld world, BlockPos pos, int radius) {
        Box box = new Box(pos).expand(radius);
        for (PzZombieEntity z : world.getEntitiesByClass(PzZombieEntity.class, box, e -> e.isAlive())) z.hear(pos);
    }

    public static void emitFrom(ServerPlayerEntity p, int radius) {
        if (!(p.getWorld() instanceof ServerWorld world)) return;
        int r = p.isSneaking() ? radius / 2 : radius;
        BlockPos pos = p.getBlockPos();
        Box box = new Box(pos).expand(r);
        for (PzZombieEntity z : world.getEntitiesByClass(PzZombieEntity.class, box, e -> e.isAlive())) {
            z.hear(pos);
        }
    }
}
