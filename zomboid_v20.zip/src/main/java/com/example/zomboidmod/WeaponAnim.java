package com.example.zomboidmod;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

import java.util.Set;

/**
 * Анимации ударов: тяжёлое оружие (бита, пожарный топор, монтировка) — замах из-за плеча двумя руками и удар наискось;
 * ножи — укол вперёд; лёгкое (молоток, сковорода, мачете, топорик) — короткий рубящий удар сверху.
 */
public final class WeaponAnim {
    private static final Set<String> HEAVY = Set.of("baseball_bat", "spiked_bat", "fire_axe", "crowbar");
    private static final Set<String> STAB = Set.of("kitchen_knife", "hunting_knife");
    private static final Set<String> LIGHT = Set.of("hammer", "frying_pan", "machete", "hand_axe");

    private WeaponAnim() {
    }

    public static String kind(ItemStack st) {
        if (st == null || st.isEmpty()) return null;
        Identifier id = Registries.ITEM.getId(st.getItem());
        if (!id.getNamespace().equals(ZomboidMod.MOD_ID)) return null;
        String p = id.getPath();
        if (HEAVY.contains(p)) return "heavy";
        if (STAB.contains(p)) return "stab";
        if (LIGHT.contains(p)) return "light";
        return null;
    }

    /** Вместо стандартного взмаха от первого лица. При swing = 0 преобразование нулевое. */
    public static void firstPerson(String kind, MatrixStack m, Arm arm, float s) {
        int i = arm == Arm.RIGHT ? 1 : -1;
        switch (kind) {
            case "stab" -> {
                float t = MathHelper.sin(MathHelper.sqrt(s) * MathHelper.PI);
                m.translate(i * -0.05f * t, 0.04f * t, -0.45f * t);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-12f * t));
            }
            case "heavy" -> {
                float up = s < 0.3f ? s / 0.3f : 1f - (s - 0.3f) / 0.7f;
                float hit = s < 0.3f ? 0f : MathHelper.sin((s - 0.3f) / 0.7f * MathHelper.PI);
                m.translate(i * (0.12f * up - 0.32f * hit), 0.22f * up - 0.28f * hit, 0.12f * up - 0.25f * hit);
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * (18f * up - 42f * hit)));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * (22f * up - 55f * hit)));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(38f * up - 100f * hit));
            }
            default -> {
                float f = MathHelper.sin(s * s * MathHelper.PI);
                float g = MathHelper.sin(MathHelper.sqrt(s) * MathHelper.PI);
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * (45f + f * -25f)));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * g * -25f));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -105f));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * -45f));
            }
        }
    }

    /** От третьего лица: тяжёлое оружие держат двумя руками, удар — замах над плечом и рубящее движение. */
    public static void thirdPerson(BipedEntityModel<?> model, LivingEntity e) {
        String k = kind(e.getMainHandStack());
        if (k == null) return;
        boolean right = e.getMainArm() == Arm.RIGHT;
        ModelPart main = right ? model.rightArm : model.leftArm, off = right ? model.leftArm : model.rightArm;
        float side = right ? 1f : -1f;
        float s = model.handSwingProgress;
        if (k.equals("heavy")) {
            if (s > 0f) {
                float up = s < 0.3f ? s / 0.3f : 1f - (s - 0.3f) / 0.7f;
                float hit = s < 0.3f ? 0f : MathHelper.sin((s - 0.3f) / 0.7f * MathHelper.PI);
                main.pitch = -0.9f - 1.9f * up + 1.1f * hit;
                main.yaw = side * (-0.35f + 0.65f * hit);
                main.roll = 0f;
                off.pitch = main.pitch + 0.15f;
                off.yaw = side * (0.6f + 0.35f * hit);
                off.roll = 0f;
                model.body.yaw = side * (0.35f * up - 0.5f * hit);
            } else {
                main.pitch = -0.75f + main.pitch * 0.15f;
                main.yaw = side * -0.2f;
                off.pitch = -0.9f + off.pitch * 0.1f;
                off.yaw = side * 0.6f;
                off.roll = 0f;
            }
        } else if (k.equals("stab") && s > 0f) {
            float t = MathHelper.sin(s * MathHelper.PI);
            main.pitch = -0.3f - 1.25f * t;
            main.yaw = side * -0.12f * t;
        }
    }
}
