package com.example.zomboidmod.mixin;

import com.example.zomboidmod.survival.Survival;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Днём уставший персонаж спит, пока не выспится (в ванилле днём сразу будят). */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;isDay()Z"))
    private boolean zomboid$daySleep(World world) {
        return world.isDay() && !Survival.keepSleeping((PlayerEntity) (Object) this);
    }

    /** Без правой руки всё делает левая (и наоборот): ведущая рука — та, что осталась. */
    @Inject(method = "getMainArm", at = @At("RETURN"), cancellable = true)
    private void zomboid$remainingArm(org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<net.minecraft.util.Arm> cir) {
        int lost = com.example.zomboidmod.amputation.Amputation.lostBits((PlayerEntity) (Object) this) & 3;
        if (lost == 2) cir.setReturnValue(net.minecraft.util.Arm.LEFT);
        else if (lost == 1) cir.setReturnValue(net.minecraft.util.Arm.RIGHT);
    }

    /** Паркур: в окне — ползком, после падения — лёжа, на заборе — стоя (не приседать). */
    @Inject(method = "updatePose", at = @At("HEAD"), cancellable = true)
    private void zomboid$parkourPose(CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        net.minecraft.entity.EntityPose pose = com.example.zomboidmod.parkour.Parkour.forcedPose(self);
        if (pose == null) pose = com.example.zomboidmod.motion.Knockdown.forcedPose(self);   // сбит с ног — лежит
        if (pose != null) {
            self.setPose(pose);
            ci.cancel();
        }
    }
}
