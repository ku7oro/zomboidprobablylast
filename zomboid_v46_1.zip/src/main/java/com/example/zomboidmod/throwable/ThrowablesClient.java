package com.example.zomboidmod.throwable;

import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;

/** Летящая самоделка рисуется как предмет. */
public final class ThrowablesClient {
    private ThrowablesClient() {
    }

    public static void init() {
        EntityRendererRegistry.register(Throwables.DEVICE, FlyingItemEntityRenderer::new);
    }
}
