package com.example.zomboidmod.throwable;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.media.Knowledge;
import com.example.zomboidmod.vehicle.GasCanItem;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Самоделки и приманки (как в PZ): коктейль Молотова, самодельная бомба, дымовая шашка,
 * будильник и шумовая приманка (уводят орду), петарды.
 */
public final class Throwables {
    private Throwables() {
    }

    public enum Kind {MOLOTOV, PIPE_BOMB, SMOKE, ALARM_CLOCK, NOISE_MAKER, FIRECRACKERS}

    public static Item MOLOTOV, PIPE_BOMB, SMOKE_BOMB, ALARM_CLOCK, NOISE_MAKER, FIRECRACKERS;
    public static EntityType<ThrownDeviceEntity> DEVICE;
    public static SoundEvent ALARM_SOUND, NOISE_SOUND, FIRECRACKER_SOUND;
    public static final List<Item> ITEMS = new ArrayList<>();

    private static Item reg(String id, Item item) {
        Item it = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
        ITEMS.add(it);
        return it;
    }

    private static SoundEvent sound(String id) {
        Identifier i = Identifier.of(ZomboidMod.MOD_ID, id);
        return Registry.register(Registries.SOUND_EVENT, i, SoundEvent.of(i));
    }

    public static void register() {
        ALARM_SOUND = sound("alarm_clock");
        NOISE_SOUND = sound("noise_maker");
        FIRECRACKER_SOUND = sound("firecracker");
        DEVICE = Registry.register(Registries.ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, "thrown_device"),
                EntityType.Builder.<ThrownDeviceEntity>create(ThrownDeviceEntity::new, SpawnGroup.MISC).dimensions(0.25f, 0.25f)
                        .maxTrackingRange(6).trackingTickInterval(5).build("thrown_device"));
        MOLOTOV = reg("molotov", new Device(new Item.Settings().maxCount(4), Kind.MOLOTOV,
                "Бросок (ПКМ): море огня в 2 блоках. Осторожно — дома горят!"));
        PIPE_BOMB = reg("pipe_bomb", new Device(new Item.Settings().maxCount(4), Kind.PIPE_BOMB,
                "Бросок (ПКМ): взрыв при ударе. Слышно на полгорода"));
        SMOKE_BOMB = reg("smoke_bomb", new Device(new Item.Settings().maxCount(8), Kind.SMOKE,
                "Бросок (ПКМ): густой дым на 20 с — зомби теряют вас из виду"));
        ALARM_CLOCK = reg("alarm_clock", new Device(new Item.Settings().maxCount(1), Kind.ALARM_CLOCK,
                "Бросок (ПКМ): звенит 15 с и уводит зомби. Потом его можно подобрать"));
        NOISE_MAKER = reg("noise_maker", new Device(new Item.Settings().maxDamage(5), Kind.NOISE_MAKER,
                "Бросок (ПКМ): пищит 20 с, слышно очень далеко. Батареи на 5 раз"));
        FIRECRACKERS = reg("firecrackers", new Device(new Item.Settings().maxCount(16), Kind.FIRECRACKERS,
                "Бросок (ПКМ): треск на 6 с — орда сбегается на шум"));
        Knowledge.gate(PIPE_BOMB, "engineer", null, 0);
        Knowledge.gate(SMOKE_BOMB, "engineer", null, 0);
        Knowledge.gate(NOISE_MAKER, "engineer", PzSkill.METALWORKING, 4);
        // коктейль Молотова: в канистре должно быть хотя бы пол-литра
        Knowledge.rule((p, in, out) -> {
            if (!out.isOf(MOLOTOV)) return null;
            for (int i = 0; i < in.size(); i++) {
                ItemStack s = in.getStack(i);
                if (s.getItem() instanceof GasCanItem && GasCanItem.liters(s) < 0.5f) return "В канистре нет бензина";
            }
            return null;
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> ITEMS.forEach(e::add));
        ServerTickEvents.END_SERVER_TICK.register(Throwables::tick);
    }

    /** Бросаемая вещь. */
    public static class Device extends Item {
        final Kind kind;
        final String hint;

        Device(Settings s, Kind kind, String hint) {
            super(s);
            this.kind = kind;
            this.hint = hint;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(hint).formatted(Formatting.GRAY));
        }

        @Override
        public boolean isEnchantable(ItemStack stack) {
            return false;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            world.playSound(null, user.getX(), user.getY(), user.getZ(),
                    kind == Kind.MOLOTOV ? SoundEvents.ITEM_FIRECHARGE_USE : SoundEvents.ENTITY_SNOWBALL_THROW,
                    SoundCategory.PLAYERS, 0.6f, 0.5f / (world.getRandom().nextFloat() * 0.4f + 0.8f));
            if (!world.isClient) {
                ThrownDeviceEntity e = new ThrownDeviceEntity(world, user);
                ItemStack one = st.copyWithCount(1);
                e.setItem(one);
                float speed = kind == Kind.MOLOTOV || kind == Kind.PIPE_BOMB ? 1.0f : 0.9f;
                e.setVelocity(user, user.getPitch(), user.getYaw(), 0f, speed, 1.0f);
                world.spawnEntity(e);
                if (kind == Kind.MOLOTOV && user instanceof net.minecraft.server.network.ServerPlayerEntity sp)
                    sp.sendMessage(Text.literal("Фитиль горит!").formatted(Formatting.GOLD), true);
            }
            user.getItemCooldownManager().set(this, 12);
            st.decrementUnlessCreative(1, user);
            return TypedActionResult.success(st, world.isClient());
        }
    }

    // =====================================================================================
    //                                   дымовая завеса
    // =====================================================================================

    private record Smoke(ServerWorld w, Vec3d pos, int[] left) {}

    private static final List<Smoke> SMOKES = new ArrayList<>();
    static final double SMOKE_R = 4.5;

    static void smoke(ServerWorld w, Vec3d pos) {
        SMOKES.add(new Smoke(w, pos, new int[]{400}));
        w.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 1.2f, 0.6f);
    }

    /** Кто-то из двоих в дыму (зомби или его жертва) — не видно. */
    public static boolean smoked(Vec3d a, Vec3d b) {
        if (SMOKES.isEmpty()) return false;
        double r2 = SMOKE_R * SMOKE_R;
        for (Smoke s : SMOKES) if (s.pos().squaredDistanceTo(a) < r2 || s.pos().squaredDistanceTo(b) < r2) return true;
        return false;
    }

    private static void tick(MinecraftServer server) {
        if (SMOKES.isEmpty()) return;
        for (Iterator<Smoke> it = SMOKES.iterator(); it.hasNext(); ) {
            Smoke s = it.next();
            int left = --s.left()[0];
            if (left <= 0 || s.w().getServer() != server) {
                it.remove();
                continue;
            }
            if (left % 2 == 0) {
                float k = Math.min(1f, left / 100f);   // к концу дым редеет
                int n = Math.max(2, Math.round(10 * k));
                s.w().spawnParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, s.pos().x, s.pos().y + 0.6, s.pos().z, n, 1.8 * k + 0.4, 0.8, 1.8 * k + 0.4, 0.01);
                if (left > 340) s.w().spawnParticles(ParticleTypes.LARGE_SMOKE, s.pos().x, s.pos().y + 0.2, s.pos().z, 6, 0.3, 0.2, 0.3, 0.05);
            }
            if (left % 40 == 0) s.w().playSound(null, s.pos().x, s.pos().y, s.pos().z, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.3f, 0.5f);
        }
    }
}
