package com.example.zomboidmod.motion;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * «Живое тело» на клиенте: настройки (сохраняются), приём состояния тела и падений, тики анимаций и камеры.
 * Команда /realism — что включено; /realism camera|body|falls|inertia on|off; /realism bob 0..2; /realism all on|off.
 */
public final class MotionClient {
    private MotionClient() {
    }

    private static boolean camera = true, body = true, falls = true, inertia = true;
    private static float bob = 1f;
    private static Path file;

    public static boolean camera() {
        return camera;
    }

    public static boolean body() {
        return body;
    }

    public static boolean falls() {
        return falls;
    }

    public static boolean inertia() {
        return inertia;
    }

    public static float bobScale() {
        return bob;
    }

    public static void init() {
        load();
        ClientPlayNetworking.registerGlobalReceiver(BodySync.StatePayload.ID, (pl, ctx) -> ctx.client().execute(() -> BodyAnim.FLAGS.put(pl.entity(), pl.flags())));
        ClientPlayNetworking.registerGlobalReceiver(Knockdown.DownPayload.ID, (pl, ctx) -> ctx.client().execute(() -> {
            Knockdown.CLIENT.put(pl.entity(), new Knockdown.Down(pl.start(), pl.len(), pl.face()));
            if (ctx.client().player != null && pl.entity() == ctx.client().player.getId()) ctx.client().player.setSprinting(false);
        }));
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> {
            Knockdown.CLIENT.clear();
            BodyAnim.FLAGS.clear();
            BodyAnim.STATE.clear();
        });
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            if (c.world == null) return;
            BodyAnim.tick(c);
            CameraFx.tick(c);
            long now = c.world.getTime();
            Knockdown.CLIENT.values().removeIf(d -> d.over(now) || now < d.start() - 100);
        });
        ClientCommandRegistrationCallback.EVENT.register((d, access) -> d.register(ClientCommandManager.literal("realism")
                .executes(ctx -> {
                    status();
                    return 1;
                })
                .then(ClientCommandManager.literal("bob").then(ClientCommandManager.argument("value", FloatArgumentType.floatArg(0f, 2f)).executes(ctx -> {
                    bob = FloatArgumentType.getFloat(ctx, "value");
                    save();
                    status();
                    return 1;
                })))
                .then(ClientCommandManager.argument("what", StringArgumentType.word())
                        .then(ClientCommandManager.argument("state", StringArgumentType.word()).executes(ctx -> {
                            String what = StringArgumentType.getString(ctx, "what"), st = StringArgumentType.getString(ctx, "state");
                            boolean on = st.equals("on") || st.equals("вкл");
                            switch (what) {
                                case "camera" -> camera = on;
                                case "body" -> body = on;
                                case "falls" -> falls = on;
                                case "inertia" -> inertia = on;
                                case "all" -> camera = body = falls = inertia = on;
                                default -> {
                                    msg("Не знаю «" + what + "». Можно: camera, body, falls, inertia, all", Formatting.RED);
                                    return 0;
                                }
                            }
                            save();
                            status();
                            return 1;
                        })))));
    }

    private static void status() {
        msg("Реализм: камера " + onOff(camera) + ", тело " + onOff(body) + ", падения " + onOff(falls) + ", инерция " + onOff(inertia)
                + ", покачивание ×" + String.format("%.1f", bob), Formatting.GRAY);
        msg("Менять: /realism camera|body|falls|inertia|all on|off, /realism bob 0..2", Formatting.DARK_GRAY);
    }

    private static String onOff(boolean b) {
        return b ? "вкл" : "выкл";
    }

    private static void msg(String s, Formatting f) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) c.player.sendMessage(Text.literal(s).formatted(f), false);
    }

    private static void load() {
        try {
            file = FabricLoader.getInstance().getConfigDir().resolve("zomboidmod_realism.properties");
            if (!Files.exists(file)) return;
            Properties p = new Properties();
            try (Reader r = Files.newBufferedReader(file)) {
                p.load(r);
            }
            camera = !"false".equals(p.getProperty("camera"));
            body = !"false".equals(p.getProperty("body"));
            falls = !"false".equals(p.getProperty("falls"));
            inertia = !"false".equals(p.getProperty("inertia"));
            bob = Float.parseFloat(p.getProperty("bob", "1"));
        } catch (Throwable ignored) {
        }
    }

    private static void save() {
        try {
            if (file == null) return;
            Properties p = new Properties();
            p.setProperty("camera", String.valueOf(camera));
            p.setProperty("body", String.valueOf(body));
            p.setProperty("falls", String.valueOf(falls));
            p.setProperty("inertia", String.valueOf(inertia));
            p.setProperty("bob", String.valueOf(bob));
            try (Writer w = Files.newBufferedWriter(file)) {
                p.store(w, "Zomboid mod: realism settings");
            }
        } catch (Throwable ignored) {
        }
    }
}
