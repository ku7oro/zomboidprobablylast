package com.example.zomboidmod.motion;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.ZomboidClient;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.SurvivalClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Камера от первого лица, как у живого человека:
 * шаги — мягкое покачивание (глубже с грузом, без сил и на больной ноге, где каждый второй шаг проседает);
 * поворот — голова чуть кренится и догоняет взгляд; шаг вбок — лёгкий наклон;
 * приземление — камера проседает и пружинит; удар — встряска; одышка — дыхание видно;
 * сбитый с ног — мир заваливается набок, при подъёме выравнивается.
 * В прицеле руки дрожат от усталости, страха и ран (прицел гуляет по-настоящему, а не только картинка).
 */
public final class CameraFx {
    private CameraFx() {
    }

    // сглаженные величины (обновляются раз в тик)
    private static float yawVel, yawVelPrev, side, sidePrev, breath, breathPrev, breathRate = 0.08f;
    private static float landY, landYPrev, landV, landP, landPPrev;
    private static float shake, shakePrev, shakeSeedR, shakeSeedP;
    private static float prevYaw;
    private static boolean wasGround = true;
    private static float lastVy;
    private static int lastHurt;
    private static float limpDip, limpDipPrev;

    static void tick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null) return;
        // поворот головы
        float dy = MathHelper.wrapDegrees(p.getYaw() - prevYaw);
        prevYaw = p.getYaw();
        yawVelPrev = yawVel;
        yawVel += (MathHelper.clamp(dy, -30f, 30f) - yawVel) * 0.35f;
        // шаг вбок
        float yr = p.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        double vx = p.getVelocity().x, vz = p.getVelocity().z;
        float s = (float) (vx * MathHelper.cos(yr) + vz * MathHelper.sin(yr));
        sidePrev = side;
        side += (s - side) * 0.25f;
        // дыхание
        int ex = Mood.exertion(SurvivalClient.endurance);
        float want = 0.07f + ex * 0.05f + (p.isSprinting() ? 0.05f : 0f);
        breathRate += (want - breathRate) * 0.05f;
        breathPrev = breath;
        breath += breathRate;
        // приземление: пружина
        boolean ground = p.isOnGround();
        if (ground && !wasGround && lastVy < -0.25f) {
            float power = Math.min(1.4f, (-lastVy - 0.2f) * 1.6f);
            landV -= 0.09f * power;
            landP += 2.8f * power;
        }
        wasGround = ground;
        lastVy = (float) p.getVelocity().y;
        landYPrev = landY;
        landPPrev = landP;
        landV += -landY * 0.32f;                 // пружина возвращает
        landV *= 0.62f;                          // и гасится
        landY += landV;
        landP *= 0.78f;
        // удар: встряска
        if (p.hurtTime > 0 && p.hurtTime == p.maxHurtTime && lastHurt != p.age) {
            lastHurt = p.age;
            shake = Math.min(1.2f, shake + 0.8f);
            shakeSeedR = p.getRandom().nextFloat() * 6.28f;
            shakeSeedP = p.getRandom().nextFloat() * 6.28f;
        }
        shakePrev = shake;
        shake *= 0.8f;
        limpDipPrev = limpDip;
    }

    /** Покачивание при ходьбе вместо ванильного. true — ванильное не нужно. */
    public static boolean bob(MatrixStack m, float td) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (!MotionClient.camera() || !(c.getCameraEntity() instanceof PlayerEntity p)) return false;
        float g = p.horizontalSpeed - p.prevHorizontalSpeed;
        float h = -(p.horizontalSpeed + g * td);
        float i = MathHelper.lerp(td, p.prevStrideDistance, p.strideDistance);
        int f = BodyAnim.FLAGS.getOrDefault(p.getId(), 0);
        int ex = BodySync.exertion(f), load = BodySync.load(f);
        float amp = MotionClient.bobScale() * (0.62f + 0.12f * load + 0.12f * ex + (p.isSprinting() ? 0.15f : 0f));
        float sx = MathHelper.sin(h * MathHelper.PI), cx = MathHelper.cos(h * MathHelper.PI);
        // шаг: голова уходит вниз на каждом шаге (|cos|), вбок — в сторону опорной ноги
        float down = Math.abs(cx) * i;
        // больная нога: шаг на неё проседает сильнее и с креном
        boolean limpL = (f & BodySync.LIMP_L) != 0, limpR = (f & BodySync.LIMP_R) != 0;
        float limp = 0f;
        if (limpL ^ limpR) {
            boolean bad = (f & (limpL ? BodySync.LIMP_L_BAD : BodySync.LIMP_R_BAD)) != 0;
            float onHurt = limpL ? Math.max(0f, sx) : Math.max(0f, -sx);   // фаза шага на больную ногу
            limp = onHurt * i * (bad ? 1.6f : 0.9f);
        }
        m.translate(sx * i * 0.32f * amp, -(down * amp + limp * 0.55f), 0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sx * i * 2.2f * amp + (limpL ? -1f : 1f) * limp * 4f));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(Math.abs(MathHelper.cos(h * MathHelper.PI - 0.2f) * i) * 3.4f * amp + limp * 2f));
        return true;
    }

    /** Всё остальное (из tiltViewWhenHurt — вызывается всегда, и для мира, и для рук). */
    public static void apply(MatrixStack m, float td) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (!MotionClient.camera() || c.player == null || c.getCameraEntity() != c.player || !c.options.getPerspective().isFirstPerson()) return;
        ClientPlayerEntity p = c.player;
        float roll = 0f, pitch = 0f, yaw = 0f;
        float y = 0f;
        // крен на поворотах и при шаге вбок
        float yv = MathHelper.lerp(td, yawVelPrev, yawVel);
        float moving = Math.min(1f, (float) p.getVelocity().horizontalLength() / 0.2f);
        roll += MathHelper.clamp(yv * 0.07f, -2.2f, 2.2f) * (0.35f + 0.65f * moving);
        roll += MathHelper.clamp(MathHelper.lerp(td, sidePrev, side) * 9f, -1.6f, 1.6f);
        // дыхание (сильнее, когда запыхался)
        int ex = Mood.exertion(SurvivalClient.endurance);
        float b = MathHelper.lerp(td, breathPrev, breath);
        float bAmp = 0.12f + 0.32f * ex + (p.isSprinting() ? 0.2f : 0f);
        pitch += MathHelper.sin(b) * bAmp;
        y += MathHelper.sin(b) * 0.006f * bAmp;
        // опьянение: мир плывёт
        if (Mood.drunk(SurvivalClient.drunk) >= 2) {
            float t = (p.age + td) * 0.05f;
            roll += MathHelper.sin(t) * 1.6f * (Mood.drunk(SurvivalClient.drunk) - 1);
            yaw += MathHelper.sin(t * 0.7f) * 0.8f;
        }
        // приземление
        y += MathHelper.lerp(td, landYPrev, landY);
        pitch += MathHelper.lerp(td, landPPrev, landP);
        // удар
        float sh = MathHelper.lerp(td, shakePrev, shake);
        if (sh > 0.01f) {
            float t = (p.age + td) * 2.1f;
            roll += MathHelper.sin(t + shakeSeedR) * 2.4f * sh;
            pitch += MathHelper.sin(t * 1.3f + shakeSeedP) * 1.6f * sh;
            yaw += MathHelper.cos(t * 0.9f) * 1.0f * sh;
        }
        // сбит с ног: мир заваливается набок, при подъёме — выравнивается
        Knockdown.Down d = Knockdown.CLIENT.get(p.getId());
        if (d != null && !d.over(p.getWorld().getTime())) {
            float el = d.elapsed(p.getWorld().getTime(), td);
            float k;
            if (el < 6f) k = el / 6f;
            else if (el < d.len()) k = 1f;
            else k = 1f - FallAnim.smooth((el - d.len()) / Knockdown.GETUP);
            float side = d.face() ? 1f : -1f;
            float impact = el < 10f ? MathHelper.sin(el / 10f * MathHelper.PI) : 0f;
            roll += (17f * side + 4f * impact) * k;
            pitch += (d.face() ? 12f : -14f) * k + 6f * impact;
            y -= 0.05f * impact;
        }
        if (y != 0f) m.translate(0f, y, 0f);
        if (roll != 0f) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(roll));
        if (pitch != 0f) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
        if (yaw != 0f) m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
    }

    // =====================================================================================
    //                       дрожь прицела (настоящая: меняет направление взгляда)
    // =====================================================================================
    private static long swayLast = -1;
    private static float swayT, swayX, swayY;

    /** Каждый кадр (из Mouse.updateMouse): плавно уводит прицел по «восьмёрке». */
    public static void aimSway() {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        long now = System.nanoTime();
        if (swayLast < 0) swayLast = now;
        float dt = Math.min(0.1f, (now - swayLast) / 1e9f);
        swayLast = now;
        if (p == null || !MotionClient.camera() || c.isPaused() || c.currentScreen != null || !p.isUsingItem()
                || !(p.getActiveItem().getItem() instanceof com.example.zomboidmod.gun.GunItem)) {
            swayX = swayY = 0f;
            return;
        }
        int f = BodyAnim.FLAGS.getOrDefault(p.getId(), 0);
        int ex = Mood.exertion(SurvivalClient.endurance), panic = Mood.panic(SurvivalClient.panic);
        float a = 0.18f + 0.22f * ex + 0.15f * panic + ((f & (BodySync.ARM_L | BodySync.ARM_R)) != 0 ? 0.35f : 0f)
                + ((f & BodySync.PAIN) != 0 ? 0.2f : 0f) + (Mood.drunk(SurvivalClient.drunk) >= 2 ? 0.4f : 0f);
        a *= 1f - 0.06f * ZomboidClient.skillLevel(PzSkill.AIMING);
        if (p.isSneaking()) a *= 0.45f;                           // присел — упор, руки твёрже
        a = Math.max(0.03f, a);
        swayT += dt * (0.55f + 0.25f * ex);
        float nx = MathHelper.sin(swayT * 1.1f) * a + MathHelper.sin(swayT * 2.9f) * a * 0.25f;
        float ny = MathHelper.sin(swayT * 2.2f) * a * 0.55f + MathHelper.cos(swayT * 3.7f) * a * 0.15f;
        float dx = nx - swayX, dyy = ny - swayY;
        swayX = nx;
        swayY = ny;
        // changeLookDirection умножает на 0.15
        p.changeLookDirection(dx / 0.15f, dyy / 0.15f);
    }
}
