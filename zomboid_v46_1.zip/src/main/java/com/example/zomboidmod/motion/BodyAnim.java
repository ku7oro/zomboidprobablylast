package com.example.zomboidmod.motion;

import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.survivors.SurvivorEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;

/**
 * Живое тело от третьего лица (своё и чужое): корпус наклоняется при разгоне и на бегу, кренится на поворотах,
 * плечи следуют за взглядом; грудь и плечи дышат (чаще после бега); стоя — переносит вес с ноги на ногу.
 * Раненая нога — хромота, раненая рука прижата к телу, кровящий живот зажимают ладонью, без сил — сутулится и
 * упирается руками в колени, на холоде обнимает себя и дрожит, пьяного качает, с грузом — гнётся вперёд.
 * Приземление — присед; сбитый с ног лежит и, поднимаясь, опирается на руки.
 */
public final class BodyAnim {
    private BodyAnim() {
    }

    /** Что нужно знать о движении каждого: считается раз в тик по позициям (у чужих скорость не приходит). */
    static final class St {
        double px, py, pz;
        float prevBodyYaw;
        float fwd, side, accel, turn;        // сглаженные: скорость вперёд/вбок (блоков за тик), ускорение, поворот (градусов за тик)
        float fwdPrev;
        boolean ground = true;
        float vy, landPower;
        int landAge = 99, idle;
        float breath, breathRate = 0.09f;
        boolean init;
    }

    static final Map<Integer, St> STATE = new HashMap<>();
    /** Состояние тела от сервера (BodySync): по id сущности. */
    public static final Map<Integer, Integer> FLAGS = new HashMap<>();

    static St st(Entity e) {
        return STATE.computeIfAbsent(e.getId(), k -> new St());
    }

    /** Раз в тик (клиент): обновить всех людей и выживших поблизости. */
    static void tick(MinecraftClient c) {
        if (c.world == null || c.player == null) {
            STATE.clear();
            FLAGS.clear();
            return;
        }
        World w = c.world;
        java.util.Set<Integer> seen = new java.util.HashSet<>();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof PlayerEntity || e instanceof SurvivorEntity) || e.squaredDistanceTo(c.player) > 64 * 64) continue;
            LivingEntity le = (LivingEntity) e;
            seen.add(e.getId());
            St s = st(e);
            if (!s.init) {
                s.px = e.getX();
                s.py = e.getY();
                s.pz = e.getZ();
                s.prevBodyYaw = le.bodyYaw;
                s.init = true;
            }
            double dx = e.getX() - s.px, dy = e.getY() - s.py, dz = e.getZ() - s.pz;
            s.px = e.getX();
            s.py = e.getY();
            s.pz = e.getZ();
            float yaw = le.bodyYaw * MathHelper.RADIANS_PER_DEGREE;
            float fx = -MathHelper.sin(yaw), fz = MathHelper.cos(yaw);
            float fwd = (float) (dx * fx + dz * fz), side = (float) (dx * fz - dz * fx);
            if (Math.abs(fwd) > 1.2f) fwd = 0f;                // телепорт
            s.fwdPrev = s.fwd;
            s.fwd += (fwd - s.fwd) * 0.35f;
            s.side += (side - s.side) * 0.35f;
            s.accel += ((s.fwd - s.fwdPrev) - s.accel) * 0.3f;
            float turn = MathHelper.wrapDegrees(le.bodyYaw - s.prevBodyYaw);
            s.prevBodyYaw = le.bodyYaw;
            s.turn += (MathHelper.clamp(turn, -40f, 40f) - s.turn) * 0.3f;
            boolean ground = e.isOnGround();
            if (ground && !s.ground && s.vy < -0.3f) {
                s.landPower = Math.min(1f, -s.vy * 1.3f);
                s.landAge = 0;
            } else if (s.landAge < 99) s.landAge++;
            s.ground = ground;
            s.vy = (float) dy;
            boolean still = Math.abs(s.fwd) < 0.01f && Math.abs(s.side) < 0.01f;
            s.idle = still ? s.idle + 1 : 0;
            int f = FLAGS.getOrDefault(e.getId(), 0);
            int ex = BodySync.exertion(f);
            float want = 0.085f + ex * 0.06f + (e.isSprinting() ? 0.06f : 0f);
            s.breathRate += (want - s.breathRate) * 0.05f;
            s.breath += s.breathRate;
        }
        STATE.keySet().retainAll(seen);
        if (w.getTime() % 200 == 0) FLAGS.keySet().retainAll(seen);
    }

    // =====================================================================================
    //                                      поза
    // =====================================================================================

    /** Из BipedEntityModel.setAngles (в конце), до поз оружия и паркура. */
    public static void apply(BipedEntityModel<?> m, LivingEntity e, float limbAngle, float limbDistance, float age) {
        if (e instanceof PzZombieEntity) return;
        boolean player = e instanceof PlayerEntity;
        if (!player && !(e instanceof SurvivorEntity)) return;
        // модель общая для всех игроков: то, что игра сама не сбрасывает, — сбрасываем
        m.head.roll = 0f;
        m.body.roll = 0f;
        if (age == 0f || !MotionClient.body()) return;          // рука от первого лица (renderArm) — не трогаем
        float td = MathHelper.clamp(age - e.age, 0f, 1f);
        // мёртвый выживший падает
        if (e.deathTime > 0) {
            if (e instanceof SurvivorEntity && MotionClient.falls()) {
                boolean face = com.example.zomboidmod.life.BodyEntity.survivorFace(e.getUuid());
                FallAnim.blendToBody(m, FallAnim.fall(e.deathTime - 1 + td), com.example.zomboidmod.life.BodyEntity.fallPose(e.getUuid(), face),
                        e.getUuid().getLeastSignificantBits(), false);
            }
            return;
        }
        if (e.hasVehicle() || e.isSleeping() || e.isFallFlying() || e.isTouchingWater() || com.example.zomboidmod.parkour.ParkourClient.climbing(e)) return;
        // сбит с ног
        if (player) {
            Knockdown.Down d = Knockdown.CLIENT.get(e.getId());
            if (d != null && !d.over(e.getWorld().getTime())) {
                knocked(m, e, d, td, age);
                return;
            }
        }
        if (e.isInPose(EntityPose.SWIMMING)) return;
        St s = STATE.get(e.getId());
        if (s == null) return;
        int f = FLAGS.getOrDefault(e.getId(), 0);
        int ex = BodySync.exertion(f), load = BodySync.load(f);
        boolean sneak = e.isInSneakingPose();
        boolean emptyMain = e.getMainHandStack().isEmpty(), emptyOff = e.getOffHandStack().isEmpty();
        boolean rightMain = e.getMainArm() == Arm.RIGHT;
        boolean emptyR = rightMain ? emptyMain : emptyOff, emptyL = rightMain ? emptyOff : emptyMain;
        boolean busy = m.handSwingProgress > 0f || e.isUsingItem();
        float t = age + e.getId() * 13.7f;
        float spd = Math.min(1f, Math.abs(s.fwd) / 0.28f);
        boolean idle = s.idle > 30 && limbDistance < 0.05f;

        // ---------------- корпус: разгон, бег, груз, усталость
        float lean = 0f;
        if (!sneak) {
            if (e.isSprinting()) lean += 0.17f;
            lean += MathHelper.clamp(s.accel * 4.5f, -0.12f, 0.18f);
            lean += load * 0.045f;
            if (ex >= 2) lean += 0.07f * (ex - 1);
            if (idle && ex >= 3) lean += 0.38f;                 // упёрся руками в колени, отдышаться
        }
        // приземление: присел, наклонился
        float land = s.landAge < 10 ? s.landPower * (float) Math.exp(-(s.landAge + td) / 2.6f) : 0f;
        lean += land * 0.35f;

        // ---------------- дыхание
        float br = MathHelper.sin(s.breath + s.breathRate * td);
        float bAmp = 0.35f + ex * 0.35f + (e.isSprinting() ? 0.3f : 0f);

        // ---------------- крен: на повороте и вбок, опьянение, перенос веса стоя
        float bank = MathHelper.clamp(-s.turn * 0.006f * (0.25f + spd), -0.18f, 0.18f) + MathHelper.clamp(s.side * 0.9f, -0.08f, 0.08f);
        if ((f & BodySync.DRUNK) != 0) bank += 0.07f * MathHelper.sin(t * 0.06f) + 0.03f * MathHelper.sin(t * 0.17f);
        float shift = idle ? MathHelper.sin(t * 0.03f) : 0f;
        bank += shift * 0.035f;

        // ---------------- хромота
        boolean limpL = (f & BodySync.LIMP_L) != 0, limpR = (f & BodySync.LIMP_R) != 0;
        float limpAmt = 0f;
        float c = MathHelper.cos(limbAngle * 0.6662f);
        if ((limpL || limpR) && limbDistance > 0.05f && !(limpL && limpR)) {
            boolean bad = (f & (limpL ? BodySync.LIMP_L_BAD : BodySync.LIMP_R_BAD)) != 0;
            boolean splint = (f & (limpL ? BodySync.SPLINT_L : BodySync.SPLINT_R)) != 0;
            ModelPart hurt = limpL ? m.leftLeg : m.rightLeg;
            float k = bad ? 0.3f : 0.55f;
            hurt.pitch *= k;                                     // больная нога шагает коротко
            if (splint) hurt.roll = limpL ? -0.16f * Math.abs(c) * limbDistance : 0.16f * Math.abs(c) * limbDistance;   // в шине — обносит ногу дугой
            // опираясь на больную ногу, тело проседает в её сторону
            float stance = limpL ? Math.max(0f, c) : Math.max(0f, -c);
            limpAmt = stance * Math.min(1f, limbDistance * 2f) * (bad ? 1f : 0.6f);
            bank += (limpL ? 0.13f : -0.13f) * limpAmt;
            lean += 0.06f * limpAmt;
        } else if (limpL && limpR && limbDistance > 0.05f) {    // обе ноги — семенит
            m.leftLeg.pitch *= 0.5f;
            m.rightLeg.pitch *= 0.5f;
            lean += 0.08f;
        }

        // ---------------- применяем корпус
        leanBody(m, lean, sneak);
        m.body.roll = bank;
        m.head.roll = -bank * 0.55f;
        m.head.pitch -= lean * 0.7f;                             // голова держит взгляд, когда корпус наклонён
        m.head.pitch -= 0.025f * br * bAmp;
        // плечи следуют за взглядом
        if (!busy) {
            float twist = MathHelper.clamp(m.head.yaw * 0.22f, -0.28f, 0.28f);
            twistBody(m, twist);
        }

        // ---------------- руки: дыхание и мелкие движения
        m.rightArm.pivotY -= 0.35f * br * bAmp;
        m.leftArm.pivotY -= 0.35f * br * bAmp;
        if (emptyR && !busy) m.rightArm.roll += 0.035f * br * bAmp + 0.04f;
        if (emptyL && !busy) m.leftArm.roll -= 0.035f * br * bAmp + 0.04f;
        if (idle && !busy) {
            float sway = MathHelper.sin(t * 0.045f) * 0.04f;
            if (emptyR) m.rightArm.pitch += sway;
            if (emptyL) m.leftArm.pitch -= sway;
            // вес на одну ногу: другая чуть согнута и отставлена
            ModelPart relax = shift > 0 ? m.rightLeg : m.leftLeg;
            relax.pitch -= 0.09f * Math.abs(shift);
            relax.roll += (shift > 0 ? 0.03f : -0.03f) * Math.abs(shift);
        }
        // упёрся в колени
        if (idle && ex >= 3 && !sneak && !busy) {
            if (emptyR) {
                m.rightArm.pitch = -0.55f + 0.05f * br;
                m.rightArm.roll = 0.12f;
                m.rightArm.yaw = 0f;
            }
            if (emptyL) {
                m.leftArm.pitch = -0.55f + 0.05f * br;
                m.leftArm.roll = -0.12f;
                m.leftArm.yaw = 0f;
            }
        }
        // холодно: обнял себя и дрожит
        if ((f & BodySync.COLD) != 0 && emptyR && emptyL && !busy && limbDistance < 0.3f) {
            float shiver = 0.03f * MathHelper.sin(t * 2.9f);
            m.rightArm.pitch = -1.05f + shiver;
            m.rightArm.yaw = -0.72f;
            m.rightArm.roll = 0.15f;
            m.leftArm.pitch = -0.95f - shiver;
            m.leftArm.yaw = 0.72f;
            m.leftArm.roll = -0.15f;
            m.body.roll += shiver * 0.4f;
        }
        // кровит живот — свободной рукой зажимает рану
        if ((f & BodySync.TORSO) != 0 && !busy) {
            if (emptyL) pressWound(m.leftArm, 1f, t);
            else if (emptyR) pressWound(m.rightArm, -1f, t);
        }
        // раненая рука прижата к телу (если в ней ничего нет), иначе — движется скупо
        if ((f & BodySync.ARM_R) != 0) hurtArm(m.rightArm, -1f, emptyR && !busy, t);
        if ((f & BodySync.ARM_L) != 0) hurtArm(m.leftArm, 1f, emptyL && !busy, t);
        // приземление: руки в стороны для равновесия
        if (land > 0.05f && !busy) {
            if (emptyR) m.rightArm.roll += 0.35f * land;
            if (emptyL) m.leftArm.roll -= 0.35f * land;
        }
        m.hat.copyTransform(m.head);
    }

    private static void pressWound(ModelPart arm, float side, float t) {
        arm.pitch = -0.62f + 0.03f * MathHelper.sin(t * 0.2f);
        arm.yaw = 0.62f * side;
        arm.roll = 0f;
    }

    private static void hurtArm(ModelPart arm, float side, boolean free, float t) {
        if (free) {
            arm.pitch = -0.75f + 0.03f * MathHelper.sin(t * 0.1f);
            arm.yaw = 0.48f * side;
            arm.roll = 0.12f * -side;
        } else {
            arm.pitch *= 0.5f;
        }
    }

    /** Наклон корпуса вокруг шеи: бёдра (ноги) уходят назад, как у WeaponAnim. */
    static void leanBody(BipedEntityModel<?> m, float lean, boolean sneak) {
        if (lean == 0f) return;
        float base = m.body.pitch;
        float total = base + lean;
        m.body.pitch = total;
        float dz = 12f * (MathHelper.sin(total) - MathHelper.sin(base)), dy = 12f * (MathHelper.cos(total) - MathHelper.cos(base));
        m.rightLeg.pivotZ += dz;
        m.leftLeg.pivotZ += dz;
        m.rightLeg.pivotY += dy;
        m.leftLeg.pivotY += dy;
    }

    /** Поворот плеч: руки уезжают вместе с корпусом. */
    static void twistBody(BipedEntityModel<?> m, float by) {
        if (by == 0f) return;
        m.body.yaw += by;
        float sx = MathHelper.cos(m.body.yaw) * 5f, sz = MathHelper.sin(m.body.yaw) * 5f;
        m.rightArm.pivotX = -sx;
        m.rightArm.pivotZ = sz;
        m.leftArm.pivotX = sx;
        m.leftArm.pivotZ = -sz;
        m.rightArm.yaw += by;
        m.leftArm.yaw += by;
    }

    /** Сбит с ног: лежит (поза ползком), отталкивается руками; поднимаясь — опирается на колено и встаёт. */
    private static void knocked(BipedEntityModel<?> m, LivingEntity e, Knockdown.Down d, float td, float age) {
        float el = d.elapsed(e.getWorld().getTime(), td);
        if (el < d.len()) {
            if (!e.isInPose(EntityPose.SWIMMING)) return;
            // лежит: руки упираются в землю, ноги вытянуты
            float push = el > d.len() - 10 ? (el - (d.len() - 10)) / 10f : 0f;
            float w = MathHelper.sin(age * 0.3f) * 0.15f * (1f - push);
            m.rightArm.pitch = MathHelper.PI * 0.9f - push * 1.2f + w;
            m.leftArm.pitch = MathHelper.PI * 0.9f - push * 1.2f - w;
            m.rightArm.yaw = -0.3f;
            m.leftArm.yaw = 0.3f;
            m.rightArm.roll = 0.15f;
            m.leftArm.roll = -0.15f;
            m.rightLeg.pitch = 0.1f;
            m.leftLeg.pitch = -0.05f;
            m.rightLeg.roll = 0.1f;
            m.leftLeg.roll = -0.12f;
            m.hat.copyTransform(m.head);
            return;
        }
        // встаёт: глубокий присед и наклон, руки упираются в колени, плавно выпрямляется
        float u = (el - d.len()) / Knockdown.GETUP;
        float g = 1f - FallAnim.smooth(u);
        m.body.pitch = 0.75f * g;
        m.body.pivotY = 5f * g;
        m.head.pivotY = 5.5f * g;
        m.head.pitch -= 0.5f * g;
        m.rightArm.pivotY = 2f + 6f * g;
        m.leftArm.pivotY = 2f + 6f * g;
        m.rightArm.pitch = -0.7f * g;
        m.leftArm.pitch = -0.6f * g;
        m.rightLeg.pivotZ = 0.1f + 5f * g;
        m.leftLeg.pivotZ = 0.1f + 5f * g;
        m.rightLeg.pivotY = 12f + 0.3f * g;
        m.leftLeg.pivotY = 12f + 0.3f * g;
        m.rightLeg.pitch = -0.9f * g;
        m.leftLeg.pitch = 0.2f * g;
        m.body.roll = 0f;
        m.head.roll = 0f;
        m.hat.copyTransform(m.head);
    }
}
