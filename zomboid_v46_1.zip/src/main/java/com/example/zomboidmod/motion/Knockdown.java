package com.example.zomboidmod.motion;

import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.Weight;
import com.example.zomboidmod.ZombieKind;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.Survival;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Падения: человека может повалить мертвец (особенно сзади), он может споткнуться на бегу с грузом, без сил или пьяным,
 * упасть с высоты или от взрыва. Лежащий не дерётся и не бежит — встаёт через пару секунд, а мертвецы тем временем рядом.
 * С разбега можно сбить мертвеца с ног; лежачего зомби бьют сильнее.
 */
public final class Knockdown {
    private Knockdown() {
    }

    /** Сколько тиков встаёт человек после падения. */
    public static final int GETUP = 16;
    /** Сколько тиков встаёт мертвец. */
    public static final int Z_GETUP = 22;

    /** Падение: когда (время мира), сколько лежать, ничком ли. */
    public record Down(long start, int len, boolean face) {
        public float elapsed(long now, float td) {
            return now - start + td;
        }

        public boolean lying(long now) {
            return now - start < len;
        }

        public boolean over(long now) {
            return now - start >= len + GETUP;
        }
    }

    public record DownPayload(int entity, long start, int len, boolean face) implements CustomPayload {
        public static final CustomPayload.Id<DownPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "knockdown"));
        public static final PacketCodec<RegistryByteBuf, DownPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, DownPayload::entity, PacketCodecs.VAR_LONG, DownPayload::start, PacketCodecs.VAR_INT, DownPayload::len,
                PacketCodecs.BOOL, DownPayload::face, DownPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Лежащие люди: на сервере (по UUID) и на клиенте (по id сущности). */
    private static final Map<UUID, Down> SERVER = new HashMap<>();
    public static final Map<Integer, Down> CLIENT = new HashMap<>();
    private static final Map<UUID, Integer> SHOVE_CD = new HashMap<>();

    public static void register() {
        PayloadTypeRegistry.playS2C().register(DownPayload.ID, DownPayload.CODEC);
        ServerTickEvents.END_SERVER_TICK.register(Knockdown::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((h, s) -> {
            SERVER.remove(h.player.getUuid());
            SHOVE_CD.remove(h.player.getUuid());
        });
        // лёжа не подраться и ничего не взять
        AttackEntityCallback.EVENT.register((p, w, hand, e, hit) -> down(p) ? ActionResult.FAIL : ActionResult.PASS);
        UseBlockCallback.EVENT.register((p, w, hand, hit) -> down(p) ? ActionResult.FAIL : ActionResult.PASS);
        UseItemCallback.EVENT.register((p, w, hand) -> down(p) ? TypedActionResult.fail(p.getStackInHand(hand)) : TypedActionResult.pass(p.getStackInHand(hand)));
        // жёсткое приземление с высоты валит с ног
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayerEntity p && source.isIn(DamageTypeTags.IS_FALL) && amount >= 4f)
                p.getServer().execute(() -> {
                    if (p.isAlive()) knock(p, p.getRandom().nextBoolean(), 34, "Тяжело упали — перехватило дыхание");
                });
            return true;
        });
    }

    /** Лежит ли человек (на сервере или на клиенте). */
    public static boolean down(PlayerEntity p) {
        Down d = p.getWorld().isClient ? CLIENT.get(p.getId()) : SERVER.get(p.getUuid());
        return d != null && d.lying(p.getWorld().getTime());
    }

    /** Поза: лёжа — ползком (низкая камера и хитбокс), пока встаёт — уже стоя. */
    public static EntityPose forcedPose(PlayerEntity p) {
        return down(p) ? EntityPose.SWIMMING : null;
    }

    public static Down state(PlayerEntity p) {
        return p.getWorld().isClient ? CLIENT.get(p.getId()) : SERVER.get(p.getUuid());
    }

    /** Повалить человека. faceDown — ничком (толкнули в спину), иначе — навзничь. */
    public static boolean knock(ServerPlayerEntity p, boolean faceDown, int len, String why) {
        if (p.isCreative() || p.isSpectator() || p.hasVehicle() || p.isSleeping() || p.getAbilities().flying || p.isTouchingWater()
                || p.isClimbing() || com.example.zomboidmod.parkour.Parkour.climbing(p)) return false;
        long now = p.getWorld().getTime();
        Down old = SERVER.get(p.getUuid());
        if (old != null && !old.over(now)) return false;
        Down d = new Down(now, len, faceDown);
        SERVER.put(p.getUuid(), d);
        p.setSprinting(false);
        p.stopUsingItem();
        send(p, d);
        p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_BIG_FALL, SoundCategory.PLAYERS, 0.9f, 0.8f);
        p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_GRAVEL_FALL, SoundCategory.PLAYERS, 0.5f, 0.6f);
        if (why != null) p.sendMessage(Text.literal(why).formatted(Formatting.RED), true);
        Survival.mood(p).panic = Math.min(100f, Survival.mood(p).panic + 12f);
        return true;
    }

    private static void send(ServerPlayerEntity p, Down d) {
        DownPayload pl = new DownPayload(p.getId(), d.start(), d.len(), d.face());
        ServerPlayNetworking.send(p, pl);
        for (ServerPlayerEntity o : PlayerLookup.tracking(p)) if (o != p) ServerPlayNetworking.send(o, pl);
    }

    // =====================================================================================
    //                                        причины
    // =====================================================================================

    /** Мертвец ударил: может повалить — особенно сзади, громила, ярый, или когда вокруг толпа. */
    public static void onZombieHit(ServerPlayerEntity p, PzZombieEntity z) {
        Vec3d look = p.getRotationVector().multiply(1, 0, 1).normalize();
        Vec3d toZ = z.getPos().subtract(p.getPos()).multiply(1, 0, 1).normalize();
        boolean behind = look.dotProduct(toZ) < -0.35;
        ZombieKind k = z.kind();
        float c = 0.03f;
        if (behind) c += 0.22f;
        if (k == ZombieKind.FERAL) c += 0.12f;
        if (z.isBrute() || k == ZombieKind.CARRIER) c += 0.3f;
        Mood m = Survival.mood(p);
        int ex = Mood.exertion(m.endurance);
        if (ex >= 3) c += 0.08f;
        if (Weight.level(Weight.carried(p) / Weight.capacity(Skills.level(p, PzSkill.STRENGTH))) >= 3) c += 0.08f;
        int crowd = p.getWorld().getEntitiesByClass(PzZombieEntity.class, p.getBoundingBox().expand(2.5), PzZombieEntity::isAlive).size();
        if (crowd >= 3) c += 0.12f + 0.04f * (crowd - 3);
        c *= 1f - 0.04f * Skills.level(p, PzSkill.FITNESS);
        if (p.getRandom().nextFloat() < c)
            knock(p, behind, 36 + p.getRandom().nextInt(16), behind ? "Мертвец навалился сзади — вы упали!" : "Мертвец сбил вас с ног!");
    }

    /** Взрыв рядом: людей и мертвецов разбрасывает. */
    public static void blast(ServerWorld w, Vec3d at, double r) {
        Box box = new Box(at, at).expand(r);
        for (ServerPlayerEntity p : w.getEntitiesByClass(ServerPlayerEntity.class, box, LivingEntity::isAlive)) {
            Vec3d away = p.getPos().subtract(at);
            boolean face = away.horizontalLengthSquared() > 0.01 && p.getRotationVector().dotProduct(away.normalize()) > 0;
            knock(p, face, 40, "Взрывной волной вас сбило с ног");
        }
        for (PzZombieEntity z : w.getEntitiesByClass(PzZombieEntity.class, box, LivingEntity::isAlive)) z.knockDown(50 + w.random.nextInt(30), z.fallsFaceDown(at));
    }

    private static void tick(MinecraftServer server) {
        long now = server.getOverworld().getTime();
        List<UUID> done = new ArrayList<>();
        for (Map.Entry<UUID, Down> en : SERVER.entrySet()) {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
            Down d = en.getValue();
            if (p == null || !p.isAlive()) {
                done.add(en.getKey());
                continue;
            }
            now = p.getWorld().getTime();
            if (d.over(now)) {
                done.add(en.getKey());
                continue;
            }
            if (d.lying(now)) {
                p.setSprinting(false);
                Vec3d v = p.getVelocity();
                if (v.horizontalLengthSquared() > 0.0004) {
                    p.setVelocity(v.x * 0.2, v.y, v.z * 0.2);
                    p.velocityModified = true;
                }
            }
        }
        done.forEach(SERVER::remove);
        if (server.getTicks() % 2 == 0) for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (!p.isAlive() || p.isCreative() || p.isSpectator() || !p.isSprinting() || down(p)) continue;
            shove(p);
            if (server.getTicks() % 10 == 0) trip(p);
        }
        SHOVE_CD.entrySet().removeIf(e -> e.getValue() <= server.getTicks());
    }

    /** Споткнуться на бегу: груз, одышка, хмель, больная нога, кусты под ногами. */
    private static void trip(ServerPlayerEntity p) {
        if (!p.isOnGround()) return;
        Mood m = Survival.mood(p);
        int load = Weight.level(Weight.carried(p) / Weight.capacity(Skills.level(p, PzSkill.STRENGTH)));
        int ex = Mood.exertion(m.endurance), dr = Mood.drunk(m.drunk);
        int flags = BodySync.compute(p);
        float c = 0f;
        if (load >= 2) c += 0.008f * (load - 1);
        if (ex >= 2) c += 0.006f * (ex - 1);
        if (dr >= 2) c += 0.012f * (dr - 1);
        if ((flags & (BodySync.LIMP_L_BAD | BodySync.LIMP_R_BAD)) != 0) c += 0.02f;
        BlockState feet = p.getWorld().getBlockState(p.getBlockPos());
        if (feet.isIn(BlockTags.REPLACEABLE_BY_TREES) || feet.isIn(BlockTags.LEAVES) || feet.isIn(BlockTags.FLOWERS)) c += 0.004f;
        if (c <= 0f) return;
        c *= 1f - 0.06f * Skills.level(p, PzSkill.SPRINTING);
        if (p.getRandom().nextFloat() < c) {
            knock(p, true, 26 + p.getRandom().nextInt(10), "Вы споткнулись на бегу!");
            p.damage(p.getDamageSources().generic(), 0.5f);
        }
    }

    /** С разбега — в мертвеца: сбить с ног (или отлететь самому, если это громила). */
    private static void shove(ServerPlayerEntity p) {
        if (SHOVE_CD.containsKey(p.getUuid())) return;
        Vec3d v = p.getVelocity().multiply(1, 0, 1);
        if (v.lengthSquared() < 0.03) return;
        Vec3d dir = v.normalize();
        Box zone = p.getBoundingBox().offset(dir.multiply(0.55)).expand(0.15, 0, 0.15);
        World w = p.getWorld();
        for (PzZombieEntity z : w.getEntitiesByClass(PzZombieEntity.class, zone, e -> e.isAlive() && !e.isDown() && !e.isCrawler())) {
            SHOVE_CD.put(p.getUuid(), p.getServer().getTicks() + 20);
            Mood m = Survival.mood(p);
            m.endurance = Math.max(0f, m.endurance - 0.06f);
            p.setSprinting(false);
            w.playSound(null, z.getX(), z.getY(), z.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, SoundCategory.PLAYERS, 1f, 0.7f);
            boolean heavy = z.isBrute() || z.kind() == ZombieKind.CARRIER || z.kind() == ZombieKind.ARMORED;
            float chance = 0.55f + 0.05f * Skills.level(p, PzSkill.STRENGTH);
            if (!heavy && p.getRandom().nextFloat() < chance) {
                z.knockDown(45 + p.getRandom().nextInt(30), z.fallsFaceDown(p.getPos()));
                z.setVelocity(dir.x * 0.45, 0.12, dir.z * 0.45);
                z.velocityModified = true;
                p.setVelocity(v.multiply(0.3));
                p.velocityModified = true;
                Skills.addXp(p, PzSkill.STRENGTH, 1f);
                p.sendMessage(Text.literal("Сбили мертвеца с ног!").formatted(Formatting.GREEN), true);
            } else {
                p.setVelocity(dir.multiply(-0.35).add(0, 0.1, 0));
                p.velocityModified = true;
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20, 1, false, false));
                if (heavy && p.getRandom().nextFloat() < 0.4f) knock(p, false, 30, "Отлетели от него, как от стены");
                else p.sendMessage(Text.literal("Не удалось сбить — он устоял").formatted(Formatting.GOLD), true);
            }
            return;
        }
    }
}
