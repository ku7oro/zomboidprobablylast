package com.example.zomboidmod.motion;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Падение тела как у настоящего: валится, разгоняясь (как падающий столб, вокруг ступней), ударяется о землю
 * и чуть подскакивает; ноги при этом проскальзывают. Конечная поза совпадает с лежащим телом (BodyRenderer),
 * поэтому, когда мёртвый зомби сменяется телом, ничего не дёргается.
 */
public final class FallAnim {
    private FallAnim() {
    }

    /** Тиков на само падение. */
    public static final float FALL = 11f;

    /** 0 — стоит, 1 — лежит. t — тиков с начала падения. */
    public static float fall(float t) {
        if (t <= 0f) return 0f;
        if (t < FALL) {
            float x = t / FALL;
            return x * x * (0.55f + 0.45f * x);         // медленно начинает, быстро валится
        }
        float b = t - FALL;
        if (b < 6f) return 1f - 0.075f * MathHelper.sin(b / 6f * MathHelper.PI);   // удар и отскок
        return 1f;
    }

    /** Подъём: сначала на четвереньки/на руки (до ~0.5), потом встаёт. u — доля подъёма 0..1. */
    public static float getUp(float u) {
        u = MathHelper.clamp(u, 0f, 1f);
        if (u < 0.45f) return 1f - 0.42f * smooth(u / 0.45f);
        return 0.58f * (1f - smooth((u - 0.45f) / 0.55f));
    }

    /** Сбит с ног: падает, лежит, поднимается. */
    public static float knock(float elapsed, int len, int getup) {
        if (elapsed < 0f) return 0f;
        if (elapsed < len) return fall(elapsed);
        return getUp((elapsed - len) / getup);
    }

    public static float smooth(float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    /** Поворот модели (после поворота по рысканью): ничком — вперёд, навзничь — назад; wide — ширина (раздутые). */
    public static void apply(MatrixStack m, float k, boolean faceDown, float wide) {
        if (k <= 0f) return;
        float len = 0.92f, lift = 0.2f * wide;
        m.translate(0f, lift * k, (faceDown ? len : -len) * k);
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees((faceDown ? -90f : 90f) * k));
    }

    // ---------------------------------------------------------------- плавный переход частей тела к позе лёжа
    private static final float[] TMP = new float[6 * 9];

    private static void save(ModelPart p, float[] a, int i) {
        a[i] = p.pitch;
        a[i + 1] = p.yaw;
        a[i + 2] = p.roll;
        a[i + 3] = p.pivotX;
        a[i + 4] = p.pivotY;
        a[i + 5] = p.pivotZ;
    }

    private static void mix(ModelPart p, float[] a, int i, float k) {
        p.pitch = MathHelper.lerp(k, a[i], p.pitch);
        p.yaw = MathHelper.lerp(k, a[i + 1], p.yaw);
        p.roll = MathHelper.lerp(k, a[i + 2], p.roll);
        p.pivotX = MathHelper.lerp(k, a[i + 3], p.pivotX);
        p.pivotY = MathHelper.lerp(k, a[i + 4], p.pivotY);
        p.pivotZ = MathHelper.lerp(k, a[i + 5], p.pivotZ);
    }

    /** Руки и ноги — от текущей позы к позе лежащего тела (pose 0..3, как у BodyEntity). */
    public static void blendToBody(BipedEntityModel<?> m, float k, int pose, long seed, boolean noLegs) {
        if (k <= 0f) return;
        float kk = MathHelper.clamp(k, 0f, 1f);
        ModelPart[] parts = {m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg};
        for (int i = 0; i < parts.length; i++) save(parts[i], TMP, i * 6);
        com.example.zomboidmod.life.BodyRenderer.pose(m, pose, seed, noLegs);   // выставляет позу лёжа
        // руки взлетают при падении (рефлекс), потом опадают в позу
        float flail = MathHelper.sin(MathHelper.clamp(kk * 1.25f, 0f, 1f) * MathHelper.PI) * (1f - kk);
        for (int i = 0; i < parts.length; i++) mix(parts[i], TMP, i * 6, kk);
        m.rightArm.pitch -= flail * 1.4f;
        m.leftArm.pitch -= flail * 1.2f;
        m.rightArm.roll += flail * 0.5f;
        m.leftArm.roll -= flail * 0.5f;
        m.hat.copyTransform(m.head);
    }
}
