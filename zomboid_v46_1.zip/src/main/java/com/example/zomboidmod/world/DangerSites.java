package com.example.zomboidmod.world;

import com.example.zomboidmod.ZombieKind;
import com.example.zomboidmod.ZombieOutfit;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.LanternBlock;
import net.minecraft.util.math.Direction;

/**
 * Опасные зоны — самые трудные места округа: павший карантинный лагерь с боссом (Носитель)
 * и место крушения военного вертолёта. Тут особые зомби (бронированные, крикуны, раздутые, ярые)
 * и элитный лут: пулемёт, броня, редкие тома книг, экспериментальная сыворотка.
 */
final class DangerSites {
    private DangerSites() {
    }

    private static final BlockState AIR = Blocks.AIR.getDefaultState();

    // =====================================================================================
    //                                  общее
    // =====================================================================================

    /** Особый зомби в точке (если клетка свободна). */
    private static void special(Plan g, int x, int y, int z, ZombieOutfit o, ZombieKind k) {
        if (g.get(x, y, z) != null && !g.get(x, y, z).isAir()) return;
        g.zombie(x, y, z, o, 3, k);
    }

    /** n особых зомби в прямоугольнике. */
    private static void specials(Plan g, int x1, int z1, int x2, int z2, int n, ZombieOutfit o, ZombieKind k) {
        for (int i = 0; i < n * 3 && n > 0; i++) {
            int x = x1 + g.r.nextInt(Math.max(1, x2 - x1)), z = z1 + g.r.nextInt(Math.max(1, z2 - z1));
            if (g.get(x, 1, z) != null) continue;
            g.zombie(x, 1, z, o, 3, k);
            n--;
        }
    }

    /** Пролом в ограде с отступом inset: лагерь пал. */
    private static void breach(Plan g, int inset) {
        int side = g.r.nextInt(4), len = (side < 2 ? g.w : g.d) - 2 * inset - 8;
        int t = inset + 4 + g.r.nextInt(Math.max(1, len));
        for (int k = 0; k < 2 + g.r.nextInt(2); k++)
            for (int y = 1; y <= 5; y++) {
                int x = switch (side) {
                    case 0 -> t + k;
                    case 1 -> t + k;
                    case 2 -> inset;
                    default -> g.w - 1 - inset;
                };
                int z = switch (side) {
                    case 0 -> inset;
                    case 1 -> g.d - 1 - inset;
                    default -> t + k;
                };
                g.set(x, y, z, AIR);
            }
    }

    /** Кровь на земле. */
    private static void blood(Plan g, int x1, int z1, int x2, int z2, int n) {
        for (int i = 0; i < n; i++) {
            int x = x1 + g.r.nextInt(Math.max(1, x2 - x1)), z = z1 + g.r.nextInt(Math.max(1, z2 - z1));
            if (g.get(x, 1, z) == null) g.set(x, 1, z, Landmarks.decal(g, com.example.zomboidmod.block.ZomboidBlocks.BLOOD));
        }
    }

    /** Большая палатка: стены и двускатная крыша из ткани, входы с торцов, фонари под крышей. */
    private static void bigTent(Plan g, int x1, int z1, int x2, int z2, Block cloth) {
        BlockState c = cloth.getDefaultState();
        int mz = (z1 + z2) / 2;
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                boolean edge = x == x1 || x == x2 || z == z1 || z == z2;
                for (int y = 1; y <= 3; y++) g.set(x, y, z, edge ? c : AIR);
                int dz = Math.abs(z - mz), half = (z2 - z1) / 2;
                g.set(x, 4, z, dz >= half - 2 || x == x1 || x == x2 ? c : AIR);
                g.set(x, 5, z, dz < half - 2 ? c : AIR);
                if (dz <= 1) g.set(x, 6, z, c);
            }
        for (int z = mz - 1; z <= mz + 1; z++) {   // входы с торцов
            g.set(x1, 1, z, AIR);
            g.set(x1, 2, z, AIR);
            g.set(x2, 1, z, AIR);
            g.set(x2, 2, z, AIR);
        }
        for (int x = x1 + 3; x < x2; x += 6) g.set(x, 4, mz, Blocks.LANTERN.getDefaultState().with(LanternBlock.HANGING, true));
    }

    /** Сигнальный костёр: столб дыма виден за сотни блоков. */
    private static void fire(Plan g, int x, int y, int z) {
        g.set(x, y, z, Blocks.CAMPFIRE.getDefaultState().with(CampfireBlock.LIT, true).with(CampfireBlock.SIGNAL_FIRE, true));
        g.set(x, y - 1, z, Blocks.HAY_BLOCK.getDefaultState());
    }

    // =====================================================================================
    //                               КАРАНТИННАЯ ЗОНА
    // =====================================================================================

    static void quarantine(Plan g, Landmarks.Site s) {
        int W = g.w, D = g.d, cx = W / 2, cz = D / 2;
        g.danger = 3;
        Wild.ground(g, 0, 0, W - 1, D - 1, Blocks.GRASS_BLOCK, Blocks.COARSE_DIRT, 0.35f);
        Landmarks.asphalt(g, cx - 3, 0, cx + 3, D - 1);
        Landmarks.asphalt(g, 11, cz - 2, W - 12, cz + 2);
        // двойное ограждение: сетка с колючкой и кольцо бетонных блоков; в обоих — проломы
        BlockState post = Landmarks.bb("concrete_dark", Blocks.GRAY_CONCRETE), bars = Blocks.IRON_BARS.getDefaultState();
        Landmarks.perimeter(g, 2, 4, post, bars, 4, 4);
        Landmarks.wire(g, 2, 5, 0.7f);
        BlockState jersey = Landmarks.bb("concrete_panel", Blocks.LIGHT_GRAY_CONCRETE);
        Landmarks.perimeter(g, 10, 2, jersey, jersey, 4, 1);
        for (int k = 0; k < 4; k++) breach(g, 2);
        for (int k = 0; k < 7; k++) breach(g, 10);
        for (int[] t : new int[][]{{4, 4}, {W - 8, 4}, {4, D - 8}, {W - 8, D - 8}}) Landmarks.watchTower(g, t[0] + 1, t[1] + 1, 10, ZombieOutfit.SOLDIER);
        // КПП у южных ворот
        Landmarks.gatePost(g, cx + 6, D - 17, true, ZombieOutfit.SOLDIER);
        Landmarks.barriers(g, cx, true, D - 5, 4);
        Landmarks.barriers(g, cx, true, D - 13, 4);
        for (int x = cx - 10; x <= cx - 5; x++) g.furn(x, 1, D - 15, "sandbags", Direction.SOUTH);
        g.furn(cx - 6, 1, D - 4, "stop_sign", Direction.SOUTH);
        g.furn(cx + 6, 1, D - 4, "stop_sign", Direction.SOUTH);

        // ---- северо-запад: палаточный городок беженцев
        int tent = 0;
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 3; j++) {
                int x = 15 + i * 12, z = 15 + j * 16;
                Landmarks.tent(g, x, z, 7, 9, Blocks.WHITE_WOOL, (i + j) % 3 == 0 ? Loot.CLOTHES : (i + j) % 3 == 1 ? Loot.BEDROOM : Loot.GROCERY);
                if (tent++ == 5) g.note(x + 5, 1, z + 7, Stories.T_QUARANTINE);
                g.zombie(x + 3, 1, z + 4, null, 2);
                if (g.r.nextFloat() < 0.5f) g.zombie(x + 2, 1, z + 6, g.r.nextBoolean() ? ZombieOutfit.NURSE : null, 2);
                if (g.r.nextFloat() < 0.3f) special(g, x + 4, 1, z + 2, null, ZombieKind.BLOATER);
            }
        Landmarks.scatter(g, 13, 13, 64, 64, 14, null, 2);
        // бельё, бочки, кострища
        for (int k = 0; k < 5; k++) {
            int x = 18 + g.r.nextInt(44), z = 26 + g.r.nextInt(4) * 16;
            if (g.get(x, 1, z) == null) g.set(x, 1, z, Blocks.CAMPFIRE.getDefaultState().with(CampfireBlock.LIT, false));
        }

        // ---- северо-восток: полевой госпиталь с изолятором (там Носитель)
        int hx1 = 82, hz1 = 16, hx2 = 128, hz2 = 40, hm = (hz1 + hz2) / 2;
        bigTent(g, hx1, hz1, hx2, hz2, Blocks.WHITE_WOOL);
        for (int x = hx1 + 3; x <= hx2 - 18; x += 3) {
            g.bed(x, 1, hz1 + 1, Blocks.WHITE_BED, Direction.SOUTH);
            g.bed(x, 1, hz2 - 2, Blocks.WHITE_BED, Direction.NORTH);
        }
        for (int x = hx1 + 2; x <= hx2 - 18; x += 7) g.furnLoot(x, 1, hm - 2, "shelf_meds", Direction.SOUTH, Loot.HOSPITAL);
        g.furnLoot(hx1 + 4, 1, hm + 2, "desk", Direction.NORTH, Loot.OFFICE);
        g.note(hx1 + 4, 1, hm + 2, Stories.T_QUARANTINE);
        g.furnLoot(hx1 + 8, 1, hm + 2, "fridge", Direction.NORTH, Loot.HOSPITAL);
        // изолятор: решётка поперёк палатки, внутри — Носитель и ящик с образцами
        int ix = hx2 - 15;
        for (int z = hz1 + 1; z < hz2; z++)
            for (int y = 1; y <= 3; y++) g.set(ix, y, z, Math.abs(z - hm) <= 1 && y <= 2 ? AIR : bars);
        for (int x = ix + 2; x < hx2 - 1; x += 3) g.bed(x, 1, hz1 + 1, Blocks.RED_BED, Direction.SOUTH);
        g.furnLoot(hx2 - 2, 1, hm, "army_crate", Direction.WEST, Loot.ELITE);
        g.furnLoot(hx2 - 2, 1, hz2 - 2, "shelf_meds", Direction.NORTH, Loot.HOSPITAL);
        special(g, ix + 7, 1, hm, ZombieOutfit.HAZMAT, ZombieKind.CARRIER);
        blood(g, ix + 1, hz1 + 1, hx2 - 1, hz2 - 1, 16);
        for (int k = 0; k < 9; k++) g.zombie(hx1 + 2 + g.r.nextInt(ix - hx1 - 3), 1, hm - 1 + g.r.nextInt(3), k % 2 == 0 ? ZombieOutfit.DOCTOR : ZombieOutfit.NURSE, 3);
        special(g, hx1 + 12, 1, hm, null, ZombieKind.FERAL);
        special(g, hx1 + 20, 1, hm + 1, ZombieOutfit.NURSE, ZombieKind.SCREAMER);
        // склад медикаментов и скорые
        Landmarks.tent(g, 86, 46, 9, 11, Blocks.WHITE_WOOL, Loot.HOSPITAL);
        Landmarks.tent(g, 99, 46, 9, 11, Blocks.WHITE_WOOL, Loot.CLINIC);
        g.vehicle(116, 1, 50, "ambulance", 90f, false);
        g.vehicle(116, 1, 57, "ambulance", 80f, true);

        // ---- юго-запад: санобработка и братская могила
        Landmarks.tent(g, 16, 82, 7, 9, Blocks.YELLOW_WOOL, Loot.HOSPITAL);
        Landmarks.tent(g, 28, 82, 7, 9, Blocks.YELLOW_WOOL, Loot.BATHROOM);
        Landmarks.scatter(g, 14, 80, 40, 94, 6, ZombieOutfit.HAZMAT, 3);
        for (int k = 0; k < 3; k++) g.set(42 + k * 2, 1, 84, Blocks.WATER_CAULDRON.getDefaultState());
        int px1 = 18, pz1 = 100, px2 = 44, pz2 = 118;
        for (int x = px1; x <= px2; x++)
            for (int z = pz1; z <= pz2; z++) {
                for (int y = -2; y <= 0; y++) g.set(x, y, z, AIR);
                g.set(x, -3, z, Blocks.COARSE_DIRT.getDefaultState());
                float q = g.r.nextFloat();
                if (q < 0.18f) g.set(x, -2, z, Blocks.BLACK_CARPET.getDefaultState());   // мешки с телами
                else if (q < 0.26f) g.set(x, -2, z, Blocks.BONE_BLOCK.getDefaultState());
                else if (q < 0.32f) g.set(x, -2, z, Blocks.WHITE_CONCRETE_POWDER.getDefaultState());   // известь
            }
        for (int x = px1 - 1; x <= px2 + 1; x++) {   // отвалы земли по краям
            if (g.r.nextFloat() < 0.6f) g.set(x, 1, pz1 - 1, Blocks.COARSE_DIRT.getDefaultState());
            if (g.r.nextFloat() < 0.6f) g.set(x, 1, pz2 + 1, Blocks.COARSE_DIRT.getDefaultState());
        }
        fire(g, px1 + 5, -2, pz1 + 6);
        fire(g, px2 - 6, -2, pz2 - 4);
        for (int k = 0; k < 4; k++) special(g, px1 + 3 + g.r.nextInt(px2 - px1 - 6), -2, pz1 + 3 + g.r.nextInt(pz2 - pz1 - 6), null, ZombieKind.BLOATER);
        for (int k = 0; k < 10; k++) g.zombie(px1 + 2 + g.r.nextInt(px2 - px1 - 4), -2, pz1 + 2 + g.r.nextInt(pz2 - pz1 - 4), null, 2);

        // ---- юго-восток: штаб, вертолётная площадка, склад
        int sx1 = 84, sz1 = 84, sx2 = 99, sz2 = 95;
        BlockState wall = Blocks.GREEN_TERRACOTTA.getDefaultState();
        g.walls(sx1, 1, sz1, sx2, 4, sz2, wall);
        g.air(sx1 + 1, 1, sz1 + 1, sx2 - 1, 4, sz2 - 1);
        g.fill(sx1, 5, sz1, sx2, 5, sz2, Landmarks.bb("roof_tar", Blocks.GRAY_CONCRETE));
        for (int x = sx1 + 2; x < sx2 - 1; x += 3) {
            g.set(x, 2, sz1, Blocks.GLASS_PANE.getDefaultState());
            g.set(x, 2, sz2, Blocks.GLASS_PANE.getDefaultState());
        }
        g.door((sx1 + sx2) / 2, 1, sz2, Blocks.IRON_DOOR, Direction.SOUTH);
        g.air((sx1 + sx2) / 2 + 1, 1, sz2, (sx1 + sx2) / 2 + 1, 2, sz2);   // дверь выбита рядом
        g.furnLoot(sx1 + 1, 1, sz1 + 1, "gun_rack", Direction.SOUTH, Loot.ELITE);
        g.furnLoot(sx1 + 3, 1, sz1 + 1, "army_crate", Direction.SOUTH, Loot.ELITE);
        g.furnLoot(sx1 + 5, 1, sz1 + 1, "army_crate", Direction.SOUTH, Loot.ARMY);
        g.furnLoot(sx2 - 2, 1, sz1 + 1, "desk", Direction.SOUTH, Loot.OFFICE);
        g.note(sx2 - 2, 1, sz1 + 1, Stories.T_QUARANTINE);
        g.furn(sx2 - 4, 1, sz1 + 1, "radio", Direction.SOUTH);
        g.furnLoot(sx2 - 1, 1, sz2 - 2, "army_crate", Direction.WEST, Loot.ELITE);
        g.furnLoot(sx1 + 1, 1, sz2 - 2, "shelf_meds", Direction.EAST, Loot.HOSPITAL);
        g.set((sx1 + sx2) / 2, 4, (sz1 + sz2) / 2, Blocks.LANTERN.getDefaultState().with(LanternBlock.HANGING, true));
        g.furn(sx2 + 2, 1, sz1 + 2, "generator", Direction.EAST);
        special(g, sx1 + 4, 1, sz1 + 5, ZombieOutfit.RIOT, ZombieKind.ARMORED);
        special(g, sx2 - 4, 1, sz1 + 6, ZombieOutfit.SOLDIER, ZombieKind.ARMORED);
        special(g, (sx1 + sx2) / 2, 1, sz2 + 3, ZombieOutfit.RIOT, ZombieKind.ARMORED);
        special(g, (sx1 + sx2) / 2 + 3, 1, sz2 + 2, ZombieOutfit.SOLDIER, ZombieKind.ARMORED);
        for (int k = 0; k < 4; k++) g.zombie(sx1 + 2 + g.r.nextInt(sx2 - sx1 - 3), 1, sz1 + 3 + g.r.nextInt(5), ZombieOutfit.SOLDIER, 3);
        // площадка: бетон, жёлтая «Н», огни по углам, мешки
        int hx = 106, hz = 104;
        for (int x = hx; x <= hx + 12; x++)
            for (int z = hz; z <= hz + 12; z++) g.set(x, 0, z, Landmarks.bb("floor_concrete", Blocks.LIGHT_GRAY_CONCRETE));
        for (int z = hz + 3; z <= hz + 9; z++) {
            g.set(hx + 4, 0, z, Blocks.YELLOW_CONCRETE.getDefaultState());
            g.set(hx + 8, 0, z, Blocks.YELLOW_CONCRETE.getDefaultState());
        }
        for (int x = hx + 5; x <= hx + 7; x++) g.set(x, 0, hz + 6, Blocks.YELLOW_CONCRETE.getDefaultState());
        for (int[] c : new int[][]{{hx, hz}, {hx + 12, hz}, {hx, hz + 12}, {hx + 12, hz + 12}}) g.set(c[0], 0, c[1], Blocks.SEA_LANTERN.getDefaultState());
        for (int x = hx - 2; x <= hx + 14; x++) if (g.r.nextFloat() < 0.7f) g.furn(x, 1, hz - 2, "sandbags", Direction.NORTH);
        for (int k = 0; k < 6; k++) g.furnLoot(hx + 1 + k * 2, 1, hz + 14, "army_crate", Direction.NORTH, k % 3 == 0 ? Loot.ARMY : Loot.WAREHOUSE);
        Landmarks.scatter(g, hx - 4, hz - 4, hx + 16, hz + 16, 6, ZombieOutfit.SOLDIER, 3);
        for (int k = 0; k < 3; k++) g.vehicle(88 + k * 6.5, 1, 112, k == 1 ? "pickup" : "van", 0f, g.r.nextFloat() < 0.5f);

        // ---- по всей зоне: солдаты, беженцы, особые зомби, кровь
        Landmarks.scatter(g, 12, 12, W - 12, D - 12, 22, ZombieOutfit.SOLDIER, 3);
        Landmarks.scatter(g, 12, 12, W - 12, D - 12, 18, null, 2);
        specials(g, 12, 12, W - 12, D - 12, 8, null, ZombieKind.FERAL);
        specials(g, 12, 12, W - 12, D - 12, 4, null, ZombieKind.SCREAMER);
        specials(g, 12, 12, W - 12, D - 12, 3, ZombieOutfit.RIOT, ZombieKind.ARMORED);
        specials(g, 12, 12, W - 12, D - 12, 3, null, ZombieKind.BLOATER);
        blood(g, 12, 12, W - 12, D - 12, 50);
    }

    // =====================================================================================
    //                            МЕСТО КРУШЕНИЯ ВЕРТОЛЁТА
    // =====================================================================================

    static void crash(Plan g, Landmarks.Site s) {
        int W = g.w, D = g.d, cx = W / 2, cz = D / 2;
        g.danger = 3;
        Wild.ground(g, 0, 0, W - 1, D - 1, Blocks.GRASS_BLOCK, Blocks.COARSE_DIRT, 0.12f);
        // борозда от удара — с северо-востока к центру, обугленная земля вокруг
        double ax = W - 12, az = 10, bx = cx + 6, bz = cz - 2;
        for (int i = 0; i <= 60; i++) {
            double t = i / 60.0, x = ax + (bx - ax) * t, z = az + (bz - az) * t;
            int wdt = 2 + (int) (t * 3);
            for (int dx = -wdt; dx <= wdt; dx++)
                for (int dz = -wdt; dz <= wdt; dz++) {
                    if (dx * dx + dz * dz > wdt * wdt) continue;
                    float q = g.r.nextFloat();
                    g.set((int) x + dx, 0, (int) z + dz, q < 0.45f ? Blocks.COARSE_DIRT : q < 0.75f ? Blocks.BLACKSTONE : Blocks.COAL_BLOCK);
                }
        }
        for (int x = cx - 24; x <= cx + 24; x++)
            for (int z = cz - 18; z <= cz + 18; z++) {
                double dd = Math.hypot((x - cx) / 24.0, (z - cz) / 18.0);
                if (dd < 1 && g.r.nextFloat() < 0.8 - dd * 0.7) g.set(x, 0, z, g.r.nextFloat() < 0.5f ? Blocks.COARSE_DIRT : Blocks.BLACKSTONE);
            }
        // фюзеляж тяжёлого транспортного вертолёта (21 x 7 x 5), разломан посередине
        BlockState hull = Blocks.GREEN_TERRACOTTA.getDefaultState(), dark = Blocks.BLACK_TERRACOTTA.getDefaultState();
        int fx1 = cx - 12, fx2 = cx + 8, fz1 = cz - 3, fz2 = cz + 3;
        g.walls(fx1, 1, fz1, fx2, 4, fz2, hull);
        g.fill(fx1, 5, fz1 + 1, fx2, 5, fz2 - 1, hull);
        g.air(fx1 + 1, 1, fz1 + 1, fx2 - 1, 4, fz2 - 1);
        g.fill(fx1 + 1, 0, fz1 + 1, fx2 - 1, 0, fz2 - 1, Blocks.IRON_TRAPDOOR.getDefaultState());
        for (int x = fx1; x <= fx2; x++) g.set(x, 3, fz1, (x - fx1) % 4 == 2 ? Blocks.GRAY_STAINED_GLASS_PANE.getDefaultState() : dark);
        for (int x = fx1; x <= fx2; x++) g.set(x, 3, fz2, (x - fx1) % 4 == 2 ? Blocks.GRAY_STAINED_GLASS_PANE.getDefaultState() : dark);
        for (int z = fz1 + 1; z < fz2; z++)
            for (int y = 2; y <= 4; y++) g.set(fx1, y, z, Blocks.GRAY_STAINED_GLASS_PANE.getDefaultState());   // кабина
        for (int z = fz1 + 1; z < fz2; z++)
            for (int y = 1; y <= 4; y++) g.set(fx2, y, z, AIR);                                           // открытая аппарель
        for (int z = fz1 + 1; z < fz2; z++) g.set(fx2 + 1, 1, z, Blocks.SMOOTH_STONE_SLAB.getDefaultState());
        for (int y = 1; y <= 5; y++)
            for (int z = fz1; z <= fz1 + 2; z++) if (g.r.nextFloat() < 0.8f) g.set(cx - 2, y, z, AIR);   // разлом по борту
        g.air(cx - 1, 1, fz1, cx, 4, fz1);
        // два винта: мачты и лопасти, одна оторвана и лежит в стороне
        for (int mx : new int[]{fx1 + 4, fx2 - 3}) {
            g.set(mx, 6, cz, Blocks.IRON_BLOCK.getDefaultState());
            for (int i = 1; i <= 7; i++) g.set(mx + (mx < cx ? -i : i), 6, cz, Blocks.SMOOTH_STONE_SLAB.getDefaultState());
            for (int i = 1; i <= 5; i++) g.set(mx, 6, cz + (mx < cx ? i : -i), Blocks.SMOOTH_STONE_SLAB.getDefaultState());
        }
        for (int i = 0; i < 9; i++) g.set(cx - 6 + i, 1, cz + 11 + i / 3, Blocks.SMOOTH_STONE_SLAB.getDefaultState());
        // хвост отломан при ударе
        int tx = cx + 16, tz = cz + 10;
        g.walls(tx, 1, tz, tx + 6, 3, tz + 3, hull);
        g.air(tx + 1, 1, tz + 1, tx + 5, 3, tz + 2);
        g.fill(tx + 6, 4, tz + 1, tx + 6, 7, tz + 2, hull);
        g.fill(tx + 5, 7, tz, tx + 7, 7, tz + 3, Blocks.IRON_BARS.getDefaultState());
        // обломки: двигатель, наковальни, цепи
        for (int k = 0; k < 10; k++) {
            int x = cx - 20 + g.r.nextInt(42), z = cz - 16 + g.r.nextInt(34);
            if (g.get(x, 1, z) != null) continue;
            float q = g.r.nextFloat();
            g.set(x, 1, z, q < 0.3f ? Blocks.IRON_BLOCK.getDefaultState() : q < 0.55f ? Blocks.DAMAGED_ANVIL.getDefaultState()
                    : q < 0.8f ? Blocks.SMOOTH_STONE_SLAB.getDefaultState() : Blocks.CHAIN.getDefaultState());
        }
        Wild.scatter(g, cx - 22, cz - 18, cx + 22, cz + 18, 16, true);
        // пожар: дым видно издалека
        fire(g, cx + 3, 1, cz + 5);
        fire(g, fx1 - 2, 1, cz - 5);
        fire(g, tx + 3, 1, tz + 5);
        fire(g, cx + 12, 1, cz - 10);
        // груз внутри и вокруг
        g.furnLoot(fx1 + 3, 1, fz1 + 1, "army_crate", Direction.SOUTH, Loot.ELITE);
        g.furnLoot(fx1 + 6, 1, fz2 - 1, "army_crate", Direction.NORTH, Loot.ELITE);
        g.furnLoot(fx2 - 2, 1, fz1 + 1, "gun_rack", Direction.SOUTH, Loot.ELITE);
        g.furnLoot(fx2 - 4, 1, fz2 - 1, "army_crate", Direction.NORTH, Loot.ARMY);
        g.furnLoot(fx2 - 6, 1, fz1 + 1, "shelf_meds", Direction.SOUTH, Loot.HOSPITAL);
        g.loot(fx1 + 1, 1, fz1 + 1, Buildings.chest(Direction.EAST), Loot.ARMY);
        g.note(fx1 + 1, 1, fz1 + 1, Stories.T_CRASH);
        for (int k = 0; k < 7; k++) {
            int x = cx - 18 + g.r.nextInt(36), z = cz - 14 + g.r.nextInt(28);
            if (g.get(x, 1, z) == null) g.furnLoot(x, 1, z, "army_crate", Direction.Type.HORIZONTAL.random(g.r), k % 3 == 0 ? Loot.ARMY : Loot.WAREHOUSE);
        }
        for (int k = 0; k < 6; k++) g.pile(cx - 20 + g.r.nextInt(40), 1, cz - 16 + g.r.nextInt(32), k % 2 == 0 ? Loot.ARMY : Loot.POLICE);
        // выжившие солдаты успели окопаться: дуга мешков, палатка, машины — не помогло
        for (int a = 0; a < 360; a += 6) {
            if (a > 300 && a < 340) continue;   // проход
            double rad = Math.toRadians(a);
            int x = cx + (int) Math.round(Math.cos(rad) * 17), z = cz + (int) Math.round(Math.sin(rad) * 13);
            if (g.get(x, 1, z) == null && g.r.nextFloat() < 0.8f) g.furn(x, 1, z, "sandbags", Direction.fromHorizontal(((a + 45) / 90 + 1) % 4));
        }
        Landmarks.tent(g, cx - 30, cz + 18, 9, 11, Blocks.GREEN_WOOL, Loot.HOSPITAL);
        g.note(cx - 30 + 7, 1, cz + 18 + 9, Stories.T_CRASH);
        g.vehicle(cx + 26, 1, cz - 20, "pickup", 35f, true);
        g.vehicle(cx - 26, 1, cz - 14, "van", 120f, true);
        // мертвецы: экипаж, охрана груза, учёные — и те, кого собрал грохот
        g.zombie(fx1 + 1, 1, cz, ZombieOutfit.SOLDIER, 3);
        g.zombie(fx1 + 2, 1, cz + 1, ZombieOutfit.SOLDIER, 3);
        for (int k = 0; k < 4; k++) g.zombie(cx - 6 + g.r.nextInt(12), 1, cz - 7 - g.r.nextInt(3), ZombieOutfit.DOCTOR, 3);
        Landmarks.scatter(g, 8, 8, W - 8, D - 8, 18, ZombieOutfit.SOLDIER, 3);
        Landmarks.scatter(g, 8, 8, W - 8, D - 8, 10, null, 2);
        specials(g, cx - 18, cz - 14, cx + 18, cz + 14, 8, ZombieOutfit.SOLDIER, ZombieKind.ARMORED);
        specials(g, 8, 8, W - 8, D - 8, 7, null, ZombieKind.FERAL);
        specials(g, 8, 8, W - 8, D - 8, 3, null, ZombieKind.SCREAMER);
        specials(g, 8, 8, W - 8, D - 8, 2, null, ZombieKind.BLOATER);
        blood(g, cx - 22, cz - 18, cx + 22, cz + 18, 30);
    }
}
