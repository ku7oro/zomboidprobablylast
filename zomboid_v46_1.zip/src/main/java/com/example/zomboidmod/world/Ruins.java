package com.example.zomboidmod.world;

import com.example.zomboidmod.ZombieOutfit;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.util.math.Direction;

/**
 * Руины большой техники — то, что видно издалека и к чему хочется свернуть: градирня мёртвой электростанции,
 * завод с трубой, ракетная шахта, воронка с неразорвавшейся бомбой, нефтебаза с качалкой, радар, опоры ЛЭП,
 * упавший спутник. Всё брошено давно: бетон в трещинах и мху, ржавчина, провалы в крышах.
 * Координаты плана — как в Wild: y = 0 — земля, отрицательные y — под землёй.
 */
final class Ruins {
    private Ruins() {
    }

    static void build(Sites.Kind k, Plan p) {
        switch (k) {
            case FACTORY -> factory(p);
            case COOLING -> cooling(p);
            case SILO -> silo(p);
            case CRATER -> crater(p);
            case DEPOT -> depot(p);
            case PYLON -> pylon(p);
            case RADAR -> radar(p);
            case SATELLITE -> satellite(p);
            default -> {
            }
        }
    }

    // ===================== материалы: старое, битое, заросшее =====================

    /** Бетон: серый, с тёмными потёками, трещинами и мхом. */
    static Block concrete(Plan p) {
        float f = p.r.nextFloat();
        if (f < 0.66f) return Blocks.LIGHT_GRAY_CONCRETE;
        if (f < 0.80f) return Blocks.STONE_BRICKS;
        if (f < 0.89f) return Blocks.CRACKED_STONE_BRICKS;
        if (f < 0.95f) return Blocks.MOSSY_STONE_BRICKS;
        return Blocks.GRAY_CONCRETE;
    }

    /** Кирпич заводских стен. */
    static Block brick(Plan p) {
        float f = p.r.nextFloat();
        if (f < 0.72f) return Blocks.BRICKS;
        if (f < 0.86f) return Blocks.TERRACOTTA;
        if (f < 0.94f) return Blocks.GRANITE;
        return Blocks.MOSSY_COBBLESTONE;
    }

    /** Крашеный металл в ржавчине. */
    static Block rusty(Plan p, Block paint) {
        float f = p.r.nextFloat();
        if (f < 0.68f) return paint;
        if (f < 0.86f) return Blocks.TERRACOTTA;
        if (f < 0.95f) return Blocks.BROWN_TERRACOTTA;
        return Blocks.ORANGE_TERRACOTTA;
    }

    /** Выжженная земля. */
    static Block scorched(Plan p) {
        float f = p.r.nextFloat();
        if (f < 0.34f) return Blocks.BLACKSTONE;
        if (f < 0.58f) return Blocks.BASALT;
        if (f < 0.80f) return Blocks.GRAVEL;
        if (f < 0.92f) return Blocks.COARSE_DIRT;
        return Blocks.COAL_BLOCK;
    }

    static boolean free(Plan p, int x, int y, int z) {
        BlockState s = p.get(x, y, z);
        return s == null || s.isAir();
    }

    /** Мох, паутина и кусты там, где пусто. */
    static void overgrow(Plan p, int x1, int z1, int x2, int z2, int n) {
        for (int i = 0; i < n; i++) {
            int x = x1 + p.r.nextInt(x2 - x1 + 1), z = z1 + p.r.nextInt(z2 - z1 + 1);
            if (!free(p, x, 1, z) || p.get(x, 0, z) == null) continue;
            float f = p.r.nextFloat();
            if (f < 0.55f) p.set(x, 1, z, Blocks.MOSS_CARPET);
            else if (f < 0.8f) p.set(x, 1, z, Blocks.OAK_LEAVES.getDefaultState().with(LeavesBlock.PERSISTENT, true));
            else p.set(x, 1, z, Blocks.COBWEB);
        }
    }

    /** Куча обломков. */
    static void rubble(Plan p, int cx, int cz, int r, Block a, Block b) {
        for (int x = cx - r; x <= cx + r; x++)
            for (int z = cz - r; z <= cz + r; z++) {
                double d = Math.hypot(x - cx, z - cz);
                if (d > r + 0.3) continue;
                int h = (int) Math.round((r - d) * 0.8 + p.r.nextFloat() * 0.9);
                for (int y = 1; y <= h; y++) p.set(x, y, z, p.r.nextFloat() < 0.6f ? a : b);
            }
    }

    /** Стенка цилиндра (кольцо) на высотах y1..y2. hole — доля выбитых блоков. */
    static void ring(Plan p, int cx, int cz, double r, int y1, int y2, java.util.function.Supplier<Block> b, float hole) {
        int n = (int) Math.ceil(r) + 1;
        for (int x = cx - n; x <= cx + n; x++)
            for (int z = cz - n; z <= cz + n; z++) {
                double d = Math.hypot(x - cx, z - cz);
                if (d < r - 0.5 || d >= r + 0.5) continue;
                for (int y = y1; y <= y2; y++) if (hole <= 0f || p.r.nextFloat() >= hole) p.set(x, y, z, b.get());
            }
    }

    /** Сплошной круг на высоте y. */
    static void disc(Plan p, int cx, int cz, double r, int y, java.util.function.Supplier<Block> b) {
        int n = (int) Math.ceil(r) + 1;
        for (int x = cx - n; x <= cx + n; x++)
            for (int z = cz - n; z <= cz + n; z++) if (Math.hypot(x - cx, z - cz) < r + 0.5) p.set(x, y, z, b.get());
    }

    static void fence(Plan p, int x1, int z1, int x2, int z2, float gaps) {
        Wild.fenceLine(p, x1, z1, x2, z1, Blocks.IRON_BARS, 2, gaps);
        Wild.fenceLine(p, x1, z2, x2, z2, Blocks.IRON_BARS, 2, gaps);
        Wild.fenceLine(p, x1, z1, x1, z2, Blocks.IRON_BARS, 2, gaps);
        Wild.fenceLine(p, x2, z1, x2, z2, Blocks.IRON_BARS, 2, gaps);
    }

    // ===================== завод =====================
    /** Цех с провалившейся крышей, станки, цистерны и высокая кирпичная труба. */
    static void factory(Plan p) {
        p.danger = 2;
        int W = p.w - 1, D = p.d - 1;
        Wild.ground(p, 0, 0, W, D, Blocks.GRAVEL, Blocks.COARSE_DIRT, 0.35f);
        int x1 = 2, z1 = 4, x2 = 23, z2 = 22, top = 7;
        // пол и стены цеха
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) p.set(x, 0, z, p.r.nextFloat() < 0.1f ? Blocks.GRAVEL : Blocks.SMOOTH_STONE);
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                if (x != x1 && x != x2 && z != z1 && z != z2) continue;
                for (int y = 1; y <= top; y++) {
                    if (y >= top - 1 && p.r.nextFloat() < 0.16f) continue;          // верх стен осыпался
                    p.set(x, y, z, brick(p));
                }
            }
        // высокие цеховые окна: где стекло, где решётка, где дыра
        for (int x = x1 + 2; x <= x2 - 2; x += 3)
            for (int y = 3; y <= 5; y++) {
                for (int z : new int[]{z1, z2}) {
                    float f = p.r.nextFloat();
                    p.set(x, y, z, f < 0.4f ? Blocks.GLASS_PANE : f < 0.7f ? Blocks.IRON_BARS : Blocks.AIR);
                }
            }
        for (int z = z1 + 3; z <= z2 - 3; z += 3)
            for (int y = 3; y <= 5; y++) p.set(x1, y, z, p.r.nextFloat() < 0.5f ? Blocks.GLASS_PANE : Blocks.AIR);
        // ворота
        p.air(11, 1, z1, 14, 4, z1);
        for (int x = 11; x <= 14; x++) p.set(x, 0, z1 - 1, Blocks.SMOOTH_STONE);
        // балки и крыша с провалом
        for (int x = x1 + 3; x <= x2 - 3; x += 4) for (int z = z1 + 1; z <= z2 - 1; z++) p.set(x, top, z, Blocks.IRON_BARS);
        int hx = 8 + p.r.nextInt(8), hz = 10 + p.r.nextInt(7);
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                double d = Math.hypot((x - hx) / 1.5, z - hz);
                if (d < 4.2 || p.r.nextFloat() < 0.05f) continue;
                p.set(x, top + 1, z, p.r.nextFloat() < 0.85f ? Blocks.SMOOTH_STONE_SLAB : Blocks.STONE_BRICK_SLAB);
            }
        rubble(p, hx, hz, 3, Blocks.COBBLESTONE, Blocks.GRAVEL);
        // станки вдоль стены и лента конвейера
        for (int x = 4; x <= 20; x += 4) {
            p.set(x, 1, z2 - 2, Blocks.BLAST_FURNACE);
            p.set(x + 1, 1, z2 - 2, Blocks.IRON_BLOCK);
            p.set(x + 1, 2, z2 - 2, p.r.nextBoolean() ? Blocks.HOPPER : Blocks.ANVIL);
        }
        for (int x = 4; x <= 20; x++) {
            if (Math.hypot(x - hx, 7 - hz) < 3.5) continue;
            p.set(x, 1, 7, Blocks.SMOOTH_STONE_SLAB);
            if (x % 5 == 0) p.set(x, top - 1, 7, Blocks.CHAIN);
        }
        p.furnLoot(3, 1, 10, "shelf_tools", Direction.EAST, Loot.HARDWARE);
        p.furnLoot(3, 1, 12, "shelf_tools", Direction.EAST, Loot.HARDWARE);
        p.furnLoot(3, 1, 14, "shelf_tools", Direction.EAST, Loot.WAREHOUSE);
        p.furn(3, 1, 17, "generator", Direction.EAST);
        p.loot(22, 1, 6, Buildings.chest(Direction.WEST), Loot.WAREHOUSE);
        p.loot(22, 1, 12, Buildings.chest(Direction.WEST), Loot.HARDWARE);
        p.loot(22, 1, 18, Buildings.chest(Direction.WEST), Loot.GARAGE);
        p.note(22, 1, 12, -1);
        for (int i = 0; i < 4; i++) p.pile(4 + p.r.nextInt(17), 1, 9 + p.r.nextInt(9), Loot.WAREHOUSE);
        // цистерны у стены
        for (int cz : new int[]{7, 13}) {
            ring(p, 28, cz, 2, 1, 5, () -> rusty(p, Blocks.LIGHT_GRAY_CONCRETE), 0.03f);
            disc(p, 28, cz, 2, 6, () -> Blocks.SMOOTH_STONE_SLAB);
        }
        for (int x = 24; x <= 26; x++) p.set(x, 3, 7, Blocks.GRAY_CONCRETE);     // труба от цеха к цистерне
        // дымовая труба: видна издалека, верх обвалился
        for (int y = 0; y <= 24; y++)
            for (int x = 27; x <= 30; x++)
                for (int z = 18; z <= 21; z++) {
                    boolean wall = x == 27 || x == 30 || z == 18 || z == 21;
                    if (!wall) continue;
                    if (y >= 22 && p.r.nextFloat() < 0.45f) continue;
                    p.set(x, y, z, y % 8 == 7 ? Blocks.STONE_BRICKS : brick(p));
                }
        rubble(p, 31, 23, 1, Blocks.BRICKS, Blocks.GRAVEL);
        overgrow(p, 0, 0, W, D, 60);
        Wild.scatter(p, x1 + 1, z1 + 1, x2 - 1, z2 - 1, 16, true);
        for (int i = 0; i < 9; i++)
            p.zombie(4 + p.r.nextInt(17), 1, 9 + p.r.nextInt(11), p.r.nextBoolean() ? ZombieOutfit.CONSTRUCTION : ZombieOutfit.MECHANIC, 1);
        Buildings.car(p, 16, 0, false, "pickup");
    }

    // ===================== градирня =====================
    /** Градирня остановленной электростанции: бетонная оболочка в двадцать шесть блоков высотой. */
    static void cooling(Plan p) {
        p.danger = 2;
        int W = p.w - 1, D = p.d - 1, c = 13, H = 26;
        Wild.ground(p, 0, 0, W, D, Blocks.GRAVEL, Blocks.COARSE_DIRT, 0.4f);
        disc(p, c, c, 11, 0, () -> p.r.nextFloat() < 0.2f ? Blocks.MOSS_BLOCK : Blocks.STONE);
        for (int y = 1; y <= H; y++) {
            double t = (y - 17) / 17.0;
            double r = 6.5 + 4.5 * t * t;                 // узкая «талия» на двух третях высоты
            final int yy = y;
            if (y <= 3) {                                 // внизу — опоры через одну: воздух шёл под оболочку
                int n = (int) Math.ceil(r) + 1;
                for (int x = c - n; x <= c + n; x++)
                    for (int z = c - n; z <= c + n; z++) {
                        double d = Math.hypot(x - c, z - c);
                        if (d < r - 0.5 || d >= r + 0.5) continue;
                        if (((x + z) & 1) == 0) p.set(x, yy, z, Blocks.GRAY_CONCRETE);
                    }
                continue;
            }
            float hole = y >= H - 1 ? 0.3f : y > 18 ? 0.035f : 0.012f;   // край выкрошился
            ring(p, c, c, r, y, y, () -> concrete(p), hole);
        }
        // внутри: оросительные лотки на столбах и мокрый заросший пол
        for (int x = c - 6; x <= c + 6; x += 4)
            for (int z = c - 6; z <= c + 6; z += 4) {
                if (Math.hypot(x - c, z - c) > 7.5) continue;
                for (int y = 1; y <= 4; y++) p.set(x, y, z, Blocks.STONE_BRICK_WALL);
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) if (p.r.nextFloat() < 0.7f) p.set(x + dx, 5, z + dz, Blocks.SMOOTH_STONE_SLAB);
            }
        // проход в оболочке
        p.air(c - 1, 1, 1, c + 1, 3, 3);
        for (int i = 0; i < 26; i++) {
            int x = c - 8 + p.r.nextInt(17), z = c - 8 + p.r.nextInt(17);
            if (Math.hypot(x - c, z - c) < 8.5 && free(p, x, 1, z)) p.set(x, 1, z, p.r.nextFloat() < 0.75f ? Blocks.MOSS_CARPET : Blocks.COBWEB);
        }
        p.loot(c + 3, 1, c, Buildings.chest(Direction.WEST), Loot.ELECTRONICS);
        p.loot(c - 3, 1, c + 2, Buildings.chest(Direction.EAST), Loot.HARDWARE);
        p.note(c + 3, 1, c, -1);
        p.furn(c, 1, c - 4, "generator", Direction.SOUTH);
        for (int i = 0; i < 3; i++) p.pile(c - 5 + p.r.nextInt(11), 1, c - 5 + p.r.nextInt(11), Loot.WAREHOUSE);
        for (int i = 0; i < 7; i++) {
            int x = c - 5 + p.r.nextInt(11), z = c - 5 + p.r.nextInt(11);
            p.zombie(x, 1, z, i < 3 ? ZombieOutfit.HAZMAT : ZombieOutfit.CONSTRUCTION, 2);
        }
        overgrow(p, 0, 0, W, D, 40);
    }

    // ===================== ракетная шахта =====================
    /** Открытая ракетная шахта: ракета так и стоит внизу. Спуск по скобам, на дне — склад расчёта. */
    static void silo(Plan p) {
        p.danger = 3;
        int W = p.w - 1, D = p.d - 1, c = 9, bottom = -17;
        for (int x = 0; x <= W; x++) for (int z = 0; z <= D; z++) p.set(x, 0, z, concrete(p));
        fence(p, 0, 0, W, D, 0.12f);
        p.air(c - 1, 1, 0, c + 1, 2, 0);
        // ствол
        for (int y = bottom; y <= 0; y++) {
            for (int x = c - 5; x <= c + 5; x++)
                for (int z = c - 5; z <= c + 5; z++) {
                    double d = Math.hypot(x - c, z - c);
                    if (d < 3.5) p.set(x, y, z, Blocks.AIR);
                    else if (d < 4.5) p.set(x, y, z, y == 0 ? ((x + z) & 1) == 0 ? Blocks.YELLOW_CONCRETE : Blocks.BLACK_CONCRETE
                            : y % 6 == 0 ? Blocks.GRAY_CONCRETE : concrete(p));
                }
        }
        disc(p, c, c, 4, bottom - 1, () -> Blocks.GRAY_CONCRETE);
        // ракета
        for (int y = bottom; y <= -4; y++) {
            Block skin = y == -9 || y == -10 ? Blocks.RED_CONCRETE : y % 5 == 0 ? Blocks.LIGHT_GRAY_CONCRETE : Blocks.WHITE_CONCRETE;
            p.set(c, y, c, skin);
            if (y <= -6) {
                p.set(c + 1, y, c, skin);
                p.set(c - 1, y, c, skin);
                p.set(c, y, c + 1, skin);
                p.set(c, y, c - 1, skin);
            }
        }
        p.set(c, -3, c, Blocks.RED_CONCRETE);
        p.set(c, -2, c, Blocks.LIGHTNING_ROD);
        for (int y = bottom; y <= bottom + 1; y++) {      // стабилизаторы
            p.set(c + 2, y, c, Blocks.GRAY_CONCRETE);
            p.set(c - 2, y, c, Blocks.GRAY_CONCRETE);
            p.set(c, y, c + 2, Blocks.GRAY_CONCRETE);
            p.set(c, y, c - 2, Blocks.GRAY_CONCRETE);
        }
        // скобы по стене и площадки обслуживания
        p.ladder(c, bottom, 0, c - 3, Direction.SOUTH);
        for (int y : new int[]{-6, -12}) {
            for (int x = c - 3; x <= c + 3; x++)
                for (int z = c - 3; z <= c + 3; z++) {
                    double d = Math.hypot(x - c, z - c);
                    if (d >= 2.5 && d < 3.5 && !(x == c && z == c - 3)) p.set(x, y, z, Blocks.IRON_BARS);
                }
        }
        // на дне — ниша со складом
        p.air(c + 4, bottom, c - 1, c + 7, bottom + 2, c + 1);
        for (int x = c + 4; x <= c + 8; x++)
            for (int z = c - 2; z <= c + 2; z++)
                for (int y = bottom - 1; y <= bottom + 3; y++) if (free(p, x, y, z) && p.get(x, y, z) == null) p.set(x, y, z, Blocks.GRAY_CONCRETE);
        p.furnLoot(c + 7, bottom, c - 1, "army_crate", Direction.WEST, Loot.ARMY);
        p.furnLoot(c + 7, bottom, c + 1, "army_crate", Direction.WEST, Loot.ARMY);
        p.loot(c + 7, bottom, c, Buildings.chest(Direction.WEST), Loot.ELITE);
        p.set(c + 5, bottom + 2, c, Blocks.LANTERN.getDefaultState().with(net.minecraft.block.LanternBlock.HANGING, true));
        // пост управления наверху
        p.walls(1, 1, 13, 6, 3, 17, Blocks.LIGHT_GRAY_CONCRETE.getDefaultState());
        p.air(2, 1, 14, 5, 3, 16);
        p.fill(1, 4, 13, 6, 4, 17, Blocks.GRAY_CONCRETE);
        p.door(6, 1, 15, Blocks.IRON_DOOR, Direction.EAST);
        p.set(3, 2, 13, Blocks.GLASS_PANE);
        p.set(4, 2, 13, Blocks.GLASS_PANE);
        p.furn(2, 1, 16, "desk", Direction.NORTH);
        p.furn(3, 1, 16, "radio", Direction.NORTH);
        p.loot(2, 1, 14, Buildings.chest(Direction.EAST), Loot.OFFICE);
        p.note(2, 1, 14, Stories.T_MILITARY);
        p.furn(5, 1, 14, "generator", Direction.WEST);
        for (int i = 0; i < 4; i++) p.zombie(2 + p.r.nextInt(15), 1, 2 + p.r.nextInt(3), ZombieOutfit.SOLDIER, 2);
        p.zombie(c + 5, bottom, c, ZombieOutfit.HAZMAT, 3);
        p.zombie(c + 6, bottom, c + 1, ZombieOutfit.SOLDIER, 3);
        p.zombie(3, 1, 15, ZombieOutfit.SOLDIER, 2);
        Wild.scatter(p, 1, 1, W - 1, 4, 6, true);
    }

    // ===================== воронка =====================
    /** Воронка от авиабомбы; вторая бомба не взорвалась и торчит из дна. Вокруг — горелые стволы. */
    static void crater(Plan p) {
        p.danger = 2;
        int W = p.w - 1, D = p.d - 1, c = 12;
        for (int x = 0; x <= W; x++)
            for (int z = 0; z <= D; z++) {
                double d = Math.hypot(x - c, z - c) + (p.r.nextFloat() - 0.5) * 0.8;
                if (d >= 12.3) continue;
                if (d >= 9.6) {                                         // вал выброшенной земли
                    int h = d < 11 ? 1 + (p.r.nextFloat() < 0.4f ? 1 : 0) : (p.r.nextFloat() < 0.6f ? 1 : 0);
                    p.set(x, 0, z, Blocks.COARSE_DIRT);
                    for (int y = 1; y <= h; y++) p.set(x, y, z, p.r.nextFloat() < 0.7f ? Blocks.COARSE_DIRT : Blocks.GRAVEL);
                    continue;
                }
                int depth = Math.max(1, (int) Math.round(6.0 * (1.0 - (d / 9.6) * (d / 9.6))));
                for (int y = 0; y > -depth; y--) p.set(x, y, z, Blocks.AIR);
                p.set(x, -depth, z, scorched(p));
                p.set(x, -depth - 1, z, Blocks.BLACKSTONE);
            }
        // неразорвавшаяся бомба: ушла в дно под углом
        for (int i = 0; i < 5; i++) {
            int x = c + 1 + i / 2, y = -6 + i, z = c;
            p.set(x, y, z, i == 2 ? Blocks.YELLOW_CONCRETE : Blocks.GREEN_TERRACOTTA);
            p.set(x, y, z + 1, i == 2 ? Blocks.YELLOW_CONCRETE : Blocks.GREEN_TERRACOTTA);
        }
        p.set(c + 3, -1, c, Blocks.IRON_BARS);
        p.set(c + 3, -1, c + 1, Blocks.IRON_BARS);
        p.set(c + 4, -2, c, Blocks.IRON_BARS);
        // горелые стволы на валу и за ним
        for (int i = 0; i < 9; i++) {
            double a = p.r.nextDouble() * Math.PI * 2, rr = 10.2 + p.r.nextDouble() * 1.6;
            int x = c + (int) Math.round(Math.cos(a) * rr), z = c + (int) Math.round(Math.sin(a) * rr);
            if (x < 0 || z < 0 || x > W || z > D) continue;
            int base = 1;
            while (base < 4 && !free(p, x, base, z)) base++;
            int h = 2 + p.r.nextInt(4);
            for (int y = base; y < base + h; y++) p.set(x, y, z, p.r.nextFloat() < 0.75f ? Blocks.DARK_OAK_LOG : Blocks.BASALT);
        }
        // кто-то уже пытался её обезвредить
        p.furnLoot(c - 3, -5, c - 2, "army_crate", Direction.EAST, Loot.ARMY);
        p.pile(c - 2, -5, c + 2, Loot.ARMY);
        p.pile(c - 4, -4, c + 1, Loot.HARDWARE);
        Wild.blood(p, c - 1, -5, c - 1);
        Wild.blood(p, c - 2, -5, c);
        p.zombie(c - 2, -5, c - 1, ZombieOutfit.HAZMAT, 2);
        p.zombie(c - 3, -4, c + 2, ZombieOutfit.SOLDIER, 2);
        p.zombie(c + 1, -5, c - 3, ZombieOutfit.SOLDIER, 2);
        p.zombie(c - 5, -3, c - 3, ZombieOutfit.HAZMAT, 2);
    }

    // ===================== нефтебаза =====================
    /** Три резервуара, трубопровод, насосная и станок-качалка. Здесь ещё осталось топливо. */
    static void depot(Plan p) {
        p.danger = 1;
        int W = p.w - 1, D = p.d - 1;
        Wild.ground(p, 0, 0, W, D, Blocks.GRAVEL, Blocks.COARSE_DIRT, 0.3f);
        fence(p, 0, 0, W, D, 0.15f);
        p.air(13, 1, 0, 15, 2, 0);
        // резервуары
        int[][] tanks = {{6, 15}, {15, 15}, {24, 15}};
        for (int[] t : tanks) {
            int cx = t[0], cz = t[1];
            disc(p, cx, cz, 4, 0, () -> Blocks.SMOOTH_STONE);
            ring(p, cx, cz, 4, 1, 6, () -> rusty(p, Blocks.WHITE_CONCRETE), 0f);
            for (int x = cx - 5; x <= cx + 5; x++)                      // тёмный пояс с номером
                for (int z = cz - 5; z <= cz + 5; z++) {
                    double d = Math.hypot(x - cx, z - cz);
                    if (d >= 3.5 && d < 4.5 && p.r.nextFloat() < 0.8f) p.set(x, 4, z, Blocks.GRAY_CONCRETE);
                }
            disc(p, cx, cz, 4, 7, () -> p.r.nextFloat() < 0.9f ? Blocks.SMOOTH_STONE_SLAB : Blocks.STONE_BRICK_SLAB);
            ring(p, cx, cz, 4, 8, 8, () -> Blocks.IRON_BARS, 0.25f);
            p.ladder(cx, 1, 7, cz - 5, Direction.NORTH);
            p.set(cx, 8, cz - 4, Blocks.AIR);
        }
        // трубопровод вдоль резервуаров
        for (int x = 2; x <= 27; x++) {
            if (free(p, x, 1, 9)) p.set(x, 1, 9, x % 6 == 3 ? Blocks.IRON_BLOCK : Blocks.GRAY_CONCRETE);
        }
        for (int[] t : tanks) p.set(t[0], 1, 10, Blocks.GRAY_CONCRETE);
        // насосная
        p.fill(2, 0, 2, 7, 0, 6, Blocks.SMOOTH_STONE);
        p.walls(2, 1, 2, 7, 3, 6, Blocks.BRICKS.getDefaultState());
        for (int x = 2; x <= 7; x++) for (int z = 2; z <= 6; z++) if ((x == 2 || x == 7 || z == 2 || z == 6) && p.r.nextFloat() < 0.25f) p.set(x, 1 + p.r.nextInt(3), z, Blocks.TERRACOTTA);
        p.air(3, 1, 3, 6, 3, 5);
        p.fill(2, 4, 2, 7, 4, 6, Blocks.SMOOTH_STONE_SLAB);
        p.door(5, 1, 6, Blocks.IRON_DOOR, Direction.SOUTH);
        p.set(3, 2, 2, Blocks.GLASS_PANE);
        p.furnLoot(3, 1, 3, "shelf_tools", Direction.SOUTH, Loot.GAS);
        p.loot(6, 1, 3, Buildings.chest(Direction.WEST), Loot.GARAGE);
        p.note(6, 1, 3, -1);
        p.furn(3, 1, 5, "generator", Direction.EAST);
        p.furn(9, 1, 4, "gas_pump", Direction.SOUTH);
        // станок-качалка: рама, коромысло, противовес
        int bx = 21, bz = 4;
        p.fill(bx - 3, 0, bz - 1, bx + 4, 0, bz + 1, Blocks.SMOOTH_STONE);
        for (int y = 1; y <= 4; y++) {
            p.set(bx, y, bz - 1, Blocks.IRON_BARS);
            p.set(bx, y, bz + 1, Blocks.IRON_BARS);
        }
        p.set(bx, 5, bz, Blocks.IRON_BLOCK);
        for (int i = -3; i <= 4; i++) p.set(bx + i, i < -1 ? 6 : i > 2 ? 4 : 5, bz, Blocks.GRAY_CONCRETE);   // коромысло замерло с наклоном
        p.set(bx + 4, 3, bz, Blocks.BLACK_CONCRETE);                                                        // «голова»
        p.set(bx + 4, 2, bz, Blocks.CHAIN);
        p.set(bx + 4, 1, bz, Blocks.IRON_BLOCK);
        p.fill(bx - 3, 4, bz, bx - 3, 5, bz, Blocks.BLACK_CONCRETE);                                        // противовес
        p.fill(bx - 2, 1, bz - 1, bx - 2, 2, bz + 1, Blocks.TERRACOTTA);                                    // редуктор
        // лужа нефти у качалки
        for (int i = 0; i < 12; i++) {
            int x = bx + 2 + p.r.nextInt(5), z = bz - 2 + p.r.nextInt(5);
            if (x < W && z > 0 && free(p, x, 1, z)) p.set(x, 0, z, Blocks.BLACK_CONCRETE_POWDER);
        }
        for (int i = 0; i < 3; i++) p.pile(10 + p.r.nextInt(8), 1, 3 + p.r.nextInt(4), Loot.GAS);
        for (int i = 0; i < 5; i++) p.zombie(9 + p.r.nextInt(10), 1, 2 + p.r.nextInt(6), ZombieOutfit.MECHANIC, 1);
        Buildings.car(p, 11, 5, false, "pickup");
        overgrow(p, 1, 1, W - 1, D - 1, 30);
    }

    // ===================== опора ЛЭП =====================
    /** Решётчатая опора высоковольтной линии. Провода оборваны и висят. */
    static void pylon(Plan p) {
        int c = 4, H = 26;
        for (int y = 1; y <= H; y++) {
            int hw = y < 6 ? 3 : y < 13 ? 2 : 1;
            for (int sx = -1; sx <= 1; sx += 2)
                for (int sz = -1; sz <= 1; sz += 2) p.set(c + sx * hw, y, c + sz * hw, Blocks.IRON_BARS);
            if (y % 6 == 0 || y == 5 || y == 12) {                       // пояса жёсткости
                for (int x = c - hw; x <= c + hw; x++) {
                    p.set(x, y, c - hw, Blocks.IRON_BARS);
                    p.set(x, y, c + hw, Blocks.IRON_BARS);
                }
                for (int z = c - hw; z <= c + hw; z++) {
                    p.set(c - hw, y, z, Blocks.IRON_BARS);
                    p.set(c + hw, y, z, Blocks.IRON_BARS);
                }
            }
        }
        for (int[] q : new int[][]{{-3, -3}, {3, -3}, {-3, 3}, {3, 3}}) p.set(c + q[0], 0, c + q[1], Blocks.SMOOTH_STONE);
        // траверсы с гирляндами изоляторов
        for (int y : new int[]{18, 23}) {
            int arm = y == 18 ? 4 : 3;
            for (int x = c - arm; x <= c + arm; x++) p.set(x, y, c, Blocks.IRON_BARS);
            for (int s = -1; s <= 1; s += 2) {
                int x = c + s * arm;
                p.set(x, y - 1, c, Blocks.CHAIN);
                p.set(x, y - 2, c, Blocks.CHAIN);
                if (p.r.nextBoolean()) for (int k = 3; k <= 3 + p.r.nextInt(6); k++) p.set(x, y - k, c, Blocks.CHAIN);   // оборванный провод
            }
        }
        p.set(c, H + 1, c, Blocks.LIGHTNING_ROD);
        // монтёр так и не спустился
        p.pile(c + 1, 1, c, Loot.HARDWARE);
        Wild.blood(p, c, 1, c + 1);
        p.zombie(c - 1, 1, c, ZombieOutfit.CONSTRUCTION, 0);
        overgrow(p, 0, 0, p.w - 1, p.d - 1, 10);
    }

    // ===================== радар =====================
    /** Радарная станция: аппаратная, на крыше — решётчатая чаша антенны. */
    static void radar(Plan p) {
        p.danger = 2;
        int W = p.w - 1, D = p.d - 1;
        Wild.ground(p, 0, 0, W, D, Blocks.GRAVEL, Blocks.COARSE_DIRT, 0.25f);
        fence(p, 0, 0, W, D, 0.1f);
        p.air(9, 1, 0, 11, 2, 0);
        // аппаратная
        int x1 = 5, z1 = 6, x2 = 14, z2 = 13;
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.SMOOTH_STONE);
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++)
                if (x == x1 || x == x2 || z == z1 || z == z2) for (int y = 1; y <= 4; y++) p.set(x, y, z, concrete(p));
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, 4, z2 - 1);
        for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++) p.set(x, 5, z, Blocks.GRAY_CONCRETE);
        p.door(9, 1, z1, Blocks.IRON_DOOR, Direction.NORTH);
        for (int x = x1 + 2; x <= x2 - 2; x += 3) p.set(x, 3, z2, Blocks.GLASS_PANE);
        p.furn(x1 + 1, 1, z2 - 1, "desk", Direction.NORTH);
        p.furn(x1 + 2, 1, z2 - 1, "radio", Direction.NORTH);
        p.furn(x1 + 3, 1, z2 - 1, "desk", Direction.NORTH);
        p.furnLoot(x2 - 1, 1, z2 - 1, "shelf_electronics", Direction.NORTH, Loot.ELECTRONICS);
        p.furnLoot(x2 - 1, 1, z1 + 1, "army_crate", Direction.WEST, Loot.ARMY);
        p.loot(x1 + 1, 1, z1 + 1, Buildings.chest(Direction.EAST), Loot.OFFICE);
        p.note(x1 + 1, 1, z1 + 1, Stories.T_MILITARY);
        p.stashMap(x1 + 1, 1, z1 + 1);
        p.furn(x2 - 1, 1, z1 + 3, "generator", Direction.WEST);
        Houses.ceilingLamp(p, 9, 4, 10);
        // тумба и чаша: смотрит вверх и в сторону
        int cx = 10, cz = 10;
        p.fill(cx - 1, 6, cz - 1, cx, 8, cz, Blocks.LIGHT_GRAY_CONCRETE);
        for (int dx = -5; dx <= 5; dx++)
            for (int dy = -5; dy <= 5; dy++) {
                double r = Math.hypot(dx, dy);
                if (r > 5.3) continue;
                int back = (int) Math.round(r * r / 9.0);                 // параболическая чаша
                int x = cx + dx, y = 13 + dy - back / 2, z = cz + 2 - back;
                boolean rim = r > 4.3;
                if (rim || ((dx + dy) & 1) == 0 || p.r.nextFloat() < 0.2f) p.set(x, y, z, rim ? Blocks.WHITE_CONCRETE : Blocks.IRON_BARS);
            }
        for (int y = 9; y <= 12; y++) p.set(cx, y, cz + 1, Blocks.LIGHT_GRAY_CONCRETE);
        for (int k = 1; k <= 4; k++) p.set(cx, 13, cz + 2 - k - 1, Blocks.IRON_BARS);     // штанга облучателя
        p.set(cx, 13, cz - 4, Blocks.REDSTONE_LAMP);
        // двор
        p.furnLoot(16, 1, 3, "army_crate", Direction.SOUTH, Loot.ARMY);
        p.furn(17, 1, 3, "army_crate", Direction.SOUTH);
        Buildings.car(p, 1, 2, true, "pickup");
        for (int i = 0; i < 5; i++) p.zombie(2 + p.r.nextInt(16), 1, 2 + p.r.nextInt(3), ZombieOutfit.SOLDIER, 2);
        p.zombie(8, 1, 9, ZombieOutfit.SOLDIER, 2);
        p.zombie(11, 1, 11, ZombieOutfit.SOLDIER, 2);
        overgrow(p, 1, 1, W - 1, D - 1, 24);
    }

    // ===================== упавший спутник =====================
    /** Спутник сошёл с орбиты: неглубокая воронка, обгоревший корпус, разбросанные панели батарей. */
    static void satellite(Plan p) {
        int W = p.w - 1, D = p.d - 1, c = 5;
        for (int x = 0; x <= W; x++)
            for (int z = 0; z <= D; z++) {
                double d = Math.hypot(x - c, z - c) + (p.r.nextFloat() - 0.5) * 0.7;
                if (d > 5.2) continue;
                if (d > 3.4) {
                    p.set(x, 0, z, scorched(p));
                    continue;
                }
                int depth = d < 1.8 ? 2 : 1;
                for (int y = 0; y > -depth; y--) p.set(x, y, z, Blocks.AIR);
                p.set(x, -depth, z, scorched(p));
            }
        // корпус
        p.set(c, -1, c, Blocks.IRON_BLOCK);
        p.set(c + 1, -1, c, Blocks.YELLOW_TERRACOTTA);
        p.set(c, 0, c, Blocks.YELLOW_TERRACOTTA);
        p.set(c + 1, 0, c, Blocks.IRON_BLOCK);
        p.set(c, 1, c, Blocks.LIGHTNING_ROD);
        p.set(c + 1, 1, c, Blocks.IRON_BARS);
        // панели солнечных батарей — одна ещё держится, остальные вокруг
        p.set(c - 1, 0, c, Blocks.DAYLIGHT_DETECTOR);
        p.set(c - 2, 0, c, Blocks.DAYLIGHT_DETECTOR);
        for (int i = 0; i < 5; i++) {
            int x = 1 + p.r.nextInt(W - 1), z = 1 + p.r.nextInt(D - 1);
            if (Math.hypot(x - c, z - c) > 3.6 && free(p, x, 1, z) && p.get(x, 0, z) != null) p.set(x, 1, z, Blocks.DAYLIGHT_DETECTOR);
        }
        p.loot(c, -1, c + 1, Buildings.chest(Direction.SOUTH), Loot.ELECTRONICS);
        p.pile(c - 1, -1, c - 1, Loot.ELITE);
        p.note(c, -1, c + 1, -1);
    }
}
