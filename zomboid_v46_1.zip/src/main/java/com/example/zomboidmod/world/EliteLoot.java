package com.example.zomboidmod.world;

import com.example.zomboidmod.PzFoods;
import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.clothing.ClothingLoot;
import com.example.zomboidmod.clothing.ClothingStack;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;

/** Элитный лут опасных зон: военное снаряжение в ящиках и трофеи с Носителя. */
public final class EliteLoot {
    private EliteLoot() {
    }

    private static final String[][] GEAR = {{"vest_army", "0.3"}, {"army_helmet", "0.3"}, {"gas_mask", "0.25"}, {"tactical_gloves", "0.25"},
            {"riot_helmet", "0.1"}, {"army_boots", "0.2"}, {"ghillie_top", "0.06"}, {"ghillie_pants", "0.06"}};

    /** Снаряжение поверх обычных вещей: бронежилеты, шлемы, противогазы. */
    static void extras(Inventory inv, Random r) {
        if (inv.size() == 0) return;
        int put = 0;
        for (String[] g : GEAR) {
            if (put >= 2 || r.nextFloat() >= Float.parseFloat(g[1])) continue;
            ItemStack s = ClothingLoot.make(g[0], r);
            if (s.isEmpty()) continue;
            if (r.nextFloat() < 0.4f) ClothingStack.weather(s, r, r.nextFloat() * 0.3f, r.nextFloat() * 0.4f, 0);
            inv.setStack(r.nextInt(inv.size()), s);
            put++;
        }
    }

    /** Трофеи с Носителя: сыворотка (одна наверняка), элитный лут и старший том книги. */
    public static void bossDrops(PzZombieEntity z, Random r) {
        z.dropStack(new ItemStack(PzFoods.SERUM, 1 + (r.nextFloat() < 0.3f ? 1 : 0)));
        SimpleInventory inv = new SimpleInventory(27);
        for (int i = 0; i < 2; i++) Loot.ELITE.fillAlways(inv, r);
        for (int i = 0; i < inv.size(); i++) {
            ItemStack st = inv.getStack(i);
            if (!st.isEmpty()) z.dropStack(st);
        }
    }
}
