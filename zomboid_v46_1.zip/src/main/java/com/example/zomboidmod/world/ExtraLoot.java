package com.example.zomboidmod.world;

import com.example.zomboidmod.cooking.Cooking;
import com.example.zomboidmod.farm.Farm;
import com.example.zomboidmod.forage.Forage;
import com.example.zomboidmod.media.Media;
import com.example.zomboidmod.metal.Metal;
import com.example.zomboidmod.throwable.Throwables;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/** Лут v43: журналы и кассеты, металл и горелки, семена и огород, приправы, самоделки. */
final class ExtraLoot {
    private ExtraLoot() {
    }

    private record E(java.util.function.Function<Random, Item> item, int min, int max, float chance) {}

    private static final Map<Loot, List<E>> T = new EnumMap<>(Loot.class);

    private static void add(Loot l, Supplier<Item> item, int min, int max, float chance) {
        T.computeIfAbsent(l, k -> new ArrayList<>()).add(new E(rr -> item.get(), min, max, chance));
    }

    /** Случайная вещь из группы (кассета, журнал, семена) — тем же генератором, что и весь контейнер. */
    private static void addR(Loot l, java.util.function.Function<Random, Item> item, int min, int max, float chance) {
        T.computeIfAbsent(l, k -> new ArrayList<>()).add(new E(item, min, max, chance));
    }

    private static Item seeds(Random r) {
        Farm.Crop[] c = Farm.Crop.values();
        return c[r.nextInt(c.length)].seeds;
    }

    private static Item tape(Random r) {
        return Media.TAPES.isEmpty() ? null : Media.TAPES.get(r.nextInt(Media.TAPES.size()));
    }

    private static Item mag(Random r) {
        return Media.MAGAZINES.isEmpty() ? null : Media.MAGAZINES.get(r.nextInt(Media.MAGAZINES.size()));
    }

    private static synchronized void init() {
        if (!T.isEmpty()) return;
        // кухня и продукты
        for (Loot l : new Loot[]{Loot.KITCHEN, Loot.DINER}) {
            add(l, () -> Cooking.SALT, 1, 1, .3f);
            add(l, () -> Cooking.PEPPER, 1, 1, .25f);
            add(l, () -> Cooking.SPICES, 1, 1, .12f);
            add(l, () -> Cooking.OIL, 1, 1, .2f);
            add(l, () -> Cooking.FLOUR, 1, 2, .2f);
        }
        add(Loot.KITCHEN, () -> Cooking.PIE_DISH, 1, 1, .08f);
        add(Loot.KITCHEN, () -> Media.MAG_KITCHEN, 1, 1, .04f);
        add(Loot.DINER, () -> Cooking.CHEESE, 1, 2, .15f);
        add(Loot.FRIDGE, () -> Cooking.CHEESE, 1, 2, .3f);
        for (Farm.Crop c : Farm.Crop.values()) {
            add(Loot.FRIDGE, () -> c.produce, 1, 3, .06f);
            add(Loot.GROCERY, () -> c.produce, 1, 4, .1f);
            add(Loot.GROCERY, () -> c.seeds, 1, 3, .05f);
            add(Loot.HARDWARE, () -> c.seeds, 1, 3, .06f);
            add(Loot.BARN, () -> c.seeds, 2, 5, .15f);
        }
        add(Loot.GROCERY, () -> Cooking.SALT, 1, 2, .3f);
        add(Loot.GROCERY, () -> Cooking.PEPPER, 1, 2, .25f);
        add(Loot.GROCERY, () -> Cooking.SPICES, 1, 1, .15f);
        add(Loot.GROCERY, () -> Cooking.OIL, 1, 2, .3f);
        add(Loot.GROCERY, () -> Cooking.FLOUR, 1, 3, .3f);
        add(Loot.GROCERY, () -> Cooking.CHEESE, 1, 2, .2f);
        add(Loot.GROCERY, () -> Throwables.FIRECRACKERS, 1, 3, .05f);
        add(Loot.GROCERY, () -> Media.MAG_KITCHEN, 1, 1, .04f);
        // огород
        add(Loot.BARN, () -> Farm.WATERING_CAN, 1, 1, .3f);
        add(Loot.BARN, () -> Farm.FERTILIZER, 1, 4, .35f);
        add(Loot.BARN, () -> Farm.PESTICIDE, 1, 1, .2f);
        add(Loot.BARN, () -> Media.MAG_GARDEN, 1, 1, .1f);
        add(Loot.BARN, () -> Metal.PROPANE, 1, 1, .1f);
        add(Loot.BARN, () -> Metal.SCRAP, 1, 4, .2f);
        add(Loot.HARDWARE, () -> Farm.WATERING_CAN, 1, 1, .2f);
        add(Loot.HARDWARE, () -> Farm.FERTILIZER, 1, 3, .2f);
        add(Loot.HARDWARE, () -> Farm.PESTICIDE, 1, 1, .1f);
        add(Loot.HARDWARE, () -> Media.MAG_GARDEN, 1, 1, .06f);
        // металл
        for (Loot l : new Loot[]{Loot.HARDWARE, Loot.GARAGE, Loot.AUTO}) {
            add(l, () -> Metal.BLOWTORCH, 1, 1, l == Loot.HARDWARE ? .2f : .12f);
            add(l, () -> Metal.PROPANE, 1, 1, .2f);
            add(l, () -> Metal.MASK, 1, 1, .12f);
            add(l, () -> Metal.SCREWS, 2, 8, .4f);
            add(l, () -> Metal.WIRE, 1, 4, .3f);
            add(l, () -> Metal.SCRAP, 1, 5, .3f);
            add(l, () -> Metal.SMALL_SHEET, 1, 2, .18f);
            add(l, () -> Metal.SHEET, 1, 1, .1f);
            add(l, () -> Media.MAG_WELDING, 1, 1, .06f);
            add(l, () -> Media.MAG_ENGINEER, 1, 1, .04f);
        }
        add(Loot.GARAGE, () -> Metal.ELECTRONICS, 1, 3, .15f);
        add(Loot.GARAGE, () -> Farm.WATERING_CAN, 1, 1, .1f);
        add(Loot.HARDWARE, () -> Throwables.FIRECRACKERS, 1, 2, .05f);
        add(Loot.HARDWARE, () -> Throwables.NOISE_MAKER, 1, 1, .02f);
        add(Loot.WAREHOUSE, () -> Metal.SCRAP, 2, 6, .3f);
        add(Loot.WAREHOUSE, () -> Metal.SHEET, 1, 2, .15f);
        add(Loot.WAREHOUSE, () -> Metal.SMALL_SHEET, 1, 3, .2f);
        add(Loot.WAREHOUSE, () -> Metal.SCREWS, 2, 8, .3f);
        add(Loot.WAREHOUSE, () -> Metal.WIRE, 1, 4, .2f);
        add(Loot.WAREHOUSE, () -> Metal.PROPANE, 1, 1, .1f);
        add(Loot.WAREHOUSE, () -> Cooking.FLOUR, 1, 4, .15f);
        add(Loot.WAREHOUSE, () -> Cooking.SALT, 1, 3, .15f);
        add(Loot.TRASH, () -> Metal.SCRAP, 1, 2, .2f);
        add(Loot.TRASH, () -> Metal.ELECTRONICS, 1, 1, .1f);
        add(Loot.TRASH, () -> Metal.WIRE, 1, 1, .1f);
        add(Loot.TRASH, () -> Metal.SCREWS, 1, 3, .1f);
        // электроника, кассеты, журналы
        add(Loot.ELECTRONICS, () -> Metal.ELECTRONICS, 1, 4, .5f);
        add(Loot.ELECTRONICS, () -> Metal.WIRE, 1, 4, .4f);
        add(Loot.ELECTRONICS, () -> Metal.SCREWS, 2, 6, .3f);
        add(Loot.ELECTRONICS, () -> Throwables.ALARM_CLOCK, 1, 1, .2f);
        add(Loot.ELECTRONICS, () -> Throwables.NOISE_MAKER, 1, 1, .05f);
        addR(Loot.ELECTRONICS, ExtraLoot::tape, 1, 1, .5f);
        addR(Loot.ELECTRONICS, ExtraLoot::tape, 1, 1, .3f);
        addR(Loot.LIVING, ExtraLoot::tape, 1, 1, .2f);
        add(Loot.LIVING, () -> Throwables.ALARM_CLOCK, 1, 1, .05f);
        addR(Loot.LIVING, ExtraLoot::mag, 1, 1, .08f);
        add(Loot.BEDROOM, () -> Throwables.ALARM_CLOCK, 1, 1, .15f);
        add(Loot.BEDROOM, () -> Media.TAPES.isEmpty() ? null : Media.TAPES.get(Media.TAPES.size() - 1), 1, 1, .06f);
        addR(Loot.BEDROOM, ExtraLoot::mag, 1, 1, .06f);
        add(Loot.BEDROOM, () -> Throwables.FIRECRACKERS, 1, 2, .03f);
        addR(Loot.BOOKS, ExtraLoot::mag, 1, 1, .6f);
        addR(Loot.BOOKS, ExtraLoot::mag, 1, 1, .4f);
        addR(Loot.BOOKS, ExtraLoot::tape, 1, 1, .2f);
        addR(Loot.OFFICE, ExtraLoot::mag, 1, 1, .08f);
        addR(Loot.SCHOOL, ExtraLoot::tape, 1, 1, .1f);
        add(Loot.SCHOOL, () -> Media.MAG_HERBAL, 1, 1, .05f);
        add(Loot.PHARMACY, () -> Media.MAG_HERBAL, 1, 1, .05f);
        add(Loot.GAS, () -> Metal.PROPANE, 1, 1, .2f);
        add(Loot.GAS, () -> Throwables.FIRECRACKERS, 1, 2, .05f);
        add(Loot.LIQUOR, () -> Throwables.FIRECRACKERS, 1, 3, .1f);
        add(Loot.SPORTS, () -> Throwables.FIRECRACKERS, 1, 2, .05f);
        // лес и выживание
        add(Loot.CABIN, () -> Media.MAG_HERBAL, 1, 1, .1f);
        add(Loot.CABIN, () -> Forage.MORTAR, 1, 1, .12f);
        add(Loot.CABIN, () -> Cooking.SALT, 1, 2, .2f);
        add(Loot.CABIN, () -> Forage.HAZELNUTS, 2, 8, .15f);
        // порох: для патронов, бомб и петард
        add(Loot.GUNSTORE, () -> net.minecraft.item.Items.GUNPOWDER, 2, 6, .45f);
        add(Loot.HARDWARE, () -> net.minecraft.item.Items.GUNPOWDER, 1, 3, .1f);
        add(Loot.POLICE, () -> net.minecraft.item.Items.GUNPOWDER, 1, 3, .1f);
        add(Loot.ARMY, () -> net.minecraft.item.Items.GUNPOWDER, 2, 5, .25f);
        add(Loot.SPORTS, () -> net.minecraft.item.Items.GUNPOWDER, 1, 3, .1f);
        // военные и опасные места
        add(Loot.ARMY, () -> Throwables.SMOKE_BOMB, 1, 2, .2f);
        add(Loot.ARMY, () -> Throwables.PIPE_BOMB, 1, 1, .06f);
        add(Loot.ARMY, () -> Media.MAG_ENGINEER, 1, 1, .08f);
        add(Loot.POLICE, () -> Throwables.SMOKE_BOMB, 1, 2, .15f);
        add(Loot.STASH, () -> Throwables.MOLOTOV, 1, 2, .12f);
        add(Loot.STASH, () -> Throwables.PIPE_BOMB, 1, 1, .05f);
        add(Loot.STASH, () -> Throwables.SMOKE_BOMB, 1, 1, .1f);
        add(Loot.STASH, () -> Throwables.NOISE_MAKER, 1, 1, .06f);
        add(Loot.STASH, () -> Media.MAG_ENGINEER, 1, 1, .08f);
        addR(Loot.STASH, ExtraLoot::seeds, 2, 5, .2f);
        add(Loot.ELITE, () -> Throwables.PIPE_BOMB, 1, 2, .2f);
        add(Loot.ELITE, () -> Throwables.SMOKE_BOMB, 1, 2, .2f);
        add(Loot.ELITE, () -> Media.MAG_ENGINEER, 1, 1, .15f);
        add(Loot.ELITE, () -> Media.MAG_WELDING, 1, 1, .1f);
        add(Loot.ELITE, () -> Metal.CAR_ARMOR, 1, 1, .05f);
    }

    /** Докладывает новые вещи в уже наполненный контейнер (в свободные места, если есть). */
    static void fill(Loot l, Inventory inv, Random r, float cm) {
        init();
        List<E> list = T.get(l);
        if (list == null) return;
        for (E e : list) {
            if (r.nextFloat() >= Math.min(1f, e.chance() * cm)) continue;
            Item item = e.item().apply(r);
            if (item == null) continue;
            int n = e.min() + (e.max() > e.min() ? r.nextInt(e.max() - e.min() + 1) : 0);
            ItemStack st = new ItemStack(item, Math.min(n, item.getMaxCount()));
            int slot = -1;
            for (int k = 0; k < 6 && slot < 0; k++) {
                int s = r.nextInt(inv.size());
                if (inv.getStack(s).isEmpty()) slot = s;
            }
            if (slot < 0) continue;   // места нет — не вытесняем основной лут
            inv.setStack(slot, st);
        }
    }
}
