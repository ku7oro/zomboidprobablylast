package com.example.zomboidmod.sandbox;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public final class SandboxClient {
    private SandboxClient() {
    }

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(Sandbox.OpenPayload.ID, (pl, ctx) -> ctx.client().setScreen(new SandboxScreen(pl.data())));
    }
}
