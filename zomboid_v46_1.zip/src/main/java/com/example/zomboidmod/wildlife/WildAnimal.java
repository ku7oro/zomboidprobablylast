package com.example.zomboidmod.wildlife;

import com.example.zomboidmod.hunting.CorpseEntity;
import com.example.zomboidmod.hunting.Game;
import com.example.zomboidmod.hunting.Tracks;
import com.example.zomboidmod.nature.Climate;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.NoPenaltyTargeting;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;

/**
 * Дикий зверь, как в PZ B42: пугается шума (выстрел слышно далеко), замечает игрока глазами и носом —
 * подходить надо крадучись и против ветра. Раненый зверь убегает и истекает кровью, оставляя след из капель;
 * на мягкой земле и в снегу видны отпечатки. Крупный зверь после смерти остаётся тушей.
 */
public abstract class WildAnimal extends AnimalEntity {
    private int bleed;
    private BlockPos fleeFrom;
    private int fleeTicks;

    protected WildAnimal(EntityType<? extends AnimalEntity> type, World world) {
        super(type, world);
    }

    /** Чей след оставляет (Tracks.*). */
    protected abstract int trackKind();

    /** Какая туша останется (null — без туши, по таблице добычи). */
    protected abstract @Nullable Game.Big corpse();

    /** Скорость бегства. */
    protected double fleeSpeed() {
        return 1.9;
    }

    /**
     * Заметил ли игрока: глазами (на открытом месте, крадущегося — втрое ближе, ночью хуже)
     * или носом — если ветер дует от игрока к зверю.
     */
    public boolean notices(PlayerEntity p, float sight) {
        if (p.isCreative() || p.isSpectator() || !p.isAlive()) return false;
        double d = distanceTo(p);
        float s = sight * (p.isSneaking() ? 0.35f : 1f);
        long tod = Math.floorMod(getWorld().getTimeOfDay(), 24000L);
        if (tod > 13000 && tod < 23000) s *= 0.65f;
        if (p.getVelocity().horizontalLengthSquared() > 0.04) s *= 1.3f;   // бегущего видно издалека
        if (d < s && canSee(p)) return true;
        double dx = getX() - p.getX(), dz = getZ() - p.getZ();
        double len = Math.max(0.01, Math.hypot(dx, dz));
        double[] wv = Climate.windVector();
        double along = (dx * wv[0] + dz * wv[1]) / len;          // > 0 — зверь с подветренной стороны
        double scent = 3.5 + Math.max(0, along) * (8 + 26 * Climate.wind) + (p.isSneaking() ? 0 : 1.5);
        return d < scent;
    }

    /** Испугаться шума/опасности в точке. */
    public void startle(BlockPos from, int ticks) {
        fleeFrom = from;
        fleeTicks = Math.max(fleeTicks, ticks);
    }

    /** Шум (выстрел, крик, мотор) пугает зверей вдвое дальше, чем его слышат зомби. */
    public static void hear(ServerWorld w, BlockPos pos, int radius) {
        if (radius <= 2) return;
        int r = (int) (radius * 1.5f);
        for (WildAnimal a : w.getEntitiesByClass(WildAnimal.class, new Box(pos).expand(r), Entity::isAlive))
            a.startle(pos, 100 + radius * 6);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new FleeNoiseGoal());
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        boolean hurt = super.damage(source, amount);
        if (hurt && !getWorld().isClient && isAlive() && amount >= 1.5f) {
            bleed = Math.max(bleed, (int) (200 + amount * 80));
            if (getHealth() < getMaxHealth() * 0.5f) bleed = Math.max(bleed, 20 * 150);   // тяжело ранен — долго истекает кровью
            Entity a = source.getAttacker();
            startle(a != null ? a.getBlockPos() : getBlockPos(), 200);
        }
        return hurt;
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient || !(getWorld() instanceof ServerWorld w) || !isAlive()) return;
        if (fleeTicks > 0) fleeTicks--;
        boolean moving = getVelocity().horizontalLengthSquared() > 0.0015;
        if (bleed > 0) {
            bleed--;
            if (age % 14 == 0 && isOnGround()) Tracks.leave(w, getBlockPos(), Tracks.BLOOD, getHorizontalFacing());
            if (age % 80 == 0 && getHealth() < getMaxHealth() * 0.5f) damage(getDamageSources().generic(), 1f);
        }
        if (moving && isOnGround() && age % 24 == 0 && random.nextFloat() < 0.55f)
            Tracks.leave(w, getBlockPos(), trackKind(), getHorizontalFacing());
    }

    /** Крупный зверь не исчезает с облачком, а остаётся тушей. */
    @Override
    protected void updatePostDeath() {
        Game.Big c = corpse();
        if (c == null) {
            super.updatePostDeath();
            return;
        }
        ++this.deathTime;
        if (this.deathTime >= 20 && !getWorld().isClient() && !isRemoved()) {
            if (getWorld() instanceof ServerWorld w) CorpseEntity.spawn(w, getX(), getY(), getZ(), bodyYaw, c);
            this.remove(Entity.RemovalReason.KILLED);
        }
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return false;
    }

    @Override
    public @Nullable PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Bleed", bleed);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        bleed = nbt.getInt("Bleed");
    }

    /** Бегство от шума: в сторону от источника. */
    final class FleeNoiseGoal extends Goal {
        FleeNoiseGoal() {
            setControls(EnumSet.of(Goal.Control.MOVE));
        }

        @Override
        public boolean canStart() {
            return fleeTicks > 0 && fleeFrom != null;
        }

        @Override
        public void start() {
            run();
        }

        @Override
        public boolean shouldContinue() {
            return fleeTicks > 0;
        }

        @Override
        public void tick() {
            if (getNavigation().isIdle()) run();
        }

        private void run() {
            Vec3d t = NoPenaltyTargeting.findFrom(WildAnimal.this, 20, 7, Vec3d.ofCenter(fleeFrom));
            if (t != null) getNavigation().startMovingTo(t.x, t.y, t.z, fleeSpeed());
        }
    }
}
