package com.example.zomboidmod.wildlife;

import com.example.zomboidmod.hunting.Game;
import com.example.zomboidmod.hunting.Tracks;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.FleeEntityGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Кабан (одичавшие свиньи водятся в лесах Кентукки): осторожен, но если подойти вплотную не таясь
 * или ранить — бросается и бьёт клыками. Тяжело раненый удирает. Даёт тушу: свинину, шкуру, жир.
 */
public class BoarEntity extends WildAnimal {
    public BoarEntity(EntityType<? extends AnimalEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder attributes() {
        return MobEntity.createMobAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 22.0).add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.27)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 4.0).add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.4)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 20.0);
    }

    private boolean weak() {
        return getHealth() < getMaxHealth() * 0.3f;
    }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.6, true));
        this.goalSelector.add(2, new FleeEntityGoal<>(this, PlayerEntity.class, 24f, 1.5, 2.0,
                e -> weak() && e instanceof PlayerEntity p && notices(p, 18f)));
        this.goalSelector.add(3, new FleeEntityGoal<>(this, ZombieEntity.class, 10f, 1.4, 1.9));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.85));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8f));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        // слишком близко и не таясь — нападает
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, 10, true, false,
                e -> e instanceof PlayerEntity p && !weak() && !p.isSneaking() && !p.isCreative() && !p.isSpectator() && distanceTo(p) < 5f));
    }

    @Override
    protected int trackKind() {
        return Tracks.BOAR;
    }

    @Override
    protected Game.Big corpse() {
        return Game.Big.BOAR;
    }

    @Override
    protected double fleeSpeed() {
        return 1.7;
    }

    @Override
    public int getMinAmbientSoundDelay() {
        return 260;
    }

    @Override
    protected @Nullable SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_HOGLIN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_HOGLIN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_HOGLIN_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(SoundEvents.ENTITY_HOGLIN_STEP, 0.15f, 1.1f);
    }

    @Override
    public float getSoundPitch() {
        return 1.15f + (random.nextFloat() - 0.5f) * 0.15f;
    }
}
