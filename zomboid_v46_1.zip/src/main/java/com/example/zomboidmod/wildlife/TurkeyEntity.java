package com.example.zomboidmod.wildlife;

import com.example.zomboidmod.hunting.Game;
import com.example.zomboidmod.hunting.Tracks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.EscapeDangerGoal;
import net.minecraft.entity.ai.goal.FleeEntityGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Дикая индейка: ходит стайками по опушкам, пугливая, срывается и перелетает, планируя. */
public class TurkeyEntity extends WildAnimal {
    public float flap, prevFlap;

    public TurkeyEntity(EntityType<? extends AnimalEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder attributes() {
        return MobEntity.createMobAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 10.0).add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25);
    }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new EscapeDangerGoal(this, 2.0));
        this.goalSelector.add(2, new FleeEntityGoal<>(this, PlayerEntity.class, 32f, 1.5, 2.1,
                e -> e instanceof PlayerEntity p && notices(p, 16f)));
        this.goalSelector.add(3, new FleeEntityGoal<>(this, ZombieEntity.class, 10f, 1.4, 2.0));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8f));
        this.goalSelector.add(7, new LookAroundGoal(this));
    }

    @Override
    public void tickMovement() {
        super.tickMovement();
        prevFlap = flap;
        boolean air = !isOnGround();
        flap += ((air ? 1f : 0f) - flap) * 0.3f;
        if (air && getVelocity().y < 0) setVelocity(getVelocity().multiply(1.0, 0.6, 1.0));   // планирует
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        return false;
    }

    @Override
    protected int trackKind() {
        return Tracks.BIRD;
    }

    @Override
    protected @Nullable Game.Big corpse() {
        return null;
    }

    @Override
    public int getMinAmbientSoundDelay() {
        return 200;
    }

    @Override
    protected @Nullable SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_CHICKEN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_CHICKEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_CHICKEN_DEATH;
    }

    @Override
    public float getSoundPitch() {
        return 0.6f + (random.nextFloat() - 0.5f) * 0.1f;
    }
}
