package com.example.zomboidmod.wildlife;

import com.example.zomboidmod.ZomboidMod;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class BoarRenderer extends MobEntityRenderer<BoarEntity, BoarModel> {
    private static final Identifier TEX = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/boar.png");

    public BoarRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new BoarModel(BoarModel.create().createModel()), 0.6f);
    }

    @Override
    public Identifier getTexture(BoarEntity entity) {
        return TEX;
    }
}
