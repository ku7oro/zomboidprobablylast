package com.example.zomboidmod.wildlife;

import com.example.zomboidmod.ZomboidMod;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class TurkeyRenderer extends MobEntityRenderer<TurkeyEntity, TurkeyModel> {
    private static final Identifier TEX = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/turkey.png");

    public TurkeyRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new TurkeyModel(TurkeyModel.create().createModel()), 0.35f);
    }

    @Override
    public Identifier getTexture(TurkeyEntity entity) {
        return TEX;
    }
}
