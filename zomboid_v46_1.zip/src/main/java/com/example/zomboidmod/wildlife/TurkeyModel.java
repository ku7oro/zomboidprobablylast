package com.example.zomboidmod.wildlife;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/** Модель дикой индейки: шаг с кивком, хлопанье крыльями, веер хвоста (сгенерировано gen_animals.py). */
public class TurkeyModel extends SinglePartEntityModel<TurkeyEntity> {
    private final ModelPart root, body, fan, wing0, wing1, neck, head, leg0, leg1;

    public TurkeyModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.fan = body.getChild("fan");
        this.wing0 = body.getChild("wing0");
        this.wing1 = body.getChild("wing1");
        this.neck = body.getChild("neck");
        this.head = neck.getChild("head");
        this.leg0 = root.getChild("leg0");
        this.leg1 = root.getChild("leg1");
    }

    public static TexturedModelData create() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        ModelPartData p_body = root.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-3.5f, -4f, -5f, 7, 8, 10), ModelTransform.of(0f, 13f, 0f, 0f, 0f, 0f));
        ModelPartData p_fan = p_body.addChild("fan", ModelPartBuilder.create().uv(34, 0).cuboid(-6f, -10f, 0f, 12, 10, 1), ModelTransform.of(0f, -2f, 5f, -0.35f, 0f, 0f));
        ModelPartData p_wing0 = p_body.addChild("wing0", ModelPartBuilder.create().uv(0, 18).cuboid(-1f, 0f, 0f, 1, 5, 8), ModelTransform.of(-3.5f, -2f, -3f, 0f, 0f, 0f));
        ModelPartData p_wing1 = p_body.addChild("wing1", ModelPartBuilder.create().uv(18, 18).cuboid(0f, 0f, 0f, 1, 5, 8), ModelTransform.of(3.5f, -2f, -3f, 0f, 0f, 0f));
        ModelPartData p_neck = p_body.addChild("neck", ModelPartBuilder.create().uv(36, 18).cuboid(-1f, -6f, -1f, 2, 7, 2), ModelTransform.of(0f, -3f, -4f, 0.25f, 0f, 0f));
        ModelPartData p_head = p_neck.addChild("head", ModelPartBuilder.create().uv(44, 18).cuboid(-1f, -2f, -2f, 2, 2, 3).uv(54, 18).cuboid(-0.5f, -1.5f, -3f, 1, 1, 1).uv(58, 18).cuboid(-0.5f, -2.5f, -2.5f, 1, 3, 1).uv(0, 31).cuboid(-0.5f, 0f, -1.5f, 1, 2, 1), ModelTransform.of(0f, -6f, 0f, -0.25f, 0f, 0f));
        ModelPartData p_leg0 = root.addChild("leg0", ModelPartBuilder.create().uv(4, 31).cuboid(-0.5f, 0f, -0.5f, 1, 7, 1).uv(8, 31).cuboid(-1f, 6.5f, -2f, 2, 0, 3), ModelTransform.of(-1.5f, 17f, 1f, 0f, 0f, 0f));
        ModelPartData p_leg1 = root.addChild("leg1", ModelPartBuilder.create().uv(18, 31).cuboid(-0.5f, 0f, -0.5f, 1, 7, 1).uv(22, 31).cuboid(-1f, 6.5f, -2f, 2, 0, 3), ModelTransform.of(1.5f, 17f, 1f, 0f, 0f, 0f));
        return TexturedModelData.of(md, 64, 64);
    }

    @Override
    public ModelPart getPart() {
        return root;
    }

    @Override
    public void setAngles(TurkeyEntity e, float limbAngle, float limbDistance, float age, float headYaw, float headPitch) {
        float k = 1.4f * limbDistance;
        leg0.pitch = MathHelper.cos(limbAngle * 0.9f) * k;
        leg1.pitch = MathHelper.cos(limbAngle * 0.9f + MathHelper.PI) * k;
        float f = MathHelper.lerp(MathHelper.clamp(age - e.age, 0f, 1f), e.prevFlap, e.flap);
        wing0.roll = f * (0.4f + MathHelper.sin(age * 1.6f) * 0.9f);
        wing1.roll = -wing0.roll;
        neck.pitch = 0.25f + MathHelper.sin(limbAngle * 0.9f) * 0.25f * limbDistance + headPitch * MathHelper.RADIANS_PER_DEGREE * 0.4f;
        neck.yaw = headYaw * MathHelper.RADIANS_PER_DEGREE * 0.5f;
        head.pitch = -0.25f + headPitch * MathHelper.RADIANS_PER_DEGREE * 0.3f;
        fan.pitch = -0.35f - 0.25f * (1f - limbDistance);
    }
}
