package com.example.zomboidmod.wildlife;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/** Модель кабана: шаг, поворот головы, хвост виляет (сгенерировано gen_animals.py). */
public class BoarModel extends SinglePartEntityModel<BoarEntity> {
    private final ModelPart root, body, head, tail, leg0, leg1, leg2, leg3;

    public BoarModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = body.getChild("head");
        this.tail = body.getChild("tail");
        this.leg0 = root.getChild("leg0");
        this.leg1 = root.getChild("leg1");
        this.leg2 = root.getChild("leg2");
        this.leg3 = root.getChild("leg3");
    }

    public static TexturedModelData create() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        ModelPartData p_body = root.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-5f, -5f, -8f, 10, 10, 16).uv(0, 26).cuboid(-1.5f, -6.5f, -7f, 3, 2, 12), ModelTransform.of(0f, 13f, 0f, 0f, 0f, 0f));
        ModelPartData p_head = p_body.addChild("head", ModelPartBuilder.create().uv(30, 26).cuboid(-4f, -4f, -6f, 8, 8, 6).uv(0, 40).cuboid(-2.5f, -1f, -9f, 5, 4, 3).uv(16, 40).cuboid(-4f, -6.5f, -2f, 2, 3, 1).uv(22, 40).cuboid(2f, -6.5f, -2f, 2, 3, 1).uv(28, 40).cuboid(-3.5f, 1f, -8.5f, 1, 2, 1).uv(32, 40).cuboid(2.5f, 1f, -8.5f, 1, 2, 1), ModelTransform.of(0f, -1f, -8f, 0.1f, 0f, 0f));
        ModelPartData p_tail = p_body.addChild("tail", ModelPartBuilder.create().uv(36, 40).cuboid(-0.5f, 0f, 0f, 1, 5, 1), ModelTransform.of(0f, -3f, 8f, 0.4f, 0f, 0f));
        ModelPartData p_leg0 = root.addChild("leg0", ModelPartBuilder.create().uv(40, 40).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3), ModelTransform.of(-3f, 18f, -5f, 0f, 0f, 0f));
        ModelPartData p_leg1 = root.addChild("leg1", ModelPartBuilder.create().uv(52, 40).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3), ModelTransform.of(3f, 18f, -5f, 0f, 0f, 0f));
        ModelPartData p_leg2 = root.addChild("leg2", ModelPartBuilder.create().uv(0, 49).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3), ModelTransform.of(-3f, 18f, 5f, 0f, 0f, 0f));
        ModelPartData p_leg3 = root.addChild("leg3", ModelPartBuilder.create().uv(12, 49).cuboid(-1.5f, 0f, -1.5f, 3, 6, 3), ModelTransform.of(3f, 18f, 5f, 0f, 0f, 0f));
        return TexturedModelData.of(md, 64, 64);
    }

    @Override
    public ModelPart getPart() {
        return root;
    }

    @Override
    public void setAngles(BoarEntity e, float limbAngle, float limbDistance, float age, float headYaw, float headPitch) {
        float k = 1.3f * limbDistance;
        leg0.pitch = MathHelper.cos(limbAngle * 0.9f) * k;
        leg3.pitch = MathHelper.cos(limbAngle * 0.9f) * k;
        leg1.pitch = MathHelper.cos(limbAngle * 0.9f + MathHelper.PI) * k;
        leg2.pitch = MathHelper.cos(limbAngle * 0.9f + MathHelper.PI) * k;
        head.pitch = 0.1f + headPitch * MathHelper.RADIANS_PER_DEGREE * 0.6f;
        head.yaw = headYaw * MathHelper.RADIANS_PER_DEGREE * 0.6f;
        tail.yaw = MathHelper.sin(age * 0.25f) * 0.25f;
    }
}
