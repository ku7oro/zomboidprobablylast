package com.example.zomboidmod.life;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtIntArray;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * «Живой мир»: тела мертвецов, сигнализации в домах и магазинах, события вокруг игрока
 * (далёкие перестрелки, крики, взрывы, выживший в беде, стычки бандитов, проходящие толпы).
 */
public final class Life {
    private Life() {
    }

    public static EntityType<BodyEntity> BODY;
    public static SoundEvent FLIES, HOUSE_ALARM, CAR_ALARM, EXPLOSION_FAR;

    private static SoundEvent sound(String id) {
        Identifier i = Identifier.of(ZomboidMod.MOD_ID, id);
        return Registry.register(Registries.SOUND_EVENT, i, SoundEvent.of(i));
    }

    public static void register() {
        BODY = Registry.register(Registries.ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, "body"),
                EntityType.Builder.<BodyEntity>create(BodyEntity::new, SpawnGroup.MISC).dimensions(1.2f, 0.35f).maxTrackingRange(8).build("body"));
        FLIES = sound("flies");
        HOUSE_ALARM = sound("house_alarm");
        CAR_ALARM = sound("car_alarm");
        EXPLOSION_FAR = sound("explosion_far");

        // сигнализация: открыл дверь или разбил окно в доме под охраной
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.isClient && hand == Hand.MAIN_HAND && world instanceof ServerWorld sw
                    && world.getBlockState(hit.getBlockPos()).getBlock() instanceof DoorBlock)
                tryAlarm(sw, hit.getBlockPos(), player);
            return ActionResult.PASS;
        });
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (world instanceof ServerWorld sw && (glass(state) || state.getBlock() instanceof DoorBlock)) tryAlarm(sw, pos, player);
        });
        ServerTickEvents.END_SERVER_TICK.register(Life::tick);
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> {
            ACTIVE.clear();
            Encounters.reset();
        });
        Encounters.register();
    }

    static boolean glass(BlockState s) {
        String id = Registries.BLOCK.getId(s.getBlock()).getPath();
        return id.contains("glass") || id.contains("window");
    }

    // =====================================================================================
    //                                  сигнализации
    // =====================================================================================

    /** Здания под сигнализацией: {x1, y1, z1, x2, y2, z2} в мире. */
    public static final class State extends PersistentState {
        final List<int[]> alarms = new ArrayList<>();

        private static final PersistentState.Type<State> TYPE = new PersistentState.Type<>(State::new, State::fromNbt, null);

        public static State get(MinecraftServer server) {
            return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, "zomboidmod_life");
        }

        @Override
        public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
            NbtList l = new NbtList();
            for (int[] a : alarms) l.add(new NbtIntArray(a));
            nbt.put("alarms", l);
            return nbt;
        }

        static State fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
            State s = new State();
            NbtList l = nbt.getList("alarms", NbtElement.INT_ARRAY_TYPE);
            for (int i = 0; i < l.size(); i++) {
                int[] a = l.getIntArray(i);
                if (a.length == 6) s.alarms.add(a);
            }
            return s;
        }
    }

    /** Здание поставлено в мир с сигнализацией (вызывается при постройке города). */
    public static void addAlarm(ServerWorld w, int x1, int y1, int z1, int x2, int y2, int z2) {
        State st = State.get(w.getServer());
        st.alarms.add(new int[]{Math.min(x1, x2), Math.min(y1, y2), Math.min(z1, z2), Math.max(x1, x2), Math.max(y1, y2), Math.max(z1, z2)});
        st.markDirty();
    }

    private record Active(ServerWorld w, BlockPos pos, int[] left) {}

    private static final List<Active> ACTIVE = new ArrayList<>();

    /** Если тут дом под охраной и в сети есть ток — включить сирену (один раз на здание). */
    static void tryAlarm(ServerWorld w, BlockPos pos, PlayerEntity player) {
        if (!com.example.zomboidmod.survival.Power.gridOn(w)) return;   // без электричества сигнализации молчат
        State st = State.get(w.getServer());
        for (Iterator<int[]> it = st.alarms.iterator(); it.hasNext(); ) {
            int[] a = it.next();
            if (pos.getX() < a[0] - 1 || pos.getX() > a[3] + 1 || pos.getZ() < a[2] - 1 || pos.getZ() > a[5] + 1
                    || pos.getY() < a[1] || pos.getY() > a[4]) continue;
            it.remove();
            st.markDirty();
            ACTIVE.add(new Active(w, pos.toImmutable(), new int[]{1200}));
            if (player instanceof ServerPlayerEntity sp) {
                sp.sendMessage(Text.literal("Сработала сигнализация! Сейчас сюда сбегутся мертвецы").formatted(Formatting.RED), true);
                com.example.zomboidmod.survival.Mood m = com.example.zomboidmod.survival.Survival.mood(sp);
                m.panic = Math.min(100f, m.panic + 15f);
            }
            return;
        }
    }

    private static void tick(MinecraftServer server) {
        for (Iterator<Active> it = ACTIVE.iterator(); it.hasNext(); ) {
            Active a = it.next();
            int left = --a.left()[0];
            if (left % 40 == 0) a.w().playSound(null, a.pos(), HOUSE_ALARM, SoundCategory.BLOCKS, 6f, 1f);
            if (left % 80 == 0) Noise.emitAt(a.w(), a.pos(), 72);
            if (left <= 0) it.remove();
        }
        Encounters.tick(server);
    }
}
