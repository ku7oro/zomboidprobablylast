package com.example.zomboidmod.life;

import com.example.zomboidmod.survival.Clock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Тело мертвеца (как в PZ): убитые зомби и люди не исчезают, а остаются лежать. Их можно обыскать (ПКМ) —
 * вещи теперь в теле, а не россыпью на земле. Свежие тела привлекают мертвецов (едят), гниющие — мух.
 * Через несколько дней тело разлагается и исчезает вместе с вещами. Старые тела, лежавшие в мире до
 * прихода игрока, не исчезают.
 */
public class BodyEntity extends Entity {
    /** Внешность: у зомби — вариант (одежда | тон << 8 | повадки << 16), у людей — -(номер скина + 1). */
    private static final TrackedData<Integer> LOOK = DataTracker.registerData(BodyEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> POSE = DataTracker.registerData(BodyEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Float> ROT = DataTracker.registerData(BodyEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Optional<UUID>> SKIN = DataTracker.registerData(BodyEntity.class, TrackedDataHandlerRegistry.OPTIONAL_UUID);
    /** Чего у тела не хватает (биты combat.Limbs): отрубленные руки, ноги, голова. */
    private static final TrackedData<Integer> LIMBS = DataTracker.registerData(BodyEntity.class, TrackedDataHandlerRegistry.INTEGER);

    /** Сколько дней тело лежит до полного разложения. */
    public static final float DAYS = 4f;
    /** Не больше стольких тел в радиусе 32 блоков (лишние — самые старые — убираются). */
    private static final int CAP = 40;

    private final SimpleInventory inv = new SimpleInventory(27) {
        @Override
        public boolean canPlayerUse(PlayerEntity player) {
            return BodyEntity.this.isAlive() && player.squaredDistanceTo(BodyEntity.this) < 36;
        }
    };
    private long died = -1;
    /** Лежало в мире изначально: не гниёт дальше и не исчезает. */
    private boolean old;

    public BodyEntity(EntityType<? extends BodyEntity> type, World world) {
        super(type, world);
    }

    /** Положить тело с вещами. */
    public static BodyEntity spawn(ServerWorld w, double x, double y, double z, float yaw, int look, UUID skin, List<ItemStack> loot, boolean old) {
        BodyEntity b = new BodyEntity(Life.BODY, w);
        b.refreshPositionAndAngles(x, y, z, yaw, 0f);
        b.dataTracker.set(LOOK, look);
        b.dataTracker.set(SKIN, Optional.ofNullable(skin));
        b.dataTracker.set(POSE, w.getRandom().nextInt(4));
        b.old = old;
        b.died = Clock.now(w);
        if (old) b.dataTracker.set(ROT, 0.35f + w.getRandom().nextFloat() * 0.35f);
        int slot = 0;
        for (ItemStack s : loot) {
            if (s.isEmpty() || slot >= b.inv.size()) continue;
            b.inv.setStack(slot++, s);
        }
        cap(w, b);
        w.spawnEntity(b);
        return b;
    }

    /** Ограничение числа тел рядом: убрать самые старые (кроме лежавших изначально). */
    private static void cap(ServerWorld w, BodyEntity fresh) {
        List<BodyEntity> near = w.getEntitiesByClass(BodyEntity.class, fresh.getBoundingBox().expand(32), e -> e.isAlive() && !e.old);
        if (near.size() < CAP) return;
        near.sort((a, b) -> Long.compare(a.died, b.died));
        for (int i = 0; i <= near.size() - CAP; i++) near.get(i).discard();
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(LOOK, 0);
        builder.add(POSE, 0);
        builder.add(ROT, 0f);
        builder.add(SKIN, Optional.empty());
        builder.add(LIMBS, 0);
    }

    public void setLimbs(int limbs) {
        dataTracker.set(LIMBS, limbs);
    }

    public int limbs() {
        return dataTracker.get(LIMBS);
    }

    public int look() {
        return dataTracker.get(LOOK);
    }

    /** Поза, в которой тело осталось после падения: навзничь (0-1) или ничком (2-3), по внешности. */
    public static int fallPose(UUID id, boolean faceDown) {
        return (faceDown ? 2 : 0) + (int) ((id.getLeastSignificantBits() >>> 3) & 1);
    }

    /** Выживший падает ничком или навзничь — по внешности (чтобы клиент и сервер совпали без лишних пакетов). */
    public static boolean survivorFace(UUID id) {
        return ((id.getMostSignificantBits() >>> 7) & 1) == 1;
    }

    public void setFallPose(int pose) {
        dataTracker.set(POSE, pose);
    }

    public int pose() {
        return dataTracker.get(POSE);
    }

    /** 0 — свежее, 1 — почти разложилось. */
    public float rot() {
        return dataTracker.get(ROT);
    }

    public UUID skin() {
        return dataTracker.get(SKIN).orElse(getUuid());
    }

    /** Свежее тело — мертвецы его чуют и едят. */
    public boolean fresh() {
        return !old && rot() < 0.6f;
    }

    public boolean isEmpty() {
        return inv.isEmpty();
    }

    @Override
    public void tick() {
        super.tick();
        if (!hasNoGravity()) setVelocity(getVelocity().add(0, -0.04, 0));
        move(MovementType.SELF, getVelocity());
        setVelocity(getVelocity().multiply(isOnGround() ? 0.5 : 0.98, 0.98, isOnGround() ? 0.5 : 0.98));
        World w = getWorld();
        if (w.isClient) {
            // мухи над гниющим телом
            float r = rot();
            if (r > 0.2f && random.nextFloat() < 0.12f * r)
                w.addParticle(ParticleTypes.MYCELIUM, getX() + (random.nextDouble() - 0.5) * 1.2, getY() + 0.3 + random.nextDouble() * 0.6,
                        getZ() + (random.nextDouble() - 0.5) * 1.2, 0, 0, 0);
            if (r > 0.25f && random.nextInt(500) == 0)
                w.playSound(getX(), getY(), getZ(), Life.FLIES, SoundCategory.NEUTRAL, 0.35f, 0.9f + random.nextFloat() * 0.2f, false);
            return;
        }
        if (isInLava() || getY() < w.getBottomY() - 8) {
            discard();
            return;
        }
        if (age % 100 != 0 || old) return;
        long now = Clock.now(w);
        if (died < 0) died = now;
        float days = (now - died) / (float) Clock.DAY;
        dataTracker.set(ROT, Math.min(1f, Math.max(0f, days / DAYS)));
        if (days > DAYS) discard();
    }

    @Override
    public boolean canHit() {
        return true;
    }

    @Override
    public boolean isCollidable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return false;
    }

    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        if (hand != Hand.MAIN_HAND) return ActionResult.PASS;
        if (getWorld().isClient) return ActionResult.SUCCESS;
        getWorld().playSound(null, getBlockPos(), SoundEvents.ITEM_BUNDLE_REMOVE_ONE, SoundCategory.PLAYERS, 0.8f, 0.7f);
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, pinv, p) -> GenericContainerScreenHandler.createGeneric9x3(syncId, pinv, inv),
                Text.literal(look() < 0 ? "Тело человека" : "Тело мертвеца")));
        return ActionResult.CONSUME;
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        dataTracker.set(LOOK, nbt.getInt("Look"));
        dataTracker.set(POSE, nbt.getInt("Pose"));
        dataTracker.set(ROT, nbt.getFloat("Rot"));
        dataTracker.set(LIMBS, nbt.getInt("Limbs"));
        if (nbt.containsUuid("Skin")) dataTracker.set(SKIN, Optional.of(nbt.getUuid("Skin")));
        died = nbt.contains("Died") ? nbt.getLong("Died") : -1;
        old = nbt.getBoolean("Old");
        inv.getHeldStacks().clear();
        net.minecraft.util.collection.DefaultedList<ItemStack> list = net.minecraft.util.collection.DefaultedList.ofSize(inv.size(), ItemStack.EMPTY);
        Inventories.readNbt(nbt, list, this.getRegistryManager());
        for (int i = 0; i < list.size(); i++) inv.setStack(i, list.get(i));
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putInt("Look", look());
        nbt.putInt("Pose", pose());
        nbt.putFloat("Rot", rot());
        nbt.putInt("Limbs", limbs());
        dataTracker.get(SKIN).ifPresent(u -> nbt.putUuid("Skin", u));
        nbt.putLong("Died", died);
        nbt.putBoolean("Old", old);
        Inventories.writeNbt(nbt, inv.getHeldStacks(), this.getRegistryManager());
    }
}
