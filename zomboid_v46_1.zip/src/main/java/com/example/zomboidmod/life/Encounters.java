package com.example.zomboidmod.life;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.ZomboidEntities;
import com.example.zomboidmod.gun.Guns;
import com.example.zomboidmod.sandbox.Sandbox;
import com.example.zomboidmod.survival.SurvivalSounds;
import com.example.zomboidmod.survivors.SurvivorEntity;
import com.example.zomboidmod.survivors.Survivors;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * События вокруг игрока, чтобы мир жил: раз в несколько минут где-то стреляют, кричат, взрывается,
 * воет сигнализация — и мертвецы округи идут на этот шум. А иногда это не просто звук: выживший в беде,
 * стычка бандитов с выжившими или толпа мертвецов, бредущая мимо.
 */
public final class Encounters {
    private Encounters() {
    }

    private static final Map<UUID, Long> NEXT = new HashMap<>();

    private record Later(long at, Runnable run) {}

    private static final List<Later> LATER = new ArrayList<>();

    static void register() {
    }

    static void reset() {
        NEXT.clear();
        LATER.clear();
    }

    private static void later(ServerWorld w, int delay, Runnable r) {
        LATER.add(new Later(w.getTime() + delay, r));
    }

    static void tick(MinecraftServer server) {
        ServerWorld w = server.getOverworld();
        long now = w.getTime();
        if (!LATER.isEmpty()) {
            List<Later> due = new ArrayList<>();
            LATER.removeIf(l -> {
                if (now >= l.at()) {
                    due.add(l);
                    return true;
                }
                return false;
            });
            for (Later l : due) l.run().run();
        }
        if (now % 20 != 0) return;
        float mult = Sandbox.eventsMult();
        Random r = w.getRandom();
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (p.isSpectator() || !p.isAlive()) continue;
            Long t = NEXT.get(p.getUuid());
            if (t == null || t > now + 40000) {   // первое событие — через 1-3 минуты после входа
                NEXT.put(p.getUuid(), now + 1200 + r.nextInt(2400));
                continue;
            }
            if (now < t) continue;
            NEXT.put(p.getUuid(), now + (mult <= 0 ? 6000 : (long) ((3000 + r.nextInt(5400)) / mult)));
            if (mult > 0) fire(w, p, r);
        }
    }

    // =====================================================================================
    //                                        выбор
    // =====================================================================================

    private static void fire(ServerWorld w, ServerPlayerEntity p, Random r) {
        boolean zombies = Sandbox.pop() > 0, people = Sandbox.survivorsMult() > 0, bandits = people && Sandbox.banditMult() > 0;
        boolean night = !w.isDay();
        int[] weight = {20, 8, 6, 8, night ? 6 : 0, zombies && people ? 16 : 0, bandits ? 12 : 0, zombies ? 18 : 0};
        int total = 0;
        for (int x : weight) total += x;
        int k = r.nextInt(total), pick = 0;
        for (; pick < weight.length; pick++) {
            k -= weight[pick];
            if (k < 0) break;
        }
        double a = r.nextDouble() * Math.PI * 2;
        boolean ok = switch (pick) {
            case 0 -> gunfire(w, p, a, r);
            case 1 -> scream(w, p, a, r);
            case 2 -> explosion(w, p, a, r);
            case 3 -> carAlarm(w, p, a, r);
            case 4 -> howl(w, p, a, r);
            case 5 -> help(w, p, r);
            case 6 -> feud(w, p, r);
            default -> horde(w, p, a, r);
        };
        if (!ok) gunfire(w, p, a, r);   // не нашлось места — хотя бы далёкая стрельба
    }

    // =====================================================================================
    //                                    помощники
    // =====================================================================================

    /** «на северо-востоке» по смещению. */
    public static String dir(double dx, double dz) {
        double ang = Math.toDegrees(Math.atan2(dx, -dz));
        String[] n = {"на севере", "на северо-востоке", "на востоке", "на юго-востоке", "на юге", "на юго-западе", "на западе", "на северо-западе"};
        return n[(int) Math.floorMod(Math.round(ang / 45.0), 8L)];
    }

    private static BlockPos at(ServerPlayerEntity p, double a, double dist) {
        return BlockPos.ofFloored(p.getX() + Math.sin(a) * dist, p.getY(), p.getZ() - Math.cos(a) * dist);
    }

    /** Звук издалека: слышен с нужной стороны, тихо. */
    private static void distant(ServerWorld w, ServerPlayerEntity p, double a, SoundEvent ev, float vol, float pitch) {
        w.playSound(null, p.getX() + Math.sin(a) * 36, p.getY() + 4, p.getZ() - Math.cos(a) * 36, ev, SoundCategory.AMBIENT, vol, pitch);
    }

    private static void hint(ServerPlayerEntity p, String text) {
        p.sendMessage(Text.literal(text).formatted(Formatting.GRAY), true);
    }

    /** Найти место для встречи на расстоянии min..max (несколько попыток). */
    private static BlockPos spot(ServerWorld w, ServerPlayerEntity p, Random r, int min, int max) {
        for (int i = 0; i < 8; i++) {
            double a = r.nextDouble() * Math.PI * 2, d = min + r.nextInt(Math.max(1, max - min));
            BlockPos s = Survivors.groundSpot(w, MathHelper.floor(p.getX() + Math.sin(a) * d), MathHelper.floor(p.getZ() - Math.cos(a) * d));
            if (s != null && Math.abs(s.getY() - p.getY()) < 24) return s;
        }
        return null;
    }

    // =====================================================================================
    //                                   звуковые события
    // =====================================================================================

    /** Перестрелка вдалеке: несколько выстрелов, мертвецы со всей округи идут туда. */
    private static boolean gunfire(ServerWorld w, ServerPlayerEntity p, double a, Random r) {
        BlockPos ev = at(p, a, 100 + r.nextInt(70));
        SoundEvent[] guns = {Guns.RIFLE_SHOT, Guns.SHOTGUN_SHOT, Guns.PISTOL_SHOT, Guns.AR_SHOT};
        SoundEvent g = guns[r.nextInt(guns.length)];
        int n = 3 + r.nextInt(7), t = 0;
        for (int i = 0; i < n; i++) {
            t += 3 + r.nextInt(16);
            SoundEvent s = r.nextFloat() < 0.25f ? guns[r.nextInt(guns.length)] : g;
            float pitch = 0.55f + r.nextFloat() * 0.15f;
            later(w, t, () -> distant(w, p, a, s, 2.4f, pitch));
        }
        Noise.emitAt(w, ev, 90);
        later(w, t + 10, () -> Noise.emitAt(w, ev, 90));
        hint(p, "Вдалеке стреляют — " + dir(ev.getX() - p.getX(), ev.getZ() - p.getZ()));
        return true;
    }

    /** Крик вдалеке. */
    private static boolean scream(ServerWorld w, ServerPlayerEntity p, double a, Random r) {
        BlockPos ev = at(p, a, 80 + r.nextInt(60));
        distant(w, p, a, SoundEvents.ENTITY_FOX_SCREECH, 2.2f, 0.62f + r.nextFloat() * 0.1f);
        later(w, 25 + r.nextInt(20), () -> distant(w, p, a, SoundEvents.ENTITY_FOX_SCREECH, 2.0f, 0.55f + r.nextFloat() * 0.1f));
        Noise.emitAt(w, ev, 60);
        return true;
    }

    /** Взрыв (газ, бензовоз, граната) — гремит на всю округу. */
    private static boolean explosion(ServerWorld w, ServerPlayerEntity p, double a, Random r) {
        BlockPos ev = at(p, a, 120 + r.nextInt(80));
        distant(w, p, a, Life.EXPLOSION_FAR, 4f, 0.9f + r.nextFloat() * 0.2f);
        Noise.emitAt(w, ev, 120);
        later(w, 60, () -> Noise.emitAt(w, ev, 120));
        hint(p, "Где-то " + dir(ev.getX() - p.getX(), ev.getZ() - p.getZ()) + " прогремел взрыв");
        return true;
    }

    /** Чужая сигнализация воет вдалеке. */
    private static boolean carAlarm(ServerWorld w, ServerPlayerEntity p, double a, Random r) {
        BlockPos ev = at(p, a, 70 + r.nextInt(50));
        for (int i = 0; i < 10; i++) later(w, i * 40, () -> distant(w, p, a, Life.CAR_ALARM, 2.4f, 1f));
        for (int i = 0; i < 4; i++) later(w, i * 100, () -> Noise.emitAt(w, ev, 56));
        hint(p, "Вдалеке воет сигнализация — " + dir(ev.getX() - p.getX(), ev.getZ() - p.getZ()));
        return true;
    }

    /** Ночью — вой одичавших собак. */
    private static boolean howl(ServerWorld w, ServerPlayerEntity p, double a, Random r) {
        distant(w, p, a, SoundEvents.ENTITY_WOLF_HOWL, 2.2f, 0.8f + r.nextFloat() * 0.2f);
        return true;
    }

    // =====================================================================================
    //                                     встречи
    // =====================================================================================

    /** Выжившего окружили мертвецы: он кричит, убегает, отбивается. Спасёшь — отблагодарит и пойдёт с тобой. */
    private static boolean help(ServerWorld w, ServerPlayerEntity p, Random r) {
        BlockPos s = spot(w, p, r, 45, 70);
        if (s == null) return false;
        SurvivorEntity e = Survivors.spawnAt(w, s, SurvivorEntity.NEUTRAL, true);
        if (e == null) return false;
        int n = Math.max(3, Math.min(10, Math.round((5 + r.nextInt(4)) * Sandbox.pop())));
        for (int i = 0; i < n; i++) {
            double ang = r.nextDouble() * Math.PI * 2, d = 4 + r.nextDouble() * 4;
            BlockPos zs = Survivors.groundSpot(w, MathHelper.floor(s.getX() + Math.cos(ang) * d), MathHelper.floor(s.getZ() + Math.sin(ang) * d));
            if (zs == null) continue;
            PzZombieEntity z = ZomboidEntities.PZ_ZOMBIE.create(w);
            if (z == null) continue;
            z.refreshPositionAndAngles(zs.getX() + 0.5, zs.getY(), zs.getZ() + 0.5, r.nextFloat() * 360f, 0f);
            z.setup(null, 1);
            w.spawnEntity(z);
            z.setTarget(e);
        }
        callForHelp(w, e);
        return true;
    }

    /** Крик о помощи слышно издалека: в строке состояния — откуда кричат. */
    public static void callForHelp(ServerWorld w, SurvivorEntity e) {
        for (ServerPlayerEntity p : w.getPlayers()) {
            double d = p.distanceTo(e);
            if (d < 20 || d > 110 || p.isSpectator()) continue;
            p.sendMessage(Text.literal("Кто-то кричит «Помогите!» — " + dir(e.getX() - p.getX(), e.getZ() - p.getZ()) + ", метрах в " + (int) (Math.round(d / 10.0) * 10))
                    .formatted(Formatting.GOLD), true);
        }
    }

    /** Бандиты напали на выживших: перестрелка (её слышат и мертвецы). */
    private static boolean feud(ServerWorld w, ServerPlayerEntity p, Random r) {
        BlockPos s = spot(w, p, r, 55, 80);
        if (s == null) return false;
        double ang = r.nextDouble() * Math.PI * 2;
        List<SurvivorEntity> good = new ArrayList<>(), bad = new ArrayList<>();
        for (int i = 0; i < 2 + r.nextInt(2); i++) {
            BlockPos b = Survivors.groundSpot(w, MathHelper.floor(s.getX() + Math.cos(ang) * 7 + r.nextInt(3) - 1), MathHelper.floor(s.getZ() + Math.sin(ang) * 7 + r.nextInt(3) - 1));
            if (b != null) {
                SurvivorEntity e = Survivors.spawnAt(w, b, SurvivorEntity.BANDIT, false);
                if (e != null) bad.add(e);
            }
        }
        for (int i = 0; i < 2; i++) {
            BlockPos g = Survivors.groundSpot(w, MathHelper.floor(s.getX() - Math.cos(ang) * 7 + r.nextInt(3) - 1), MathHelper.floor(s.getZ() - Math.sin(ang) * 7 + r.nextInt(3) - 1));
            if (g != null) {
                SurvivorEntity e = Survivors.spawnAt(w, g, SurvivorEntity.NEUTRAL, false);
                if (e != null) good.add(e);
            }
        }
        if (bad.isEmpty() || good.isEmpty()) {
            bad.forEach(SurvivorEntity::discard);
            good.forEach(SurvivorEntity::discard);
            return false;
        }
        for (int i = 0; i < bad.size(); i++) bad.get(i).setTarget(good.get(i % good.size()));
        for (int i = 0; i < good.size(); i++) good.get(i).setTarget(bad.get(i % bad.size()));
        Noise.emitAt(w, s, 48);
        hint(p, "Где-то " + dir(s.getX() - p.getX(), s.getZ() - p.getZ()) + " слышны крики и стрельба");
        return true;
    }

    /** Толпа мертвецов бредёт мимо: видно издалека, лучше переждать или обойти. */
    private static boolean horde(ServerWorld w, ServerPlayerEntity p, double a, Random r) {
        BlockPos s = null;
        for (int i = 0; i < 6 && s == null; i++) {
            double aa = a + i * 1.05, d = 75 + r.nextInt(20);
            BlockPos c = Survivors.groundSpot(w, MathHelper.floor(p.getX() + Math.sin(aa) * d), MathHelper.floor(p.getZ() - Math.cos(aa) * d));
            if (c != null && Math.abs(c.getY() - p.getY()) < 24) {
                s = c;
                a = aa;
            }
        }
        if (s == null) return false;
        // идут насквозь, мимо игрока: на противоположную сторону со сдвигом вбок
        double side = r.nextBoolean() ? 1 : -1, back = a + Math.PI;
        BlockPos dest = BlockPos.ofFloored(p.getX() + Math.sin(back) * 80 + Math.cos(back) * 32 * side, p.getY(),
                p.getZ() - Math.cos(back) * 80 + Math.sin(back) * 32 * side);
        int n = Math.min(28, Math.round((10 + r.nextInt(12)) * Sandbox.pop()));
        int made = 0;
        for (int i = 0; i < n; i++) {
            BlockPos zs = Survivors.groundSpot(w, s.getX() + r.nextInt(11) - 5, s.getZ() + r.nextInt(11) - 5);
            if (zs == null) continue;
            PzZombieEntity z = ZomboidEntities.PZ_ZOMBIE.create(w);
            if (z == null) continue;
            z.refreshPositionAndAngles(zs.getX() + 0.5, zs.getY(), zs.getZ() + 0.5, r.nextFloat() * 360f, 0f);
            z.setup(null, 0);
            w.spawnEntity(z);
            z.migrate(dest, 1600);
            made++;
        }
        if (made == 0) return false;
        final double fa = a;
        distant(w, p, fa, SurvivalSounds.HORDE, 2.5f, 0.75f);
        hint(p, "Слышен гул множества голосов — " + dir(s.getX() - p.getX(), s.getZ() - p.getZ()) + ". Идёт толпа");
        return true;
    }
}
