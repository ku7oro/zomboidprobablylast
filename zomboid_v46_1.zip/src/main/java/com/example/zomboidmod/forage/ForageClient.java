package com.example.zomboidmod.forage;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.MathHelper;

/** Режим поиска на клиенте: клавиша G (пешком), затемнение по краям экрана и значок «Поиск». */
public final class ForageClient {
    private ForageClient() {
    }

    private static boolean on;
    private static float fade;   // 0..1 — плавное появление виньетки
    private static int ticks;

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(Forage.SearchPayload.ID, (pl, ctx) -> on = pl.on());
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> on = false);
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            ticks++;
            fade = MathHelper.clamp(fade + (on ? 0.08f : -0.12f), 0f, 1f);
            if (on && c.player != null && c.player.hasVehicle()) on = false;
        });
        HudRenderCallback.EVENT.register(ForageClient::hud);
    }

    public static boolean searching() {
        return on;
    }

    public static void toggle() {
        ClientPlayNetworking.send(new Forage.SearchPayload(!on));
    }

    private static void hud(DrawContext ctx, RenderTickCounter counter) {
        if (fade <= 0.01f) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.options.hudHidden || c.player == null) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        // мягкая виньетка: взгляд сосредоточен под ногами
        int steps = 14, depth = Math.min(w, h) / 5;
        for (int i = 0; i < steps; i++) {
            float k = 1f - i / (float) steps;
            int a = (int) (fade * 70 * k * k);
            if (a <= 0) continue;
            int col = a << 24 | 0x0A0F08;
            int d = depth * i / steps, d2 = depth * (i + 1) / steps;
            ctx.fill(0, d, w, d2, col);                 // верх
            ctx.fill(0, h - d2, w, h - d, col);         // низ
            ctx.fill(d, d2, d2, h - d2, col);           // лево
            ctx.fill(w - d2, d2, w - d, h - d2, col);   // право
        }
        // значок: глаз + «Поиск»
        int x = w / 2 - 30, y = h - 62;
        int alpha = (int) (fade * 255) << 24;
        float pulse = 0.75f + 0.25f * MathHelper.sin(ticks * 0.15f);
        int green = alpha | ((int) (0x9F * pulse) << 16) | ((int) (0xE0 * pulse) << 8) | 0x7A;
        drawEye(ctx, x, y + 1, alpha);
        ctx.drawTextWithShadow(c.textRenderer, "Поиск", x + 16, y + 2, green);
    }

    /** Маленький пиксельный глаз 12×7. */
    private static void drawEye(DrawContext ctx, int x, int y, int alpha) {
        int white = alpha | 0xE8E4D0, dark = alpha | 0x1A2416, iris = alpha | 0x6FA850;
        ctx.fill(x + 3, y, x + 9, y + 1, dark);
        ctx.fill(x + 1, y + 1, x + 11, y + 2, dark);
        ctx.fill(x, y + 2, x + 12, y + 5, dark);
        ctx.fill(x + 1, y + 5, x + 11, y + 6, dark);
        ctx.fill(x + 3, y + 6, x + 9, y + 7, dark);
        ctx.fill(x + 2, y + 2, x + 10, y + 5, white);
        ctx.fill(x + 4, y + 1, x + 8, y + 6, white);
        ctx.fill(x + 4, y + 2, x + 8, y + 5, iris);
        ctx.fill(x + 5, y + 3, x + 7, y + 4, alpha | 0x0A0A0A);
    }
}
