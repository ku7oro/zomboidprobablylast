package com.example.zomboidmod.forage;

import com.example.zomboidmod.MedItem;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.media.Knowledge;
import com.example.zomboidmod.nature.Climate;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.Survival;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.LightType;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Собирательство (как в PZ): режим поиска по клавише G. Идёшь медленно и смотришь под ноги — находишь ягоды,
 * грибы, лечебные травы, орехи, насекомых, ветки и кору, а в городе — мелочь. Что попадётся, зависит от места
 * (лес, луг, берег, улица), времени года, света и навыка. Ядовитые ягоды и грибы без знаний не отличить.
 */
public final class Forage {
    private Forage() {
    }

    public enum Hab {FOREST, MEADOW, WATER, TOWN}

    public enum Type {BERRY, MUSHROOM, HERB, NUT, INSECT, MATERIAL, JUNK}

    private static final int SP = 1, SU = 2, AU = 4, WI = 8, ALL = 15;

    /** Находка: предмет, вид, места, сезоны, вес, сколько штук. */
    public record Find(Supplier<Item> item, Type type, EnumSet<Hab> where, int seasons, int weight, int min, int max) {}

    public static Item BLUEBERRY, BLACKBERRY, RASPBERRY, WILD_STRAWBERRY, WOLFBERRY, NIGHTSHADE, ROSE_HIPS;
    public static Item PORCINI, CHANTERELLE, HONEY_FUNGUS, FLY_AGARIC, DEATH_CAP;
    public static Item PLANTAIN, COMFREY, WILD_GARLIC, CHAMOMILE, NETTLE, DANDELION, CATTAIL, HAZELNUTS, ACORNS;
    public static Item GRASSHOPPER, GRUBS, BARK;
    public static Item UNKNOWN_BERRIES, UNKNOWN_MUSHROOMS;
    public static Item MORTAR, POULTICE_PLANTAIN, POULTICE_COMFREY, POULTICE_GARLIC, CHAMOMILE_TEA;

    /** Ядовитость: 0 нет, 1 слегка (горько, жжётся), 2 отравление, 3 смертельно. */
    private static final Map<Item, Integer> TOXIC = new HashMap<>();
    private static final Set<Item> BERRIES = new HashSet<>(), MUSHROOMS = new HashSet<>();
    public static final List<Item> ALL_ITEMS = new ArrayList<>();
    static final List<Find> FINDS = new ArrayList<>();

    private static Item reg(String id, Item item) {
        Item it = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
        ALL_ITEMS.add(it);
        return it;
    }

    private static Item.Settings food(int n, float sat) {
        return new Item.Settings().maxCount(32).food(new FoodComponent.Builder().nutrition(n).saturationModifier(sat).snack().build());
    }

    private static Item plant(String id, int n, float sat, int toxic, String hint) {
        Item it = reg(id, n > 0 ? new WildFood(food(n, sat), toxic, hint) : new Hinted(new Item.Settings().maxCount(32), hint));
        if (toxic > 0) TOXIC.put(it, toxic);
        return it;
    }

    public static void register() {
        BLUEBERRY = plant("forage_blueberry", 2, 0.25f, 0, "Сладкая лесная ягода");
        BLACKBERRY = plant("forage_blackberry", 2, 0.25f, 0, "Колючие кусты на опушках");
        RASPBERRY = plant("forage_raspberry", 2, 0.2f, 0, "Ароматная, с кустов у дорог и в лесу");
        WILD_STRAWBERRY = plant("forage_wild_strawberry", 1, 0.2f, 0, "Мелкая и очень сладкая");
        WOLFBERRY = plant("forage_wolfberry", 2, 0.1f, 2, "Ядовитые ягоды! Есть нельзя");
        NIGHTSHADE = plant("forage_nightshade", 2, 0.1f, 2, "Ядовитые ягоды паслёна! Есть нельзя");
        ROSE_HIPS = plant("forage_rose_hips", 1, 0.3f, 0, "Висит на кустах до самой зимы; согревает");
        PORCINI = plant("forage_porcini", 3, 0.35f, 0, "Лучший гриб леса. Вкуснее в супе");
        CHANTERELLE = plant("forage_chanterelle", 2, 0.3f, 0, "Рыжие и съедобные. Вкуснее в супе");
        HONEY_FUNGUS = plant("forage_honey_fungus", 2, 0.3f, 0, "Растут гроздьями на пнях. Вкуснее в супе");
        FLY_AGARIC = plant("forage_fly_agaric", 2, 0.1f, 2, "Ядовитый гриб! Есть нельзя");
        DEATH_CAP = plant("forage_death_cap", 2, 0.1f, 3, "Смертельно ядовитый гриб!");
        PLANTAIN = plant("forage_plantain", 1, 0.1f, 0, "Лечебная трава: в ступке — припарка на рану");
        COMFREY = plant("forage_comfrey", 0, 0f, 0, "Лечебная трава: в ступке — припарка на перелом");
        WILD_GARLIC = plant("forage_wild_garlic", 1, 0.2f, 0, "Дикий чеснок: в ступке — припарка от заражения раны");
        CHAMOMILE = plant("forage_chamomile", 0, 0f, 0, "С водой — успокаивающий чай");
        NETTLE = plant("forage_nettle", 1, 0.2f, 1, "Жжётся сырой. В супе — вкусно и сытно");
        DANDELION = plant("forage_dandelion", 1, 0.1f, 0, "Листья съедобны, горчат");
        CATTAIL = plant("forage_cattail", 3, 0.3f, 0, "Корень рогоза — крахмалистый, сытный");
        HAZELNUTS = plant("forage_hazelnuts", 2, 0.5f, 0, "Сытные орехи");
        ACORNS = plant("forage_acorns", 1, 0.3f, 1, "Сырые горькие; в супе — съедобны");
        GRASSHOPPER = plant("forage_grasshopper", 1, 0.3f, 1, "Белок есть белок... Лучше поджарить в супе. Или как наживку");
        GRUBS = plant("forage_grubs", 1, 0.3f, 1, "Жирные личинки из гнилого пня. Бр-р");
        BARK = plant("forage_bark", 0, 0f, 0, "Берёзовая кора — растопка для костра");
        BERRIES.addAll(List.of(BLUEBERRY, BLACKBERRY, RASPBERRY, WOLFBERRY, NIGHTSHADE));
        MUSHROOMS.addAll(List.of(PORCINI, CHANTERELLE, HONEY_FUNGUS, FLY_AGARIC, DEATH_CAP));
        UNKNOWN_BERRIES = reg("forage_unknown_berries", new Unknown(food(2, 0.2f), false));
        UNKNOWN_MUSHROOMS = reg("forage_unknown_mushrooms", new Unknown(food(2, 0.25f), true));
        // травяная аптека
        MORTAR = reg("mortar", new Mortar(new Item.Settings().maxDamage(40)));
        POULTICE_PLANTAIN = reg("poultice_plantain", new MedItem(new Item.Settings().maxCount(8), MedItem.Kind.PLANTAIN));
        POULTICE_COMFREY = reg("poultice_comfrey", new MedItem(new Item.Settings().maxCount(8), MedItem.Kind.COMFREY));
        POULTICE_GARLIC = reg("poultice_garlic", new MedItem(new Item.Settings().maxCount(8), MedItem.Kind.GARLIC));
        CHAMOMILE_TEA = reg("chamomile_tea", new Tea(new Item.Settings().maxCount(8)));
        for (Item p : new Item[]{POULTICE_PLANTAIN, POULTICE_COMFREY, POULTICE_GARLIC, CHAMOMILE_TEA}) Knowledge.gate(p, "herbal", PzSkill.FORAGING, 4);

        // что где находят
        EnumSet<Hab> F = EnumSet.of(Hab.FOREST), M = EnumSet.of(Hab.MEADOW), W = EnumSet.of(Hab.WATER), T = EnumSet.of(Hab.TOWN);
        EnumSet<Hab> FM = EnumSet.of(Hab.FOREST, Hab.MEADOW), MW = EnumSet.of(Hab.MEADOW, Hab.WATER), MT = EnumSet.of(Hab.MEADOW, Hab.TOWN);
        add(() -> BLUEBERRY, Type.BERRY, F, SU | AU, 10, 3, 8);
        add(() -> BLACKBERRY, Type.BERRY, FM, SU | AU, 8, 3, 8);
        add(() -> RASPBERRY, Type.BERRY, FM, SU, 7, 3, 7);
        add(() -> WILD_STRAWBERRY, Type.BERRY, M, SP | SU, 6, 2, 6);
        add(() -> WOLFBERRY, Type.BERRY, F, SU | AU, 6, 3, 8);
        add(() -> NIGHTSHADE, Type.BERRY, MW, SU | AU, 4, 3, 6);
        add(() -> ROSE_HIPS, Type.BERRY, FM, AU | WI, 6, 3, 8);
        add(() -> PORCINI, Type.MUSHROOM, F, SU | AU, 5, 1, 3);
        add(() -> CHANTERELLE, Type.MUSHROOM, F, SU | AU, 6, 2, 6);
        add(() -> HONEY_FUNGUS, Type.MUSHROOM, F, AU, 6, 3, 8);
        add(() -> FLY_AGARIC, Type.MUSHROOM, F, SU | AU, 5, 1, 2);
        add(() -> DEATH_CAP, Type.MUSHROOM, F, SU | AU, 3, 1, 2);
        add(() -> PLANTAIN, Type.HERB, MT, SP | SU | AU, 8, 2, 5);
        add(() -> COMFREY, Type.HERB, MW, SP | SU, 5, 1, 3);
        add(() -> WILD_GARLIC, Type.HERB, F, SP | SU, 6, 2, 5);
        add(() -> CHAMOMILE, Type.HERB, M, SU, 6, 2, 6);
        add(() -> NETTLE, Type.HERB, EnumSet.of(Hab.FOREST, Hab.MEADOW, Hab.TOWN), SP | SU | AU, 8, 2, 6);
        add(() -> DANDELION, Type.HERB, MT, SP | SU, 8, 2, 6);
        add(() -> CATTAIL, Type.HERB, W, ALL, 8, 1, 3);
        add(() -> HAZELNUTS, Type.NUT, F, AU, 6, 3, 10);
        add(() -> ACORNS, Type.NUT, F, AU | WI, 6, 4, 12);
        add(() -> GRASSHOPPER, Type.INSECT, M, SU | AU, 6, 1, 4);
        add(() -> GRUBS, Type.INSECT, F, SP | SU | AU, 5, 2, 6);
        add(() -> com.example.zomboidmod.hunting.HuntingItems.WORM, Type.INSECT, EnumSet.of(Hab.FOREST, Hab.MEADOW, Hab.WATER), SP | SU | AU, 8, 1, 4);
        add(() -> BARK, Type.MATERIAL, F, ALL, 6, 1, 3);
        add(() -> Items.STICK, Type.MATERIAL, F, ALL, 8, 1, 4);
        add(() -> Items.FLINT, Type.MATERIAL, MW, ALL, 4, 1, 2);
        add(() -> Items.FEATHER, Type.MATERIAL, M, ALL, 3, 1, 3);
        add(() -> com.example.zomboidmod.build.CarpentryItems.NAILS, Type.JUNK, T, ALL, 8, 1, 4);
        add(() -> ZomboidMod.RAG, Type.JUNK, T, ALL, 6, 1, 2);
        add(() -> Items.GLASS_BOTTLE, Type.JUNK, T, ALL, 6, 1, 1);
        add(() -> com.example.zomboidmod.survival.SurvivalItems.BATTERY, Type.JUNK, T, ALL, 3, 1, 1);
        add(() -> com.example.zomboidmod.LootItems.DUCT_TAPE, Type.JUNK, T, ALL, 2, 1, 1);
        add(() -> com.example.zomboidmod.metal.Metal.SCRAP, Type.JUNK, T, ALL, 6, 1, 2);
        add(() -> com.example.zomboidmod.metal.Metal.SCREWS, Type.JUNK, T, ALL, 4, 1, 3);

        // сроки годности: ягоды и грибы портятся за пару дней, орехи лежат месяцами
        for (Item b : List.of(BLUEBERRY, BLACKBERRY, RASPBERRY, WILD_STRAWBERRY, WOLFBERRY, NIGHTSHADE, UNKNOWN_BERRIES,
                PORCINI, CHANTERELLE, HONEY_FUNGUS, FLY_AGARIC, DEATH_CAP, UNKNOWN_MUSHROOMS)) com.example.zomboidmod.survival.Food.perish(b, 2, 4);
        for (Item h : List.of(PLANTAIN, COMFREY, WILD_GARLIC, CHAMOMILE, NETTLE, DANDELION)) com.example.zomboidmod.survival.Food.perish(h, 3, 6);
        com.example.zomboidmod.survival.Food.perish(ROSE_HIPS, 10, 20);
        com.example.zomboidmod.survival.Food.perish(CATTAIL, 4, 8);
        com.example.zomboidmod.survival.Food.perish(HAZELNUTS, 60, 120);
        com.example.zomboidmod.survival.Food.perish(ACORNS, 60, 120);
        com.example.zomboidmod.survival.Food.perish(GRASSHOPPER, 1, 2);
        com.example.zomboidmod.survival.Food.perish(GRUBS, 1, 2);

        net.fabricmc.fabric.api.registry.FuelRegistry.INSTANCE.add(BARK, 150);   // кора — растопка

        PayloadTypeRegistry.playC2S().register(SearchPayload.ID, SearchPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SearchPayload.ID, SearchPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SearchPayload.ID, (pl, ctx) -> setSearching(ctx.player(), pl.on()));
        ServerPlayConnectionEvents.DISCONNECT.register((h, s) -> SEARCHING.remove(h.player.getUuid()));
        ServerTickEvents.END_SERVER_TICK.register(Forage::tick);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(e -> ALL_ITEMS.forEach(e::add));
    }

    private static void add(Supplier<Item> item, Type t, EnumSet<Hab> where, int seasons, int weight, int min, int max) {
        FINDS.add(new Find(item, t, where, seasons, weight, min, max));
    }

    public static int toxicity(ItemStack st) {
        if (st.isOf(UNKNOWN_BERRIES) || st.isOf(UNKNOWN_MUSHROOMS)) {
            Item real = Unknown.real(st);
            return real == null ? 0 : TOXIC.getOrDefault(real, 0);
        }
        return TOXIC.getOrDefault(st.getItem(), 0);
    }

    /** Грибы (в т.ч. неизвестные) — для названия супа. */
    public static boolean mushroom(Item i) {
        return MUSHROOMS.contains(i) || i == UNKNOWN_MUSHROOMS;
    }

    /** Последствия: от «горько» до смертельного отравления. */
    public static void poison(ServerPlayerEntity p, int level, Item what) {
        if (level <= 0) return;
        Mood m = Survival.mood(p);
        float k = Skills.poisonMult(p);
        switch (level) {
            case 1 -> {
                m.unhappy = Math.min(100f, m.unhappy + 4f);
                if (what == NETTLE) {
                    p.damage(p.getDamageSources().generic(), 0.5f);
                    p.sendMessage(Text.literal("Крапива обожгла рот!").formatted(Formatting.GRAY), true);
                } else if (what == GRASSHOPPER || what == GRUBS) {
                    m.unhappy = Math.min(100f, m.unhappy + 8f);
                    p.sendMessage(Text.literal("Бр-р... Мерзость").formatted(Formatting.GRAY), true);
                } else {
                    m.foodSick = Math.min(100f, m.foodSick + 8f * k);
                    p.sendMessage(Text.literal("Горько... Живот крутит").formatted(Formatting.GRAY), true);
                }
            }
            case 2 -> {
                m.foodSick = Math.min(100f, m.foodSick + 45f * k);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 400, 0));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 120, 0));
                if (what == FLY_AGARIC) p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 300, 0));
                p.sendMessage(Text.literal("Вас мутит, кружится голова... Это было ядовито").formatted(Formatting.RED), false);
            }
            default -> {
                m.foodSick = Math.min(100f, m.foodSick + 95f * k);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 900, 1));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 300, 1));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 2400, 1));
                p.sendMessage(Text.literal("Страшная резь в животе... Это была бледная поганка").formatted(Formatting.DARK_RED), false);
            }
        }
    }

    // =====================================================================================
    //                                    режим поиска
    // =====================================================================================

    public record SearchPayload(boolean on) implements CustomPayload {
        public static final CustomPayload.Id<SearchPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "forage_search"));
        public static final PacketCodec<RegistryByteBuf, SearchPayload> CODEC = PacketCodec.tuple(PacketCodecs.BOOL, SearchPayload::on, SearchPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    private static final Set<UUID> SEARCHING = new HashSet<>();
    private static final Identifier SLOW = Identifier.of(ZomboidMod.MOD_ID, "forage_search");
    /** Обысканные места: чанк → сколько уже нашли (за день). */
    private static final Map<Long, Integer> PICKED = new HashMap<>();
    private static long pickedDay = -1;
    /** Находки, подсвеченные на время: предмет → тик, когда погасить. */
    private static final Map<ItemEntity, Long> GLOW = new HashMap<>();

    private static void setSearching(ServerPlayerEntity p, boolean on) {
        EntityAttributeInstance sp = p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (sp != null) sp.removeModifier(SLOW);
        if (on && p.hasVehicle()) on = false;
        if (on) {
            SEARCHING.add(p.getUuid());
            if (sp != null) sp.addTemporaryModifier(new EntityAttributeModifier(SLOW, -0.3, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
            p.sendMessage(Text.literal("Режим поиска: идите медленно и смотрите под ноги (G — выключить)").formatted(Formatting.GREEN), true);
        } else {
            SEARCHING.remove(p.getUuid());
            p.sendMessage(Text.literal("Режим поиска выключен").formatted(Formatting.GRAY), true);
        }
        ServerPlayNetworking.send(p, new SearchPayload(on));
    }

    private static void tick(MinecraftServer server) {
        ServerWorld w = server.getOverworld();
        long now = w.getTime();
        if (!GLOW.isEmpty()) GLOW.entrySet().removeIf(en -> {
            if (now < en.getValue() && en.getKey().isAlive()) return false;
            if (en.getKey().isAlive()) en.getKey().setGlowing(false);
            return true;
        });
        if (SEARCHING.isEmpty() || now % 40 != 0) return;
        long day = now / 24000L;
        if (day != pickedDay) {
            pickedDay = day;
            PICKED.clear();
        }
        for (UUID id : new ArrayList<>(SEARCHING)) {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(id);
            if (p == null || !p.isAlive() || p.hasVehicle() || p.getServerWorld() != w) {
                if (p != null) setSearching(p, false);
                else SEARCHING.remove(id);
                continue;
            }
            if (p.isOnGround()) roll(w, p);
        }
    }

    private static EnumSet<Hab> habitats(ServerWorld w, BlockPos at) {
        int leaves = 0, logs = 0, water = 0, grass = 0, street = 0;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -5; dx <= 5; dx++)
            for (int dz = -5; dz <= 5; dz++)
                for (int dy = -2; dy <= 4; dy++) {
                    BlockState s = w.getBlockState(m.set(at.getX() + dx, at.getY() + dy, at.getZ() + dz));
                    if (s.isAir()) continue;
                    if (s.isIn(BlockTags.LEAVES)) leaves++;
                    else if (s.isIn(BlockTags.LOGS)) logs++;
                    else if (s.getFluidState().isIn(FluidTags.WATER)) water++;
                    else if (s.isIn(BlockTags.REPLACEABLE_BY_TREES) || s.isIn(BlockTags.FLOWERS)) grass++;
                    else if (dy == -1) {
                        String id = Registries.BLOCK.getId(s.getBlock()).getPath();
                        if (id.contains("asphalt") || id.contains("sidewalk") || id.contains("concrete") || id.contains("road")) street++;
                    }
                }
        EnumSet<Hab> h = EnumSet.noneOf(Hab.class);
        if (leaves + logs >= 8) h.add(Hab.FOREST);
        if (grass >= 5) h.add(Hab.MEADOW);
        if (water >= 3) h.add(Hab.WATER);
        if (street >= 6 || com.example.zomboidmod.world.Knox.zoneAt(w.getSeed(), at.getX(), at.getZ()) == 2) h.add(Hab.TOWN);
        return h;
    }

    private static int seasonBit(ServerWorld w) {
        return switch (Climate.season(w).name()) {
            case "SPRING" -> SP;
            case "SUMMER" -> SU;
            case "AUTUMN" -> AU;
            default -> WI;
        };
    }

    private static void roll(ServerWorld w, ServerPlayerEntity p) {
        Random r = p.getRandom();
        BlockPos at = p.getBlockPos();
        int lvl = Skills.level(p, PzSkill.FORAGING);
        float chance = 0.22f + 0.035f * lvl;
        int light = w.getLightLevel(LightType.SKY, at) - w.getAmbientDarkness();
        light = Math.max(light, w.getLightLevel(LightType.BLOCK, at));
        if (light < 6) chance *= 0.35f;                                      // в темноте почти ничего не видно
        boolean snow = w.getBlockState(at).isOf(net.minecraft.block.Blocks.SNOW);
        if (snow) chance *= 0.5f;
        long ck = ChunkPos.toLong(at.getX() >> 4, at.getZ() >> 4);
        int picked = PICKED.getOrDefault(ck, 0);
        if (picked > 10) chance *= 0.3f;                                      // тут уже всё обобрали
        if (r.nextFloat() > chance) return;
        EnumSet<Hab> hab = habitats(w, at);
        if (hab.isEmpty()) return;
        int sb = seasonBit(w);
        boolean rain = w.isRaining();
        List<Find> ok = new ArrayList<>();
        int total = 0;
        for (Find f : FINDS) {
            if ((f.seasons() & sb) == 0) continue;
            boolean here = false;
            for (Hab h : f.where()) if (hab.contains(h)) here = true;
            if (!here || f.item().get() == null) continue;
            ok.add(f);
            total += weight(f, rain);
        }
        if (ok.isEmpty()) return;
        int k = r.nextInt(total);
        Find pick = ok.get(0);
        for (Find f : ok) {
            k -= weight(f, rain);
            if (k < 0) {
                pick = f;
                break;
            }
        }
        int n = pick.min() + r.nextInt(pick.max() - pick.min() + 1) + lvl / 3;
        ItemStack st = new ItemStack(pick.item().get(), Math.max(1, n));
        // ядовитое от съедобного без знаний не отличить
        Item it = st.getItem();
        boolean mush = MUSHROOMS.contains(it), berry = BERRIES.contains(it);
        if ((mush || berry) && !Knowledge.identifies(p, mush)) st = Unknown.of(st, mush);
        place(w, p, st, r);
        PICKED.merge(ck, 1, Integer::sum);
        Skills.addXp(p, PzSkill.FORAGING, pick.type() == Type.JUNK || pick.type() == Type.MATERIAL ? 2f : 4f);
        p.sendMessage(Text.literal("Что-то нашлось: ").formatted(Formatting.GREEN).append(st.getName().copy().formatted(Formatting.WHITE))
                .append(Text.literal(" ×" + st.getCount()).formatted(Formatting.GRAY)), true);
    }

    private static int weight(Find f, boolean rain) {
        return f.type() == Type.MUSHROOM && rain ? f.weight() * 2 : f.weight();
    }

    /** Находка лежит в паре шагов впереди и светится, пока её не подберут. */
    private static void place(ServerWorld w, ServerPlayerEntity p, ItemStack st, Random r) {
        double yaw = Math.toRadians(p.getYaw() + (r.nextFloat() - 0.5f) * 140f), d = 2 + r.nextDouble() * 3;
        int x = MathHelper.floor(p.getX() - Math.sin(yaw) * d), z = MathHelper.floor(p.getZ() + Math.cos(yaw) * d);
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        double px = x + 0.5, py = y + 0.1, pz = z + 0.5;
        if (Math.abs(y - p.getY()) > 3) {
            px = p.getX();
            py = p.getY() + 0.2;
            pz = p.getZ();
        }
        ItemEntity e = new ItemEntity(w, px, py, pz, st, 0, 0.12, 0);
        e.setPickupDelay(8);
        e.setGlowing(true);
        w.spawnEntity(e);
        GLOW.put(e, w.getTime() + 600);
        w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, px, py + 0.3, pz, 5, 0.25, 0.2, 0.25, 0.01);
        w.playSound(null, BlockPos.ofFloored(px, py, pz), SoundEvents.BLOCK_SWEET_BERRY_BUSH_PICK_BERRIES, SoundCategory.PLAYERS, 0.6f, 1.2f);
    }

    // =====================================================================================
    //                                       предметы
    // =====================================================================================

    /** Подсказка в описании. */
    static class Hinted extends Item {
        final String hint;

        Hinted(Settings s, String hint) {
            super(s);
            this.hint = hint;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(hint).formatted(Formatting.GRAY));
        }
    }

    /** Дикая еда: ядовитая травит, жгучая жжётся, горькая горчит. */
    static class WildFood extends Hinted {
        final int toxic;

        WildFood(Settings s, int toxic, String hint) {
            super(s, hint);
            this.toxic = toxic;
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            Item what = stack.getItem();
            ItemStack out = super.finishUsing(stack, world, user);
            if (!world.isClient && user instanceof ServerPlayerEntity p) {
                poison(p, toxic, what);
                if (what == ROSE_HIPS) Survival.mood(p).cold = Math.max(0f, Survival.mood(p).cold - 120f);   // витамин C: простуда проходит быстрее
            }
            return out;
        }
    }

    /** «Неизвестные ягоды/грибы»: что внутри — узнаешь, когда поднаберёшься знаний (или съешь). */
    public static class Unknown extends Item {
        final boolean mushroom;

        Unknown(Settings s, boolean mushroom) {
            super(s);
            this.mushroom = mushroom;
        }

        static ItemStack of(ItemStack real, boolean mushroom) {
            ItemStack u = new ItemStack(mushroom ? UNKNOWN_MUSHROOMS : UNKNOWN_BERRIES, real.getCount());
            String id = Registries.ITEM.getId(real.getItem()).toString();
            NbtComponent.set(DataComponentTypes.CUSTOM_DATA, u, nbt -> nbt.putString("real", id));
            return u;
        }

        static Item real(ItemStack st) {
            NbtComponent c = st.get(DataComponentTypes.CUSTOM_DATA);
            if (c == null) return null;
            NbtCompound n = c.copyNbt();
            if (!n.contains("real")) return null;
            Identifier id = Identifier.tryParse(n.getString("real"));
            return id == null ? null : Registries.ITEM.get(id);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal("Съедобные или ядовитые — не разобрать").formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Узнать: собирательство " + (mushroom ? 5 : 3) + " ур., черта «Травник» или журнал «Лесная аптека»; потом Shift+ПКМ")
                    .formatted(Formatting.DARK_GRAY));
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            if (user.isSneaking()) {   // рассмотреть
                if (!world.isClient && user instanceof ServerPlayerEntity p) {
                    Item r = real(st);
                    if (r != null && Knowledge.identifies(p, mushroom)) {
                        ItemStack known = new ItemStack(r, st.getCount());
                        p.sendMessage(Text.literal("Присмотревшись, вы узнали: ").append(known.getName()), true);
                        return TypedActionResult.success(known);
                    }
                    p.sendMessage(Text.literal("Не разобрать, что это. Рискнуть и съесть?").formatted(Formatting.GRAY), true);
                }
                return TypedActionResult.fail(st);
            }
            return super.use(world, user, hand);
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            Item r = real(stack);
            ItemStack out = super.finishUsing(stack, world, user);
            if (!world.isClient && user instanceof ServerPlayerEntity p && r != null) poison(p, TOXIC.getOrDefault(r, 0), r);
            return out;
        }
    }

    /** Ступка с пестиком: перетирать травы (не тратится, а изнашивается). */
    static class Mortar extends Hinted {
        Mortar(Settings s) {
            super(s, "Три лечебных травы + ступка = припарка");
        }

        @Override
        public ItemStack getRecipeRemainder(ItemStack stack) {
            ItemStack c = stack.copy();
            c.setDamage(c.getDamage() + 1);
            return c.getDamage() >= c.getMaxDamage() ? ItemStack.EMPTY : c;
        }
    }

    /** Ромашковый чай: успокаивает, снимает стресс и панику. */
    static class Tea extends Hinted {
        Tea(Settings s) {
            super(s, "Успокаивает: меньше стресса и паники");
        }

        @Override
        public net.minecraft.util.UseAction getUseAction(ItemStack stack) {
            return net.minecraft.util.UseAction.DRINK;
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            return 32;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            user.setCurrentHand(hand);
            return TypedActionResult.consume(user.getStackInHand(hand));
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (!world.isClient && user instanceof ServerPlayerEntity p) {
                ZomboidMod.addThirst(p, 25);
                Mood m = Survival.mood(p);
                m.stress = Math.max(0f, m.stress - 25f);
                m.panic = Math.max(0f, m.panic - 30f);
                m.unhappy = Math.max(0f, m.unhappy - 5f);
                world.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GENERIC_DRINK, SoundCategory.PLAYERS, 0.8f, 1f);
                p.sendMessage(Text.literal("Тёплый ромашковый чай. Стало спокойнее").formatted(Formatting.GREEN), true);
                if (!p.isCreative()) stack.decrement(1);   // бутылка вернулась ещё при заварке
            }
            return stack;
        }
    }
}
