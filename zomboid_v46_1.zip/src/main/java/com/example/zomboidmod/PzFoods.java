package com.example.zomboidmod;

import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * Еда из Project Zomboid: консервы (нужен консервный нож), сухие пайки, сладости, напитки,
 * армейский сухпаёк — и экспериментальная сыворотка из опасных зон. Названия и рисунки свои.
 */
public final class PzFoods {
    public static Item CANNED_CORN, CANNED_PEACHES, CANNED_CHILI, CANNED_SARDINES, CANNED_STEW, CANNED_MILK, DOG_FOOD;
    public static Item OPEN_CORN, OPEN_PEACHES, OPEN_CHILI, OPEN_SARDINES, OPEN_STEW, OPEN_MILK, OPEN_DOG_FOOD;
    public static Item PEANUT_BUTTER, JAM, CRACKERS, GRANOLA_BAR, INSTANT_NOODLES, BEEF_JERKY, PICKLES, CANDY, POPCORN, MRE;
    public static Item JUICE_BOX, ENERGY_DRINK, SERUM, BOOK_AIMING;

    private static final List<Item> ALL = new ArrayList<>();

    private PzFoods() {
    }

    private static Item reg(String id, Item item) {
        Item it = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
        ALL.add(it);
        return it;
    }

    private static Item.Settings food(int nutrition, float sat) {
        return new Item.Settings().maxCount(16).food(new FoodComponent.Builder().nutrition(nutrition).saturationModifier(sat).build());
    }

    private static Item.Settings snack(int nutrition, float sat) {
        return new Item.Settings().maxCount(16).food(new FoodComponent.Builder().nutrition(nutrition).saturationModifier(sat).snack().build());
    }

    public static void register() {
        // открытые банки (портятся за пару дней)
        OPEN_CORN = reg("open_corn", new LootItems.FoodDrink(food(5, 0.5f), 4, "Открытая банка"));
        OPEN_PEACHES = reg("open_peaches", new LootItems.FoodDrink(food(4, 0.5f), 10, "Сладкие персики в сиропе: настроение лучше"));
        OPEN_CHILI = reg("open_chili", new LootItems.FoodDrink(food(8, 0.8f), -4, "Острое и сытное"));
        OPEN_SARDINES = reg("open_sardines", new LootItems.FoodDrink(food(5, 0.7f), -2, "Открытая банка"));
        OPEN_STEW = reg("open_stew", new LootItems.FoodDrink(food(8, 0.9f), 0, "Тушёное мясо — очень сытно"));
        OPEN_MILK = reg("open_milk", new LootItems.FoodDrink(food(4, 0.6f), 0, "Сладко! Поднимает настроение"));
        OPEN_DOG_FOOD = reg("open_dog_food", new LootItems.FoodDrink(food(6, 0.6f), 0, "Есть можно... но лучше не надо"));
        // закрытые консервы — хранятся годами
        CANNED_CORN = reg("canned_corn", new LootItems.Canned(new Item.Settings().maxCount(16), () -> OPEN_CORN));
        CANNED_PEACHES = reg("canned_peaches", new LootItems.Canned(new Item.Settings().maxCount(16), () -> OPEN_PEACHES));
        CANNED_CHILI = reg("canned_chili", new LootItems.Canned(new Item.Settings().maxCount(16), () -> OPEN_CHILI));
        CANNED_SARDINES = reg("canned_sardines", new LootItems.Canned(new Item.Settings().maxCount(16), () -> OPEN_SARDINES));
        CANNED_STEW = reg("canned_stew", new LootItems.Canned(new Item.Settings().maxCount(16), () -> OPEN_STEW));
        CANNED_MILK = reg("canned_milk", new LootItems.Canned(new Item.Settings().maxCount(16), () -> OPEN_MILK));
        DOG_FOOD = reg("dog_food", new LootItems.Canned(new Item.Settings().maxCount(16), () -> OPEN_DOG_FOOD));
        // сухое и сладкое — не портится
        PEANUT_BUTTER = reg("peanut_butter", new LootItems.FoodDrink(food(7, 0.8f), -3, "Банка арахисовой пасты: калорийно, хочется пить"));
        JAM = reg("jam", new LootItems.FoodDrink(food(3, 0.3f), 0, "Сладкое: настроение лучше"));
        CRACKERS = reg("crackers", new LootItems.FoodDrink(snack(3, 0.3f), -2, "Сухие и солёные"));
        GRANOLA_BAR = reg("granola_bar", new LootItems.FoodDrink(snack(4, 0.5f), 0, "Быстро съесть на ходу"));
        INSTANT_NOODLES = reg("instant_noodles", new LootItems.FoodDrink(food(4, 0.3f), -6, "Сухая лапша: солёная, хочется пить"));
        BEEF_JERKY = reg("beef_jerky", new LootItems.FoodDrink(snack(5, 0.7f), -4, "Вяленое мясо: не портится"));
        PICKLES = reg("pickles", new LootItems.FoodDrink(food(3, 0.4f), -2, "Банка маринованных огурцов"));
        CANDY = reg("candy", new LootItems.FoodDrink(snack(1, 0.1f), 0, "Леденцы: чуть веселее"));
        POPCORN = reg("popcorn", new LootItems.FoodDrink(snack(2, 0.2f), -2, "Попкорн: не так скучно"));
        MRE = reg("mre", new LootItems.FoodDrink(food(12, 1.0f), 0, "Армейский сухпаёк: сытный обед в пакете"));
        JUICE_BOX = reg("juice_box", new LootItems.Drink(new Item.Settings().maxCount(16), 30, 1, "Сок: +30% к воде"));
        ENERGY_DRINK = reg("energy_drink", new EnergyDrink(new Item.Settings().maxCount(16)));
        SERUM = reg("serum", new Serum(new Item.Settings().maxCount(4)));
        BOOK_AIMING = reg("book_aiming", new LootItems.SkillBook(new Item.Settings().maxCount(1), PzSkill.AIMING, "Меткая стрельба"));
    }

    public static List<Item> all() {
        return ALL;
    }

    /** Сроки свежести (дни: свежее, до гнили) — для системы порчи. */
    public static void freshness(BiConsumer<Item, float[]> put) {
        for (Item i : new Item[]{OPEN_CORN, OPEN_PEACHES, OPEN_CHILI, OPEN_SARDINES, OPEN_STEW, OPEN_MILK, OPEN_DOG_FOOD})
            put.accept(i, new float[]{2, 4});
    }

    /** Еда для настроения: {грусть, скука}. */
    public static float[] comfort(Item i) {
        if (i == OPEN_PEACHES || i == OPEN_MILK) return new float[]{-8, -4};
        if (i == JAM) return new float[]{-5, -3};
        if (i == CANDY) return new float[]{-5, -2};
        if (i == POPCORN) return new float[]{-2, -8};
        if (i == MRE) return new float[]{-6, -4};
        if (i == OPEN_DOG_FOOD) return new float[]{12, 8};
        if (i == INSTANT_NOODLES) return new float[]{2, 4};   // всухомятку — так себе
        return null;
    }

    /** Энергетик: бодрит (меньше усталости), но и пить хочется. */
    static class EnergyDrink extends LootItems.Drink {
        EnergyDrink(Settings s) {
            super(s, 15, 1, "Бодрит: меньше усталости");
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (!world.isClient && user instanceof ServerPlayerEntity p) {
                com.example.zomboidmod.survival.Mood m = com.example.zomboidmod.survival.Survival.mood(p);
                m.fatigue = Math.max(0f, m.fatigue - 0.25f);
                m.endurance = Math.min(1f, m.endurance + 0.3f);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600, 0, false, false));
            }
            return super.finishUsing(stack, world, user);
        }
    }

    /**
     * Экспериментальная сыворотка из карантинной зоны: единственное, что убивает вирус Нокс.
     * Укол тяжёлый: тошнота, слабость. Без заражения — просто плохо станет.
     */
    static class Serum extends Item {
        Serum(Settings s) {
            super(s);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, net.minecraft.item.tooltip.TooltipType type) {
            tooltip.add(Text.literal("Опытный образец из карантинной зоны").formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Убивает вирус Нокс в крови").formatted(Formatting.GREEN));
            tooltip.add(Text.literal("Зажмите ПКМ, чтобы сделать укол").formatted(Formatting.DARK_GRAY));
        }

        @Override
        public boolean hasGlint(ItemStack stack) {
            return true;
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            return 50;
        }

        @Override
        public UseAction getUseAction(ItemStack stack) {
            return UseAction.BOW;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            user.setCurrentHand(hand);
            return TypedActionResult.consume(user.getStackInHand(hand));
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (!world.isClient && user instanceof ServerPlayerEntity p) {
                boolean cured = Wounds.cureZombie(p);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 400, 0));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 1200, 0));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 600, 1));
                world.playSound(null, p.getBlockPos(), SoundEvents.ITEM_BOTTLE_EMPTY, SoundCategory.PLAYERS, 1f, 0.7f);
                p.sendMessage(Text.literal(cured ? "Жжёт по венам... Жар спадает. Вирус отступил!" : "Укол... Ничего, кроме тошноты: вы не были заражены")
                        .formatted(cured ? Formatting.GREEN : Formatting.YELLOW), false);
                stack.decrementUnlessCreative(1, user);
                if (stack.isEmpty()) return new ItemStack(Items.GLASS_BOTTLE);
                p.getInventory().offerOrDrop(new ItemStack(Items.GLASS_BOTTLE));
            }
            return stack;
        }
    }
}
