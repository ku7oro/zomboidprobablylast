package com.example.zomboidmod.mixin;

import com.example.zomboidmod.nature.Climate;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.biome.Biome;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Снег и лёд — по погоде, а не навсегда по биому: зимой снег идёт и ложится везде, где мороз,
 * а летом не выпадает даже в снежных биомах. От этого зависят осадки, сугробы и замерзание воды.
 */
@Mixin(Biome.class)
public abstract class BiomeMixin {
    @Inject(method = "doesNotSnow", at = @At("HEAD"), cancellable = true)
    private void zomboid$seasonalSnow(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(!Climate.freezing((Biome) (Object) this, pos));
    }
}
