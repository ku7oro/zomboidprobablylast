package com.example.zomboidmod.mixin;

import com.example.zomboidmod.media.Knowledge;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.CraftingResultInventory;
import net.minecraft.inventory.RecipeInputInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Рецепты из журналов (как в PZ): не читал журнал и не хватает навыка — результата в сетке крафта нет. */
@Mixin(CraftingScreenHandler.class)
public abstract class CraftingScreenHandlerMixin {
    @Inject(method = "updateResult", at = @At("RETURN"))
    private static void zomboid$gateRecipe(ScreenHandler handler, World world, PlayerEntity player, RecipeInputInventory craftingInventory,
                                           CraftingResultInventory resultInventory, RecipeEntry<CraftingRecipe> recipe, CallbackInfo ci) {
        if (world.isClient || !(player instanceof ServerPlayerEntity sp)) return;
        ItemStack out = resultInventory.getStack(0);
        if (out.isEmpty()) return;
        String why = Knowledge.check(sp, craftingInventory, out);
        if (why == null) return;
        resultInventory.setStack(0, ItemStack.EMPTY);
        handler.setPreviousTrackedSlot(0, ItemStack.EMPTY);
        sp.networkHandler.sendPacket(new ScreenHandlerSlotUpdateS2CPacket(handler.syncId, handler.nextRevision(), 0, ItemStack.EMPTY));
        sp.sendMessage(Text.literal(why).formatted(Formatting.GRAY), true);
    }
}
