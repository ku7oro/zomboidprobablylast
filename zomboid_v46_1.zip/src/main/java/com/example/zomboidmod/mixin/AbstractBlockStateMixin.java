package com.example.zomboidmod.mixin;

import com.example.zomboidmod.build.Carpentry;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Скорость ломания как в PZ: стены — только кувалдой, дерево — инструментом, и всё это долго. */
@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class AbstractBlockStateMixin {
    @Inject(method = "calcBlockBreakingDelta", at = @At("HEAD"), cancellable = true)
    private void zomboid$pzBreaking(PlayerEntity player, BlockView world, BlockPos pos, CallbackInfoReturnable<Float> cir) {
        float d = Carpentry.delta((BlockState) (Object) this, player, world, pos);
        if (!Float.isNaN(d)) cir.setReturnValue(d);
    }

    /** Сезоны: в холод урожай на улице не растёт, а мороз его губит. */
    @Inject(method = "randomTick", at = @At("HEAD"), cancellable = true)
    private void zomboid$seasonalGrowth(ServerWorld world, BlockPos pos, Random random, CallbackInfo ci) {
        if (com.example.zomboidmod.nature.Climate.blockGrowth((BlockState) (Object) this, world, pos, random)) ci.cancel();
    }
}
