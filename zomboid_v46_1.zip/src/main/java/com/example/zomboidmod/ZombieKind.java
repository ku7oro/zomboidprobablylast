package com.example.zomboidmod;

import com.example.zomboidmod.sandbox.Sandbox;
import net.minecraft.util.math.random.Random;

/**
 * Повадки зомби. Обычные (как в Project Zomboid): шатун, быстрый шатун, бегун, ползун, громила.
 * Особые (свои, редкие, в основном в опасных зонах): бронированный, крикун, раздутый, ярый и босс — Носитель.
 * Новые виды — только в конец: номер вида хранится в сохранённых зомби.
 */
public enum ZombieKind {
    SHAMBLER("Шатун", 0.16, 0.19, 22, 68),
    FAST_SHAMBLER("Быстрый шатун", 0.19, 0.24, 20, 20),
    SPRINTER("Бегун", 0.18, 0.33, 18, 4),   // идёт шагом, пока не заметил жертву, потом несётся
    CRAWLER("Ползун", 0.05, 0.06, 12, 7),   // ползёт, но хватает за ноги
    BRUTE("Громила", 0.15, 0.21, 70, 1),    // огромный и живучий: бьёт так, что отбрасывает, выносит двери с пары ударов
    ARMORED("Бронированный", 0.15, 0.20, 34, 0),   // в бронежилете и шлеме: пули и удары по корпусу почти не берут
    SCREAMER("Крикун", 0.17, 0.27, 16, 0),         // заметив человека, визжит — сбегаются все мертвецы округи
    BLOATER("Раздутый", 0.11, 0.14, 32, 0),        // лопается облаком трупного газа
    FERAL("Ярый", 0.20, 0.36, 24, 0),              // свежий, быстрый, бросается в прыжке
    CARRIER("Носитель", 0.17, 0.24, 420, 0);       // босс карантинной зоны: огромный, ревёт, поднимает мертвецов

    public final String title;
    public final double idleSpeed;
    public final double chaseSpeed;
    public final int health;
    public final int weight;

    ZombieKind(String title, double idleSpeed, double chaseSpeed, int health, int weight) {
        this.title = title;
        this.idleSpeed = idleSpeed;
        this.chaseSpeed = chaseSpeed;
        this.health = health;
        this.weight = weight;
    }

    public boolean special() {
        return ordinal() >= ARMORED.ordinal();
    }

    public static ZombieKind random(Random r) {
        int total = 0;
        for (ZombieKind k : values()) total += k.weight;
        int n = r.nextInt(total);
        for (ZombieKind k : values()) {
            n -= k.weight;
            if (n < 0) return k;
        }
        return SHAMBLER;
    }

    /**
     * Повадки с учётом опасности места: чем ценнее лут вокруг (полиция, оружейный, больница, военные),
     * тем больше бегунов и громил. tier 0 — жилой дом, 1 — магазин, 2 — полиция/аптека/оружие, 3 — военные/больница.
     */
    public static ZombieKind forTier(Random r, int tier) {
        float k = r.nextFloat();
        switch (tier) {
            case 1 -> {
                if (k < 0.04f) return BRUTE;
                if (k < 0.12f) return SPRINTER;
                if (k < 0.4f) return FAST_SHAMBLER;
            }
            case 2 -> {
                if (k < 0.12f) return BRUTE;
                if (k < 0.3f) return SPRINTER;
                if (k < 0.55f) return FAST_SHAMBLER;
            }
            case 3 -> {
                if (k < 0.22f) return BRUTE;
                if (k < 0.47f) return SPRINTER;
                if (k < 0.72f) return FAST_SHAMBLER;
            }
            default -> {
            }
        }
        return random(r);
    }

    /** Повадки нового зомби с учётом песочницы: скорость и особые зомби среди обычных. */
    public static ZombieKind pick(Random r, int tier) {
        ZombieKind k = forTier(r, tier);
        float sp = Sandbox.special() * (0.012f + 0.012f * tier);
        if (sp > 0 && k != BRUTE && k != CRAWLER && r.nextFloat() < sp) {
            float q = r.nextFloat();
            k = q < 0.34f ? SCREAMER : q < 0.62f ? BLOATER : (q < 0.88f || tier < 2) ? FERAL : ARMORED;
        }
        return withSpeed(k, r);
    }

    /** Песочница «Скорость зомби». */
    public static ZombieKind withSpeed(ZombieKind k, Random r) {
        switch (Sandbox.speedMode()) {
            case 0 -> {
                if (k == SPRINTER || k == FAST_SHAMBLER || k == FERAL) return SHAMBLER;
            }
            case 2 -> {
                if ((k == SHAMBLER || k == FAST_SHAMBLER) && r.nextFloat() < 0.22f) return SPRINTER;
            }
            case 3 -> {
                if (k == SHAMBLER || k == FAST_SHAMBLER) return SPRINTER;
            }
            default -> {
            }
        }
        return k;
    }
}
