package com.example.zomboidmod.combat;

import com.example.zomboidmod.PzZombieEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Отрубленная рука, нога или голова: отлетает от удара, кувыркается, падает и остаётся лежать —
 * в той же коже и одежде, что была на мертвеце. Через несколько минут исчезает.
 */
public class LimbEntity extends Entity {
    private static final TrackedData<Integer> LOOK = DataTracker.registerData(LimbEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> PART = DataTracker.registerData(LimbEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Optional<UUID>> SKIN = DataTracker.registerData(LimbEntity.class, TrackedDataHandlerRegistry.OPTIONAL_UUID);
    private static final TrackedData<Boolean> LANDED = DataTracker.registerData(LimbEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    /** Сколько тиков лежит. */
    private static final int LIFE = 20 * 60 * 4;
    private static final int CAP = 24;
    private int life;

    public LimbEntity(EntityType<? extends LimbEntity> type, World world) {
        super(type, world);
    }

    /** from — откуда ударили: конечность летит в противоположную сторону. */
    public static void spawn(ServerWorld w, PzZombieEntity z, Limbs.Part part, Vec3d at, Vec3d from) {
        if (Combat.LIMB == null) return;
        LimbEntity e = new LimbEntity(Combat.LIMB, w);
        e.refreshPositionAndAngles(at.x, at.y, at.z, w.getRandom().nextFloat() * 360f, 0f);
        e.dataTracker.set(LOOK, z.rawVariant());
        e.dataTracker.set(PART, part.ordinal());
        e.dataTracker.set(SKIN, Optional.of(z.getUuid()));
        Vec3d away = from == null ? Vec3d.ZERO : at.subtract(from).multiply(1, 0, 1);
        if (away.lengthSquared() < 1e-4) away = new Vec3d(w.getRandom().nextDouble() - 0.5, 0, w.getRandom().nextDouble() - 0.5);
        away = away.normalize().rotateY((w.getRandom().nextFloat() - 0.5f) * 1.2f);
        double sp = 0.16 + w.getRandom().nextDouble() * 0.14;
        e.setVelocity(away.x * sp, 0.24 + w.getRandom().nextDouble() * 0.14, away.z * sp);
        List<LimbEntity> near = w.getEntitiesByClass(LimbEntity.class, e.getBoundingBox().expand(24), Entity::isAlive);
        if (near.size() >= CAP) {   // не копить сотни обрубков: убрать самые старые
            near.sort((a, b) -> Integer.compare(b.life, a.life));
            for (int i = 0; i <= near.size() - CAP; i++) near.get(i).discard();
        }
        w.spawnEntity(e);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(LOOK, 0);
        builder.add(PART, Limbs.Part.ARM_R.ordinal());
        builder.add(SKIN, Optional.empty());
        builder.add(LANDED, false);
    }

    public int look() {
        return dataTracker.get(LOOK);
    }

    public Limbs.Part part() {
        Limbs.Part[] a = Limbs.Part.values();
        return a[Math.max(0, Math.min(a.length - 1, dataTracker.get(PART)))];
    }

    public UUID skin() {
        return dataTracker.get(SKIN).orElse(getUuid());
    }

    public boolean landed() {
        return dataTracker.get(LANDED);
    }

    @Override
    public void tick() {
        super.tick();
        if (!hasNoGravity()) setVelocity(getVelocity().add(0, -0.045, 0));
        move(MovementType.SELF, getVelocity());
        boolean ground = isOnGround();
        setVelocity(getVelocity().multiply(ground ? 0.55 : 0.98, 0.98, ground ? 0.55 : 0.98));
        World w = getWorld();
        if (w.isClient) return;
        if (ground && !landed()) {
            dataTracker.set(LANDED, true);
            w.playSound(null, getBlockPos(), SoundEvents.BLOCK_HONEY_BLOCK_FALL, SoundCategory.NEUTRAL, 0.7f, 0.7f + random.nextFloat() * 0.3f);
            if (w instanceof ServerWorld sw) {
                Combat.gore(sw, getPos().add(0, 0.1, 0), 6, 0.06);
                if (random.nextFloat() < 0.6f) Combat.stain(sw, getBlockPos(), random);
            }
        } else if (!ground && landed() && getVelocity().y < -0.1) {
            dataTracker.set(LANDED, false);   // из-под обрубка убрали блок — снова падает
        }
        if (++life > LIFE || isInLava() || getY() < w.getBottomY() - 8) discard();
    }

    @Override
    public boolean canHit() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        dataTracker.set(LOOK, nbt.getInt("Look"));
        dataTracker.set(PART, nbt.getInt("Part"));
        if (nbt.containsUuid("Skin")) dataTracker.set(SKIN, Optional.of(nbt.getUuid("Skin")));
        dataTracker.set(LANDED, nbt.getBoolean("Landed"));
        life = nbt.getInt("Life");
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putInt("Look", look());
        nbt.putInt("Part", dataTracker.get(PART));
        dataTracker.get(SKIN).ifPresent(u -> nbt.putUuid("Skin", u));
        nbt.putBoolean("Landed", landed());
        nbt.putInt("Life", life);
    }
}
