package com.example.zomboidmod.combat;

import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.block.DecalBlock;
import com.example.zomboidmod.block.ZomboidBlocks;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;

/** Бой по частям тела: отлетевшие конечности, звуки, кровь. Сама логика попаданий — в PzZombieEntity и Limbs. */
public final class Combat {
    private Combat() {
    }

    public static EntityType<LimbEntity> LIMB;
    public static SoundEvent CHOP, CRACK, SPLAT;

    private static SoundEvent sound(String id) {
        Identifier i = Identifier.of(ZomboidMod.MOD_ID, id);
        return Registry.register(Registries.SOUND_EVENT, i, SoundEvent.of(i));
    }

    public static void register() {
        LIMB = Registry.register(Registries.ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, "limb"),
                EntityType.Builder.<LimbEntity>create(LimbEntity::new, SpawnGroup.MISC).dimensions(0.4f, 0.25f).maxTrackingRange(6)
                        .trackingTickInterval(2).build("limb"));
        CHOP = sound("limb_chop");
        CRACK = sound("bone_crack");
        SPLAT = sound("head_splat");
    }

    /** Брызги крови. */
    public static void gore(ServerWorld w, Vec3d at, int count, double speed) {
        w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.getDefaultState()),
                at.x, at.y, at.z, count, 0.12, 0.12, 0.12, speed);
    }

    /** Пятно крови на земле под этой клеткой (если там есть куда лечь). */
    public static void stain(ServerWorld w, BlockPos at, Random r) {
        if (ZomboidBlocks.BLOOD == null) return;
        for (int dy = 0; dy >= -2; dy--) {
            BlockPos p = at.up(dy);
            BlockState here = w.getBlockState(p);
            if (!here.isAir()) continue;
            BlockState below = w.getBlockState(p.down());
            if (!below.isSideSolidFullSquare(w, p.down(), Direction.UP)) continue;
            w.setBlockState(p, ZomboidBlocks.BLOOD.getDefaultState().with(DecalBlock.VARIANT, r.nextInt(4))
                    .with(DecalBlock.FACING, Direction.Type.HORIZONTAL.random(r)));
            return;
        }
    }

    /** Короткая строка над панелью быстрого доступа: что случилось с мертвецом. */
    public static void tell(ServerPlayerEntity p, String text) {
        if (p != null) p.sendMessage(Text.literal(text).formatted(Formatting.RED), true);
    }
}
