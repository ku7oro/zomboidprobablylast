package com.example.zomboidmod.combat;

import com.example.zomboidmod.ZomboidMod;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/**
 * Как выглядит изувеченное тело (только клиент). Отрубленная часть скрывается, на её месте — короткий обрубок
 * в той же коже и одежде (те же места текстуры, что у целой руки или ноги) с кровавым срезом и костью;
 * вместо головы — шея с позвонком; сломанная челюсть отвисает. Одно и то же для живого мертвеца и для тела.
 */
public final class Gore {
    private Gore() {
    }

    private static final Identifier TEX = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/zombie/gore.png");
    private static ModelPart stubArmR, stubArmL, stubLegR, stubLegL;
    private static ModelPart capArmR, capArmL, capLegR, capLegL, neck, jaw;

    private static void init() {
        if (stubArmR != null) return;
        // обрубки: раскладка текстуры как у обычной модели зомби (64×64)
        ModelData md = new ModelData();
        ModelPartData r = md.getRoot();
        r.addChild("arm_r", ModelPartBuilder.create().uv(40, 16).cuboid(-3f, -2f, -2f, 4, 4, 4), ModelTransform.NONE);
        r.addChild("arm_l", ModelPartBuilder.create().uv(40, 16).mirrored().cuboid(-1f, -2f, -2f, 4, 4, 4), ModelTransform.NONE);
        r.addChild("leg_r", ModelPartBuilder.create().uv(0, 16).cuboid(-2f, 0f, -2f, 4, 3, 4), ModelTransform.NONE);
        r.addChild("leg_l", ModelPartBuilder.create().uv(0, 16).mirrored().cuboid(-2f, 0f, -2f, 4, 3, 4), ModelTransform.NONE);
        ModelPart stubs = TexturedModelData.of(md, 64, 64).createModel();
        stubArmR = stubs.getChild("arm_r");
        stubArmL = stubs.getChild("arm_l");
        stubLegR = stubs.getChild("leg_r");
        stubLegL = stubs.getChild("leg_l");
        // срезы, кости, шея, челюсть: своя текстура (32×32)
        ModelData gd = new ModelData();
        ModelPartData g = gd.getRoot();
        g.addChild("arm_r", ModelPartBuilder.create().uv(0, 0).cuboid(-2.5f, 2f, -1.5f, 3, 1, 3).uv(24, 0).cuboid(-1.5f, 3f, -0.5f, 1, 1, 1), ModelTransform.NONE);
        g.addChild("arm_l", ModelPartBuilder.create().uv(0, 0).cuboid(-0.5f, 2f, -1.5f, 3, 1, 3).uv(24, 0).cuboid(0.5f, 3f, -0.5f, 1, 1, 1), ModelTransform.NONE);
        g.addChild("leg_r", ModelPartBuilder.create().uv(0, 0).cuboid(-1.5f, 3f, -1.5f, 3, 1, 3).uv(24, 0).cuboid(-0.5f, 4f, -0.5f, 1, 1, 1), ModelTransform.NONE);
        g.addChild("leg_l", ModelPartBuilder.create().uv(0, 0).cuboid(-1.5f, 3f, -1.5f, 3, 1, 3).uv(24, 0).cuboid(-0.5f, 4f, -0.5f, 1, 1, 1), ModelTransform.NONE);
        g.addChild("neck", ModelPartBuilder.create().uv(0, 6).cuboid(-2f, -1.5f, -1.5f, 4, 2, 3).uv(24, 0).cuboid(-0.5f, -2.5f, -0.5f, 1, 1, 1), ModelTransform.NONE);
        ModelPartData j = g.addChild("jaw", ModelPartBuilder.create().uv(0, 12).cuboid(-3f, -3.2f, -5.1f, 6, 3, 1, new Dilation(0f, 0f, -0.35f)), ModelTransform.NONE);
        j.addChild("drop", ModelPartBuilder.create().uv(0, 18).cuboid(-2.5f, 0f, -0.9f, 5, 2, 1), ModelTransform.of(0f, -0.6f, -4.4f, -0.3f, 0f, 0.12f));
        ModelPart caps = TexturedModelData.of(gd, 32, 32).createModel();
        capArmR = caps.getChild("arm_r");
        capArmL = caps.getChild("arm_l");
        capLegR = caps.getChild("leg_r");
        capLegL = caps.getChild("leg_l");
        neck = caps.getChild("neck");
        jaw = caps.getChild("jaw");
    }

    /** Скрыть отсечённое. Модель общая на всех, поэтому выставляется каждый раз заново. */
    public static void visibility(BipedEntityModel<?> m, int l) {
        m.head.visible = (l & Limbs.HEAD) == 0;
        m.hat.visible = m.head.visible;
        m.rightArm.visible = (l & Limbs.ARM_R) == 0;
        m.leftArm.visible = (l & Limbs.ARM_L) == 0;
        m.rightLeg.visible = (l & Limbs.LEG_R) == 0;
        m.leftLeg.visible = (l & Limbs.LEG_L) == 0;
    }

    /** Обрубки и срезы поверх уже нарисованной модели (с теми же поворотами частей). clothes может быть null. */
    public static void render(BipedEntityModel<?> m, int l, MatrixStack ms, VertexConsumerProvider vcp, int light, int overlay, int color,
                              Identifier body, Identifier clothes) {
        int gone = l & (Limbs.ARM_R | Limbs.ARM_L | Limbs.LEG_R | Limbs.LEG_L);
        boolean head = (l & Limbs.HEAD) != 0, jawHangs = !head && (l & Limbs.JAW) != 0;
        if (gone == 0 && !head && !jawHangs) return;
        init();
        stubArmR.copyTransform(m.rightArm);
        stubArmL.copyTransform(m.leftArm);
        stubLegR.copyTransform(m.rightLeg);
        stubLegL.copyTransform(m.leftLeg);
        capArmR.copyTransform(m.rightArm);
        capArmL.copyTransform(m.leftArm);
        capLegR.copyTransform(m.rightLeg);
        capLegL.copyTransform(m.leftLeg);
        neck.copyTransform(m.body);
        jaw.copyTransform(m.head);
        if (gone != 0) {
            stubs(gone, ms, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(body)), light, overlay, color);
            if (clothes != null) stubs(gone, ms, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(clothes)), light, overlay, color);
        }
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX));
        if ((gone & Limbs.ARM_R) != 0) capArmR.render(ms, vc, light, overlay, color);
        if ((gone & Limbs.ARM_L) != 0) capArmL.render(ms, vc, light, overlay, color);
        if ((gone & Limbs.LEG_R) != 0) capLegR.render(ms, vc, light, overlay, color);
        if ((gone & Limbs.LEG_L) != 0) capLegL.render(ms, vc, light, overlay, color);
        if (head) neck.render(ms, vc, light, overlay, color);
        if (jawHangs) jaw.render(ms, vc, light, overlay, color);
    }

    private static void stubs(int gone, MatrixStack ms, VertexConsumer vc, int light, int overlay, int color) {
        if ((gone & Limbs.ARM_R) != 0) stubArmR.render(ms, vc, light, overlay, color);
        if ((gone & Limbs.ARM_L) != 0) stubArmL.render(ms, vc, light, overlay, color);
        if ((gone & Limbs.LEG_R) != 0) stubLegR.render(ms, vc, light, overlay, color);
        if ((gone & Limbs.LEG_L) != 0) stubLegL.render(ms, vc, light, overlay, color);
    }
}
