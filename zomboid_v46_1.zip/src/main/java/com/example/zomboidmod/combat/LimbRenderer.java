package com.example.zomboidmod.combat;

import com.example.zomboidmod.PzZombieRenderer;
import com.example.zomboidmod.ZombieKind;
import com.example.zomboidmod.ZombieOutfit;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

import java.util.UUID;

/** Отлетевшая часть тела: та же модель и текстуры, что у мертвеца. В полёте кувыркается, на земле лежит. */
public class LimbRenderer extends EntityRenderer<LimbEntity> {
    private final BipedEntityModel<LivingEntity> model;

    public LimbRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        model = new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE));
        model.child = false;
        this.shadowRadius = 0.2f;
    }

    @Override
    public void render(LimbEntity e, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vcp, int light) {
        Limbs.Part part = e.part();
        int look = e.look();
        UUID skin = e.skin();
        ZombieKind[] ks = ZombieKind.values();
        ZombieOutfit[] os = ZombieOutfit.values();
        ZombieKind kind = look < 0 ? ZombieKind.SHAMBLER : ks[Math.min((look >> 16) & 255, ks.length - 1)];
        ZombieOutfit outfit = look < 0 ? os[0] : os[Math.min(look & 255, os.length - 1)];
        Identifier body = PzZombieRenderer.bodyTex(skin, look < 0 ? 0 : (look >> 8) & 255, kind);
        float scale = switch (kind) {
            case BRUTE -> 1.3f;
            case BLOATER -> 1.12f;
            case ARMORED -> 1.05f;
            default -> 1f;
        };
        ModelPart p = switch (part) {
            case HEAD -> model.head;
            case ARM_L -> model.leftArm;
            case LEG_R -> model.rightLeg;
            case LEG_L -> model.leftLeg;
            default -> model.rightArm;
        };
        boolean head = part == Limbs.Part.HEAD;
        long seed = e.getUuid().getLeastSignificantBits();
        float rest = ((seed >>> 4) & 255) / 255f;
        matrices.push();
        matrices.translate(0f, head ? 0.25f * scale : 0.125f * scale, 0f);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-e.getYaw()));
        if (e.landed()) {
            if (head) matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(70f + rest * 40f));   // голова на боку
            else matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90f));                    // рука или нога плашмя
        } else {
            float t = e.age + tickDelta;
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(t * 31f));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(t * 17f + rest * 360f));
        }
        matrices.scale(-scale, -scale, scale);
        // середина части — в начало координат (в единицах модели: 1/16 блока)
        float cx = part == Limbs.Part.ARM_R ? 1f : part == Limbs.Part.ARM_L ? -1f : 0f;
        float cy = head ? 4f : part.arm() ? -4f : -6f;
        matrices.translate(cx / 16f, cy / 16f, 0f);
        p.resetTransform();
        p.setPivot(0f, 0f, 0f);
        p.visible = true;
        p.render(matrices, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(body)), light, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
        if (head) {
            model.hat.resetTransform();
            model.hat.setPivot(0f, 0f, 0f);
        }
        if (kind != ZombieKind.CARRIER) {
            var vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(outfit.outfitTexture(skin)));
            p.render(matrices, vc, light, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
            if (head) model.hat.render(matrices, vc, light, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
        }
        matrices.pop();
        super.render(e, yaw, tickDelta, matrices, vcp, light);
    }

    @Override
    public Identifier getTexture(LimbEntity e) {
        return PzZombieRenderer.bodyTex(e.skin(), 0, ZombieKind.SHAMBLER);
    }
}
