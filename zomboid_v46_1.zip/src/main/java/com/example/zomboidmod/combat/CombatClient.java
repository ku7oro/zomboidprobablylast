package com.example.zomboidmod.combat;

import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public final class CombatClient {
    private CombatClient() {
    }

    public static void init() {
        EntityRendererRegistry.register(Combat.LIMB, LimbRenderer::new);
    }
}
