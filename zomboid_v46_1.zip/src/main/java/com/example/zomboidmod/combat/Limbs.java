package com.example.zomboidmod.combat;

import com.example.zomboidmod.PzWeaponItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.SwordItem;

/**
 * Тело мертвеца по частям. Куда попал — то и пострадало: клинок и топор рубят конечности, дробящее их ломает,
 * пуля перебивает (а крупный калибр и дробь в упор — отрывает). Без рук не схватить, без ног — только ползти,
 * со сломанной челюстью не укусить, без головы — конец.
 * Состояние — набор битов (одно число на зомби и на его тело после смерти).
 */
public final class Limbs {
    private Limbs() {
    }

    // оторвано / отрублено
    public static final int ARM_R = 1, ARM_L = 2, LEG_R = 4, LEG_L = 8, HEAD = 16;
    // сломано (конечность на месте, но не работает)
    public static final int ARM_R_BROKEN = 32, ARM_L_BROKEN = 64, LEG_R_BROKEN = 128, LEG_L_BROKEN = 256, JAW = 512;

    public enum Part {
        HEAD(Limbs.HEAD, 0, "голова"),
        TORSO(0, 0, "корпус"),
        ARM_R(Limbs.ARM_R, ARM_R_BROKEN, "правая рука"),
        ARM_L(Limbs.ARM_L, ARM_L_BROKEN, "левая рука"),
        LEG_R(Limbs.LEG_R, LEG_R_BROKEN, "правая нога"),
        LEG_L(Limbs.LEG_L, LEG_L_BROKEN, "левая нога");

        public final int gone, broken;
        public final String title;

        Part(int gone, int broken, String title) {
            this.gone = gone;
            this.broken = broken;
            this.title = title;
        }

        public boolean arm() {
            return this == ARM_R || this == ARM_L;
        }

        public boolean leg() {
            return this == LEG_R || this == LEG_L;
        }

        public boolean limb() {
            return arm() || leg();
        }
    }

    /** Чем ударили. */
    public enum Hit {
        BLADE, BLUNT, PIERCE, SHOT, BLAST, RAM, FALL, OTHER
    }

    /** Сколько рук ещё могут хватать (не оторваны и не сломаны). */
    public static int armsUsable(int l) {
        int n = 0;
        if ((l & (ARM_R | ARM_R_BROKEN)) == 0) n++;
        if ((l & (ARM_L | ARM_L_BROKEN)) == 0) n++;
        return n;
    }

    /** Стоять не на чем: нет ноги или перебиты обе. */
    public static boolean crawls(int l) {
        return (l & (LEG_R | LEG_L)) != 0 || ((l & LEG_R_BROKEN) != 0 && (l & LEG_L_BROKEN) != 0);
    }

    /** Одна нога перебита — хромает. */
    public static boolean limps(int l) {
        return !crawls(l) && (l & (LEG_R_BROKEN | LEG_L_BROKEN)) != 0;
    }

    public static boolean jawBroken(int l) {
        return (l & JAW) != 0;
    }

    public static boolean has(int l, Part p) {
        return (l & p.gone) == 0;
    }

    // ------------------------------------------------------------------ оружие

    public static Hit hitOf(ItemStack st) {
        Item i = st.getItem();
        if (i instanceof PzWeaponItem w) return w.hitKind();
        if (i instanceof AxeItem || i instanceof SwordItem) return Hit.BLADE;
        return Hit.BLUNT;
    }

    /**
     * Сила оружия для этого вида удара: у клинка — насколько хорошо рубит (нож 0.25, тесак 0.8, мачете 1, катана 1.25),
     * у дробящего — насколько хорошо ломает кости (кулак 0.35, лопата 0.8, бита 1).
     */
    public static float powerOf(ItemStack st) {
        Item i = st.getItem();
        if (i instanceof PzWeaponItem w) return w.limbPower();
        if (i instanceof AxeItem) return 1.1f;
        if (i instanceof SwordItem) return 1f;
        if (i instanceof MiningToolItem) return 0.8f;
        return 0.35f;
    }

    /** Во сколько раз удар в эту часть тела опаснее (или безопаснее) для жизни, чем в корпус. */
    public static float healthMult(Part part, Hit hit, float power) {
        if (hit == Hit.BLAST || hit == Hit.RAM || hit == Hit.FALL || hit == Hit.OTHER) return 1f;
        if (part == Part.HEAD) {
            if (hit == Hit.SHOT) return 1f;                       // выстрел в голову уже усилен самим оружием
            if (hit == Hit.PIERCE || (hit == Hit.BLADE && power < 0.5f)) return 1.8f;   // нож и копьё — точно в глаз
            return 1.5f;
        }
        if (part.limb()) return hit == Hit.SHOT ? 0.5f : 0.4f;    // от ран в руки и ноги мертвецы не умирают
        return 1f;
    }

    /** Доля здоровья мертвеца, которую надо «прорубить», чтобы отнять эту часть. */
    public static float severAt(Part p) {
        return p.arm() ? 0.40f : p.leg() ? 0.55f : 0.60f;
    }

    /** Доля здоровья, после которой кость ломается. */
    public static float breakAt(Part p) {
        return p.arm() ? 0.35f : 0.45f;
    }
}
