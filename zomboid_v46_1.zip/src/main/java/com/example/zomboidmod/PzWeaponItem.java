package com.example.zomboidmod;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * Холодное оружие в духе PZ. Дробящее (бита, монтировка, сковорода, молоток) отбрасывает и может сбить
 * с ног: сбитый зомби ненадолго замирает. Режущее (ножи, мачете) бьёт быстрее и сильнее, но ломается чаще.
 */
public class PzWeaponItem extends SwordItem {
    private final boolean blunt;
    private final float knockdown;

    /** totalDamage - итоговый урон, как в подсказке Minecraft (вместе с базовым 1 урона игрока). */
    public PzWeaponItem(ToolMaterial material, int totalDamage, float attackSpeed, int durability,
                        boolean blunt, float knockdown, Settings settings) {
        this(material, totalDamage, attackSpeed, durability, blunt, knockdown, 0f, settings);
    }

    /** reach — насколько дальше достаёт (копьё, вилы). */
    public PzWeaponItem(ToolMaterial material, int totalDamage, float attackSpeed, int durability,
                        boolean blunt, float knockdown, float reach, Settings settings) {
        super(material, settings.maxDamage(durability).attributeModifiers(withReach(SwordItem.createAttributeModifiers(
                material, Math.max(0, totalDamage - 1 - Math.round(material.getAttackDamage())), attackSpeed), reach)));
        this.blunt = blunt;
        this.knockdown = knockdown;
        this.reach = reach;
        this.total = totalDamage;
        this.speed = attackSpeed;
    }

    private final float reach;
    private final int total;
    private final float speed;

    /** Чем это оружие бьёт по телу: дробит кости, рубит конечности или колет. */
    public com.example.zomboidmod.combat.Limbs.Hit hitKind() {
        if (blunt) return com.example.zomboidmod.combat.Limbs.Hit.BLUNT;
        if (reach >= 1f) return com.example.zomboidmod.combat.Limbs.Hit.PIERCE;   // копьё, вилы
        return com.example.zomboidmod.combat.Limbs.Hit.BLADE;
    }

    /** Короткий клинок (нож, скальпель, шило): конечность им не отрубить, зато в голову бьёт точно. */
    public boolean shortBlade() {
        return !blunt && reach < 1f && speed > -2.05f;
    }

    /** Насколько хорошо рубит (клинок) или ломает кости (дробящее). */
    public float limbPower() {
        if (blunt) return Math.max(0.6f, Math.min(1.5f, total / 6f));
        if (reach >= 1f) return 0.5f;
        if (shortBlade()) return 0.25f;
        return Math.max(0.6f, Math.min(1.25f, total / 8f));
    }

    private static net.minecraft.component.type.AttributeModifiersComponent withReach(net.minecraft.component.type.AttributeModifiersComponent c, float reach) {
        if (reach <= 0f) return c;
        return c.with(net.minecraft.entity.attribute.EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE,
                new net.minecraft.entity.attribute.EntityAttributeModifier(net.minecraft.util.Identifier.of(ZomboidMod.MOD_ID, "weapon_reach"), reach,
                        net.minecraft.entity.attribute.EntityAttributeModifier.Operation.ADD_VALUE),
                net.minecraft.component.type.AttributeModifierSlot.MAINHAND);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (blunt) knockDown(target, attacker, knockdown);
        return super.postHit(stack, target, attacker);
    }

    static void knockDown(LivingEntity target, LivingEntity attacker, float chance) {
        target.takeKnockback(0.5, attacker.getX() - target.getX(), attacker.getZ() - target.getZ());
        if (attacker.getRandom().nextFloat() < chance) {
            if (target instanceof PzZombieEntity z) {   // по-настоящему падает, а потом встаёт
                z.knockDown(40 + attacker.getRandom().nextInt(35), z.fallsFaceDown(attacker.getPos()));
                return;
            }
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 9, false, false));
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 40, 4, false, false));
        }
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal(blunt ? "Дробящее: сбивает с ног, ломает руки, ноги и челюсти"
                : reach >= 1f ? "Колющее: точный удар в голову" : shortBlade() ? "Короткий клинок: точный удар в голову"
                : "Рубящее: отсекает руки, ноги и головы").formatted(Formatting.GRAY));
        if (reach > 0f) tooltip.add(Text.literal("Длинное: достаёт дальше обычного").formatted(Formatting.GRAY));
    }

    /** Уход за оружием: с шансом удар не отнимает прочность. */
    public void postDamageEntity(ItemStack stack, net.minecraft.entity.LivingEntity target, net.minecraft.entity.LivingEntity attacker) {
        if (Skills.saveDurability(attacker)) return;
        super.postDamageEntity(stack, target, attacker);
    }
}
