package com.example.zomboidmod.survivors;

import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.gun.NpcGuns;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.FleeEntityGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LongDoorInteractGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.ai.pathing.MobNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.village.TradeOffer;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.UUID;

/**
 * Живой выживший. Роли: мирный (можно уговорить пойти с тобой), бандит (грабит и стреляет),
 * торговец (меняет вещи, денег больше нет). Напарник слушается команд: «за мной», «жди», «охраняй»;
 * его надо кормить, иначе уйдёт. Укус зомби заражает: через сутки-двое человек обращается.
 * Зомби охотятся на выживших так же, как на игрока, а выстрелы NPC собирают мертвецов со всей округи.
 */
public class SurvivorEntity extends MerchantEntity {
    public static final int NEUTRAL = 0, BANDIT = 1, TRADER = 2;
    public static final int FOLLOW = 0, WAIT = 1, GUARD = 2;
    private static final TrackedData<Integer> SKIN = DataTracker.registerData(SurvivorEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> ROLE = DataTracker.registerData(SurvivorEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Boolean> AIMING = DataTracker.registerData(SurvivorEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    @Nullable UUID owner;
    int mode = FOLLOW;
    @Nullable BlockPos guardPos;
    int trust;
    float food = 80f;
    long infectedAt = -1, bornAt = -1, calmUntil;
    int ammo;
    /** В беде: окружён мертвецами и зовёт на помощь (событие мира). */
    boolean rescue;
    private int rescueCalm;
    // тело после смерти: вещи складываются в него
    private boolean collecting, bodyDone, leaveBody;
    private final java.util.List<ItemStack> pendingLoot = new java.util.ArrayList<>();
    @Nullable UUID grudge;          // кто на него напал (мирный станет врагом)
    private int warnedAge = -1, farTicks, shotCd, lastSpeech = -1000, starving, ownerHits;
    String seenTraderStock = "";

    public SurvivorEntity(EntityType<? extends MerchantEntity> type, World world) {
        super(type, world);
        if (getNavigation() instanceof MobNavigation nav) {
            nav.setCanPathThroughDoors(true);
            nav.setCanEnterOpenDoors(true);
        }
    }

    public static DefaultAttributeContainer.Builder attributes() {
        return MobEntity.createMobAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0).add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.33)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 2.0).add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(SKIN, 0);
        builder.add(ROLE, NEUTRAL);
        builder.add(AIMING, false);
    }

    public int skin() {
        return dataTracker.get(SKIN);
    }

    public void setSkin(int s) {
        dataTracker.set(SKIN, s);
    }

    public int role() {
        return dataTracker.get(ROLE);
    }

    public void setRole(int r) {
        dataTracker.set(ROLE, r);
    }

    public boolean aiming() {
        return dataTracker.get(AIMING);
    }

    public boolean isFollower() {
        return owner != null;
    }

    public boolean isBandit() {
        return role() == BANDIT;
    }

    // =====================================================================================
    //                                       поведение
    // =====================================================================================

    /** Бежать: слишком много мертвецов рядом или сильно ранен. */
    boolean shouldFlee() {
        if (getHealth() < getMaxHealth() * 0.3f) return true;
        return getWorld().getEntitiesByClass(PzZombieEntity.class, getBoundingBox().expand(9), e -> e.isAlive()).size() >= (isFollower() ? 6 : 4);
    }

    boolean armed() {
        ItemStack s = getMainHandStack();
        return !s.isEmpty();
    }

    boolean hasGun() {
        return NpcGuns.isGun(getMainHandStack().getItem()) && ammo > 0;
    }

    @Nullable PlayerEntity ownerPlayer() {
        return owner == null ? null : getWorld().getPlayerByUuid(owner);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new FleeEntityGoal<>(this, ZombieEntity.class, 10f, 1.0, 1.35, e -> shouldFlee()));
        this.goalSelector.add(2, new ShootGoal());
        this.goalSelector.add(3, new MeleeAttackGoal(this, 1.15, false) {
            @Override
            public boolean canStart() {
                return !hasGun() && super.canStart();
            }
        });
        this.goalSelector.add(4, new FollowOwnerGoal());
        this.goalSelector.add(5, new GuardGoal());
        this.goalSelector.add(6, new LongDoorInteractGoal(this, true));
        this.goalSelector.add(7, new WanderAroundFarGoal(this, 0.75) {
            @Override
            public boolean canStart() {
                return !isFollower() && super.canStart();
            }
        });
        this.goalSelector.add(8, new LookAtEntityGoal(this, PlayerEntity.class, 8f));
        this.goalSelector.add(9, new LookAroundGoal(this));

        this.targetSelector.add(1, new RevengeGoal(this));
        // мертвецы рядом: вооружённый дерётся, безоружный держится подальше
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PzZombieEntity.class, 10, true, false,
                e -> (armed() || isFollower()) && !shouldFlee() && distanceTo(e) < (isFollower() ? 16f : 10f)));
        // бандит: сначала окрикнет, потом нападёт
        this.targetSelector.add(3, new ActiveTargetGoal<>(this, PlayerEntity.class, 10, true, false,
                e -> e instanceof PlayerEntity p && hostileTo(p)));
        // бандиты и остальные выжившие — враги: стычки слышно издалека
        this.targetSelector.add(4, new ActiveTargetGoal<>(this, SurvivorEntity.class, 10, true, false,
                e -> e instanceof SurvivorEntity o && o.isAlive() && o.isBandit() != isBandit() && (isBandit() || armed())
                        && !(isFollower() && o.isFollower()) && distanceTo(e) < 22f));
    }

    /** Нападать ли на игрока. */
    boolean hostileTo(PlayerEntity p) {
        if (p.isCreative() || p.isSpectator()) return false;
        if (grudge != null && grudge.equals(p.getUuid())) return true;
        if (!isBandit() || getWorld().getTime() < calmUntil) return false;
        double d = distanceTo(p);
        if (d < 5) return true;                                     // подошёл вплотную — сразу
        return warnedAge >= 0 && age - warnedAge > 70 && d < 14;   // не ушёл после окрика
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient || !(getWorld() instanceof ServerWorld w)) return;
        if (shotCd > 0) shotCd--;
        if (bornAt < 0) bornAt = w.getTime();
        if (age % 20 == 0) second(w);
    }

    private boolean greeted;

    private void second(ServerWorld w) {
        if (!hasCustomName()) Survivors.init(this, NEUTRAL, random);   // из яйца призыва
        dataTracker.set(AIMING, getTarget() != null && hasGun() && canSee(getTarget()));
        PlayerEntity near = w.getClosestPlayer(this, 24);
        if (!greeted && !isBandit() && !isFollower() && near != null && distanceTo(near) < 10 && canSee(near)) {
            greeted = true;
            say(Survivors.line(role() == TRADER ? "trader_greet" : "greet", random), 16);
        }
        // бандит окрикивает
        if (isBandit() && near != null && !near.isCreative() && w.getTime() >= calmUntil) {
            double d = distanceTo(near);
            if (warnedAge < 0 && d < 18 && canSee(near)) {
                warnedAge = age;
                say(Survivors.line("bandit_warn", random), 24);
            } else if (warnedAge >= 0 && d > 26) warnedAge = -1;
        }
        // лечится понемногу, когда не в бою
        if (getTarget() == null && age - getLastAttackedTime() > 200 && getHealth() < getMaxHealth() && age % 200 == 0) heal(1f);
        // напарник: голод, защита хозяина
        if (isFollower()) {
            food = Math.max(0f, food - 100f / (24000f / 20f));      // сутки без еды — пустой желудок
            PlayerEntity o = ownerPlayer();
            if (o != null) {
                LivingEntity threat = o.getAttacker();
                if (threat != null && threat.isAlive() && threat != this && o.age - o.getLastAttackedTime() < 100 && distanceTo(threat) < 20)
                    setTarget(threat);
                LivingEntity hit = o.getAttacking();
                if (hit instanceof PzZombieEntity && hit.isAlive() && distanceTo(hit) < 16 && getTarget() == null) setTarget(hit);
            }
            if (food <= 0f) {
                if (++starving % 300 == 1) say(Survivors.line("hungry", random), 16);
                if (starving > 1200) {                               // сутки голодал — уходит
                    say(Survivors.line("leave_hungry", random), 20);
                    dismiss();
                }
            } else if (food < 25f && age % 1200 == 0) say(Survivors.line("hungry", random), 16);
            else starving = 0;
        }
        // заражён: через сутки-двое обращается
        if (infectedAt >= 0) {
            long t = w.getTime() - infectedAt;
            if (t > 12000 && age % 2400 == 0) say(Survivors.line("sick", random), 16);
            if (t > 24000 + (getUuid().getLeastSignificantBits() & 0x5FFF)) {
                Survivors.reanimate(w, this);
                discard();
                return;
            }
        }
        // в беде: зовёт на помощь, пока рядом мертвецы; спасителю — награда и доверие
        if (rescue) rescueTick(w);
        // разговоры в бою
        if (getTarget() instanceof PzZombieEntity && random.nextInt(12) == 0) say(Survivors.line("combat", random), 16);
        if (getTarget() instanceof SurvivorEntity && random.nextInt(10) == 0) say(Survivors.line(isBandit() ? "feud_bandit" : "feud_neutral", random), 24);
        if (shouldFlee() && random.nextInt(10) == 0) say(Survivors.line("flee", random), 16);
        // исчезают, если долго никого рядом (кроме напарников)
        if (!isFollower() && !isPersistent()) {
            if (w.getClosestPlayer(this, 160) == null) farTicks += 20;
            else farTicks = 0;
            boolean traderLeaves = role() == TRADER && w.getTime() - bornAt > 2 * 24000 && near == null;
            if (farTicks > 2400 || traderLeaves) discard();
        }
    }

    private void rescueTick(ServerWorld w) {
        int zombies = w.getEntitiesByClass(PzZombieEntity.class, getBoundingBox().expand(12), z -> z.isAlive()).size();
        if (zombies > 0) {
            rescueCalm = 0;
            if (age - lastSpeech >= 120 && random.nextInt(3) == 0) {
                say(Survivors.line("help", random), 24);
                com.example.zomboidmod.life.Encounters.callForHelp(w, this);   // далёкие слышат крик и направление
            }
            return;
        }
        PlayerEntity near = w.getClosestPlayer(this, 14);
        if (near instanceof ServerPlayerEntity sp && !sp.isSpectator() && ++rescueCalm >= 3) {
            rescue = false;
            lastSpeech = -1000;
            say(Survivors.line("rescued", random), 16);
            Survivors.reward(w, this, sp);
            trust = Math.max(trust, 75);   // готов пойти за спасителем
            calmUntil = w.getTime() + 24000;
        } else if (rescueCalm > 120) {
            rescue = false;                // отбился сам или спасать никто не пришёл
        }
    }

    /** Реплика: в чат всем рядом, не чаще раза в 6 секунд. */
    void say(String text, int radius) {
        if (text == null || age - lastSpeech < 120 || !(getWorld() instanceof ServerWorld w)) return;
        lastSpeech = age;
        Survivors.speak(w, this, text, radius);
    }

    void dismiss() {
        owner = null;
        mode = FOLLOW;
        guardPos = null;
        starving = 0;
        trust = Math.min(trust, 40);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        boolean hurt = super.damage(source, amount);
        if (!hurt || getWorld().isClient) return hurt;
        if (source.getAttacker() instanceof ZombieEntity && infectedAt < 0 && random.nextFloat() < 0.25f) {
            infectedAt = getWorld().getTime();                      // укус
        }
        if (source.getAttacker() instanceof PlayerEntity p && !p.isCreative()) {
            if (owner != null && owner.equals(p.getUuid())) {
                if (++ownerHits >= 3) {                             // хозяин бьёт — уходит и злится
                    say(Survivors.line("betrayed", random), 20);
                    dismiss();
                    grudge = p.getUuid();
                } else say(Survivors.line("ouch_owner", random), 16);
            } else if (!isBandit()) {
                grudge = p.getUuid();
                trust = 0;
                say(Survivors.line("attacked", random), 20);
            }
        }
        return hurt;
    }

    @Override
    public net.minecraft.entity.ItemEntity dropStack(ItemStack stack, float yOffset) {
        if (collecting) {
            if (!stack.isEmpty()) pendingLoot.add(stack.copy());
            return null;
        }
        return super.dropStack(stack, yOffset);
    }

    @Override
    protected void updatePostDeath() {
        super.updatePostDeath();
        if (!getWorld().isClient && deathTime >= 20 && !bodyDone && getWorld() instanceof ServerWorld w) {
            bodyDone = true;
            if (leaveBody) {
                com.example.zomboidmod.life.BodyEntity b = com.example.zomboidmod.life.BodyEntity.spawn(w, getX(), getY(), getZ(), bodyYaw, -(skin() + 1), getUuid(), pendingLoot, false);
                if (b != null) b.setFallPose(com.example.zomboidmod.life.BodyEntity.fallPose(getUuid(), com.example.zomboidmod.life.BodyEntity.survivorFace(getUuid())));
            }
            else for (ItemStack st : pendingLoot) super.dropStack(st, 0f);
            pendingLoot.clear();
        }
    }

    @Override
    public void onDeath(DamageSource source) {
        boolean willTurn = source.getAttacker() instanceof ZombieEntity || infectedAt >= 0;
        leaveBody = !willTurn;               // укушенный встанет мертвецом — тела не будет
        collecting = !getWorld().isClient && leaveBody;   // вещи — в тело
        try {
            onDeathInner(source);
        } finally {
            collecting = false;
        }
    }

    private void onDeathInner(DamageSource source) {
        if (!getWorld().isClient && getWorld() instanceof ServerWorld w) {
            ItemStack hand = getMainHandStack();
            if (!hand.isEmpty() && random.nextFloat() < 0.8f) dropStack(hand.copy());
            equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            Survivors.dropLoot(w, this);
            boolean bitten = source.getAttacker() instanceof ZombieEntity || infectedAt >= 0;
            if (bitten) Survivors.reanimateLater(w, this);
            PlayerEntity o = ownerPlayer();
            if (o != null) o.sendMessage(net.minecraft.text.Text.literal(getName().getString() + " погиб(ла)").formatted(net.minecraft.util.Formatting.RED), false);
        }
        super.onDeath(source);
    }

    @Override
    protected ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (hand != Hand.MAIN_HAND || !isAlive()) return ActionResult.PASS;
        if (!getWorld().isClient && player instanceof ServerPlayerEntity sp) {
            if (hostileTo(player) && getTarget() == player) return ActionResult.FAIL;
            Survivors.openTalk(sp, this);
        }
        return ActionResult.success(getWorld().isClient);
    }

    // =====================================================================================
    //                                       торговля
    // =====================================================================================
    @Override
    protected void afterUsing(TradeOffer offer) {
        trust = Math.min(100, trust + 2);
    }

    @Override
    protected void fillRecipes() {
        Survivors.fillTrades(this, getOffers());
    }

    @Override
    public boolean isLeveledMerchant() {
        return false;
    }

    @Override
    public @Nullable PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    protected @Nullable SoundEvent getAmbientSound() {
        return null;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_PLAYER_DEATH;
    }

    @Override
    public SoundEvent getYesSound() {
        return SoundEvents.ENTITY_ITEM_PICKUP;
    }

    @Override
    protected SoundEvent getTradingSound(boolean sold) {
        return SoundEvents.ENTITY_ITEM_PICKUP;
    }

    // =====================================================================================
    //                                       сохранение
    // =====================================================================================
    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("PzSkin", skin());
        nbt.putInt("PzRole", role());
        if (owner != null) nbt.putUuid("PzOwner", owner);
        if (grudge != null) nbt.putUuid("PzGrudge", grudge);
        nbt.putInt("PzMode", mode);
        if (guardPos != null) nbt.putLong("PzGuard", guardPos.asLong());
        nbt.putInt("PzTrust", trust);
        nbt.putBoolean("PzRescue", rescue);
        nbt.putFloat("PzFood", food);
        nbt.putLong("PzInfected", infectedAt);
        nbt.putLong("PzBorn", bornAt);
        nbt.putLong("PzCalm", calmUntil);
        nbt.putInt("PzAmmo", ammo);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        setSkin(nbt.getInt("PzSkin"));
        setRole(nbt.getInt("PzRole"));
        owner = nbt.containsUuid("PzOwner") ? nbt.getUuid("PzOwner") : null;
        grudge = nbt.containsUuid("PzGrudge") ? nbt.getUuid("PzGrudge") : null;
        mode = nbt.getInt("PzMode");
        guardPos = nbt.contains("PzGuard") ? BlockPos.fromLong(nbt.getLong("PzGuard")) : null;
        trust = nbt.getInt("PzTrust");
        rescue = nbt.getBoolean("PzRescue");
        food = nbt.contains("PzFood") ? nbt.getFloat("PzFood") : 80f;
        infectedAt = nbt.contains("PzInfected") ? nbt.getLong("PzInfected") : -1;
        bornAt = nbt.contains("PzBorn") ? nbt.getLong("PzBorn") : -1;
        calmUntil = nbt.getLong("PzCalm");
        ammo = nbt.getInt("PzAmmo");
    }

    // =====================================================================================
    //                                       цели ИИ
    // =====================================================================================

    /** Стрельба: стоит, целится и стреляет, пока есть патроны. */
    final class ShootGoal extends Goal {
        ShootGoal() {
            setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
        }

        @Override
        public boolean canStart() {
            LivingEntity t = getTarget();
            return t != null && t.isAlive() && hasGun() && distanceTo(t) < NpcGuns.range(getMainHandStack().getItem());
        }

        @Override
        public boolean shouldContinue() {
            return canStart();
        }

        @Override
        public boolean shouldRunEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity t = getTarget();
            if (t == null) return;
            getLookControl().lookAt(t, 30f, 30f);
            boolean see = canSee(t);
            if (!see) {
                getNavigation().startMovingTo(t, 1.0);
                return;
            }
            if (distanceTo(t) < 4 && t instanceof PzZombieEntity) {     // мертвец вплотную — отступить
                var away = net.minecraft.entity.ai.NoPenaltyTargeting.findFrom(SurvivorEntity.this, 8, 4, t.getPos());
                if (away != null) getNavigation().startMovingTo(away.x, away.y, away.z, 1.2);
            } else getNavigation().stop();
            if (shotCd <= 0 && getWorld() instanceof ServerWorld w) {
                shotCd = NpcGuns.cooldown(getMainHandStack().getItem()) + random.nextInt(10);
                ammo--;
                swingHand(Hand.MAIN_HAND);
                NpcGuns.fire(w, SurvivorEntity.this, t, getMainHandStack().getItem(), isBandit() ? 0.45f : 0.6f);
                if (ammo <= 0) say(Survivors.line("no_ammo", random), 16);
            }
        }
    }

    /** Напарник идёт за хозяином; отстал слишком сильно — догоняет бегом. */
    final class FollowOwnerGoal extends Goal {
        FollowOwnerGoal() {
            setControls(EnumSet.of(Goal.Control.MOVE));
        }

        @Override
        public boolean canStart() {
            PlayerEntity o = ownerPlayer();
            return isFollower() && mode == FOLLOW && o != null && getTarget() == null && squaredDistanceTo(o) > 25;
        }

        @Override
        public boolean shouldContinue() {
            PlayerEntity o = ownerPlayer();
            return isFollower() && mode == FOLLOW && o != null && getTarget() == null && squaredDistanceTo(o) > 9;
        }

        @Override
        public void tick() {
            PlayerEntity o = ownerPlayer();
            if (o == null || age % 10 != 0) return;
            double d2 = squaredDistanceTo(o);
            if (d2 > 48 * 48 && !canSee(o)) {                        // потерялся — догнал
                BlockPos p = o.getBlockPos();
                requestTeleport(p.getX() + 0.5, p.getY(), p.getZ() + 0.5);
                getNavigation().stop();
                return;
            }
            getNavigation().startMovingTo(o, d2 > 144 ? 1.35 : 1.0);
        }

        @Override
        public void stop() {
            getNavigation().stop();
        }
    }

    /** «Жди» и «охраняй»: держится у своей точки. */
    final class GuardGoal extends Goal {
        GuardGoal() {
            setControls(EnumSet.of(Goal.Control.MOVE));
        }

        @Override
        public boolean canStart() {
            return isFollower() && mode != FOLLOW && guardPos != null && getTarget() == null
                    && squaredDistanceTo(guardPos.getX() + 0.5, guardPos.getY(), guardPos.getZ() + 0.5) > (mode == WAIT ? 4 : 100);
        }

        @Override
        public boolean shouldContinue() {
            return canStart() && !getNavigation().isIdle();
        }

        @Override
        public void start() {
            getNavigation().startMovingTo(guardPos.getX() + 0.5, guardPos.getY(), guardPos.getZ() + 0.5, 1.0);
        }
    }
}
