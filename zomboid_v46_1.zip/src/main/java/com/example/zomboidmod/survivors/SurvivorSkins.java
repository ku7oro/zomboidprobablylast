package com.example.zomboidmod.survivors;

/** Скины выживших (сгенерировано gen_survivors.py). */
public final class SurvivorSkins {
    public static final int COUNT = 24;
    public static final boolean[] MALE = {true, false, true, true, false, true, false, false, true, true, false, false, true, true, true, true, true, true, false, false, true, false, true, false};
    public static final int[] NEUTRAL = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
    public static final int[] BANDIT = {12, 13, 14, 15, 16, 17, 18};
    public static final int[] TRADER = {19, 20, 21, 22, 23};

    private SurvivorSkins() {
    }
}
