package com.example.zomboidmod.survivors;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public final class SurvivorClient {
    private SurvivorClient() {
    }

    public static void init() {
        EntityRendererRegistry.register(Survivors.SURVIVOR, SurvivorRenderer::new);
        ClientPlayNetworking.registerGlobalReceiver(Survivors.TalkPayload.ID, (pl, ctx) -> {
            if (ctx.client().currentScreen instanceof SurvivorScreen s && s.entity == pl.entity()) s.update(pl.info());
            else ctx.client().setScreen(new SurvivorScreen(pl.entity(), pl.info()));
        });
    }
}
