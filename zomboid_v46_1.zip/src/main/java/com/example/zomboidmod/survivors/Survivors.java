package com.example.zomboidmod.survivors;

import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.ZomboidEntities;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.gun.Guns;
import com.example.zomboidmod.gun.NpcGuns;
import com.example.zomboidmod.survivors.SurvivorEntity;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.item.SwordItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradeOfferList;
import net.minecraft.village.TradedItem;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Выжившие: кто бродит по округу, как с ними говорить, вербовать, торговать и откупаться от бандитов.
 * Группы появляются в стороне от игрока; бандитов со временем становится больше — общество распадается.
 */
public final class Survivors {
    public static EntityType<SurvivorEntity> SURVIVOR;
    public static Item SURVIVOR_SPAWN_EGG;
    private static final int MAX_FOLLOWERS = 3;

    public static final int A_TALK = 0, A_RECRUIT = 1, A_GIVE = 2, A_TRADE = 3, A_FOLLOW = 4, A_WAIT = 5, A_GUARD = 6,
            A_WEAPON = 7, A_DISMISS = 8, A_PAY = 9, A_AMMO = 10;

    private Survivors() {
    }

    // =====================================================================================
    //                                       пакеты
    // =====================================================================================

    /** Сервер -> клиент: открыть/обновить разговор. */
    public record TalkPayload(int entity, NbtCompound info) implements CustomPayload {
        public static final Id<TalkPayload> ID = new Id<>(Identifier.of(ZomboidMod.MOD_ID, "survivor_talk"));
        public static final PacketCodec<RegistryByteBuf, TalkPayload> CODEC =
                PacketCodec.tuple(PacketCodecs.VAR_INT, TalkPayload::entity, PacketCodecs.NBT_COMPOUND, TalkPayload::info, TalkPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Клиент -> сервер: кнопка в разговоре. */
    public record ActionPayload(int entity, int action) implements CustomPayload {
        public static final Id<ActionPayload> ID = new Id<>(Identifier.of(ZomboidMod.MOD_ID, "survivor_action"));
        public static final PacketCodec<RegistryByteBuf, ActionPayload> CODEC =
                PacketCodec.tuple(PacketCodecs.VAR_INT, ActionPayload::entity, PacketCodecs.VAR_INT, ActionPayload::action, ActionPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    // =====================================================================================
    //                                       имена и реплики
    // =====================================================================================
    private static final String[] MALE = {"Джон", "Майк", "Дэйв", "Билл", "Том", "Рэй", "Пол", "Стив", "Гэри", "Фрэнк", "Джо", "Эрл", "Кит",
            "Дуг", "Бобби", "Уэйн", "Карл", "Ллойд", "Тони", "Расти"};
    private static final String[] FEMALE = {"Сара", "Линда", "Кэрол", "Джен", "Эми", "Донна", "Лиза", "Мэри", "Бет", "Тина", "Кэти", "Рут",
            "Джуди", "Нэнси", "Пэм", "Шерил"};
    private static final String[] LAST = {"Миллер", "Харрис", "Коллинз", "Бейкер", "Тёрнер", "Паркер", "Хьюз", "Росс", "Грант", "Лоусон",
            "Уэллс", "Карвер", "Дэниелс", "Маккой", "Шоу", "Рид", "Флинн", "Барнс", "Кроуфорд", "Додсон", "Пратт", "Хейл"};
    private static final String[] NICK = {"Шрам", "Бешеный", "Кривой", "Хорёк", "Гвоздь", "Барсук", "Шакал", "Седой", "Кабан", "Лис", "Штырь", "Ржавый"};

    private static final Map<String, String[]> LINES = new HashMap<>();

    static {
        L("greet", "Тише ты. Их тут полно.", "Живой? Я уж думал, одна я осталась на всю округу.", "Не подходи так быстро... Ладно, вижу, не кусаешься.",
                "Еды у меня нет, если ты за этим.", "Ты слышал вертолёт пару дней назад? Он не вернулся.", "Держись подальше от больших улиц. Там их стада.",
                "Радио ещё что-то говорит. Только толку от этого...", "Я видел, как мой сосед встал после смерти. С тех пор не сплю.");
        L("trader_greet", "Меняю вещи. Денег больше нет — есть только то, что можно съесть или чем стрелять.",
                "Смотри, что есть. Торгуюсь честно, но в долг не даю.", "Мне нужна еда и патроны. Остальное обсуждаемо.");
        L("bandit_warn", "Стоять! Ещё шаг — и стреляю!", "Эй! Это наша улица. Разворачивайся.", "Руки, чтобы я видел! И проваливай!",
                "Не дёргайся. Выкладывай, что есть, или уходи.", "Ты не туда забрёл, приятель.");
        L("bandit_talk", "Хочешь пройти — плати. Еда, патроны, ствол. Выбирай.", "Время идёт. Платишь или уходишь?",
                "Нас больше. Подумай хорошенько.");
        L("paid", "Умный. Иди, пока мы добрые.", "Вот так бы сразу. Проходи.", "Сегодня живи.");
        L("not_enough", "Это что, подачка? Ты издеваешься?", "Мало. Сам напросился.");
        L("grudge", "Ты на меня руку поднял. Не подходи.", "Отвали! Я тебе больше не верю.");
        L("recruit_ok", "Ладно. Вдвоём больше шансов. Я с тобой.", "Хорошо. Только не бросай меня, как остальные.", "Идёт. Веди.");
        L("recruit_no", "Я тебя не знаю. С чего бы мне тебе верить?", "Нет. Одной... одному спокойнее.", "Может, потом. Докажи, что тебе можно доверять.");
        L("too_many", "У тебя и так целый отряд. Я лишний.");
        L("thanks", "Спасибо. Правда спасибо.", "Давно не ел нормально.", "Я этого не забуду.");
        L("follow", "Иду за тобой.", "Понял.", "Держусь рядом.");
        L("wait", "Жду тут.", "Хорошо, никуда не уйду.");
        L("guard", "Буду сторожить это место.", "Если полезут — встречу.");
        L("dismiss", "Ну... удачи тебе.", "Ясно. Каждый сам за себя.");
        L("hungry", "Я есть хочу. Совсем.", "У тебя есть что-нибудь пожевать?", "Живот сводит от голода.");
        L("leave_hungry", "Я ухожу. С тобой я просто умру с голоду.");
        L("sick", "Мне что-то нехорошо... Жар.", "Голова раскалывается. Это ведь не укус, правда?", "Если я... обращусь — не жалей меня.");
        L("combat", "Сзади!", "Ещё один!", "Держи слева!", "Бей в голову!", "Получай, тварь!");
        L("flee", "Их слишком много! Бежим!", "Уходим, уходим!", "Я так долго не продержусь!");
        L("no_ammo", "Патроны кончились!", "Пусто! Мне нужны патроны!");
        L("attacked", "Ты что творишь?!", "Псих! Не подходи ко мне!");
        L("betrayed", "Всё. Я ухожу. И не попадайся мне.");
        L("ouch_owner", "Эй! Смотри, куда бьёшь!", "Ты по своим-то не маши!");
        L("weapon", "С этим будет полегче.", "Хорошая вещь. Спасибо.");
        L("ammo", "Теперь есть чем отстреливаться.");
        L("healed", "Так-то лучше.", "Спасибо, перевязка была кстати.");
        L("help", "Помогите!", "Кто-нибудь! Помогите!", "Их слишком много! Сюда!", "Я не продержусь! Помогите!");
        L("rescued", "Ты... ты меня спас. Держи, это тебе.", "Думал, конец мне. Спасибо! Возьми, пригодится.",
                "Вовремя ты. Вот, бери — заслужил.");
        L("feud_bandit", "Гляди-ка, добыча! Валим их!", "Отдавайте всё — и, может, уйдёте!");
        L("feud_neutral", "Бандиты! К оружию!", "Опять эти... Отбиваемся!");
    }

    private static void L(String key, String... lines) {
        LINES.put(key, lines);
    }

    public static String line(String key, Random r) {
        String[] a = LINES.get(key);
        return a == null || a.length == 0 ? null : a[r.nextInt(a.length)];
    }

    static void name(SurvivorEntity e, Random r) {
        boolean male = SurvivorSkins.MALE[Math.floorMod(e.skin(), SurvivorSkins.COUNT)];
        String first = male ? MALE[r.nextInt(MALE.length)] : FEMALE[r.nextInt(FEMALE.length)];
        String n = e.isBandit() ? NICK[r.nextInt(NICK.length)] + " " + first : first + " " + LAST[r.nextInt(LAST.length)];
        e.setCustomName(Text.literal(n));
    }

    private static Formatting color(SurvivorEntity e) {
        if (e.isFollower()) return Formatting.GREEN;
        if (e.isBandit()) return Formatting.RED;
        if (e.role() == SurvivorEntity.TRADER) return Formatting.GOLD;
        return Formatting.YELLOW;
    }

    static void speak(ServerWorld w, SurvivorEntity e, String text, int radius) {
        MutableText msg = Text.literal(e.getName().getString()).formatted(color(e)).append(Text.literal(": " + text).formatted(Formatting.WHITE));
        for (ServerPlayerEntity p : w.getPlayers())
            if (p.squaredDistanceTo(e) < radius * radius) p.sendMessage(msg, false);
    }

    // =====================================================================================
    //                                       снаряжение
    // =====================================================================================
    private static Item pick(Random r, Supplier<?>... items) {
        Object o = items[r.nextInt(items.length)].get();
        return o instanceof Item i ? i : Items.AIR;
    }

    /** Новый выживший: роль, внешность, имя, оружие. */
    public static void init(SurvivorEntity e, int role, Random r) {
        e.setRole(role);
        int[] pool = role == SurvivorEntity.BANDIT ? SurvivorSkins.BANDIT : role == SurvivorEntity.TRADER ? SurvivorSkins.TRADER : SurvivorSkins.NEUTRAL;
        e.setSkin(pool[r.nextInt(pool.length)]);
        name(e, r);
        Item weapon = Items.AIR;
        float k = r.nextFloat();
        if (role == SurvivorEntity.BANDIT) {
            if (k < 0.45f) weapon = pick(r, () -> Guns.PISTOL, () -> Guns.REVOLVER, () -> Guns.SHOTGUN, () -> Guns.SAWED_OFF, () -> Guns.HUNTING_RIFLE);
            else weapon = pick(r, () -> ZomboidMod.SPIKED_BAT, () -> ZomboidMod.MACHETE, () -> ZomboidMod.FIRE_AXE, () -> ZomboidMod.CROWBAR,
                    () -> ZomboidMod.BASEBALL_BAT, () -> ZomboidMod.BARBED_BAT, () -> ZomboidMod.CLUB_HAMMER);
            e.trust = 0;
        } else if (role == SurvivorEntity.TRADER) {
            weapon = k < 0.5f ? Guns.SHOTGUN : ZomboidMod.MACHETE;
            e.trust = 30;
            e.setPersistent();
        } else {
            if (k < 0.12f) weapon = pick(r, () -> Guns.PISTOL, () -> Guns.REVOLVER);
            else if (k < 0.7f) weapon = pick(r, () -> ZomboidMod.BASEBALL_BAT, () -> ZomboidMod.CROWBAR, () -> ZomboidMod.KITCHEN_KNIFE,
                    () -> ZomboidMod.HAMMER, () -> ZomboidMod.FRYING_PAN, () -> ZomboidMod.HAND_AXE, () -> ZomboidMod.METAL_PIPE,
                    () -> ZomboidMod.GOLF_CLUB, () -> ZomboidMod.PIPE_WRENCH, () -> ZomboidMod.HOCKEY_STICK, () -> ZomboidMod.TABLE_LEG);
            e.trust = 10 + r.nextInt(25);
        }
        if (weapon != null && weapon != Items.AIR) e.equipStack(EquipmentSlot.MAINHAND, new ItemStack(weapon));
        if (NpcGuns.isGun(weapon)) e.ammo = 8 + r.nextInt(role == SurvivorEntity.BANDIT ? 24 : 14);
        e.food = 50f + r.nextFloat() * 40f;
    }

    // =====================================================================================
    //                                       регистрация
    // =====================================================================================
    public static void register() {
        SURVIVOR = Registry.register(Registries.ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, "survivor"),
                EntityType.Builder.create(SurvivorEntity::new, SpawnGroup.MISC).dimensions(0.6f, 1.8f).maxTrackingRange(10).build("survivor"));
        FabricDefaultAttributeRegistry.register(SURVIVOR, SurvivorEntity.attributes());
        SURVIVOR_SPAWN_EGG = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, "survivor_spawn_egg"),
                new SpawnEggItem(SURVIVOR, 0x6A5A44, 0x3E5A76, new Item.Settings()));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(e -> e.add(SURVIVOR_SPAWN_EGG));
        PayloadTypeRegistry.playS2C().register(TalkPayload.ID, TalkPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (pl, ctx) -> ctx.server().execute(() -> {
            if (ctx.player().getWorld().getEntityById(pl.entity()) instanceof SurvivorEntity e && e.isAlive() && ctx.player().squaredDistanceTo(e) < 64)
                act(ctx.player(), e, pl.action());
        }));
        ServerTickEvents.END_SERVER_TICK.register(Survivors::tick);
    }

    // =====================================================================================
    //                                       разговор
    // =====================================================================================
    public static void openTalk(ServerPlayerEntity p, SurvivorEntity e) {
        String line;
        if (e.grudge != null && e.grudge.equals(p.getUuid())) line = line("grudge", e.getRandom());
        else if (e.isBandit()) line = e.getWorld().getTime() < e.calmUntil ? line("paid", e.getRandom()) : line("bandit_talk", e.getRandom());
        else if (e.isFollower()) line = e.food < 25 ? line("hungry", e.getRandom()) : (e.infectedAt >= 0 ? line("sick", e.getRandom()) : line("follow", e.getRandom()));
        else if (e.role() == SurvivorEntity.TRADER) line = line("trader_greet", e.getRandom());
        else line = line("greet", e.getRandom());
        send(p, e, line);
    }

    private static void send(ServerPlayerEntity p, SurvivorEntity e, String line) {
        NbtCompound n = new NbtCompound();
        n.putString("name", e.getName().getString());
        n.putInt("role", e.role());
        n.putBoolean("follower", e.isFollower());
        n.putBoolean("mine", e.owner != null && e.owner.equals(p.getUuid()));
        n.putBoolean("grudge", e.grudge != null && e.grudge.equals(p.getUuid()));
        n.putBoolean("calm", e.getWorld().getTime() < e.calmUntil);
        n.putInt("mode", e.mode);
        n.putInt("trust", e.trust);
        n.putFloat("food", e.food);
        n.putFloat("hp", e.getHealth());
        n.putFloat("maxHp", e.getMaxHealth());
        n.putBoolean("sick", e.infectedAt >= 0 && e.getWorld().getTime() - e.infectedAt > 12000);
        n.putInt("ammo", e.ammo);
        n.putBoolean("gun", NpcGuns.isGun(e.getMainHandStack().getItem()));
        n.putString("weapon", e.getMainHandStack().isEmpty() ? "без оружия" : e.getMainHandStack().getName().getString());
        n.putString("line", line == null ? "" : line);
        ServerPlayNetworking.send(p, new TalkPayload(e.getId(), n));
    }

    private static int followers(ServerPlayerEntity p) {
        int n = 0;
        for (SurvivorEntity s : p.getServerWorld().getEntitiesByClass(SurvivorEntity.class, p.getBoundingBox().expand(256), x -> x.isAlive()))
            if (s.owner != null && s.owner.equals(p.getUuid())) n++;
        return n;
    }

    private static boolean isWeapon(ItemStack s) {
        Item i = s.getItem();
        return i instanceof com.example.zomboidmod.PzWeaponItem || i instanceof AxeItem || i instanceof SwordItem || NpcGuns.isGun(i);
    }

    static void act(ServerPlayerEntity p, SurvivorEntity e, int action) {
        Random r = e.getRandom();
        ItemStack hand = p.getMainHandStack();
        boolean mine = e.owner != null && e.owner.equals(p.getUuid());
        boolean grudge = e.grudge != null && e.grudge.equals(p.getUuid());
        String reply = null;
        switch (action) {
            case A_TALK -> {
                if (grudge) reply = line("grudge", r);
                else {
                    String rumor = r.nextFloat() < 0.7f ? com.example.zomboidmod.world.Knox.rumor(p.getServerWorld().getSeed(), e.getBlockX(), e.getBlockZ(),
                            new java.util.Random(r.nextLong())) : null;
                    reply = rumor != null ? rumor : line("greet", r);
                    if (!e.isBandit()) e.trust = Math.min(100, e.trust + 2);
                }
            }
            case A_RECRUIT -> {
                if (e.isBandit() || e.role() == SurvivorEntity.TRADER || e.isFollower() || grudge) break;
                if (followers(p) >= MAX_FOLLOWERS) reply = line("too_many", r);
                else if (e.trust >= 60 || r.nextInt(100) < e.trust) {
                    e.owner = p.getUuid();
                    e.mode = SurvivorEntity.FOLLOW;
                    e.setPersistent();
                    e.setTarget(null);
                    reply = line("recruit_ok", r);
                    p.getServerWorld().playSound(null, e.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.NEUTRAL, 0.4f, 1.4f);
                } else {
                    e.trust = Math.max(0, e.trust - 5);
                    reply = line("recruit_no", r);
                }
            }
            case A_GIVE -> {
                FoodComponent f = hand.get(DataComponentTypes.FOOD);
                if (hand.isOf(ZomboidMod.BANDAGE) || hand.isOf(ZomboidMod.SUTURE_KIT)) {
                    e.heal(hand.isOf(ZomboidMod.BANDAGE) ? 6f : 10f);
                    e.trust = Math.min(100, e.trust + 10);
                    hand.decrementUnlessCreative(1, p);
                    reply = line("healed", r);
                } else if (f != null && !grudge) {
                    int nut = Math.max(1, f.nutrition());
                    if (e.isFollower()) e.food = Math.min(100f, e.food + nut * 9f);
                    e.trust = Math.min(100, e.trust + nut * 3);
                    hand.decrementUnlessCreative(1, p);
                    reply = line("thanks", r);
                } else reply = "Возьмите в руку еду или бинт.";
            }
            case A_TRADE -> {
                if (e.role() == SurvivorEntity.TRADER && !grudge) {
                    e.setCustomer(p);
                    e.sendOffers(p, e.getDisplayName(), 1);
                    return;
                }
            }
            case A_FOLLOW, A_WAIT, A_GUARD -> {
                if (!mine) break;
                e.mode = action == A_FOLLOW ? SurvivorEntity.FOLLOW : action == A_WAIT ? SurvivorEntity.WAIT : SurvivorEntity.GUARD;
                e.guardPos = e.mode == SurvivorEntity.FOLLOW ? null : e.getBlockPos();
                e.getNavigation().stop();
                reply = line(action == A_FOLLOW ? "follow" : action == A_WAIT ? "wait" : "guard", r);
            }
            case A_WEAPON -> {
                if (!mine) break;
                if (!isWeapon(hand)) {
                    reply = "Возьмите в руку оружие, чтобы отдать.";
                    break;
                }
                ItemStack old = e.getMainHandStack().copy();
                e.equipStack(EquipmentSlot.MAINHAND, hand.copyWithCount(1));
                hand.decrement(1);
                if (!old.isEmpty()) p.getInventory().offerOrDrop(old);
                if (!NpcGuns.isGun(e.getMainHandStack().getItem())) e.ammo = 0;
                reply = line("weapon", r);
            }
            case A_AMMO -> {
                if (!mine) break;
                Item need = NpcGuns.ammoFor(e.getMainHandStack().getItem());
                if (need == null) {
                    reply = "У меня нет ствола.";
                    break;
                }
                int took = 0;
                for (int i = 0; i < p.getInventory().size() && took < 40; i++) {
                    ItemStack s = p.getInventory().getStack(i);
                    if (!s.isOf(need)) continue;
                    int n = Math.min(s.getCount(), 40 - took);
                    s.decrement(n);
                    took += n;
                }
                e.ammo += took;
                reply = took > 0 ? line("ammo", r) : "У тебя нет подходящих патронов.";
            }
            case A_DISMISS -> {
                if (!mine) break;
                e.dismiss();
                reply = line("dismiss", r);
            }
            case A_PAY -> {
                if (!e.isBandit()) break;
                Item i = hand.getItem();
                boolean food = hand.get(DataComponentTypes.FOOD) != null;
                boolean ok = !hand.isEmpty() && ((food && hand.getCount() >= 2) || NpcGuns.isGun(i) || hand.getCount() >= 4 || isWeapon(hand));
                if (ok) {
                    hand.setCount(0);
                    long until = e.getWorld().getTime() + 3000;
                    for (SurvivorEntity b : p.getServerWorld().getEntitiesByClass(SurvivorEntity.class, e.getBoundingBox().expand(20), SurvivorEntity::isBandit)) {
                        b.calmUntil = until;
                        if (b.getTarget() == p) b.setTarget(null);
                    }
                    reply = line("paid", r);
                } else {
                    reply = line("not_enough", r);
                    e.grudge = p.getUuid();
                    e.setTarget(p);
                }
            }
            default -> {
            }
        }
        send(p, e, reply);
    }

    // =====================================================================================
    //                                       торговля
    // =====================================================================================
    private record Deal(Supplier<Item> give, int giveN, Supplier<Item> get, int getN) {
    }

    private static final List<Deal> DEALS = List.of(
            new Deal(() -> Items.COOKED_BEEF, 3, () -> ZomboidMod.BANDAGE, 2),
            new Deal(() -> com.example.zomboidmod.LootItems.CANNED_BEANS, 4, () -> Guns.AMMO_9MM, 12),
            new Deal(() -> com.example.zomboidmod.hunting.HuntingItems.HIDE_LARGE, 2, () -> Guns.SHOTGUN_SHELLS, 6),
            new Deal(() -> Items.LEATHER, 6, () -> ZomboidMod.ANTIBIOTICS, 1),
            new Deal(() -> Items.BREAD, 5, () -> com.example.zomboidmod.build.CarpentryItems.NAILS, 24),
            new Deal(() -> com.example.zomboidmod.survival.SurvivalItems.CIGARETTES, 4, () -> com.example.zomboidmod.LootItems.BOOK_FIRST_AID, 1),
            new Deal(() -> com.example.zomboidmod.LootItems.CHOCOLATE, 3, () -> com.example.zomboidmod.survival.SurvivalItems.BATTERY, 2),
            new Deal(() -> com.example.zomboidmod.LootItems.CANNED_TUNA, 6, () -> ZomboidMod.HUNTING_KNIFE, 1),
            new Deal(() -> com.example.zomboidmod.survival.SurvivalItems.BEER, 3, () -> ZomboidMod.PAINKILLERS, 1),
            new Deal(() -> com.example.zomboidmod.hunting.HuntingItems.COOKED_FISH_FILLET, 3, () -> Items.WHEAT_SEEDS, 10),
            new Deal(() -> com.example.zomboidmod.hunting.HuntingItems.COOKED_FISH_FILLET, 3, () -> Items.CARROT, 4),
            new Deal(() -> Guns.AMMO_9MM, 10, () -> com.example.zomboidmod.LootItems.CANNED_SOUP, 3),
            new Deal(() -> Guns.SHOTGUN_SHELLS, 4, () -> com.example.zomboidmod.LootItems.CANNED_BEANS, 3),
            new Deal(() -> com.example.zomboidmod.hunting.HuntingItems.HIDE_SMALL, 4, () -> ZomboidMod.RAG, 6),
            new Deal(() -> Items.IRON_INGOT, 3, () -> com.example.zomboidmod.LootItems.BOOK_TRAPPING, 1),
            new Deal(() -> com.example.zomboidmod.hunting.HuntingItems.ANIMAL_FAT, 4, () -> com.example.zomboidmod.survival.SurvivalItems.COFFEE, 1));

    static void fillTrades(SurvivorEntity e, TradeOfferList list) {
        java.util.Random r = new java.util.Random(e.getUuid().getMostSignificantBits());
        List<Deal> pool = new ArrayList<>(DEALS);
        java.util.Collections.shuffle(pool, r);
        for (int i = 0; i < 7 && i < pool.size(); i++) {
            Deal d = pool.get(i);
            Item give = d.give.get(), get = d.get.get();
            if (give == null || get == null) continue;
            list.add(new TradeOffer(new TradedItem(give, d.giveN), new ItemStack(get, d.getN), 4 + r.nextInt(5), 1, 0.05f));
        }
    }

    // =====================================================================================
    //                                       появление, смерть, обращение
    // =====================================================================================
    private record Pending(ServerWorld w, double x, double y, double z, float yaw, String name, long at) {
    }

    private static final List<Pending> PENDING = new ArrayList<>();

    static void reanimateLater(ServerWorld w, SurvivorEntity e) {
        PENDING.add(new Pending(w, e.getX(), e.getY(), e.getZ(), e.getYaw(), e.getName().getString(), w.getTime() + 300 + w.random.nextInt(300)));
    }

    static void reanimate(ServerWorld w, SurvivorEntity e) {
        spawnZombie(w, e.getX(), e.getY(), e.getZ(), e.getYaw(), e.getName().getString());
    }

    private static void spawnZombie(ServerWorld w, double x, double y, double z, float yaw, String name) {
        PzZombieEntity zb = ZomboidEntities.PZ_ZOMBIE.create(w);
        if (zb == null) return;
        zb.refreshPositionAndAngles(x, y, z, yaw, 0f);
        zb.setup(null);
        zb.setCustomName(Text.literal(name).formatted(Formatting.DARK_GRAY));
        w.spawnEntity(zb);
        w.playSound(null, zb.getBlockPos(), SoundEvents.ENTITY_ZOMBIE_INFECT, SoundCategory.HOSTILE, 1.2f, 0.8f);
        for (ServerPlayerEntity p : w.getPlayers())
            if (p.squaredDistanceTo(x, y, z) < 40 * 40) p.sendMessage(Text.literal(name + " обратился(лась)...").formatted(Formatting.DARK_RED), false);
    }

    static void dropLoot(ServerWorld w, SurvivorEntity e) {
        Random r = e.getRandom();
        Item ammo = NpcGuns.ammoFor(e.getMainHandStack().getItem());
        if (ammo != null && e.ammo > 1) e.dropStack(new ItemStack(ammo, Math.min(64, e.ammo / 2 + 1)));
        Supplier<?>[] loot = {() -> com.example.zomboidmod.LootItems.CANNED_BEANS, () -> ZomboidMod.BANDAGE, () -> com.example.zomboidmod.LootItems.CHOCOLATE,
                () -> com.example.zomboidmod.survival.SurvivalItems.CIGARETTES, () -> com.example.zomboidmod.LootItems.WATER_BOTTLE, () -> ZomboidMod.RAG,
                () -> com.example.zomboidmod.LootItems.CHIPS};
        int n = 1 + r.nextInt(e.isBandit() ? 4 : 3);
        for (int i = 0; i < n; i++) {
            Item it = pick(r, loot);
            if (it != Items.AIR) e.dropStack(new ItemStack(it));
        }
    }

    private static boolean groundOk(BlockState s) {
        if (s.isOf(Blocks.GRASS_BLOCK) || s.isOf(Blocks.DIRT) || s.isOf(Blocks.COARSE_DIRT) || s.isOf(Blocks.SAND) || s.isOf(Blocks.GRAVEL)
                || s.isOf(Blocks.PODZOL) || s.isOf(Blocks.DIRT_PATH) || s.isOf(Blocks.SNOW_BLOCK)) return true;
        String id = Registries.BLOCK.getId(s.getBlock()).getPath();
        return id.startsWith("asphalt") || id.startsWith("sidewalk") || id.startsWith("road_line");
    }

    private static void tick(MinecraftServer server) {
        if (!PENDING.isEmpty()) {
            Iterator<Pending> it = PENDING.iterator();
            while (it.hasNext()) {
                Pending p = it.next();
                if (p.w.getTime() < p.at) continue;
                it.remove();
                spawnZombie(p.w, p.x, p.y, p.z, p.yaw, p.name);
            }
        }
        if (server.getTicks() % 600 != 300) return;
        ServerWorld w = server.getOverworld();
        Random r = w.random;
        int day = com.example.zomboidmod.survival.Clock.day(w);
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (p.isSpectator() || r.nextFloat() > 0.12f * com.example.zomboidmod.sandbox.Sandbox.survivorsMult()) continue;   // песочница: выжившие
            if (w.getEntitiesByClass(SurvivorEntity.class, p.getBoundingBox().expand(128), x -> x.isAlive() && !x.isFollower()).size() >= 4) continue;
            double ang = r.nextDouble() * Math.PI * 2, dist = 40 + r.nextInt(32);
            int x = (int) (p.getX() + Math.cos(ang) * dist), z = (int) (p.getZ() + Math.sin(ang) * dist);
            if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
            if (com.example.zomboidmod.nature.Climate.state(w).bases.contains(ChunkPos.toLong(x >> 4, z >> 4))) continue;
            BlockPos top = w.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
            if (!groundOk(w.getBlockState(top.down())) || !w.getFluidState(top).isEmpty()) continue;
            float bandit = Math.min(0.6f, Math.min(0.4f, 0.08f + 0.02f * day) * com.example.zomboidmod.sandbox.Sandbox.banditMult()), k = r.nextFloat();   // песочница: бандиты
            int role = k < bandit ? SurvivorEntity.BANDIT : k < bandit + 0.12f ? SurvivorEntity.TRADER : SurvivorEntity.NEUTRAL;
            int n = role == SurvivorEntity.BANDIT ? 2 + r.nextInt(2) : role == SurvivorEntity.TRADER ? 1 : 1 + (r.nextFloat() < 0.4f ? 1 : 0) + (r.nextFloat() < 0.15f ? 1 : 0);
            for (int i = 0; i < n; i++) {
                SurvivorEntity e = SURVIVOR.create(w);
                if (e == null) continue;
                e.refreshPositionAndAngles(top.getX() + 0.5 + r.nextInt(5) - 2, top.getY(), top.getZ() + 0.5 + r.nextInt(5) - 2, r.nextFloat() * 360f, 0f);
                init(e, role, r);
                w.spawnEntity(e);
            }
        }
    }

    /** Место для встречи: загруженный чанк, твёрдая земля (или улица), не вода и не рядом с базой игрока. null — не годится. */
    public static BlockPos groundSpot(ServerWorld w, int x, int z) {
        if (!w.isChunkLoaded(x >> 4, z >> 4)) return null;
        if (com.example.zomboidmod.nature.Climate.state(w).bases.contains(ChunkPos.toLong(x >> 4, z >> 4))) return null;
        BlockPos top = w.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
        BlockState below = w.getBlockState(top.down());
        String id = net.minecraft.registry.Registries.BLOCK.getId(below.getBlock()).getPath();
        boolean street = id.contains("asphalt") || id.contains("sidewalk") || id.contains("road");
        if (!(groundOk(below) || street) || !w.getFluidState(top).isEmpty() || !w.shouldTickEntity(top)) return null;
        return top;
    }

    /** Выживший для события: обычный, бандит или «в беде» (зовёт на помощь, спасённый благодарит). */
    public static SurvivorEntity spawnAt(ServerWorld w, BlockPos top, int role, boolean rescue) {
        SurvivorEntity e = SURVIVOR.create(w);
        if (e == null) return null;
        Random r = w.getRandom();
        e.refreshPositionAndAngles(top.getX() + 0.5, top.getY(), top.getZ() + 0.5, r.nextFloat() * 360f, 0f);
        init(e, role, r);
        e.rescue = rescue;
        if (rescue) e.trust = Math.max(e.trust, 20);
        w.spawnEntity(e);
        return e;
    }

    /** Награда спасителю: что-то из запасов выжившего. */
    static void reward(ServerWorld w, SurvivorEntity e, ServerPlayerEntity p) {
        net.minecraft.inventory.SimpleInventory inv = new net.minecraft.inventory.SimpleInventory(9);
        com.example.zomboidmod.world.Loot.STASH.fillAlways(inv, e.getRandom());
        int given = 0;
        for (int i = 0; i < inv.size() && given < 2; i++) {
            ItemStack st = inv.getStack(i);
            if (st.isEmpty()) continue;
            if (!p.getInventory().insertStack(st.copy())) p.dropItem(st.copy(), false);
            given++;
        }
        if (given == 0 && !p.getInventory().insertStack(new ItemStack(ZomboidMod.BANDAGE, 2))) p.dropItem(new ItemStack(ZomboidMod.BANDAGE, 2), false);
    }

    static boolean worldOk(World w) {
        return w instanceof ServerWorld;
    }
}
