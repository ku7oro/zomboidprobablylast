package com.example.zomboidmod.voice;

import org.lwjgl.openal.AL10;
import org.lwjgl.openal.ALC10;
import org.lwjgl.openal.ALC11;
import org.lwjgl.openal.ALUtil;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;
import java.util.ArrayList;
import java.util.List;

/**
 * Доступ к микрофону. Сначала — через OpenAL (тот же звуковой движок, что у самой игры), если не вышло —
 * через звук Java. Отдаёт только сырые отсчёты для подсчёта громкости; ничего не хранит.
 */
final class Mic {
    private Mic() {
    }

    static final int RATE = 16000;

    interface Source {
        /** Сколько отсчётов прочитано (0 — пока нечего). */
        int read(short[] buf);

        void close();

        String name();
    }

    /** name — пустая строка или null: микрофон по умолчанию. */
    static Source open(String name) throws Exception {
        String dev = name == null || name.isEmpty() ? null : name;
        Throwable first;
        try {
            return new Al(dev);
        } catch (Throwable t) {
            first = t;
        }
        try {
            return new Jv(dev);
        } catch (Throwable t) {
            throw new Exception(String.valueOf(first.getMessage() != null ? first.getMessage() : t.getMessage()));
        }
    }

    /** Названия микрофонов, какие видит система. */
    static List<String> devices() {
        List<String> out = new ArrayList<>();
        try {
            List<String> al = ALUtil.getStringList(0L, ALC11.ALC_CAPTURE_DEVICE_SPECIFIER);
            if (al != null) out.addAll(al);
        } catch (Throwable ignored) {
        }
        if (!out.isEmpty()) return out;
        try {
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, Jv.format());
            for (Mixer.Info mi : AudioSystem.getMixerInfo()) {
                if (AudioSystem.getMixer(mi).isLineSupported(info)) out.add(mi.getName());
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    private static final class Al implements Source {
        private final long device;
        private final String name;

        Al(String dev) {
            String def = dev != null ? dev : ALC10.alcGetString(0L, ALC11.ALC_CAPTURE_DEFAULT_DEVICE_SPECIFIER);
            long d = ALC11.alcCaptureOpenDevice(dev, RATE, AL10.AL_FORMAT_MONO16, RATE);
            if (d == 0L) throw new IllegalStateException("микрофон не найден");
            device = d;
            name = def == null ? "микрофон по умолчанию" : def;
            ALC11.alcCaptureStart(device);
        }

        @Override
        public int read(short[] buf) {
            int n = Math.min(ALC10.alcGetInteger(device, ALC11.ALC_CAPTURE_SAMPLES), buf.length);
            if (n <= 0) return 0;
            ALC11.alcCaptureSamples(device, buf, n);
            return n;
        }

        @Override
        public void close() {
            try {
                ALC11.alcCaptureStop(device);
                ALC11.alcCaptureCloseDevice(device);
            } catch (Throwable ignored) {
            }
        }

        @Override
        public String name() {
            return name;
        }
    }

    private static final class Jv implements Source {
        private final TargetDataLine line;
        private final String name;
        private final byte[] bytes = new byte[RATE];

        static AudioFormat format() {
            return new AudioFormat(RATE, 16, 1, true, false);
        }

        Jv(String dev) throws Exception {
            AudioFormat f = format();
            TargetDataLine l = null;
            String n = "микрофон по умолчанию";
            if (dev != null) {
                DataLine.Info info = new DataLine.Info(TargetDataLine.class, f);
                for (Mixer.Info mi : AudioSystem.getMixerInfo()) {
                    if (!mi.getName().equals(dev)) continue;
                    Mixer m = AudioSystem.getMixer(mi);
                    if (m.isLineSupported(info)) {
                        l = (TargetDataLine) m.getLine(info);
                        n = mi.getName();
                    }
                }
            }
            if (l == null) l = AudioSystem.getTargetDataLine(f);
            l.open(f, RATE * 2);
            l.start();
            line = l;
            name = n;
        }

        @Override
        public int read(short[] buf) {
            int n = Math.min(Math.min(line.available(), bytes.length) / 2, buf.length);
            if (n <= 0) return 0;
            int got = line.read(bytes, 0, n * 2) / 2;
            for (int i = 0; i < got; i++) buf[i] = (short) ((bytes[i * 2] & 0xFF) | (bytes[i * 2 + 1] << 8));
            return got;
        }

        @Override
        public void close() {
            try {
                line.stop();
                line.close();
            } catch (Throwable ignored) {
            }
        }

        @Override
        public String name() {
            return name;
        }
    }
}
