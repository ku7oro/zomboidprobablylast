package com.example.zomboidmod.voice;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

/**
 * Микрофон на клиенте. По умолчанию выключен: включается клавишей (M) или командой /voice on.
 * Отдельный поток считает громкость (20 мс за раз), сравнивает её с тишиной в комнате и с обычной речью
 * и сообщает серверу одно число. Сам звук не сохраняется и не уходит с компьютера.
 * Команды: /voice, /voice on|off, /voice calibrate, /voice sens 0.3..3, /voice devices, /voice device N.
 */
public final class VoiceClient {
    private VoiceClient() {
    }

    private static final int FRAME = Mic.RATE / 50;          // 20 мс
    private static final float MAX = 2.4f;                   // правый край шкалы

    // настройки (сохраняются)
    private static boolean enabled, hinted;
    private static volatile float sens = 1f;
    private static volatile float quietDb = Float.NaN, speechDb = Float.NaN;   // после калибровки
    private static String device = "";
    private static Path file;
    private static KeyBinding key;

    // состояние потока
    private static volatile Thread worker;
    private static volatile boolean running, failed;
    private static volatile String status = "выключен";
    private static volatile float meter;                     // громкость для шкалы (в долях обычной речи)
    private static volatile int calib;                       // 0 — нет, 1 — тишина, 2 — речь
    private static final Object LOCK = new Object();
    private static float peak;
    private static int ticks, heard;
    private static float heardLevel;

    public static void init() {
        load();
        key = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.zomboidmod.voice", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, "category.zomboidmod"));
        HudRenderCallback.EVENT.register(VoiceClient::hud);
        ClientTickEvents.END_CLIENT_TICK.register(VoiceClient::tick);
        ClientPlayConnectionEvents.JOIN.register((h, s, c) -> c.execute(() -> {
            if (enabled || hinted) return;
            hinted = true;
            save();
            msg("Мертвецы могут слышать твой настоящий голос: крикнешь вслух — придут на звук, шёпот не услышат.", Formatting.GRAY);
            msg("Включить — клавиша M или /voice on. Звук не записывается и никуда не передаётся: мод считает только громкость.", Formatting.DARK_GRAY);
        }));
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> stop());
        ClientCommandRegistrationCallback.EVENT.register((d, access) -> d.register(ClientCommandManager.literal("voice")
                .executes(ctx -> {
                    info();
                    return 1;
                })
                .then(ClientCommandManager.literal("on").executes(ctx -> {
                    set(true);
                    return 1;
                }))
                .then(ClientCommandManager.literal("off").executes(ctx -> {
                    set(false);
                    return 1;
                }))
                .then(ClientCommandManager.literal("calibrate").executes(ctx -> {
                    calibrate();
                    return 1;
                }))
                .then(ClientCommandManager.literal("sens").then(ClientCommandManager.argument("value", FloatArgumentType.floatArg(0.3f, 3f)).executes(ctx -> {
                    sens = FloatArgumentType.getFloat(ctx, "value");
                    save();
                    msg("Чувствительность микрофона ×" + String.format("%.1f", sens) + " (больше — мертвецы слышат тише сказанное)", Formatting.GRAY);
                    return 1;
                })))
                .then(ClientCommandManager.literal("devices").executes(ctx -> {
                    devices();
                    return 1;
                }))
                .then(ClientCommandManager.literal("device").then(ClientCommandManager.argument("number", IntegerArgumentType.integer(0, 64)).executes(ctx -> {
                    pick(IntegerArgumentType.getInteger(ctx, "number"));
                    return 1;
                })))));
    }

    // ------------------------------------------------------------------ включение

    private static void set(boolean on) {
        enabled = on;
        save();
        if (!on) {
            stop();
            msg("Микрофон выключен: мертвецы тебя не слышат", Formatting.GRAY);
            return;
        }
        msg("Микрофон включён: мертвецы слышат твой голос. Шёпот — безопасно, разговор слышно рядом, крик — далеко.", Formatting.YELLOW);
        msg("Полоска слева внизу показывает громкость. Точнее настроить: /voice calibrate. В наушниках надёжнее — иначе слышны звуки самой игры.", Formatting.DARK_GRAY);
        start();
    }

    private static void start() {
        if (worker != null && worker.isAlive()) return;
        running = true;
        failed = false;
        status = "подключаюсь к микрофону";
        Thread t = new Thread(new Listener(device), "zomboid-mic");
        t.setDaemon(true);
        worker = t;
        t.start();
    }

    private static void stop() {
        running = false;
        calib = 0;
        Thread t = worker;
        worker = null;
        if (t != null) t.interrupt();
        meter = 0f;
        synchronized (LOCK) {
            peak = 0f;
        }
        if (!failed) status = "выключен";
    }

    private static void calibrate() {
        if (!enabled) {
            msg("Сначала включи микрофон: /voice on", Formatting.RED);
            return;
        }
        if (failed || worker == null) {
            msg("Микрофон недоступен: " + status, Formatting.RED);
            return;
        }
        calib = 1;
        msg("Настройка микрофона. Помолчи три секунды…", Formatting.YELLOW);
    }

    private static void info() {
        msg("Микрофон: " + (enabled ? "включён" : "выключен") + " — " + status, Formatting.GRAY);
        msg(Float.isNaN(speechDb) ? "Не настроен под твой голос: /voice calibrate" : String.format("Настроен: тишина %.0f дБ, речь %.0f дБ", quietDb, speechDb), Formatting.GRAY);
        msg("Команды: /voice on|off, /voice calibrate, /voice sens 0.3..3 (сейчас ×" + String.format("%.1f", sens) + "), /voice devices, /voice device N", Formatting.DARK_GRAY);
    }

    private static void devices() {
        List<String> list = Mic.devices();
        if (list.isEmpty()) {
            msg("Микрофонов не найдено", Formatting.RED);
            return;
        }
        msg("Микрофоны (выбрать: /voice device N):", Formatting.GRAY);
        msg("0 — по умолчанию" + (device.isEmpty() ? "  ◄" : ""), Formatting.GRAY);
        for (int i = 0; i < list.size(); i++) msg((i + 1) + " — " + list.get(i) + (list.get(i).equals(device) ? "  ◄" : ""), Formatting.GRAY);
    }

    private static void pick(int n) {
        List<String> list = Mic.devices();
        if (n > list.size()) {
            msg("Нет микрофона с номером " + n + ". Список: /voice devices", Formatting.RED);
            return;
        }
        device = n == 0 ? "" : list.get(n - 1);
        save();
        msg("Микрофон: " + (n == 0 ? "по умолчанию" : device), Formatting.GRAY);
        if (enabled) {
            stop();
            failed = false;
            start();
        }
    }

    // ------------------------------------------------------------------ каждый тик

    private static void tick(MinecraftClient c) {
        while (key.wasPressed()) set(!enabled);
        if (heard > 0) heard--;
        if (!enabled || c.world == null || c.player == null) return;
        if (worker == null && !failed) start();
        if (++ticks % 5 != 0) return;
        float p;
        synchronized (LOCK) {
            p = peak;
            peak = 0f;
        }
        if (p < Voice.WHISPER || calib != 0 || c.isPaused() || !c.player.isAlive() || c.player.isSpectator() || c.player.isCreative()) return;
        if (!ClientPlayNetworking.canSend(Voice.LoudPayload.ID)) return;
        ClientPlayNetworking.send(new Voice.LoudPayload(Math.round(Math.min(p, 3f) * 100f)));
        heard = 14;
        heardLevel = p;
    }

    // ------------------------------------------------------------------ шкала

    private static void hud(DrawContext ctx, RenderTickCounter counter) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (!enabled || c.options.hudHidden || c.player == null) return;
        int x = 6, y = ctx.getScaledWindowHeight() - 15;
        float t = meter;
        boolean loud = heard > 0;
        int col = failed ? 0xFF8A8A8A : loud ? 0xFFE8503C : t >= Voice.WHISPER ? 0xFFE6C24E : 0xFFC8C8C0;
        // значок микрофона
        ctx.fill(x + 2, y, x + 5, y + 6, col);
        ctx.fill(x, y + 3, x + 1, y + 7, col);
        ctx.fill(x + 6, y + 3, x + 7, y + 7, col);
        ctx.fill(x, y + 7, x + 7, y + 8, col);
        ctx.fill(x + 3, y + 8, x + 4, y + 10, col);
        ctx.fill(x + 1, y + 10, x + 6, y + 11, col);
        if (failed) {
            ctx.drawTextWithShadow(c.textRenderer, "нет микрофона", x + 11, y + 2, 0xFF9A9A9A);
            return;
        }
        int bx = x + 11, by = y + 3, bw = 56;
        int w1 = Math.round(bw * Voice.WHISPER / MAX), w2 = Math.round(bw * Voice.SHOUT / MAX);
        ctx.fill(bx - 1, by - 1, bx + bw + 1, by + 6, 0x99000000);
        ctx.fill(bx, by, bx + w1, by + 5, 0x55909090);            // шёпот — не слышно
        ctx.fill(bx + w1, by, bx + w2, by + 5, 0x55C8A030);       // голос
        ctx.fill(bx + w2, by, bx + bw, by + 5, 0x55C83020);       // крик
        int f = Math.round(bw * Math.min(t, MAX) / MAX);
        if (f > 0) ctx.fill(bx, by + 1, bx + f, by + 4, t >= Voice.SHOUT ? 0xFFE8503C : t >= Voice.WHISPER ? 0xFFE6C24E : 0xFFD0D0C8);
        if (calib != 0) ctx.drawTextWithShadow(c.textRenderer, calib == 1 ? "тишина…" : "говори…", bx + bw + 5, y + 2, 0xFFE6C24E);
        else if (loud) ctx.drawTextWithShadow(c.textRenderer, heardLevel >= Voice.SHOUT ? "крик слышно далеко" : "тебя слышно", bx + bw + 5, y + 2, 0xFFE8503C);
    }

    // ------------------------------------------------------------------ поток, слушающий микрофон

    private static final class Listener implements Runnable {
        private final String dev;
        private final short[] frame = new short[FRAME];
        private int have, active;
        private float floor;
        // калибровка
        private int calFrames;
        private double calSum;
        private final List<Float> calSpeech = new ArrayList<>();
        private float calQuiet;

        Listener(String dev) {
            this.dev = dev;
            this.floor = Float.isNaN(quietDb) ? -55f : quietDb;
        }

        @Override
        public void run() {
            Mic.Source src = null;
            try {
                src = Mic.open(dev);
                status = "слушаю: " + src.name();
                short[] buf = new short[FRAME * 8];
                while (running && worker == Thread.currentThread()) {
                    int n = src.read(buf);
                    if (n <= 0) {
                        Thread.sleep(10);
                        continue;
                    }
                    for (int i = 0; i < n; i++) {
                        frame[have++] = buf[i];
                        if (have == FRAME) {
                            have = 0;
                            process();
                        }
                    }
                }
            } catch (InterruptedException ignored) {
            } catch (Throwable t) {
                failed = true;
                String why = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
                status = "микрофон недоступен (" + why + ")";
                say("Микрофон недоступен: " + why + ". Проверь, что он подключён и разрешён для игры, потом /voice on", Formatting.RED);
            } finally {
                if (src != null) src.close();
                meter = 0f;
            }
        }

        /** Один кусок в 20 мс: громкость в дБ → доля обычной речи. */
        private void process() {
            double mean = 0;
            for (short s : frame) mean += s;
            mean /= FRAME;
            double sum = 0;
            for (short s : frame) sum += (s - mean) * (s - mean);
            float db = (float) (20.0 * Math.log10(Math.sqrt(sum / FRAME) / 32768.0 + 1e-7));

            if (calib != 0) {
                calibrate(db);
                return;
            }
            // «тишина в комнате»: быстро опускается, медленно поднимается
            boolean tuned = !Float.isNaN(speechDb) && !Float.isNaN(quietDb);
            if (db < floor) floor += (db - floor) * 0.25f;
            else floor += Math.min(db - floor, 0.02f);
            floor = tuned ? Math.max(quietDb - 6f, Math.min(quietDb + 6f, floor)) : Math.max(-80f, Math.min(-25f, floor));
            float ref = tuned ? Math.max(speechDb, floor + 12f) : floor + 24f;
            float t = (db - floor - 6f) / (ref - floor - 6f) * sens;
            t = Math.max(0f, Math.min(3f, t));
            float m = meter;
            meter = t > m ? t : Math.max(t, m - 0.06f);
            // щелчок клавиши или мыши короче 60 мс — не голос
            if (t >= Voice.WHISPER) active++;
            else active = 0;
            if (active >= 3) synchronized (LOCK) {
                if (t > peak) peak = t;
            }
        }

        private void calibrate(float db) {
            meter = 0f;
            if (calib == 1) {
                calSum += db;
                if (++calFrames >= 150) {
                    calQuiet = (float) (calSum / calFrames);
                    calFrames = 0;
                    calSum = 0;
                    calSpeech.clear();
                    calib = 2;
                    say("Теперь четыре секунды говори обычным голосом — так, как говорил бы с соседом по комнате.", Formatting.YELLOW);
                }
                return;
            }
            if (db > calQuiet + 8f) calSpeech.add(db);
            if (++calFrames < 200) return;
            calFrames = 0;
            calib = 0;
            if (calSpeech.size() < 20) {
                say("Голоса не расслышал. Проверь микрофон (/voice devices) и попробуй ещё раз: /voice calibrate", Formatting.RED);
                return;
            }
            Collections.sort(calSpeech);
            float speech = calSpeech.get((int) (calSpeech.size() * 0.75f));
            quietDb = calQuiet;
            speechDb = Math.max(speech, calQuiet + 12f);
            floor = calQuiet;
            MinecraftClient.getInstance().execute(VoiceClient::save);
            say("Готово. Шёпот мертвецы не услышат, обычный голос — в нескольких шагах, крик — метров за тридцать.", Formatting.GREEN);
        }

        private static void say(String s, Formatting f) {
            MinecraftClient.getInstance().execute(() -> msg(s, f));
        }
    }

    // ------------------------------------------------------------------ служебное

    private static void msg(String s, Formatting f) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) c.player.sendMessage(Text.literal(s).formatted(f), false);
    }

    private static void load() {
        try {
            file = FabricLoader.getInstance().getConfigDir().resolve("zomboidmod_voice.properties");
            if (!Files.exists(file)) return;
            Properties p = new Properties();
            try (Reader r = Files.newBufferedReader(file)) {
                p.load(r);
            }
            enabled = "true".equals(p.getProperty("enabled"));
            hinted = "true".equals(p.getProperty("hinted"));
            sens = Math.max(0.3f, Math.min(3f, Float.parseFloat(p.getProperty("sens", "1"))));
            device = p.getProperty("device", "");
            if (p.getProperty("quiet") != null && p.getProperty("speech") != null) {
                quietDb = Float.parseFloat(p.getProperty("quiet"));
                speechDb = Float.parseFloat(p.getProperty("speech"));
            }
        } catch (Throwable ignored) {
        }
    }

    private static void save() {
        try {
            if (file == null) return;
            Properties p = new Properties();
            p.setProperty("enabled", String.valueOf(enabled));
            p.setProperty("hinted", String.valueOf(hinted));
            p.setProperty("sens", String.valueOf(sens));
            p.setProperty("device", device);
            if (!Float.isNaN(quietDb) && !Float.isNaN(speechDb)) {
                p.setProperty("quiet", String.valueOf(quietDb));
                p.setProperty("speech", String.valueOf(speechDb));
            }
            try (Writer w = Files.newBufferedWriter(file)) {
                p.store(w, "Zomboid mod: microphone (only loudness is used, nothing is recorded)");
            }
        } catch (Throwable ignored) {
        }
    }
}
