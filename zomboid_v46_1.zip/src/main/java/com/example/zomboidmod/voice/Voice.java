package com.example.zomboidmod.voice;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Мертвецы слышат настоящий голос игрока. Клиент слушает микрофон и присылает одно число — громкость
 * (100 = обычная речь); сам звук никуда не записывается и не передаётся. Шёпот не слышен никому,
 * разговор — в соседней комнате, крик — на полквартала.
 */
public final class Voice {
    private Voice() {
    }

    /** Ниже этой громкости (в долях обычной речи) — шёпот: его не слышно. */
    public static final float WHISPER = 0.45f;
    /** С этой громкости — уже крик. */
    public static final float SHOUT = 1.3f;

    public record LoudPayload(int level) implements CustomPayload {
        public static final CustomPayload.Id<LoudPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "voice_loud"));
        public static final PacketCodec<RegistryByteBuf, LoudPayload> CODEC = PacketCodec.tuple(PacketCodecs.VAR_INT, LoudPayload::level, LoudPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    private static final Map<UUID, Long> LAST = new HashMap<>();

    public static void register() {
        PayloadTypeRegistry.playC2S().register(LoudPayload.ID, LoudPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(LoudPayload.ID, (pl, ctx) -> heard(ctx.player(), pl.level()));
    }

    /** На сколько блоков слышно голос такой громкости. */
    public static int radius(int level) {
        if (level < WHISPER * 100f) return 0;
        float[][] pts = {{45, 4}, {80, 7}, {130, 14}, {180, 26}, {260, 48}};
        for (int i = 1; i < pts.length; i++) {
            if (level <= pts[i][0]) {
                float k = (level - pts[i - 1][0]) / (pts[i][0] - pts[i - 1][0]);
                return Math.round(MathHelper.lerp(k, pts[i - 1][1], pts[i][1]));
            }
        }
        return 48;
    }

    private static void heard(ServerPlayerEntity p, int level) {
        if (p == null || !p.isAlive() || p.isSpectator() || p.isCreative()) return;
        long now = p.getWorld().getTime();
        Long last = LAST.get(p.getUuid());
        if (last != null && now - last >= 0 && now - last < 4) return;   // не чаще пяти раз в секунду
        LAST.put(p.getUuid(), now);
        int r = radius(MathHelper.clamp(level, 0, 300));
        if (r > 0) Noise.voice(p, r);
    }
}
