package com.example.zomboidmod.metal;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.build.BuildState;
import com.example.zomboidmod.build.Carpentry;
import com.example.zomboidmod.media.Knowledge;
import com.example.zomboidmod.vehicle.VehicleEntity;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.MapColor;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Equipment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Металлообработка (как в PZ): газовая горелка, сварочная маска, металлолом и листы.
 * Разбирать металлическую мебель и технику (отвёртка — электроника и шурупы, горелка — листы и трубы),
 * резать брошенные машины на металл, варить стены и листы на окна, бронировать машину.
 */
public final class Metal {
    private Metal() {
    }

    public static Item SCRAP, SHEET, SMALL_SHEET, SCREWS, ELECTRONICS, WIRE, BLOWTORCH, PROPANE, MASK, CAR_ARMOR;
    public static Block METAL_WALL, METAL_PLATE;
    public static SoundEvent TORCH_SOUND;
    public static final List<Item> ITEMS = new ArrayList<>();

    /** Газ: 100 единиц в полной горелке. */
    public static final int FUEL = 100;
    /** Сколько газа уходит на один рецепт с горелкой в сетке крафта. */
    public static final int CRAFT_COST = 5;

    private static Item reg(String id, Item item) {
        Item it = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
        ITEMS.add(it);
        return it;
    }

    public static void register() {
        Identifier sid = Identifier.of(ZomboidMod.MOD_ID, "blowtorch");
        TORCH_SOUND = Registry.register(Registries.SOUND_EVENT, sid, SoundEvent.of(sid));

        SCRAP = reg("scrap_metal", new Hinted(new Item.Settings().maxCount(64), "Горелкой из 4 кусков — малый лист"));
        SMALL_SHEET = reg("small_metal_sheet", new Hinted(new Item.Settings().maxCount(32), "Два малых листа горелкой — большой лист"));
        SHEET = reg("metal_sheet", new Hinted(new Item.Settings().maxCount(16), "Для сварных стен, листов на окна и брони машины"));
        SCREWS = reg("screws", new Hinted(new Item.Settings().maxCount(64), "Скрепить металл и электронику"));
        ELECTRONICS = reg("electronics_scrap", new Hinted(new Item.Settings().maxCount(64), "Платы и детали: для самодельных приборов"));
        WIRE = reg("wire", new Hinted(new Item.Settings().maxCount(64), "Медный провод"));
        BLOWTORCH = reg("blowtorch", new Torch(new Item.Settings().maxDamage(FUEL)));
        PROPANE = reg("propane_tank", new Propane(new Item.Settings().maxDamage(4)));
        MASK = reg("welding_mask", new Mask(new Item.Settings().maxCount(1)));
        CAR_ARMOR = reg("car_armor_kit", new Hinted(new Item.Settings().maxCount(1),
                "ПКМ по машине (горелка с газом в инвентаре): листы на окна, решётка на капот. Машина держит удары вдвое лучше, но тяжелее"));

        METAL_WALL = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, "metal_wall"),
                new Block(AbstractBlock.Settings.create().mapColor(MapColor.IRON_GRAY).strength(6f, 20f).sounds(BlockSoundGroup.METAL)));
        METAL_PLATE = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, "metal_plate"),
                new PlateBlock(AbstractBlock.Settings.create().mapColor(MapColor.IRON_GRAY).strength(4f, 12f).sounds(BlockSoundGroup.METAL).nonOpaque()));
        reg("metal_wall", new WeldItem(METAL_WALL, new Item.Settings(), "Сварная стена: зомби ломают её очень долго. Ставится с горелкой в инвентаре"));
        reg("metal_plate", new WeldItem(METAL_PLATE, new Item.Settings(), "Лист на окно или проём. Ставится с горелкой в инвентаре"));

        Knowledge.gate(Registries.ITEM.get(Identifier.of(ZomboidMod.MOD_ID, "metal_wall")), "welding", PzSkill.METALWORKING, 2);
        Knowledge.gate(Registries.ITEM.get(Identifier.of(ZomboidMod.MOD_ID, "metal_plate")), "welding", PzSkill.METALWORKING, 1);
        Knowledge.gate(CAR_ARMOR, "welding", PzSkill.METALWORKING, 3);
        Knowledge.rule((p, in, out) -> {
            for (int i = 0; i < in.size(); i++) {
                ItemStack s = in.getStack(i);
                if (s.getItem() instanceof Torch && Torch.fuel(s) < CRAFT_COST) return "В горелке кончился газ: заправьте баллоном пропана";
            }
            return null;
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> ITEMS.forEach(e::add));
        ServerTickEvents.END_SERVER_TICK.register(Metal::tick);
        SALVAGE.putAll(Salvage.table());
    }

    // =====================================================================================
    //                                         предметы
    // =====================================================================================

    public static class Hinted extends Item {
        final String hint;

        public Hinted(Settings s, String hint) {
            super(s);
            this.hint = hint;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(hint).formatted(Formatting.GRAY));
        }
    }

    /** Газовая горелка. «Прочность» — это газ: пустая горелка не ломается, её заправляют баллоном. */
    public static class Torch extends Item {
        Torch(Settings s) {
            super(s);
        }

        public static int fuel(ItemStack s) {
            return s.getItem() instanceof Torch ? Math.max(0, s.getMaxDamage() - s.getDamage()) : 0;
        }

        public static boolean burn(ItemStack s, int n) {
            if (fuel(s) < n) return false;
            s.setDamage(Math.min(s.getMaxDamage(), s.getDamage() + n));
            return true;
        }

        @Override
        public ItemStack getRecipeRemainder(ItemStack stack) {   // в крафте горелка не тратится — уходит газ
            ItemStack c = stack.copy();
            c.setCount(1);
            c.setDamage(Math.min(c.getMaxDamage(), c.getDamage() + CRAFT_COST));
            return c;
        }

        @Override
        public boolean isEnchantable(ItemStack stack) {
            return false;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            int f = fuel(stack);
            tooltip.add(Text.literal("Газ: " + f + "%").formatted(f > 20 ? Formatting.GREEN : f > 0 ? Formatting.GOLD : Formatting.RED));
            tooltip.add(Text.literal("Режет металл, варит листы. Без маски слепит глаза").formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Заправка: баллон пропана во второй руке + ПКМ").formatted(Formatting.DARK_GRAY));
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            ItemStack other = user.getStackInHand(hand == Hand.MAIN_HAND ? Hand.OFF_HAND : Hand.MAIN_HAND);
            if (other.getItem() instanceof Propane) return refill(world, user, st, other) ? TypedActionResult.success(st) : TypedActionResult.fail(st);
            return TypedActionResult.pass(st);
        }
    }

    /** Баллон пропана: 4 полные заправки горелки. */
    public static class Propane extends Hinted {
        Propane(Settings s) {
            super(s, "Заправляет газовую горелку (горелка во второй руке + ПКМ)");
        }

        @Override
        public boolean isEnchantable(ItemStack stack) {
            return false;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            super.appendTooltip(stack, context, tooltip, type);
            tooltip.add(Text.literal("Заправок осталось: " + (stack.getMaxDamage() - stack.getDamage())).formatted(Formatting.DARK_GRAY));
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            ItemStack other = user.getStackInHand(hand == Hand.MAIN_HAND ? Hand.OFF_HAND : Hand.MAIN_HAND);
            if (other.getItem() instanceof Torch) return refill(world, user, other, st) ? TypedActionResult.success(user.getStackInHand(hand)) : TypedActionResult.fail(st);
            return TypedActionResult.pass(st);
        }
    }

    static boolean refill(World world, PlayerEntity user, ItemStack torch, ItemStack tank) {
        if (torch.getDamage() <= 0) {
            if (!world.isClient) user.sendMessage(Text.literal("Горелка и так полная").formatted(Formatting.GRAY), true);
            return false;
        }
        if (world.isClient) return true;
        torch.setDamage(0);
        if (!user.isCreative()) {
            tank.setDamage(tank.getDamage() + 1);
            if (tank.getDamage() >= tank.getMaxDamage()) {
                tank.decrement(1);
                user.sendMessage(Text.literal("Горелка заправлена. Баллон пуст").formatted(Formatting.GRAY), true);
            } else user.sendMessage(Text.literal("Горелка заправлена").formatted(Formatting.GREEN), true);
        }
        world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.PLAYERS, 0.4f, 1.7f);
        return true;
    }

    /** Сварочная маска: надевается на голову, защищает глаза. Через неё всё видно, как сквозь тёмное стекло. */
    public static class Mask extends Hinted implements Equipment {
        Mask(Settings s) {
            super(s, "Надеть на голову (ПКМ). Без маски сварка слепит");
        }

        @Override
        public EquipmentSlot getSlotType() {
            return EquipmentSlot.HEAD;
        }

        @Override
        public RegistryEntry<SoundEvent> getEquipSound() {
            return SoundEvents.ITEM_ARMOR_EQUIP_IRON;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            return this.equipAndSwap(this, world, user, hand);
        }
    }

    public static boolean masked(LivingEntity p) {
        return MASK != null && p.getEquippedStack(EquipmentSlot.HEAD).isOf(MASK);
    }

    /** Вспышка сварки без маски. */
    static void glare(ServerPlayerEntity p) {
        if (masked(p) || p.isCreative()) return;
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 50, 0, false, false, true));
        p.sendMessage(Text.literal("Глаза режет от вспышки! Наденьте сварочную маску").formatted(Formatting.RED), true);
    }

    /** Лучшая горелка в инвентаре (сначала — в руке). */
    public static ItemStack torch(PlayerEntity p, int need) {
        ItemStack h = p.getMainHandStack();
        if (Torch.fuel(h) >= need) return h;
        h = p.getOffHandStack();
        if (Torch.fuel(h) >= need) return h;
        var inv = p.getInventory();
        ItemStack best = ItemStack.EMPTY;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (Torch.fuel(s) >= need && Torch.fuel(s) > Torch.fuel(best)) best = s;
        }
        return best;
    }

    static boolean hasTorch(PlayerEntity p) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).getItem() instanceof Torch) return true;
        return false;
    }

    // =====================================================================================
    //                                 сварные стены и листы
    // =====================================================================================

    /** Лист металла на окно: тонкая пластина по центру блока, вдоль оси X или Z. */
    public static class PlateBlock extends Block {
        public static final EnumProperty<Direction.Axis> AXIS = Properties.HORIZONTAL_AXIS;
        private static final VoxelShape X = Block.createCuboidShape(0, 0, 7, 16, 16, 9), Z = Block.createCuboidShape(7, 0, 0, 9, 16, 16);

        public PlateBlock(Settings s) {
            super(s);
            setDefaultState(getDefaultState().with(AXIS, Direction.Axis.X));
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(AXIS);
        }

        @Override
        public BlockState getPlacementState(ItemPlacementContext ctx) {
            Direction f = ctx.getHorizontalPlayerFacing();
            return getDefaultState().with(AXIS, f.getAxis() == Direction.Axis.Z ? Direction.Axis.X : Direction.Axis.Z);
        }

        @Override
        protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            return state.get(AXIS) == Direction.Axis.X ? X : Z;
        }
    }

    static class WeldItem extends BlockItem {
        final String hint;

        WeldItem(Block b, Settings s, String hint) {
            super(b, s);
            this.hint = hint;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(hint).formatted(Formatting.GRAY));
        }
    }

    public static boolean welded(Block b) {
        return b != null && (b == METAL_WALL || b == METAL_PLATE);
    }

    private static int weldCost(Block b) {
        return b == METAL_WALL ? 6 : 3;
    }

    /** Можно ли варить (вызывается и на клиенте). null — можно. */
    public static String placeCheck(PlayerEntity p, Block b) {
        if (p == null || p.isCreative()) return null;
        int need = weldCost(b);
        if (torch(p, need).isEmpty())
            return hasTorch(p) ? "В горелке мало газа — заправьте баллоном пропана" : "Чтобы приварить, нужна газовая горелка в инвентаре";
        return null;
    }

    /** Приварили: газ, вспышка, опыт, прочность. */
    public static void placed(PlayerEntity p, World w, BlockPos pos, Block b) {
        if (!(w instanceof ServerWorld sw)) return;
        int lvl = 0;
        if (p instanceof ServerPlayerEntity sp && !sp.isCreative()) {
            lvl = Skills.level(sp, PzSkill.METALWORKING);
            ItemStack t = torch(sp, weldCost(b));
            // опытный сварщик тратит меньше газа
            Torch.burn(t, Math.max(1, weldCost(b) - lvl / 4));
            glare(sp);
            Skills.addXp(sp, PzSkill.METALWORKING, b == METAL_WALL ? 5f : 3f);
            sp.getItemCooldownManager().set(b.asItem(), Math.max(8, Math.round((b == METAL_WALL ? 40 : 24) * (1f - 0.06f * lvl))));
            Carpentry.tire(sp, 0.01f);
        } else if (p instanceof ServerPlayerEntity sp) lvl = Skills.level(sp, PzSkill.METALWORKING);
        sparks(sw, pos.toCenterPos().x, pos.toCenterPos().y, pos.toCenterPos().z, 14);
        sw.playSound(null, pos, TORCH_SOUND, SoundCategory.BLOCKS, 0.8f, 1f);
        sw.playSound(null, pos, SoundEvents.BLOCK_ANVIL_PLACE, SoundCategory.BLOCKS, 0.25f, 1.6f);
        Noise.emitAt(sw, pos, 12);
        int base = b == METAL_WALL ? 4000 + 250 * lvl : 2500 + 150 * lvl;
        BuildState bs = BuildState.get(sw);
        bs.built.put(pos.asLong(), BuildState.pack(base, base));
        bs.markDirty();
    }

    static void sparks(ServerWorld w, double x, double y, double z, int n) {
        w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, n, 0.3, 0.3, 0.3, 0.15);
        w.spawnParticles(ParticleTypes.SMALL_FLAME, x, y, z, Math.max(1, n / 3), 0.2, 0.2, 0.2, 0.01);
    }

    /** Горелкой срезали металлический блок: что осталось. */
    public static List<ItemStack> cut(ServerPlayerEntity p, BlockState st, ItemStack torch) {
        List<ItemStack> out = new ArrayList<>();
        ServerWorld w = p.getServerWorld();
        Block b = st.getBlock();
        int lvl = Skills.level(p, PzSkill.METALWORKING);
        Torch.burn(torch, 2);
        glare(p);
        sparks(w, p.getX(), p.getEyeY() - 0.4, p.getZ(), 6);
        w.playSound(null, p.getBlockPos(), TORCH_SOUND, SoundCategory.BLOCKS, 0.7f, 1.1f);
        Skills.addXp(p, PzSkill.METALWORKING, 3f);
        Random r = p.getRandom();
        if (b == METAL_WALL) {
            out.add(new ItemStack(r.nextFloat() < 0.6f + 0.04f * lvl ? SHEET : SMALL_SHEET));
            if (r.nextFloat() < 0.5f) out.add(new ItemStack(SCRAP, 1 + r.nextInt(2)));
        } else if (b == METAL_PLATE) {
            out.add(new ItemStack(SMALL_SHEET));
            if (r.nextFloat() < 0.3f + 0.04f * lvl) out.add(new ItemStack(SCRAP));
        } else {
            out.addAll(Block.getDroppedStacks(st, w, p.getBlockPos(), null, p, torch));
            if (r.nextFloat() < 0.4f) out.add(new ItemStack(SCRAP));
        }
        return out;
    }

    // =====================================================================================
    //                        разбор металлической мебели и техники
    // =====================================================================================

    /** Что даёт вещь: листы, малые листы, лом, трубы, провод, электроника, шурупы (максимум каждого). */
    public record Yield(int sheet, int small, int scrap, int pipe, int wire, int elec, int screws) {}

    static final Map<String, Yield> SALVAGE = new HashMap<>();

    /**
     * Отвёртка — аккуратно: электроника, провод, шурупы, немного лома. Горелка — грубо: листы, трубы и лом,
     * а мелкая электроника частью сгорает. Возвращает true, если вещь разобрана.
     */
    public static boolean salvage(ServerWorld w, ServerPlayerEntity p, BlockPos pos, BlockState st, ItemStack tool) {
        boolean driver = tool.isOf(com.example.zomboidmod.vehicle.Mechanics.SCREWDRIVER);
        boolean torch = tool.getItem() instanceof Torch;
        if (!driver && !torch) return false;
        Identifier id = Registries.BLOCK.getId(st.getBlock());
        Yield y = SALVAGE.get(id.getNamespace().equals("minecraft") ? "minecraft:" + id.getPath() : id.getPath());
        if (y == null) return false;
        if (torch && Torch.fuel(tool) < 3) {
            p.sendMessage(Text.literal("В горелке мало газа").formatted(Formatting.GRAY), true);
            return false;
        }
        int lvl = Skills.level(p, PzSkill.METALWORKING);
        Random r = p.getRandom();
        float k = 1f + 0.08f * lvl;
        List<ItemStack> drops = new ArrayList<>();
        if (driver) {
            add(drops, ELECTRONICS, y.elec(), k, r);
            add(drops, WIRE, y.wire(), k, r);
            add(drops, SCREWS, y.screws(), k, r);
            add(drops, SCRAP, (y.scrap() + 1) / 2, k, r);
            add(drops, SMALL_SHEET, y.small() / 2, k, r);
        } else {
            add(drops, SHEET, y.sheet(), k, r);
            add(drops, SMALL_SHEET, y.small(), k, r);
            add(drops, SCRAP, y.scrap(), k, r);
            add(drops, ZomboidMod.METAL_PIPE, y.pipe(), 1f, r);
            add(drops, WIRE, y.wire() / 2, 1f, r);
            add(drops, ELECTRONICS, y.elec() / 2, 1f, r);
        }
        if (drops.isEmpty()) drops.add(new ItemStack(SCRAP));
        BuildState bs = BuildState.get(w);
        if (bs.built.containsKey(pos.asLong())) {
            bs.built.remove(pos.asLong());
            bs.markDirty();
        }
        w.breakBlock(pos, false, p);
        for (ItemStack d : drops) Block.dropStack(w, pos, d);
        if (driver) {
            if (!p.isCreative()) tool.damage(1, p, EquipmentSlot.MAINHAND);
            w.playSound(null, pos, SoundEvents.BLOCK_CHAIN_BREAK, SoundCategory.BLOCKS, 0.9f, 1.3f);
            Noise.emitAt(w, pos, 6);
        } else {
            Torch.burn(tool, 3);
            glare(p);
            sparks(w, pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5, 12);
            w.playSound(null, pos, TORCH_SOUND, SoundCategory.BLOCKS, 0.8f, 1f);
            Noise.emitAt(w, pos, 10);
        }
        Skills.addXp(p, PzSkill.METALWORKING, driver ? 3f : 5f);
        StringBuilder sb = new StringBuilder("Разобрано: ");
        for (int i = 0; i < drops.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(drops.get(i).getName().getString()).append(" ×").append(drops.get(i).getCount());
        }
        p.sendMessage(Text.literal(sb.toString()).formatted(Formatting.GRAY), true);
        return true;
    }

    private static void add(List<ItemStack> to, Item item, int max, float k, Random r) {
        if (max <= 0 || item == null) return;
        int n = Math.round(max * (0.45f + 0.55f * r.nextFloat()) * k);
        if (n > 0) to.add(new ItemStack(item, n));
    }

    // =====================================================================================
    //                          машины: разрезать на металл и бронировать
    // =====================================================================================

    private enum JobType {CUT, ARMOR}

    private record Job(JobType type, VehicleEntity v, int total, int[] left) {}

    private static final Map<UUID, Job> JOBS = new HashMap<>();

    /** ПКМ по машине: горелка (присев) — резать; комплект брони — приварить. null — не наше дело. */
    public static ActionResult vehicleInteract(VehicleEntity v, PlayerEntity player, Hand hand) {
        ItemStack st = player.getStackInHand(hand);
        boolean armor = CAR_ARMOR != null && st.isOf(CAR_ARMOR);
        boolean cut = st.getItem() instanceof Torch && player.isSneaking();
        if (!armor && !cut) return null;
        if (player.getWorld().isClient) return ActionResult.SUCCESS;
        if (!(player instanceof ServerPlayerEntity p)) return ActionResult.PASS;
        if (JOBS.containsKey(p.getUuid())) {
            JOBS.remove(p.getUuid());
            p.sendMessage(Text.literal("Работа прервана").formatted(Formatting.GRAY), true);
            return ActionResult.CONSUME;
        }
        if (v.hasPassengers()) {
            p.sendMessage(Text.literal("В машине кто-то сидит").formatted(Formatting.GRAY), true);
            return ActionResult.CONSUME;
        }
        int lvl = Skills.level(p, PzSkill.METALWORKING);
        if (armor) {
            if (v.type.bike()) {
                p.sendMessage(Text.literal("Мотоцикл не забронировать").formatted(Formatting.GRAY), true);
                return ActionResult.CONSUME;
            }
            if (v.armored()) {
                p.sendMessage(Text.literal("Машина уже бронирована").formatted(Formatting.GRAY), true);
                return ActionResult.CONSUME;
            }
            if (torch(p, 20).isEmpty()) {
                p.sendMessage(Text.literal("Нужна горелка, в которой хватит газа (20%)").formatted(Formatting.GRAY), true);
                return ActionResult.CONSUME;
            }
            int t = Math.round(400 * (1f - 0.05f * lvl));
            JOBS.put(p.getUuid(), new Job(JobType.ARMOR, v, t, new int[]{t}));
            p.sendMessage(Text.literal("Привариваю броню... Не отходите от машины").formatted(Formatting.AQUA), true);
        } else {
            if (Torch.fuel(st) < 10) {
                p.sendMessage(Text.literal("Слишком мало газа, чтобы резать машину").formatted(Formatting.GRAY), true);
                return ActionResult.CONSUME;
            }
            int t = Math.round(600 * (1f - 0.05f * lvl));
            JOBS.put(p.getUuid(), new Job(JobType.CUT, v, t, new int[]{t}));
            p.sendMessage(Text.literal("Режу машину на металл... (ПКМ ещё раз — прервать)").formatted(Formatting.AQUA), true);
        }
        return ActionResult.CONSUME;
    }

    private static void tick(MinecraftServer server) {
        if (JOBS.isEmpty()) return;
        for (Iterator<Map.Entry<UUID, Job>> it = JOBS.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Job> en = it.next();
            Job j = en.getValue();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
            VehicleEntity v = j.v();
            boolean holding = p != null && (j.type() == JobType.CUT ? p.getMainHandStack().getItem() instanceof Torch
                    : CAR_ARMOR != null && (p.getMainHandStack().isOf(CAR_ARMOR) || p.getOffHandStack().isOf(CAR_ARMOR)));
            if (p == null || !p.isAlive() || v.isRemoved() || p.getWorld() != v.getWorld() || p.squaredDistanceTo(v) > 30 || !holding || v.hasPassengers()) {
                if (p != null) p.sendMessage(Text.literal("Работа прервана").formatted(Formatting.GRAY), true);
                it.remove();
                continue;
            }
            ServerWorld w = p.getServerWorld();
            int left = --j.left()[0];
            if (left % 20 == 0) {
                ItemStack t = j.type() == JobType.CUT ? p.getMainHandStack() : torch(p, 1);
                if (!Torch.burn(t, 1)) {
                    p.sendMessage(Text.literal("Кончился газ в горелке").formatted(Formatting.RED), true);
                    it.remove();
                    continue;
                }
                int pct = 100 - left * 100 / j.total();
                p.sendMessage(Text.literal((j.type() == JobType.CUT ? "Режу машину: " : "Привариваю броню: ") + pct + "%").formatted(Formatting.AQUA), true);
                double a = p.getRandom().nextDouble() * Math.PI * 2;
                sparks(w, v.getX() + Math.cos(a) * v.getWidth() * 0.45, v.getY() + 0.4 + p.getRandom().nextDouble() * 0.8, v.getZ() + Math.sin(a) * v.getWidth() * 0.45, 10);
                w.playSound(null, v.getBlockPos(), TORCH_SOUND, SoundCategory.BLOCKS, 0.8f, 0.9f + p.getRandom().nextFloat() * 0.2f);
                Noise.emitAt(w, v.getBlockPos(), 10);
                Skills.addXp(p, PzSkill.METALWORKING, 0.8f);
                if (left % 60 == 0) glare(p);
                Carpentry.tire(p, 0.004f);
            }
            if (left > 0) continue;
            it.remove();
            if (j.type() == JobType.ARMOR) {
                ItemStack kit = p.getMainHandStack().isOf(CAR_ARMOR) ? p.getMainHandStack() : p.getOffHandStack();
                if (!p.isCreative()) kit.decrement(1);
                v.setArmored(true);
                Skills.addXp(p, PzSkill.METALWORKING, 25f);
                w.playSound(null, v.getBlockPos(), SoundEvents.BLOCK_ANVIL_USE, SoundCategory.BLOCKS, 0.6f, 0.8f);
                p.sendMessage(Text.literal("Броня приварена! Машина выдержит гораздо больше").formatted(Formatting.GREEN), false);
            } else {
                Random r = p.getRandom();
                int lvl = Skills.level(p, PzSkill.METALWORKING);
                float k = 1f + 0.08f * lvl;
                boolean big = v.type.width >= 2.4f;
                List<ItemStack> drops = new ArrayList<>();
                if (!v.type.bike()) add(drops, SHEET, (big ? 5 : 3) + (v.armored() ? 3 : 0), k, r);
                add(drops, SMALL_SHEET, v.type.bike() ? 2 : 3, k, r);
                add(drops, SCRAP, v.type.bike() ? 5 : 9, k, r);
                add(drops, ZomboidMod.METAL_PIPE, v.type.bike() ? 2 : 2, 1f, r);
                add(drops, WIRE, 3, k, r);
                add(drops, ELECTRONICS, 2, k, r);
                add(drops, SCREWS, 6, k, r);
                for (ItemStack d : drops) v.dropStack(d, 0.5f);
                sparks(w, v.getX(), v.getY() + 0.8, v.getZ(), 30);
                w.playSound(null, v.getBlockPos(), SoundEvents.ENTITY_IRON_GOLEM_DEATH, SoundCategory.BLOCKS, 0.7f, 0.6f);
                Skills.addXp(p, PzSkill.METALWORKING, 30f);
                v.scrapped();
                p.sendMessage(Text.literal("Машина разрезана на металл").formatted(Formatting.GREEN), false);
            }
        }
    }
}
