package com.example.zomboidmod.metal;

import java.util.HashMap;
import java.util.Map;

/** Что можно разобрать на металл и детали. Ключ — id блока мода или «minecraft:id». */
final class Salvage {
    private Salvage() {
    }

    private static Metal.Yield y(int sheet, int small, int scrap, int pipe, int wire, int elec, int screws) {
        return new Metal.Yield(sheet, small, scrap, pipe, wire, elec, screws);
    }

    static Map<String, Metal.Yield> table() {
        Map<String, Metal.Yield> m = new HashMap<>();
        //                          лист мал. лом труба провод элек. шурупы
        m.put("fridge", y(1, 2, 3, 0, 2, 1, 4));
        m.put("stove", y(1, 1, 3, 0, 2, 1, 3));
        m.put("washing_machine", y(1, 1, 3, 0, 2, 2, 4));
        m.put("dumpster", y(2, 2, 5, 0, 0, 0, 2));
        m.put("gas_pump", y(0, 2, 3, 1, 3, 2, 3));
        m.put("street_lamp", y(0, 0, 2, 2, 3, 1, 2));
        m.put("stop_sign", y(0, 2, 1, 1, 0, 0, 2));
        m.put("generator", y(0, 2, 3, 0, 4, 3, 4));
        m.put("shopping_cart", y(0, 0, 4, 1, 0, 0, 1));
        for (String s : new String[]{"shelf_food", "shelf_meds", "shelf_tools", "shelf_books"}) m.put(s, y(0, 2, 2, 0, 0, 0, 4));
        m.put("shelf_electronics", y(0, 2, 2, 0, 2, 2, 4));
        m.put("trash_can", y(0, 1, 2, 0, 0, 0, 0));
        m.put("hydrant", y(0, 0, 4, 1, 0, 0, 1));
        m.put("tv", y(0, 0, 1, 0, 2, 3, 3));
        m.put("radio", y(0, 0, 0, 0, 2, 3, 2));
        m.put("floor_lamp", y(0, 0, 1, 1, 2, 1, 1));
        m.put("kitchen_sink", y(0, 1, 1, 1, 0, 0, 2));
        m.put("bathroom_sink", y(0, 0, 1, 1, 0, 0, 1));
        m.put("bathtub", y(1, 0, 2, 1, 0, 0, 1));
        m.put("mailbox", y(0, 1, 1, 0, 0, 0, 2));
        m.put("road_barrier", y(0, 1, 2, 1, 0, 0, 2));
        m.put("minecraft:anvil", y(0, 0, 9, 0, 0, 0, 0));
        m.put("minecraft:chipped_anvil", y(0, 0, 7, 0, 0, 0, 0));
        m.put("minecraft:damaged_anvil", y(0, 0, 5, 0, 0, 0, 0));
        m.put("minecraft:cauldron", y(0, 1, 4, 0, 0, 0, 0));
        m.put("minecraft:water_cauldron", y(0, 1, 4, 0, 0, 0, 0));
        m.put("minecraft:hopper", y(0, 1, 3, 0, 0, 0, 0));
        m.put("minecraft:blast_furnace", y(0, 1, 3, 0, 0, 0, 0));
        m.put("minecraft:lightning_rod", y(0, 0, 1, 1, 1, 0, 0));
        m.put("minecraft:jukebox", y(0, 0, 1, 0, 2, 3, 2));
        m.put("minecraft:note_block", y(0, 0, 0, 0, 1, 2, 1));
        m.put("minecraft:observer", y(0, 0, 1, 0, 1, 2, 1));
        m.put("minecraft:daylight_detector", y(0, 0, 0, 0, 1, 2, 1));
        return m;
    }
}
