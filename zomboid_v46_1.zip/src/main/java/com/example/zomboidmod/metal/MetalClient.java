package com.example.zomboidmod.metal;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** Вид сквозь сварочную маску: всё вокруг закрыто, смотришь в узкое тёмно-зелёное окошко. */
public final class MetalClient {
    private MetalClient() {
    }

    public static void init() {
        HudRenderCallback.EVENT.register(MetalClient::hud);
    }

    private static void hud(DrawContext ctx, RenderTickCounter counter) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden || !c.options.getPerspective().isFirstPerson() || !Metal.masked(c.player)) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int ww = Math.max(120, w * 46 / 100), wh = Math.max(36, h * 22 / 100);
        int x0 = (w - ww) / 2, y0 = (h - wh) / 2 - h / 14, x1 = x0 + ww, y1 = y0 + wh;
        int shell = 0xF2151815, rim = 0xFF2A2E2A, rim2 = 0xFF3E443E;
        ctx.fill(0, 0, w, y0, shell);
        ctx.fill(0, y1, w, h, shell);
        ctx.fill(0, y0, x0, y1, shell);
        ctx.fill(x1, y0, w, y1, shell);
        // рамка окошка
        ctx.fill(x0 - 3, y0 - 3, x1 + 3, y0, rim);
        ctx.fill(x0 - 3, y1, x1 + 3, y1 + 3, rim);
        ctx.fill(x0 - 3, y0, x0, y1, rim);
        ctx.fill(x1, y0, x1 + 3, y1, rim);
        ctx.fill(x0 - 1, y0 - 1, x1 + 1, y0, rim2);
        ctx.fill(x0 - 1, y1, x1 + 1, y1 + 1, rim2);
        // тёмное зелёное стекло
        ctx.fill(x0, y0, x1, y1, 0x8C0B2A12);
        // блик на стекле
        ctx.fill(x0 + 4, y0 + 3, x0 + ww / 3, y0 + 4, 0x30FFFFFF);
        // заклёпки
        for (int i = 0; i < 4; i++) {
            int rx = i < 2 ? x0 - 10 : x1 + 7, ry = (i % 2 == 0) ? y0 + 4 : y1 - 7;
            ctx.fill(rx, ry, rx + 3, ry + 3, 0xFF4B524B);
        }
    }
}
