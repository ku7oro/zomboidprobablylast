package com.example.zomboidmod.cooking;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.farm.Farm;
import com.example.zomboidmod.forage.Forage;
import com.example.zomboidmod.media.Knowledge;
import com.example.zomboidmod.survival.Clock;
import com.example.zomboidmod.survival.Food;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.Power;
import com.example.zomboidmod.survival.Survival;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.SpecialCraftingRecipe;
import net.minecraft.recipe.SpecialRecipeSerializer;
import net.minecraft.recipe.book.CraftingRecipeCategory;
import net.minecraft.recipe.input.CraftingRecipeInput;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Готовка (как в PZ): суп получает имя по тому, что в нём (уха, щи, грибной...), приправы делают еду вкуснее,
 * а из овощей, хлеба и теста собираются салаты, бутерброды и пироги.
 */
public final class Cooking {
    private Cooking() {
    }

    // категории ингредиентов (биты)
    public static final int MEAT = 1, FISH = 2, MUSHROOM = 4, VEG = 8, FRUIT = 16, CABBAGE = 32, NETTLE = 64, GRAIN = 128, DAIRY = 256;

    public static Item SALT, PEPPER, SPICES, OIL, FLOUR, DOUGH, CHEESE, PIE_DISH, SALAD, SANDWICH, PIE_RAW, PIE;
    public static final List<Item> ITEMS = new ArrayList<>();
    private static final Set<Item> SPICE = new HashSet<>();
    public static RecipeSerializer<?> SALAD_RECIPE, SANDWICH_RECIPE, PIE_RECIPE;

    private static Item reg(String id, Item item) {
        Item it = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
        ITEMS.add(it);
        return it;
    }

    public static void register() {
        SALT = reg("salt", new Hint(new Item.Settings().maxCount(16), "Приправа: в кастрюлю (2-я рука + ПКМ), салат, бутерброд или пирог"));
        PEPPER = reg("pepper", new Hint(new Item.Settings().maxCount(16), "Приправа: в кастрюлю (2-я рука + ПКМ), салат, бутерброд или пирог"));
        SPICES = reg("spices", new Hint(new Item.Settings().maxCount(16), "Приправа: в кастрюлю (2-я рука + ПКМ), салат, бутерброд или пирог"));
        OIL = reg("cooking_oil", new Hint(new Item.Settings().maxCount(16), "Заправка для салата и жарки"));
        SPICE.addAll(List.of(SALT, PEPPER, SPICES, OIL));
        FLOUR = reg("flour", new Hint(new Item.Settings().maxCount(16), "Мука: две муки и чистая вода — тесто"));
        DOUGH = reg("dough", new Hint(new Item.Settings().maxCount(16), "Тесто: в печи — хлеб; с начинкой в форме — пирог"));
        CHEESE = reg("cheese", new Item(new Item.Settings().maxCount(16).food(new FoodComponent.Builder().nutrition(4).saturationModifier(0.6f).build())));
        PIE_DISH = reg("pie_dish", new Hint(new Item.Settings().maxCount(1), "Форма + тесто + 1–3 начинки (ягоды, фрукты, мясо, овощи, грибы) = сырой пирог"));
        SALAD = reg("salad", new Dish(new Item.Settings().maxCount(1).food(new FoodComponent.Builder().nutrition(4).saturationModifier(0.4f)
                .usingConvertsTo(Items.BOWL).build()), "Миска + 2–4 овоща, фрукта или ягоды (+ приправа)"));
        SANDWICH = reg("sandwich", new Dish(new Item.Settings().maxCount(1).food(new FoodComponent.Builder().nutrition(6).saturationModifier(0.6f).build()),
                "Хлеб + 1–3 начинки: сыр, мясо, рыба, овощи (+ приправа)"));
        PIE_RAW = reg("pie_raw", new PieRaw(new Item.Settings().maxCount(1)));
        PIE = reg("pie", new Pie(new Item.Settings().maxCount(1)));
        Knowledge.gate(DOUGH, "kitchen", PzSkill.COOKING, 2);
        Knowledge.gate(PIE_RAW, "kitchen", PzSkill.COOKING, 3);

        SALAD_RECIPE = Registry.register(Registries.RECIPE_SERIALIZER, Identifier.of(ZomboidMod.MOD_ID, "salad"), new SpecialRecipeSerializer<>(SaladRecipe::new));
        SANDWICH_RECIPE = Registry.register(Registries.RECIPE_SERIALIZER, Identifier.of(ZomboidMod.MOD_ID, "sandwich"), new SpecialRecipeSerializer<>(SandwichRecipe::new));
        PIE_RECIPE = Registry.register(Registries.RECIPE_SERIALIZER, Identifier.of(ZomboidMod.MOD_ID, "pie"), new SpecialRecipeSerializer<>(PieRecipe::new));

        Food.perish(CHEESE, 14, 28);
        Food.perish(DOUGH, 2, 4);
        Food.perish(SALAD, 1, 2);
        Food.perish(SANDWICH, 2, 4);
        Food.perish(PIE_RAW, 1, 2);
        Food.perish(PIE, 3, 6);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(e -> ITEMS.forEach(e::add));
    }

    public static boolean spice(Item i) {
        return SPICE.contains(i);
    }

    private static final Set<Item> FRUITS = new HashSet<>(), VEGS = new HashSet<>();

    private static void sets() {
        if (!FRUITS.isEmpty()) return;
        FRUITS.addAll(List.of(Items.APPLE, Items.MELON_SLICE, Items.SWEET_BERRIES, Items.GLOW_BERRIES, Items.CHORUS_FRUIT,
                Forage.BLUEBERRY, Forage.BLACKBERRY, Forage.RASPBERRY, Forage.WILD_STRAWBERRY, Forage.WOLFBERRY, Forage.NIGHTSHADE, Forage.ROSE_HIPS,
                Forage.UNKNOWN_BERRIES, Farm.Crop.STRAWBERRY.produce));
        VEGS.addAll(List.of(Items.CARROT, Items.POTATO, Items.BAKED_POTATO, Items.BEETROOT, Items.PUMPKIN, Items.DRIED_KELP,
                Forage.WILD_GARLIC, Forage.DANDELION, Forage.CATTAIL, Forage.PLANTAIN, Forage.HAZELNUTS, Forage.ACORNS));
        for (Farm.Crop c : Farm.Crop.values()) if (c != Farm.Crop.STRAWBERRY) VEGS.add(c.produce);
    }

    /** Категория ингредиента (для названия блюда и рецептов). */
    public static int category(Item it) {
        sets();
        if (it == null) return 0;
        if (Forage.mushroom(it)) return MUSHROOM;
        if (it == Forage.NETTLE) return NETTLE | VEG;
        if (it == Farm.Crop.CABBAGE.produce) return CABBAGE | VEG;
        if (FRUITS.contains(it)) return FRUIT;
        if (VEGS.contains(it)) return VEG;
        if (it == CHEESE || it == Items.MILK_BUCKET) return DAIRY;
        if (it == Items.BREAD) return GRAIN;
        String p = Registries.ITEM.getId(it).getPath();
        if (p.contains("fish") || p.contains("cod") || p.contains("salmon") || p.contains("tuna") || p.contains("sardine")) return FISH;
        if (p.contains("beef") || p.contains("pork") || p.contains("chicken") || p.contains("mutton") || p.contains("rabbit")
                || p.contains("venison") || p.contains("meat") || p.contains("jerky") || p.contains("steak") || p.contains("sausage")) return MEAT;
        if (p.contains("corn") || p.contains("bean") || p.contains("pickle") || p.contains("pea")) return p.contains("peach") ? FRUIT : VEG;
        if (p.contains("noodle") || p.contains("cracker") || p.contains("cereal") || p.contains("bread")) return GRAIN;
        if (p.contains("grasshopper") || p.contains("grubs") || p.contains("worm")) return MEAT;
        return 0;
    }

    static boolean raw(Item it) {
        String p = Registries.ITEM.getId(it).getPath();
        int c = category(it);
        return (c & (MEAT | FISH)) != 0 && !p.startsWith("cooked") && !p.contains("jerky") && !p.contains("canned") && !p.contains("open_");
    }

    /** Название супа по составу. */
    public static String stewName(int cat, int spice) {
        String n;
        boolean meat = (cat & MEAT) != 0, fish = (cat & FISH) != 0;
        if (fish && !meat) n = "Уха";
        else if ((cat & CABBAGE) != 0 && !fish) n = "Щи";
        else if ((cat & MUSHROOM) != 0 && !meat && !fish) n = "Грибной суп";
        else if ((cat & NETTLE) != 0 && !meat && !fish) n = "Крапивный суп";
        else if (cat != 0 && (cat & ~(FRUIT)) == 0) n = "Ягодный компот";
        else if (!meat && !fish && (cat & VEG) != 0) n = "Овощной суп";
        else if (meat && (cat & VEG) != 0) n = "Рагу с мясом и овощами";
        else if (meat) n = "Мясное рагу";
        else n = "Рагу";
        return spice > 0 ? n + " с приправами" : n;
    }

    /** Подпись состава для подсказки. */
    public static String contents(int cat) {
        List<String> s = new ArrayList<>();
        if ((cat & MEAT) != 0) s.add("мясо");
        if ((cat & FISH) != 0) s.add("рыба");
        if ((cat & MUSHROOM) != 0) s.add("грибы");
        if ((cat & CABBAGE) != 0) s.add("капуста");
        if ((cat & NETTLE) != 0) s.add("крапива");
        if ((cat & VEG) != 0 && (cat & (CABBAGE | NETTLE)) == 0) s.add("овощи");
        if ((cat & FRUIT) != 0) s.add("ягоды и фрукты");
        if ((cat & DAIRY) != 0) s.add("сыр");
        if ((cat & GRAIN) != 0) s.add("крупа и хлеб");
        return String.join(", ", s);
    }

    /** Вкусная еда с приправами: настроение лучше. */
    public static void tasty(ServerPlayerEntity p, int spice, float k) {
        if (spice <= 0) return;
        Mood m = Survival.mood(p);
        m.unhappy = Math.max(0f, m.unhappy - 5f * Math.min(2, spice) * k);
        m.boredom = Math.max(0f, m.boredom - 5f * Math.min(2, spice) * k);
    }

    static NbtCompound data(ItemStack st) {
        NbtComponent c = st.get(DataComponentTypes.CUSTOM_DATA);
        return c == null ? new NbtCompound() : c.copyNbt();
    }

    static int toxicity(ItemStack st) {
        return Forage.toxicity(st);
    }

    // =====================================================================================
    //                                       предметы
    // =====================================================================================

    static class Hint extends Item {
        final String hint;

        Hint(Settings s, String hint) {
            super(s);
            this.hint = hint;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(hint).formatted(Formatting.GRAY));
        }
    }

    /** Салат или бутерброд: сытость считается из того, что внутри; приправы радуют, ядовитое — травит. */
    static class Dish extends Hint {
        Dish(Settings s, String hint) {
            super(s, hint);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            NbtCompound d = data(stack);
            if (d.contains("cat")) {
                tooltip.add(Text.literal("Состав: " + contents(d.getInt("cat"))).formatted(Formatting.GRAY));
                FoodComponent fc = stack.get(DataComponentTypes.FOOD);
                if (fc != null) tooltip.add(Text.literal("Сытость: " + fc.nutrition()).formatted(Formatting.DARK_GRAY));
                if (d.getInt("sp") > 0) tooltip.add(Text.literal("С приправами — вкуснее").formatted(Formatting.GOLD));
            } else super.appendTooltip(stack, context, tooltip, type);
        }

        @Override
        public void onCraftByPlayer(ItemStack stack, World world, PlayerEntity player) {
            if (!world.isClient && player instanceof ServerPlayerEntity p) {
                int lvl = Skills.level(p, PzSkill.COOKING);
                FoodComponent fc = stack.get(DataComponentTypes.FOOD);
                if (fc != null && lvl > 0)   // умелый повар — сытнее
                    stack.set(DataComponentTypes.FOOD, scaled(fc, 1f + 0.04f * lvl));
                Skills.addXp(p, PzSkill.COOKING, 3f);
            }
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            NbtCompound d = data(stack);
            ItemStack out = super.finishUsing(stack, world, user);
            if (!world.isClient && user instanceof ServerPlayerEntity p) {
                tasty(p, d.getInt("sp"), 1f);
                Forage.poison(p, d.getInt("tox"), null);
            }
            return out;
        }
    }

    static FoodComponent scaled(FoodComponent fc, float k) {
        FoodComponent.Builder b = new FoodComponent.Builder().nutrition(Math.max(1, Math.round(fc.nutrition() * k)))
                .saturationModifier(fc.nutrition() > 0 ? fc.saturation() / (2f * fc.nutrition()) : 0.3f);
        fc.usingConvertsTo().ifPresent(s -> b.usingConvertsTo(s.getItem()));
        return b.build();
    }

    /** Сырой пирог: печь у огня (ПКМ, как кастрюлю). */
    static class PieRaw extends Item {
        PieRaw(Settings s) {
            super(s);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            NbtCompound d = data(stack);
            if (d.contains("cat")) tooltip.add(Text.literal("Начинка: " + contents(d.getInt("cat"))).formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Испечь: зажмите ПКМ у костра, печи или плиты").formatted(Formatting.DARK_GRAY));
        }

        @Override
        public void onCraftByPlayer(ItemStack stack, World world, PlayerEntity player) {
            if (!world.isClient && player instanceof ServerPlayerEntity p) Skills.addXp(p, PzSkill.COOKING, 4f);
        }

        @Override
        public UseAction getUseAction(ItemStack stack) {
            return UseAction.NONE;
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            return 140;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            if (Power.heatNear(world, user.getBlockPos(), 2)) {
                user.setCurrentHand(hand);
                return TypedActionResult.consume(st);
            }
            if (!world.isClient) user.sendMessage(Text.literal("Нужен жар: костёр, печь или плита со светом рядом"), true);
            return TypedActionResult.fail(st);
        }

        @Override
        public void usageTick(World world, LivingEntity user, ItemStack stack, int remaining) {
            if (world.isClient && remaining % 6 == 0) {
                Vec3d v = user.getRotationVector().multiply(0.6).add(user.getPos()).add(0, 1.1, 0);
                world.addParticle(ParticleTypes.SMOKE, v.x, v.y, v.z, 0, 0.03, 0);
            }
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (world.isClient || !(user instanceof ServerPlayerEntity p)) return stack;
            if (!Power.heatNear(world, p.getBlockPos(), 2)) {
                p.sendMessage(Text.literal("Огонь погас"), true);
                return stack;
            }
            NbtCompound d = data(stack);
            int lvl = Skills.level(p, PzSkill.COOKING);
            float k = 1.3f + 0.05f * lvl;
            long now = Clock.now(world);
            ItemStack out = new ItemStack(PIE);
            NbtComponent.set(DataComponentTypes.CUSTOM_DATA, out, nbt -> {
                nbt.putFloat("n", d.getFloat("n") * k + 4f);   // тесто тоже сытное
                nbt.putFloat("s", d.getFloat("s") * k + 2f);
                nbt.putInt("cat", d.getInt("cat"));
                nbt.putInt("sp", d.getInt("sp"));
                nbt.putInt("tox", d.getInt("tox") >= 2 ? d.getInt("tox") : 0);   // горечь пропекается, яд — нет
                nbt.putLong("born", Math.floorDiv(now, Clock.HOUR) * Clock.HOUR);
                nbt.putLong("cooked", now);
            });
            out.set(DataComponentTypes.ITEM_NAME, Text.literal(pieName(d.getInt("cat"))));
            Skills.addXp(p, PzSkill.COOKING, 10f);
            world.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_SMOKER_SMOKE, SoundCategory.PLAYERS, 1f, 1f);
            p.sendMessage(Text.literal("Пирог испёкся! Пахнет как дома").formatted(Formatting.GREEN), true);
            return out;
        }
    }

    static String pieName(int cat) {
        if ((cat & FRUIT) != 0 && (cat & (MEAT | FISH | VEG | MUSHROOM)) == 0) return "Ягодный пирог";
        if ((cat & MEAT) != 0) return "Мясной пирог";
        if ((cat & FISH) != 0) return "Рыбный пирог";
        if ((cat & MUSHROOM) != 0) return "Пирог с грибами";
        if ((cat & CABBAGE) != 0) return "Пирог с капустой";
        if ((cat & DAIRY) != 0 && (cat & VEG) == 0) return "Сырный пирог";
        return "Овощной пирог";
    }

    /** Пирог: несколько кусков по 5 сытости. Свежий и тёплый — праздник посреди конца света. */
    static class Pie extends Item {
        Pie(Settings s) {
            super(s);
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            if (!user.canConsume(false)) return TypedActionResult.fail(user.getStackInHand(hand));
            user.setCurrentHand(hand);
            return TypedActionResult.consume(user.getStackInHand(hand));
        }

        @Override
        public UseAction getUseAction(ItemStack stack) {
            return UseAction.EAT;
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            return 32;
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (world.isClient || !(user instanceof ServerPlayerEntity p)) return stack;
            NbtCompound d = data(stack);
            float n = d.getFloat("n"), s = d.getFloat("s");
            float slice = Math.min(n, 5f), sat = n > 0 ? s * slice / n : 0;
            int food = Math.max(1, Math.round(slice));
            p.getHungerManager().add(food, sat / (2f * food));
            long now = Clock.now(world);
            int st = Food.state(stack, now);
            Mood m = Survival.mood(p);
            if (st == Food.FRESH) {
                boolean warm = now - d.getLong("cooked") < 3000;
                m.unhappy = Math.max(0f, m.unhappy - (warm ? 12f : 7f));
                m.boredom = Math.max(0f, m.boredom - (warm ? 10f : 5f));
                m.stress = Math.max(0f, m.stress - 4f);
                if (warm) p.sendMessage(Text.literal("Тёплый пирог... Почти как раньше").formatted(Formatting.GREEN), true);
            } else if (st == Food.ROTTEN) {
                m.foodSick = Math.min(100f, m.foodSick + 25f);
                p.sendMessage(Text.literal("Пирог испортился...").formatted(Formatting.RED), true);
            }
            tasty(p, d.getInt("sp"), 0.5f);
            Forage.poison(p, d.getInt("tox"), null);
            world.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GENERIC_EAT, SoundCategory.PLAYERS, 0.8f, 1f);
            float left = n - slice, sLeft = s - sat;
            if (left < 0.5f) return p.isCreative() ? stack : new ItemStack(PIE_DISH);
            NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack, nbt -> {
                nbt.putFloat("n", left);
                nbt.putFloat("s", sLeft);
            });
            return stack;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            NbtCompound d = data(stack);
            tooltip.add(Text.literal("Кусков: " + (int) Math.ceil(d.getFloat("n") / 5f) + " (сытость " + Math.round(d.getFloat("n")) + ")")
                    .formatted(Formatting.GRAY));
            if (d.contains("cat")) tooltip.add(Text.literal("Начинка: " + contents(d.getInt("cat"))).formatted(Formatting.DARK_GRAY));
        }
    }

    // =====================================================================================
    //                                 рецепты с переменным составом
    // =====================================================================================

    /** Разбор сетки: основа (миска/хлеб/форма+тесто), начинки и приправы. null — не подходит. */
    private record Parts(List<ItemStack> fill, int spice, int base, int dough) {}

    private static Parts parts(CraftingRecipeInput in, Item base, boolean needDough) {
        List<ItemStack> fill = new ArrayList<>();
        int spice = 0, b = 0, dough = 0;
        for (int i = 0; i < in.getSize(); i++) {
            ItemStack s = in.getStackInSlot(i);
            if (s.isEmpty()) continue;
            Item it = s.getItem();
            if (it == base) b++;
            else if (needDough && it == DOUGH) dough++;
            else if (spice(it)) spice++;
            else fill.add(s);
        }
        if (b != 1 || (needDough && dough != 1) || spice > 2) return null;
        return new Parts(fill, spice, b, dough);
    }

    /** Сытость и состав начинок. */
    private static float[] sum(List<ItemStack> fill, int[] catTox) {
        float n = 0, s = 0;
        int cat = 0, tox = 0;
        for (ItemStack f : fill) {
            FoodComponent fc = f.get(DataComponentTypes.FOOD);
            if (fc != null) {
                n += fc.nutrition();
                s += fc.saturation();
            }
            cat |= category(f.getItem());
            tox = Math.max(tox, toxicity(f));
        }
        catTox[0] = cat;
        catTox[1] = tox;
        return new float[]{n, s};
    }

    private static ItemStack dish(Item item, float n, float s, int cat, int tox, int spice, String name, Item convertsTo) {
        ItemStack out = new ItemStack(item);
        int nut = Math.max(1, Math.min(20, Math.round(n)));
        FoodComponent.Builder b = new FoodComponent.Builder().nutrition(nut).saturationModifier(n > 0 ? Math.min(1.2f, s / (2f * n)) : 0.3f);
        if (convertsTo != null) b.usingConvertsTo(convertsTo);
        out.set(DataComponentTypes.FOOD, b.build());
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, out, nbt -> {
            nbt.putInt("cat", cat);
            nbt.putInt("tox", tox);
            nbt.putInt("sp", spice);
        });
        out.set(DataComponentTypes.ITEM_NAME, Text.literal(name));
        return out;
    }

    public static class SaladRecipe extends SpecialCraftingRecipe {
        public SaladRecipe(CraftingRecipeCategory c) {
            super(c);
        }

        static boolean ok(ItemStack s) {
            int c = category(s.getItem());
            if (s.getItem() == Forage.NETTLE) return false;                         // сырая крапива жжётся
            return s.contains(DataComponentTypes.FOOD) && (c & (VEG | FRUIT | MUSHROOM | DAIRY | MEAT | FISH)) != 0 && !raw(s.getItem());
        }

        @Override
        public boolean matches(CraftingRecipeInput in, World world) {
            Parts p = parts(in, Items.BOWL, false);
            if (p == null || p.fill().size() < 2 || p.fill().size() > 4) return false;
            for (ItemStack f : p.fill()) if (!ok(f)) return false;
            return true;
        }

        @Override
        public ItemStack craft(CraftingRecipeInput in, RegistryWrapper.WrapperLookup lookup) {
            Parts p = parts(in, Items.BOWL, false);
            if (p == null) return ItemStack.EMPTY;
            int[] ct = new int[2];
            float[] ns = sum(p.fill(), ct);
            int cat = ct[0];
            String name = (cat & ~FRUIT) == 0 ? "Фруктовый салат" : (cat & MUSHROOM) != 0 ? "Салат с грибами"
                    : (cat & (MEAT | FISH)) != 0 ? "Сытный салат" : "Овощной салат";
            return dish(SALAD, ns[0] * 1.15f + p.spice(), ns[1] * 1.15f + p.spice(), cat, ct[1], p.spice(), name, Items.BOWL);
        }

        @Override
        public boolean fits(int width, int height) {
            return width * height >= 3;
        }

        @Override
        public ItemStack getResult(RegistryWrapper.WrapperLookup lookup) {
            return new ItemStack(SALAD);
        }

        @Override
        public RecipeSerializer<?> getSerializer() {
            return SALAD_RECIPE;
        }
    }

    public static class SandwichRecipe extends SpecialCraftingRecipe {
        public SandwichRecipe(CraftingRecipeCategory c) {
            super(c);
        }

        static boolean ok(ItemStack s) {
            int c = category(s.getItem());
            return s.contains(DataComponentTypes.FOOD) && c != 0 && c != GRAIN && !raw(s.getItem()) && s.getItem() != Forage.NETTLE;
        }

        @Override
        public boolean matches(CraftingRecipeInput in, World world) {
            Parts p = parts(in, Items.BREAD, false);
            if (p == null || p.fill().isEmpty() || p.fill().size() > 3) return false;
            for (ItemStack f : p.fill()) if (!ok(f)) return false;
            return true;
        }

        @Override
        public ItemStack craft(CraftingRecipeInput in, RegistryWrapper.WrapperLookup lookup) {
            Parts p = parts(in, Items.BREAD, false);
            if (p == null) return ItemStack.EMPTY;
            int[] ct = new int[2];
            float[] ns = sum(p.fill(), ct);
            Set<String> names = new LinkedHashSet<>();
            for (ItemStack f : p.fill()) names.add(f.getName().getString().toLowerCase());
            return dish(SANDWICH, 5f + ns[0] * 1.1f + p.spice(), 6f + ns[1] * 1.1f, ct[0], ct[1], p.spice(),
                    "Бутерброд (" + String.join(", ", names) + ")", null);
        }

        @Override
        public boolean fits(int width, int height) {
            return width * height >= 2;
        }

        @Override
        public ItemStack getResult(RegistryWrapper.WrapperLookup lookup) {
            return new ItemStack(SANDWICH);
        }

        @Override
        public RecipeSerializer<?> getSerializer() {
            return SANDWICH_RECIPE;
        }
    }

    public static class PieRecipe extends SpecialCraftingRecipe {
        public PieRecipe(CraftingRecipeCategory c) {
            super(c);
        }

        static boolean ok(ItemStack s) {
            int c = category(s.getItem());
            return s.contains(DataComponentTypes.FOOD) && (c & (FRUIT | MEAT | FISH | VEG | MUSHROOM | DAIRY | CABBAGE)) != 0;
        }

        @Override
        public boolean matches(CraftingRecipeInput in, World world) {
            Parts p = parts(in, PIE_DISH, true);
            if (p == null || p.fill().isEmpty() || p.fill().size() > 3) return false;
            for (ItemStack f : p.fill()) if (!ok(f)) return false;
            return true;
        }

        @Override
        public ItemStack craft(CraftingRecipeInput in, RegistryWrapper.WrapperLookup lookup) {
            Parts p = parts(in, PIE_DISH, true);
            if (p == null) return ItemStack.EMPTY;
            int[] ct = new int[2];
            float[] ns = sum(p.fill(), ct);
            ItemStack out = new ItemStack(PIE_RAW);
            int cat = ct[0], tox = ct[1], sp = p.spice();
            NbtComponent.set(DataComponentTypes.CUSTOM_DATA, out, nbt -> {
                nbt.putFloat("n", ns[0]);
                nbt.putFloat("s", ns[1]);
                nbt.putInt("cat", cat);
                nbt.putInt("tox", tox);
                nbt.putInt("sp", sp);
            });
            out.set(DataComponentTypes.ITEM_NAME, Text.literal(pieName(cat) + " (сырой)"));
            return out;
        }

        @Override
        public boolean fits(int width, int height) {
            return width * height >= 3;
        }

        @Override
        public ItemStack getResult(RegistryWrapper.WrapperLookup lookup) {
            return new ItemStack(PIE_RAW);
        }

        @Override
        public RecipeSerializer<?> getSerializer() {
            return PIE_RECIPE;
        }
    }
}
