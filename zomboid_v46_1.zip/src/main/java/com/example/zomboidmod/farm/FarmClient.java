package com.example.zomboidmod.farm;

import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.client.render.RenderLayer;

/** Грядки рисуются с прозрачностью, как ванильные посевы. */
public final class FarmClient {
    private FarmClient() {
    }

    public static void init() {
        for (Farm.Crop c : Farm.Crop.values()) BlockRenderLayerMap.INSTANCE.putBlock(c.block, RenderLayer.getCutout());
        BlockRenderLayerMap.INSTANCE.putBlock(com.example.zomboidmod.metal.Metal.METAL_PLATE, RenderLayer.getCutout());
    }
}
