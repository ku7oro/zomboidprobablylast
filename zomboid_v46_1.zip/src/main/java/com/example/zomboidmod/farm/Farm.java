package com.example.zomboidmod.farm;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.media.Knowledge;
import com.example.zomboidmod.nature.Climate;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.block.FarmlandBlock;
import net.minecraft.block.MapColor;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AliasedBlockItem;
import net.minecraft.item.BoneMealItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.loot.context.LootContextParameterSet;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

import java.util.ArrayList;
import java.util.List;

/**
 * Огород (как в PZ): у каждой культуры свой сезон, грядки нужно поливать, урожай может поразить болезнь
 * (лечится средством от вредителей, а то перекинется на соседей). Навык земледелия — больше урожая.
 */
public final class Farm {
    private Farm() {
    }

    private static final int SP = 1, SU = 2, AU = 4, WI = 8;

    /** Культура: id, название, сезоны роста, скорость, еда (сытость, насыщение), урожай мин–макс, многолетняя. */
    public enum Crop {
        TOMATO("tomato", "томат", "Томат", SP | SU, 0.10f, 3, 0.35f, 3, 5, false),
        CABBAGE("cabbage", "капуста", "Капуста", SP | AU, 0.08f, 5, 0.45f, 1, 2, false),
        RADISH("radish", "редис", "Редис", SP | SU | AU, 0.20f, 2, 0.3f, 2, 4, false),
        BROCCOLI("broccoli", "брокколи", "Брокколи", SP | AU, 0.09f, 3, 0.5f, 1, 3, false),
        ONION("onion", "лук", "Лук", SP | SU | AU, 0.12f, 2, 0.25f, 2, 4, false),
        STRAWBERRY("strawberry", "клубника", "Клубника", SP | SU, 0.11f, 1, 0.3f, 3, 6, true),
        BELL_PEPPER("bell_pepper", "болгарский перец", "Болгарский перец", SU, 0.09f, 3, 0.4f, 2, 4, false),
        ZUCCHINI("zucchini", "кабачок", "Кабачок", SU, 0.13f, 3, 0.4f, 1, 3, false);

        public final String id, genitive, title;
        public final int seasons, food, min, max;
        public final float speed, sat;
        public final boolean perennial;
        public PzCropBlock block;
        public Item seeds, produce;

        Crop(String id, String genitive, String title, int seasons, float speed, int food, float sat, int min, int max, boolean perennial) {
            this.id = id;
            this.genitive = genitive;
            this.title = title;
            this.seasons = seasons;
            this.speed = speed;
            this.food = food;
            this.sat = sat;
            this.min = min;
            this.max = max;
            this.perennial = perennial;
        }

        public boolean inSeason(World w) {
            return (seasons & seasonBit(w)) != 0;
        }

        String seasonText() {
            List<String> s = new ArrayList<>();
            if ((seasons & SP) != 0) s.add("весна");
            if ((seasons & SU) != 0) s.add("лето");
            if ((seasons & AU) != 0) s.add("осень");
            return String.join(", ", s);
        }
    }

    static int seasonBit(World w) {
        return switch (Climate.season(w).name()) {
            case "SPRING" -> SP;
            case "SUMMER" -> SU;
            case "AUTUMN" -> AU;
            default -> WI;
        };
    }

    public static Item WATERING_CAN, FERTILIZER, PESTICIDE;
    public static final List<Item> ITEMS = new ArrayList<>();

    private static Item reg(String id, Item item) {
        Item it = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
        ITEMS.add(it);
        return it;
    }

    public static void register() {
        for (Crop c : Crop.values()) {
            c.block = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, "crop_" + c.id),
                    new PzCropBlock(AbstractBlock.Settings.create().mapColor(MapColor.DARK_GREEN).noCollision().ticksRandomly()
                            .breakInstantly().sounds(BlockSoundGroup.CROP).pistonBehavior(PistonBehavior.DESTROY), c));
            c.seeds = reg("seeds_" + c.id, new Seeds(c.block, new Item.Settings(), c));
            c.produce = reg(c.id, new Item(new Item.Settings().food(new FoodComponent.Builder().nutrition(c.food).saturationModifier(c.sat).build())));
        }
        WATERING_CAN = reg("watering_can", new WateringCan(new Item.Settings().maxDamage(20)));
        FERTILIZER = reg("fertilizer", new Fertilizer(new Item.Settings().maxCount(16)));
        PESTICIDE = reg("pesticide", new Pesticide(new Item.Settings().maxDamage(8)));
        Knowledge.gate(FERTILIZER, "garden", PzSkill.FARMING, 3);
        Knowledge.gate(PESTICIDE, "garden", PzSkill.FARMING, 2);
        float[][] life = {{5, 9}, {10, 16}, {7, 12}, {5, 9}, {30, 60}, {2, 4}, {6, 10}, {7, 12}};
        for (Crop c : Crop.values()) com.example.zomboidmod.survival.Food.perish(c.produce, life[c.ordinal()][0], life[c.ordinal()][1]);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.NATURAL).register(e -> ITEMS.forEach(e::add));
    }

    /** Случайная культура для заброшенных огородов при генерации мира. */
    public static CropBlock randomCrop(Random r) {
        Crop[] v = Crop.values();
        return v[r.nextInt(v.length)].block;
    }

    // =====================================================================================
    //                                        грядка
    // =====================================================================================

    public static class PzCropBlock extends CropBlock {
        public static final IntProperty AGE = Properties.AGE_3;
        public static final BooleanProperty BLIGHT = BooleanProperty.of("blight");
        private static final VoxelShape[] SHAPES = {
                Block.createCuboidShape(0, 0, 0, 16, 4, 16), Block.createCuboidShape(0, 0, 0, 16, 7, 16),
                Block.createCuboidShape(0, 0, 0, 16, 10, 16), Block.createCuboidShape(0, 0, 0, 16, 13, 16)};
        public final Crop crop;

        PzCropBlock(Settings s, Crop crop) {
            super(s);
            this.crop = crop;
            setDefaultState(getDefaultState().with(AGE, 0).with(BLIGHT, false));
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(AGE, BLIGHT);
        }

        @Override
        protected IntProperty getAgeProperty() {
            return AGE;
        }

        @Override
        public int getMaxAge() {
            return 3;
        }

        @Override
        protected ItemConvertible getSeedsItem() {
            return crop.seeds != null ? crop.seeds : net.minecraft.item.Items.WHEAT_SEEDS;
        }

        @Override
        protected int getGrowthAmount(World world) {
            return 1;
        }

        @Override
        protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            return SHAPES[Math.min(3, state.get(AGE))];
        }

        @Override
        public boolean hasRandomTicks(BlockState state) {
            return true;   // и зрелые: могут перезреть и сгнить
        }

        @Override
        public boolean isFertilizable(WorldView world, BlockPos pos, BlockState state) {
            return !isMature(state) && !state.get(BLIGHT);
        }

        @Override
        protected void randomTick(BlockState st, ServerWorld w, BlockPos pos, Random r) {
            if (w.getBaseLightLevel(pos, 0) < 9) return;
            BlockState soil = w.getBlockState(pos.down());
            int moist = soil.contains(FarmlandBlock.MOISTURE) ? soil.get(FarmlandBlock.MOISTURE) : 0;
            if (st.get(BLIGHT)) {
                if (r.nextFloat() < 0.15f) {          // болезнь перекидывается на соседние грядки
                    BlockPos n = pos.offset(Direction.Type.HORIZONTAL.random(r));
                    BlockState ns = w.getBlockState(n);
                    if (ns.getBlock() instanceof PzCropBlock && !ns.get(BLIGHT)) w.setBlockState(n, ns.with(BLIGHT, true), Block.NOTIFY_LISTENERS);
                }
                if (r.nextFloat() < 0.05f) {          // засохло на корню
                    w.setBlockState(pos, Blocks.AIR.getDefaultState());
                    w.spawnParticles(ParticleTypes.ASH, pos.getX() + 0.5, pos.getY() + 0.3, pos.getZ() + 0.5, 12, 0.3, 0.2, 0.3, 0.01);
                }
                return;
            }
            // гниль и тля: в дождь и на переувлажнённой земле чаще
            float sick = 0.006f * (w.hasRain(pos.up()) ? 2.5f : 1f);
            if (r.nextFloat() < sick) {
                w.setBlockState(pos, st.with(BLIGHT, true), Block.NOTIFY_LISTENERS);
                return;
            }
            if (isMature(st)) {                       // перезрело на грядке — гниёт
                if (r.nextFloat() < 0.012f) w.setBlockState(pos, st.with(BLIGHT, true), Block.NOTIFY_LISTENERS);
                return;
            }
            float g = crop.speed;
            if (moist == 0) g *= 0.15f;               // сухая земля — почти не растёт
            if (!crop.inSeason(w)) g *= 0.35f;        // не сезон
            if (r.nextFloat() < g) w.setBlockState(pos, st.with(AGE, st.get(AGE) + 1), Block.NOTIFY_LISTENERS);
        }

        /** Урожай: зрелое — по навыку, больное — почти ничего, незрелое — вернуть семечко. */
        List<ItemStack> harvestDrops(BlockState st, Random r, ServerPlayerEntity p) {
            List<ItemStack> out = new ArrayList<>();
            boolean blight = st.get(BLIGHT);
            if (!isMature(st)) {
                if (!blight || r.nextBoolean()) out.add(new ItemStack(crop.seeds));
                return out;
            }
            int lvl = p != null ? Skills.level(p, PzSkill.FARMING) : 0;
            int n = crop.min + r.nextInt(crop.max - crop.min + 1) + lvl / 3;
            if (blight) n = r.nextInt(2);
            if (n > 0) out.add(new ItemStack(crop.produce, n));
            if (!crop.perennial && !blight && r.nextFloat() < 0.4f + 0.04f * lvl) out.add(new ItemStack(crop.seeds, 1 + (r.nextFloat() < 0.25f ? 1 : 0)));
            return out;
        }

        @Override
        protected List<ItemStack> getDroppedStacks(BlockState state, LootContextParameterSet.Builder builder) {
            Entity e = builder.getOptional(LootContextParameters.THIS_ENTITY);
            return harvestDrops(state, builder.getWorld().getRandom(), e instanceof ServerPlayerEntity sp ? sp : null);
        }

        @Override
        protected ItemActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
            Item it = stack.getItem();
            if (it instanceof WateringCan || it instanceof Fertilizer || it instanceof Pesticide) return ItemActionResult.SKIP_DEFAULT_BLOCK_INTERACTION;
            return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        /** ПКМ по зрелому — собрать (клубника отрастает снова). */
        @Override
        protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
            if (!isMature(state)) {
                if (state.get(BLIGHT) && !world.isClient) player.sendMessage(Text.literal("Растение поражено болезнью: нужно средство от вредителей")
                        .formatted(Formatting.GOLD), true);
                return ActionResult.PASS;
            }
            if (world.isClient) return ActionResult.SUCCESS;
            ServerPlayerEntity sp = player instanceof ServerPlayerEntity s ? s : null;
            List<ItemStack> drops = harvestDrops(state, world.getRandom(), sp);
            for (ItemStack d : drops) Block.dropStack(world, pos, d);
            if (crop.perennial && !state.get(BLIGHT)) world.setBlockState(pos, state.with(AGE, 1), Block.NOTIFY_LISTENERS);
            else world.setBlockState(pos, Blocks.AIR.getDefaultState());
            world.playSound(null, pos, SoundEvents.BLOCK_SWEET_BERRY_BUSH_PICK_BERRIES, SoundCategory.BLOCKS, 0.8f, 0.9f + world.random.nextFloat() * 0.2f);
            if (sp != null) {
                Skills.addXp(sp, PzSkill.FARMING, state.get(BLIGHT) ? 1f : 5f);
                if (state.get(BLIGHT)) sp.sendMessage(Text.literal("Урожай погубила болезнь...").formatted(Formatting.GRAY), true);
            }
            return ActionResult.CONSUME;
        }
    }

    // =====================================================================================
    //                                       предметы
    // =====================================================================================

    static class Seeds extends AliasedBlockItem {
        final Crop crop;

        Seeds(Block b, Settings s, Crop crop) {
            super(b, s);
            this.crop = crop;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal("Сажать на вспаханную землю. Растёт: " + crop.seasonText()).formatted(Formatting.GRAY));
            if (crop.perennial) tooltip.add(Text.literal("Многолетняя: после сбора отрастает снова").formatted(Formatting.DARK_GREEN));
            tooltip.add(Text.literal("Поливайте лейкой, берегите от болезней").formatted(Formatting.DARK_GRAY));
        }
    }

    /** Лейка: набрать в водоёме (ПКМ по воде), полить грядки 3×3. */
    public static class WateringCan extends Item {
        WateringCan(Settings s) {
            super(s);
        }

        static int water(ItemStack s) {
            return s.getMaxDamage() - s.getDamage();
        }

        @Override
        public boolean isEnchantable(ItemStack stack) {
            return false;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal("Воды: " + water(stack) + "/" + stack.getMaxDamage()).formatted(Formatting.AQUA));
            tooltip.add(Text.literal("ПКМ по воде — набрать, по грядке — полить 3×3").formatted(Formatting.GRAY));
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            BlockHitResult hit = raycast(world, user, RaycastContext.FluidHandling.SOURCE_ONLY);
            if (hit.getType() != HitResult.Type.BLOCK || !world.getFluidState(hit.getBlockPos()).isIn(net.minecraft.registry.tag.FluidTags.WATER))
                return TypedActionResult.pass(st);
            if (st.getDamage() == 0) return TypedActionResult.pass(st);
            if (!world.isClient) {
                st.setDamage(0);
                world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_BUCKET_FILL, SoundCategory.PLAYERS, 0.8f, 1.2f);
                user.sendMessage(Text.literal("Лейка полна").formatted(Formatting.AQUA), true);
            }
            return TypedActionResult.success(st, world.isClient);
        }

        @Override
        public ActionResult useOnBlock(ItemUsageContext ctx) {
            World w = ctx.getWorld();
            BlockPos pos = ctx.getBlockPos();
            if (!w.getBlockState(pos).contains(FarmlandBlock.MOISTURE)) pos = pos.down();
            if (!w.getBlockState(pos).contains(FarmlandBlock.MOISTURE)) return ActionResult.PASS;
            ItemStack st = ctx.getStack();
            PlayerEntity p = ctx.getPlayer();
            if (water(st) <= 0) {
                if (!w.isClient && p != null) p.sendMessage(Text.literal("Лейка пуста: наберите воды (ПКМ по воде)").formatted(Formatting.GRAY), true);
                return ActionResult.FAIL;
            }
            if (w.isClient) return ActionResult.SUCCESS;
            int n = 0;
            for (BlockPos q : BlockPos.iterate(pos.add(-1, 0, -1), pos.add(1, 0, 1))) {
                BlockState s = w.getBlockState(q);
                if (!s.contains(FarmlandBlock.MOISTURE)) continue;
                w.setBlockState(q, s.with(FarmlandBlock.MOISTURE, FarmlandBlock.MAX_MOISTURE), Block.NOTIFY_LISTENERS);
                ((ServerWorld) w).spawnParticles(ParticleTypes.SPLASH, q.getX() + 0.5, q.getY() + 1.1, q.getZ() + 0.5, 6, 0.3, 0.05, 0.3, 0.05);
                n++;
            }
            if (n == 0) return ActionResult.PASS;
            if (p == null || !p.isCreative()) st.setDamage(st.getDamage() + 1);
            w.playSound(null, pos, SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.BLOCKS, 0.5f, 1.4f);
            if (p instanceof ServerPlayerEntity sp) Skills.addXp(sp, PzSkill.FARMING, 0.5f);
            return ActionResult.CONSUME;
        }
    }

    /** Удобрение: грядка подрастает. */
    public static class Fertilizer extends Item {
        Fertilizer(Settings s) {
            super(s);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal("ПКМ по растению — подрастёт. Больные растения не берёт").formatted(Formatting.GRAY));
        }

        @Override
        public ActionResult useOnBlock(ItemUsageContext ctx) {
            World w = ctx.getWorld();
            BlockPos pos = ctx.getBlockPos();
            BlockState st = w.getBlockState(pos);
            if (st.getBlock() instanceof PzCropBlock c && st.get(PzCropBlock.BLIGHT)) {
                if (!w.isClient && ctx.getPlayer() != null)
                    ctx.getPlayer().sendMessage(Text.literal("Сначала вылечите растение от болезни").formatted(Formatting.GRAY), true);
                return ActionResult.FAIL;
            }
            ItemStack copy = ctx.getStack();
            if (!BoneMealItem.useOnFertilizable(copy, w, pos)) return ActionResult.PASS;
            if (!w.isClient) {
                BlockState after = w.getBlockState(pos);
                if (after.getBlock() instanceof PzCropBlock c && !c.isMature(after) && w.random.nextFloat() < 0.35f)
                    w.setBlockState(pos, after.with(PzCropBlock.AGE, after.get(PzCropBlock.AGE) + 1), Block.NOTIFY_LISTENERS);
                w.syncWorldEvent(net.minecraft.world.WorldEvents.BONE_MEAL_USED, pos, 15);
                if (ctx.getPlayer() instanceof ServerPlayerEntity sp) Skills.addXp(sp, PzSkill.FARMING, 1f);
            }
            return ActionResult.success(w.isClient);
        }
    }

    /** Средство от вредителей (настой чеснока и крапивы): лечит больные растения 3×3. */
    public static class Pesticide extends Item {
        Pesticide(Settings s) {
            super(s);
        }

        @Override
        public boolean isEnchantable(ItemStack stack) {
            return false;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal("ПКМ по больной грядке — вылечить растения вокруг (3×3)").formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Осталось: " + (stack.getMaxDamage() - stack.getDamage())).formatted(Formatting.DARK_GRAY));
        }

        @Override
        public ActionResult useOnBlock(ItemUsageContext ctx) {
            World w = ctx.getWorld();
            BlockPos pos = ctx.getBlockPos();
            if (w.isClient) return w.getBlockState(pos).getBlock() instanceof PzCropBlock ? ActionResult.SUCCESS : ActionResult.PASS;
            int n = 0;
            for (BlockPos q : BlockPos.iterate(pos.add(-1, -1, -1), pos.add(1, 1, 1))) {
                BlockState s = w.getBlockState(q);
                if (s.getBlock() instanceof PzCropBlock && s.get(PzCropBlock.BLIGHT)) {
                    w.setBlockState(q, s.with(PzCropBlock.BLIGHT, false), Block.NOTIFY_LISTENERS);
                    n++;
                }
                if (s.getBlock() instanceof PzCropBlock)
                    ((ServerWorld) w).spawnParticles(ParticleTypes.CLOUD, q.getX() + 0.5, q.getY() + 0.6, q.getZ() + 0.5, 3, 0.25, 0.15, 0.25, 0.01);
            }
            PlayerEntity p = ctx.getPlayer();
            w.playSound(null, pos, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.35f, 1.8f);
            if (n == 0) {
                if (p != null) p.sendMessage(Text.literal("Здесь нечего лечить").formatted(Formatting.GRAY), true);
                return ActionResult.CONSUME;
            }
            ItemStack st = ctx.getStack();
            if (p == null || !p.isCreative()) {
                st.setDamage(st.getDamage() + 1);
                if (st.getDamage() >= st.getMaxDamage()) st.decrement(1);
            }
            if (p instanceof ServerPlayerEntity sp) {
                Skills.addXp(sp, PzSkill.FARMING, 2f * n);
                sp.sendMessage(Text.literal("Вылечено растений: " + n).formatted(Formatting.GREEN), true);
            }
            return ActionResult.CONSUME;
        }
    }
}
