package com.example.zomboidmod.hunting;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SnowBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Оставить след: на мягкой земле — отпечатки, в тонком снегу — продавленный снег, кровь — на чём угодно. */
public final class Tracks {
    public static final int DEER = 0, BOAR = 1, RABBIT = 2, BIRD = 3, HUMAN = 4, BLOOD = 5;
    public static Block TRACKS;

    private Tracks() {
    }

    private static boolean soft(BlockState s) {
        return s.isOf(Blocks.GRASS_BLOCK) || s.isOf(Blocks.DIRT) || s.isOf(Blocks.COARSE_DIRT) || s.isOf(Blocks.PODZOL)
                || s.isOf(Blocks.MUD) || s.isOf(Blocks.SAND) || s.isOf(Blocks.RED_SAND) || s.isOf(Blocks.ROOTED_DIRT)
                || s.isOf(Blocks.MYCELIUM) || s.isOf(Blocks.SNOW_BLOCK) || s.isOf(Blocks.CLAY) || s.isOf(Blocks.MOSS_BLOCK);
    }

    public static void leave(ServerWorld w, BlockPos feet, int kind, Direction facing) {
        if (TRACKS == null || facing.getAxis().isVertical()) return;
        BlockState at = w.getBlockState(feet);
        BlockState mark = TRACKS.getDefaultState().with(TracksBlock.KIND, kind).with(TracksBlock.FACING, facing);
        if (at.isOf(Blocks.SNOW) && at.get(SnowBlock.LAYERS) == 1) {
            w.setBlockState(feet, mark.with(TracksBlock.SNOW, true), Block.NOTIFY_LISTENERS);
        } else if (at.isOf(TRACKS)) {
            if (kind == BLOOD || at.get(TracksBlock.KIND) != BLOOD)   // свежий след поверх старого
                w.setBlockState(feet, at.with(TracksBlock.KIND, kind).with(TracksBlock.AGE, 0).with(TracksBlock.FACING, facing), Block.NOTIFY_LISTENERS);
        } else if (at.isAir() && kind != HUMAN) {
            BlockPos below = feet.down();
            BlockState b = w.getBlockState(below);
            if (!b.isSideSolidFullSquare(w, below, Direction.UP)) return;
            if (kind != BLOOD && !soft(b)) return;
            w.setBlockState(feet, mark, Block.NOTIFY_LISTENERS);
        }
    }
}
