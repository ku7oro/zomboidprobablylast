package com.example.zomboidmod.hunting;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

/**
 * Следы на земле и в снегу (олень, кабан, кролик, птица, человек) и капли крови раненого зверя.
 * Со временем выветриваются; в снегу держатся дольше. По ним можно выследить добычу.
 */
public class TracksBlock extends Block {
    public static final IntProperty KIND = IntProperty.of("kind", 0, 5);
    public static final IntProperty AGE = IntProperty.of("age", 0, 3);
    public static final BooleanProperty SNOW = BooleanProperty.of("snow");
    public static final DirectionProperty FACING = Properties.HORIZONTAL_FACING;
    private static final VoxelShape GROUND = Block.createCuboidShape(0, 0, 0, 16, 0.25, 16);
    private static final VoxelShape SNOW_SHAPE = Block.createCuboidShape(0, 0, 0, 16, 2, 16);

    public TracksBlock(Settings settings) {
        super(settings);
        setDefaultState(getDefaultState().with(KIND, 0).with(AGE, 0).with(SNOW, false).with(FACING, Direction.NORTH));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(KIND, AGE, SNOW, FACING);
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return state.get(SNOW) ? SNOW_SHAPE : GROUND;
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return VoxelShapes.empty();
    }

    @Override
    protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        BlockPos below = pos.down();
        return world.getBlockState(below).isSideSolidFullSquare(world, below, Direction.UP);
    }

    @Override
    protected BlockState getStateForNeighborUpdate(BlockState state, Direction direction, BlockState neighborState, WorldAccess world,
                                                   BlockPos pos, BlockPos neighborPos) {
        if (direction == Direction.DOWN && !canPlaceAt(state, world, pos)) return Blocks.AIR.getDefaultState();
        return super.getStateForNeighborUpdate(state, direction, neighborState, world, pos, neighborPos);
    }

    /** Следы стареют и исчезают; в снегу — вдвое медленнее и остаётся ровный снег. */
    @Override
    protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        boolean snow = state.get(SNOW);
        if (snow && random.nextBoolean()) return;
        int age = state.get(AGE);
        if (age < 3) world.setBlockState(pos, state.with(AGE, age + 1), Block.NOTIFY_LISTENERS);
        else world.setBlockState(pos, snow ? Blocks.SNOW.getDefaultState() : Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
    }

    @Override
    protected BlockState rotate(BlockState state, BlockRotation rotation) {
        return state.with(FACING, rotation.rotate(state.get(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, BlockMirror mirror) {
        return state.rotate(mirror.getRotation(state.get(FACING)));
    }
}
