package com.example.zomboidmod.hunting;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.Waterloggable;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

/** Ловушка: ПКМ едой — положить приманку, ПКМ — посмотреть/забрать улов. Верша ставится только в воду. */
public class TrapBlock extends Block implements BlockEntityProvider, Waterloggable {
    public static final IntProperty CAUGHT = IntProperty.of("caught", 0, 11);
    public static final BooleanProperty BAITED = BooleanProperty.of("baited");
    public static final DirectionProperty FACING = Properties.HORIZONTAL_FACING;
    public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
    public final Traps.Kind kind;
    private final VoxelShape shape;

    public TrapBlock(Traps.Kind kind, Settings settings) {
        super(settings);
        this.kind = kind;
        this.shape = switch (kind) {
            case SNARE -> Block.createCuboidShape(3, 0, 3, 13, 6, 13);
            case STICK -> Block.createCuboidShape(2, 0, 2, 14, 9, 14);
            case BOX -> Block.createCuboidShape(1, 0, 3, 15, 10, 13);
            case CAGE -> Block.createCuboidShape(1, 0, 3.5, 15, 9, 12.5);
            case MOUSE -> Block.createCuboidShape(5, 0, 3, 11, 2, 13);
            case FISH -> Block.createCuboidShape(2, 0, 2, 14, 10, 14);
        };
        setDefaultState(getDefaultState().with(CAUGHT, 0).with(BAITED, false).with(FACING, Direction.NORTH).with(WATERLOGGED, false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(CAUGHT, BAITED, FACING, WATERLOGGED);
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return shape;
    }

    @Override
    public @Nullable BlockState getPlacementState(ItemPlacementContext ctx) {
        FluidState f = ctx.getWorld().getFluidState(ctx.getBlockPos());
        boolean water = f.getFluid() == Fluids.WATER && f.isStill();
        if (kind.water != water) return null;                    // верша — в воду, остальное — на сушу
        return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite()).with(WATERLOGGED, water);
    }

    @Override
    protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        BlockPos below = pos.down();
        return world.getBlockState(below).isSideSolidFullSquare(world, below, Direction.UP);
    }

    @Override
    protected FluidState getFluidState(BlockState state) {
        return state.get(WATERLOGGED) ? Fluids.WATER.getStill(false) : super.getFluidState(state);
    }

    @Override
    protected BlockState getStateForNeighborUpdate(BlockState state, Direction direction, BlockState neighborState, WorldAccess world,
                                                   BlockPos pos, BlockPos neighborPos) {
        if (state.get(WATERLOGGED)) world.scheduleFluidTick(pos, Fluids.WATER, Fluids.WATER.getTickRate(world));
        if (direction == Direction.DOWN && !canPlaceAt(state, world, pos))
            return state.get(WATERLOGGED) ? Blocks.WATER.getDefaultState() : Blocks.AIR.getDefaultState();
        return super.getStateForNeighborUpdate(state, direction, neighborState, world, pos, neighborPos);
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack itemStack) {
        super.onPlaced(world, pos, state, placer, itemStack);
        if (!world.isClient && placer instanceof ServerPlayerEntity sp && world.getBlockEntity(pos) instanceof TrapBlockEntity be)
            be.placed(world, Skills.level(sp, kind.skill));
    }

    @Override
    protected ItemActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand,
                                             BlockHitResult hit) {
        if (state.get(CAUGHT) > 0) {
            if (!world.isClient) collect(state, world, pos, player);
            return ItemActionResult.success(world.isClient);
        }
        if (!Traps.isBait(kind, stack.getItem())) return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (!world.isClient && world.getBlockEntity(pos) instanceof TrapBlockEntity be) {
            be.setBait(world, stack.copyWithCount(1));
            stack.decrementUnlessCreative(1, player);
            world.setBlockState(pos, state.with(BAITED, true), Block.NOTIFY_ALL);
            world.playSound(null, pos, SoundEvents.ITEM_BUNDLE_INSERT, SoundCategory.BLOCKS, 0.6f, 1f);
            player.sendMessage(Text.literal(kind.title + ": приманка — " + stack.getItem().getName().getString()
                    + (kind.water ? "" : ". Отойдите подальше: звери сторонятся людей")).formatted(Formatting.GRAY), true);
        }
        return ItemActionResult.success(world.isClient);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (state.get(CAUGHT) > 0) {
            if (!world.isClient) collect(state, world, pos, player);
            return ActionResult.success(world.isClient);
        }
        if (!world.isClient && world.getBlockEntity(pos) instanceof TrapBlockEntity be) {
            String msg = be.bait().isEmpty()
                    ? kind.title + ": пусто, без приманки. Подойдёт: " + Traps.baitHint(kind)
                    : kind.title + ": ждёт добычу (приманка — " + be.bait().getItem().getName().getString() + (be.spoiled(world) ? ", испортилась" : "") + ")";
            player.sendMessage(Text.literal(msg).formatted(Formatting.GRAY), true);
        }
        return ActionResult.success(world.isClient);
    }

    private void collect(BlockState state, World world, BlockPos pos, PlayerEntity player) {
        Traps.Prey p = Traps.prey(state.get(CAUGHT));
        BlockState reset = state.with(CAUGHT, 0).with(BAITED, false);
        if (world.getBlockEntity(pos) instanceof TrapBlockEntity be) be.reset();
        if (p == null) {
            world.setBlockState(pos, reset, Block.NOTIFY_ALL);
            return;
        }
        player.getInventory().offerOrDrop(p.catchStack.get());
        int lv = 0;
        if (player instanceof ServerPlayerEntity sp) {
            lv = Skills.level(sp, kind.skill);
            Skills.addXp(sp, p.fish() ? PzSkill.FISHING : PzSkill.TRAPPING, p.xp * 1.5f);
        }
        player.sendMessage(Text.literal(kind.title + ": улов — " + p.title).formatted(Formatting.GRAY), true);
        world.playSound(null, pos, kind.water ? SoundEvents.ENTITY_FISH_SWIM : SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.BLOCKS, 0.7f, 1f);
        if (world.random.nextFloat() < kind.breakChance * Math.max(0.3f, 1f - 0.07f * lv)) {
            world.setBlockState(pos, state.get(WATERLOGGED) ? Blocks.WATER.getDefaultState() : Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
            world.playSound(null, pos, SoundEvents.BLOCK_WOOD_BREAK, SoundCategory.BLOCKS, 0.7f, 1.2f);
            player.sendMessage(Text.literal(kind.title + " сломалась, пока доставали добычу").formatted(Formatting.GRAY), true);
            return;
        }
        world.setBlockState(pos, reset, Block.NOTIFY_ALL);
    }

    @Override
    public @Nullable BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new TrapBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> @Nullable BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
        if (world.isClient) return null;
        return (w, p, s, be) -> {
            if (be instanceof TrapBlockEntity t) t.serverTick(w, p, s);
        };
    }

    @Override
    protected BlockState rotate(BlockState state, BlockRotation rotation) {
        return state.with(FACING, rotation.rotate(state.get(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, BlockMirror mirror) {
        return state.rotate(mirror.getRotation(state.get(FACING)));
    }
}
