package com.example.zomboidmod.hunting;

import com.example.zomboidmod.ZomboidMod;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.function.Supplier;

/** Добыча: что даёт туша крупного зверя и тушка мелкого (по навыку «Разделка»). */
public final class Game {
    private Game() {
    }

    /** Крупные звери: после смерти остаётся туша на земле, разделывают ножом (ПКМ несколько раз). */
    public enum Big {
        DEER("олень", "оленя", () -> com.example.zomboidmod.wildlife.Wildlife.VENISON, 10, 1, 3, 1, 8),
        BOAR("кабан", "кабана", () -> Items.PORKCHOP, 8, 1, 2, 2, 7),
        COW("корова", "коровы", () -> Items.BEEF, 14, 2, 4, 2, 12),
        PIG("свинья", "свиньи", () -> Items.PORKCHOP, 9, 1, 2, 3, 8),
        SHEEP("овца", "овцы", () -> Items.MUTTON, 7, 1, 2, 1, 7);

        public final String title, genitive;
        public final Supplier<Item> meat;
        public final int meatBase, hides, bones, fat, cuts;

        Big(String title, String genitive, Supplier<Item> meat, int meatBase, int hides, int bones, int fat, int cuts) {
            this.title = title;
            this.genitive = genitive;
            this.meat = meat;
            this.meatBase = meatBase;
            this.hides = hides;
            this.bones = bones;
            this.fat = fat;
            this.cuts = cuts;
        }

        public static Big of(int i) {
            Big[] a = values();
            return a[Math.floorMod(i, a.length)];
        }
    }

    /** Мелкая дичь: тушка-предмет, разделывают в руках (нужен нож в инвентаре). */
    public enum Small {
        RABBIT("Тушка кролика", () -> Items.RABBIT, 2, 3, 0.55f, 1, 0, 50, 6, 0x8A7560),
        SQUIRREL("Тушка белки", () -> HuntingItems.SMALL_GAME, 1, 1, 0.35f, 0, 0, 40, 5, 0x9A5A34),
        RACCOON("Тушка енота", () -> HuntingItems.SMALL_GAME, 2, 3, 0.6f, 1, 0, 60, 8, 0x6E6A66),
        BIRD("Тушка птички", () -> HuntingItems.BIRD_MEAT, 1, 1, 0f, 0, 2, 30, 4, 0x7A6448),
        MOUSE("Дохлая мышь", () -> HuntingItems.SMALL_GAME, 0, 1, 0f, 0, 0, 20, 2, 0x8C8580),
        RAT("Дохлая крыса", () -> HuntingItems.SMALL_GAME, 1, 1, 0f, 0, 0, 25, 3, 0x5E5650),
        TURKEY("Тушка индейки", () -> HuntingItems.TURKEY_MEAT, 3, 5, 0f, 1, 4, 70, 6, 0x5A4632);

        public final String title;
        public final Supplier<Item> meat;
        public final int meatMin, meatMax, bones, feathers, useTicks, xp, color;
        public final float hideChance;
        public Item carcass;

        Small(String title, Supplier<Item> meat, int meatMin, int meatMax, float hideChance, int bones, int feathers, int useTicks, int xp, int color) {
            this.title = title;
            this.meat = meat;
            this.meatMin = meatMin;
            this.meatMax = meatMax;
            this.hideChance = hideChance;
            this.bones = bones;
            this.feathers = feathers;
            this.useTicks = useTicks;
            this.xp = xp;
            this.color = color;
        }

        public ItemStack stack() {
            return new ItemStack(carcass);
        }
    }

    /** Чем можно разделывать и насколько хорошо (охотничий нож — лучше всего). */
    public static float knife(ItemStack s) {
        Item i = s.getItem();
        if (i == ZomboidMod.HUNTING_KNIFE) return 1.15f;
        if (i == ZomboidMod.MEAT_CLEAVER) return 1.1f;
        if (i == ZomboidMod.KITCHEN_KNIFE || i == ZomboidMod.COMBAT_KNIFE) return 1f;
        if (i == ZomboidMod.MACHETE) return 0.85f;
        return 0f;
    }
}
