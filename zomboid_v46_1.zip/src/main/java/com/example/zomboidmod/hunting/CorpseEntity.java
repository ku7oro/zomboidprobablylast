package com.example.zomboidmod.hunting;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.block.ZomboidBlocks;
import com.example.zomboidmod.survival.Clock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Туша крупного зверя на земле (как в PZ B42): лежит, пока её не разделают или пока не сгниёт.
 * Разделка — ПКМ ножом несколько раз: сначала шкура, потом мясо, в конце кости и жир.
 * Сколько выйдет — зависит от навыка «Разделка» и ножа. Мясо портится с момента смерти зверя.
 */
public class CorpseEntity extends Entity {
    private static final TrackedData<Integer> SPECIES = DataTracker.registerData(CorpseEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> CUTS = DataTracker.registerData(CorpseEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Float> ROT = DataTracker.registerData(CorpseEntity.class, TrackedDataHandlerRegistry.FLOAT);
    /** Время смерти (время суток мира, как у еды). */
    private long died = -1;
    /** Сколько осталось (считается при первом надрезе). */
    private int meat = -1, hides, bones, fat;

    public CorpseEntity(EntityType<? extends CorpseEntity> type, World world) {
        super(type, world);
    }

    public static void spawn(ServerWorld w, double x, double y, double z, float yaw, Game.Big species) {
        CorpseEntity c = new CorpseEntity(Hunting.CORPSE, w);
        c.refreshPositionAndAngles(x, y, z, yaw, 0f);
        c.setSpecies(species);
        c.died = Clock.now(w);
        w.spawnEntity(c);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(SPECIES, 0);
        builder.add(CUTS, 0);
        builder.add(ROT, 0f);
    }

    public Game.Big species() {
        return Game.Big.of(dataTracker.get(SPECIES));
    }

    public void setSpecies(Game.Big b) {
        dataTracker.set(SPECIES, b.ordinal());
    }

    public int cuts() {
        return dataTracker.get(CUTS);
    }

    /** 0 — свежая, 1 — сгнила совсем. */
    public float rot() {
        return dataTracker.get(ROT);
    }

    @Override
    public void tick() {
        super.tick();
        if (!hasNoGravity()) setVelocity(getVelocity().add(0, -0.04, 0));
        move(MovementType.SELF, getVelocity());
        setVelocity(getVelocity().multiply(isOnGround() ? 0.5 : 0.98, 0.98, isOnGround() ? 0.5 : 0.98));
        if (getWorld().isClient || age % 100 != 0) return;
        long now = Clock.now(getWorld());
        if (died < 0) died = now;
        float days = (now - died) / (float) Clock.DAY;
        dataTracker.set(ROT, Math.min(1f, Math.max(0f, (days - 1f) / 2.5f)));   // через сутки начинает портиться
        if (days > 5f) discard();                                                   // за пять дней от туши ничего не остаётся
    }

    @Override
    public boolean canHit() {
        return true;
    }

    @Override
    public boolean isCollidable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return false;
    }

    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        if (hand != Hand.MAIN_HAND) return ActionResult.PASS;
        ItemStack knife = player.getMainHandStack();
        float mult = Game.knife(knife);
        World w = getWorld();
        if (mult <= 0f) {
            if (w.isClient) player.sendMessage(Text.literal("Туша " + species().genitive + ". Чтобы разделать, возьмите в руку нож или тесак")
                    .formatted(Formatting.GRAY), true);
            return ActionResult.SUCCESS;
        }
        if (w.isClient) return ActionResult.SUCCESS;
        if (!(player instanceof ServerPlayerEntity sp) || player.getItemCooldownManager().isCoolingDown(knife.getItem())) return ActionResult.CONSUME;
        player.getItemCooldownManager().set(knife.getItem(), 8);
        cut(sp, knife, mult);
        return ActionResult.CONSUME;
    }

    private void cut(ServerPlayerEntity p, ItemStack knife, float mult) {
        ServerWorld w = p.getServerWorld();
        Game.Big g = species();
        int lv = Skills.level(p, PzSkill.BUTCHERING);
        var r = p.getRandom();
        if (meat < 0) {   // первый надрез: сколько удастся снять
            meat = Math.max(1, Math.round(g.meatBase * (0.55f + 0.045f * lv) * mult * (1f - rot() * 0.5f)));
            hides = 0;
            for (int i = 0; i < g.hides; i++) if (r.nextFloat() < 0.35f + 0.065f * lv + (mult > 1.1f ? 0.15f : 0f)) hides++;
            bones = g.bones;
            fat = Math.max(0, Math.round(g.fat * (0.5f + 0.05f * lv)));
        }
        int done = cuts() + 1;
        int total = Math.max(3, g.cuts - lv / 3);
        dataTracker.set(CUTS, done);
        long born = died < 0 ? -1 : died;
        if (done == 1) {
            if (hides > 0) {
                HuntingItems.give(p, HuntingItems.HIDE_LARGE, hides, -1);
                p.sendMessage(Text.literal("Шкура снята").formatted(Formatting.GRAY), true);
            } else if (g.hides > 0) {
                p.sendMessage(Text.literal("Шкура испорчена — не хватило умения").formatted(Formatting.GRAY), true);
            }
        } else if (done < total) {
            int left = total - done;                            // разрезов до конца (последний — кости)
            int piece = (int) Math.ceil(meat / (double) (left + 0));
            piece = Math.min(piece, meat);
            HuntingItems.give(p, g.meat.get(), piece, born);
            meat -= piece;
        }
        if (done >= total) {
            HuntingItems.give(p, g.meat.get(), meat, born);
            HuntingItems.give(p, Items.BONE, bones, -1);
            HuntingItems.give(p, HuntingItems.ANIMAL_FAT, fat, born);
            meat = 0;
            BlockPos at = getBlockPos();
            BlockState here = w.getBlockState(at);
            if (here.isAir() && w.getBlockState(at.down()).isSideSolidFullSquare(w, at.down(), net.minecraft.util.math.Direction.UP))
                w.setBlockState(at, ZomboidBlocks.BLOOD.getDefaultState().with(com.example.zomboidmod.block.DecalBlock.VARIANT, r.nextInt(4)));
            discard();
        }
        Skills.addXp(p, PzSkill.BUTCHERING, 3f);
        if (!p.isCreative()) knife.damage(1, p, net.minecraft.entity.EquipmentSlot.MAINHAND);
        w.playSound(null, getBlockPos(), SoundEvents.ENTITY_SHEEP_SHEAR, SoundCategory.PLAYERS, 0.7f, 0.6f + r.nextFloat() * 0.3f);
        w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.getDefaultState()),
                getX(), getY() + 0.4, getZ(), 8, 0.3, 0.15, 0.3, 0.05);
        Noise.emitAt(w, getBlockPos(), 4);
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        dataTracker.set(SPECIES, nbt.getInt("species"));
        dataTracker.set(CUTS, nbt.getInt("cuts"));
        died = nbt.contains("died") ? nbt.getLong("died") : -1;
        meat = nbt.contains("meat") ? nbt.getInt("meat") : -1;
        hides = nbt.getInt("hides");
        bones = nbt.getInt("bones");
        fat = nbt.getInt("fat");
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putInt("species", dataTracker.get(SPECIES));
        nbt.putInt("cuts", dataTracker.get(CUTS));
        nbt.putLong("died", died);
        nbt.putInt("meat", meat);
        nbt.putInt("hides", hides);
        nbt.putInt("bones", bones);
        nbt.putInt("fat", fat);
    }

    /** Мухи над гниющей тушей (клиент). */
    public Vec3d fliesAt() {
        return getPos().add(0, 0.6, 0);
    }
}
