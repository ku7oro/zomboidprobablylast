package com.example.zomboidmod.hunting;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.build.Carpentry;
import com.example.zomboidmod.survival.Clock;
import com.example.zomboidmod.survival.Food;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/** Предметы охоты: мясо, тушки, шкуры, рыба PZ, филе, червяки. */
public final class HuntingItems {
    public static Item TURKEY_MEAT, COOKED_TURKEY, SMALL_GAME, COOKED_SMALL_GAME, BIRD_MEAT, COOKED_BIRD_MEAT;
    public static Item FISH_FILLET, COOKED_FISH_FILLET, ANIMAL_FAT, HIDE_LARGE, HIDE_SMALL, WORM;
    public static final List<Item> FISH = new ArrayList<>();
    public static final List<Item> ALL = new ArrayList<>();

    private HuntingItems() {
    }

    /** Рыба Кентукки (виды из PZ): длина в см и «плотность» (вес = k · длина³). */
    public enum Fish {
        BLUEGILL("fish_bluegill", "Синежаберный солнечник", 10, 25, 2.0e-5),
        PERCH("fish_perch", "Жёлтый окунь", 12, 30, 1.2e-5),
        CRAPPIE("fish_crappie", "Белый краппи", 15, 35, 1.4e-5),
        LARGEMOUTH_BASS("fish_largemouth_bass", "Большеротый окунь", 25, 60, 1.5e-5),
        SMALLMOUTH_BASS("fish_smallmouth_bass", "Малоротый окунь", 20, 50, 1.4e-5),
        CHANNEL_CATFISH("fish_channel_catfish", "Канальный сомик", 30, 80, 1.1e-5),
        RAINBOW_TROUT("fish_rainbow_trout", "Радужная форель", 25, 60, 1.1e-5),
        WALLEYE("fish_walleye", "Судак", 30, 70, 1.0e-5),
        NORTHERN_PIKE("fish_northern_pike", "Щука", 40, 100, 0.7e-5),
        STRIPED_BASS("fish_striped_bass", "Полосатый лаврак", 40, 100, 1.2e-5),
        BLUE_CATFISH("fish_blue_catfish", "Голубой сом", 50, 140, 1.2e-5),
        MUSKELLUNGE("fish_muskellunge", "Маскинонг", 70, 150, 0.75e-5),
        CRAYFISH("crayfish", "Рак", 7, 14, 3.0e-5),
        BAIT_FISH("bait_fish", "Малёк", 4, 9, 1.0e-5);

        public final String id, title;
        public final int minLen, maxLen;
        public final double k;
        public Item item;

        Fish(String id, String title, int minLen, int maxLen, double k) {
            this.id = id;
            this.title = title;
            this.minLen = minLen;
            this.maxLen = maxLen;
            this.k = k;
        }
    }

    private static Item reg(String id, Item item) {
        Item i = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
        ALL.add(i);
        return i;
    }

    private static Item food(String id, int nutrition, float sat) {
        return reg(id, new Item(new Item.Settings().food(new FoodComponent.Builder().nutrition(nutrition).saturationModifier(sat).build())));
    }

    public static void register() {
        TURKEY_MEAT = food("turkey_meat", 2, 0.15f);
        COOKED_TURKEY = food("cooked_turkey", 7, 0.7f);
        SMALL_GAME = food("small_game", 1, 0.1f);
        COOKED_SMALL_GAME = food("cooked_small_game", 4, 0.5f);
        BIRD_MEAT = food("bird_meat", 1, 0.1f);
        COOKED_BIRD_MEAT = food("cooked_bird_meat", 3, 0.45f);
        FISH_FILLET = food("fish_fillet", 2, 0.1f);
        COOKED_FISH_FILLET = food("cooked_fish_fillet", 5, 0.6f);
        ANIMAL_FAT = food("animal_fat", 2, 0.25f);
        HIDE_LARGE = reg("hide_large", new Item(new Item.Settings().maxCount(16)));
        HIDE_SMALL = reg("hide_small", new Item(new Item.Settings().maxCount(32)));
        WORM = reg("worm", new Item(new Item.Settings()));
        for (Game.Small g : Game.Small.values())
            g.carcass = reg("carcass_" + g.name().toLowerCase(), new CarcassItem(g, new Item.Settings().maxCount(8)));
        for (Fish f : Fish.values()) {
            f.item = reg(f.id, new FishItem(f, new Item.Settings().maxCount(16)));
            FISH.add(f.item);
        }
        FuelRegistry.INSTANCE.add(ANIMAL_FAT, 400);   // жир горит в печи
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(e -> {
            for (Item i : ALL) e.add(i);
        });
    }

    /** Сроки свежести (дни, как у мяса и рыбы в PZ). Вызывается из Food.init. */
    public static void freshness(java.util.function.BiConsumer<Item, float[]> put) {
        for (Item i : new Item[]{TURKEY_MEAT, SMALL_GAME, BIRD_MEAT, FISH_FILLET}) put.accept(i, new float[]{2, 4});
        for (Item i : new Item[]{COOKED_TURKEY, COOKED_SMALL_GAME, COOKED_BIRD_MEAT, COOKED_FISH_FILLET}) put.accept(i, new float[]{3, 6});
        put.accept(ANIMAL_FAT, new float[]{10, 30});
        for (Game.Small g : Game.Small.values()) put.accept(g.carcass, new float[]{2, 4});
        for (Item i : FISH) put.accept(i, new float[]{2, 4});
    }

    public static boolean isCooked(Item i) {
        return i == COOKED_TURKEY || i == COOKED_SMALL_GAME || i == COOKED_BIRD_MEAT || i == COOKED_FISH_FILLET;
    }

    // =====================================================================================
    //                                  нож и выдача добычи
    // =====================================================================================

    /** Лучший нож в инвентаре (сначала в руках). */
    static ItemStack findKnife(PlayerEntity p) {
        if (Game.knife(p.getMainHandStack()) > 0) return p.getMainHandStack();
        if (Game.knife(p.getOffHandStack()) > 0) return p.getOffHandStack();
        ItemStack best = ItemStack.EMPTY;
        for (ItemStack s : p.getInventory().main) if (Game.knife(s) > Game.knife(best)) best = s;
        return best;
    }

    /** Выдать кусок добычи: мясо получает дату «рождения» (портится с момента смерти зверя). */
    static void give(PlayerEntity p, Item item, int count, long born) {
        if (item == null || count <= 0) return;
        ItemStack s = new ItemStack(item, count);
        if (born >= 0 && Food.perishable(s)) Food.setBorn(s, Math.floorDiv(born, Clock.HOUR) * Clock.HOUR);
        p.getInventory().offerOrDrop(s);
    }

    static long bornOf(ItemStack s) {
        return Food.stamped(s) ? Food.born(s) : -1L;
    }

    private static void useKnife(PlayerEntity user, ItemStack knife) {
        if (user instanceof ServerPlayerEntity sp && !sp.isCreative() && !knife.isEmpty())
            knife.damage(1, sp.getServerWorld(), sp, it -> {
            });
    }

    // =====================================================================================
    //                                       тушки
    // =====================================================================================

    /** Тушка мелкой дичи: зажми ПКМ (нужен нож в инвентаре) — разделать на мясо, шкурку, кости, перья. */
    public static class CarcassItem extends Item {
        final Game.Small game;

        CarcassItem(Game.Small game, Settings s) {
            super(s);
            this.game = game;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            if (findKnife(user).isEmpty()) {
                if (world.isClient) user.sendMessage(Text.literal("Чтобы разделать тушку, нужен нож или тесак").formatted(Formatting.GRAY), true);
                return TypedActionResult.fail(st);
            }
            user.setCurrentHand(hand);
            return TypedActionResult.consume(st);
        }

        @Override
        public UseAction getUseAction(ItemStack stack) {
            return UseAction.BRUSH;
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            int lv = user instanceof PlayerEntity p ? Carpentry.level(p, PzSkill.BUTCHERING) : 0;
            return Math.max(10, (int) (game.useTicks * (1f - 0.04f * lv)));
        }

        @Override
        public void usageTick(World world, LivingEntity user, ItemStack stack, int left) {
            if (!world.isClient && left % 10 == 0)
                world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_SHEEP_SHEAR, SoundCategory.PLAYERS, 0.4f, 0.7f + world.random.nextFloat() * 0.3f);
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (world.isClient || !(user instanceof ServerPlayerEntity p)) return stack;
            ItemStack knife = findKnife(p);
            if (knife.isEmpty()) return stack;
            long born = bornOf(stack);
            int lv = Skills.level(p, PzSkill.BUTCHERING);
            Random r = p.getRandom();
            float mult = Game.knife(knife);
            int meat = game.meatMin + r.nextInt(game.meatMax - game.meatMin + 1);
            if (r.nextFloat() < lv * 0.06f * mult) meat++;                 // умелый мясник срежет больше
            give(p, game.meat.get(), meat, born);
            if (game.hideChance > 0 && r.nextFloat() < game.hideChance + lv * 0.04f) give(p, HIDE_SMALL, 1, -1);
            if (game.bones > 0) give(p, Items.BONE, game.bones, -1);
            if (game.feathers > 0) give(p, Items.FEATHER, 1 + r.nextInt(game.feathers), -1);
            if (game == Game.Small.RABBIT && r.nextFloat() < 0.08f) give(p, Items.RABBIT_FOOT, 1, -1);
            Skills.addXp(p, PzSkill.BUTCHERING, 3f + game.xp * 0.5f);
            useKnife(p, knife);
            stack.decrementUnlessCreative(1, p);
            return stack;
        }

        @Override
        public void appendTooltip(ItemStack stack, Item.TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal("Зажмите ПКМ с ножом в инвентаре — разделать").formatted(Formatting.DARK_GRAY));
        }
    }

    // =====================================================================================
    //                                       рыба
    // =====================================================================================

    /** Рыба: у каждой своя длина и вес (крупнее — с навыком рыбалки); зажми ПКМ с ножом — разделать на филе. */
    public static class FishItem extends Item {
        final Fish fish;

        FishItem(Fish fish, Settings s) {
            super(s);
            this.fish = fish;
        }

        public static int length(ItemStack s) {
            NbtComponent c = s.get(DataComponentTypes.CUSTOM_DATA);
            return c == null ? 0 : c.copyNbt().getInt("len");
        }

        public double weight(ItemStack s) {
            int len = Math.max(length(s), (fish.minLen + fish.maxLen) / 2);
            return fish.k * len * len * len;
        }

        /** Размер по навыку, как в PZ: новичок ловит мелочь, мастер — трофеи. */
        static int rollLength(Fish f, int lvl, Random r) {
            float small = 95f - 8.5f * lvl;
            float big = lvl <= 5 ? 2.4f * lvl : 12f + 7.6f * (lvl - 5);
            float k = r.nextFloat() * 100f;
            float lo, hi;
            if (k < small) {
                lo = 0f;
                hi = 0.4f;
            } else if (k < 100f - big) {
                lo = 0.35f;
                hi = 0.75f;
            } else {
                lo = 0.7f;
                hi = 1f;
            }
            float t = lo + (hi - lo) * r.nextFloat();
            return Math.round(f.minLen + (f.maxLen - f.minLen) * t);
        }

        @Override
        public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
            if (world.isClient || length(stack) > 0) return;
            int lvl = entity instanceof ServerPlayerEntity sp ? Skills.level(sp, PzSkill.FISHING) : 0;
            int len = rollLength(fish, lvl, world.random);
            NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack, n -> n.putInt("len", len));
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            if (findKnife(user).isEmpty()) {
                if (world.isClient) user.sendMessage(Text.literal("Чтобы разделать рыбу, нужен нож").formatted(Formatting.GRAY), true);
                return TypedActionResult.fail(st);
            }
            user.setCurrentHand(hand);
            return TypedActionResult.consume(st);
        }

        @Override
        public UseAction getUseAction(ItemStack stack) {
            return UseAction.BRUSH;
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            return fish == Fish.CRAYFISH || fish == Fish.BAIT_FISH ? 12 : 30;
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (world.isClient || !(user instanceof ServerPlayerEntity p)) return stack;
            ItemStack knife = findKnife(p);
            if (knife.isEmpty()) return stack;
            double kg = weight(stack);
            int lv = Skills.level(p, PzSkill.BUTCHERING);
            int fillets = MathHelper.clamp((int) Math.round(kg * 3.5 * (0.85 + 0.03 * lv)), 1, 14);
            give(p, FISH_FILLET, fillets, bornOf(stack));
            int len = Math.max(length(stack), fish.minLen);
            Skills.addXp(p, PzSkill.BUTCHERING, 2f);
            Skills.addXp(p, PzSkill.FISHING, len * 0.15f);   // PZ: опыт рыбалки зависит от длины
            p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_COD_FLOP, SoundCategory.PLAYERS, 0.5f, 1f);
            useKnife(p, knife);
            stack.decrementUnlessCreative(1, p);
            return stack;
        }

        @Override
        public void appendTooltip(ItemStack stack, Item.TooltipContext context, List<Text> tooltip, TooltipType type) {
            int len = length(stack);
            if (len > 0) {
                double kg = fish.k * len * len * len;
                tooltip.add(Text.literal(String.format("Длина %d см · вес %.2f кг", len, kg)).formatted(Formatting.GRAY));
            }
            tooltip.add(Text.literal("Зажмите ПКМ с ножом в инвентаре — разделать на филе").formatted(Formatting.DARK_GRAY));
        }
    }

    static ServerWorld sw(World w) {
        return w instanceof ServerWorld s ? s : null;
    }
}
