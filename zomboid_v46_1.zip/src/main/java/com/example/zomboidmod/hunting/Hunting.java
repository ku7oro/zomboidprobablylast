package com.example.zomboidmod.hunting;

import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.passive.RabbitEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ShovelItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Охота и звери (по PZ B42): туши крупных зверей и разделка ножом, тушки мелкой дичи, ловушки с приманкой,
 * рыба Кентукки и верши, следы и кровь раненого зверя. Звери пугаются шума и чуют по ветру.
 */
public final class Hunting {
    public static EntityType<CorpseEntity> CORPSE;
    private static final List<Pending> PENDING = new ArrayList<>();

    private record Pending(ServerWorld w, double x, double y, double z, float yaw, Game.Big species, long at) {
    }

    private Hunting() {
    }

    public static void register() {
        HuntingItems.register();
        Traps.register();
        Tracks.TRACKS = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, "tracks"),
                new TracksBlock(AbstractBlock.Settings.create().breakInstantly().noCollision().nonOpaque().dropsNothing().ticksRandomly()
                        .replaceable().sounds(BlockSoundGroup.SNOW)));
        CORPSE = Registry.register(Registries.ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, "corpse"),
                EntityType.Builder.<CorpseEntity>create(CorpseEntity::new, SpawnGroup.MISC).dimensions(1.3f, 0.6f).maxTrackingRange(8).build("corpse"));

        // домашний скот: после смерти тоже остаётся туша (с задержкой, пока ванильное тело не исчезнет)
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity.getWorld() instanceof ServerWorld w)) return;
            Game.Big g = entity instanceof SheepEntity ? Game.Big.SHEEP : entity instanceof PigEntity ? Game.Big.PIG
                    : entity instanceof CowEntity ? Game.Big.COW : null;
            if (g == null || entity.isBaby()) return;
            PENDING.add(new Pending(w, entity.getX(), entity.getY(), entity.getZ(), entity.bodyYaw, g, w.getTime() + 19));
        });
        ServerTickEvents.END_SERVER_TICK.register(Hunting::tick);

        // червяки: копая землю лопатой, иногда находишь червя (приманка для птиц и рыбы)
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (world.isClient || player.isCreative()) return;
            if (!(state.isOf(Blocks.DIRT) || state.isOf(Blocks.GRASS_BLOCK) || state.isOf(Blocks.COARSE_DIRT) || state.isOf(Blocks.MUD)
                    || state.isOf(Blocks.ROOTED_DIRT) || state.isOf(Blocks.PODZOL))) return;
            ItemStack tool = player.getMainHandStack();
            float chance = tool.getItem() instanceof ShovelItem || tool.isOf(ZomboidMod.SHOVEL) ? 0.14f : 0.03f;
            if (world.isRaining()) chance *= 1.6f;                // в дождь черви вылезают
            if (world.random.nextFloat() < chance)
                net.minecraft.block.Block.dropStack(world, pos, new ItemStack(HuntingItems.WORM));
        });
    }

    private static void tick(MinecraftServer server) {
        if (!PENDING.isEmpty()) {
            Iterator<Pending> it = PENDING.iterator();
            while (it.hasNext()) {
                Pending p = it.next();
                if (p.w.getTime() < p.at) continue;
                it.remove();
                CorpseEntity.spawn(p.w, p.x, p.y, p.z, p.yaw, p.species);
            }
        }
        // кролики (ванильные) тоже оставляют следы
        if (server.getTicks() % 20 != 7) return;
        ServerWorld w = server.getOverworld();
        for (ServerPlayerEntity pl : w.getPlayers()) {
            for (RabbitEntity r : w.getEntitiesByClass(RabbitEntity.class, pl.getBoundingBox().expand(40), e -> e.isAlive() && e.isOnGround())) {
                if (r.getVelocity().horizontalLengthSquared() > 0.002 && w.random.nextFloat() < 0.4f)
                    Tracks.leave(w, r.getBlockPos(), Tracks.RABBIT, r.getHorizontalFacing());
            }
        }
    }

    /** Есть ли на этой позиции след (для подсказок). */
    public static boolean isTrack(BlockState s) {
        return s.isOf(Tracks.TRACKS);
    }

    static boolean near(BlockPos a, BlockPos b, int r) {
        return a.isWithinDistance(b, r);
    }
}
