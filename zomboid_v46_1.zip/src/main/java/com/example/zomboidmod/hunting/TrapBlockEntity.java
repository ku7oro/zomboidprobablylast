package com.example.zomboidmod.hunting;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Состояние ловушки: приманка (и когда положена), навык поставившего, когда последний раз проверяли. */
public class TrapBlockEntity extends BlockEntity {
    private static final long HOUR = 1000L, BAIT_LIFE = 3 * 24000L;
    private ItemStack bait = ItemStack.EMPTY;
    private long baitTime, lastCheck = Long.MIN_VALUE;
    private int skill;

    public TrapBlockEntity(BlockPos pos, BlockState state) {
        super(Traps.TRAP_BE, pos, state);
    }

    public ItemStack bait() {
        return bait;
    }

    void placed(World w, int skill) {
        this.skill = skill;
        lastCheck = w.getTimeOfDay();
        markDirty();
    }

    void setBait(World w, ItemStack s) {
        bait = s;
        baitTime = w.getTimeOfDay();
        lastCheck = w.getTimeOfDay();
        markDirty();
    }

    boolean spoiled(World w) {
        return !bait.isEmpty() && w.getTimeOfDay() - baitTime > BAIT_LIFE;
    }

    void reset() {
        bait = ItemStack.EMPTY;
        markDirty();
    }

    /** Раз в 5 секунд: прошедшие игровые часы — броски на улов (если рядом нет людей). */
    void serverTick(World world, BlockPos pos, BlockState state) {
        if (!(world instanceof ServerWorld w) || Math.floorMod(w.getTime() + pos.asLong(), 100L) != 0) return;
        long now = w.getTimeOfDay();
        if (lastCheck == Long.MIN_VALUE || now < lastCheck) {
            lastCheck = now;
            markDirty();
            return;
        }
        long hours = (now - lastCheck) / HOUR;
        if (hours <= 0) return;
        TrapBlock tb = (TrapBlock) state.getBlock();
        if (state.get(TrapBlock.CAUGHT) > 0 || bait.isEmpty()
                || w.getClosestPlayer(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, tb.kind.water ? 6 : 20, false) != null) {
            lastCheck = now;          // занято, пусто или рядом человек — звери не подойдут
            markDirty();
            return;
        }
        hours = Math.min(hours, 72);
        int zone = Traps.zone(w, pos);
        Traps.Prey got = null;
        for (long i = hours; i >= 1; i--) {
            long t = now - (i - 1) * HOUR;
            if (t - baitTime > BAIT_LIFE) break;                  // приманка протухла
            int hour = (int) ((Math.floorMod(t, 24000L) / 1000 + 6) % 24);
            got = Traps.roll(tb.kind, bait.getItem(), skill, zone, hour, w.random);
            if (got != null) break;
            if (w.random.nextFloat() < 0.015f) {                  // приманку утащили
                bait = ItemStack.EMPTY;
                break;
            }
        }
        lastCheck = now;
        markDirty();
        if (got != null) {
            bait = ItemStack.EMPTY;
            w.setBlockState(pos, state.with(TrapBlock.CAUGHT, got.ordinal() + 1).with(TrapBlock.BAITED, false), Block.NOTIFY_ALL);
        } else if (bait.isEmpty() && state.get(TrapBlock.BAITED)) {
            w.setBlockState(pos, state.with(TrapBlock.BAITED, false), Block.NOTIFY_ALL);
        }
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.writeNbt(nbt, lookup);
        if (!bait.isEmpty()) nbt.put("bait", bait.encode(lookup));
        nbt.putLong("baitTime", baitTime);
        nbt.putLong("last", lastCheck);
        nbt.putInt("skill", skill);
    }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.readNbt(nbt, lookup);
        bait = nbt.contains("bait") ? ItemStack.fromNbt(lookup, nbt.getCompound("bait")).orElse(ItemStack.EMPTY) : ItemStack.EMPTY;
        baitTime = nbt.getLong("baitTime");
        lastCheck = nbt.contains("last") ? nbt.getLong("last") : Long.MIN_VALUE;
        skill = nbt.getInt("skill");
    }
}
