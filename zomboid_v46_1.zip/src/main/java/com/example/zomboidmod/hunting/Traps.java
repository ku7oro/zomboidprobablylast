package com.example.zomboidmod.hunting;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.build.Carpentry;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Трапперство по вики PZ: ловушка + свежая приманка + подходящее место. Раз в игровой час, пока
 * рядом никого нет (звери сторонятся людей), идёт бросок: (вес ловушки + вес приманки + навык·1.5)
 * на (вес места + навык·1.5). Кролики, белки и еноты попадаются ночью (19–5), птицы и мыши — когда угодно.
 * Пока игрока нет поблизости, ловушки продолжают работать — улов ждёт.
 */
public final class Traps {
    public static BlockEntityType<TrapBlockEntity> TRAP_BE;
    public static final List<TrapBlock> BLOCKS = new ArrayList<>();

    private Traps() {
    }

    /** Виды ловушек: навык для установки, шанс сломаться при снятии улова. */
    public enum Kind {
        SNARE("snare_trap", "Силки", PzSkill.TRAPPING, 1, 0, 0.12f, false),
        STICK("stick_trap", "Птичья ловушка", PzSkill.TRAPPING, 0, 0, 0.18f, false),
        BOX("box_trap", "Ящик-ловушка", PzSkill.TRAPPING, 0, 1, 0.05f, false),
        CAGE("cage_trap", "Клетка-ловушка", PzSkill.TRAPPING, 3, 0, 0.02f, false),
        MOUSE("mouse_trap", "Мышеловка", PzSkill.TRAPPING, 0, 0, 0.06f, false),
        FISH("fish_trap", "Верша", PzSkill.FISHING, 2, 0, 0.05f, true);

        public final String id, title;
        public final PzSkill skill;
        public final int level, carpentry;
        public final float breakChance;
        public final boolean water;
        public TrapBlock block;

        Kind(String id, String title, PzSkill skill, int level, int carpentry, float breakChance, boolean water) {
            this.id = id;
            this.title = title;
            this.skill = skill;
            this.level = level;
            this.carpentry = carpentry;
            this.breakChance = breakChance;
            this.water = water;
        }
    }

    // зоны (как у PZ): поляна/луг, лес, глухой лес, фермы, город
    static final int Z_VEG = 0, Z_FOREST = 1, Z_DEEP = 2, Z_FARM = 3, Z_TOWN = 4;

    /** Кто попадается: веса ловушек (по Kind), веса мест, часы активности, приманки. */
    public enum Prey {
        RABBIT("кролик", () -> Game.Small.RABBIT.stack(), new int[]{30, 0, 30, 40, 0, 0}, new int[]{10, 12, 15, 6, 2}, true, 6, 0x8A7560,
                "minecraft:carrot=45,minecraft:golden_carrot=50,minecraft:beetroot=40,minecraft:potato=35,minecraft:apple=35,minecraft:melon_slice=35,minecraft:sweet_berries=35,minecraft:wheat=30"),
        SQUIRREL("белка", () -> Game.Small.SQUIRREL.stack(), new int[]{30, 0, 25, 40, 0, 0}, new int[]{8, 14, 15, 4, 3}, true, 5, 0x9A5A34,
                "minecraft:pumpkin_seeds=45,minecraft:melon_seeds=40,minecraft:wheat_seeds=35,zomboidmod:cereal=45,minecraft:apple=40,minecraft:sweet_berries=40,minecraft:glow_berries=40,minecraft:cookie=35"),
        RACCOON("енот", () -> Game.Small.RACCOON.stack(), new int[]{30, 0, 30, 40, 0, 0}, new int[]{8, 12, 12, 6, 8}, true, 8, 0x6E6A66,
                "minecraft:carrot=40,minecraft:apple=35,minecraft:bread=35,zomboidmod:chips=40,zomboidmod:chocolate=35,minecraft:cookie=35,minecraft:sweet_berries=35,zomboidmod:small_game=40,zomboidmod:fish_fillet=40"),
        BIRD("птица", () -> Game.Small.BIRD.stack(), new int[]{0, 40, 0, 0, 0, 0}, new int[]{30, 20, 20, 35, 30}, false, 4, 0x7A6448,
                "minecraft:bread=50,zomboidmod:worm=50,minecraft:wheat_seeds=50,minecraft:wheat=45,zomboidmod:cereal=45,minecraft:beetroot_seeds=45"),
        MOUSE("мышь", () -> Game.Small.MOUSE.stack(), new int[]{0, 0, 0, 0, 30, 0}, new int[]{20, 10, 10, 60, 50}, false, 2, 0x8C8580,
                "zomboidmod:chips=50,zomboidmod:chocolate=40,minecraft:cookie=45,minecraft:bread=45,zomboidmod:cereal=40,minecraft:apple=35,minecraft:wheat=35"),
        RAT("крыса", () -> Game.Small.RAT.stack(), new int[]{0, 0, 0, 0, 25, 0}, new int[]{20, 10, 10, 50, 30}, false, 3, 0x5E5650,
                "zomboidmod:chips=45,minecraft:bread=45,minecraft:cookie=40,zomboidmod:chocolate=35,minecraft:apple=30,zomboidmod:small_game=40,minecraft:rotten_flesh=30"),
        BAIT_FISH("малёк", () -> new ItemStack(HuntingItems.Fish.BAIT_FISH.item), new int[]{0, 0, 0, 0, 0, 40}, null, false, 3, 0xB8C0B8,
                "minecraft:bread=40,zomboidmod:worm=40,minecraft:wheat=30"),
        CRAYFISH("рак", () -> new ItemStack(HuntingItems.Fish.CRAYFISH.item), new int[]{0, 0, 0, 0, 0, 35}, null, false, 4, 0x8A4A30,
                "zomboidmod:fish_fillet=50,zomboidmod:small_game=45,zomboidmod:worm=40,minecraft:rotten_flesh=35"),
        BLUEGILL("солнечник", () -> new ItemStack(HuntingItems.Fish.BLUEGILL.item), new int[]{0, 0, 0, 0, 0, 25}, null, false, 5, 0x5A7A6A,
                "zomboidmod:worm=50,minecraft:bread=30"),
        PERCH("окунь", () -> new ItemStack(HuntingItems.Fish.PERCH.item), new int[]{0, 0, 0, 0, 0, 20}, null, false, 5, 0x9A9A4A,
                "zomboidmod:worm=50,zomboidmod:bait_fish=40"),
        CATFISH("сомик", () -> new ItemStack(HuntingItems.Fish.CHANNEL_CATFISH.item), new int[]{0, 0, 0, 0, 0, 15}, null, false, 8, 0x5E6064,
                "zomboidmod:fish_fillet=50,zomboidmod:bait_fish=50,zomboidmod:small_game=40,minecraft:rotten_flesh=40");

        public final String title;
        final Supplier<ItemStack> catchStack;
        final int[] trap, zone;
        final boolean night;
        public final int xp, color;
        private final String baitSpec;
        private Map<Item, Integer> baits;

        Prey(String title, Supplier<ItemStack> catchStack, int[] trap, int[] zone, boolean night, int xp, int color, String baitSpec) {
            this.title = title;
            this.catchStack = catchStack;
            this.trap = trap;
            this.zone = zone;
            this.night = night;
            this.xp = xp;
            this.color = color;
            this.baitSpec = baitSpec;
        }

        public int bait(Item i) {
            if (baits == null) {
                Map<Item, Integer> m = new HashMap<>();
                for (String e : baitSpec.split(",")) {
                    String[] kv = e.split("=");
                    Identifier id = Identifier.tryParse(kv[0]);
                    if (id != null && Registries.ITEM.containsId(id)) m.put(Registries.ITEM.get(id), Integer.parseInt(kv[1]));
                }
                baits = m;
            }
            return baits.getOrDefault(i, 0);
        }

        public boolean fish() {
            return zone == null;
        }
    }

    public static Prey prey(int caught) {
        Prey[] a = Prey.values();
        return caught >= 1 && caught <= a.length ? a[caught - 1] : null;
    }

    /** Годится ли предмет как приманка для этой ловушки. */
    public static boolean isBait(Kind k, Item i) {
        for (Prey p : Prey.values()) if (p.trap[k.ordinal()] > 0 && p.bait(i) > 0) return true;
        return false;
    }

    /** Что положить в ловушку (для подсказки). */
    public static String baitHint(Kind k) {
        List<String> names = new ArrayList<>();
        for (Prey p : Prey.values()) {
            if (p.trap[k.ordinal()] <= 0) continue;
            p.bait(net.minecraft.item.Items.AIR);
            Item best = null;
            int bw = 0;
            for (var e : p.baits.entrySet()) if (e.getValue() > bw) {
                bw = e.getValue();
                best = e.getKey();
            }
            if (best != null) {
                String n = best.getName().getString();
                if (!names.contains(n)) names.add(n);
            }
        }
        return String.join(", ", names);
    }

    /** Место для ловушки по PZ: город, фермы, лес, глухой лес, поляна. */
    static int zone(ServerWorld w, BlockPos pos) {
        int z = com.example.zomboidmod.world.Knox.zoneAt(w.getSeed(), pos.getX(), pos.getZ());
        if (z == 2) return Z_TOWN;
        if (z == 1) return Z_FARM;
        RegistryEntry<Biome> b = w.getBiome(pos);
        if (b.matchesKey(BiomeKeys.DARK_FOREST) || b.matchesKey(BiomeKeys.OLD_GROWTH_BIRCH_FOREST)
                || b.matchesKey(BiomeKeys.OLD_GROWTH_PINE_TAIGA) || b.matchesKey(BiomeKeys.OLD_GROWTH_SPRUCE_TAIGA)) return Z_DEEP;
        if (b.isIn(BiomeTags.IS_FOREST) || b.isIn(BiomeTags.IS_TAIGA)) return Z_FOREST;
        return Z_VEG;
    }

    /** Бросок одного игрового часа. null — никто не попался. */
    static Prey roll(Kind k, Item bait, int skill, int zone, int hour, Random r) {
        List<Prey> ok = new ArrayList<>();
        for (Prey p : Prey.values()) {
            int tw = p.trap[k.ordinal()];
            if (tw <= 0) continue;
            int bw = p.bait(bait);
            if (bw <= 0) continue;
            if (p.night && hour >= 5 && hour < 19) continue;
            float a = (tw + bw + skill * 1.5f) / 100f;
            float b = (p.fish() ? 30f : p.zone[zone]) / 100f + skill * 0.015f;
            if (p.fish() && ((hour >= 4 && hour < 7) || (hour >= 18 && hour < 21))) b *= 1.2f;   // рыба клюёт на зорьке
            if (r.nextFloat() < a && r.nextFloat() < b) ok.add(p);
        }
        return ok.isEmpty() ? null : ok.get(r.nextInt(ok.size()));
    }

    // =====================================================================================
    //                                       регистрация
    // =====================================================================================

    /** Ловушка-предмет: ставится только с нужным навыком. */
    public static class TrapItem extends BlockItem {
        final Kind kind;

        TrapItem(Kind kind, Block block, Settings s) {
            super(block, s);
            this.kind = kind;
        }

        @Override
        public ActionResult place(ItemPlacementContext ctx) {
            PlayerEntity p = ctx.getPlayer();
            if (p != null && !p.isCreative()) {
                int lv = Carpentry.level(p, kind.skill), cp = Carpentry.level(p, PzSkill.CARPENTRY);
                String why = null;
                if (lv < kind.level) why = "Нужен навык «" + kind.skill.title + "» " + kind.level + " (у вас " + lv + ")";
                else if (cp < kind.carpentry) why = "Нужно плотницкое дело " + kind.carpentry + " (у вас " + cp + ")";
                if (why != null) {
                    if (ctx.getWorld().isClient) p.sendMessage(Text.literal(why).formatted(Formatting.GRAY), true);
                    return ActionResult.FAIL;
                }
            }
            return super.place(ctx);
        }
    }

    public static void register() {
        for (Kind k : Kind.values()) {
            AbstractBlock.Settings s = AbstractBlock.Settings.create().strength(0.6f).nonOpaque()
                    .sounds(k == Kind.CAGE || k == Kind.MOUSE ? BlockSoundGroup.CHAIN : BlockSoundGroup.WOOD);
            if (k == Kind.SNARE || k == Kind.STICK) s = s.noCollision();
            TrapBlock b = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, k.id), new TrapBlock(k, s));
            k.block = b;
            BLOCKS.add(b);
            Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, k.id), new TrapItem(k, b, new Item.Settings().maxCount(16)));
        }
        TRAP_BE = Registry.register(Registries.BLOCK_ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, "trap"),
                BlockEntityType.Builder.create(TrapBlockEntity::new, BLOCKS.toArray(new Block[0])).build(null));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            for (TrapBlock b : BLOCKS) e.add(b);
        });
    }
}
