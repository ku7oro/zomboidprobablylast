package com.example.zomboidmod.hunting;

import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.wildlife.BoarModel;
import com.example.zomboidmod.wildlife.DeerModel;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.CowEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PigEntityModel;
import net.minecraft.client.render.entity.model.SheepEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Туша лежит на боку той же моделью, что и живой зверь; гниющая — темнеет и зеленеет. */
public class CorpseRenderer extends EntityRenderer<CorpseEntity> {
    private static final Identifier DEER_TEX = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/deer.png");
    private static final Identifier BOAR_TEX = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/boar.png");
    private static final Identifier COW_TEX = Identifier.ofVanilla("textures/entity/cow/cow.png");
    private static final Identifier PIG_TEX = Identifier.ofVanilla("textures/entity/pig/pig.png");
    private static final Identifier SHEEP_TEX = Identifier.ofVanilla("textures/entity/sheep/sheep.png");
    private final DeerModel deer;
    private final BoarModel boar;
    private final CowEntityModel<CowEntity> cow;
    private final PigEntityModel<PigEntity> pig;
    private final SheepEntityModel<SheepEntity> sheep;

    public CorpseRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        deer = new DeerModel(DeerModel.create().createModel());
        boar = new BoarModel(BoarModel.create().createModel());
        cow = new CowEntityModel<>(ctx.getPart(EntityModelLayers.COW));
        pig = new PigEntityModel<>(ctx.getPart(EntityModelLayers.PIG));
        sheep = new SheepEntityModel<>(ctx.getPart(EntityModelLayers.SHEEP));
        this.shadowRadius = 0.5f;
    }

    @Override
    public void render(CorpseEntity e, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vcp, int light) {
        Model m;
        Identifier tex;
        switch (e.species()) {
            case BOAR -> {
                m = boar;
                tex = BOAR_TEX;
            }
            case COW -> {
                m = cow;
                tex = COW_TEX;
            }
            case PIG -> {
                m = pig;
                tex = PIG_TEX;
            }
            case SHEEP -> {
                m = sheep;
                tex = SHEEP_TEX;
            }
            default -> {
                m = deer;
                tex = DEER_TEX;
            }
        }
        float rot = e.rot();
        int r = (int) MathHelper.lerp(rot, 255, 120), g = (int) MathHelper.lerp(rot, 255, 132), b = (int) MathHelper.lerp(rot, 255, 96);
        int color = 0xFF000000 | (r << 16) | (g << 8) | b;
        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - e.getYaw()));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(90f));     // на боку
        matrices.scale(-1f, -1f, 1f);
        matrices.translate(0f, -1.501f, 0f);
        m.render(matrices, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(tex)), light, OverlayTexture.DEFAULT_UV, color);
        matrices.pop();
        super.render(e, yaw, tickDelta, matrices, vcp, light);
    }

    @Override
    public Identifier getTexture(CorpseEntity e) {
        return DEER_TEX;
    }
}
