package com.example.zomboidmod.hunting;

import com.example.zomboidmod.nature.Climate;
import com.example.zomboidmod.wildlife.BoarRenderer;
import com.example.zomboidmod.wildlife.TurkeyRenderer;
import com.example.zomboidmod.wildlife.Wildlife;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.block.Block;
import net.minecraft.client.render.RenderLayer;

/** Клиент охоты и природы: модели зверей и туш, ловушки с уловом, следы, погода с сервера. */
public final class HuntingClient {
    private HuntingClient() {
    }

    public static void init() {
        EntityRendererRegistry.register(Wildlife.BOAR, BoarRenderer::new);
        EntityRendererRegistry.register(Wildlife.TURKEY, TurkeyRenderer::new);
        EntityRendererRegistry.register(Hunting.CORPSE, CorpseRenderer::new);
        BlockRenderLayerMap.INSTANCE.putBlock(Tracks.TRACKS, RenderLayer.getTranslucent());
        for (TrapBlock b : Traps.BLOCKS) BlockRenderLayerMap.INSTANCE.putBlock(b, RenderLayer.getCutout());
        // улов в ловушке окрашен в цвет зверя
        ColorProviderRegistry.BLOCK.register((state, world, pos, tint) -> {
            if (tint != 0) return 0xFFFFFFFF;
            Traps.Prey p = Traps.prey(state.get(TrapBlock.CAUGHT));
            return p == null ? 0xFFFFFFFF : 0xFF000000 | p.color;
        }, Traps.BLOCKS.toArray(new Block[0]));
        // погода и календарь с сервера; температура пересчитывается каждый тик для снега и листвы
        ClientPlayNetworking.registerGlobalReceiver(Climate.ClimatePayload.ID, (pl, ctx) -> Climate.apply(pl.data()));
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            if (c.world != null) Climate.updateBase(c.world);
        });
    }
}
