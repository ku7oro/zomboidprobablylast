package com.example.zomboidmod.gun;

import com.example.zomboidmod.Noise;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Стрельба NPC: тот же урон, дальность, дробь и шум, что у оружия игрока, но точность — по умению стрелка. */
public final class NpcGuns {
    private NpcGuns() {
    }

    public static boolean isGun(Item i) {
        return i instanceof GunItem;
    }

    public static int cooldown(Item i) {
        return i instanceof GunItem g ? Math.max(14, g.fireTicks * 2) : 20;
    }

    public static float range(Item i) {
        return i instanceof GunItem g ? Math.min(24f, g.range) : 0f;
    }

    public static Item ammoFor(Item i) {
        return i instanceof GunItem g ? g.ammo.get() : null;
    }

    /**
     * Выстрел по цели. skill 0..1: чем выше, тем меньше разброс. Возвращает true, если попал.
     * Шум выстрела слышат зомби — перестрелка собирает толпу, как в PZ.
     */
    public static boolean fire(ServerWorld w, LivingEntity shooter, LivingEntity target, Item gun, float skill) {
        if (!(gun instanceof GunItem g)) return false;
        Vec3d eye = shooter.getEyePos();
        Vec3d aim = new Vec3d(target.getX(), target.getBodyY(0.6), target.getZ());
        double dist = eye.distanceTo(aim);
        boolean hit = false;
        for (int i = 0; i < g.pellets; i++) {
            float spread = (0.07f - 0.045f * skill) * (float) (1 + dist / 16.0);
            Vec3d dir = aim.subtract(eye).normalize().add(shooter.getRandom().nextGaussian() * spread,
                    shooter.getRandom().nextGaussian() * spread, shooter.getRandom().nextGaussian() * spread).normalize();
            Vec3d end = eye.add(dir.multiply(g.range * 1.4));
            var bh = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, shooter));
            Vec3d stop = bh.getType() == HitResult.Type.MISS ? end : bh.getPos();
            // попал ли луч в цель (по её рамке)
            var box = target.getBoundingBox().expand(0.15);
            var cut = box.raycast(eye, stop);
            if (cut.isPresent()) {
                float fall = dist <= g.range ? 1f : Math.max(0.25f, 1f - (float) (dist - g.range) / g.range);
                if (g.pellets > 1) fall *= Math.max(0.3f, 1f - (float) dist / g.range);
                target.timeUntilRegen = 0;
                target.damage(w.getDamageSources().mobProjectile(shooter, shooter), g.damage * 0.75f * fall);
                Vec3d hp = cut.get();
                w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.getDefaultState()),
                        hp.x, hp.y, hp.z, 8, 0.1, 0.1, 0.1, 0.15);
                hit = true;
            } else if (bh.getType() == HitResult.Type.BLOCK) {
                Vec3d hp = bh.getPos();
                w.spawnParticles(ParticleTypes.SMOKE, hp.x, hp.y, hp.z, 2, 0.02, 0.02, 0.02, 0.01);
            }
        }
        Vec3d muzzle = eye.add(shooter.getRotationVector().multiply(0.9)).add(0, -0.15, 0);
        w.spawnParticles(ParticleTypes.FLASH, muzzle.x, muzzle.y, muzzle.z, 1, 0, 0, 0, 0);
        w.spawnParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 5, 0.05, 0.05, 0.05, 0.02);
        w.playSound(null, shooter.getBlockPos(), g.sound.get(), SoundCategory.HOSTILE, 4f, 0.95f + shooter.getRandom().nextFloat() * 0.1f);
        Noise.emitAt(w, shooter.getBlockPos(), Math.max(8, g.noise));
        return hit;
    }
}
