package com.example.zomboidmod.drag;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.block.FurnitureBlock;
import com.example.zomboidmod.block.ZomboidBlocks;
import com.example.zomboidmod.build.BuildState;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.Survival;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.inventory.Inventories;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

/**
 * Мебель, снятая с места: её тащит игрок или сдвинули мертвецы. Хранит сам блок и всё, что в нём лежало.
 * Пока её держат — едет за руками (не быстрее, чем позволяет вес) и поворачивается вместе с игроком;
 * отпустили — встаёт в ближайшую свободную клетку и снова становится блоком. Твёрдая: сквозь неё не пройти.
 */
public class FurnitureEntity extends Entity {
    private static final TrackedData<BlockState> STATE = DataTracker.registerData(FurnitureEntity.class, TrackedDataHandlerRegistry.BLOCK_STATE);
    private static final TrackedData<Integer> HOLDER = DataTracker.registerData(FurnitureEntity.class, TrackedDataHandlerRegistry.INTEGER);
    /** На сколько градусов мебель повернули с тех пор, как сняли с места. */
    private static final TrackedData<Float> TURN = DataTracker.registerData(FurnitureEntity.class, TrackedDataHandlerRegistry.FLOAT);

    private NbtCompound contents;
    private float weight = 30f;
    private int builtHp = -1;
    private UUID holder;
    private float arm, grabYaw;
    private Vec3d slideTo, kick = Vec3d.ZERO;
    private int slideTicks, settleWait, loose, soundCd, crowd;
    private double press, sinceNoise, sinceXp;
    private long pressAt;
    // клиент: плавный поворот
    private float turnNow, turnPrev;
    private boolean turnInit;

    public FurnitureEntity(EntityType<? extends FurnitureEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(STATE, Blocks.AIR.getDefaultState());
        builder.add(HOLDER, -1);
        builder.add(TURN, 0f);
    }

    /** Снять мебель с места: блок исчезает, появляется эта сущность со всем содержимым. */
    public static FurnitureEntity lift(ServerWorld w, BlockPos pos) {
        BlockState st = w.getBlockState(pos);
        if (!(st.getBlock() instanceof FurnitureBlock fb) || Drag.FURNITURE == null) return null;
        float kg = Drag.weight(w, pos, fb);
        BlockEntity be = w.getBlockEntity(pos);
        NbtCompound nbt = be != null ? be.createNbt(w.getRegistryManager()) : null;
        BuildState bs = BuildState.get(w);
        int hp = -1;
        if (bs.built.containsKey(pos.asLong())) {
            hp = bs.built.remove(pos.asLong());
            bs.markDirty();
        }
        if (be != null) w.removeBlockEntity(pos);                 // иначе вещи высыплются на пол
        w.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
        FurnitureEntity e = new FurnitureEntity(Drag.FURNITURE, w);
        e.dataTracker.set(STATE, st);
        e.contents = nbt;
        e.weight = kg;
        e.builtHp = hp;
        e.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0f, 0f);
        w.spawnEntity(e);
        return e;
    }

    public BlockState state() {
        return dataTracker.get(STATE);
    }

    public boolean tall() {
        return state().getBlock() instanceof FurnitureBlock fb && fb.tall;
    }

    private boolean wheels() {
        return state().getBlock() instanceof FurnitureBlock fb && fb.id.equals("shopping_cart");
    }

    public boolean held() {
        return holder != null;
    }

    public UUID holder() {
        return holder;
    }

    /** id сущности того, кто тащит (на клиенте — чтобы поднять ему руки), -1 — никто. */
    public int holderId() {
        return dataTracker.get(HOLDER);
    }

    /** Поворот для отрисовки, градусы. */
    public float turn(float tickDelta) {
        return MathHelper.lerp(tickDelta, turnPrev, turnNow);
    }

    public float weight() {
        return weight;
    }

    public void hold(ServerPlayerEntity p) {
        holder = p.getUuid();
        dataTracker.set(HOLDER, p.getId());
        arm = (float) (MathHelper.atan2(-(getX() - p.getX()), getZ() - p.getZ()) * 180.0 / Math.PI);
        grabYaw = arm - dataTracker.get(TURN);
        slideTo = null;
        loose = 0;
        settleWait = 0;
        Drag.holding(p, this, Drag.speed(p, weight, wheels()));
        String name = state().getBlock().getName().getString();
        Drag.tell(p, name + (weight >= 70 ? " — тяжело" : weight >= 30 ? "" : " — легко") + ". Отпустить — та же клавиша");
    }

    public void release(ServerPlayerEntity p, String why) {
        holder = null;
        dataTracker.set(HOLDER, -1);
        settleWait = 0;
        loose = 0;
        if (p != null) {
            Drag.dropped(p);
            Drag.tell(p, why);
        }
    }

    /** Съехать в эту точку (мертвецы сдвинули). */
    public void slide(Vec3d to) {
        slideTo = to;
        slideTicks = 0;
    }

    /** Мертвец упёрся и давит. */
    public void pressedBy(PzZombieEntity z) {
        long now = getWorld().getTime();
        press = Drag.decay(press, now - pressAt) + (z.isBrute() ? 4 : 1);
        pressAt = now;
        if (press < Drag.need(weight) * (held() ? 1.0 : 0.6)) return;
        press = 0;
        Vec3d d = getPos().subtract(z.getPos()).multiply(1, 0, 1);
        if (d.lengthSquared() < 1e-4) return;
        kick = d.normalize().multiply(0.22);
        getWorld().playSound(null, getBlockPos(), Drag.SCRAPE, SoundCategory.BLOCKS, 0.9f, 0.85f + random.nextFloat() * 0.2f);
        ServerPlayerEntity p = getWorld() instanceof ServerWorld sw && holder != null ? sw.getServer().getPlayerManager().getPlayer(holder) : null;
        if (p != null) {
            Drag.tell(p, "Мертвецы давят с той стороны!");
            if (!p.isCreative()) {
                Mood m = Survival.mood(p);
                m.endurance = Math.max(0f, m.endurance - 0.03f);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        World w = getWorld();
        if (w.isClient) {
            float t = dataTracker.get(TURN);
            if (!turnInit) {
                turnInit = true;
                turnNow = t;
            }
            turnPrev = turnNow;
            turnNow += MathHelper.wrapDegrees(t - turnNow) * 0.6f;
            int id = holderId();
            if (id >= 0) Drag.CLIENT_HOLDERS.put(id, w.getTime());
            return;
        }
        if (!(w instanceof ServerWorld sw)) return;
        if (state().isAir()) {
            discard();
            return;
        }
        ServerPlayerEntity h = holder == null ? null : sw.getServer().getPlayerManager().getPlayer(holder);
        if (holder != null) {
            String why = h == null || h.getWorld() != w ? "" : Drag.whyNot(h);
            if (why != null) {
                release(h, why);
                h = null;
            }
        }
        Vec3d before = getPos();
        double vy = isOnGround() ? -0.04 : Math.max(getVelocity().y - 0.06, -1.5);
        Vec3d step = Vec3d.ZERO;
        if (h != null) {
            // плечо хвата идёт за взглядом не сразу: тяжёлое разворачивать долго
            float rate = Drag.turnRate(weight);
            arm += MathHelper.clamp(MathHelper.wrapDegrees(h.getYaw() - arm), -rate, rate);
            dataTracker.set(TURN, arm - grabYaw);
            Vec3d f = Vec3d.fromPolar(0f, arm);
            double dx = h.getX() + f.x * Drag.REACH - getX(), dz = h.getZ() + f.z * Drag.REACH - getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            double max = Drag.speed(h, weight, wheels()) / (1.0 + 0.4 * crowd);   // сквозь толпу — медленнее
            if (len > 1e-4) {
                double k = Math.min(1.0, max / len);
                step = new Vec3d(dx * k, 0, dz * k);
            }
        } else if (slideTo != null) {
            double dx = slideTo.x - getX(), dz = slideTo.z - getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 0.03 || ++slideTicks > 40) slideTo = null;
            else {
                double k = Math.min(1.0, 0.09 / len);
                step = new Vec3d(dx * k, 0, dz * k);
            }
        }
        if (kick != Vec3d.ZERO) {
            step = step.add(kick);
            kick = kick.multiply(0.6);
            if (kick.lengthSquared() < 1e-4) kick = Vec3d.ZERO;
        }
        setVelocity(step.x, vy, step.z);
        move(MovementType.SELF, getVelocity());
        double moved = Math.sqrt((getX() - before.x) * (getX() - before.x) + (getZ() - before.z) * (getZ() - before.z));
        if (moved > 0.004) {
            shove(sw, h, step);
            effort(sw, h, moved);
            if (settleWait > 0) settleWait = 0;
        } else crowd = 0;
        if (soundCd > 0) soundCd--;

        if (h != null) {
            if (h.squaredDistanceTo(this) > 2.9 * 2.9) release(h, "Выскользнуло из рук");
        } else if (slideTo == null && kick == Vec3d.ZERO && isOnGround()) {
            loose++;
            if (++settleWait >= 3) {
                if (settle(sw, loose > 100)) return;
                settleWait = -17;                                 // место занято: ещё попытка через секунду
            }
            if (loose > 600) spill(sw);                           // так и не встала — разваливается на вещи
        }
        if (getY() < w.getBottomY() - 16) spill(sw);
    }

    /** Расталкивает тех, кто стоит на пути. */
    private void shove(ServerWorld sw, ServerPlayerEntity h, Vec3d step) {
        List<LivingEntity> hit = sw.getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(0.08, 0, 0.08),
                e -> e != h && e.isAlive() && !e.isSpectator());
        crowd = 0;
        for (LivingEntity e : hit) {
            if (e instanceof PzZombieEntity) crowd++;
            e.addVelocity(step.x * 1.4, 0, step.z * 1.4);
            e.velocityModified = true;
        }
    }

    /** Скрежет, шум для мертвецов и усталость того, кто тащит. */
    private void effort(ServerWorld sw, ServerPlayerEntity h, double moved) {
        boolean wheels = wheels();
        if (soundCd <= 0) {
            soundCd = wheels ? 14 : 9;
            sw.playSound(null, getBlockPos(), Drag.SCRAPE, SoundCategory.BLOCKS, wheels ? 0.25f : Math.min(1.0f, 0.3f + weight / 150f),
                    (wheels ? 1.7f : MathHelper.clamp(1.3f - weight / 200f, 0.7f, 1.3f)) + random.nextFloat() * 0.1f);
        }
        sinceNoise += moved;
        if (sinceNoise >= 1.0) {
            sinceNoise = 0;
            Noise.emitAt(sw, getBlockPos(), wheels ? 7 : Math.min(18, 5 + Math.round(weight / 9f)));
        }
        if (h == null || h.isCreative()) return;
        Mood m = Survival.mood(h);
        m.endurance = Math.max(0f, m.endurance - (float) moved * Drag.effort(h, weight, wheels));
        sinceXp += moved;
        if (sinceXp >= 2.0) {
            sinceXp = 0;
            Skills.addXp(h, PzSkill.STRENGTH, 0.5f + weight / 50f);
        }
    }

    /** Встать на место: в свою клетку или в соседнюю свободную. */
    private boolean settle(ServerWorld sw, boolean force) {
        boolean tall = tall();
        BlockPos c0 = BlockPos.ofFloored(getX(), getY() + 0.3, getZ());
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (BlockPos c : new BlockPos[]{c0, c0.north(), c0.south(), c0.east(), c0.west(), c0.up()}) {
            if (!Drag.fits(sw, c, tall, force)) continue;
            double dx = c.getX() + 0.5 - getX(), dz = c.getZ() + 0.5 - getZ();
            double d = dx * dx + dz * dz + (c.getY() != c0.getY() ? 4.0 : 0.0);   // на клетку выше (стоит на полублоке) — в последнюю очередь
            if (d < bd) {
                bd = d;
                best = c;
            }
        }
        if (best == null) return false;
        BlockState st = state();
        if (st.contains(FurnitureBlock.FACING)) {
            Direction f = st.get(FurnitureBlock.FACING);
            int q = Math.floorMod(Math.round(dataTracker.get(TURN) / 90f), 4);
            for (int i = 0; i < q; i++) f = f.rotateYClockwise();
            st = st.with(FurnitureBlock.FACING, f);
        }
        sw.setBlockState(best, st, Block.NOTIFY_ALL);
        if (tall) sw.setBlockState(best.up(), ZomboidBlocks.FURNITURE_TOP.getDefaultState(), Block.NOTIFY_ALL);
        BlockEntity be = sw.getBlockEntity(best);
        if (be != null && contents != null) {
            be.read(contents, sw.getRegistryManager());
            be.markDirty();
        }
        // у переставленной мебели есть прочность: если её не сдвинуть, мертвецы будут её ломать
        BuildState bs = BuildState.get(sw);
        int max = Drag.hp(weight);
        bs.built.put(best.asLong(), builtHp > 0 ? builtHp : BuildState.pack(max, max));
        bs.markDirty();
        sw.playSound(null, best, st.getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 0.9f, 0.75f);
        contents = null;
        discard();
        return true;
    }

    /** Поставить некуда: мебель и всё, что в ней было, остаётся лежать вещами. */
    private void spill(ServerWorld sw) {
        if (isRemoved()) return;
        dropStack(new ItemStack(state().getBlock().asItem()));
        if (contents != null) {
            DefaultedList<ItemStack> list = DefaultedList.ofSize(27, ItemStack.EMPTY);
            Inventories.readNbt(contents, list, sw.getRegistryManager());
            for (ItemStack s : list) if (!s.isEmpty()) dropStack(s);
        }
        contents = null;
        discard();
    }

    @Override
    public EntityDimensions getDimensions(EntityPose pose) {
        return EntityDimensions.fixed(0.7f, tall() ? 1.95f : 0.98f);
    }

    @Override
    public void onTrackedDataSet(TrackedData<?> data) {
        super.onTrackedDataSet(data);
        if (STATE.equals(data)) calculateDimensions();
    }

    @Override
    public float getStepHeight() {
        return 0.6f;
    }

    @Override
    public boolean isCollidable() {
        return true;
    }

    @Override
    public boolean canHit() {
        return true;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return false;
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        Block b = Registries.BLOCK.get(Identifier.of(nbt.getString("Block")));
        BlockState st = b.getDefaultState();
        Direction f = Direction.byName(nbt.getString("Facing"));
        if (f != null && st.contains(FurnitureBlock.FACING) && f.getAxis().isHorizontal()) st = st.with(FurnitureBlock.FACING, f);
        dataTracker.set(STATE, st);
        dataTracker.set(TURN, nbt.getFloat("Turn"));
        contents = nbt.contains("Contents") ? nbt.getCompound("Contents") : null;
        weight = nbt.contains("Weight") ? nbt.getFloat("Weight") : 30f;
        builtHp = nbt.contains("Hp") ? nbt.getInt("Hp") : -1;
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        BlockState st = state();
        nbt.putString("Block", Registries.BLOCK.getId(st.getBlock()).toString());
        if (st.contains(FurnitureBlock.FACING)) nbt.putString("Facing", st.get(FurnitureBlock.FACING).getName());
        nbt.putFloat("Turn", dataTracker.get(TURN));
        if (contents != null) nbt.put("Contents", contents);
        nbt.putFloat("Weight", weight);
        nbt.putInt("Hp", builtHp);
    }
}
