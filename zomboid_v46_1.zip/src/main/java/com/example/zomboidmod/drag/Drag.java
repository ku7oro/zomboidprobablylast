package com.example.zomboidmod.drag;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.Weight;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.block.FurnitureBlock;
import com.example.zomboidmod.block.FurnitureBlockEntity;
import com.example.zomboidmod.block.ZomboidBlocks;
import com.example.zomboidmod.motion.Knockdown;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.Survival;
import com.example.zomboidmod.vehicle.VehicleEntity;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Мебель и машины двигают руками. Клавиша «Тащить / толкать» (Z): взялся за шкаф — он едет за руками,
 * куда идёшь и поворачиваешься; отпустил — встал на место. Чем тяжелее вещь (и чем больше в ней лежит),
 * тем медленнее, шумнее и тем быстрее кончаются силы. Мертвецы, упёршись в мебель, давят на неё: лёгкую
 * сдвигает один, тяжёлую — только толпа; подпёртую сзади не сдвинуть вовсе, её будут ломать.
 * Машину без водителя можно катить, упёршись спереди или сзади, — тихо, без мотора.
 */
public final class Drag {
    private Drag() {
    }

    public static EntityType<FurnitureEntity> FURNITURE;
    public static SoundEvent SCRAPE;
    /** На каком расстоянии от себя игрок держит мебель. */
    public static final double REACH = 1.3;
    private static final Identifier SLOW = Identifier.of(ZomboidMod.MOD_ID, "drag");

    /** Вес пустой мебели, кг. */
    private static final Map<String, Integer> KG = Map.ofEntries(
            Map.entry("chair", 6), Map.entry("traffic_cone", 3), Map.entry("cardboard_box", 4), Map.entry("trash_can", 8),
            Map.entry("floor_lamp", 6), Map.entry("radio", 4), Map.entry("nightstand", 14), Map.entry("shopping_cart", 15),
            Map.entry("tv", 15), Map.entry("road_barrier", 14), Map.entry("kitchen_table", 25), Map.entry("desk", 35),
            Map.entry("armchair", 30), Map.entry("dresser", 40), Map.entry("bench", 30), Map.entry("shelf_food", 40),
            Map.entry("shelf_meds", 40), Map.entry("shelf_tools", 40), Map.entry("shelf_books", 40), Map.entry("shelf_electronics", 40),
            Map.entry("display_case", 45), Map.entry("gun_rack", 30), Map.entry("army_crate", 30), Map.entry("sandbags", 50),
            Map.entry("rain_barrel", 20), Map.entry("generator", 55), Map.entry("stove", 60), Map.entry("washing_machine", 70),
            Map.entry("sofa", 55), Map.entry("fridge", 90), Map.entry("wardrobe", 80), Map.entry("dumpster", 130));
    /** Вкопано, прикручено или подключено к трубам. */
    private static final Set<String> FIXED = Set.of("street_lamp", "hydrant", "gas_pump", "stop_sign", "mailbox", "toilet", "bathtub",
            "bathroom_sink", "kitchen_sink", "kitchen_counter");

    public record ActPayload(int kind, long pos, int entity) implements CustomPayload {
        public static final int GRAB = 0, GRAB_ENTITY = 1, RELEASE = 2, PUSH = 3;
        public static final CustomPayload.Id<ActPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "drag_act"));
        public static final PacketCodec<RegistryByteBuf, ActPayload> CODEC = PacketCodec.tuple(PacketCodecs.VAR_INT, ActPayload::kind,
                PacketCodecs.VAR_LONG, ActPayload::pos, PacketCodecs.VAR_INT, ActPayload::entity, ActPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Клиенту: за что он сейчас держится (id сущности) или -1. */
    public record StatePayload(int entity) implements CustomPayload {
        public static final CustomPayload.Id<StatePayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "drag_state"));
        public static final PacketCodec<RegistryByteBuf, StatePayload> CODEC = PacketCodec.tuple(PacketCodecs.VAR_INT, StatePayload::entity, StatePayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Клиент: кто сейчас что-то тащит (id сущности игрока → время мира) — чтобы поднять ему руки. */
    public static final Map<Integer, Long> CLIENT_HOLDERS = new HashMap<>();
    /** Кто что тащит: игрок → id сущности. */
    private static final Map<UUID, Integer> HOLDING = new HashMap<>();
    private static final Map<UUID, Long> PUSHED = new HashMap<>();
    /** Напор мертвецов на стоящую мебель: клетка → {сила, время последнего толчка}. */
    private static final Map<Long, double[]> PRESS = new HashMap<>();

    public static void register() {
        FURNITURE = Registry.register(Registries.ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, "moved_furniture"),
                EntityType.Builder.<FurnitureEntity>create(FurnitureEntity::new, SpawnGroup.MISC).dimensions(0.7f, 0.98f).maxTrackingRange(8)
                        .trackingTickInterval(1).build("moved_furniture"));
        Identifier s = Identifier.of(ZomboidMod.MOD_ID, "furniture_scrape");
        SCRAPE = Registry.register(Registries.SOUND_EVENT, s, SoundEvent.of(s));
        PayloadTypeRegistry.playC2S().register(ActPayload.ID, ActPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(StatePayload.ID, StatePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActPayload.ID, (pl, ctx) -> act(ctx.player(), pl));
    }

    private static void act(ServerPlayerEntity p, ActPayload pl) {
        if (p == null || !(p.getWorld() instanceof ServerWorld w)) return;
        switch (pl.kind()) {
            case ActPayload.GRAB -> grab(w, p, BlockPos.fromLong(pl.pos()));
            case ActPayload.GRAB_ENTITY -> {
                if (w.getEntityById(pl.entity()) instanceof FurnitureEntity f && !f.held() && ready(p) && p.squaredDistanceTo(f) < 3.4 * 3.4) f.hold(p);
            }
            case ActPayload.RELEASE -> {
                FurnitureEntity f = held(w, p);
                if (f != null) f.release(p, null);
                else state(p, -1);
            }
            case ActPayload.PUSH -> {
                if (w.getEntityById(pl.entity()) instanceof VehicleEntity v) push(w, p, v);
            }
            default -> {
            }
        }
    }

    // ------------------------------------------------------------------ вес и сила

    public static boolean movable(FurnitureBlock fb) {
        return !FIXED.contains(fb.id);
    }

    public static float weight(ServerWorld w, BlockPos pos, FurnitureBlock fb) {
        float kg = KG.getOrDefault(fb.id, 30);
        if (w.getBlockEntity(pos) instanceof FurnitureBlockEntity be) {
            for (ItemStack s : be.stacks()) kg += Weight.of(s);
            kg += be.fuel * 0.7f + be.water;
        }
        return kg;
    }

    /** Скорость, с которой игрок тащит такую тяжесть (блоков за тик). */
    public static double speed(ServerPlayerEntity p, float kg, boolean wheels) {
        double v = MathHelper.clamp(0.15 - 0.0008 * kg, 0.06, 0.14);
        if (wheels) v = 0.16;
        v *= 1.0 + 0.05 * Skills.level(p, PzSkill.STRENGTH);
        if (!p.isCreative() && Mood.exertion(Survival.mood(p).endurance) >= 2) v *= 0.65;
        return v;
    }

    /** На сколько градусов за тик можно развернуть такую тяжесть вокруг себя. */
    public static float turnRate(float kg) {
        return MathHelper.clamp(10f - kg * 0.085f, 2.2f, 10f);
    }

    /** Сколько сил уходит на блок пути. */
    public static float effort(ServerPlayerEntity p, float kg, boolean wheels) {
        float e = wheels ? 0.003f : 0.004f + kg * 0.00035f;
        return e * (1f - 0.05f * Skills.level(p, PzSkill.STRENGTH));
    }

    /** Прочность мебели как преграды (её колотят мертвецы, если не могут сдвинуть). */
    public static int hp(float kg) {
        return Math.min(900, 180 + Math.round(kg * 4f));
    }

    /** Какой напор нужен, чтобы сдвинуть такую мебель. */
    public static double need(float kg) {
        return kg / 7.0;
    }

    /** Напор спадает, если на мебель перестают давить: один мертвец тяжёлое не сдвинет никогда. */
    public static double decay(double force, long ticks) {
        long n = Math.min(ticks, 400);
        for (long i = 0; i < n && force > 0; i += 5) force -= 5 * (force * 0.0075 + 0.015);
        return Math.max(0, force);
    }

    // ------------------------------------------------------------------ игрок берётся за мебель

    /** Может ли игрок сейчас что-то тащить; null — может, иначе — почему нет. */
    public static String whyNot(ServerPlayerEntity p) {
        if (!p.isAlive() || p.isSpectator()) return "";
        if (p.hasVehicle()) return "";
        if (Knockdown.down(p)) return "Сбит с ног";
        if (p.isSwimming() || p.isSleeping()) return "";
        if (!p.isCreative() && Survival.mood(p).endurance < 0.03f) return "Нет сил";
        return null;
    }

    private static boolean ready(ServerPlayerEntity p) {
        if (HOLDING.containsKey(p.getUuid()) && held((ServerWorld) p.getWorld(), p) != null) return false;
        String why = whyNot(p);
        if (why == null) return true;
        if (!why.isEmpty()) tell(p, why.equals("Руки заняты") ? "Чтобы тащить, нужны свободные руки" : why);
        return false;
    }

    private static void grab(ServerWorld w, ServerPlayerEntity p, BlockPos pos) {
        BlockState st = w.getBlockState(pos);
        if (st.isOf(ZomboidBlocks.FURNITURE_TOP)) {
            pos = pos.down();
            st = w.getBlockState(pos);
        }
        if (!(st.getBlock() instanceof FurnitureBlock fb)) return;
        if (p.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 3.4 * 3.4) return;
        if (!movable(fb)) {
            tell(p, "Это не сдвинуть — закреплено намертво");
            return;
        }
        if (!ready(p)) return;
        FurnitureEntity f = FurnitureEntity.lift(w, pos);
        if (f != null) f.hold(p);
    }

    public static FurnitureEntity held(ServerWorld w, ServerPlayerEntity p) {
        Integer id = HOLDING.get(p.getUuid());
        if (id == null) return null;
        if (w.getEntityById(id) instanceof FurnitureEntity f && f.isAlive() && p.getUuid().equals(f.holder())) return f;
        HOLDING.remove(p.getUuid());
        return null;
    }

    static void holding(ServerPlayerEntity p, FurnitureEntity f, double speed) {
        HOLDING.put(p.getUuid(), f.getId());
        EntityAttributeInstance inst = p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (inst != null) {
            inst.removeModifier(SLOW);
            // шаг игрока — под скорость того, что он тащит (обычный шаг — около 0.216 блока за тик)
            double k = MathHelper.clamp(speed / 0.216 * 0.92, 0.2, 0.8);
            inst.addTemporaryModifier(new EntityAttributeModifier(SLOW, k - 1.0, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        state(p, f.getId());
    }

    static void dropped(ServerPlayerEntity p) {
        HOLDING.remove(p.getUuid());
        EntityAttributeInstance inst = p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (inst != null) inst.removeModifier(SLOW);
        state(p, -1);
    }

    private static void state(ServerPlayerEntity p, int id) {
        if (ServerPlayNetworking.canSend(p, StatePayload.ID)) ServerPlayNetworking.send(p, new StatePayload(id));
    }

    static void tell(ServerPlayerEntity p, String s) {
        if (p != null && s != null && !s.isEmpty()) p.sendMessage(Text.literal(s).formatted(Formatting.GRAY), true);
    }

    /** Свободна ли клетка под мебель. ignore — не проверять, стоит ли там кто-то. */
    public static boolean fits(ServerWorld w, BlockPos c, boolean tall, boolean ignoreBodies) {
        if (c.getY() <= w.getBottomY() || c.getY() >= w.getTopY() - 2) return false;
        BlockState here = w.getBlockState(c);
        if (!here.isReplaceable() || !here.getFluidState().isEmpty()) return false;
        if (tall && !w.getBlockState(c.up()).isReplaceable()) return false;
        if (w.getBlockState(c.down()).getCollisionShape(w, c.down()).isEmpty()) return false;
        if (ignoreBodies) return true;
        Box box = new Box(c).contract(0.2, 0.0, 0.2).stretch(0, tall ? 0.9 : 0, 0);
        return w.getEntitiesByClass(LivingEntity.class, box, e -> e.isAlive() && !e.isSpectator()).isEmpty();
    }

    // ------------------------------------------------------------------ мертвецы давят на мебель

    /** Мертвец упёрся в стоящую мебель. true — давит на неё (и, может быть, сдвинул); false — тут не мебель. */
    public static boolean zombiePress(ServerWorld w, BlockPos pos, BlockState st, PzZombieEntity z) {
        if (st.isOf(ZomboidBlocks.FURNITURE_TOP)) {
            pos = pos.down();
            st = w.getBlockState(pos);
        }
        if (!(st.getBlock() instanceof FurnitureBlock fb) || !movable(fb)) return false;
        float kg = weight(w, pos, fb);
        long now = w.getTime(), key = pos.asLong();
        double[] pr = PRESS.computeIfAbsent(key, k -> new double[]{0, now});
        pr[0] = decay(pr[0], now - (long) pr[1]) + (z.isBrute() ? 4 : 1);
        pr[1] = now;
        if (PRESS.size() > 512) PRESS.entrySet().removeIf(e -> now - (long) e.getValue()[1] > 1200);
        if (pr[0] < need(kg)) {                                   // пока не хватает напора — наваливаются и колотят
            if (w.random.nextInt(3) == 0) w.playSound(null, pos, st.getSoundGroup().getHitSound(), SoundCategory.HOSTILE, 0.8f, 0.6f + w.random.nextFloat() * 0.2f);
            return false;
        }
        Direction dir = Direction.getFacing(pos.getX() + 0.5 - z.getX(), 0, pos.getZ() + 0.5 - z.getZ());
        if (dir.getAxis().isVertical()) return false;
        BlockPos dest = pos.offset(dir);
        if (!fits(w, dest, fb.tall, true)) return false;          // подпёрта сзади стеной или другой мебелью: не сдвинуть
        // сзади стоит человек и держит: держит, пока хватает сил
        boolean heldBack = false;
        for (ServerPlayerEntity p : w.getEntitiesByClass(ServerPlayerEntity.class, new Box(dest).expand(0.1, 0.5, 0.1),
                e -> e.isAlive() && !e.isSpectator() && !Knockdown.down(e))) {
            if (p.isCreative()) {
                heldBack = true;
                continue;
            }
            Mood m = Survival.mood(p);
            if (m.endurance < 0.08f) {
                tell(p, "Не удержать — мертвецы продавили!");
                continue;
            }
            m.endurance = Math.max(0f, m.endurance - 0.05f);
            tell(p, "Ты держишь " + fb.getName().getString().toLowerCase(java.util.Locale.ROOT) + " собой — мертвецы давят!");
            heldBack = true;
        }
        if (heldBack) {
            pr[0] = need(kg) * 0.5;
            w.playSound(null, pos, st.getSoundGroup().getHitSound(), SoundCategory.HOSTILE, 1.0f, 0.5f);
            return true;
        }
        PRESS.remove(key);
        FurnitureEntity f = FurnitureEntity.lift(w, pos);
        if (f == null) return false;
        f.slide(new Vec3d(dest.getX() + 0.5, dest.getY(), dest.getZ() + 0.5));
        z.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        w.playSound(null, pos, SCRAPE, SoundCategory.BLOCKS, 1.0f, 0.8f + w.random.nextFloat() * 0.2f);
        Noise.emitAt(w, pos, 12);
        return true;
    }

    /** Мертвец упёрся в мебель, которую тащат или которая ещё не встала на место. */
    public static boolean zombiePressEntity(PzZombieEntity z) {
        if (!(z.getWorld() instanceof ServerWorld w)) return false;
        Vec3d fwd = Vec3d.fromPolar(0f, z.getYaw());
        for (FurnitureEntity f : w.getEntitiesByClass(FurnitureEntity.class, z.getBoundingBox().expand(0.7, 0.2, 0.7), Entity::isAlive)) {
            Vec3d to = f.getPos().subtract(z.getPos()).multiply(1, 0, 1);
            if (to.lengthSquared() > 1e-4 && to.normalize().dotProduct(fwd) < 0.2) continue;   // не перед ним
            f.pressedBy(z);
            z.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ толкать машину

    private static void push(ServerWorld w, ServerPlayerEntity p, VehicleEntity v) {
        if (!p.isAlive() || p.isSpectator() || p.hasVehicle() || Knockdown.down(p)) return;
        long now = w.getTime();
        Long last = PUSHED.get(p.getUuid());
        if (last != null && now - last >= 0 && now - last < 3) return;
        PUSHED.put(p.getUuid(), now);
        if (!p.getBoundingBox().expand(1.0, 0.5, 1.0).intersects(v.getBoundingBox())) return;
        if (v.getControllingPassenger() != null) {
            tell(p, "За рулём кто-то есть");
            return;
        }
        Vec3d fwd = Vec3d.fromPolar(0f, v.getYaw());
        Vec3d look = Vec3d.fromPolar(0f, p.getYaw());
        double dot = fwd.dotProduct(look);
        if (Math.abs(dot) < 0.45) {
            tell(p, "Упрись в машину спереди или сзади — вбок её не сдвинуть");
            return;
        }
        boolean bike = v.type.bike();
        float mass = bike ? 0.3f : v.type.width >= 2.45f ? 1.4f : 1f;
        if (!p.isCreative()) {
            Mood m = Survival.mood(p);
            if (m.endurance < 0.06f) {
                tell(p, "Нет сил толкать");
                return;
            }
            m.endurance = Math.max(0f, m.endurance - 0.0045f * mass * (1f - 0.05f * Skills.level(p, PzSkill.STRENGTH)));
        }
        float str = 1f + 0.06f * Skills.level(p, PzSkill.STRENGTH);
        float cap = (bike ? 0.085f : 0.05f) * (float) Math.sqrt(str) / (float) Math.sqrt(Math.max(1f, mass));
        v.handPush((float) Math.signum(dot) * 0.011f * str / mass, cap);
        if (now % 20 < 3) {
            Noise.emitAt(w, v.getBlockPos(), bike ? 4 : 7);
            if (w.random.nextInt(3) == 0) Skills.addXp(p, PzSkill.STRENGTH, 0.6f * mass);
        }
    }
}
