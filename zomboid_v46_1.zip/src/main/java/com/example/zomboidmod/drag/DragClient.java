package com.example.zomboidmod.drag;

import com.example.zomboidmod.block.FurnitureBlock;
import com.example.zomboidmod.block.ZomboidBlocks;
import com.example.zomboidmod.vehicle.VehicleEntity;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * Клавиша «Тащить / толкать» (Z; не X — её в игре уже занимает загрузка панели быстрого доступа). Смотришь на мебель — взяться; ещё раз — отпустить.
 * Смотришь на машину и держишь клавишу — толкаешь её. Тот, кто тащит, держит руки перед собой.
 */
public final class DragClient {
    private DragClient() {
    }

    private static KeyBinding key;
    private static int held = -1;        // id мебели, которую тащу
    private static int tick, hintLeft = 20 * 90, pushing;
    private static String hint;

    public static boolean dragging() {
        return held >= 0;
    }

    public static void init() {
        key = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.zomboidmod.pull", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, "category.zomboidmod"));
        EntityRendererRegistry.register(Drag.FURNITURE, FurnitureEntityRenderer::new);
        ClientPlayNetworking.registerGlobalReceiver(Drag.StatePayload.ID, (pl, ctx) -> ctx.client().execute(() -> held = pl.entity()));
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> {
            held = -1;
            Drag.CLIENT_HOLDERS.clear();
        });
        ClientTickEvents.END_CLIENT_TICK.register(DragClient::tick);
        HudRenderCallback.EVENT.register(DragClient::hud);
    }

    private static void send(int kind, long pos, int entity) {
        if (ClientPlayNetworking.canSend(Drag.ActPayload.ID)) ClientPlayNetworking.send(new Drag.ActPayload(kind, pos, entity));
    }

    private static void tick(MinecraftClient c) {
        hint = null;
        if (c.world == null || c.player == null) {
            held = -1;
            return;
        }
        tick++;
        if (pushing > 0) pushing--;
        if (held >= 0 && !(c.world.getEntityById(held) instanceof FurnitureEntity)) {
            if (tick % 40 == 0) held = -1;     // мебель встала на место или пропала из виду
        }
        long now = c.world.getTime();
        if (tick % 100 == 0) Drag.CLIENT_HOLDERS.values().removeIf(t -> now - t > 20 || now < t);

        HitResult hr = c.crosshairTarget;
        boolean free = c.currentScreen == null && !c.player.hasVehicle() && !c.player.isSpectator();
        boolean furniture = false, vehicle = false;
        if (free && hr instanceof BlockHitResult bh && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = c.world.getBlockState(bh.getBlockPos());
            if (st.isOf(ZomboidBlocks.FURNITURE_TOP)) st = c.world.getBlockState(bh.getBlockPos().down());
            furniture = st.getBlock() instanceof FurnitureBlock fb && Drag.movable(fb)
                    && c.player.squaredDistanceTo(bh.getPos()) < 3.2 * 3.2;
        } else if (free && hr instanceof EntityHitResult eh) {
            if (eh.getEntity() instanceof FurnitureEntity f) furniture = !(f.holderId() >= 0) && c.player.squaredDistanceTo(f) < 3.2 * 3.2;
            else if (eh.getEntity() instanceof VehicleEntity v) vehicle = v.getControllingPassenger() == null && c.player.squaredDistanceTo(v) < 4.5 * 4.5;
        }

        while (key.wasPressed()) {
            if (!free) continue;
            if (held >= 0) send(Drag.ActPayload.RELEASE, 0L, 0);
            else if (furniture && hr instanceof BlockHitResult bh) send(Drag.ActPayload.GRAB, bh.getBlockPos().asLong(), 0);
            else if (furniture && hr instanceof EntityHitResult eh) send(Drag.ActPayload.GRAB_ENTITY, 0L, eh.getEntity().getId());
        }
        // машину толкают, пока держат клавишу
        if (free && held < 0 && vehicle && key.isPressed() && hr instanceof EntityHitResult eh && tick % 4 == 0) {
            send(Drag.ActPayload.PUSH, 0L, eh.getEntity().getId());
            pushing = 8;
        }

        // подсказки: первые полминуты, пока игрок не привык
        if (hintLeft > 0 && free) {
            String k = key.getBoundKeyLocalizedText().getString();
            if (held >= 0) {
                hint = "[" + k + "] отпустить";
                hintLeft--;
            } else if (furniture) {
                hint = "[" + k + "] тащить";
                hintLeft--;
            } else if (vehicle && pushing == 0) {
                hint = "[" + k + "] держать — толкать машину";
                hintLeft--;
            }
        }
    }

    private static void hud(DrawContext ctx, RenderTickCounter counter) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (hint == null || c.options.hudHidden || c.currentScreen != null) return;
        ctx.drawCenteredTextWithShadow(c.textRenderer, hint, ctx.getScaledWindowWidth() / 2, ctx.getScaledWindowHeight() / 2 + 28, 0xFFF0E6C8);
    }

    /** Тот, кто тащит мебель, держит её обеими руками перед собой и налегает корпусом. */
    public static void pose(BipedEntityModel<?> m, LivingEntity e, float limbAngle, float limbDistance, float age) {
        if (!(e instanceof PlayerEntity) || age == 0f || Drag.CLIENT_HOLDERS.isEmpty()) return;
        Long seen = Drag.CLIENT_HOLDERS.get(e.getId());
        if (seen == null) return;
        long now = e.getWorld().getTime();
        if (now - seen > 4 || now < seen) return;
        float strain = MathHelper.sin(limbAngle * 0.6662f) * 0.08f * Math.min(1f, limbDistance * 2f);
        m.rightArm.pitch = -1.25f + strain;
        m.leftArm.pitch = -1.25f - strain;
        m.rightArm.yaw = -0.12f;
        m.leftArm.yaw = 0.12f;
        m.rightArm.roll = 0f;
        m.leftArm.roll = 0f;
        m.body.pitch += 0.12f;
        m.head.pitch -= 0.08f;
        m.hat.copyTransform(m.head);
        if (m instanceof net.minecraft.client.render.entity.model.PlayerEntityModel<?> pm) {
            pm.rightSleeve.copyTransform(m.rightArm);
            pm.leftSleeve.copyTransform(m.leftArm);
            pm.jacket.copyTransform(m.body);
        }
    }
}
