package com.example.zomboidmod.drag;

import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/** Мебель, которую тащат: та же модель, что у блока, повёрнутая вместе с тем, кто её держит. */
public class FurnitureEntityRenderer extends EntityRenderer<FurnitureEntity> {
    private final BlockRenderManager blocks;

    public FurnitureEntityRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.blocks = ctx.getBlockRenderManager();
        this.shadowRadius = 0.45f;
    }

    @Override
    public void render(FurnitureEntity e, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vcp, int light) {
        BlockState st = e.state();
        if (st.getRenderType() == BlockRenderType.MODEL) {
            matrices.push();
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-e.turn(tickDelta)));
            matrices.translate(-0.5f, 0f, -0.5f);
            blocks.renderBlockAsEntity(st, matrices, vcp, light, OverlayTexture.DEFAULT_UV);
            matrices.pop();
        }
        super.render(e, yaw, tickDelta, matrices, vcp, light);
    }

    @Override
    public Identifier getTexture(FurnitureEntity e) {
        return SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE;
    }
}
