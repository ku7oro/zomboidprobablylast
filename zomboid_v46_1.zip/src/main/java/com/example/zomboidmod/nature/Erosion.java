package com.example.zomboidmod.nature;

import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.block.BuildingBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.TallPlantBlock;
import net.minecraft.block.VineBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

/**
 * Эрозия как в PZ: месяц за месяцем природа забирает округ. Асфальт трескается и зарастает,
 * тротуары крошатся, лужайки превращаются в бурьян с кустами и молодыми деревцами,
 * стены затягивает плющ, камень покрывается мхом, крыши — зелёным налётом.
 * За «Дни эрозии» (игровое правило zomboidErosionDays, по умолчанию 100) мир зарастает полностью.
 * Чанки, которые игрок не видел, догоняют свой уровень, как только он придёт. Где игрок строился,
 * природа не наступает — дом обжит.
 */
public final class Erosion {
    public static Block ASPHALT_OVERGROWN, SIDEWALK_CRACKED, SIDEWALK_OVERGROWN;
    /** Проб на чанк за каждый процент эрозии (полное зарастание — около 700 проб, ~3 на столбец). */
    private static final int SAMPLES_PER_PERCENT = 7;
    private static final int FLAGS = Block.NOTIFY_LISTENERS;
    private static final Block[] FLOWERS = {Blocks.DANDELION, Blocks.POPPY, Blocks.OXEYE_DAISY, Blocks.CORNFLOWER, Blocks.AZURE_BLUET, Blocks.DANDELION};

    private Erosion() {
    }

    public static void register() {
        Block asphalt = BuildingBlocks.get("asphalt"), sidewalk = BuildingBlocks.get("sidewalk");
        ASPHALT_OVERGROWN = reg("asphalt_overgrown", asphalt);
        SIDEWALK_CRACKED = reg("sidewalk_cracked", sidewalk);
        SIDEWALK_OVERGROWN = reg("sidewalk_overgrown", sidewalk);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS).register(e -> {
            e.add(ASPHALT_OVERGROWN);
            e.add(SIDEWALK_CRACKED);
            e.add(SIDEWALK_OVERGROWN);
        });
    }

    private static Block reg(String id, Block like) {
        AbstractBlock.Settings s = like != null ? AbstractBlock.Settings.copy(like) : AbstractBlock.Settings.copy(Blocks.STONE);
        Block b = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, id), new Block(s));
        Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), new BlockItem(b, new Item.Settings()));
        return b;
    }

    /** Насколько мир зарос, 0..1. */
    public static float level(ServerWorld w) {
        int days = w.getGameRules().getInt(Climate.EROSION_DAYS);
        if (days <= 0) return 0f;
        return (float) MathHelper.clamp(Climate.dayFloat(w) / days, 0.0, 1.0);
    }

    /** Игрок поставил блок: этот чанк — его дом, тут не зарастает. */
    public static void markBase(World world, BlockPos pos) {
        if (!(world instanceof ServerWorld sw) || sw.getRegistryKey() != World.OVERWORLD) return;
        ClimateState st = Climate.state(sw);
        if (st.bases.add(ChunkPos.toLong(pos.getX() >> 4, pos.getZ() >> 4))) st.markDirty();
    }

    /** Каждые 5 тиков: догоняем уровень эрозии в чанках вокруг игроков (не больше бюджета за раз). */
    static void tick(ServerWorld w, ClimateState st) {
        if (com.example.zomboidmod.world.Knox.busy()) return;    // сначала пусть достроятся города
        float lv = level(w);
        int target = (int) (lv * 100f);
        if (target <= 0) return;
        int budget = 110;
        Random r = w.random;
        for (ServerPlayerEntity p : w.getPlayers()) {
            int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
            for (int ring = 0; ring <= 3 && budget > 0; ring++) {
                for (int dx = -ring; dx <= ring && budget > 0; dx++) {
                    for (int dz = -ring; dz <= ring && budget > 0; dz++) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) != ring) continue;
                        int cx = pcx + dx, cz = pcz + dz;
                        long key = ChunkPos.toLong(cx, cz);
                        if (st.bases.contains(key)) continue;
                        int have = st.erosion.get(key);
                        if (have >= target || !w.isChunkLoaded(cx, cz)) continue;
                        int n = (target - have) * SAMPLES_PER_PERCENT;
                        for (int i = 0; i < n; i++) sample(w, (cx << 4) + r.nextInt(16), (cz << 4) + r.nextInt(16), lv, r);
                        st.erosion.put(key, (byte) target);
                        st.markDirty();
                        budget -= n;
                    }
                }
            }
        }
    }

    private static String id(BlockState s) {
        return Registries.BLOCK.getId(s.getBlock()).getPath();
    }

    /** Одна проба в столбце (x, z). */
    private static void sample(ServerWorld w, int x, int z, float e, Random r) {
        BlockPos top = w.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
        BlockPos g = top.down();
        BlockState gs = w.getBlockState(g), ts = w.getBlockState(top);
        if (!gs.getFluidState().isEmpty()) return;
        boolean warm = Climate.tempAt(w, top) > 3f;   // зимой ничего не растёт, только трескается
        String gid = id(gs);
        boolean ours = Registries.BLOCK.getId(gs.getBlock()).getNamespace().equals(ZomboidMod.MOD_ID);

        // ---------- трава на месте: дорастает до бурьяна ----------
        if (ts.isOf(Blocks.SHORT_GRASS)) {
            if (warm && e > 0.25f && r.nextFloat() < 0.3f && w.isAir(top.up()) && gs.isOf(Blocks.GRASS_BLOCK))
                TallPlantBlock.placeAt(w, Blocks.TALL_GRASS.getDefaultState(), top, FLAGS);
            return;
        }
        if (!ts.isAir()) return;

        // ---------- дороги и тротуары ----------
        if (ours) {
            if (gid.equals("asphalt")) {
                if (r.nextFloat() < 0.55f) set(w, g, BuildingBlocks.get("asphalt_cracked"));
                return;
            }
            if (gid.equals("road_line_white") || gid.equals("road_line_yellow")) {   // разметка стирается
                if (e > 0.35f && r.nextFloat() < 0.25f) set(w, g, BuildingBlocks.get("asphalt"));
                return;
            }
            if (gid.equals("asphalt_cracked")) {
                if (e > 0.2f && r.nextFloat() < 0.45f) set(w, g, ASPHALT_OVERGROWN);
                return;
            }
            if (gid.equals("sidewalk")) {
                if (r.nextFloat() < 0.5f) set(w, g, SIDEWALK_CRACKED);
                return;
            }
            if (gid.equals("sidewalk_cracked")) {
                if (e > 0.25f && r.nextFloat() < 0.45f) set(w, g, SIDEWALK_OVERGROWN);
                return;
            }
            if (gid.equals("asphalt_overgrown") || gid.equals("sidewalk_overgrown")) {
                if (!warm) return;
                float k = r.nextFloat();
                if (e > 0.6f && k < 0.1f) set(w, g, Blocks.GRASS_BLOCK);                    // корни взломали покрытие
                else if (e > 0.4f && k < 0.22f) w.setBlockState(top, Blocks.MOSS_CARPET.getDefaultState(), FLAGS);
                return;
            }
            if (gid.startsWith("shingles") || gid.startsWith("roof_tar")) {        // крыши зеленеют
                if (warm && e > 0.4f && r.nextFloat() < 0.08f) w.setBlockState(top, Blocks.MOSS_CARPET.getDefaultState(), FLAGS);
                return;
            }
        }

        if (!warm) return;
        // ---------- плющ на стенах и мох на камне ----------
        if (r.nextFloat() < 0.5f) {
            Direction d = Direction.fromHorizontal(r.nextInt(4));
            BlockPos n = top.offset(d);
            BlockState ns = w.getBlockState(n);
            if (ns.isOpaqueFullCube(w, n) && w.getBlockState(n.up()).isOpaqueFullCube(w, n.up())) {
                if (e > 0.35f && r.nextFloat() < 0.25f) {
                    if (ns.isOf(Blocks.COBBLESTONE)) set(w, n, Blocks.MOSSY_COBBLESTONE);
                    else if (ns.isOf(Blocks.STONE_BRICKS)) set(w, n, Blocks.MOSSY_STONE_BRICKS);
                }
                if (e > 0.15f && r.nextFloat() < 0.4f) vines(w, top, d, 1 + r.nextInt(1 + (int) (e * 9f)));
                return;
            }
        }

        // ---------- земля: бурьян, цветы, кусты, деревца ----------
        if (gs.isOf(Blocks.DIRT_PATH)) {
            if (e > 0.25f && r.nextFloat() < 0.4f) set(w, g, Blocks.GRASS_BLOCK);
            return;
        }
        if (gs.isOf(Blocks.DIRT) || gs.isOf(Blocks.COARSE_DIRT)) {
            if (e > 0.15f && r.nextFloat() < 0.3f) set(w, g, Blocks.GRASS_BLOCK);
            return;
        }
        if (!gs.isOf(Blocks.GRASS_BLOCK) || r.nextFloat() > 0.6f) return;
        float k = r.nextFloat();
        if (e > 0.45f && k < 0.03f) {
            w.setBlockState(top, (r.nextFloat() < 0.7f ? Blocks.OAK_SAPLING : Blocks.BIRCH_SAPLING).getDefaultState(), FLAGS);
        } else if (e > 0.3f && k < 0.08f) {                         // куст
            w.setBlockState(top, Blocks.OAK_LEAVES.getDefaultState().with(LeavesBlock.PERSISTENT, true), FLAGS);
        } else if (e > 0.15f && k < 0.2f) {
            w.setBlockState(top, FLOWERS[r.nextInt(FLOWERS.length)].getDefaultState(), FLAGS);
        } else if (e > 0.2f && k < 0.38f && w.isAir(top.up())) {
            TallPlantBlock.placeAt(w, (r.nextFloat() < 0.25f ? Blocks.LARGE_FERN : Blocks.TALL_GRASS).getDefaultState(), top, FLAGS);
        } else if (k < 0.48f) {
            w.setBlockState(top, Blocks.FERN.getDefaultState(), FLAGS);
        } else {
            w.setBlockState(top, Blocks.SHORT_GRASS.getDefaultState(), FLAGS);
        }
    }

    private static void set(ServerWorld w, BlockPos pos, Block b) {
        if (b != null) w.setBlockState(pos, b.getDefaultState(), FLAGS);
    }

    /** Плющ от земли вверх по стене, что в стороне d. */
    private static void vines(ServerWorld w, BlockPos from, Direction d, int h) {
        for (int i = 0; i < h; i++) {
            BlockPos p = from.up(i);
            BlockPos wall = p.offset(d);
            if (!w.getBlockState(wall).isOpaqueFullCube(w, wall)) return;
            BlockState s = w.getBlockState(p);
            if (s.isOf(Blocks.VINE)) w.setBlockState(p, s.with(VineBlock.getFacingProperty(d), true), FLAGS);
            else if (s.isAir()) w.setBlockState(p, Blocks.VINE.getDefaultState().with(VineBlock.getFacingProperty(d), true), FLAGS);
            else return;
        }
    }
}
