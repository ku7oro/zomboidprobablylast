package com.example.zomboidmod.nature;

import com.example.zomboidmod.survival.Clock;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ByteOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;

/**
 * Сохранённое состояние природы: календарь (с учётом скорости сезонов), погода по дням,
 * насколько «заросли» чанки и где живут игроки (там природа не наступает).
 */
public class ClimateState extends PersistentState {
    /** Календарь: дата = anchorYear + (день мира − anchorDay) · speed. Так скорость можно менять без скачков. */
    public double anchorYear = Clock.START_DOY, anchorDay = 0;
    public int speed = 1;
    /** Погода по номерам дней. */
    public final Int2ObjectOpenHashMap<Day> days = new Int2ObjectOpenHashMap<>();
    /** Эрозия: чанк -> сколько процентов уже применено. */
    public final Long2ByteOpenHashMap erosion = new Long2ByteOpenHashMap();
    /** Чанки, где игроки что-то строили. */
    public final LongOpenHashSet bases = new LongOpenHashSet();

    /** Погода одного дня. */
    public static final class Day {
        public float front;        // отклонение температуры от нормы, °C
        public float wind;         // сила ветра 0..1
        public float windFrom;     // откуда дует, градусы (0 — с севера, 90 — с востока)
        public boolean rain, storm;
        public float rainStart, rainLen;   // часы
        public float fog;          // вероятность утреннего тумана 0..1
        public boolean heat, cold; // аномальная жара / сильные морозы

        NbtCompound write() {
            NbtCompound c = new NbtCompound();
            c.putFloat("f", front);
            c.putFloat("w", wind);
            c.putFloat("wd", windFrom);
            c.putBoolean("r", rain);
            c.putBoolean("s", storm);
            c.putFloat("rs", rainStart);
            c.putFloat("rl", rainLen);
            c.putFloat("fog", fog);
            c.putBoolean("h", heat);
            c.putBoolean("c", cold);
            return c;
        }

        static Day read(NbtCompound c) {
            Day d = new Day();
            d.front = c.getFloat("f");
            d.wind = c.getFloat("w");
            d.windFrom = c.getFloat("wd");
            d.rain = c.getBoolean("r");
            d.storm = c.getBoolean("s");
            d.rainStart = c.getFloat("rs");
            d.rainLen = c.getFloat("rl");
            d.fog = c.getFloat("fog");
            d.heat = c.getBoolean("h");
            d.cold = c.getBoolean("c");
            return d;
        }
    }

    private static final PersistentState.Type<ClimateState> TYPE = new PersistentState.Type<>(ClimateState::new, ClimateState::fromNbt, null);

    public static ClimateState get(ServerWorld w) {
        return w.getPersistentStateManager().getOrCreate(TYPE, "zomboidmod_climate");
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        nbt.putDouble("ay", anchorYear);
        nbt.putDouble("ad", anchorDay);
        nbt.putInt("sp", speed);
        NbtList l = new NbtList();
        for (var e : days.int2ObjectEntrySet()) {
            NbtCompound c = e.getValue().write();
            c.putInt("day", e.getIntKey());
            l.add(c);
        }
        nbt.put("days", l);
        long[] keys = new long[erosion.size()];
        byte[] vals = new byte[erosion.size()];
        int i = 0;
        for (var e : erosion.long2ByteEntrySet()) {
            keys[i] = e.getLongKey();
            vals[i] = e.getByteValue();
            i++;
        }
        nbt.putLongArray("ek", keys);
        nbt.putByteArray("ev", vals);
        nbt.putLongArray("bases", bases.toLongArray());
        return nbt;
    }

    public static ClimateState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        ClimateState s = new ClimateState();
        if (nbt.contains("ay")) {
            s.anchorYear = nbt.getDouble("ay");
            s.anchorDay = nbt.getDouble("ad");
            s.speed = Math.max(1, nbt.getInt("sp"));
        }
        NbtList l = nbt.getList("days", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < l.size(); i++) {
            NbtCompound c = l.getCompound(i);
            s.days.put(c.getInt("day"), Day.read(c));
        }
        long[] keys = nbt.getLongArray("ek");
        byte[] vals = nbt.getByteArray("ev");
        for (int i = 0; i < keys.length && i < vals.length; i++) s.erosion.put(keys[i], vals[i]);
        for (long b : nbt.getLongArray("bases")) s.bases.add(b);
        return s;
    }
}
