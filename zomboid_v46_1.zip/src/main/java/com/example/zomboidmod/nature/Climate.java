package com.example.zomboidmod.nature;

import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.survival.Clock;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CocoaBlock;
import net.minecraft.block.CropBlock;
import net.minecraft.block.SaplingBlock;
import net.minecraft.block.SnowBlock;
import net.minecraft.block.StemBlock;
import net.minecraft.block.SugarCaneBlock;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.GameRules;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;

/**
 * Сезоны и погода как в PZ. Календарь начинается 9 июля; лето, осень, зима и весна сменяют друг друга,
 * температура зависит от сезона, времени суток и атмосферных фронтов. Погода расписана по дням
 * (её и передают по радио): ясно, дожди, грозы, туманы, жара летом, морозы, снегопады и метели зимой.
 * Когда холодно, вместо дождя идёт снег, вода замерзает, урожай на улице перестаёт расти и гибнет от морозов.
 * Значения, нужные клиенту (снег, листва, часы), синхронизируются пакетом.
 */
public final class Climate {
    /** Во сколько раз быстрее идёт календарь (1 — как в PZ: игровой день = день года). */
    public static GameRules.Key<GameRules.IntRule> SEASON_SPEED;
    /** За сколько дней природа полностью забирает город (как ErosionDays в PZ; 0 — выключено). */
    public static GameRules.Key<GameRules.IntRule> EROSION_DAYS;

    public enum Season {
        SPRING("весна"), SUMMER("лето"), AUTUMN("осень"), WINTER("зима");
        public final String title;

        Season(String t) {
            title = t;
        }
    }

    // ---- общие значения (на сервере их пишет сервер, на клиенте — пакет; в одиночной игре они совпадают) ----
    public static volatile double anchorYear = Clock.START_DOY, anchorDay = 0;
    public static volatile int speed = 1;
    public static volatile float front, wind = 0.3f, windFrom = 225f;
    public static volatile int kind;
    /** Температура воздуха «сейчас» без поправки на биом и высоту, °C (пересчитывается каждый тик). */
    public static volatile float baseTemp = 20f;

    public static final int K_CLEAR = 0, K_CLOUDY = 1, K_RAIN = 2, K_STORM = 3, K_SNOW = 4, K_BLIZZARD = 5, K_FOG = 6, K_HEAT = 7, K_COLD = 8;
    private static final String[] KIND_NAMES = {"ясно", "облачно", "дождь", "гроза", "снег", "метель", "туман", "жара", "мороз"};
    private static final String[] DIR_SHORT = {"С", "СВ", "В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ"};
    private static final String[] DIR_ADJ = {"северный", "северо-восточный", "восточный", "юго-восточный", "южный", "юго-западный",
            "западный", "северо-западный"};

    private static ClimateState state;

    private Climate() {
    }

    // =====================================================================================
    //                                       календарь
    // =====================================================================================

    /** Сколько дней прошло с начала (дробное; 0.25 — 6 утра первого дня). */
    public static double dayFloat(World w) {
        return (w.getTimeOfDay() + 6000) / 24000.0;
    }

    /** День года (дробный, может быть больше 365 — берите по модулю). */
    public static double yearDay(World w) {
        return anchorYear + (dayFloat(w) - anchorDay) * speed;
    }

    public static Season season(double yearDay) {
        int d = Math.floorMod((int) Math.floor(yearDay), 365);
        if (d >= 59 && d < 151) return Season.SPRING;
        if (d >= 151 && d < 243) return Season.SUMMER;
        if (d >= 243 && d < 334) return Season.AUTUMN;
        return Season.WINTER;
    }

    public static Season season(World w) {
        return season(yearDay(w));
    }

    /** Средняя температура дня года в Кентукки, °C (январь ~1°, июль ~26°). */
    public static float seasonTemp(double yearDay) {
        return (float) (13.5 - 12.5 * Math.cos(2 * Math.PI * (yearDay - 20) / 365.0));
    }

    /** Суточный ход ±6°: холоднее всего перед рассветом, теплее всего в 15 часов. */
    public static float dayOffset(double hour) {
        return (float) (6.0 * Math.cos(2 * Math.PI * (hour - 15) / 24.0));
    }

    private static double hourOf(World w) {
        return ((Math.floorMod(w.getTimeOfDay(), 24000L) / 1000.0) + 6.0) % 24.0;
    }

    /** Пересчитать текущую температуру (сервер — по своему миру, клиент — по своему). */
    public static void updateBase(World w) {
        baseTemp = seasonTemp(yearDay(w)) + dayOffset(hourOf(w)) + front;
    }

    /** Температура воздуха в точке: сезон, сутки, фронт, биом, высота. */
    public static float tempAt(World w, BlockPos pos) {
        return baseTemp + biomeAdj(w.getBiome(pos).value(), pos);
    }

    private static float biomeAdj(Biome b, BlockPos pos) {
        float t = (b.getTemperature() - 0.8f) * 15f;
        if (pos.getY() > 90) t -= (pos.getY() - 90) * 0.08f;
        return t;
    }

    /** Для миксина биома: холодно ли тут для снега и льда. */
    public static boolean freezing(Biome b, BlockPos pos) {
        return baseTemp + biomeAdj(b, pos) < 0.5f;
    }

    /** Куда дует ветер (единичный вектор по x и z), умноженный на силу. */
    public static double[] windVector() {
        double f = Math.toRadians(windFrom);
        return new double[]{-Math.sin(f) * wind, Math.cos(f) * wind};
    }

    public static String windShort() {
        return DIR_SHORT[Math.floorMod(Math.round(windFrom / 45f), 8)];
    }

    public static int windMs() {
        return Math.round(wind * 18f);
    }

    public static String kindName(int k) {
        return k >= 0 && k < KIND_NAMES.length ? KIND_NAMES[k] : "";
    }

    // =====================================================================================
    //                                       регистрация
    // =====================================================================================

    public record ClimatePayload(NbtCompound data) implements CustomPayload {
        public static final CustomPayload.Id<ClimatePayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "climate"));
        public static final PacketCodec<RegistryByteBuf, ClimatePayload> CODEC =
                PacketCodec.tuple(PacketCodecs.NBT_COMPOUND, ClimatePayload::data, ClimatePayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public static void register() {
        SEASON_SPEED = GameRuleRegistry.register("zomboidSeasonSpeed", GameRules.Category.MISC, GameRuleFactory.createIntRule(1, 1, 60));
        EROSION_DAYS = GameRuleRegistry.register("zomboidErosionDays", GameRules.Category.MISC, GameRuleFactory.createIntRule(100, 0, 36500));
        PayloadTypeRegistry.playS2C().register(ClimatePayload.ID, ClimatePayload.CODEC);

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            ServerWorld w = server.getOverworld();
            state = ClimateState.get(w);
            anchorYear = state.anchorYear;
            anchorDay = state.anchorDay;
            speed = state.speed;
            server.getGameRules().get(GameRules.DO_WEATHER_CYCLE).set(false, server);   // погодой управляем сами
            lastRain = -1;
            refresh(w);
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> state = null);
        ServerPlayConnectionEvents.JOIN.register((h, sender, server) -> ServerPlayNetworking.send(h.getPlayer(), payload()));
        ServerTickEvents.END_SERVER_TICK.register(Climate::tick);
    }

    public static void apply(NbtCompound n) {
        anchorYear = n.getDouble("ay");
        anchorDay = n.getDouble("ad");
        speed = Math.max(1, n.getInt("sp"));
        front = n.getFloat("fr");
        wind = n.getFloat("wi");
        windFrom = n.getFloat("wd");
        kind = n.getInt("k");
    }

    private static ClimatePayload payload() {
        NbtCompound n = new NbtCompound();
        n.putDouble("ay", anchorYear);
        n.putDouble("ad", anchorDay);
        n.putInt("sp", speed);
        n.putFloat("fr", front);
        n.putFloat("wi", wind);
        n.putFloat("wd", windFrom);
        n.putInt("k", kind);
        return new ClimatePayload(n);
    }

    public static ClimateState state(ServerWorld w) {
        if (state == null) state = ClimateState.get(w);
        return state;
    }

    // =====================================================================================
    //                                       погода по дням
    // =====================================================================================

    /** Погода дня (генерируется по цепочке от предыдущего дня и запоминается). */
    public static ClimateState.Day day(ServerWorld w, int d) {
        ClimateState st = state(w);
        ClimateState.Day have = st.days.get(d);
        if (have != null) return have;
        ClimateState.Day prev = st.days.get(d - 1);
        ClimateState.Day nd = generate(w, d, prev);
        st.days.put(d, nd);
        st.days.int2ObjectEntrySet().removeIf(e -> e.getIntKey() < d - 4);
        st.markDirty();
        return nd;
    }

    private static ClimateState.Day generate(ServerWorld w, int d, ClimateState.Day prev) {
        java.util.Random r = new java.util.Random(w.getSeed() * 0x9E3779B97F4A7C15L + d * 7919L);
        double yd = yearDay(w) + (d - Clock.day(w)) * (double) speed;
        Season s = season(yd);
        ClimateState.Day x = new ClimateState.Day();
        float pf = prev == null ? 0f : prev.front;
        boolean wave = prev != null && (prev.heat || prev.cold) && r.nextFloat() < 0.7f;   // волна держится несколько дней
        x.front = (float) (pf * 0.62 + r.nextGaussian() * 2.6);
        if (wave) {
            x.heat = prev.heat && s == Season.SUMMER;
            x.cold = prev.cold && s == Season.WINTER;
            x.front = prev.front + (float) r.nextGaussian();
        } else if (s == Season.SUMMER && r.nextFloat() < 0.06f) {
            x.heat = true;
            x.front = 6f + r.nextFloat() * 3f;
        } else if (s == Season.WINTER && r.nextFloat() < 0.09f) {
            x.cold = true;
            x.front = -8f - r.nextFloat() * 3.5f;
        }
        x.front = MathHelper.clamp(x.front, -13f, 11f);
        float rainChance = switch (s) {
            case SPRING -> 0.42f;
            case SUMMER -> 0.3f;
            case AUTUMN -> 0.36f;
            case WINTER -> 0.32f;
        };
        if (x.heat) rainChance *= 0.4f;
        x.rain = r.nextFloat() < rainChance;
        float stormChance = switch (s) {
            case SPRING -> 0.28f;
            case SUMMER -> 0.35f;
            case AUTUMN -> 0.12f;
            case WINTER -> 0.12f;
        };
        x.storm = x.rain && r.nextFloat() < stormChance;
        x.rainStart = r.nextFloat() * 24f;
        x.rainLen = x.storm ? 2f + r.nextFloat() * 4f : 2f + r.nextFloat() * 9f;
        x.wind = MathHelper.clamp(0.12f + r.nextFloat() * 0.33f + (x.rain ? 0.12f : 0f) + (x.storm ? 0.42f : 0f), 0f, 1f);
        float pd = prev == null ? 225f : prev.windFrom;   // в Кентукки чаще дует с юго-запада
        x.windFrom = (float) Math.floorMod((long) Math.round(pd * 0.7f + 225f * 0.3f + r.nextGaussian() * 55f), 360L);
        x.fog = r.nextFloat() < (s == Season.AUTUMN ? 0.35f : 0.16f) ? 0.5f + r.nextFloat() * 0.5f : 0f;
        if (d <= 1) {   // первый день — тихий летний
            x.rain = x.storm = x.heat = x.cold = false;
            x.front = 0.5f;
            x.wind = 0.25f;
            x.fog = 0f;
        }
        return x;
    }

    private static boolean inRain(ClimateState.Day d, double hour) {
        return d.rain && hour >= d.rainStart && hour < d.rainStart + d.rainLen;
    }

    /** Утренний туман сегодня (0..1) — для тумана в WorldEvents. */
    public static float todayFog(ServerWorld w) {
        return day(w, Clock.day(w)).fog;
    }

    // =====================================================================================
    //                                       каждый тик
    // =====================================================================================
    private static int lastRain = -1;

    private static void tick(MinecraftServer server) {
        ServerWorld w = server.getOverworld();
        if (w == null || state == null) return;
        updateBase(w);
        int ticks = server.getTicks();
        if (ticks % 20 == 0) refresh(w);
        if (ticks % 2 == 0) melt(w);
        if (ticks % 5 == 0) Erosion.tick(w, state);
        if (ticks % 20 == 0) {
            for (ServerPlayerEntity p : w.getPlayers()) snowWalk(w, p);
        }
        if (ticks % 100 == 0) {
            ClimatePayload pl = payload();
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) ServerPlayNetworking.send(p, pl);
        }
    }

    /** Раз в секунду: скорость календаря, фронт, ветер, дождь/снег по расписанию. */
    private static void refresh(ServerWorld w) {
        ClimateState st = state(w);
        int sp = w.getGameRules().getInt(SEASON_SPEED);
        if (sp != st.speed) {   // сменили скорость — календарь продолжается с той же даты
            double now = yearDay(w);
            st.anchorDay = dayFloat(w);
            st.anchorYear = now;
            st.speed = sp;
            st.markDirty();
        }
        anchorYear = st.anchorYear;
        anchorDay = st.anchorDay;
        speed = st.speed;

        int dn = Clock.day(w);
        double hour = hourOf(w);
        ClimateState.Day today = day(w, dn), tomorrow = day(w, dn + 1), yesterday = day(w, dn - 1);
        float k = (float) (hour / 24.0);
        front = today.front + (tomorrow.front - today.front) * k;
        wind = today.wind + (tomorrow.wind - today.wind) * k * 0.5f;
        windFrom = today.windFrom;
        boolean raining = inRain(today, hour) || inRain(yesterday, hour + 24);
        boolean storm = raining && (inRain(today, hour) ? today.storm : yesterday.storm);
        if (raining) wind = Math.max(wind, storm ? 0.75f : 0.4f);

        int code = raining ? (storm ? 2 : 1) : 0;
        if (code != lastRain || w.isRaining() != raining || w.isThundering() != storm) {
            lastRain = code;
            w.setWeather(raining ? 0 : 12000, raining ? 12000 : 0, raining, storm);
        }
        boolean cold = baseTemp < 0.5f;
        if (raining) kind = cold ? (storm ? K_BLIZZARD : K_SNOW) : (storm ? K_STORM : K_RAIN);
        else if (today.heat) kind = K_HEAT;
        else if (today.cold) kind = K_COLD;
        else if (com.example.zomboidmod.survival.WorldEvents.fog > 0.3f) kind = K_FOG;
        else if (today.rain && hour < today.rainStart && today.rainStart - hour < 4) kind = K_CLOUDY;
        else kind = K_CLEAR;
        // сколько снега может лечь: метель наметает сугробы
        int want = raining && cold ? (storm ? 4 : 2) : 1;
        GameRules.IntRule acc = w.getGameRules().get(GameRules.SNOW_ACCUMULATION_HEIGHT);
        if (acc.get() < want || (!raining && acc.get() != 1)) acc.set(want, w.getServer());
    }

    /** Оттепель: снег и лёд тают вокруг игроков (ванильный снег тает только от факелов). */
    private static void melt(ServerWorld w) {
        if (baseTemp < 1.5f && !w.isRaining()) return;
        Random r = w.random;
        for (ServerPlayerEntity p : w.getPlayers()) {
            float t = tempAt(w, p.getBlockPos());
            if (t < 1.5f) continue;
            int n = Math.min(24, (int) ((t - 1f) * 2.5f) + (w.isRaining() ? 3 : 0));
            for (int i = 0; i < n; i++) {
                int x = p.getBlockX() + r.nextInt(97) - 48, z = p.getBlockZ() + r.nextInt(97) - 48;
                if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                BlockPos top = w.getTopPosition(Heightmap.Type.WORLD_SURFACE, new BlockPos(x, 0, z)).down();
                BlockState s = w.getBlockState(top);
                if (s.isOf(Blocks.SNOW)) {
                    int layers = s.get(SnowBlock.LAYERS);
                    w.setBlockState(top, layers > 1 ? s.with(SnowBlock.LAYERS, layers - 1) : Blocks.AIR.getDefaultState());
                } else if (s.getBlock() instanceof com.example.zomboidmod.hunting.TracksBlock && s.get(com.example.zomboidmod.hunting.TracksBlock.SNOW)) {
                    w.setBlockState(top, Blocks.AIR.getDefaultState());
                } else if (s.isOf(Blocks.ICE) && t > 3f) {
                    w.setBlockState(top, Blocks.WATER.getDefaultState());
                }
            }
        }
    }

    /** По снегу идти тяжелее (PZ: в снегу калории сгорают быстрее), за игроком остаются следы. */
    private static void snowWalk(ServerWorld w, ServerPlayerEntity p) {
        if (p.isCreative() || p.isSpectator() || !p.isOnGround()) return;
        BlockPos feet = p.getBlockPos();
        BlockState s = w.getBlockState(feet);
        boolean snow = s.isOf(Blocks.SNOW) || s.isOf(Blocks.SNOW_BLOCK) || w.getBlockState(feet.down()).isOf(Blocks.SNOW_BLOCK);
        if (!snow || p.getVelocity().horizontalLengthSquared() < 0.002) return;
        p.addExhaustion(0.03f);
        if (s.isOf(Blocks.SNOW) && w.random.nextFloat() < 0.6f)
            com.example.zomboidmod.hunting.Tracks.leave(w, feet, com.example.zomboidmod.hunting.Tracks.HUMAN, p.getHorizontalFacing());
    }

    // =====================================================================================
    //                                       урожай
    // =====================================================================================

    /** Для миксина randomTick: true — рост в этот раз отменён (холод), заодно мороз губит урожай. */
    public static boolean blockGrowth(BlockState st, ServerWorld w, BlockPos pos, Random r) {
        Block b = st.getBlock();
        boolean crop = b instanceof CropBlock || b instanceof StemBlock || b instanceof SweetBerryBushBlock || b instanceof CocoaBlock;
        if (!crop && !(b instanceof SaplingBlock) && !(b instanceof SugarCaneBlock)) return false;
        if (w.getRegistryKey() != World.OVERWORLD || !w.isSkyVisible(pos.up())) return false;   // в доме и под крышей растёт
        float t = tempAt(w, pos);
        if (crop && t < -3f && r.nextFloat() < 0.2f) {   // заморозки
            if (b instanceof SweetBerryBushBlock) w.setBlockState(pos, st.with(SweetBerryBushBlock.AGE, 0));
            else w.setBlockState(pos, Blocks.AIR.getDefaultState());
            return true;
        }
        if (t < 4f) return true;
        return t < 10f && r.nextBoolean();
    }

    // =====================================================================================
    //                                       прогноз
    // =====================================================================================

    private static String signed(float v) {
        int i = Math.round(v);
        return (i > 0 ? "+" : "") + i;
    }

    private static String partOfDay(float h) {
        if (h < 6) return "ночью";
        if (h < 12) return "утром";
        if (h < 18) return "днём";
        return "вечером";
    }

    /** Прогноз на день d (для радио и ТВ). */
    public static String forecast(ServerWorld w, int d, boolean full) {
        ClimateState.Day x = day(w, d);
        double yd = yearDay(w) + (d - Clock.day(w)) * (double) speed;
        float base = seasonTemp(Math.floor(yd) + 0.5) + x.front;
        float max = base + 6f, min = base - 6f;
        StringBuilder sb = new StringBuilder();
        sb.append("днём ").append(signed(max)).append("°C, ночью ").append(signed(min)).append("°C");
        String dir = DIR_ADJ[Math.floorMod(Math.round(x.windFrom / 45f), 8)];
        String force = x.wind < 0.25f ? "слабый" : x.wind < 0.5f ? "умеренный" : x.wind < 0.75f ? "сильный" : "штормовой";
        sb.append(", ветер ").append(dir).append(", ").append(force);
        if (full) sb.append(" (").append(Math.round(x.wind * 18f)).append(" м/с)");
        if (x.rain) {
            boolean snow = min + (max - min) * 0.4f < 1f;
            String what = snow ? (x.storm ? "метель" : "снег") : (x.storm ? "гроза с ливнем" : "дождь");
            sb.append(". ").append(Character.toUpperCase(what.charAt(0))).append(what.substring(1)).append(" ").append(partOfDay(x.rainStart));
        } else {
            sb.append(". Без осадков");
        }
        if (x.fog > 0) sb.append(", утром туман");
        if (x.heat) sb.append(". Аномальная жара: пейте больше воды");
        if (x.cold) sb.append(". Сильные морозы: берегитесь обморожения");
        return sb.append('.').toString();
    }
}
