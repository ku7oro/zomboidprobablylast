package com.example.zomboidmod.media;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.PzTrait;
import com.example.zomboidmod.SkillState;
import com.example.zomboidmod.Skills;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashMap;
import java.util.Map;

/**
 * Знания персонажа, как в PZ: часть рецептов открывают только журналы (или достаточный навык).
 * Просмотренные кассеты тоже запоминаются — второй раз опыта не дают.
 */
public final class Knowledge {
    private Knowledge() {
    }

    /** Чему учит рецепт: ключ журнала и навык, которого хватит и без журнала (null — только журнал). */
    public record Gate(String key, PzSkill skill, int level) {}

    private static final Map<Item, Gate> GATES = new HashMap<>();

    /** Дополнительные условия крафта (газ в горелке, бензин в канистре...): null — можно, иначе — почему нельзя. */
    public interface CraftRule {
        String check(ServerPlayerEntity p, net.minecraft.inventory.RecipeInputInventory in, ItemStack out);
    }

    private static final java.util.List<CraftRule> RULES = new java.util.ArrayList<>();

    public static void rule(CraftRule r) {
        RULES.add(r);
    }

    /** Итоговая проверка крафта: null — можно. */
    public static String check(ServerPlayerEntity p, net.minecraft.inventory.RecipeInputInventory in, ItemStack out) {
        if (p.isCreative()) return null;
        if (!allowed(p, out)) return why(out);
        for (CraftRule r : RULES) {
            String w = r.check(p, in, out);
            if (w != null) return w;
        }
        return null;
    }

    /** Названия журналов по ключу — для подсказок. */
    public static final Map<String, String> TITLES = new HashMap<>();

    public static void gate(Item result, String key, PzSkill skill, int level) {
        if (result != null) GATES.put(result, new Gate(key, skill, level));
    }

    public static Gate gateOf(Item item) {
        return GATES.get(item);
    }

    public static boolean knows(ServerPlayerEntity p, String key) {
        return Skills.of(p).known.contains(key);
    }

    /** Узнать; true — новое знание. */
    public static boolean learn(ServerPlayerEntity p, String key) {
        boolean added = Skills.of(p).known.add(key);
        if (added) SkillState.get(p.getServer()).markDirty();
        return added;
    }

    /** Можно ли скрафтить этот результат. */
    public static boolean allowed(ServerPlayerEntity p, ItemStack out) {
        Gate g = GATES.get(out.getItem());
        if (g == null || p.isCreative()) return true;
        if (knows(p, g.key())) return true;
        if (g.key().equals("herbal") && Skills.has(p, PzTrait.HERBALIST)) return true;
        if (g.key().equals("welding") && Skills.of(p).profession == com.example.zomboidmod.Profession.METALWORKER.ordinal()) return true;
        return g.skill() != null && Skills.level(p, g.skill()) >= g.level();
    }

    /** Почему нельзя (для строки состояния). */
    public static String why(ItemStack out) {
        Gate g = GATES.get(out.getItem());
        if (g == null) return "";
        String mag = TITLES.getOrDefault(g.key(), g.key());
        return "Вы не знаете, как это сделать. Нужен журнал «" + mag + "»"
                + (g.skill() != null ? " или навык «" + g.skill().title + "» " + g.level() + " ур." : "");
    }

    /** Отличает ли ядовитые ягоды/грибы: черта «Травник», журнал «Лесная аптека» или навык собирательства. */
    public static boolean identifies(ServerPlayerEntity p, boolean mushroom) {
        if (Skills.has(p, PzTrait.HERBALIST) || knows(p, "herbal")) return true;
        return Skills.level(p, PzSkill.FORAGING) >= (mushroom ? 5 : 3);
    }
}
