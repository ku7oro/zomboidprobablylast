package com.example.zomboidmod.media;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Журналы с рецептами и видеокассеты (как в PZ). Журнал читается раз и навсегда открывает рецепты.
 * Кассету смотрят на телевизоре (нужен ток): полминуты — и заметный опыт в навыке, один раз на кассету.
 */
public final class Media {
    private Media() {
    }

    public static Item MAG_ENGINEER, MAG_WELDING, MAG_GARDEN, MAG_HERBAL, MAG_KITCHEN;
    public static final List<Item> MAGAZINES = new ArrayList<>(), TAPES = new ArrayList<>();

    private static Item reg(String id, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
    }

    public static void register() {
        MAG_ENGINEER = mag("mag_engineer", "engineer", "Инженер-самоучка", "Самодельная бомба, дымовая шашка, шумовая приманка");
        MAG_WELDING = mag("mag_welding", "welding", "Сварка для всех", "Сварная стена, лист на окно, броня для машины");
        MAG_GARDEN = mag("mag_garden", "garden", "Сад и огород", "Удобрение и средство от вредителей");
        MAG_HERBAL = mag("mag_herbal", "herbal", "Лесная аптека", "Припарки из трав, ромашковый чай; как отличить ядовитые ягоды и грибы");
        MAG_KITCHEN = mag("mag_kitchen", "kitchen", "Домашняя кухня", "Тесто и пироги");
        tape("vhs_carpentry", "Сам себе плотник", PzSkill.CARPENTRY);
        tape("vhs_cooking", "Кухня за 30 минут", PzSkill.COOKING);
        tape("vhs_farming", "Огород круглый год", PzSkill.FARMING);
        tape("vhs_first_aid", "Первая помощь дома", PzSkill.FIRST_AID);
        tape("vhs_mechanics", "Ремонт авто своими руками", PzSkill.MECHANICS);
        tape("vhs_metal", "Сварка: первые шаги", PzSkill.METALWORKING);
        tape("vhs_foraging", "Дары леса", PzSkill.FORAGING);
        tape("vhs_fishing", "Клёвое место", PzSkill.FISHING);
        tape("vhs_home", "Домашнее видео", null);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            MAGAZINES.forEach(e::add);
            TAPES.forEach(e::add);
        });
        ServerTickEvents.END_SERVER_TICK.register(Media::tick);
    }

    private static Item mag(String id, String key, String title, String teaches) {
        Knowledge.TITLES.put(key, title);
        Item it = reg(id, new Magazine(new Item.Settings().maxCount(1), key, title, teaches));
        MAGAZINES.add(it);
        return it;
    }

    private static void tape(String id, String title, PzSkill skill) {
        TAPES.add(reg(id, new Tape(new Item.Settings().maxCount(1), id, title, skill)));
    }

    // =====================================================================================
    //                                       журнал
    // =====================================================================================
    public static class Magazine extends Item {
        final String key, title, teaches;

        Magazine(Settings s, String key, String title, String teaches) {
            super(s);
            this.key = key;
            this.title = title;
            this.teaches = teaches;
        }

        @Override
        public Text getName(ItemStack stack) {
            return Text.literal("Журнал «" + title + "»");
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal("Учит: " + teaches).formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Зажмите ПКМ, чтобы прочитать").formatted(Formatting.DARK_GRAY));
        }

        @Override
        public UseAction getUseAction(ItemStack stack) {
            return UseAction.NONE;
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            return 70;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            user.setCurrentHand(hand);
            return TypedActionResult.consume(user.getStackInHand(hand));
        }

        @Override
        public void usageTick(World world, LivingEntity user, ItemStack stack, int remaining) {
            if (!world.isClient && remaining % 18 == 0)
                world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.PLAYERS, 0.6f, 1.1f);
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (!world.isClient && user instanceof ServerPlayerEntity p) {
                if (Knowledge.learn(p, key)) {
                    p.sendMessage(Text.literal("Прочитано «" + title + "». Теперь вы умеете: " + teaches).formatted(Formatting.GREEN), false);
                    com.example.zomboidmod.survival.Mood m = com.example.zomboidmod.survival.Survival.mood(p);
                    m.boredom = Math.max(0f, m.boredom - 15f);
                } else {
                    p.sendMessage(Text.literal("Этот журнал вы уже читали").formatted(Formatting.GRAY), true);
                }
            }
            return stack;
        }
    }

    // =====================================================================================
    //                                       кассеты
    // =====================================================================================
    public static class Tape extends Item {
        final String id, title;
        final PzSkill skill;

        Tape(Settings s, String id, String title, PzSkill skill) {
            super(s);
            this.id = id;
            this.title = title;
            this.skill = skill;
        }

        @Override
        public Text getName(ItemStack stack) {
            return Text.literal("Видеокассета «" + title + "»");
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(skill != null ? "Обучающее видео: " + skill.title : "Чья-то свадьба, пикник, дети... Жизнь до конца света")
                    .formatted(Formatting.GRAY));
            tooltip.add(Text.literal("ПКМ по телевизору (нужен ток), смотреть полминуты рядом").formatted(Formatting.DARK_GRAY));
        }
    }

    /** Кто что смотрит: игрок → (телевизор, кассета, тиков осталось). */
    private record Watch(ServerWorld w, BlockPos tv, Tape tape, int[] left) {}

    private static final Map<UUID, Watch> WATCHING = new HashMap<>();
    private static final int WATCH_TICKS = 600;

    /** ПКМ по телевизору кассетой. */
    public static ItemActionResult useTape(ItemStack stack, World world, BlockPos pos, PlayerEntity player) {
        if (!(stack.getItem() instanceof Tape t)) return null;
        if (world.isClient) return ItemActionResult.SUCCESS;
        if (!(player instanceof ServerPlayerEntity p) || !(world instanceof ServerWorld w)) return ItemActionResult.CONSUME;
        if (!com.example.zomboidmod.survival.Power.powered(w, pos)) {
            p.sendMessage(Text.literal("Телевизор не включается: нет электричества").formatted(Formatting.GRAY), true);
            return ItemActionResult.CONSUME;
        }
        if (t.skill != null && Knowledge.knows(p, "vhs:" + t.id)) {
            p.sendMessage(Text.literal("Эту кассету вы уже смотрели — ничего нового").formatted(Formatting.GRAY), true);
            return ItemActionResult.CONSUME;
        }
        WATCHING.put(p.getUuid(), new Watch(w, pos.toImmutable(), t, new int[]{WATCH_TICKS}));
        p.sendMessage(Text.literal("Кассета «" + t.title + "»: смотрите, не отходя от экрана").formatted(Formatting.AQUA), true);
        w.playSound(null, pos, SoundEvents.BLOCK_DISPENSER_DISPENSE, SoundCategory.BLOCKS, 0.6f, 1.5f);
        return ItemActionResult.CONSUME;
    }

    private static void tick(MinecraftServer server) {
        for (Iterator<Map.Entry<UUID, Watch>> it = WATCHING.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Watch> en = it.next();
            Watch wt = en.getValue();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
            if (p == null || !p.isAlive() || p.getServerWorld() != wt.w() || p.squaredDistanceTo(wt.tv().toCenterPos()) > 36
                    || !com.example.zomboidmod.survival.Power.powered(wt.w(), wt.tv())) {
                if (p != null) p.sendMessage(Text.literal("Просмотр прерван").formatted(Formatting.GRAY), true);
                it.remove();
                continue;
            }
            int left = --wt.left()[0];
            if (left % 20 == 0) {
                wt.w().spawnParticles(ParticleTypes.ELECTRIC_SPARK, wt.tv().getX() + 0.5, wt.tv().getY() + 0.7, wt.tv().getZ() + 0.5, 2, 0.25, 0.15, 0.25, 0.01);
                int sec = (WATCH_TICKS - left) / 20;
                p.sendMessage(Text.literal("Смотрите «" + wt.tape().title + "»: " + sec + " / " + WATCH_TICKS / 20 + " с").formatted(Formatting.AQUA), true);
            }
            if (left % 100 == 0 && wt.tape().skill != null) Skills.addXp(p, wt.tape().skill, 40f);
            if (left <= 0) {
                it.remove();
                if (wt.tape().skill != null) {
                    Knowledge.learn(p, "vhs:" + wt.tape().id);
                    p.sendMessage(Text.literal("Кассета досмотрена: навык «" + wt.tape().skill.title + "» подрос").formatted(Formatting.GREEN), false);
                } else {
                    com.example.zomboidmod.survival.Mood m = com.example.zomboidmod.survival.Survival.mood(p);
                    m.boredom = Math.max(0f, m.boredom - 40f);
                    m.unhappy = Math.max(0f, m.unhappy - 12f);
                    m.stress = Math.max(0f, m.stress - 10f);
                    p.sendMessage(Text.literal("Чужая счастливая жизнь на экране... Стало чуть теплее на душе").formatted(Formatting.GREEN), false);
                }
            }
        }
    }
}
