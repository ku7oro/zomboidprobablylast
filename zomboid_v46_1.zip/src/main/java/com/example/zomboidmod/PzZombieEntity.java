package com.example.zomboidmod;

import com.example.zomboidmod.combat.Combat;
import com.example.zomboidmod.combat.LimbEntity;
import com.example.zomboidmod.combat.Limbs;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** Зомби в духе Project Zomboid: одежда, повадки (шатун, бегун, ползун), шум, вещи в карманах. */
public class PzZombieEntity extends ZombieEntity {
    private static final TrackedData<Integer> VARIANT =
            DataTracker.registerData(PzZombieEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private BlockPos noisePos;
    private int noiseTicks;
    private boolean lootRolled;

    public PzZombieEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(VARIANT, -1);
        builder.add(FEEDING, false);
        builder.add(DOWN_AT, -1);
        builder.add(DOWN_INFO, 0);
        builder.add(FALL_FACE, false);
        builder.add(LIMBS, 0);
        builder.add(CRAWL_AT, -1);
    }

    // ===================== падения: сбит с ног / убит =====================
    /** Когда сбит (младшие биты времени мира) и сколько лежит (младшие 15 бит) + ничком (бит 15). */
    private static final TrackedData<Integer> DOWN_AT = DataTracker.registerData(PzZombieEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> DOWN_INFO = DataTracker.registerData(PzZombieEntity.class, TrackedDataHandlerRegistry.INTEGER);
    /** Куда упадёт мёртвым: true — ничком (ударили в спину), false — навзничь. */
    private static final TrackedData<Boolean> FALL_FACE = DataTracker.registerData(PzZombieEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    private int staggerUntil;

    private int nowLow() {
        return (int) (this.getWorld().getTime() & 0x3FFFFFFFL);
    }

    /** Сбить с ног: лежит len тиков, потом встаёт (Knockdown.Z_GETUP). */
    public void knockDown(int len, boolean faceDown) {
        if (this.getWorld().isClient || !this.isAlive() || isCrawler() || isDown() || kind() == ZombieKind.CARRIER) return;
        if (isBrute()) len /= 2;
        this.getDataTracker().set(DOWN_INFO, Math.min(len, 0x7FFF) | (faceDown ? 0x8000 : 0));
        this.getDataTracker().set(DOWN_AT, nowLow());
        this.getNavigation().stop();
        this.playSound(net.minecraft.sound.SoundEvents.ENTITY_PLAYER_BIG_FALL, 0.9f, 0.7f);
    }

    /** Сколько тиков прошло с падения (на клиенте — с долей тика), -1 — не лежит. */
    public float downElapsed(float tickDelta) {
        int at = this.getDataTracker().get(DOWN_AT);
        if (at < 0) return -1f;
        int el = (nowLow() - at) & 0x3FFFFFFF;
        float e = el + tickDelta;
        return e > downLen() + com.example.zomboidmod.motion.Knockdown.Z_GETUP ? -1f : e;
    }

    public int downLen() {
        return this.getDataTracker().get(DOWN_INFO) & 0x7FFF;
    }

    public boolean downFace() {
        return (this.getDataTracker().get(DOWN_INFO) & 0x8000) != 0;
    }

    /** Лежит (или ещё поднимается). */
    public boolean isDown() {
        return downElapsed(0f) >= 0f;
    }

    /** Упадёт ли ничком, если толкнуть / ударить отсюда: удар в спину — ничком. */
    public boolean fallsFaceDown(net.minecraft.util.math.Vec3d from) {
        net.minecraft.util.math.Vec3d fwd = net.minecraft.util.math.Vec3d.fromPolar(0f, this.bodyYaw);
        net.minecraft.util.math.Vec3d to = from.subtract(this.getPos()).multiply(1, 0, 1);
        if (to.lengthSquared() < 1e-4) return this.getRandom().nextBoolean();
        return fwd.dotProduct(to.normalize()) < 0;
    }

    public boolean deathFaceDown() {
        return this.getDataTracker().get(FALL_FACE);
    }

    @Override
    public boolean damage(net.minecraft.entity.damage.DamageSource source, float amount) {
        if (this.getWorld().isClient) return super.damage(source, amount);
        // куда пришёлся удар и чем
        Limbs.Part part = aimPart;
        Limbs.Hit hit = aimHit;
        boolean heavy = aimHeavy;
        float power = 1f;
        aimPart = null;
        net.minecraft.entity.Entity att = source.getAttacker();
        if (part == null && this.isAlive()) {
            if (source.isIn(net.minecraft.registry.tag.DamageTypeTags.IS_EXPLOSION)) {
                hit = Limbs.Hit.BLAST;
                part = Limbs.Part.values()[2 + this.getRandom().nextInt(4)];
            } else if (source.isIn(net.minecraft.registry.tag.DamageTypeTags.IS_FALL)) {
                hit = Limbs.Hit.FALL;
                part = this.getRandom().nextBoolean() ? Limbs.Part.LEG_R : Limbs.Part.LEG_L;
            } else if (source.isIn(net.minecraft.registry.tag.DamageTypeTags.IS_PROJECTILE) && source.getSource() != null) {
                hit = Limbs.Hit.PIERCE;
                power = 0.5f;
                part = locate(source.getSource().getPos());
            } else if (att instanceof net.minecraft.entity.player.PlayerEntity pl && source.getSource() == pl) {
                if (pl.getVehicle() instanceof com.example.zomboidmod.vehicle.VehicleEntity) {   // сбит машиной: по ногам
                    hit = Limbs.Hit.RAM;
                    part = this.getRandom().nextBoolean() ? Limbs.Part.LEG_R : Limbs.Part.LEG_L;
                } else {
                    net.minecraft.item.ItemStack w = pl.getMainHandStack();
                    hit = Limbs.hitOf(w);
                    power = Limbs.powerOf(w);
                    PzSkill ws = Skills.weaponSkill(w);   // мастер рубит и ломает вернее
                    if (ws != null && pl instanceof net.minecraft.server.network.ServerPlayerEntity sp && (hit == Limbs.Hit.BLADE || hit == Limbs.Hit.BLUNT))
                        power *= 1f + 0.03f * Skills.level(sp, ws);
                    part = locate(aimPoint(pl));
                }
            }
        }
        if (part != null) part = redirect(part);
        if (att instanceof net.minecraft.entity.player.PlayerEntity) {
            if (isDown()) amount *= 1.6f;   // лежачего добивают
            else if (!source.isIn(net.minecraft.registry.tag.DamageTypeTags.IS_PROJECTILE))
                staggerUntil = this.age + (isBrute() ? 4 : 9);   // от удара пошатнулся
        }
        // куда упадёт, если этот удар смертельный
        net.minecraft.util.math.Vec3d from = source.getPosition();
        if (from != null) this.getDataTracker().set(FALL_FACE, fallsFaceDown(from));
        boolean boss = kind() == ZombieKind.CARRIER;
        float dealt = amount;
        if (part != null && !boss) {
            dealt = amount * Limbs.healthMult(part, hit, power);
            // клинок дорубил шею — этот удар последний
            if (part == Limbs.Part.HEAD && hit == Limbs.Hit.BLADE && power >= 0.6f
                    && cut[0] + amount * power >= Limbs.severAt(part) * limbBase()) dealt = Math.max(dealt, this.getHealth() * 3f + 20f);
        }
        boolean ok = super.damage(source, dealt);
        if (ok && part != null && !boss) anatomy(part, hit, amount, power, heavy, att, from);
        return ok;
    }

    // ===================== тело по частям: руки, ноги, челюсть, голова =====================
    private static final TrackedData<Integer> LIMBS = DataTracker.registerData(PzZombieEntity.class, TrackedDataHandlerRegistry.INTEGER);
    /** Когда рухнул на землю, лишившись ног (младшие биты времени мира): для плавного падения на клиенте. */
    private static final TrackedData<Integer> CRAWL_AT = DataTracker.registerData(PzZombieEntity.class, TrackedDataHandlerRegistry.INTEGER);
    /** Сколько «прорублено» и «раздроблено» в каждой части тела (порядок как в Limbs.Part). */
    private final float[] cut = new float[6], crush = new float[6];
    private Limbs.Part aimPart;
    private Limbs.Hit aimHit = Limbs.Hit.OTHER;
    private boolean aimHeavy;
    private int bleedUntil;

    /** Что оторвано и сломано (биты Limbs). Прирождённый ползун — без ног. */
    public int limbs() {
        if (this.getDataTracker() == null) return 0;
        int l = this.getDataTracker().get(LIMBS);
        if (kind() == ZombieKind.CRAWLER) l |= Limbs.LEG_R | Limbs.LEG_L;
        return l;
    }

    public int armsUsable() {
        return Limbs.armsUsable(limbs());
    }

    public boolean jawBroken() {
        return Limbs.jawBroken(limbs());
    }

    /** Насколько уже лёг (0..1) после того, как лишился ног. */
    public float crawlLie(float tickDelta) {
        int at = this.getDataTracker().get(CRAWL_AT);
        if (at < 0) return 1f;
        float e = ((nowLow() - at) & 0x3FFFFFFF) + tickDelta;
        return e >= 9f ? 1f : com.example.zomboidmod.motion.FallAnim.smooth(e / 9f);
    }

    /** Выстрел: оружие само знает точку попадания. Возвращает true, если попали в голову. */
    public boolean aimShot(net.minecraft.util.math.Vec3d hitPos, boolean heavy) {
        aimPart = locate(hitPos);
        aimHit = Limbs.Hit.SHOT;
        aimHeavy = heavy;
        return aimPart == Limbs.Part.HEAD;
    }

    /** Точка на теле, в которую смотрит бьющий. */
    private net.minecraft.util.math.Vec3d aimPoint(net.minecraft.entity.player.PlayerEntity pl) {
        net.minecraft.util.math.Vec3d eye = pl.getEyePos(), look = pl.getRotationVec(1f);
        net.minecraft.util.math.Box box = this.getBoundingBox().expand(0.12);
        if (box.contains(eye)) return eye.add(look.multiply(0.35));
        // луч мимо (удар по дуге задел соседа) — считаем, что пришлось в корпус
        return box.raycast(eye, eye.add(look.multiply(7.0))).orElse(new net.minecraft.util.math.Vec3d(this.getX(), this.getY() + this.getHeight() * 0.6, this.getZ()));
    }

    /** В какую часть тела пришлась эта точка. */
    public Limbs.Part locate(net.minecraft.util.math.Vec3d p) {
        double rad = Math.toRadians(this.bodyYaw);
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        double dx = p.x - this.getX(), dz = p.z - this.getZ();
        double along = dx * fx + dz * fz, lat = dx * -fz + dz * fx;   // вперёд и вправо (от самого мертвеца)
        double w = Math.max(0.3, this.getWidth());
        if (isDown()) {                      // лежит сбитый: бьют сверху куда придётся, чаще — по голове
            float r = this.getRandom().nextFloat();
            if (r < 0.4f) return Limbs.Part.HEAD;
            if (r < 0.7f) return Limbs.Part.TORSO;
            return Limbs.Part.values()[2 + this.getRandom().nextInt(4)];
        }
        if (isCrawler()) {                   // ползёт: голова впереди, ноги сзади
            double a = along / (w * 0.5);
            if (a > 0.3) return Limbs.Part.HEAD;
            if (a < -0.3) return lat >= 0 ? Limbs.Part.LEG_R : Limbs.Part.LEG_L;
            if (Math.abs(lat) > w * 0.28) return lat >= 0 ? Limbs.Part.ARM_R : Limbs.Part.ARM_L;
            return Limbs.Part.TORSO;
        }
        double h = (p.y - this.getY()) / Math.max(0.5, this.getHeight());
        if (h >= 0.77) return Limbs.Part.HEAD;
        if (h < 0.40) return lat >= 0 ? Limbs.Part.LEG_R : Limbs.Part.LEG_L;
        if (Math.abs(lat) > w * 0.27) return lat >= 0 ? Limbs.Part.ARM_R : Limbs.Part.ARM_L;
        return Limbs.Part.TORSO;
    }

    /** Попали туда, где конечности уже нет: удар приходится в соседнюю часть. */
    private Limbs.Part redirect(Limbs.Part part) {
        int l = limbs();
        if (part.arm() && (l & part.gone) != 0) return Limbs.Part.TORSO;
        if (part.leg() && (l & part.gone) != 0) {
            Limbs.Part other = part == Limbs.Part.LEG_R ? Limbs.Part.LEG_L : Limbs.Part.LEG_R;
            return (l & other.gone) == 0 ? other : Limbs.Part.TORSO;
        }
        return part;
    }

    /** От чего считаются пороги: у здоровяков кости крепче, броня держит удар. */
    private float limbBase() {
        return this.getMaxHealth() * (kind() == ZombieKind.ARMORED ? 1.6f : 1f);
    }

    /** Последствия попадания: копится урон по части тела — рубится, ломается, отлетает. */
    private void anatomy(Limbs.Part part, Limbs.Hit hit, float raw, float power, boolean heavy, net.minecraft.entity.Entity att,
                         net.minecraft.util.math.Vec3d from) {
        if (!(this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) || part == Limbs.Part.TORSO) return;
        int i = part.ordinal();
        switch (hit) {
            case BLADE -> cut[i] += raw * power;
            case BLUNT -> crush[i] += raw * power;
            case PIERCE -> crush[i] += raw * 0.3f;
            case SHOT -> {
                crush[i] += raw * 1.6f;   // пуля дробит кость
                cut[i] += raw * (heavy ? 0.7f : 0.4f);
            }
            case BLAST -> {
                crush[i] += raw;
                cut[i] += raw;
            }
            case RAM -> crush[i] += raw * 0.9f;
            case FALL -> crush[i] += raw * 2.5f;   // упал с высоты — ноги не выдержали
            default -> {
                return;
            }
        }
        float base = limbBase();
        boolean dead = this.isDead();
        int l = this.getDataTracker().get(LIMBS);
        net.minecraft.server.network.ServerPlayerEntity who = att instanceof net.minecraft.server.network.ServerPlayerEntity sp ? sp : null;
        if (part == Limbs.Part.HEAD) {
            if ((l & Limbs.HEAD) != 0) return;
            boolean chopped = hit == Limbs.Hit.BLADE && power >= 0.6f && dead && (cut[0] >= Limbs.severAt(part) * base || power >= 0.9f);
            boolean burst = dead && ((hit == Limbs.Hit.SHOT && heavy) || (hit == Limbs.Hit.BLAST && this.getRandom().nextBoolean())
                    || (hit == Limbs.Hit.BLUNT && raw * power >= base * 0.5f));
            if (chopped || burst) {
                this.getDataTracker().set(LIMBS, l | Limbs.HEAD);
                net.minecraft.util.math.Vec3d at = new net.minecraft.util.math.Vec3d(this.getX(), this.getY() + this.getHeight() * 0.9, this.getZ());
                if (chopped) {
                    LimbEntity.spawn(sw, this, part, at, from);
                    sw.playSound(null, this.getBlockPos(), Combat.CHOP, net.minecraft.sound.SoundCategory.HOSTILE, 1.0f, 0.85f + this.getRandom().nextFloat() * 0.15f);
                } else {
                    sw.playSound(null, this.getBlockPos(), Combat.SPLAT, net.minecraft.sound.SoundCategory.HOSTILE, 1.1f, 0.9f + this.getRandom().nextFloat() * 0.2f);
                }
                Combat.gore(sw, at, chopped ? 26 : 60, chopped ? 0.18 : 0.3);
                Combat.stain(sw, this.getBlockPos(), this.getRandom());
                Combat.tell(who, chopped ? "Голова с плеч" : "Голова разнесена");
                return;
            }
            // челюсть: дробящий удар в лицо, реже — пуля
            if (!dead && (l & Limbs.JAW) == 0) {
                float chance = hit == Limbs.Hit.BLUNT ? raw * power / (0.35f * base) : hit == Limbs.Hit.SHOT ? 0.2f : 0f;
                if (this.getRandom().nextFloat() < chance) {
                    this.getDataTracker().set(LIMBS, l | Limbs.JAW);
                    sw.playSound(null, this.getBlockPos(), Combat.CRACK, net.minecraft.sound.SoundCategory.HOSTILE, 1.0f, 1.15f + this.getRandom().nextFloat() * 0.15f);
                    Combat.gore(sw, new net.minecraft.util.math.Vec3d(this.getX(), this.getEyeY() - 0.15, this.getZ()), 8, 0.1);
                    Combat.tell(who, armsUsable() == 0 ? "Челюсть сломана — теперь он безвреден" : "Челюсть сломана — укусить не сможет");
                }
            }
            return;
        }
        if ((l & part.gone) != 0) return;
        if (cut[i] >= Limbs.severAt(part) * base) sever(sw, part, hit, who, from);
        else if ((l & part.broken) == 0 && crush[i] >= Limbs.breakAt(part) * base) fracture(sw, part, who);
    }

    /** Конечность отлетает. */
    private void sever(net.minecraft.server.world.ServerWorld sw, Limbs.Part part, Limbs.Hit hit,
                       net.minecraft.server.network.ServerPlayerEntity who, net.minecraft.util.math.Vec3d from) {
        boolean crawled = isCrawler();
        int l = (this.getDataTracker().get(LIMBS) | part.gone) & ~part.broken;
        this.getDataTracker().set(LIMBS, l);
        double rad = Math.toRadians(this.bodyYaw);
        double side = part == Limbs.Part.ARM_R || part == Limbs.Part.LEG_R ? 1 : -1;
        double off = (part.arm() ? 0.34 : 0.12) * side * this.getScale();
        net.minecraft.util.math.Vec3d at = new net.minecraft.util.math.Vec3d(this.getX() - Math.cos(rad) * off,
                this.getY() + this.getHeight() * (crawled ? 0.5 : part.arm() ? 0.62 : 0.25), this.getZ() - Math.sin(rad) * off);
        LimbEntity.spawn(sw, this, part, at, from);
        sw.playSound(null, this.getBlockPos(), Combat.CHOP, net.minecraft.sound.SoundCategory.HOSTILE, 1.0f, 0.95f + this.getRandom().nextFloat() * 0.2f);
        Combat.gore(sw, at, 22, 0.16);
        Combat.stain(sw, this.getBlockPos(), this.getRandom());
        bleedUntil = this.age + 500;
        if (part == Limbs.Part.ARM_R && !this.getMainHandStack().isEmpty()) {   // что держал — выронил
            super.dropStack(this.getMainHandStack().copy(), 0.8f);
            this.equipStack(net.minecraft.entity.EquipmentSlot.MAINHAND, net.minecraft.item.ItemStack.EMPTY);
        }
        String verb = hit == Limbs.Hit.BLADE ? "Отрублена " : "Оторвана ";
        String tail = "";
        if (part.leg() && !crawled && this.isAlive()) {
            collapse();
            tail = " — мертвец упал и ползёт";
        } else if (part.arm() && this.isAlive()) {
            int arms = Limbs.armsUsable(l);
            tail = arms == 0 ? (Limbs.jawBroken(l) ? " — теперь он безвреден" : " — схватить ему нечем, но зубы целы") : "";
        }
        Combat.tell(who, verb + part.title + tail);
    }

    /** Кость сломана: рука висит плетью, на ногу не опереться. */
    private void fracture(net.minecraft.server.world.ServerWorld sw, Limbs.Part part, net.minecraft.server.network.ServerPlayerEntity who) {
        boolean crawled = isCrawler();
        int l = this.getDataTracker().get(LIMBS) | part.broken;
        this.getDataTracker().set(LIMBS, l);
        sw.playSound(null, this.getBlockPos(), Combat.CRACK, net.minecraft.sound.SoundCategory.HOSTILE, 1.0f, 0.9f + this.getRandom().nextFloat() * 0.2f);
        String tail;
        if (part.leg()) {
            if (!crawled && Limbs.crawls(l) && this.isAlive()) {
                collapse();
                tail = " — обе ноги перебиты, мертвец упал и ползёт";
            } else tail = crawled ? "" : " — хромает";
        } else {
            int arms = Limbs.armsUsable(l);
            tail = arms == 0 ? (Limbs.jawBroken(l) ? " — теперь он безвреден" : " — схватить ему нечем, но зубы целы") : " — висит плетью";
        }
        Combat.tell(who, "Сломана " + part.title + tail);
    }

    /** Ноги больше не держат: падает и дальше только ползёт. */
    private void collapse() {
        this.getDataTracker().set(DOWN_AT, -1);
        this.getDataTracker().set(CRAWL_AT, nowLow());
        this.getNavigation().stop();
        this.setPose(EntityPose.SWIMMING);
        this.calculateDimensions();
        this.playSound(net.minecraft.sound.SoundEvents.ENTITY_PLAYER_BIG_FALL, 0.9f, 0.75f);
        setAttr(EntityAttributes.GENERIC_MOVEMENT_SPEED, limbSpeed(kind().idleSpeed, false));
    }

    /** Скорость с учётом того, что осталось от тела. */
    private double limbSpeed(double sp, boolean chasing) {
        int l = limbs();
        if (isCrawler()) {
            if (kind() != ZombieKind.CRAWLER) sp = Math.min(sp, chasing ? ZombieKind.CRAWLER.chaseSpeed : ZombieKind.CRAWLER.idleSpeed);
            int arms = Limbs.armsUsable(l);
            return sp * (arms == 2 ? 1.0 : arms == 1 ? 0.65 : 0.3);   // без рук — извивается на месте
        }
        return Limbs.limps(l) ? sp * 0.6 : sp;
    }

    @Override
    public void onTrackedDataSet(TrackedData<?> data) {
        super.onTrackedDataSet(data);
        if (LIMBS.equals(data) || VARIANT.equals(data)) this.calculateDimensions();
    }

    /** Ест тело (сидит над ним): видит хуже, его легче обойти. */
    private static final TrackedData<Boolean> FEEDING =
            DataTracker.registerData(PzZombieEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    public boolean feeding() {
        return this.getDataTracker().get(FEEDING);
    }

    // ===================== тело после смерти =====================
    /** Пока true — всё, что зомби «роняет», складывается в его тело. */
    private boolean collecting;
    private final java.util.List<net.minecraft.item.ItemStack> pendingLoot = new java.util.ArrayList<>();
    private boolean bodyDone;
    private com.example.zomboidmod.life.BodyEntity food;

    @Override
    public net.minecraft.entity.ItemEntity dropStack(net.minecraft.item.ItemStack stack, float yOffset) {
        if (collecting) {
            if (!stack.isEmpty()) pendingLoot.add(stack.copy());
            return null;
        }
        return super.dropStack(stack, yOffset);
    }

    /** Вещи мертвеца без самого мертвеца (для тел, которые уже лежат в мире). */
    public java.util.List<net.minecraft.item.ItemStack> rollLoot() {
        collecting = true;
        try {
            ZombieLoot.drop(this, outfit(), this.getRandom());
        } finally {
            collecting = false;
        }
        java.util.List<net.minecraft.item.ItemStack> out = new java.util.ArrayList<>(pendingLoot);
        pendingLoot.clear();
        return out;
    }

    /** Идти к точке долго (проходящая мимо толпа). */
    public void migrate(BlockPos to, int ticks) {
        this.noisePos = to.toImmutable();
        this.noiseTicks = ticks;
    }

    @Override
    protected void updatePostDeath() {
        super.updatePostDeath();
        if (!this.getWorld().isClient && this.deathTime >= 20 && !bodyDone && this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) {
            bodyDone = true;
            com.example.zomboidmod.life.BodyEntity b = com.example.zomboidmod.life.BodyEntity.spawn(sw, this.getX(), this.getY(), this.getZ(),
                    this.bodyYaw, rawVariant(), this.getUuid(), pendingLoot, false);
            if (b != null) {
                b.setFallPose(com.example.zomboidmod.life.BodyEntity.fallPose(this.getUuid(), deathFaceDown()));
                b.setLimbs(limbs());
            }
            pendingLoot.clear();
        }
    }

    // ----- вариант: одежда | тон << 8 | повадки << 16 -----
    public int rawVariant() {
        return this.getDataTracker().get(VARIANT);
    }

    public ZombieOutfit outfit() {
        int v = rawVariant();
        ZombieOutfit[] a = ZombieOutfit.values();
        return v < 0 ? a[0] : a[Math.min(v & 255, a.length - 1)];
    }

    public int tone() {
        int v = rawVariant();
        return v < 0 ? 0 : (v >> 8) & 255;
    }

    public ZombieKind kind() {
        int v = rawVariant();
        ZombieKind[] a = ZombieKind.values();
        return v < 0 ? a[0] : a[Math.min((v >> 16) & 255, a.length - 1)];
    }

    /** Ползёт: таким появился или лишился ног в бою. */
    public boolean isCrawler() {
        return this.getDataTracker() != null && (kind() == ZombieKind.CRAWLER || Limbs.crawls(this.getDataTracker().get(LIMBS)));
    }

    private int tier;
    /** Повадки, заданные при спавне (особые зомби опасных зон); null — случайные. */
    private ZombieKind forced;

    private void assign() {
        Random r = this.getRandom();
        ZombieKind kind = forced != null ? forced : ZombieKind.pick(r, tier);
        ZombieOutfit outfit = switch (kind) {
            case BRUTE -> ZombieOutfit.bruteOutfit(r);
            case ARMORED -> r.nextFloat() < 0.6f ? ZombieOutfit.RIOT : ZombieOutfit.SOLDIER;
            case CARRIER -> ZombieOutfit.HAZMAT;
            default -> ZombieOutfit.random(r);
        };
        int tone = kind == ZombieKind.FERAL ? 0 : r.nextInt(3);   // ярые — обратились недавно
        this.getDataTracker().set(VARIANT, outfit.ordinal() | (tone << 8) | (kind.ordinal() << 16));
        applyStats();
    }

    /** Характеристики по повадкам, одежде, опасности места и настройкам песочницы. */
    private void applyStats() {
        ZombieKind kind = kind();
        ZombieOutfit outfit = outfit();
        boolean brute = kind == ZombieKind.BRUTE, boss = kind == ZombieKind.CARRIER;
        double hp = (kind.health + outfit.bonusHealth) * (1.0 + 0.1 * tier) * com.example.zomboidmod.sandbox.Sandbox.healthMult();
        setAttr(EntityAttributes.GENERIC_MAX_HEALTH, Math.min(1000.0, hp));
        this.setHealth(this.getMaxHealth());
        setAttr(EntityAttributes.GENERIC_MOVEMENT_SPEED, kind.idleSpeed);
        setAttr(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0 * com.example.zomboidmod.sandbox.Sandbox.senses());   // зрение у мертвецов плохое — их ведёт слух
        double dmg = switch (kind) {   // опасны укусом и толпой, а не силой удара
            case BRUTE -> 7.0;
            case CARRIER -> 10.0;
            case FERAL, ARMORED -> 4.0;
            default -> 3.0;
        };
        setAttr(EntityAttributes.GENERIC_ATTACK_DAMAGE, (dmg + tier * 0.5) * com.example.zomboidmod.sandbox.Sandbox.damageMult());
        setAttr(EntityAttributes.GENERIC_ARMOR, Math.min(30, outfit.armor() + (brute ? 4 : 0) + (kind == ZombieKind.ARMORED ? 6 : 0) + (boss ? 6 : 0)));
        setAttr(EntityAttributes.GENERIC_ARMOR_TOUGHNESS, kind == ZombieKind.ARMORED ? 6 : boss ? 4 : 0);
        setAttr(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, brute ? 0.95 : boss ? 1.0 : kind == ZombieKind.ARMORED ? 0.7
                : kind == ZombieKind.BLOATER ? 0.6 : 0.35);
        setAttr(EntityAttributes.GENERIC_SCALE, brute ? 1.3 : boss ? 1.65 : kind == ZombieKind.BLOATER ? 1.12 : kind == ZombieKind.ARMORED ? 1.05 : 1.0);
        if (kind == ZombieKind.CRAWLER) this.calculateDimensions();
    }

    public boolean isBrute() {
        return kind() == ZombieKind.BRUTE;
    }

    /** Настроить зомби при спавне в здании: одежда по месту (полицейский в участке и т.п.), остальное случайно. */
    public void setup(ZombieOutfit outfit) {
        setup(outfit, 0);
    }

    /** То же с учётом опасности места: возле хорошего лута зомби сильнее. */
    public void setup(ZombieOutfit outfit, int tier) {
        this.tier = Math.max(0, Math.min(3, tier));
        assign();
        this.setCanBreakDoors(true);
        ZombieKind k = kind();
        if (outfit == null || isBrute() || k == ZombieKind.CARRIER
                || (k == ZombieKind.ARMORED && outfit != ZombieOutfit.SOLDIER && outfit != ZombieOutfit.RIOT)) return;
        int v = rawVariant();
        this.getDataTracker().set(VARIANT, (v & ~255) | outfit.ordinal());
        applyStats();
    }

    /** То же, но с заданными повадками (особые зомби опасных зон, поднятые Носителем). */
    public void setupKind(ZombieOutfit outfit, int tier, ZombieKind kind) {
        this.forced = kind;
        setup(outfit, tier);
        this.forced = null;
    }

    // громила рычит ниже
    public float getSoundPitch() {
        ZombieKind k = kind();
        if (k == ZombieKind.CARRIER) return 0.4f + this.getRandom().nextFloat() * 0.08f;
        if (k == ZombieKind.SCREAMER) return 1.25f + this.getRandom().nextFloat() * 0.2f;
        if (k == ZombieKind.BLOATER) return 0.6f + this.getRandom().nextFloat() * 0.1f;
        return isBrute() ? 0.55f + this.getRandom().nextFloat() * 0.1f : 0.9f + this.getRandom().nextFloat() * 0.2f;
    }

    private void setAttr(RegistryEntry<EntityAttribute> attr, double value) {
        EntityAttributeInstance inst = this.getAttributeInstance(attr);
        if (inst != null) inst.setBaseValue(value);
    }

    /** Зомби услышал шум в этой точке. */
    public void hear(BlockPos pos) {
        hear(pos, null);
    }

    /** Шум от игрока: если тот близко и на виду — сразу бросается на него. */
    public void hear(BlockPos pos, net.minecraft.entity.player.PlayerEntity source) {
        this.noisePos = pos.toImmutable();
        this.noiseTicks = 300;
        if (source != null && this.getTarget() == null && !source.isCreative() && !source.isSpectator()
                && this.squaredDistanceTo(source) < 14 * 14 && this.canSee(source)) {
            this.setTarget(source);
        }
    }

    private int lastHit = -100;
    private int unseen;

    /**
     * Как в PZ: мертвец медленный и неуклюжий — тянется, хватает, промахивается. Между укусами пауза,
     * от отходящей назад жертвы часто промахивается.
     */
    @Override
    public boolean tryAttack(net.minecraft.entity.Entity target) {
        if (isDown()) return false;                              // лёжа не дотянуться
        ZombieKind kk = kind();
        int arms = armsUsable();
        boolean jaw = jawBroken();
        if (arms == 0 && jaw) {                                  // ни схватить, ни укусить: только толкается
            if (this.age - lastHit > 40) {
                lastHit = this.age;
                this.playSound(net.minecraft.sound.SoundEvents.ENTITY_ZOMBIE_AMBIENT, 0.8f, 0.6f);
            }
            return false;
        }
        int cd = kk == ZombieKind.FERAL ? 22 : kk == ZombieKind.CARRIER ? 34 : isBrute() ? 36 : 30;
        if (this.age - lastHit < cd) return false;           // не чаще раза в полторы секунды (ярый — быстрее)
        lastHit = this.age;
        if (target instanceof net.minecraft.entity.player.PlayerEntity pl) {
            double back = pl.getVelocity().horizontalLengthSquared();
            float base = kk == ZombieKind.FERAL || kk == ZombieKind.CARRIER ? 0.08f : 0.2f;
            float miss = base + (back > 0.004 ? 0.2f : 0f) + (isCrawler() ? 0.1f : 0f)
                    + (arms == 1 ? 0.12f : arms == 0 ? 0.35f : 0f);   // одной рукой хватать труднее, без рук — только зубами
            if (this.getRandom().nextFloat() < miss) {                               // промах: хватает воздух
                this.swingHand(net.minecraft.util.Hand.MAIN_HAND);
                this.playSound(net.minecraft.sound.SoundEvents.ENTITY_PLAYER_ATTACK_WEAK, 0.6f, 0.7f);
                return false;
            }
        }
        boolean ok = super.tryAttack(target);
        if (ok && target instanceof net.minecraft.server.network.ServerPlayerEntity sp) com.example.zomboidmod.motion.Knockdown.onZombieHit(sp, this);
        if (ok && arms > 0 && target instanceof net.minecraft.entity.LivingEntity le) {   // хватает и держит
            le.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 15, kind() == ZombieKind.CRAWLER ? 1 : 0, false, false));
            if (isBrute() || kk == ZombieKind.CARRIER) {   // громила и Носитель отшвыривают
                double rad = Math.toRadians(this.getYaw());
                le.takeKnockback(1.3, Math.sin(rad), -Math.cos(rad));
                le.velocityModified = true;
                this.playSound(net.minecraft.sound.SoundEvents.ENTITY_RAVAGER_ATTACK, 1.0f, 0.8f);
            }
        }
        return ok;
    }

    // ===== выбивание дверей и окон, как в PZ =====
    private static final java.util.Map<Long, Integer> THUMPS = new java.util.HashMap<>();
    private net.minecraft.entity.LivingEntity lastTarget;

    private static int thumpLimit(net.minecraft.block.BlockState st) {
        net.minecraft.block.Block b = st.getBlock();
        if (st.isOf(net.minecraft.block.Blocks.IRON_BARS)) return -1;   // решётки зомби не выбить
        if (b instanceof net.minecraft.block.PaneBlock || b instanceof net.minecraft.block.TransparentBlock) return 3;
        if (b instanceof net.minecraft.block.DoorBlock) return st.isOf(net.minecraft.block.Blocks.IRON_DOOR) ? 40 : 14;
        if (b instanceof net.minecraft.block.TrapdoorBlock) return 9;
        if (b instanceof net.minecraft.block.FenceGateBlock || b instanceof net.minecraft.block.FenceBlock) return 12;
        return -1;
    }

    private void thump() {
        if (com.example.zomboidmod.drag.Drag.zombiePressEntity(this)) return;   // упёрся в мебель, которую тащат
        if (armsUsable() == 0) return;   // без рук дверь не выбить
        double rad = Math.toRadians(this.getYaw());
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        for (int dy = 0; dy <= 1; dy++) {
            BlockPos pos = BlockPos.ofFloored(this.getX() + fx * 0.9, this.getY() + 0.5 + dy, this.getZ() + fz * 0.9);
            if (bash(pos)) return;
        }
    }

    /** Удар по двери/окну в этой клетке. false — бить тут нечего. */
    public boolean bash(BlockPos pos) {
        if (pos == null) return false;
        net.minecraft.block.BlockState st = this.getWorld().getBlockState(pos);
        if (st.isOf(com.example.zomboidmod.block.ZomboidBlocks.FURNITURE_TOP)) {   // верх шкафа или холодильника
            pos = pos.down();
            st = this.getWorld().getBlockState(pos);
        }
        // мебель: навалившись, сдвигают (лёгкую — один, тяжёлую — толпой)
        if (this.getWorld() instanceof net.minecraft.server.world.ServerWorld fw && com.example.zomboidmod.drag.Drag.zombiePress(fw, pos, st, this)) return true;
        // постройки игроков и баррикады: у них своя прочность (как в PZ)
        if (this.getWorld() instanceof net.minecraft.server.world.ServerWorld bw) {
            int r = com.example.zomboidmod.build.Carpentry.zombieHit(bw, pos, st, isBrute() ? 4 : 1);
            if (r >= 0) {
                this.swingHand(net.minecraft.util.Hand.MAIN_HAND);
                this.getWorld().setBlockBreakingInfo(this.getId(), pos, r >= 10 ? -1 : r);
                Noise.emitAt(bw, pos, 14);
                return true;
            }
        }
        int limit = thumpLimit(st);
        if (limit < 0) return false;
        if (st.getBlock() instanceof net.minecraft.block.DoorBlock && st.get(net.minecraft.block.DoorBlock.OPEN)) return false;
        long key = pos.asLong();
        int n = THUMPS.merge(key, isBrute() ? 4 : 1, Integer::sum);   // громила выносит двери в разы быстрее
        this.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        boolean glass = limit <= 3;
        this.getWorld().playSound(null, pos, glass ? net.minecraft.sound.SoundEvents.BLOCK_GLASS_HIT
                        : net.minecraft.sound.SoundEvents.ENTITY_ZOMBIE_ATTACK_WOODEN_DOOR, net.minecraft.sound.SoundCategory.HOSTILE, 1.0f,
                0.8f + this.getRandom().nextFloat() * 0.3f);
        this.getWorld().setBlockBreakingInfo(this.getId(), pos, Math.min(9, n * 10 / limit));
        if (this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) Noise.emitAt(sw, pos, 14);
        if (n >= limit) {
            THUMPS.remove(key);
            this.getWorld().setBlockBreakingInfo(this.getId(), pos, -1);
            this.getWorld().syncWorldEvent(glass ? 2001 : net.minecraft.world.WorldEvents.ZOMBIE_BREAKS_WOODEN_DOOR, pos,
                    glass ? net.minecraft.block.Block.getRawIdFromState(st) : 0);
            this.getWorld().breakBlock(pos, false);
            com.example.zomboidmod.parkour.Parkour.shatter(this.getWorld(), pos, st);   // в раме остаются осколки
        }
        return true;
    }

    // ===== паркур: лезет в окно / через забор =====
    public com.example.zomboidmod.parkour.Parkour.Active climb;
    public BlockPos winGoal;
    public net.minecraft.util.math.Direction winDir;
    public int winUntil;
    public net.minecraft.util.math.Vec3d pushTo;
    public int pushUntil;

    @Override
    public void tick() {
        super.tick();

        if (!this.getWorld().isClient && climb != null) {   // лезет по маршруту — ни ИИ, ни физики
            com.example.zomboidmod.parkour.Parkour.tickZombie(this);
            return;
        }

        if (!this.getWorld().isClient && (isDown() || this.age < staggerUntil)) {
            boolean lying = isDown();
            if (lying && this.getDataTracker().get(DOWN_AT) >= 0 && downElapsed(0f) < 0f) this.getDataTracker().set(DOWN_AT, -1);
            this.getNavigation().stop();
            net.minecraft.util.math.Vec3d v = this.getVelocity();
            double k = lying ? 0.15 : 0.45;
            this.setVelocity(v.x * k, v.y, v.z * k);
            if (lying) return;
        } else if (!this.getWorld().isClient && this.getDataTracker().get(DOWN_AT) >= 0) {
            this.getDataTracker().set(DOWN_AT, -1);   // встал
        }

        if (!this.getWorld().isClient) {
            if (rawVariant() < 0) {
                assign();
                this.setCanBreakDoors(true);
            }
            ZombieKind kind = kind();

            // в тумане видят хуже (как в PZ)
            if (this.age % 40 == 0) {   // днём видят метров на 24, ночью и в тумане — гораздо хуже
                long tod = Math.floorMod(this.getWorld().getTimeOfDay(), 24000L);
                double sight = (tod > 13000 && tod < 23000) ? 14.0 : 24.0;
                sight *= com.example.zomboidmod.sandbox.Sandbox.senses() * (kind == ZombieKind.FERAL ? 1.3 : kind == ZombieKind.CARRIER ? 1.4 : 1.0);
                if (feeding()) sight *= 0.5;   // увлечён едой
                setAttr(EntityAttributes.GENERIC_FOLLOW_RANGE, sight * (1.0 - 0.5 * com.example.zomboidmod.survival.WorldEvents.fog));
            }
            // потерял жертву из виду — идёт туда, где видел её в последний раз, а потом теряет интерес
            if (this.age % 10 == 3 && this.getTarget() != null) {
                if (this.canSee(this.getTarget())) unseen = 0;
                else if ((unseen += 10) > 160) {
                    noisePos = this.getTarget().getBlockPos();
                    noiseTicks = 200;
                    this.setTarget(null);
                    unseen = 0;
                }
            }
            // в погоне ускоряются; бегун несётся и иногда спотыкается
            if (this.age % 10 == 0) {
                boolean chasing = this.getTarget() != null;
                boolean rage = kind == ZombieKind.CARRIER && this.getHealth() < this.getMaxHealth() * 0.5f;   // раненый Носитель звереет
                setAttr(EntityAttributes.GENERIC_MOVEMENT_SPEED, limbSpeed((chasing ? kind.chaseSpeed : kind.idleSpeed) * (rage ? 1.25 : 1.0), chasing));
                if (kind == ZombieKind.SPRINTER && chasing && this.getRandom().nextInt(80) == 0) {
                    this.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 6, false, false));
                }
            }

            // заметив жертву, зовёт остальных (стон слышат в радиусе 18 блоков)
            net.minecraft.entity.LivingEntity tgt = this.getTarget();
            if (tgt != null && tgt != lastTarget && this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) {
                this.playSound(net.minecraft.sound.SoundEvents.ENTITY_ZOMBIE_AMBIENT, 1.5f, 0.7f);
                for (PzZombieEntity o : sw.getEntitiesByClass(PzZombieEntity.class, this.getBoundingBox().expand(12), e -> e != this && e.isAlive())) {
                    o.noisePos = tgt.getBlockPos();
                    o.noiseTicks = 240;
                    if (o.getTarget() == null && o.squaredDistanceTo(tgt) < 16 * 16 && o.canSee(tgt)) o.setTarget(tgt);
                }
            }
            lastTarget = tgt;
            if (kind.special() && this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw2) specialTick(sw2, kind, tgt);

            // упёрся в дверь или окно — колотит, пока не выбьет
            if ((tgt != null || noiseTicks > 0) && this.age % 20 == (this.getId() & 15) && this.horizontalCollision) thump();
            // заборы и окна: переваливается, бьёт стёкла, ищет окно, если к жертве иначе не пройти
            if ((tgt != null || noiseTicks > 0) && this.age % 5 == (this.getId() & 0x7fffffff) % 5)
                com.example.zomboidmod.parkour.Parkour.zombieThink(this, tgt, tgt == null ? noisePos : null);
            if (winGoal != null || pushTo != null) com.example.zomboidmod.parkour.Parkour.steer(this);

            // скрытность: крадущегося игрока замечают только вблизи
            if (this.age % 10 == 0 && this.getTarget() instanceof net.minecraft.server.network.ServerPlayerEntity sp
                    && sp.isSneaking() && this.getAttacker() != sp
                    && this.squaredDistanceTo(sp) > Math.pow(Skills.sneakDetectRange(sp), 2)) {
                this.setTarget(null);
            }
            if (this.age % 10 == 5 && this.getTarget() instanceof net.minecraft.server.network.ServerPlayerEntity sp2
                    && this.getAttacker() != sp2
                    && this.squaredDistanceTo(sp2) > Math.pow(Skills.inconspicuousRange(sp2), 2)) {
                this.setTarget(null);
            }

            // дымовая завеса: в дыму жертву не разглядеть (вплотную — всё равно учует)
            if (this.age % 5 == 2 && this.getTarget() != null && this.squaredDistanceTo(this.getTarget()) > 4
                    && com.example.zomboidmod.throwable.Throwables.smoked(this.getPos(), this.getTarget().getPos())) {
                noisePos = this.getTarget().getBlockPos();
                noiseTicks = 60;
                this.setTarget(null);
            }

            // свежие тела: мертвецы сходятся и едят (пока нет жертвы и шума)
            feedTick();

            // идёт на шум, если жертвы не видно
            if (noiseTicks > 0) {
                noiseTicks--;
                if (this.getTarget() == null && noisePos != null && this.age % 20 == 0) {
                    double nx = noisePos.getX() + 0.5, ny = noisePos.getY(), nz = noisePos.getZ() + 0.5;
                    if (this.squaredDistanceTo(nx, ny, nz) > 4.0) {
                        this.getNavigation().startMovingTo(nx, ny, nz, 1.0);
                    } else {
                        noiseTicks = 0;
                    }
                }
            }
        }

        // из обрубков течёт: капли и след на земле
        if (!this.getWorld().isClient && this.age < bleedUntil && this.age % 12 == 0
                && this.getWorld() instanceof net.minecraft.server.world.ServerWorld bw) {
            Combat.gore(bw, new net.minecraft.util.math.Vec3d(this.getX(), this.getY() + this.getHeight() * 0.5, this.getZ()), 3, 0.05);
            if (this.age % 48 == 0 && this.getRandom().nextFloat() < 0.5f) Combat.stain(bw, this.getBlockPos(), this.getRandom());
        }

        // ползун ползёт по земле
        if (isCrawler()) this.setPose(EntityPose.SWIMMING);
    }

    @Override
    public EntityDimensions getBaseDimensions(EntityPose pose) {
        if (this.getDataTracker() != null && isCrawler()) return EntityDimensions.changing(0.7f, 0.6f);
        return super.getBaseDimensions(pose);
    }

    // Зомби не горят на солнце (как в PZ). Без @Override: сработает, если такие методы есть у родителя.
    public boolean isAffectedByDaylight() {
        return false;
    }

    public boolean burnsInDaylight() {
        return false;
    }

    public boolean shouldBurnInDay() {
        return false;
    }

    @Override
    public void onDeath(DamageSource source) {
        collecting = !this.getWorld().isClient;   // вещи — в тело, а не на землю
        try {
            super.onDeath(source);
            if (bar != null) bar.clearPlayers();
            if (!this.getWorld().isClient && !lootRolled) {
                lootRolled = true;
                ZombieLoot.drop(this, outfit(), this.getRandom());
                ZombieLoot.special(this, kind(), this.getRandom());
                if (kind() == ZombieKind.BLOATER && this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) burst(sw);
            }
        } finally {
            collecting = false;
        }
    }

    // ===================== едят тела =====================
    private void feedTick() {
        boolean free = this.getTarget() == null && noiseTicks <= 0 && !isCrawler() && climb == null && kind() != ZombieKind.CARRIER;
        if (!free || food == null || !food.isAlive() || !food.fresh()) {
            if (!free || (food != null && (!food.isAlive() || !food.fresh()))) {
                food = null;
                if (feeding()) this.getDataTracker().set(FEEDING, false);
            }
            if (!free || this.age % 60 != (this.getId() & 31)) return;
            // ищет свежее тело неподалёку (не больше троих на одно)
            java.util.List<com.example.zomboidmod.life.BodyEntity> bodies = this.getWorld().getEntitiesByClass(com.example.zomboidmod.life.BodyEntity.class,
                    this.getBoundingBox().expand(10, 3, 10), b -> b.isAlive() && b.fresh());
            for (com.example.zomboidmod.life.BodyEntity b : bodies) {
                int eaters = this.getWorld().getEntitiesByClass(PzZombieEntity.class, b.getBoundingBox().expand(1.6), z -> z != this && z.feeding()).size();
                if (eaters < 3) {
                    food = b;
                    break;
                }
            }
            return;
        }
        double d2 = this.squaredDistanceTo(food);
        if (d2 > 1.9 * 1.9) {
            if (feeding()) this.getDataTracker().set(FEEDING, false);
            if (this.age % 20 == 0) this.getNavigation().startMovingTo(food.getX(), food.getY(), food.getZ(), 0.9);
            return;
        }
        this.getNavigation().stop();
        this.getLookControl().lookAt(food.getX(), food.getY(), food.getZ());
        if (!feeding()) this.getDataTracker().set(FEEDING, true);
        if (this.age % 45 == (this.getId() & 15) && this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) {
            this.playSound(net.minecraft.sound.SoundEvents.ENTITY_GENERIC_EAT, 0.8f, 0.5f + this.getRandom().nextFloat() * 0.2f);
            sw.spawnParticles(new net.minecraft.particle.BlockStateParticleEffect(net.minecraft.particle.ParticleTypes.BLOCK,
                    net.minecraft.block.Blocks.REDSTONE_BLOCK.getDefaultState()), food.getX(), food.getY() + 0.3, food.getZ(), 6, 0.25, 0.1, 0.25, 0.05);
        }
    }

    // ===================== особые зомби =====================
    private net.minecraft.entity.boss.ServerBossBar bar;
    private int screamCd, roarCd = 60, raiseCd = 200, leapCd;

    private void specialTick(net.minecraft.server.world.ServerWorld sw, ZombieKind kind, net.minecraft.entity.LivingEntity tgt) {
        switch (kind) {
            case SCREAMER -> {
                if (screamCd > 0) screamCd--;
                if (tgt != null && screamCd <= 0 && this.canSee(tgt)) scream(sw, tgt);
            }
            case FERAL -> {
                if (leapCd > 0) leapCd--;
                if (tgt != null && leapCd <= 0 && this.isOnGround() && climb == null) {
                    double d2 = this.squaredDistanceTo(tgt);
                    if (d2 < 7 * 7 && d2 > 2.2 * 2.2 && this.canSee(tgt)) {   // бросок в прыжке
                        net.minecraft.util.math.Vec3d d = tgt.getPos().subtract(this.getPos()).multiply(1, 0, 1).normalize();
                        this.setVelocity(d.x * 0.72, 0.36, d.z * 0.72);
                        this.velocityModified = true;
                        this.playSound(net.minecraft.sound.SoundEvents.ENTITY_ZOMBIE_AMBIENT, 1.4f, 1.5f);
                        leapCd = 50 + this.getRandom().nextInt(40);
                    }
                }
            }
            case CARRIER -> carrierTick(sw, tgt);
            default -> {
            }
        }
    }

    /** Крикун: визг слышно далеко — мертвецы со всей округи идут на звук, а ближние сразу бросаются на жертву. */
    private void scream(net.minecraft.server.world.ServerWorld sw, net.minecraft.entity.LivingEntity tgt) {
        screamCd = 170 + this.getRandom().nextInt(90);
        BlockPos at = this.getBlockPos();
        sw.playSound(null, at, net.minecraft.sound.SoundEvents.ENTITY_GHAST_SCREAM, net.minecraft.sound.SoundCategory.HOSTILE, 3.5f, 0.55f + this.getRandom().nextFloat() * 0.1f);
        sw.playSound(null, at, net.minecraft.sound.SoundEvents.ENTITY_FOX_SCREECH, net.minecraft.sound.SoundCategory.HOSTILE, 3.5f, 0.5f);
        sw.spawnParticles(net.minecraft.particle.ParticleTypes.POOF, this.getX(), this.getEyeY(), this.getZ(), 12, 0.3, 0.2, 0.3, 0.05);
        this.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        Noise.emitAt(sw, at, 48);
        for (PzZombieEntity o : sw.getEntitiesByClass(PzZombieEntity.class, this.getBoundingBox().expand(22), e -> e != this && e.isAlive())) {
            if (o.getTarget() == null) o.setTarget(tgt);
        }
        if (tgt instanceof net.minecraft.server.network.ServerPlayerEntity sp) {
            sp.sendMessage(net.minecraft.text.Text.literal("Пронзительный визг! На крик сбегаются мертвецы").formatted(net.minecraft.util.Formatting.RED), true);
            com.example.zomboidmod.survival.Mood m = com.example.zomboidmod.survival.Survival.mood(sp);
            m.panic = Math.min(100f, m.panic + 20f);
        }
    }

    /** Раздутый лопается: облако трупного газа (тошнота, отравление, голод) и брызги гнили. */
    private void burst(net.minecraft.server.world.ServerWorld sw) {
        net.minecraft.entity.AreaEffectCloudEntity c = new net.minecraft.entity.AreaEffectCloudEntity(sw, this.getX(), this.getY() + 0.2, this.getZ());
        c.setRadius(3.4f);
        c.setWaitTime(4);
        c.setDuration(260);
        c.setRadiusGrowth(-3.4f / 520f);
        c.setParticleType(net.minecraft.particle.ParticleTypes.SNEEZE);
        c.addEffect(new StatusEffectInstance(StatusEffects.POISON, 120, 0));
        c.addEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 240, 0));
        c.addEffect(new StatusEffectInstance(StatusEffects.HUNGER, 300, 1));
        sw.spawnEntity(c);
        sw.spawnParticles(new net.minecraft.particle.BlockStateParticleEffect(net.minecraft.particle.ParticleTypes.BLOCK, net.minecraft.block.Blocks.MOSS_BLOCK.getDefaultState()),
                this.getX(), this.getY() + 1.0, this.getZ(), 60, 0.6, 0.5, 0.6, 0.2);
        sw.spawnParticles(new net.minecraft.particle.BlockStateParticleEffect(net.minecraft.particle.ParticleTypes.BLOCK, net.minecraft.block.Blocks.REDSTONE_BLOCK.getDefaultState()),
                this.getX(), this.getY() + 1.0, this.getZ(), 30, 0.5, 0.5, 0.5, 0.2);
        sw.playSound(null, this.getBlockPos(), net.minecraft.sound.SoundEvents.ENTITY_SLIME_SQUISH, net.minecraft.sound.SoundCategory.HOSTILE, 2f, 0.5f);
        sw.playSound(null, this.getBlockPos(), net.minecraft.sound.SoundEvents.ENTITY_PUFFER_FISH_BLOW_UP, net.minecraft.sound.SoundCategory.HOSTILE, 2f, 0.6f);
        Noise.emitAt(sw, this.getBlockPos(), 16);
    }

    /** Носитель — босс: полоса здоровья, рёв (оглушает и отбрасывает), поднимает мертвецов из-под земли. */
    private void carrierTick(net.minecraft.server.world.ServerWorld sw, net.minecraft.entity.LivingEntity tgt) {
        if (bar == null) {
            bar = new net.minecraft.entity.boss.ServerBossBar(net.minecraft.text.Text.literal(ZombieKind.CARRIER.title),
                    net.minecraft.entity.boss.BossBar.Color.RED, net.minecraft.entity.boss.BossBar.Style.NOTCHED_10);
            bar.setDarkenSky(true);
        }
        bar.setPercent(Math.max(0f, this.getHealth() / this.getMaxHealth()));
        boolean rage = this.getHealth() < this.getMaxHealth() * 0.5f;
        if (this.age % 20 == 0) {
            for (net.minecraft.server.network.ServerPlayerEntity p : sw.getPlayers()) {
                double d = this.squaredDistanceTo(p);
                if (p.isAlive() && !p.isSpectator() && d < 48 * 48) bar.addPlayer(p);
                else if (d > 64 * 64 || !p.isAlive()) bar.removePlayer(p);
            }
            if (tgt == null && this.getHealth() < this.getMaxHealth()) this.heal(2f);   // без жертвы затягивает раны
        }
        if (rage && this.age % 8 == 0)
            sw.spawnParticles(net.minecraft.particle.ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + this.getHeight() * 0.8, this.getZ(), 2, 0.3, 0.2, 0.3, 0.01);
        if (tgt == null) return;
        if (roarCd > 0) roarCd--;
        if (raiseCd > 0) raiseCd--;
        if (roarCd <= 0 && this.squaredDistanceTo(tgt) < 18 * 18) {
            roarCd = rage ? 140 : 220;
            sw.playSound(null, this.getBlockPos(), net.minecraft.sound.SoundEvents.ENTITY_RAVAGER_ROAR, net.minecraft.sound.SoundCategory.HOSTILE, 4f, 0.6f);
            Noise.emitAt(sw, this.getBlockPos(), 64);
            for (net.minecraft.server.network.ServerPlayerEntity p : sw.getEntitiesByClass(net.minecraft.server.network.ServerPlayerEntity.class,
                    this.getBoundingBox().expand(10), pl -> pl.isAlive() && !pl.isCreative() && !pl.isSpectator())) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 50, 1, false, true));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 90, 0, false, true));
                net.minecraft.util.math.Vec3d d = p.getPos().subtract(this.getPos()).normalize();
                p.takeKnockback(0.9, -d.x, -d.z);
                p.velocityModified = true;
            }
        }
        if (raiseCd <= 0) {
            raiseCd = rage ? 260 : 400;
            int around = sw.getEntitiesByClass(PzZombieEntity.class, this.getBoundingBox().expand(16), e -> e.isAlive()).size();
            if (around < 14 && com.example.zomboidmod.sandbox.Sandbox.pop() > 0) {
                int n = 2 + this.getRandom().nextInt(2) + (rage ? 1 : 0), made = 0;
                for (int i = 0; i < n; i++) {
                    double a = this.getRandom().nextDouble() * Math.PI * 2, dist = 3 + this.getRandom().nextDouble() * 4;
                    int x = net.minecraft.util.math.MathHelper.floor(this.getX() + Math.cos(a) * dist);
                    int z = net.minecraft.util.math.MathHelper.floor(this.getZ() + Math.sin(a) * dist);
                    int y = sw.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
                    if (Math.abs(y - this.getY()) > 4) continue;
                    PzZombieEntity zb = ZomboidEntities.PZ_ZOMBIE.create(sw);
                    if (zb == null) continue;
                    zb.refreshPositionAndAngles(x + 0.5, y, z + 0.5, this.getRandom().nextFloat() * 360f, 0f);
                    zb.setupKind(null, 2, this.getRandom().nextFloat() < 0.3f ? ZombieKind.FAST_SHAMBLER : ZombieKind.SHAMBLER);
                    zb.setPersistent();
                    sw.spawnEntity(zb);
                    zb.setTarget(tgt);
                    sw.spawnParticles(new net.minecraft.particle.BlockStateParticleEffect(net.minecraft.particle.ParticleTypes.BLOCK,
                            sw.getBlockState(new BlockPos(x, y - 1, z))), x + 0.5, y + 0.1, z + 0.5, 30, 0.3, 0.1, 0.3, 0.1);
                    made++;
                }
                if (made > 0) {
                    sw.playSound(null, this.getBlockPos(), net.minecraft.sound.SoundEvents.ENTITY_WARDEN_EMERGE, net.minecraft.sound.SoundCategory.HOSTILE, 2f, 0.8f);
                    if (tgt instanceof net.minecraft.server.network.ServerPlayerEntity sp)
                        sp.sendMessage(net.minecraft.text.Text.literal("Носитель ревёт — из-под земли лезут мертвецы!").formatted(net.minecraft.util.Formatting.DARK_RED), true);
                }
            }
        }
    }

    @Override
    public void onStoppedTrackingBy(net.minecraft.server.network.ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        if (bar != null) bar.removePlayer(player);
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        if (kind() == ZombieKind.CARRIER) return false;   // босса не убить, сбросив с крыши
        return super.handleFallDamage(fallDistance, damageMultiplier, damageSource);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("PzVariant", rawVariant());
        nbt.putBoolean("PzLootRolled", lootRolled);
        nbt.putInt("PzTier", tier);
        nbt.putInt("PzLimbs", this.getDataTracker().get(LIMBS));
        int[] dmg = new int[12];
        for (int i = 0; i < 6; i++) {
            dmg[i] = Math.round(cut[i] * 100f);
            dmg[6 + i] = Math.round(crush[i] * 100f);
        }
        nbt.putIntArray("PzPartDmg", dmg);
        if (climb != null) {   // сохранение посреди перелезания: не оставить зомби замороженным
            nbt.putBoolean("NoAI", false);
            nbt.remove("NoGravity");
        }
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("PzVariant")) this.getDataTracker().set(VARIANT, nbt.getInt("PzVariant"));
        lootRolled = nbt.getBoolean("PzLootRolled");
        tier = nbt.getInt("PzTier");
        this.getDataTracker().set(LIMBS, nbt.getInt("PzLimbs"));
        int[] dmg = nbt.getIntArray("PzPartDmg");
        if (dmg.length == 12) for (int i = 0; i < 6; i++) {
            cut[i] = dmg[i] / 100f;
            crush[i] = dmg[6 + i] / 100f;
        }
        if (isCrawler()) this.calculateDimensions();
    }
}
