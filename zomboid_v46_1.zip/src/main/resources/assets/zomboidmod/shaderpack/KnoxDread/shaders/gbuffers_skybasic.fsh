#version 120
/* DRAWBUFFERS:0 */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
varying vec4 color;
varying vec3 viewPos;
varying float star;
void main() {
    float day = dayFactor();
    if (star > 0.5) {
        gl_FragData[0] = vec4(color.rgb * 0.5 * (1.0 - rainStrength) * (1.0 - day), color.a);
        return;
    }
    gl_FragData[0] = vec4(skyColor(normalize(viewPos)), 1.0);
}
