#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/view.glsl"
uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
varying vec2 texcoord;
/* DRAWBUFFERS:0 */

float linZ(float d) {
    return 2.0 * near * far / (far + near - (d * 2.0 - 1.0) * (far - near));
}

bool ssr(vec3 vp, vec3 n, out vec3 col, out float fade) {
    col = vec3(0.0);
    fade = 0.0;
    vec3 r = normalize(reflect(normalize(vp), n));
    float stepL = 0.2 + 0.02 * length(vp);
    float jit = ign(gl_FragCoord.xy);
    vec3 p = vp + n * 0.04;
    vec3 prev = p;
    for (int i = 0; i < 26; i++) {
        prev = p;
        p += r * stepL * (i == 0 ? jit + 0.5 : 1.0);
        stepL *= 1.17;
        vec4 cp = gbufferProjection * vec4(p, 1.0);
        if (cp.w <= 0.0) return false;
        vec2 uv = cp.xy / cp.w * 0.5 + 0.5;
        if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return false;
        float sd = texture2D(depthtex1, uv).r;
        if (sd >= 1.0) continue;
        vec3 sv = toView(uv, sd);
        float diff = sv.z - p.z;
        if (diff > 0.0 && diff < stepL * 2.5 + 0.25) {
            vec3 a = prev, b = p;
            for (int k = 0; k < 5; k++) {
                vec3 m = (a + b) * 0.5;
                vec2 mu = toScreen(m);
                vec3 mv = toView(mu, texture2D(depthtex1, mu).r);
                if (mv.z - m.z > 0.0) b = m; else a = m;
            }
            vec2 fu = toScreen(b);
            col = texture2D(colortex0, fu).rgb;
            vec2 e = min(fu, 1.0 - fu);
            fade = smoothstep(0.0, 0.07, min(e.x, e.y));
            return true;
        }
    }
    return false;
}

vec3 ripples(vec2 p) {
    vec2 g = vec2(0.0);
#ifdef RAIN_RIPPLES
    float t = frameTimeCounter;
    for (int k = 0; k < 2; k++) {
        vec2 q = p * (k == 0 ? 1.3 : 2.1) + float(k) * 17.3;
        vec2 cell = floor(q);
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                vec2 c = cell + vec2(float(x), float(y));
                float h = hash12(c + 3.1);
                vec2 ctr = c + vec2(hash12(c), hash12(c + 9.7)) * 0.8 + 0.1;
                float life = fract(t * (0.9 + h * 0.5) + h * 7.0);
                vec2 d = q - ctr;
                float dist = length(d);
                float ring = life * 0.55;
                float w = sin(clamp((dist - ring) * 28.0, -3.1416, 3.1416)) * (1.0 - life) * (1.0 - life) * smoothstep(0.35, 0.0, abs(dist - ring));
                g += normalize(d + 1e-4) * w;
            }
        }
    }
    g *= 0.12 * rainStrength;
#endif
    return normalize(vec3(-g.x, 1.0, -g.y));
}

void main() {
    vec3 c = texture2D(colortex0, texcoord).rgb;
    float d = texture2D(depthtex0, texcoord).r;
    vec4 nm = texture2D(colortex1, texcoord);
    float mat = nm.a;
    vec4 info = texture2D(colortex2, texcoord);
    if (d >= 1.0 || mat < 0.05) {
        gl_FragData[0] = vec4(c, 1.0);
        return;
    }
    vec3 vp = toView(texcoord, d);
    if (mat < 0.65 && AO_STRENGTH > 0.0) {
        vec2 px = 1.0 / vec2(viewWidth, viewHeight);
        float lz = linZ(d), ao = 0.0, w = 0.0;
        for (int x = -2; x <= 1; x++) {
            for (int y = -2; y <= 1; y++) {
                vec2 o = (vec2(float(x), float(y)) + 0.5) * px * 1.5;
                float sw = 1.0 / (0.002 + abs(linZ(texture2D(depthtex0, texcoord + o).r) - lz));
                ao += texture2D(colortex3, texcoord + o).r * sw;
                w += sw;
            }
        }
        ao /= w;
        float k = clamp(AO_STRENGTH * (1.0 - 0.6 * info.z), 0.0, 1.0);
        c *= mix(1.0, ao, k * (1.0 - fogAmount(vp)));
    }
#ifdef REFLECTIONS
    bool water = mat > 0.75 && mat < 0.85;
    float wc = info.w;
    bool wetGround = mat > 0.1 && mat < 0.3 && wc > 0.01;
    if (water || wetGround) {
        vec3 n = normalize(nm.xyz * 2.0 - 1.0);
        float strength;
        if (water) {
            strength = 1.0;
        } else if (wc >= 0.5) {
            strength = (wc - 0.5) * 2.0;
            vec3 wp = (gbufferModelViewInverse * vec4(vp, 1.0)).xyz + cameraPosition;
            n = normalize(mat3(gbufferModelView) * ripples(wp.xz));
        } else {
            strength = wc * 0.7;
        }
        vec3 v = normalize(vp);
        float fres = 0.02 + 0.98 * pow(1.0 - clamp(dot(-v, n), 0.0, 1.0), 5.0);
        vec3 sky = skyColor(normalize(reflect(v, n))) * (0.15 + 0.85 * info.y);
        vec3 rc;
        float fade;
        if (ssr(vp, n, rc, fade)) rc = mix(sky, rc, fade);
        else rc = sky;
        float amount = water ? mix(0.12, 1.0, fres) : (wc >= 0.5 ? mix(0.3, 1.0, fres) : fres * 0.6);
        amount = clamp(amount * strength, 0.0, 1.0);
        c = mix(c, rc, amount);
    }
#endif
    gl_FragData[0] = vec4(c, 1.0);
}
