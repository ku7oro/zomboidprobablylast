#version 120
/* DRAWBUFFERS:012 */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying vec3 viewPos;
varying vec3 worldPos;
varying float isWater;
float waveH(vec2 p) {
    float t = frameTimeCounter * (0.8 + rainStrength * 0.6);
    float h = sin(p.x * 0.9 + t * 1.3) * 0.5 + sin(p.y * 1.3 - t * 1.1) * 0.35;
    h += vnoise(p * 1.7 + vec2(t * 0.6, -t * 0.4)) * 0.6 + vnoise(p * 4.1 - vec2(t * 0.9, t * 0.7)) * 0.25;
    return h * (0.06 + rainStrength * 0.05);
}
void main() {
    vec4 albedo = texture2D(texture, texcoord) * color;
    vec3 n = normalize(normal);
    if (isWater > 0.5) {
        float l = dot(albedo.rgb, vec3(0.3, 0.59, 0.11));
        albedo.rgb = vec3(0.09, 0.12, 0.10) * (0.7 + 0.6 * l);
        if (dot(n, normalize(upPosition)) > 0.6) {
            float e = 0.08;
            float h0 = waveH(worldPos.xz);
            vec3 wn = normalize(vec3(-(waveH(worldPos.xz + vec2(e, 0.0)) - h0) / e, 1.0, -(waveH(worldPos.xz + vec2(0.0, e)) - h0) / e));
            n = normalize(mat3(gbufferModelView) * wn);
        }
        vec3 c = lighting(albedo.rgb, lmcoord, n, viewPos, true, 0.0);
        vec3 v = normalize(-viewPos);
        float spec = pow(max(dot(reflect(-normalize(shadowLightPosition), n), v), 0.0), 120.0) * g_sunlit * 6.0;
        c += vec3(1.0, 0.9, 0.75) * spec;
        gl_FragData[0] = vec4(applyFog(c, viewPos), 0.9);
        gl_FragData[1] = vec4(n * 0.5 + 0.5, MAT_WATER);
        gl_FragData[2] = vec4(lmcoord, g_sunlit, 1.0);
        return;
    }
    if (albedo.a < 0.02) discard;
    vec3 c = lighting(albedo.rgb, lmcoord, n, viewPos, true, 0.0);
    gl_FragData[0] = vec4(applyFog(c, viewPos), albedo.a);
    gl_FragData[1] = vec4(n * 0.5 + 0.5, MAT_GLASS);
    gl_FragData[2] = vec4(lmcoord, g_sunlit, 0.0);
}
