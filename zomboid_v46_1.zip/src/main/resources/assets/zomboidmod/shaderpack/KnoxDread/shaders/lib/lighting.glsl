uniform sampler2D shadowtex0;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

float g_sunlit = 0.0;

vec3 distortShadow(vec3 p) {
    float d = length(p.xy);
    p.xy /= d * 0.9 + 0.1;
    p.z *= 0.2;
    return p;
}

float shadowAt(vec3 viewPos, vec3 nView, float NdotL) {
    vec3 pp = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    float pd = length(pp);
    if (pd > shadowDistance - 2.0) return 1.0;
    vec3 np = mat3(gbufferModelViewInverse) * nView;
    vec4 sp0 = shadowProjection * (shadowModelView * vec4(pp, 1.0));
    float df = length(sp0.xy) * 0.9 + 0.1;
    float texel = 2.0 * shadowDistance / float(shadowMapResolution) * df * df * 10.0;
    pp += np * (0.02 + texel * (1.0 + 1.8 * (1.0 - NdotL)));
    vec4 sp = shadowProjection * (shadowModelView * vec4(pp, 1.0));
    sp.xyz = distortShadow(sp.xyz);
    vec3 c = sp.xyz * 0.5 + 0.5;
    if (c.x < 0.0 || c.x > 1.0 || c.y < 0.0 || c.y > 1.0) return 1.0;
    float bias = 0.00003 * df * df * 10.0;
    float px = 1.0 / float(shadowMapResolution);
    float rot = ign(gl_FragCoord.xy) * 6.2831853;
    float zr = c.z - bias;
    float blockers = 0.0, bsum = 0.0;
    float search = 7.0 * max(SHADOW_SOFTNESS, 0.3);
    for (int i = 0; i < 8; i++) {
        float fi = float(i) + 0.5;
        float a = fi * 2.3999632 + rot;
        vec2 o = vec2(cos(a), sin(a)) * sqrt(fi / 8.0) * search * px;
        float d = texture2D(shadowtex0, c.xy + o).r;
        if (d < zr) {
            blockers += 1.0;
            bsum += d;
        }
    }
    float fade = smoothstep(shadowDistance - 20.0, shadowDistance - 2.0, pd);
    if (blockers < 0.5) return 1.0;
    float avgB = bsum / blockers;
    float gap = (zr - avgB) * 1280.0;
    float pen = clamp(gap * 0.035 / max(texel, 0.001), 1.0, 14.0) * SHADOW_SOFTNESS + 0.75;
    float s = 0.0;
    for (int i = 0; i < 16; i++) {
        float fi = float(i) + 0.5;
        float a = fi * 2.3999632 + rot * 1.7;
        vec2 o = vec2(cos(a), sin(a)) * sqrt(fi / 16.0) * pen * px;
        s += step(zr, texture2D(shadowtex0, c.xy + o).r);
    }
    s /= 16.0;
    return mix(s, 1.0, fade);
}

uniform int heldItemId;
uniform int heldItemId2;

vec3 lighting(vec3 albedo, vec2 lm, vec3 nView, vec3 viewPos, bool useShadow, float foliage) {
    float day = dayFactor();
    float sky = lm.y;
    float skyL = sky * sky;
    vec3 L = normalize(shadowLightPosition);
    float NdotL = max(dot(nView, L), 0.0);
#ifdef LEAF_TRANSLUCENCY
    NdotL = mix(NdotL, 0.55 + 0.35 * abs(dot(nView, L)), foliage);
#endif
    float sh = 1.0;
    if (useShadow && NdotL > 0.001 && sky > 0.05) sh = shadowAt(viewPos, nView, max(NdotL, 0.2));
    float sunH = sunHeight();
    vec3 sunC = mix(vec3(1.0, 0.55, 0.32), vec3(0.98, 0.93, 0.86), smoothstep(0.0, 0.35, sunH)) * 0.95;
    vec3 moonC = vec3(0.12, 0.145, 0.22) * 0.72 * NIGHT_BRIGHTNESS;
    vec3 direct = mix(moonC, sunC, day) * (1.0 - rainStrength * 0.75);
    float up = dot(nView, normalize(upPosition));
    float skyDir = 0.72 + 0.28 * up;
    vec3 amb = mix(vec3(0.05, 0.06, 0.085) * NIGHT_BRIGHTNESS, vec3(0.31, 0.33, 0.35) / SHADOW_DARKNESS, day) * (1.0 - rainStrength * 0.25) * skyDir;
    amb += vec3(0.05, 0.045, 0.035) * day * max(-up, 0.0) * (1.0 - rainStrength);
    float bl = lm.x;
    vec3 lamp = vec3(1.0, 0.6, 0.3) * (pow(bl, 3.2) * 1.6);
    float dist = length(viewPos);
    float flick = 0.93 + 0.07 * sin(frameTimeCounter * 9.0) * sin(frameTimeCounter * 5.3 + 1.3);
    float held = float(max(heldBlockLightValue, heldBlockLightValue2));
    float hl = clamp((held - dist * 1.1) / 15.0, 0.0, 1.0);
    lamp += vec3(1.0, 0.68, 0.42) * hl * hl * 1.3 * flick;
    if (heldItemId == 20001 || heldItemId2 == 20001) {
        vec3 dir = viewPos / max(dist, 0.001);
        float cosA = -dir.z;
        float cone = smoothstep(0.905, 0.985, cosA) + 0.16 * smoothstep(0.70, 0.93, cosA);
        float att = (1.0 - smoothstep(24.0, 38.0, dist)) / (1.0 + dist * dist * 0.006);
        float ndl = clamp(dot(nView, -dir), 0.0, 1.0) * 0.85 + 0.15;
        lamp += vec3(0.93, 0.96, 1.0) * cone * att * ndl * FLASHLIGHT_POWER;
    }
    lamp = 2.2 * (vec3(1.0) - exp(-lamp / 2.2));
    float sunVis = NdotL * sh * smoothstep(0.2, 0.9, sky);
    g_sunlit = sunVis * day * (1.0 - rainStrength);
    vec3 light = amb * skyL + direct * sunVis + lamp + vec3(0.005) + vec3(nightVision * 0.45);
    return albedo * light;
}
