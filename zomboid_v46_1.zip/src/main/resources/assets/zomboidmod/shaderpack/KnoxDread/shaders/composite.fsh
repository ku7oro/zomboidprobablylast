#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/view.glsl"
/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16;
const int colortex2Format = RGBA16;
const int colortex3Format = RGBA8;
const bool colortex0MipmapEnabled = true;
const vec4 colortex1ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex2ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex3ClearColor = vec4(1.0, 1.0, 1.0, 1.0);
*/
uniform sampler2D depthtex0;
uniform sampler2D colortex1;
varying vec2 texcoord;
/* DRAWBUFFERS:3 */
void main() {
    float ao = 1.0;
#ifdef SSAO
    float d = texture2D(depthtex0, texcoord).r;
    vec4 nm = texture2D(colortex1, texcoord);
    float mat = nm.a;
    if (d < 1.0 && mat > 0.05 && mat < 0.65 && AO_STRENGTH > 0.0) {
        vec3 vp = toView(texcoord, d);
        float dist = -vp.z;
        if (dist < 64.0) {
            vec3 n = normalize(nm.xyz * 2.0 - 1.0);
            vec3 t = normalize(cross(n, abs(n.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0)));
            vec3 b = cross(n, t);
            float r = 0.6;
            float rot = ign(gl_FragCoord.xy) * 6.2831853;
            float occ = 0.0;
            for (int i = 0; i < 12; i++) {
                float fi = float(i) + 0.5;
                float h = fi / 12.0;
                float a = fi * 2.3999632 + rot;
                vec3 dir = (t * cos(a) + b * sin(a)) * sqrt(h) + n * sqrt(1.0 - h);
                float sc = mix(0.12, 1.0, fract(fi * 0.6180339));
                vec3 sp = vp + n * 0.03 + dir * r * sc * sc;
                vec2 suv = toScreen(sp);
                if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) continue;
                vec3 sv = toView(suv, texture2D(depthtex0, suv).r);
                float range = smoothstep(0.0, 1.0, r / max(abs(vp.z - sv.z), 0.001));
                occ += (sv.z >= sp.z + 0.02 ? 1.0 : 0.0) * range;
            }
            ao = 1.0 - occ / 12.0;
            ao = mix(1.0, ao, smoothstep(64.0, 36.0, dist));
        }
    }
#endif
    gl_FragData[0] = vec4(ao, ao, ao, 1.0);
}
