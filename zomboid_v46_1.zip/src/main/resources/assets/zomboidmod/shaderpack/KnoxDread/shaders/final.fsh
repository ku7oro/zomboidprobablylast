#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;
varying vec2 texcoord;
float bayer2(vec2 a) {
    a = floor(a);
    return fract(dot(a, vec2(0.5, a.y * 0.75)));
}
float bayer8(vec2 a) {
    return bayer2(0.25 * a) * 0.0625 + bayer2(0.5 * a) * 0.25 + bayer2(a);
}
vec3 shoulder(vec3 c) {
    vec3 over = max(c - 0.8, 0.0);
    return min(c, vec3(0.8)) + 0.2 * (1.0 - exp(-over / 0.2));
}
void main() {
    vec3 c = texture2D(colortex0, texcoord).rgb;
#ifdef BLOOM
    vec3 bl = vec3(0.0);
    bl += max(texture2D(colortex0, texcoord, 2.0).rgb - 0.85, 0.0) * 0.30;
    bl += max(texture2D(colortex0, texcoord, 3.5).rgb - 0.80, 0.0) * 0.35;
    bl += max(texture2D(colortex0, texcoord, 5.0).rgb - 0.75, 0.0) * 0.45;
    bl += max(texture2D(colortex0, texcoord, 6.5).rgb - 0.70, 0.0) * 0.55;
    c += bl * 0.55 * BLOOM_STRENGTH;
#endif
    c = shoulder(c);
    float day = dayFactor();
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(l), c, COLOR_SATURATION);
    c = max((c - 0.3) * mix(1.0, 1.08, day) + 0.3, c * 0.85);
    c += vec3(-0.012, 0.004, 0.010) * (1.0 - l) + vec3(0.010, 0.004, -0.012) * l;
#ifdef VIGNETTE
    vec2 d = texcoord - 0.5;
    float vig = 1.0 - dot(d, d) * (1.3 + 1.1 * (1.0 - day));
    c *= clamp(vig, 0.0, 1.0);
#endif
#ifdef FILM_GRAIN
    float n = hash12(gl_FragCoord.xy + floor(fract(frameTimeCounter) * 24.0) * vec2(61.0, 113.0));
    c += (n - 0.5) * 0.018;
#endif
    c += (bayer8(gl_FragCoord.xy) - 0.5) / 255.0;
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
