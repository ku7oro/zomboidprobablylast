#version 120
/* DRAWBUFFERS:012 */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;
uniform sampler2D normals;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying vec3 tangent;
varying vec3 binormal;
varying vec3 viewPos;
varying float hasTangent;
varying float foliage;
void main() {
    vec4 albedo = texture2D(texture, texcoord) * color;
    if (albedo.a < 0.1) discard;
    vec3 n = normal;
    float ao = 1.0;
    if (hasTangent > 0.5) {
        vec4 nm = texture2D(normals, texcoord);
        vec3 tn = vec3(nm.xy * 2.0 - 1.0, 0.0);
        tn.z = sqrt(max(1.0 - dot(tn.xy, tn.xy), 0.0));
        n = normalize(mat3(tangent, binormal, normal) * tn);
        ao = mix(1.0, nm.b, 0.6);
    }
    float wetCode = 0.0;
    float upN = dot(normal, normalize(upPosition));
    float exposed = smoothstep(0.86, 0.97, lmcoord.y);
    float wet = clamp(wetness * WETNESS_AMOUNT, 0.0, 1.0) * exposed * (1.0 - foliage);
    if (wet > 0.01) {
        vec3 wp = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
        float puddle = 0.0;
        if (upN > 0.9) {
            float nz = vnoise(wp.xz * 0.11) * 0.62 + vnoise(wp.xz * 0.37 + 7.3) * 0.28 + vnoise(wp.xz * 1.3) * 0.10;
            puddle = smoothstep(0.56, 0.64, nz - 0.18 * (1.0 - wet)) * wet * PUDDLES;
            puddle = clamp(puddle, 0.0, 1.0);
        }
        float porous = wet * (upN > 0.5 ? 1.0 : 0.55);
        albedo.rgb *= 1.0 - 0.34 * porous - 0.12 * puddle;
        albedo.rgb = mix(albedo.rgb, albedo.rgb * albedo.rgb * 1.6, 0.25 * porous);
        wetCode = puddle > 0.02 ? 0.5 + 0.5 * puddle : 0.45 * wet * (upN > 0.5 ? 1.0 : 0.3);
    }
    vec3 c = lighting(albedo.rgb * ao, lmcoord, n, viewPos, true, foliage);
    gl_FragData[0] = vec4(applyFog(c, viewPos), albedo.a);
    gl_FragData[1] = vec4(n * 0.5 + 0.5, foliage > 0.5 ? MAT_FOLIAGE : MAT_TERRAIN);
    gl_FragData[2] = vec4(lmcoord, g_sunlit, wetCode);
}
