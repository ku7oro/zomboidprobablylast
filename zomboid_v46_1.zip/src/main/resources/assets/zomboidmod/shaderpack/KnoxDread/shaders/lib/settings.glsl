const int shadowMapResolution = 2048; // [1024 2048 3072 4096]
const float shadowDistance = 112.0;
const bool shadowHardwareFiltering = false;
const float sunPathRotation = -25.0;
const float shadowDistanceRenderMul = 1.0;
const float ambientOcclusionLevel = 1.0;

#define NIGHT_BRIGHTNESS 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
#define FOG_DENSITY 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0]
#define COLOR_SATURATION 0.62 // [0.4 0.5 0.62 0.74 0.85 1.0]
#define SHADOW_DARKNESS 1.0 // [0.6 0.8 1.0 1.2]
#define SHADOW_SOFTNESS 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define FLASHLIGHT_POWER 2.2 // [1.2 1.8 2.2 2.8 3.6]
#define AO_STRENGTH 1.0 // [0.0 0.5 0.75 1.0 1.25 1.5]
#define GOD_RAYS_STRENGTH 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define WETNESS_AMOUNT 1.0 // [0.0 0.5 1.0 1.5]
#define PUDDLES 1.0 // [0.0 0.5 1.0 1.5]
#define BLOOM_STRENGTH 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define WAVING_PLANTS
#define LEAF_TRANSLUCENCY
#define SSAO
#define GOD_RAYS
#define REFLECTIONS
#define RAIN_RIPPLES
#define BLOOM
#define VIGNETTE
//#define FILM_GRAIN
