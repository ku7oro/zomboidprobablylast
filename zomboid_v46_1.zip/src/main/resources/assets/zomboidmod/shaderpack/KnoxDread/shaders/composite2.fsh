#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/view.glsl"
uniform sampler2D colortex0;
uniform sampler2D depthtex1;
uniform ivec2 eyeBrightnessSmooth;
uniform int isEyeInWater;
varying vec2 texcoord;
/* DRAWBUFFERS:0 */
void main() {
    vec3 c = texture2D(colortex0, texcoord).rgb;
#ifdef GOD_RAYS
    float day = dayFactor();
    vec3 L = normalize(shadowLightPosition);
    vec4 sp = gbufferProjection * vec4(L * 100.0, 1.0);
    vec3 dir = normalize(toView(texcoord, 1.0));
    float cosA = dot(dir, L);
    float outside = clamp(float(eyeBrightnessSmooth.y) / 200.0, 0.0, 1.0);
    if (sp.w > 0.0 && cosA > 0.3 && GOD_RAYS_STRENGTH > 0.0 && outside > 0.02 && isEyeInWater == 0) {
        vec2 suv = sp.xy / sp.w * 0.5 + 0.5;
        vec2 delta = (suv - texcoord) / 26.0;
        vec2 uv = texcoord + delta * ign(gl_FragCoord.xy);
        float acc = 0.0, wsum = 0.0, wgt = 1.0;
        for (int i = 0; i < 26; i++) {
            vec2 q = clamp(uv, 0.0, 1.0);
            acc += (texture2D(depthtex1, q).r >= 1.0 ? 1.0 : 0.0) * wgt;
            wsum += wgt;
            wgt *= 0.95;
            uv += delta;
        }
        acc /= wsum;
        float t = float(worldTime);
        float dawn = (t > 21500.0 || t < 2500.0 || (t > 11500.0 && t < 13500.0)) ? 1.0 : 0.0;
        float haze = 0.35 + 0.35 * FOG_DENSITY + 0.6 * dawn;
        float sunH = sunHeight();
        vec3 sunC = mix(vec3(1.0, 0.5, 0.25), vec3(1.0, 0.88, 0.7), smoothstep(0.0, 0.4, sunH));
        vec3 lc = mix(vec3(0.25, 0.32, 0.45) * 0.25, sunC, day);
        float shape = pow(max(cosA, 0.0), 5.0);
        float d0 = texture2D(depthtex1, texcoord).r;
        float scatter = d0 >= 1.0 ? 1.0 : 1.0 - exp(-length(toView(texcoord, d0)) / 38.0);
        c += lc * acc * shape * haze * scatter * 0.45 * GOD_RAYS_STRENGTH * (1.0 - rainStrength * 0.85) * outside;
    }
#endif
    gl_FragData[0] = vec4(c, 1.0);
}
