uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 upPosition;
uniform vec3 shadowLightPosition;
uniform float rainStrength;
uniform float wetness;
uniform int worldTime;
uniform float nightVision;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform float fogEnd;
uniform float far;
uniform float near;
uniform vec3 cameraPosition;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform float frameTimeCounter;

float sunHeight() {
    return dot(normalize(sunPosition), normalize(upPosition));
}

float dayFactor() {
    return smoothstep(-0.08, 0.22, sunHeight());
}

vec3 fogTint(float day) {
    vec3 dayC = mix(vec3(0.37, 0.39, 0.385), vec3(0.24, 0.26, 0.265), rainStrength);
    vec3 nightC = vec3(0.014, 0.017, 0.024) * NIGHT_BRIGHTNESS;
    float dusk = (1.0 - smoothstep(0.0, 0.3, abs(sunHeight()))) * (1.0 - rainStrength);
    return mix(nightC, dayC, day) + vec3(0.10, 0.04, 0.01) * dusk * day;
}

vec3 skyColor(vec3 dir) {
    float day = dayFactor();
    float up = dot(dir, normalize(upPosition));
    vec3 zenith = mix(vec3(0.006, 0.008, 0.012), vec3(0.23, 0.255, 0.28), day);
    zenith = mix(zenith, vec3(0.19, 0.20, 0.21) * day + 0.004, rainStrength);
    vec3 horizon = fogTint(day);
    float sunDot = max(dot(dir, normalize(sunPosition)), 0.0);
    float glow = pow(sunDot, 6.0) * (1.0 - smoothstep(0.0, 0.35, abs(sunHeight()))) * (1.0 - rainStrength);
    return mix(horizon, zenith, smoothstep(-0.05, 0.45, up)) + vec3(0.42, 0.18, 0.07) * glow * 0.6;
}

float fogAmount(vec3 viewPos) {
    float day = dayFactor();
    float dist = length(viewPos);
    float end = far;
    if (fogEnd > 4.0 && fogEnd < far * 1.5) end = min(fogEnd, far);
    end *= mix(0.5, 1.0, day);
    float f = clamp(dist / max(end, 8.0), 0.0, 1.0);
    f = 1.0 - exp(-f * f * 4.5 * FOG_DENSITY);
    vec3 wp = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
    float t = float(worldTime);
    float dawn = (t > 21500.0 || t < 2500.0) ? 1.0 : 0.0;
    float mistAmount = (0.22 + 0.45 * rainStrength + 0.4 * dawn) * FOG_DENSITY;
    float mist = exp(-max(wp.y - 62.0, 0.0) / 7.0) * smoothstep(6.0, 40.0, dist) * mistAmount;
    return clamp(f + mist, 0.0, 1.0);
}

vec3 applyFog(vec3 color, vec3 viewPos) {
    return mix(color, fogTint(dayFactor()), fogAmount(viewPos));
}

vec2 normLightmap(vec2 lm) {
    return clamp((lm - 0.03125) * 1.06667, 0.0, 1.0);
}

float ign(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hash12(i), b = hash12(i + vec2(1.0, 0.0)), c = hash12(i + vec2(0.0, 1.0)), d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

const float MAT_TERRAIN = 0.2;
const float MAT_FOLIAGE = 0.4;
const float MAT_ENTITY = 0.6;
const float MAT_HAND = 0.7;
const float MAT_WATER = 0.8;
const float MAT_GLASS = 0.9;
