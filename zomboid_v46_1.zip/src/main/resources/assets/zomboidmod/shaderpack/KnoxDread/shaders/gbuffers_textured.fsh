#version 120
/* DRAWBUFFERS:012 */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying vec3 viewPos;
void main() {
    vec4 albedo = texture2D(texture, texcoord) * color;
    if (albedo.a < 0.1) discard;
    
    vec3 c = lighting(albedo.rgb, lmcoord, normalize(normal), viewPos, false, 0.0);
    gl_FragData[0] = vec4(applyFog(c, viewPos), albedo.a);
    gl_FragData[1] = vec4(0.0);
    gl_FragData[2] = vec4(0.0);
}
