package com.example.zomboidmod.survival;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.block.FurnitureBlock;
import com.example.zomboidmod.block.FurnitureBlockEntity;
import com.example.zomboidmod.vehicle.GasCanItem;
import net.minecraft.block.BlockState;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsage;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.potion.Potions;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.SmeltingRecipe;
import net.minecraft.recipe.input.SingleStackRecipeInput;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.Optional;

/**
 * Бытовые приборы: холодильник (замедляет порчу при токе), плита (готовит при токе), генератор (бензин, шум,
 * угарный газ в помещении), бочка для дождевой воды, краны (чистая вода до отключения), унитаз и ванна (сырая вода).
 */
public final class Appliances {
    public static final float GEN_TANK = 20f;          // литров
    public static final float GEN_USE_PER_HOUR = 0.5f; // литров в игровой час
    public static final float BARREL_CAP = 40f;        // порций (бутылок)

    private Appliances() {
    }

    public static boolean ticks(String id) {
        return id.equals("fridge") || id.equals("stove") || id.equals("generator") || id.equals("rain_barrel");
    }

    // ===================== раз в секунду =====================
    public static void tick(ServerWorld w, BlockPos pos, BlockState state, FurnitureBlockEntity be) {
        if (++be.clock % 20 != 0) return;
        String id = state.getBlock() instanceof FurnitureBlock fb ? fb.id : "";
        long now = Clock.now(w);
        switch (id) {
            case "fridge" -> fridge(w, pos, be, now);
            case "stove" -> stove(w, pos, be, now);
            case "generator" -> generator(w, pos, be, now);
            case "rain_barrel" -> {
                if (w.hasRain(pos.up()) && be.water < BARREL_CAP) {
                    be.water = Math.min(BARREL_CAP, be.water + 0.25f);
                    be.markDirty();
                }
            }
            default -> {
            }
        }
    }

    private static void fridge(ServerWorld w, BlockPos pos, FurnitureBlockEntity be, long now) {
        long last = be.lastTime;
        if (last < 0) {                  // впервые: продукты лежат с первого дня
            Food.stampAll(be.stacks(), 0L);
            last = 0;
        }
        long dt = now - last;
        if (dt > 0) {
            // сколько из этого времени был ток от сети
            long off = Power.powerOffTime(w);
            long grid = Math.max(0, Math.min(now, off) - Math.max(last, 0));
            long cold = grid;
            if (Power.generatorNear(w, pos)) cold = dt;   // если сейчас от генератора — считаем, что и до этого
            Food.stampAll(be.stacks(), now);
            Food.shift(be.stacks(), (long) (cold * 0.8));    // в холодильнике еда стареет в 5 раз медленнее
        }
        be.lastTime = now;
        be.markDirty();
    }

    private static void stove(ServerWorld w, BlockPos pos, FurnitureBlockEntity be, long now) {
        if (!Power.powered(w, pos)) return;
        DefaultedList<ItemStack> items = be.stacks();
        boolean any = false;
        for (ItemStack st : items) if (cookable(w, st)) any = true;
        if (!any) return;
        w.spawnParticles(ParticleTypes.SMOKE, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 2, 0.2, 0.02, 0.2, 0.01);
        if (be.clock % 100 != 0) return;           // одна порция за 5 секунд
        for (int i = 0; i < items.size(); i++) {
            ItemStack st = items.get(i);
            if (st.isEmpty()) continue;
            if (st.isOf(SurvivalItems.STEW_RAW)) {
                items.set(i, SurvivalItems.cookStew(st, now, 0));
                done(w, pos, be);
                return;
            }
            if (st.isOf(SurvivalItems.POT_WATER_TAINTED)) {
                items.set(i, new ItemStack(SurvivalItems.POT_WATER));
                done(w, pos, be);
                return;
            }
            ItemStack out = smelt(w, st);
            if (out.isEmpty()) continue;
            if (st.getCount() == 1) items.set(i, out);
            else if (insert(items, out)) st.decrement(1);
            else continue;
            done(w, pos, be);
            return;
        }
    }

    private static void done(ServerWorld w, BlockPos pos, FurnitureBlockEntity be) {
        w.playSound(null, pos, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.3f, 1.6f);
        be.markDirty();
    }

    private static boolean cookable(ServerWorld w, ItemStack st) {
        return !st.isEmpty() && (st.isOf(SurvivalItems.STEW_RAW) || st.isOf(SurvivalItems.POT_WATER_TAINTED) || !smelt(w, st).isEmpty());
    }

    /** Результат жарки, только если это еда (плита не плавит руду). */
    private static ItemStack smelt(ServerWorld w, ItemStack st) {
        Optional<RecipeEntry<SmeltingRecipe>> r = w.getRecipeManager().getFirstMatch(RecipeType.SMELTING, new SingleStackRecipeInput(st), w);
        if (r.isEmpty()) return ItemStack.EMPTY;
        ItemStack out = r.get().value().getResult(w.getRegistryManager()).copy();
        return out.contains(DataComponentTypes.FOOD) || out.isOf(ZomboidMod.CLEAN_WATER) ? out : ItemStack.EMPTY;
    }

    private static boolean insert(DefaultedList<ItemStack> items, ItemStack out) {
        for (ItemStack o : items) {
            if (!o.isEmpty() && ItemStack.areItemsAndComponentsEqual(o, out) && o.getCount() + out.getCount() <= o.getMaxCount()) {
                o.increment(out.getCount());
                return true;
            }
        }
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).isEmpty()) {
                items.set(i, out);
                return true;
            }
        }
        return false;
    }

    private static void generator(ServerWorld w, BlockPos pos, FurnitureBlockEntity be, long now) {
        SurvivalState st = SurvivalState.get(w.getServer());
        long last = be.lastTime < 0 ? now : be.lastTime;
        be.lastTime = now;
        if (!be.on) {
            if (st.generators.remove(pos.asLong())) st.markDirty();
            return;
        }
        long dt = Math.max(0, Math.min(Clock.DAY, now - last));
        be.fuel -= dt / (float) Clock.HOUR * GEN_USE_PER_HOUR;
        be.markDirty();
        if (be.fuel <= 0f) {
            be.fuel = 0f;
            be.on = false;
            st.generators.remove(pos.asLong());
            st.markDirty();
            w.playSound(null, pos, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.8f, 0.6f);
            com.example.zomboidmod.block.PowerLampBlock.refreshAround(w, pos, Power.GEN_RADIUS);
            return;
        }
        if (st.generators.add(pos.asLong())) st.markDirty();
        if (be.clock % 40 == 0) w.playSound(null, pos, SurvivalSounds.GENERATOR, SoundCategory.BLOCKS, 1.4f, 1f);
        if (be.clock % 100 == 0) {
            Noise.emitAt(w, pos, 22);       // генератор слышно издалека
            w.spawnParticles(ParticleTypes.SMOKE, pos.getX() + 0.15, pos.getY() + 0.6, pos.getZ() + 0.5, 3, 0.05, 0.05, 0.05, 0.01);
            // угарный газ: работающий генератор в закрытом помещении отравляет всех рядом
            if (!w.isSkyVisible(pos.up())) {
                for (PlayerEntity p : w.getEntitiesByClass(PlayerEntity.class, new Box(pos).expand(6), e -> e.isAlive() && !e.isCreative())) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 0));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 120, 1));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 0));
                    p.sendMessage(Text.literal("Голова кружится... Угарный газ от генератора!"), true);
                }
            }
        }
    }

    public static void generatorRemoved(World world, BlockPos pos) {
        if (world instanceof ServerWorld sw) {
            SurvivalState st = SurvivalState.get(sw.getServer());
            if (st.generators.remove(pos.asLong())) st.markDirty();
        }
    }

    // ===================== взаимодействие =====================
    private static boolean waterSource(String id) {
        return id.equals("kitchen_sink") || id.equals("bathroom_sink") || id.equals("toilet") || id.equals("bathtub") || id.equals("rain_barrel");
    }

    /** ПКМ по мебели с предметом. null — обычное поведение. */
    public static ItemActionResult useWithItem(FurnitureBlock fb, ItemStack stack, World world, BlockPos pos, PlayerEntity player, Hand hand) {
        String id = fb.id;
        if (id.equals("generator") && stack.getItem() instanceof GasCanItem) {
            if (!world.isClient && world.getBlockEntity(pos) instanceof FurnitureBlockEntity be) {
                float have = GasCanItem.liters(stack), n = Math.min(have, GEN_TANK - be.fuel);
                if (n <= 0.05f) player.sendMessage(Text.literal(have <= 0.05f ? "Канистра пуста" : "Бак генератора полон"), true);
                else {
                    be.fuel += n;
                    GasCanItem.setLiters(stack, have - n);
                    be.markDirty();
                    world.playSound(null, pos, com.example.zomboidmod.vehicle.Vehicles.REFUEL, SoundCategory.BLOCKS, 1f, 1f);
                    player.sendMessage(Text.literal(String.format("Генератор: %.1f / %.0f л", be.fuel, GEN_TANK)), true);
                }
            }
            return ItemActionResult.success(world.isClient);
        }
        if (waterSource(id) && (stack.isOf(Items.GLASS_BOTTLE) || stack.isOf(SurvivalItems.COOKING_POT))) {
            if (!world.isClient && player instanceof ServerPlayerEntity sp) fill(sp, id, (ServerWorld) world, pos, stack, hand);
            return ItemActionResult.success(world.isClient);
        }
        return null;
    }

    /** 0 — нет воды, 1 — сырая (из бочки, унитаза, остатки в трубах), 2 — чистая из крана. */
    private static int takeWater(ServerPlayerEntity p, String id, ServerWorld w, BlockPos pos, int portions) {
        if (id.equals("rain_barrel")) {
            if (w.getBlockEntity(pos) instanceof FurnitureBlockEntity be && be.water >= portions) {
                be.water -= portions;
                be.markDirty();
                return 1;
            }
            p.sendMessage(Text.literal("В бочке мало воды. Она наполняется во время дождя"), true);
            return 0;
        }
        boolean tap = !id.equals("toilet");
        if (Power.waterOn(w)) return tap ? 2 : 1;
        // после отключения в трубах и бачке остаётся немного воды
        SurvivalState st = SurvivalState.get(w.getServer());
        int cap = id.equals("bathtub") ? 12 : (id.equals("toilet") ? 4 : 5);
        int used = st.sinkUses.getOrDefault(pos.asLong(), 0);
        if (used + portions > cap) {
            p.sendMessage(Text.literal("Воды нет: водопровод отключён"), true);
            return 0;
        }
        st.sinkUses.put(pos.asLong(), used + portions);
        st.markDirty();
        return 1;
    }

    private static void fill(ServerPlayerEntity p, String id, ServerWorld w, BlockPos pos, ItemStack stack, Hand hand) {
        boolean pot = stack.isOf(SurvivalItems.COOKING_POT);
        int kind = takeWater(p, id, w, pos, pot ? 4 : 1);
        if (kind == 0) return;
        ItemStack out;
        if (pot) out = new ItemStack(kind == 2 ? SurvivalItems.POT_WATER : SurvivalItems.POT_WATER_TAINTED);
        else out = kind == 2 ? new ItemStack(ZomboidMod.CLEAN_WATER) : PotionContentsComponent.createStack(Items.POTION, Potions.WATER);
        p.setStackInHand(hand, ItemUsage.exchangeStack(stack, p, out));
        w.playSound(null, pos, SoundEvents.ITEM_BOTTLE_FILL, SoundCategory.BLOCKS, 1f, 1f);
        if (kind == 1) p.sendMessage(Text.literal("Сырая вода: лучше вскипятить"), true);
    }

    /** ПКМ пустой рукой. null — обычное поведение (открыть ящик). */
    public static ActionResult use(FurnitureBlock fb, World world, BlockPos pos, PlayerEntity player) {
        String id = fb.id;
        switch (id) {
            case "generator" -> {
                if (!world.isClient && world.getBlockEntity(pos) instanceof FurnitureBlockEntity be) {
                    if (player.isSneaking()) {
                        player.sendMessage(Text.literal(String.format("Генератор: %s, бензин %.1f / %.0f л (хватит на ~%.0f ч)",
                                be.on ? "работает" : "выключен", be.fuel, GEN_TANK, be.fuel / GEN_USE_PER_HOUR)), true);
                    } else if (!be.on && be.fuel <= 0.05f) {
                        player.sendMessage(Text.literal("Нет бензина. Залейте из канистры (ПКМ канистрой)"), true);
                    } else {
                        be.on = !be.on;
                        be.lastTime = Clock.now(world);
                        be.markDirty();
                        SurvivalState st = SurvivalState.get(world.getServer());
                        if (be.on) st.generators.add(pos.asLong());
                        else st.generators.remove(pos.asLong());
                        st.markDirty();
                        com.example.zomboidmod.block.PowerLampBlock.refreshAround((ServerWorld) world, pos, Power.GEN_RADIUS);
                        world.playSound(null, pos, be.on ? com.example.zomboidmod.vehicle.Vehicles.ENGINE_START : SoundEvents.BLOCK_FIRE_EXTINGUISH,
                                SoundCategory.BLOCKS, 1f, be.on ? 0.7f : 0.8f);
                        player.sendMessage(Text.literal(be.on ? "Генератор запущен: даёт ток в радиусе " + Power.GEN_RADIUS + " блоков. Он громкий!"
                                : "Генератор выключен"), true);
                    }
                }
                return ActionResult.success(world.isClient);
            }
            case "rain_barrel" -> {
                if (!world.isClient && world.getBlockEntity(pos) instanceof FurnitureBlockEntity be)
                    player.sendMessage(Text.literal(String.format("Бочка: %.0f / %.0f порций дождевой воды", be.water, BARREL_CAP)), true);
                return ActionResult.success(world.isClient);
            }
            case "tv", "radio" -> {
                if (!world.isClient && player instanceof ServerPlayerEntity sp) Broadcasts.toggle(sp, (ServerWorld) world, pos, id.equals("tv"));
                return ActionResult.success(world.isClient);
            }
            case "kitchen_sink", "bathroom_sink", "toilet", "bathtub" -> {
                if (!player.isSneaking() || !player.getMainHandStack().isEmpty()) return null;
                if (!world.isClient && player instanceof ServerPlayerEntity sp) {
                    if (ZomboidMod.getThirst(sp) >= ZomboidMod.MAX_THIRST) {
                        sp.sendMessage(Text.literal("Пить не хочется"), true);
                    } else {
                        int kind = takeWater(sp, id, (ServerWorld) world, pos, 1);
                        if (kind > 0) {
                            ZomboidMod.addThirst(sp, 15);
                            world.playSound(null, pos, SoundEvents.ENTITY_GENERIC_DRINK, SoundCategory.PLAYERS, 0.8f, 1f);
                            if (kind == 1) Survival.taintedSip(sp, 0.25f);
                        }
                    }
                }
                return ActionResult.success(world.isClient);
            }
            default -> {
                return null;
            }
        }
    }
}
