package com.example.zomboidmod;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/** Вещи в карманах зомби: общий набор плюс набор по одежде (у врача лекарства, у полицейского ключи и т.д.). */
public final class ZombieLoot {
    private record Entry(Supplier<Item> item, int min, int max, float chance) {}

    private static Entry e(Supplier<Item> item, int min, int max, float chance) {
        return new Entry(item, min, max, chance);
    }

    private static final List<Entry> COMMON = List.of(
            e(() -> Items.BREAD, 1, 1, 0.10f),
            e(() -> Items.APPLE, 1, 2, 0.08f),
            e(() -> Items.COOKIE, 1, 3, 0.06f),
            e(() -> ZomboidMod.BANDAGE, 1, 2, 0.04f),
            e(() -> ZomboidMod.RAG, 1, 2, 0.08f),
            e(() -> ZomboidMod.KITCHEN_KNIFE, 1, 1, 0.02f),
            e(() -> ZomboidMod.PAINKILLERS, 1, 1, 0.03f),
            e(() -> ZomboidMod.CLEAN_WATER, 1, 1, 0.04f),
            e(() -> Items.TRIPWIRE_HOOK, 1, 1, 0.04f),   // ключи
            e(() -> Items.PAPER, 1, 2, 0.08f),
            e(() -> Items.STRING, 1, 2, 0.05f),
            e(() -> Items.STICK, 1, 2, 0.05f),
            e(() -> Items.IRON_NUGGET, 1, 3, 0.04f),
            e(() -> Items.CLOCK, 1, 1, 0.02f),
            e(() -> Items.TORCH, 1, 3, 0.04f),
            e(() -> Items.FLINT, 1, 1, 0.03f));

    private static final Map<ZombieOutfit, List<Entry>> EXTRA = new EnumMap<>(ZombieOutfit.class);

    static {
        EXTRA.put(ZombieOutfit.POLICE, List.of(
                e(() -> Items.TRIPWIRE_HOOK, 1, 2, 0.25f), e(() -> ZomboidMod.BANDAGE, 1, 2, 0.25f),
                e(() -> ZomboidMod.PAINKILLERS, 1, 1, 0.10f), e(() -> ZomboidMod.CROWBAR, 1, 1, 0.06f),
                e(() -> com.example.zomboidmod.gun.Guns.PISTOL, 1, 1, 0.08f), e(() -> com.example.zomboidmod.gun.Guns.AMMO_9MM, 2, 8, 0.35f), e(() -> ZomboidMod.NIGHTSTICK, 1, 1, 0.15f)));
        EXTRA.put(ZombieOutfit.SECURITY, List.of(
                e(() -> Items.TRIPWIRE_HOOK, 1, 2, 0.30f), e(() -> Items.TORCH, 1, 3, 0.20f),
                e(() -> ZomboidMod.BANDAGE, 1, 1, 0.15f)));
        EXTRA.put(ZombieOutfit.DOCTOR, List.of(
                e(() -> ZomboidMod.ANTISEPTIC, 1, 1, 0.30f), e(() -> ZomboidMod.BANDAGE, 1, 3, 0.50f),
                e(() -> ZomboidMod.SUTURE_KIT, 1, 1, 0.20f), e(() -> ZomboidMod.PAINKILLERS, 1, 2, 0.35f),
                e(() -> ZomboidMod.ANTIBIOTICS, 1, 1, 0.20f), e(() -> ZomboidMod.SPLINT, 1, 1, 0.12f)));
        EXTRA.put(ZombieOutfit.NURSE, List.of(
                e(() -> ZomboidMod.BANDAGE, 1, 3, 0.45f), e(() -> ZomboidMod.ANTISEPTIC, 1, 1, 0.25f),
                e(() -> ZomboidMod.PAINKILLERS, 1, 2, 0.30f), e(() -> ZomboidMod.ANTIBIOTICS, 1, 1, 0.12f)));
        EXTRA.put(ZombieOutfit.FIREFIGHTER, List.of(
                e(() -> ZomboidMod.CLEAN_WATER, 1, 1, 0.25f), e(() -> ZomboidMod.BANDAGE, 1, 2, 0.25f),
                e(() -> ZomboidMod.FIRE_AXE, 1, 1, 0.08f), e(() -> Items.TORCH, 1, 3, 0.20f)));
        EXTRA.put(ZombieOutfit.SOLDIER, List.of(
                e(() -> com.example.zomboidmod.backpack.Backpacks.MILITARY, 1, 1, 0.1f),
                e(() -> Items.DRIED_KELP, 2, 5, 0.30f), e(() -> ZomboidMod.BANDAGE, 1, 3, 0.30f),
                e(() -> ZomboidMod.PAINKILLERS, 1, 1, 0.12f), e(() -> ZomboidMod.ANTISEPTIC, 1, 1, 0.12f),
                e(() -> ZomboidMod.HUNTING_KNIFE, 1, 1, 0.12f), e(() -> com.example.zomboidmod.gun.Guns.PISTOL, 1, 1, 0.06f),
                e(() -> com.example.zomboidmod.gun.Guns.AMMO_9MM, 3, 10, 0.30f), e(() -> com.example.zomboidmod.gun.Guns.RIFLE_ROUNDS, 2, 6, 0.15f)));
        EXTRA.put(ZombieOutfit.HAZMAT, List.of(
                e(() -> ZomboidMod.ANTIBIOTICS, 1, 1, 0.20f), e(() -> ZomboidMod.ANTISEPTIC, 1, 1, 0.25f),
                e(() -> ZomboidMod.CLEAN_WATER, 1, 1, 0.15f)));
        EXTRA.put(ZombieOutfit.SURVIVOR, List.of(
                e(() -> com.example.zomboidmod.backpack.Backpacks.HIKING, 1, 1, 0.12f),
                e(() -> Items.DRIED_KELP, 2, 6, 0.45f), e(() -> Items.MAP, 1, 1, 0.25f),
                e(() -> Items.COMPASS, 1, 1, 0.15f), e(() -> ZomboidMod.HUNTING_KNIFE, 1, 1, 0.15f),
                e(() -> ZomboidMod.MACHETE, 1, 1, 0.08f), e(() -> ZomboidMod.RAG, 1, 3, 0.35f), e(() -> ZomboidMod.CLEAN_WATER, 1, 2, 0.30f),
                e(() -> ZomboidMod.BANDAGE, 1, 3, 0.40f), e(() -> ZomboidMod.SPLINT, 1, 1, 0.12f),
                e(() -> ZomboidMod.ANTISEPTIC, 1, 1, 0.12f), e(() -> Items.COOKIE, 1, 3, 0.25f)));
        EXTRA.put(ZombieOutfit.FARMER, List.of(
                e(() -> Items.WHEAT, 1, 4, 0.25f), e(() -> Items.POTATO, 1, 3, 0.20f),
                e(() -> Items.CARROT, 1, 3, 0.20f), e(() -> ZomboidMod.HAND_AXE, 1, 1, 0.06f)));
        EXTRA.put(ZombieOutfit.CONSTRUCTION, List.of(
                e(() -> Items.IRON_NUGGET, 2, 6, 0.25f), e(() -> ZomboidMod.HAMMER, 1, 1, 0.10f), e(() -> ZomboidMod.CROWBAR, 1, 1, 0.05f),
                e(() -> Items.OAK_PLANKS, 2, 4, 0.10f), e(() -> Items.STICK, 1, 3, 0.15f)));
        EXTRA.put(ZombieOutfit.MECHANIC, List.of(
                e(() -> Items.IRON_INGOT, 1, 1, 0.10f), e(() -> ZomboidMod.CROWBAR, 1, 1, 0.08f), e(() -> ZomboidMod.HAMMER, 1, 1, 0.06f),
                e(() -> Items.TRIPWIRE_HOOK, 1, 1, 0.12f), e(() -> Items.COAL, 1, 2, 0.15f)));
        EXTRA.put(ZombieOutfit.PRISONER, List.of(
                e(() -> Items.STICK, 1, 1, 0.10f), e(() -> Items.TRIPWIRE_HOOK, 1, 1, 0.03f)));
        EXTRA.put(ZombieOutfit.BIKER, List.of(
                e(() -> Items.LEATHER, 1, 3, 0.25f), e(() -> ZomboidMod.BASEBALL_BAT, 1, 1, 0.10f),
                e(() -> ZomboidMod.BANDAGE, 1, 1, 0.15f), e(() -> Items.TRIPWIRE_HOOK, 1, 1, 0.15f)));
        EXTRA.put(ZombieOutfit.BUSINESS, List.of(
                e(() -> Items.GOLD_NUGGET, 1, 3, 0.12f), e(() -> Items.CLOCK, 1, 1, 0.12f),
                e(() -> Items.PAPER, 1, 3, 0.30f), e(() -> Items.TRIPWIRE_HOOK, 1, 1, 0.15f)));
        EXTRA.put(ZombieOutfit.STUDENT, List.of(
                e(() -> com.example.zomboidmod.backpack.Backpacks.SCHOOL, 1, 1, 0.25f),
                e(() -> Items.PAPER, 1, 4, 0.30f), e(() -> Items.APPLE, 1, 1, 0.12f),
                e(() -> Items.COOKIE, 1, 2, 0.12f), e(() -> ZomboidMod.BASEBALL_BAT, 1, 1, 0.05f)));
        EXTRA.put(ZombieOutfit.TRAILER, List.of(
                e(() -> Items.TRIPWIRE_HOOK, 1, 1, 0.10f), e(() -> Items.FLINT, 1, 1, 0.10f),
                e(() -> Items.COAL, 1, 2, 0.15f)));
        EXTRA.put(ZombieOutfit.PRIEST, List.of(
                e(() -> Items.PAPER, 1, 2, 0.20f), e(() -> ZomboidMod.CLEAN_WATER, 1, 1, 0.12f),
                e(() -> Items.GOLD_NUGGET, 1, 2, 0.08f)));
        EXTRA.put(ZombieOutfit.CHEF, List.of(
                e(() -> Items.BREAD, 1, 2, 0.30f), e(() -> ZomboidMod.KITCHEN_KNIFE, 1, 1, 0.12f), e(() -> ZomboidMod.FRYING_PAN, 1, 1, 0.08f),
                e(() -> Items.SUGAR, 1, 2, 0.15f)));
    }

    private ZombieLoot() {
    }

    /** Выбрасывает содержимое карманов при смерти зомби. */
    public static void drop(PzZombieEntity z, ZombieOutfit outfit, Random r) {
        if (r.nextFloat() < 0.2f) return; // у каждого пятого карманы пусты
        List<ItemStack> out = new ArrayList<>();
        roll(COMMON, r, out);
        List<Entry> extra = EXTRA.get(outfit);
        if (extra != null) roll(extra, r, out);
        for (ItemStack st : out) z.dropStack(st);
    }

    private static void roll(List<Entry> list, Random r, List<ItemStack> out) {
        for (Entry en : list) {
            if (r.nextFloat() < en.chance()) {
                Item item = en.item().get();
                if (item == null) continue;
                int count = en.min() + (en.max() > en.min() ? r.nextInt(en.max() - en.min() + 1) : 0);
                out.add(new ItemStack(item, count));
            }
        }
    }
}
