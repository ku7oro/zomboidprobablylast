package com.example.zomboidmod.world;

import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.ModificationPhase;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.world.GameRules;
import net.minecraft.world.gen.GenerationStep;

import java.util.Set;

/**
 * Мир Project Zomboid вместо Minecraft: из биомов убраны руды, пещеры, лавовые озёра, жеоды, подземелья;
 * никаких враждебных мобов, кроме зомби; домашний скот только на фермах, в природе — олени и кролики;
 * без фантомов, патрулей, торговцев; порталы в Незер не зажигаются. Рельеф и биомы — в датапаке (gen_world.py).
 */
public final class PzWorld {
    private static final String[] FEATURES = {
            "ore_dirt", "ore_gravel", "ore_granite_upper", "ore_granite_lower", "ore_diorite_upper", "ore_diorite_lower",
            "ore_andesite_upper", "ore_andesite_lower", "ore_tuff", "ore_coal_upper", "ore_coal_lower", "ore_iron_upper",
            "ore_iron_middle", "ore_iron_small", "ore_gold", "ore_gold_lower", "ore_gold_extra", "ore_redstone", "ore_redstone_lower",
            "ore_diamond", "ore_diamond_medium", "ore_diamond_large", "ore_diamond_buried", "ore_lapis", "ore_lapis_buried",
            "ore_copper", "ore_copper_large", "ore_emerald", "ore_infested", "ore_clay", "underwater_magma",
            "lake_lava_underground", "lake_lava_surface", "amethyst_geode", "monster_room", "monster_room_deep",
            "spring_water", "spring_lava", "spring_lava_frozen", "fossil_upper", "fossil_lower", "glow_lichen",
            "large_dripstone", "dripstone_cluster", "pointed_dripstone", "sculk_vein", "sculk_patch_deep_dark", "sculk_patch_ancient_city"};
    private static final String[] CARVERS = {"cave", "cave_extra_underground", "canyon"};
    private static final Set<EntityType<?>> ZOMBIES = Set.of(EntityType.ZOMBIE, EntityType.HUSK, EntityType.DROWNED, EntityType.ZOMBIE_VILLAGER);

    private PzWorld() {
    }

    public static void register() {
        Wanderers.register();
        Stories.register();
        BiomeModifications.create(Identifier.of(ZomboidMod.MOD_ID, "knox_county")).add(ModificationPhase.REMOVALS, BiomeSelectors.all(), (sel, ctx) -> {
            for (String f : FEATURES)
                ctx.getGenerationSettings().removeFeature(RegistryKey.of(RegistryKeys.PLACED_FEATURE, Identifier.ofVanilla(f)));
            for (String c : CARVERS)
                ctx.getGenerationSettings().removeCarver(GenerationStep.Carver.AIR, RegistryKey.of(RegistryKeys.CONFIGURED_CARVER, Identifier.ofVanilla(c)));
            // из враждебных — только зомби (они превращаются в зомби PZ); скот — только на фермах
            ctx.getSpawnSettings().removeSpawns((group, entry) -> (group == SpawnGroup.MONSTER && entry.type != EntityType.ZOMBIE)
                    || (group == SpawnGroup.CREATURE && entry.type != EntityType.RABBIT && entry.type != com.example.zomboidmod.wildlife.Wildlife.DEER)
                    || entry.type == EntityType.SQUID || entry.type == EntityType.GLOW_SQUID);
        });

        // на всякий случай: любые другие монстры (из яиц, спавнеров, событий) в мир не попадают
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity.getType().getSpawnGroup() != SpawnGroup.MONSTER || entity instanceof com.example.zomboidmod.PzZombieEntity) return;
            if (entity instanceof ZombieEntity && ZOMBIES.contains(entity.getType())) return;   // их заменит зомби PZ
            if (entity.getType() == EntityType.ZOMBIE) return;
            world.getServer().execute(entity::discard);
        });

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            GameRules r = server.getGameRules();
            r.get(GameRules.DO_INSOMNIA).set(false, server);          // фантомов нет
            r.get(GameRules.DO_PATROL_SPAWNING).set(false, server);   // разбойников нет
            r.get(GameRules.DO_TRADER_SPAWNING).set(false, server);   // торговцев нет
        });

        // порталов нет: обсидиан не поджечь
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            var st = player.getStackInHand(hand);
            if ((st.isOf(Items.FLINT_AND_STEEL) || st.isOf(Items.FIRE_CHARGE)) && world.getBlockState(hit.getBlockPos()).isOf(Blocks.OBSIDIAN)) {
                if (!world.isClient) player.sendMessage(Text.literal("Ничего не происходит. Здесь нет других миров — только этот."), true);
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }
}
