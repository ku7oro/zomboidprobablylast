package com.example.zomboidmod;

import com.example.zomboidmod.WeaponKinds.Kind;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Анимации ударов по ключевым позам (замах → удар → доводка → возврат) с плавными переходами.
 * От третьего лица двигаются обе руки, корпус поворачивается и наклоняется, передняя нога делает шаг.
 * Огнестрел держат на вытянутых руках по линии взгляда, при выстреле — отдача.
 */
public final class WeaponAnim {
    private WeaponAnim() {
    }

    public static Kind kind(ItemStack st) {
        return WeaponKinds.kind(st);
    }

    private static float smooth(float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    /** Значение по ключам: times — моменты 0..1, vals — значения в эти моменты. */
    private static float key(float s, float[] times, float[] vals) {
        if (s <= times[0]) return vals[0];
        for (int i = 1; i < times.length; i++) {
            if (s <= times[i]) {
                float t = smooth((s - times[i - 1]) / (times[i] - times[i - 1]));
                return vals[i - 1] + (vals[i] - vals[i - 1]) * t;
            }
        }
        return vals[vals.length - 1];
    }

    private static float recoil(float s) {
        return s < 0.15f ? s / 0.15f : 1f - smooth((s - 0.15f) / 0.85f);
    }

    // ===================== первое лицо =====================
    // ключи: время, сдвиг x/y/z (в блоках), поворот y/z/x (градусы); x и поворот y/z зеркалятся для левой руки
    private static final float[] T_HEAVY = {0f, 0.38f, 0.6f, 0.8f, 1f};
    private static final float[][] K_HEAVY = {
            {0, 0.15f, -0.32f, -0.38f, 0}, {0, 0.28f, -0.32f, -0.38f, 0}, {0, 0.12f, -0.3f, -0.2f, 0},
            {0, 20, -45, -50, 0}, {0, 30, -60, -65, 0}, {0, 45, -105, -95, 0}};
    private static final float[] T_SLASH = {0f, 0.3f, 0.55f, 0.8f, 1f};
    private static final float[][] K_SLASH = {
            {0, 0.25f, -0.4f, -0.45f, 0}, {0, 0.15f, -0.05f, -0.1f, 0}, {0, 0.05f, -0.25f, -0.15f, 0},
            {0, 35, -55, -60, 0}, {0, 40, -35, -40, 0}, {0, 20, -40, -35, 0}};
    private static final float[] T_LIGHT = {0f, 0.32f, 0.55f, 0.75f, 1f};
    private static final float[][] K_LIGHT = {
            {0, 0.05f, -0.15f, -0.15f, 0}, {0, 0.3f, -0.25f, -0.3f, 0}, {0, 0.1f, -0.3f, -0.2f, 0},
            {0, 10, -20, -20, 0}, {0, 15, -25, -25, 0}, {0, 50, -100, -95, 0}};
    private static final float[] T_STAB = {0f, 0.3f, 0.5f, 0.7f, 1f};
    private static final float[][] K_STAB = {
            {0, 0, -0.05f, -0.05f, 0}, {0, -0.03f, 0.05f, 0.04f, 0}, {0, 0.15f, -0.5f, -0.45f, 0},
            {0, 0, -5, -5, 0}, {0, 0, 0, 0, 0}, {0, 8, -12, -10, 0}};

    // копьё/вилы: двумя руками, укол вперёд с подшагом
    private static final float[] T_SPEAR = {0f, 0.32f, 0.52f, 0.72f, 1f};
    private static final float[][] K_SPEAR = {
            {0, 0.03f, -0.1f, -0.07f, 0}, {0, -0.04f, 0.06f, 0.04f, 0}, {0, 0.2f, -0.6f, -0.48f, 0},
            {0, 6, -4, -3, 0}, {0, 0, 0, 0, 0}, {0, -10, 5, 4, 0}};

    // ===================== чередование ударов (справа налево, потом слева направо) =====================
    private static final java.util.Map<Integer, float[]> SWINGS = new java.util.HashMap<>();

    /** true — обратный удар (с другой стороны). Считается по началу каждого нового взмаха. */
    public static boolean backhand(LivingEntity e, float s) {
        float[] st = SWINGS.computeIfAbsent(e.getId(), k -> new float[]{0f, 0f, 0f});
        long now = e.getWorld().getTime();
        if (s > 0f && (st[0] == 0f || s < st[0] - 0.2f)) {
            // новый взмах; если предыдущий был давно — снова «с правой»
            st[1] = now - st[2] > 30 ? 0f : 1f - st[1];
            st[2] = now;
        }
        st[0] = s;
        if (SWINGS.size() > 256) SWINGS.clear();
        return st[1] > 0.5f;
    }

    /** Лёгкое покачивание оружия в руке, когда не бьёшь (дыхание, шаг). */
    private static void idle(MatrixStack m, Arm arm) {
        net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        float t = mc.world.getTime() + mc.getRenderTickCounter().getTickDelta(true);
        int i = arm == Arm.RIGHT ? 1 : -1;
        float sprint = mc.player.isSprinting() ? 1f : 0f;
        m.translate(i * MathHelper.sin(t * 0.045f) * 0.004f, MathHelper.sin(t * 0.09f) * 0.005f - 0.06f * sprint, 0f);
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-18f * sprint));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * 4f * sprint));
    }

    public static void firstPerson(Kind kind, MatrixStack m, Arm arm, float s) {
        int i = arm == Arm.RIGHT ? 1 : -1;
        if (kind == Kind.PISTOL || kind == Kind.LONG_GUN) {
            float k = recoil(s);
            boolean longGun = kind == Kind.LONG_GUN;
            m.translate(0f, 0.03f * k, (longGun ? 0.18f : 0.12f) * k);
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees((longGun ? 12f : 10f) * k));
            return;
        }
        float[] T;
        float[][] K;
        switch (kind) {
            case HEAVY -> { T = T_HEAVY; K = K_HEAVY; }
            case SLASH -> { T = T_SLASH; K = K_SLASH; }
            case STAB -> { T = T_STAB; K = K_STAB; }
            case SPEAR -> { T = T_SPEAR; K = K_SPEAR; }
            default -> { T = T_LIGHT; K = K_LIGHT; }
        }
        if (s <= 0f) idle(m, arm);
        if (kind == Kind.SPEAR) {        // древко держат двумя руками, остриём вперёд
            m.translate(-i * 0.12f, 0.08f, 0f);
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-62f));
        }
        // обратный удар — зеркально по горизонтали (бита, мачете, молоток машут то вправо, то влево)
        net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
        float mir = kind != Kind.STAB && kind != Kind.SPEAR && mc.player != null && backhand(mc.player, s) ? -1f : 1f;
        m.translate(i * mir * key(s, T, K[0]), key(s, T, K[1]), key(s, T, K[2]));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * mir * key(s, T, K[3])));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * mir * key(s, T, K[4])));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(key(s, T, K[5])));
    }

    // ===================== третье лицо =====================
    // поза: рука с оружием (pitch, yaw, roll), вторая рука (pitch, yaw), корпус (поворот, наклон), вынос руки вперёд, шаг ногой
    private static final float NAN = Float.NaN;
    private static final float[] P_HEAVY_T = {0f, 0.38f, 0.62f, 0.8f, 1f};
    private static final float[][] P_HEAVY = {
            {-0.8f, -2.75f, -0.45f, -0.2f, -0.8f}, {-0.25f, -0.55f, 0.55f, 0.75f, -0.25f}, {0, -0.25f, 0.2f, 0.25f, 0},
            {-0.95f, -2.45f, -0.55f, -0.35f, -0.95f}, {0.6f, 0.15f, 0.85f, 0.95f, 0.6f},
            {0, 0.55f, -0.65f, -0.75f, 0}, {0, -0.05f, 0.28f, 0.22f, 0}, {0, 0, 1.5f, 1f, 0}, {0, 0, 0.4f, 0.35f, 0}};
    private static final float[] P_SLASH_T = {0f, 0.3f, 0.55f, 0.8f, 1f};
    private static final float[][] P_SLASH = {
            {-0.9f, -2.3f, -1.2f, -0.7f, -0.9f}, {-0.3f, -0.95f, 0.85f, 1.0f, -0.3f}, {0, -0.3f, 0.3f, 0.2f, 0},
            {-1.0f, -2.1f, -1.25f, -0.8f, -1.0f}, {0.55f, -0.4f, 1.1f, 1.2f, 0.55f},
            {0, 0.7f, -0.8f, -0.85f, 0}, {0, 0, 0.18f, 0.12f, 0}, {0, 0, 2f, 1f, 0}, {0, 0, 0.3f, 0.2f, 0}};
    private static final float[] P_LIGHT_T = {0f, 0.32f, 0.55f, 0.75f, 1f};
    private static final float[][] P_LIGHT = {
            {NAN, -2.9f, -0.55f, -0.35f, NAN}, {NAN, -0.2f, 0.25f, 0.3f, NAN}, {NAN, 0.25f, -0.1f, 0f, NAN},
            null, null,
            {0, 0.3f, -0.35f, -0.4f, 0}, {0, -0.05f, 0.2f, 0.15f, 0}, {0, 0, 1.5f, 1f, 0}, {0, 0, 0.25f, 0.2f, 0}};
    private static final float[] P_STAB_T = {0f, 0.3f, 0.5f, 0.7f, 1f};
    private static final float[][] P_STAB = {
            {NAN, -0.95f, -1.6f, -1.5f, NAN}, {NAN, -0.3f, 0.05f, 0f, NAN}, {NAN, 0f, 0f, 0f, NAN},
            null, null,
            {0, 0.35f, -0.4f, -0.35f, 0}, {0, 0, 0.15f, 0.1f, 0}, {0, -2f, 3f, 2.5f, 0}, {0, 0, 0.3f, 0.2f, 0}};

    /** Значение ключа, где NaN в начале/конце = «как было у ванильной позы» (v). */
    private static float keyV(float s, float[] times, float[] vals, float v) {
        float[] c = vals.clone();
        for (int k = 0; k < c.length; k++) if (Float.isNaN(c[k])) c[k] = v;
        return key(s, times, c);
    }

    /**
     * Огнестрел от третьего лица: в прицеле — винтовка у плеча, вторая рука под цевьём, пистолет — двумя руками;
     * без прицела — «наготове», стволом вниз; на бегу — оружие прижато к груди; при перезарядке — руки у оружия,
     * голова опущена; выстрел подбрасывает руки.
     */
    private static void gunPose(BipedEntityModel<?> model, LivingEntity e, boolean lg, ModelPart main, ModelPart off, float side) {
        ItemStack st = e.getMainHandStack();
        net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
        float td = mc.getRenderTickCounter().getTickDelta(true);
        long time = e.getWorld().getTime();
        float since = time + td - com.example.zomboidmod.gun.GunItem.lastFire(st);
        float kick = since < 0 || since > 20 ? 0f : (since < 1 ? since : (float) Math.exp(-(since - 1) * 0.5f));
        long rl = com.example.zomboidmod.gun.GunItem.reloadEnd(st), rs = com.example.zomboidmod.gun.GunItem.reloadStart(st);
        boolean reloading = time < rl && rl > rs;
        boolean aiming = e.isUsingItem() && e.getActiveItem().getItem() instanceof com.example.zomboidmod.gun.GunItem;
        float hp = model.head.pitch, hy = model.head.yaw;
        if (reloading) {
            float pr = MathHelper.clamp((time + td - rs) / (float) (rl - rs), 0f, 1f);
            float work = MathHelper.sin(pr * MathHelper.PI * 4f) * 0.12f;
            main.pitch = -0.95f;
            main.yaw = -side * 0.15f;
            off.pitch = -1.15f + work;
            off.yaw = side * 0.6f;
            model.head.pitch = Math.max(hp, 0.45f);
            model.hat.copyTransform(model.head);
        } else if (aiming) {
            float base = -MathHelper.HALF_PI + hp;
            main.pitch = base - (lg ? 0.2f : 0.3f) * kick;
            main.yaw = hy - side * (lg ? 0.12f : 0.05f);
            off.pitch = base - (lg ? 0.14f : 0.04f) - (lg ? 0.16f : 0.25f) * kick;
            off.yaw = hy + side * (lg ? 0.62f : 0.48f);
            model.body.yaw = side * (lg ? 0.16f : 0.06f);
        } else if (e.isSprinting()) {
            main.pitch = -0.55f;
            main.yaw = side * 0.25f;
            off.pitch = -0.75f;
            off.yaw = side * 0.7f;
        } else {
            float base = -MathHelper.HALF_PI + hp * 0.4f + (lg ? 0.8f : 0.7f);
            main.pitch = base - 0.15f * kick;
            main.yaw = hy * 0.5f - side * 0.1f;
            off.pitch = base - (lg ? 0.1f : 0.02f);
            off.yaw = side * (lg ? 0.68f : 0.48f);
        }
        main.roll = 0f;
        off.roll = 0f;
    }

    private static final float[] P_SPEAR_T = {0f, 0.32f, 0.52f, 0.72f, 1f};
    private static final float[][] P_SPEAR = {
            {-1.05f, -1.25f, -1.6f, -1.55f, -1.05f}, {0f, 0.12f, 0f, 0f, 0f}, {0f, 0f, 0f, 0f, 0f},
            {-0.95f, -1.15f, -1.5f, -1.45f, -0.95f}, {0.5f, 0.55f, 0.32f, 0.38f, 0.5f},
            {0, 0.25f, -0.22f, -0.15f, 0}, {0, -0.05f, 0.25f, 0.2f, 0}, {0, -2f, 4.5f, 3.5f, 0}, {0, 0, 0.45f, 0.35f, 0}};

    public static void thirdPerson(BipedEntityModel<?> model, LivingEntity e, float limbDistance) {
        Kind k = kind(e.getMainHandStack());
        if (k == null) return;
        boolean right = e.getMainArm() == Arm.RIGHT;
        ModelPart main = right ? model.rightArm : model.leftArm, off = right ? model.leftArm : model.rightArm;
        ModelPart frontLeg = right ? model.leftLeg : model.rightLeg, backLeg = right ? model.rightLeg : model.leftLeg;
        float side = right ? 1f : -1f;
        float s = model.handSwingProgress;

        if (k == Kind.PISTOL || k == Kind.LONG_GUN) {
            gunPose(model, e, k == Kind.LONG_GUN, main, off, side);
            return;
        }

        float[] T;
        float[][] P;
        switch (k) {
            case HEAVY -> { T = P_HEAVY_T; P = P_HEAVY; }
            case SLASH -> { T = P_SLASH_T; P = P_SLASH; }
            case STAB -> { T = P_STAB_T; P = P_STAB; }
            case SPEAR -> { T = P_SPEAR_T; P = P_SPEAR; }
            default -> { T = P_LIGHT_T; P = P_LIGHT; }
        }
        boolean twoHanded = P[3] != null;
        float mir = k != Kind.STAB && k != Kind.SPEAR && s > 0f && backhand(e, s) ? -1f : 1f;
        if (s <= 0f && !twoHanded) return;             // одноручное в покое — обычная поза

        float mp = keyV(s, T, P[0], main.pitch), my = keyV(s, T, P[1], main.yaw * side), mr = keyV(s, T, P[2], main.roll * side);
        float by = key(s, T, P[5]) * side * mir, lean = key(s, T, P[6]), ext = key(s, T, P[7]), leg = key(s, T, P[8]);
        main.pitch = mp;
        main.yaw = my * side * (mir < 0 ? -0.6f : 1f);
        main.roll = mr * side * mir;
        if (twoHanded) {
            off.pitch = key(s, T, P[3]);
            off.yaw = key(s, T, P[4]) * side;
            off.roll = 0f;
        }
        // поворот корпуса: плечи едут вместе с ним (как в ванильном ударе)
        model.body.yaw = by;
        float sx = MathHelper.cos(by) * 5f, sz = MathHelper.sin(by) * 5f;
        model.rightArm.pivotX = -sx;
        model.rightArm.pivotZ = sz;
        model.leftArm.pivotX = sx;
        model.leftArm.pivotZ = -sz;
        model.rightArm.yaw += by;
        model.leftArm.yaw += by;
        main.pivotZ -= ext;
        // наклон вперёд при ударе, бёдра остаются на месте
        if (lean != 0f && !e.isInSneakingPose()) {
            model.body.pitch = lean;
            float fwd = 12f * MathHelper.sin(lean);
            model.rightLeg.pivotZ = fwd;
            model.leftLeg.pivotZ = fwd;
            model.rightLeg.pivotY = 12f * MathHelper.cos(lean);
            model.leftLeg.pivotY = model.rightLeg.pivotY;
            model.rightArm.pivotZ += fwd * 0.35f;
            model.leftArm.pivotZ += fwd * 0.35f;
            model.head.pivotZ = -fwd * 0.6f;
        }
        // шаг передней ногой, если стоит на месте
        if (limbDistance < 0.15f && leg != 0f) {
            frontLeg.pitch = -leg;
            backLeg.pitch = leg * 0.6f;
        }
        model.hat.copyTransform(model.head);
    }
}
