package com.example.zomboidmod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.world.ServerWorld;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.ActionResult;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameRules;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ZomboidMod implements ModInitializer {
    public static final String MOD_ID = "zomboidmod";
    public static final int MAX_THIRST = 100;

    // ===== Настройки жажды =====
    private static final int SECONDS_PER_THIRST_POINT = 20; // ~33 минуты от полной воды до нуля (бег - вдвое быстрее)
    private static final int RIVER_DRINK_TICKS = 40;
    private static final int RIVER_DRINK_AMOUNT = 10;
    private static final float RIVER_POISON_CHANCE = 0.30f;
    private static final int BOTTLE_DRINK_AMOUNT = 20;
    private static final float BOTTLE_POISON_CHANCE = 0.15f;

    // Временные данные (не сохраняются)
    private static final Map<UUID, Integer> TIMER = new HashMap<>();
    private static final Map<UUID, Integer> RIVER_PROGRESS = new HashMap<>();
    private static final Map<UUID, Integer> RIVER_LAST = new HashMap<>();
    private static final Map<UUID, Integer> BOTTLE_LEFT = new HashMap<>();
    private static final Map<UUID, Long> SLEEP_START = new HashMap<>();

    public static Item CLEAN_WATER;
    public static Item BANDAGE;
    public static Item ANTISEPTIC;
    public static Item SUTURE_KIT;
    public static Item SPLINT;
    public static Item PAINKILLERS;
    public static Item ANTIBIOTICS;
    public static Item RAG;

    // Оружие
    public static Item BASEBALL_BAT, SPIKED_BAT, CROWBAR, FRYING_PAN, HAMMER;
    public static Item KITCHEN_KNIFE, HUNTING_KNIFE, MACHETE, HAND_AXE, FIRE_AXE;
    public static Item SLEDGEHAMMER, SHOVEL, GOLF_CLUB, PIPE_WRENCH, NIGHTSTICK, MEAT_CLEAVER, KATANA;
    public static Item METAL_PIPE, PLANK_NAILS, WOOD_AXE, SPEAR, PITCHFORK, COMBAT_KNIFE, ROLLING_PIN, TIRE_IRON;

    public static Item itemFor(MedItem.Kind kind) {
        return switch (kind) {
            case BANDAGE -> BANDAGE;
            case ANTISEPTIC -> ANTISEPTIC;
            case SUTURE -> SUTURE_KIT;
            case SPLINT -> SPLINT;
            case PAINKILLERS -> PAINKILLERS;
            case ANTIBIOTICS -> ANTIBIOTICS;
            case RAG -> RAG;
        };
    }

    public static int getThirst(ServerPlayerEntity p) {
        return ThirstState.get(p.getServer()).thirst.getOrDefault(p.getUuid(), MAX_THIRST);
    }

    private static void setThirst(ServerPlayerEntity p, int value) {
        ThirstState state = ThirstState.get(p.getServer());
        state.thirst.put(p.getUuid(), Math.max(0, Math.min(MAX_THIRST, value)));
        state.markDirty();
    }

    public static void addThirst(ServerPlayerEntity p, int amount) {
        setThirst(p, getThirst(p) + amount);
        sendThirst(p);
    }

    private static void sendThirst(ServerPlayerEntity p) {
        ServerPlayNetworking.send(p, new ThirstPayload(getThirst(p)));
    }

    private static Item register(String id, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(MOD_ID, id), item);
    }

    @Override
    public void onInitialize() {
        ZomboidEntities.register();
        com.example.zomboidmod.wildlife.Wildlife.register();
        com.example.zomboidmod.world.PzWorld.register();
        com.example.zomboidmod.block.ZomboidBlocks.register();
        com.example.zomboidmod.block.BuildingBlocks.register();
        com.example.zomboidmod.parkour.Parkour.register();
        com.example.zomboidmod.vehicle.Vehicles.register();

        CLEAN_WATER = register("clean_water", new CleanWaterItem(new Item.Settings().maxCount(16)
                .recipeRemainder(Items.GLASS_BOTTLE)));
        BANDAGE = register("bandage", new MedItem(new Item.Settings().maxCount(16), MedItem.Kind.BANDAGE));
        ANTISEPTIC = register("antiseptic", new MedItem(new Item.Settings().maxCount(16), MedItem.Kind.ANTISEPTIC));
        SUTURE_KIT = register("suture_kit", new MedItem(new Item.Settings().maxCount(16), MedItem.Kind.SUTURE));
        SPLINT = register("splint", new MedItem(new Item.Settings().maxCount(16), MedItem.Kind.SPLINT));
        PAINKILLERS = register("painkillers", new MedItem(new Item.Settings().maxCount(16), MedItem.Kind.PAINKILLERS));
        ANTIBIOTICS = register("antibiotics", new MedItem(new Item.Settings().maxCount(16), MedItem.Kind.ANTIBIOTICS));
        RAG = register("rag", new MedItem(new Item.Settings().maxCount(32), MedItem.Kind.RAG));

        // Оружие: (материал, урон, скорость атаки, прочность, дробящее, шанс сбить с ног)
        BASEBALL_BAT = register("baseball_bat", new PzWeaponItem(ToolMaterials.WOOD, 6, -2.8f, 180, true, 0.25f, new Item.Settings()));
        SPIKED_BAT = register("spiked_bat", new PzWeaponItem(ToolMaterials.WOOD, 7, -2.8f, 150, true, 0.25f, new Item.Settings()));
        CROWBAR = register("crowbar", new PzWeaponItem(ToolMaterials.IRON, 6, -2.8f, 600, true, 0.20f, new Item.Settings()));
        FRYING_PAN = register("frying_pan", new PzWeaponItem(ToolMaterials.IRON, 5, -2.9f, 400, true, 0.30f, new Item.Settings()));
        HAMMER = register("hammer", new PzWeaponItem(ToolMaterials.IRON, 5, -2.6f, 350, true, 0.15f, new Item.Settings()));
        KITCHEN_KNIFE = register("kitchen_knife", new PzWeaponItem(ToolMaterials.IRON, 4, -1.8f, 90, false, 0f, new Item.Settings()));
        HUNTING_KNIFE = register("hunting_knife", new PzWeaponItem(ToolMaterials.IRON, 5, -1.9f, 250, false, 0f, new Item.Settings()));
        MACHETE = register("machete", new PzWeaponItem(ToolMaterials.IRON, 8, -2.6f, 300, false, 0f, new Item.Settings()));
        HAND_AXE = register("hand_axe", new PzAxeItem(ToolMaterials.IRON, 8f, -3.0f, 300, false, new Item.Settings()));
        FIRE_AXE = register("fire_axe", new PzAxeItem(ToolMaterials.IRON, 11f, -3.4f, 450, true, new Item.Settings()));
        SLEDGEHAMMER = register("sledgehammer", new PzWeaponItem(ToolMaterials.IRON, 14, -3.55f, 500, true, 0.65f, new Item.Settings()));
        SHOVEL = register("shovel", new PzWeaponItem(ToolMaterials.IRON, 7, -3.0f, 300, true, 0.3f, new Item.Settings()));
        GOLF_CLUB = register("golf_club", new PzWeaponItem(ToolMaterials.IRON, 6, -2.7f, 150, true, 0.2f, new Item.Settings()));
        PIPE_WRENCH = register("pipe_wrench", new PzWeaponItem(ToolMaterials.IRON, 6, -2.8f, 600, true, 0.2f, new Item.Settings()));
        NIGHTSTICK = register("nightstick", new PzWeaponItem(ToolMaterials.WOOD, 5, -2.3f, 450, true, 0.15f, new Item.Settings()));
        MEAT_CLEAVER = register("meat_cleaver", new PzWeaponItem(ToolMaterials.IRON, 6, -2.3f, 200, false, 0f, new Item.Settings()));
        KATANA = register("katana", new PzWeaponItem(ToolMaterials.IRON, 11, -2.4f, 400, false, 0f, new Item.Settings()));
        METAL_PIPE = register("metal_pipe", new PzWeaponItem(ToolMaterials.IRON, 6, -2.8f, 380, true, 0.22f, new Item.Settings()));
        PLANK_NAILS = register("plank_nails", new PzWeaponItem(ToolMaterials.WOOD, 7, -2.9f, 90, true, 0.2f, new Item.Settings()));
        WOOD_AXE = register("wood_axe", new PzAxeItem(ToolMaterials.IRON, 12f, -3.45f, 420, true, new Item.Settings()));
        SPEAR = register("spear", new PzWeaponItem(ToolMaterials.WOOD, 7, -2.6f, 110, false, 0f, 1.5f, new Item.Settings()));
        PITCHFORK = register("pitchfork", new PzWeaponItem(ToolMaterials.IRON, 6, -2.8f, 260, false, 0f, 1.2f, new Item.Settings()));
        COMBAT_KNIFE = register("combat_knife", new PzWeaponItem(ToolMaterials.IRON, 6, -1.8f, 450, false, 0f, new Item.Settings()));
        ROLLING_PIN = register("rolling_pin", new PzWeaponItem(ToolMaterials.WOOD, 4, -2.4f, 140, true, 0.15f, new Item.Settings()));
        TIRE_IRON = register("tire_iron", new PzWeaponItem(ToolMaterials.IRON, 5, -2.5f, 550, true, 0.18f, new Item.Settings()));
        com.example.zomboidmod.gun.Guns.register();
        com.example.zomboidmod.backpack.Backpacks.register();

        LootItems.register();
        com.example.zomboidmod.survival.Survival.register();
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK)
                .register(entries -> {
                    entries.add(CLEAN_WATER);
                    LootItems.all().forEach(entries::add);
                });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(RAG);
            entries.add(BANDAGE);
            entries.add(ANTISEPTIC);
            entries.add(SUTURE_KIT);
            entries.add(SPLINT);
            entries.add(PAINKILLERS);
            entries.add(ANTIBIOTICS);
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            for (Item w : new Item[]{BASEBALL_BAT, SPIKED_BAT, CROWBAR, FRYING_PAN, HAMMER,
                    KITCHEN_KNIFE, HUNTING_KNIFE, MACHETE, HAND_AXE, FIRE_AXE, SLEDGEHAMMER, SHOVEL, GOLF_CLUB, PIPE_WRENCH,
                    NIGHTSTICK, MEAT_CLEAVER, KATANA, METAL_PIPE, PLANK_NAILS, WOOD_AXE, SPEAR, PITCHFORK, COMBAT_KNIFE, ROLLING_PIN, TIRE_IRON}) entries.add(w);
        });

        PayloadTypeRegistry.playS2C().register(ThirstPayload.ID, ThirstPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(WoundsPayload.ID, WoundsPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(DrinkPayload.ID, DrinkPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(TreatPayload.ID, TreatPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SkillPayloads.Sync.ID, SkillPayloads.Sync.CODEC);
        PayloadTypeRegistry.playS2C().register(SkillPayloads.Prompt.ID, SkillPayloads.Prompt.CODEC);
        PayloadTypeRegistry.playC2S().register(SkillPayloads.Choose.ID, SkillPayloads.Choose.CODEC);

        // Профессия: выбор при первом входе и после смерти (новый персонаж, как в PZ)
        ServerPlayNetworking.registerGlobalReceiver(SkillPayloads.Choose.ID,
                (payload, context) -> Skills.choose(context.player(), payload.profession(), payload.traits()));
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.getPlayer();
            Skills.sync(p);
            Skills.prompt(p);
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> Skills.clear(handler.getPlayer().getUuid()));

        // Опыт за убийства
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (source.getAttacker() instanceof ServerPlayerEntity p && entity != p) {
                Skills.onKill(p, source.isIn(DamageTypeTags.IS_PROJECTILE));
            }
        });

        // Здоровье больше не восстанавливается само от сытости: только как в Project Zomboid
        ServerLifecycleEvents.SERVER_STARTED.register(server ->
                server.getGameRules().get(GameRules.NATURAL_REGENERATION).set(false, server));

        // Клиент просит попить из водоёма (Shift + ПКМ)
        ServerPlayNetworking.registerGlobalReceiver(DrinkPayload.ID,
                (payload, context) -> requestRiverDrink(context.player(), context.server().getTicks()));

        // Лечение из панели здоровья
        ServerPlayNetworking.registerGlobalReceiver(TreatPayload.ID,
                (payload, context) -> Wounds.treatFromMenu(context.player(), payload.part(), payload.action()));

        // Раны от урона
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayerEntity p && !p.isCreative() && !p.isSpectator()) {
                Wounds.onDamage(p, source, amount);
            }
            if (source.isIn(DamageTypeTags.IS_PROJECTILE) && source.getAttacker() instanceof ServerPlayerEntity shooter
                    && entity != shooter) {
                Skills.onProjectileHit(shooter);
            }
            return true;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (!p.isAlive() || p.isSpectator()) continue;
                Skills.tick(p, server.getTicks());
                if (p.isCreative()) continue;
                handleBottle(p);
            }
            if (server.getTicks() % 20 == 0) everySecond(server);
            com.example.zomboidmod.world.Knox.tick(server);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> com.example.zomboidmod.world.Knox.stop());

        // После смерти жажда и раны сбрасываются
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            UUID id = newPlayer.getUuid();
            ThirstState state = ThirstState.get(newPlayer.getServer());
            state.thirst.remove(id);
            state.markDirty();
            TIMER.remove(id);
            RIVER_PROGRESS.remove(id);
            RIVER_LAST.remove(id);
            BOTTLE_LEFT.remove(id);
            Wounds.reset(newPlayer);
            if (!alive) Skills.newCharacter(newPlayer);
        });

        // Все ванильные зомби заменяются на зомби из PZ (одежда, повадки, вещи в карманах)
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof PersistentProjectileEntity arrow) Skills.onArrowSpawn(arrow);
        });
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if ((entity.getType() == EntityType.ZOMBIE || entity.getType() == EntityType.HUSK || entity.getType() == EntityType.DROWNED
                    || entity.getType() == EntityType.ZOMBIE_VILLAGER) && entity instanceof ZombieEntity old) {
                world.getServer().execute(() -> {
                    if (old.isRemoved() || !old.isAlive()) return;
                    PzZombieEntity z = ZomboidEntities.PZ_ZOMBIE.create(world);
                    if (z == null) return;
                    z.refreshPositionAndAngles(old.getX(), old.getY(), old.getZ(), old.getYaw(), old.getPitch());
                    z.setBaby(old.isBaby());
                    world.spawnEntity(z);
                    old.discard();
                });
            }
        });

        // Шум привлекает зомби
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (player instanceof ServerPlayerEntity sp) {
                Noise.emitFrom(sp, 14);
                if (world instanceof ServerWorld sw) Skills.onBlockBreak(sp, sw, pos, state);
            }
        });
        // скрип двери слышат соседние зомби
        net.fabricmc.fabric.api.event.player.UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.isClient && player instanceof ServerPlayerEntity sp && !sp.isSneaking()
                    && world.getBlockState(hit.getBlockPos()).getBlock() instanceof net.minecraft.block.DoorBlock) Noise.emitFrom(sp, 10);
            return ActionResult.PASS;
        });
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClient && player instanceof ServerPlayerEntity sp) {
                Noise.emitFrom(sp, 18);
                Skills.onMeleeHit(sp, entity);
            }
            return ActionResult.PASS;
        });

        // Сон: пока игрок спал, проходят игровые часы - раны заживают, здоровье восстанавливается
        EntitySleepEvents.START_SLEEPING.register((entity, pos) -> {
            if (entity instanceof ServerPlayerEntity p) {
                SLEEP_START.put(p.getUuid(), p.getWorld().getTimeOfDay());
            }
        });
        EntitySleepEvents.STOP_SLEEPING.register((entity, pos) -> {
            if (entity instanceof ServerPlayerEntity p) {
                Long start = SLEEP_START.remove(p.getUuid());
                if (start != null) {
                    long delta = p.getWorld().getTimeOfDay() - start;
                    if (delta > 100) Wounds.advanceSleep(p, delta / 1000.0);
                }
            }
        });

        // Команды
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("wounds").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                String text = Wounds.describe(p);
                ctx.getSource().sendFeedback(() -> Text.literal(text), false);
                return 1;
            }));
            dispatcher.register(CommandManager.literal("skills").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                PlayerSkills d = Skills.of(p);
                StringBuilder sb = new StringBuilder("Профессия: " + Profession.byIndex(d.profession).title);
                for (PzSkill s : PzSkill.values()) {
                    sb.append("\n").append(s.title).append(": ").append(d.level[s.ordinal()]);
                }
                String text = sb.toString();
                ctx.getSource().sendFeedback(() -> Text.literal(text), false);
                return 1;
            }));
            dispatcher.register(CommandManager.literal("zomboid")
                    .requires(src -> src.hasPermissionLevel(2))
                    .then(CommandManager.literal("map").executes(ctx -> {
                        String text = com.example.zomboidmod.world.Knox.info(ctx.getSource().getPlayerOrThrow());
                        ctx.getSource().sendFeedback(() -> Text.literal(text), false);
                        return 1;
                    }))
                    .then(CommandManager.literal("profession").executes(ctx -> {
                        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                        Skills.of(p).chosen = false;
                        Skills.prompt(p);
                        return 1;
                    }))
                    .then(CommandManager.literal("skill")
                            .then(CommandManager.argument("name", StringArgumentType.word())
                                    .then(CommandManager.argument("level", IntegerArgumentType.integer(0, 10))
                                            .executes(ctx -> {
                                                String n = StringArgumentType.getString(ctx, "name").toUpperCase();
                                                PzSkill s;
                                                try {
                                                    s = PzSkill.valueOf(n);
                                                } catch (IllegalArgumentException e) {
                                                    ctx.getSource().sendFeedback(() -> Text.literal("Навыки: strength, fitness, sprinting, lightfooted, nimble, sneaking, axe, long_blunt, short_blunt, long_blade, short_blade, maintenance, cooking, farming, first_aid, aiming, fishing"), false);
                                                    return 0;
                                                }
                                                Skills.setLevel(ctx.getSource().getPlayerOrThrow(), s, IntegerArgumentType.getInteger(ctx, "level"));
                                                return 1;
                                            }))))
                    .then(CommandManager.literal("test").executes(ctx -> {
                        Wounds.testWounds(ctx.getSource().getPlayerOrThrow());
                        ctx.getSource().sendFeedback(() -> Text.literal("Тестовые раны добавлены"), false);
                        return 1;
                    }))
                    .then(CommandManager.literal("hour")
                            .then(CommandManager.argument("seconds", IntegerArgumentType.integer(1, 3600))
                                    .executes(ctx -> {
                                        Wounds.hourSeconds = IntegerArgumentType.getInteger(ctx, "seconds");
                                        ctx.getSource().sendFeedback(() -> Text.literal(
                                                "1 игровой час PZ = " + Wounds.hourSeconds + " сек"), false);
                                        return 1;
                                    })))
                    .then(CommandManager.literal("heal").executes(ctx -> {
                        Wounds.reset(ctx.getSource().getPlayerOrThrow());
                        ctx.getSource().sendFeedback(() -> Text.literal("Все раны и болезни сброшены"), false);
                        return 1;
                    })));
        });
    }

    // ===== Питьё обычной бутылки с водой =====
    private static void handleBottle(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        boolean usingWater = p.isUsingItem() && isWaterBottle(p.getActiveItem());
        Integer prev = BOTTLE_LEFT.get(id);
        if (usingWater) {
            BOTTLE_LEFT.put(id, p.getItemUseTimeLeft());
        } else if (prev != null) {
            BOTTLE_LEFT.remove(id);
            if (prev <= 1) {
                addThirst(p, BOTTLE_DRINK_AMOUNT);
                maybePoison(p, BOTTLE_POISON_CHANCE);
            }
        }
    }

    private static boolean isWaterBottle(ItemStack stack) {
        if (!stack.isOf(Items.POTION)) return false;
        PotionContentsComponent c = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (c == null) return false;
        return c.potion().flatMap(e -> e.getKey())
                .map(k -> k.getValue().equals(Identifier.of("minecraft", "water")))
                .orElse(false);
    }

    // ===== Питьё из водоёма: Shift + зажатая ПКМ с пустой рукой =====
    private static void requestRiverDrink(ServerPlayerEntity p, int tick) {
        UUID id = p.getUuid();
        if (!p.isAlive() || p.isCreative() || p.isSpectator() || !p.isSneaking()
                || !p.getMainHandStack().isEmpty() || getThirst(p) >= MAX_THIRST || !lookingAtWater(p)) {
            RIVER_PROGRESS.remove(id);
            return;
        }
        Integer last = RIVER_LAST.get(id);
        if (last == null || tick - last > 3) RIVER_PROGRESS.put(id, 0);
        RIVER_LAST.put(id, tick);

        int n = RIVER_PROGRESS.merge(id, 1, Integer::sum);
        if (n == 1) p.sendMessage(Text.literal("Пьёшь из водоёма..."), true);
        if (n >= RIVER_DRINK_TICKS) {
            RIVER_PROGRESS.put(id, 0);
            addThirst(p, RIVER_DRINK_AMOUNT);
            p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GENERIC_DRINK,
                    SoundCategory.PLAYERS, 0.8f, 1.0f);
            maybePoison(p, RIVER_POISON_CHANCE);
        }
    }

    private static boolean lookingAtWater(ServerPlayerEntity p) {
        HitResult hit = p.raycast(4.5, 1.0f, true);
        if (hit.getType() != HitResult.Type.BLOCK) return false;
        BlockPos bp = ((BlockHitResult) hit).getBlockPos();
        return p.getWorld().getFluidState(bp).isIn(FluidTags.WATER);
    }

    private static void maybePoison(ServerPlayerEntity p, float chance) {
        if (p.getRandom().nextFloat() < chance * Skills.poisonMult(p)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 160, 0));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 0));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 400, 0));
            p.sendMessage(Text.literal("Вода оказалась грязной, вы отравились!"), false);
        }
    }

    // ===== Раз в секунду: жажда, её дебафы и здоровье =====
    private static void everySecond(MinecraftServer server) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (!p.isAlive() || p.isCreative() || p.isSpectator()) continue;

            int run = p.isSprinting() ? (Skills.fitForRunning(p) ? 1 : 2) : 1;  // хорошая форма - меньше жажды
            int t = TIMER.merge(p.getUuid(), run, Integer::sum);
            if (t >= Math.round(SECONDS_PER_THIRST_POINT * Skills.thirstIntervalMult(p))) {
                TIMER.put(p.getUuid(), 0);
                setThirst(p, getThirst(p) - 1);
            }

            // Жажда (уровни мудла PZ: >13% сухость во рту, >25% жажда, >70% головокружение, >85% умирает от жажды)
            int thirstPct = MAX_THIRST - getThirst(p);
            int sec = server.getTicks() / 20;
            if (thirstPct > 70) effect(p, StatusEffects.SLOWNESS, 0);                 // слабость и головокружение
            if (thirstPct > 85) {
                effect(p, StatusEffects.WEAKNESS, 0);
                if (sec % 15 == 0) p.damage(p.getDamageSources().starve(), 1.0f);  // здоровье медленно падает
            }

            // Голод (уровни мудла PZ: 15% / 25% / 45% / 70%); при нуле Minecraft сам наносит урон
            int hungerPct = (20 - p.getHungerManager().getFoodLevel()) * 5;
            if (hungerPct >= 45) effect(p, StatusEffects.WEAKNESS, 0);
            if (hungerPct >= 70) effect(p, StatusEffects.MINING_FATIGUE, 0);

            sendThirst(p);
            Wounds.tickSecond(p, server.getTicks());
            // шаги: бег слышно далеко, обычный шаг — рядом, крадущийся почти беззвучен
            if (p.isSprinting()) Noise.emitSteps(p, 20);
            else if (p.getVelocity().horizontalLengthSquared() > 0.003 && !p.isSneaking()) Noise.emitSteps(p, 7);
            Skills.second(p);
            Weight.tick(p);
            Skills.traitSecond(p);
        }
        HealthState.get(server).markDirty();
    }

    private static void effect(ServerPlayerEntity p, RegistryEntry<StatusEffect> effect, int amplifier) {
        p.addStatusEffect(new StatusEffectInstance(effect, 60, amplifier, true, false, true));
    }
}
