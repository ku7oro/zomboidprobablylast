package com.example.zomboidmod;

import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** Зомби в духе Project Zomboid: одежда, повадки (шатун, бегун, ползун), шум, вещи в карманах. */
public class PzZombieEntity extends ZombieEntity {
    private static final TrackedData<Integer> VARIANT =
            DataTracker.registerData(PzZombieEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private BlockPos noisePos;
    private int noiseTicks;
    private boolean lootRolled;

    public PzZombieEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(VARIANT, -1);
    }

    // ----- вариант: одежда | тон << 8 | повадки << 16 -----
    public int rawVariant() {
        return this.getDataTracker().get(VARIANT);
    }

    public ZombieOutfit outfit() {
        int v = rawVariant();
        ZombieOutfit[] a = ZombieOutfit.values();
        return v < 0 ? a[0] : a[Math.min(v & 255, a.length - 1)];
    }

    public int tone() {
        int v = rawVariant();
        return v < 0 ? 0 : (v >> 8) & 255;
    }

    public ZombieKind kind() {
        int v = rawVariant();
        ZombieKind[] a = ZombieKind.values();
        return v < 0 ? a[0] : a[Math.min((v >> 16) & 255, a.length - 1)];
    }

    public boolean isCrawler() {
        return this.getDataTracker() != null && kind() == ZombieKind.CRAWLER;
    }

    private int tier;

    private void assign() {
        Random r = this.getRandom();
        ZombieKind kind = ZombieKind.forTier(r, tier);
        ZombieOutfit outfit = kind == ZombieKind.BRUTE ? ZombieOutfit.bruteOutfit(r) : ZombieOutfit.random(r);
        int tone = r.nextInt(3);
        this.getDataTracker().set(VARIANT, outfit.ordinal() | (tone << 8) | (kind.ordinal() << 16));
        applyStats();
    }

    /** Характеристики по повадкам, одежде и опасности места. */
    private void applyStats() {
        ZombieKind kind = kind();
        ZombieOutfit outfit = outfit();
        boolean brute = kind == ZombieKind.BRUTE;
        setAttr(EntityAttributes.GENERIC_MAX_HEALTH, (kind.health + outfit.bonusHealth) * (1.0 + 0.15 * tier));
        this.setHealth(this.getMaxHealth());
        setAttr(EntityAttributes.GENERIC_MOVEMENT_SPEED, kind.idleSpeed);
        setAttr(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);                       // видят и чуют далеко
        setAttr(EntityAttributes.GENERIC_ATTACK_DAMAGE, (brute ? 11.0 : 5.0) + tier); // кусают больно, громила — страшно
        setAttr(EntityAttributes.GENERIC_ARMOR, outfit.armor() + (brute ? 4 : 0));
        setAttr(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, brute ? 0.95 : 0.35);
        setAttr(EntityAttributes.GENERIC_SCALE, brute ? 1.3 : 1.0);
        if (kind == ZombieKind.CRAWLER) this.calculateDimensions();
    }

    public boolean isBrute() {
        return kind() == ZombieKind.BRUTE;
    }

    /** Настроить зомби при спавне в здании: одежда по месту (полицейский в участке и т.п.), остальное случайно. */
    public void setup(ZombieOutfit outfit) {
        setup(outfit, 0);
    }

    /** То же с учётом опасности места: возле хорошего лута зомби сильнее. */
    public void setup(ZombieOutfit outfit, int tier) {
        this.tier = Math.max(0, Math.min(3, tier));
        assign();
        this.setCanBreakDoors(true);
        if (outfit == null || isBrute()) return;
        int v = rawVariant();
        this.getDataTracker().set(VARIANT, (v & ~255) | outfit.ordinal());
        applyStats();
    }

    // громила рычит ниже
    public float getSoundPitch() {
        return isBrute() ? 0.55f + this.getRandom().nextFloat() * 0.1f : 0.9f + this.getRandom().nextFloat() * 0.2f;
    }

    private void setAttr(RegistryEntry<EntityAttribute> attr, double value) {
        EntityAttributeInstance inst = this.getAttributeInstance(attr);
        if (inst != null) inst.setBaseValue(value);
    }

    /** Зомби услышал шум в этой точке. */
    public void hear(BlockPos pos) {
        hear(pos, null);
    }

    /** Шум от игрока: если тот близко и на виду — сразу бросается на него. */
    public void hear(BlockPos pos, net.minecraft.entity.player.PlayerEntity source) {
        this.noisePos = pos.toImmutable();
        this.noiseTicks = 300;
        if (source != null && this.getTarget() == null && !source.isCreative() && !source.isSpectator()
                && this.squaredDistanceTo(source) < 14 * 14 && this.canSee(source)) {
            this.setTarget(source);
        }
    }

    @Override
    public boolean tryAttack(net.minecraft.entity.Entity target) {
        boolean ok = super.tryAttack(target);
        if (ok && target instanceof net.minecraft.entity.LivingEntity le) {   // хватает и держит
            le.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 25, kind() == ZombieKind.CRAWLER ? 3 : 1, false, false));
            if (isBrute()) {   // громила отшвыривает
                double rad = Math.toRadians(this.getYaw());
                le.takeKnockback(1.3, Math.sin(rad), -Math.cos(rad));
                le.velocityModified = true;
                this.playSound(net.minecraft.sound.SoundEvents.ENTITY_RAVAGER_ATTACK, 1.0f, 0.8f);
            }
        }
        return ok;
    }

    // ===== выбивание дверей и окон, как в PZ =====
    private static final java.util.Map<Long, Integer> THUMPS = new java.util.HashMap<>();
    private net.minecraft.entity.LivingEntity lastTarget;

    private static int thumpLimit(net.minecraft.block.BlockState st) {
        net.minecraft.block.Block b = st.getBlock();
        if (st.isOf(net.minecraft.block.Blocks.IRON_BARS)) return -1;   // решётки зомби не выбить
        if (b instanceof net.minecraft.block.PaneBlock || b instanceof net.minecraft.block.TransparentBlock) return 3;
        if (b instanceof net.minecraft.block.DoorBlock) return st.isOf(net.minecraft.block.Blocks.IRON_DOOR) ? 40 : 14;
        if (b instanceof net.minecraft.block.TrapdoorBlock) return 9;
        if (b instanceof net.minecraft.block.FenceGateBlock || b instanceof net.minecraft.block.FenceBlock) return 12;
        return -1;
    }

    private void thump() {
        double rad = Math.toRadians(this.getYaw());
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        for (int dy = 0; dy <= 1; dy++) {
            BlockPos pos = BlockPos.ofFloored(this.getX() + fx * 0.9, this.getY() + 0.5 + dy, this.getZ() + fz * 0.9);
            if (bash(pos)) return;
        }
    }

    /** Удар по двери/окну в этой клетке. false — бить тут нечего. */
    public boolean bash(BlockPos pos) {
        if (pos == null) return false;
        net.minecraft.block.BlockState st = this.getWorld().getBlockState(pos);
        int limit = thumpLimit(st);
        if (limit < 0) return false;
        if (st.getBlock() instanceof net.minecraft.block.DoorBlock && st.get(net.minecraft.block.DoorBlock.OPEN)) return false;
        long key = pos.asLong();
        int n = THUMPS.merge(key, isBrute() ? 4 : 1, Integer::sum);   // громила выносит двери в разы быстрее
        this.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        boolean glass = limit <= 3;
        this.getWorld().playSound(null, pos, glass ? net.minecraft.sound.SoundEvents.BLOCK_GLASS_HIT
                        : net.minecraft.sound.SoundEvents.ENTITY_ZOMBIE_ATTACK_WOODEN_DOOR, net.minecraft.sound.SoundCategory.HOSTILE, 1.0f,
                0.8f + this.getRandom().nextFloat() * 0.3f);
        this.getWorld().setBlockBreakingInfo(this.getId(), pos, Math.min(9, n * 10 / limit));
        if (this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) Noise.emitAt(sw, pos, 14);
        if (n >= limit) {
            THUMPS.remove(key);
            this.getWorld().setBlockBreakingInfo(this.getId(), pos, -1);
            this.getWorld().syncWorldEvent(glass ? 2001 : net.minecraft.world.WorldEvents.ZOMBIE_BREAKS_WOODEN_DOOR, pos,
                    glass ? net.minecraft.block.Block.getRawIdFromState(st) : 0);
            this.getWorld().breakBlock(pos, false);
            com.example.zomboidmod.parkour.Parkour.shatter(this.getWorld(), pos, st);   // в раме остаются осколки
        }
        return true;
    }

    // ===== паркур: лезет в окно / через забор =====
    public com.example.zomboidmod.parkour.Parkour.Active climb;
    public BlockPos winGoal;
    public net.minecraft.util.math.Direction winDir;
    public int winUntil;
    public net.minecraft.util.math.Vec3d pushTo;
    public int pushUntil;

    @Override
    public void tick() {
        super.tick();

        if (!this.getWorld().isClient && climb != null) {   // лезет по маршруту — ни ИИ, ни физики
            com.example.zomboidmod.parkour.Parkour.tickZombie(this);
            return;
        }

        if (!this.getWorld().isClient) {
            if (rawVariant() < 0) {
                assign();
                this.setCanBreakDoors(true);
            }
            ZombieKind kind = kind();

            // в тумане видят хуже (как в PZ)
            if (this.age % 40 == 0) setAttr(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0 - 24.0 * com.example.zomboidmod.survival.WorldEvents.fog);
            // в погоне ускоряются; бегун несётся и иногда спотыкается
            if (this.age % 10 == 0) {
                boolean chasing = this.getTarget() != null;
                setAttr(EntityAttributes.GENERIC_MOVEMENT_SPEED, chasing ? kind.chaseSpeed : kind.idleSpeed);
                if (kind == ZombieKind.SPRINTER && chasing && this.getRandom().nextInt(80) == 0) {
                    this.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 6, false, false));
                }
            }

            // заметив жертву, зовёт остальных (стон слышат в радиусе 18 блоков)
            net.minecraft.entity.LivingEntity tgt = this.getTarget();
            if (tgt != null && tgt != lastTarget && this.getWorld() instanceof net.minecraft.server.world.ServerWorld sw) {
                this.playSound(net.minecraft.sound.SoundEvents.ENTITY_ZOMBIE_AMBIENT, 1.5f, 0.7f);
                for (PzZombieEntity o : sw.getEntitiesByClass(PzZombieEntity.class, this.getBoundingBox().expand(18), e -> e != this && e.isAlive())) {
                    o.noisePos = tgt.getBlockPos();
                    o.noiseTicks = 300;
                    if (o.getTarget() == null && o.squaredDistanceTo(tgt) < 24 * 24 && o.canSee(tgt)) o.setTarget(tgt);
                }
            }
            lastTarget = tgt;

            // упёрся в дверь или окно — колотит, пока не выбьет
            if ((tgt != null || noiseTicks > 0) && this.age % 20 == (this.getId() & 15) && this.horizontalCollision) thump();
            // заборы и окна: переваливается, бьёт стёкла, ищет окно, если к жертве иначе не пройти
            if ((tgt != null || noiseTicks > 0) && this.age % 5 == (this.getId() & 0x7fffffff) % 5)
                com.example.zomboidmod.parkour.Parkour.zombieThink(this, tgt, tgt == null ? noisePos : null);
            if (winGoal != null || pushTo != null) com.example.zomboidmod.parkour.Parkour.steer(this);

            // скрытность: крадущегося игрока замечают только вблизи
            if (this.age % 10 == 0 && this.getTarget() instanceof net.minecraft.server.network.ServerPlayerEntity sp
                    && sp.isSneaking() && this.getAttacker() != sp
                    && this.squaredDistanceTo(sp) > Math.pow(Skills.sneakDetectRange(sp), 2)) {
                this.setTarget(null);
            }
            if (this.age % 10 == 5 && this.getTarget() instanceof net.minecraft.server.network.ServerPlayerEntity sp2
                    && this.getAttacker() != sp2
                    && this.squaredDistanceTo(sp2) > Math.pow(Skills.inconspicuousRange(sp2), 2)) {
                this.setTarget(null);
            }

            // идёт на шум, если жертвы не видно
            if (noiseTicks > 0) {
                noiseTicks--;
                if (this.getTarget() == null && noisePos != null && this.age % 20 == 0) {
                    double nx = noisePos.getX() + 0.5, ny = noisePos.getY(), nz = noisePos.getZ() + 0.5;
                    if (this.squaredDistanceTo(nx, ny, nz) > 4.0) {
                        this.getNavigation().startMovingTo(nx, ny, nz, 1.0);
                    } else {
                        noiseTicks = 0;
                    }
                }
            }
        }

        // ползун ползёт по земле
        if (isCrawler()) this.setPose(EntityPose.SWIMMING);
    }

    @Override
    public EntityDimensions getBaseDimensions(EntityPose pose) {
        if (this.getDataTracker() != null && isCrawler()) return EntityDimensions.changing(0.7f, 0.6f);
        return super.getBaseDimensions(pose);
    }

    // Зомби не горят на солнце (как в PZ). Без @Override: сработает, если такие методы есть у родителя.
    public boolean isAffectedByDaylight() {
        return false;
    }

    public boolean burnsInDaylight() {
        return false;
    }

    public boolean shouldBurnInDay() {
        return false;
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        if (!this.getWorld().isClient && !lootRolled) {
            lootRolled = true;
            ZombieLoot.drop(this, outfit(), this.getRandom());
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("PzVariant", rawVariant());
        nbt.putBoolean("PzLootRolled", lootRolled);
        nbt.putInt("PzTier", tier);
        if (climb != null) {   // сохранение посреди перелезания: не оставить зомби замороженным
            nbt.putBoolean("NoAI", false);
            nbt.remove("NoGravity");
        }
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("PzVariant")) this.getDataTracker().set(VARIANT, nbt.getInt("PzVariant"));
        lootRolled = nbt.getBoolean("PzLootRolled");
        tier = nbt.getInt("PzTier");
        if (isCrawler()) this.calculateDimensions();
    }
}
