#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
attribute vec4 mc_Entity;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying vec3 viewPos;
varying float isWater;
void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = normLightmap((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy);
    color = gl_Color;
    normal = normalize(gl_NormalMatrix * gl_Normal);
    isWater = mc_Entity.x == 10001.0 ? 1.0 : 0.0;
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    viewPos = vp.xyz;
    gl_Position = gl_ProjectionMatrix * vp;
}
