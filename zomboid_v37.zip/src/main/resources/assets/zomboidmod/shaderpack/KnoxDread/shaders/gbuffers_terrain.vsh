#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec2 mc_midTexCoord;
uniform mat4 gbufferModelView;
uniform float frameTimeCounter;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying vec3 tangent;
varying vec3 binormal;
varying vec3 viewPos;
varying float hasTangent;
void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = normLightmap((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy);
    color = gl_Color;
    normal = normalize(gl_NormalMatrix * gl_Normal);
    hasTangent = length(at_tangent.xyz) > 0.1 ? 1.0 : 0.0;
    tangent = hasTangent > 0.5 ? normalize(gl_NormalMatrix * at_tangent.xyz) : vec3(1.0, 0.0, 0.0);
    binormal = hasTangent > 0.5 ? normalize(gl_NormalMatrix * cross(at_tangent.xyz, gl_Normal) * at_tangent.w) : vec3(0.0, 1.0, 0.0);
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    viewPos = vp.xyz;
    float id = mc_Entity.x;
#ifdef WAVING_PLANTS
    if ((id == 10002.0 || id == 10003.0) && lmcoord.y > 0.3) {
        vec4 pp = gbufferModelViewInverse * vp;
        vec3 wp = pp.xyz + cameraPosition;
        float strength = (0.35 + 0.65 * rainStrength) * lmcoord.y;
        float t = frameTimeCounter;
        vec3 off = vec3(sin(t * 1.7 + wp.x * 0.5 + wp.z * 0.3), sin(t * 2.3 + wp.x * 0.4) * 0.3, cos(t * 1.4 + wp.z * 0.6)) * 0.035 * strength;
        if (id == 10003.0) {
            bool top = gl_MultiTexCoord0.t < mc_midTexCoord.t;
            off = top ? off * 3.0 : vec3(0.0);
        }
        pp.xyz += off;
        vp = gbufferModelView * pp;
    }
#endif
    gl_Position = gl_ProjectionMatrix * vp;
}
