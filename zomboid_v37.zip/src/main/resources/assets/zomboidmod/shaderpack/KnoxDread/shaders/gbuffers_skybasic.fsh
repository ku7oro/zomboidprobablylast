#version 120
/* DRAWBUFFERS:0 */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
varying vec4 color;
varying vec3 viewPos;
varying float star;
void main() {
    float day = dayFactor();
    if (star > 0.5) {
        gl_FragData[0] = vec4(color.rgb * 0.5 * (1.0 - rainStrength) * (1.0 - day), color.a);
        return;
    }
    vec3 dir = normalize(viewPos);
    float up = dot(dir, normalize(upPosition));
    vec3 zenith = mix(vec3(0.006, 0.008, 0.012), vec3(0.23, 0.255, 0.28), day);
    zenith = mix(zenith, vec3(0.19, 0.20, 0.21) * day + 0.004, rainStrength);
    vec3 horizon = fogTint(day);
    float sunDot = max(dot(dir, normalize(sunPosition)), 0.0);
    float glow = pow(sunDot, 6.0) * (1.0 - smoothstep(0.0, 0.35, abs(sunHeight()))) * (1.0 - rainStrength);
    vec3 c = mix(horizon, zenith, smoothstep(-0.05, 0.45, up)) + vec3(0.42, 0.18, 0.07) * glow * 0.6;
    gl_FragData[0] = vec4(c, 1.0);
}
