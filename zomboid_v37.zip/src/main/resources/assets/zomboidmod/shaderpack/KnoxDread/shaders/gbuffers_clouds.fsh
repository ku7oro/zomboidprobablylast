#version 120
/* DRAWBUFFERS:0 */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
uniform sampler2D texture;
varying vec2 texcoord;
varying vec4 color;
varying vec3 viewPos;
void main() {
    vec4 c = texture2D(texture, texcoord) * color;
    if (c.a < 0.05) discard;
    float day = dayFactor();
    float l = dot(c.rgb, vec3(0.3, 0.59, 0.11));
    c.rgb = vec3(l) * mix(0.03, 0.5, day) * (1.0 - rainStrength * 0.35);
    c.rgb = mix(c.rgb, fogTint(day), 0.35);
    gl_FragData[0] = vec4(c.rgb, c.a * 0.85);
}
