#version 120
/* DRAWBUFFERS:0 */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;
uniform sampler2D normals;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying vec3 tangent;
varying vec3 binormal;
varying vec3 viewPos;
varying float hasTangent;
void main() {
    vec4 albedo = texture2D(texture, texcoord) * color;
    if (albedo.a < 0.1) discard;
    vec3 n = normal;
    float ao = 1.0;
    if (hasTangent > 0.5) {
        vec4 nm = texture2D(normals, texcoord);
        vec3 tn = vec3(nm.xy * 2.0 - 1.0, 0.0);
        tn.z = sqrt(max(1.0 - dot(tn.xy, tn.xy), 0.0));
        n = normalize(mat3(tangent, binormal, normal) * tn);
        ao = mix(1.0, nm.b, 0.6);
    }
    vec3 c = lighting(albedo.rgb * ao, lmcoord, n, viewPos, true);
    gl_FragData[0] = vec4(applyFog(c, viewPos), albedo.a);
}
