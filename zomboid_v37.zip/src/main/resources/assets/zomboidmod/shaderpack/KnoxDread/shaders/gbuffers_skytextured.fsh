#version 120
/* DRAWBUFFERS:0 */
uniform sampler2D texture;
uniform float rainStrength;
varying vec2 texcoord;
varying vec4 color;
void main() {
    vec4 c = texture2D(texture, texcoord) * color;
    c.rgb *= 0.7 * (1.0 - rainStrength * 0.9);
    gl_FragData[0] = c;
}
