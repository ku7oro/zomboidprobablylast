#version 120
#include "/lib/settings.glsl"
attribute vec4 mc_Entity;
varying vec2 texcoord;
varying vec4 color;
void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    color = gl_Color;
    gl_Position = ftransform();
    float d = length(gl_Position.xy);
    gl_Position.xy /= d * 0.9 + 0.1;
    gl_Position.z *= 0.2;
    if (mc_Entity.x == 10001.0) gl_Position = vec4(10.0, 10.0, 10.0, 1.0);
}
