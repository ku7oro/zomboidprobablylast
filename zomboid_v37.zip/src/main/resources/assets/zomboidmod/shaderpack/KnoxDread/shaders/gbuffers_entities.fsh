#version 120
/* DRAWBUFFERS:0 */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;
uniform vec4 entityColor;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying vec3 viewPos;
void main() {
    vec4 albedo = texture2D(texture, texcoord) * color;
    if (albedo.a < 0.1) discard;
    albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);
    vec3 c = lighting(albedo.rgb, lmcoord, normalize(normal), viewPos, true);
    gl_FragData[0] = vec4(applyFog(c, viewPos), albedo.a * 1.0);
}
