#version 120
/* DRAWBUFFERS:0 */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
uniform sampler2D texture;
varying vec2 texcoord;
varying vec4 color;
void main() {
    vec4 c = texture2D(texture, texcoord) * color;
    c.rgb *= mix(0.08, 0.55, dayFactor());
    gl_FragData[0] = vec4(c.rgb, c.a * 0.45);
}
