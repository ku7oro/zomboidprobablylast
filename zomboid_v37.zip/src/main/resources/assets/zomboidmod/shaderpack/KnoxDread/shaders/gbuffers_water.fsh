#version 120
/* DRAWBUFFERS:0 */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying vec3 viewPos;
varying float isWater;
void main() {
    vec4 albedo = texture2D(texture, texcoord) * color;
    vec3 n = normalize(normal);
    if (isWater > 0.5) {
        float l = dot(albedo.rgb, vec3(0.3, 0.59, 0.11));
        albedo.rgb = vec3(0.10, 0.13, 0.11) * (0.7 + 0.6 * l);
        float fres = pow(1.0 - abs(dot(normalize(-viewPos), n)), 3.0);
        vec3 c = lighting(albedo.rgb, lmcoord, n, viewPos, true);
        c = mix(c, fogTint(dayFactor()) * lmcoord.y, fres * 0.7);
        gl_FragData[0] = vec4(applyFog(c, viewPos), 0.86);
        return;
    }
    if (albedo.a < 0.02) discard;
    vec3 c = lighting(albedo.rgb, lmcoord, n, viewPos, true);
    gl_FragData[0] = vec4(applyFog(c, viewPos), albedo.a);
}
