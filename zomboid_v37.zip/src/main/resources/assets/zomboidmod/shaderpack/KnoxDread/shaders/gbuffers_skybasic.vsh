#version 120
varying vec4 color;
varying vec3 viewPos;
varying float star;
#ifdef MC_RENDER_STAGE_STARS
uniform int renderStage;
#endif
void main() {
    color = gl_Color;
#ifdef MC_RENDER_STAGE_STARS
    star = renderStage == MC_RENDER_STAGE_STARS ? 1.0 : 0.0;
#else
    star = (gl_Color.r == gl_Color.g && gl_Color.g == gl_Color.b && gl_Color.r > 0.0) ? 1.0 : 0.0;
#endif
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    viewPos = vp.xyz;
    gl_Position = gl_ProjectionMatrix * vp;
}
