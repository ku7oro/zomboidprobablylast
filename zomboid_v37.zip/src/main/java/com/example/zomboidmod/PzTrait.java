package com.example.zomboidmod;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

/**
 * Черты характера как в Project Zomboid. cost > 0 - положительная черта (тратит очки),
 * cost < 0 - отрицательная (даёт очки). Порядок не менять: номер хранится в сохранениях.
 */
public enum PzTrait {
    ATHLETIC("Атлет", 10, "Форма +4: бегает быстро и долго", "FITNESS", 4),
    STRONG("Силач", 10, "Сила +4: бьёт заметно сильнее", "STRENGTH", 4),
    THICK_SKINNED("Толстокожий", 8, "Зомби реже рвут кожу"),
    HUNTER("Охотник", 8, "Меткость, короткий клинок и скрытность +1", "AIMING", 1, "SHORT_BLADE", 1, "SNEAKING", 1),
    BRAWLER("Драчун", 6, "Топор и длинное дробящее +1", "AXE", 1, "LONG_BLUNT", 1),
    FAST_HEALER("Быстро заживает", 6, "Раны и переломы проходят быстрее"),
    FAST_LEARNER("Быстро учится", 6, "Опыт +30%"),
    FIT("В хорошей форме", 6, "Форма +2", "FITNESS", 2),
    FORMER_SCOUT("Бывший скаут", 6, "Первая помощь и рыбалка +1", "FIRST_AID", 1, "FISHING", 1),
    STOUT("Крепыш", 6, "Сила +2", "STRENGTH", 2),
    GYMNAST("Гимнаст", 5, "Лёгкая походка и проворство +1", "LIGHTFOOTED", 1, "NIMBLE", 1),
    TARGET_SHOOTER("Стрелок", 5, "Меткость +1", "AIMING", 1),
    ANGLER("Рыбак", 4, "Рыбалка +1", "FISHING", 1),
    BASEBALL_PLAYER("Бейсболист", 4, "Длинное дробящее +1", "LONG_BLUNT", 1),
    GRACEFUL("Грациозный", 4, "Шаги тише на 20%"),
    INCONSPICUOUS("Незаметный", 4, "Зомби замечают позже"),
    RESILIENT("Стойкий", 4, "Заражение убивает медленнее"),
    RUNNER("Бегун", 4, "Бег +1", "SPRINTING", 1),
    TINKERER("Мастеровой", 4, "Уход за оружием +1", "MAINTENANCE", 1),
    KEEN_COOK("Любит готовить", 3, "Кулинария +2", "COOKING", 2),
    FIRST_AIDER("Санитар", 2, "Первая помощь +1", "FIRST_AID", 1),
    GARDENER("Садовод", 2, "Фермерство +1", "FARMING", 1),
    IRON_GUT("Железный желудок", 2, "Реже травится грязной водой"),
    LIGHT_EATER("Мало ест", 2, "Голод растёт медленнее"),
    LOW_THIRST("Мало пьёт", 2, "Жажда растёт медленнее"),

    PUNY("Хилый", -10, "Сила -5: удары очень слабые", "STRENGTH", -5),
    UNFIT("Неспортивный", -10, "Форма -4: быстро выдыхается", "FITNESS", -4),
    THIN_SKINNED("Тонкокожий", -8, "Зомби чаще рвут кожу"),
    OUT_OF_SHAPE("Не в форме", -6, "Форма -2", "FITNESS", -2),
    SLOW_LEARNER("Медленно учится", -6, "Опыт -30%"),
    WEAK("Слабак", -6, "Сила -2", "STRENGTH", -2),
    FEAR_OF_BLOOD("Боится крови", -5, "Мутит, когда лечит себя; опыт первой помощи вдвое меньше"),
    RELUCTANT_FIGHTER("Неохотный боец", -5, "Опыт в бою -25%"),
    CONSPICUOUS("Заметный", -4, "Зомби тянутся к нему издалека"),
    HEARTY_APPETITE("Обжора", -4, "Голод растёт быстрее"),
    PRONE_TO_ILLNESS("Болезненный", -4, "Заражение убивает быстрее"),
    SLOW_HEALER("Медленно заживает", -3, "Раны и переломы проходят дольше"),
    CLUMSY("Неуклюжий", -2, "Шаги громче на 25%"),
    HIGH_THIRST("Много пьёт", -2, "Жажда растёт быстрее"),
    WEAK_STOMACH("Слабый желудок", -2, "Чаще травится грязной водой"),
    HANDY("Рукастый", 8, "Плотницкое дело и уход +1: строит быстрее, стены и баррикады крепче", "CARPENTRY", 1, "MAINTENANCE", 1);

    public final String title;
    public final int cost;
    public final String description;
    public final Map<PzSkill, Integer> skills = new EnumMap<>(PzSkill.class);

    PzTrait(String title, int cost, String description, Object... pairs) {
        this.title = title;
        this.cost = cost;
        this.description = description;
        for (int i = 0; i + 1 < pairs.length; i += 2) skills.put(PzSkill.valueOf((String) pairs[i]), (Integer) pairs[i + 1]);
    }

    public boolean positive() {
        return cost > 0;
    }

    /** Несовместимые черты (как в PZ). */
    public Set<PzTrait> exclusive() {
        return switch (this) {
            case ATHLETIC -> EnumSet.of(FIT, OUT_OF_SHAPE, UNFIT);
            case FIT -> EnumSet.of(ATHLETIC, OUT_OF_SHAPE, UNFIT);
            case OUT_OF_SHAPE -> EnumSet.of(ATHLETIC, FIT, UNFIT);
            case UNFIT -> EnumSet.of(ATHLETIC, FIT, OUT_OF_SHAPE);
            case STRONG -> EnumSet.of(STOUT, WEAK, PUNY);
            case STOUT -> EnumSet.of(STRONG, WEAK, PUNY);
            case WEAK -> EnumSet.of(STRONG, STOUT, PUNY);
            case PUNY -> EnumSet.of(STRONG, STOUT, WEAK);
            case THICK_SKINNED -> EnumSet.of(THIN_SKINNED);
            case THIN_SKINNED -> EnumSet.of(THICK_SKINNED);
            case FAST_HEALER -> EnumSet.of(SLOW_HEALER);
            case SLOW_HEALER -> EnumSet.of(FAST_HEALER);
            case FAST_LEARNER -> EnumSet.of(SLOW_LEARNER);
            case SLOW_LEARNER -> EnumSet.of(FAST_LEARNER);
            case GRACEFUL -> EnumSet.of(CLUMSY);
            case CLUMSY -> EnumSet.of(GRACEFUL);
            case INCONSPICUOUS -> EnumSet.of(CONSPICUOUS);
            case CONSPICUOUS -> EnumSet.of(INCONSPICUOUS);
            case RESILIENT -> EnumSet.of(PRONE_TO_ILLNESS);
            case PRONE_TO_ILLNESS -> EnumSet.of(RESILIENT);
            case IRON_GUT -> EnumSet.of(WEAK_STOMACH);
            case WEAK_STOMACH -> EnumSet.of(IRON_GUT);
            case LIGHT_EATER -> EnumSet.of(HEARTY_APPETITE);
            case HEARTY_APPETITE -> EnumSet.of(LIGHT_EATER);
            case LOW_THIRST -> EnumSet.of(HIGH_THIRST);
            case HIGH_THIRST -> EnumSet.of(LOW_THIRST);
            default -> EnumSet.noneOf(PzTrait.class);
        };
    }

    public long bit() {
        return 1L << ordinal();
    }

    public static boolean has(long mask, PzTrait t) {
        return (mask & t.bit()) != 0;
    }

    /** Остаток очков: очки профессии + отрицательные черты - положительные. Должен быть >= 0. */
    public static int balance(Profession prof, long mask) {
        int pts = prof.points;
        for (PzTrait t : values()) if (has(mask, t)) pts -= t.cost;
        return pts;
    }

    public static boolean valid(Profession prof, long mask) {
        if (balance(prof, mask) < 0) return false;
        for (PzTrait t : values()) {
            if (!has(mask, t)) continue;
            for (PzTrait x : t.exclusive()) if (has(mask, x)) return false;
        }
        return true;
    }
}
