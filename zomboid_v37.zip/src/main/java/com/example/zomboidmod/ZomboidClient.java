package com.example.zomboidmod;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

/** Интерфейс как в PZ: значки состояния (мудлы) справа, сердце и куколка с ранами слева, панель здоровья на H. */
public class ZomboidClient implements ClientModInitializer {

    public static KeyBinding healthKey;
    public static KeyBinding reloadKey;

    private static int thirst = 100;
    private static int[] codes = new int[BodyPart.values().length];
    private static boolean virus = false;
    private static boolean painkiller = false;
    private static int capPercent = 100;
    private static int pain = 0;
    private static int bleedLevel = 0;
    private static int sickLevel = 0;
    private static float lastHp = -1;

    // навыки (с сервера)
    private static int profession = 0;
    private static boolean professionChosen = true;
    private static boolean promptPending = false;
    private static final int NS = PzSkill.values().length;
    private static int[] skillLevel = new int[NS];
    private static int[] skillProgress = new int[NS];   // 0..1000
    private static int[] skillBoost = new int[NS];
    private static long traits = 0L;

    public static long traits() {
        return traits;
    }

    public static int profession() {
        return profession;
    }

    public static int skillLevel(PzSkill s) {
        return skillLevel[s.ordinal()];
    }

    public static int skillProgress(PzSkill s) {
        return skillProgress[s.ordinal()];
    }

    public static int skillBoost(PzSkill s) {
        return skillBoost[s.ordinal()];
    }

    public static void professionChosenLocally() {
        professionChosen = true;
        promptPending = false;
    }

    private static void parseSkills(String data) {
        try {
            String[] parts = data.split(";");
            int prof = Integer.parseInt(parts[0].trim());
            boolean ch = parts[1].trim().equals("1");
            String[] items = parts.length > 2 ? parts[2].split(",") : new String[0];
            int[] lv = new int[NS], pr = new int[NS], bo = new int[NS];
            for (int i = 0; i < NS && i < items.length; i++) {
                String[] f = items[i].split(":");
                lv[i] = Integer.parseInt(f[0]);
                pr[i] = Integer.parseInt(f[1]);
                bo[i] = Integer.parseInt(f[2]);
            }
            profession = prof;
            professionChosen = ch;
            skillLevel = lv;
            skillProgress = pr;
            skillBoost = bo;
            traits = parts.length > 3 ? Long.parseLong(parts[3].trim()) : 0L;
        } catch (Exception ignored) {
        }
    }
    private static int hurtFlash = 0;

    public static int[] codes() {
        return codes;
    }

    public static boolean virus() {
        return virus;
    }

    public static boolean painkiller() {
        return painkiller;
    }

    public static int capPercent() {
        return capPercent;
    }

    public static int pain() {
        return pain;
    }

    public static int thirst() {
        return thirst;
    }

    public static int sickLevel() {
        return sickLevel;
    }

    public static int bleedLevel() {
        return bleedLevel;
    }

    @Override
    public void onInitializeClient() {
        healthKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zomboidmod.health", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "category.zomboidmod"));
        reloadKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zomboidmod.reload", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.zomboidmod"));

        ClientPlayNetworking.registerGlobalReceiver(ThirstPayload.ID,
                (payload, context) -> thirst = payload.thirst());
        ClientPlayNetworking.registerGlobalReceiver(WoundsPayload.ID,
                (payload, context) -> parseWounds(payload.data()));
        EntityRendererRegistry.register(ZomboidEntities.PZ_ZOMBIE, PzZombieRenderer::new);
        EntityRendererRegistry.register(com.example.zomboidmod.wildlife.Wildlife.DEER, com.example.zomboidmod.wildlife.DeerRenderer::new);
        net.minecraft.client.render.block.entity.BlockEntityRendererFactories.register(
                com.example.zomboidmod.block.ZomboidBlocks.LOOT_PILE_BE, com.example.zomboidmod.block.LootPileRenderer::new);
        ClientPlayNetworking.registerGlobalReceiver(SkillPayloads.Sync.ID,
                (payload, context) -> parseSkills(payload.data()));
        ClientPlayNetworking.registerGlobalReceiver(SkillPayloads.Prompt.ID,
                (payload, context) -> promptPending = true);
        com.example.zomboidmod.vehicle.VehicleClient.init();
        com.example.zomboidmod.backpack.BackpackClient.init();
        com.example.zomboidmod.survival.SurvivalClient.init();
        com.example.zomboidmod.atmosphere.Atmosphere.init();
        com.example.zomboidmod.gun.GunClient.init();
        com.example.zomboidmod.parkour.ParkourClient.init();
        // плотницкое дело: клиент считает скорость ломания так же, как сервер
        com.example.zomboidmod.clothing.ClothingClient.init();
        com.example.zomboidmod.build.Carpentry.CLIENT_LEVEL = ZomboidClient::skillLevel;
        com.example.zomboidmod.build.Carpentry.CLIENT_TRAITS = ZomboidClient::traits;
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.JOIN.register(
                (h, sender, client) -> com.example.zomboidmod.build.Carpentry.clearCache());
        net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback.EVENT.register((stack, tctx, ttype, lines) -> {
            net.minecraft.item.Item it = stack.getItem();
            String[] tip = null;
            if (it == ZomboidMod.HAMMER) tip = new String[]{"Нужен в инвентаре, чтобы строить", "ПКМ по окну (по двери - Shift+ПКМ): прибить доску", "На доску: 1 доска + 2 гвоздя, до 4 досок",
                    "Разбирает деревянное на доски"};
            else if (it == ZomboidMod.SLEDGEHAMMER) tip = new String[]{"Единственное, чем можно снести стену", "из кирпича, бетона или металла. Очень громко"};
            else if (it == ZomboidMod.CROWBAR || it == ZomboidMod.TIRE_IRON) tip = new String[]{"Отрывает доски баррикад, разбирает деревянное"};
            else if (it == ZomboidMod.HAND_AXE || it == ZomboidMod.FIRE_AXE || it == ZomboidMod.WOOD_AXE) tip = new String[]{"Рубит деревья и деревянные постройки"};
            else if (it == ZomboidMod.SHOVEL) tip = new String[]{"Копает землю, песок и гравий"};
            if (tip != null) for (String t : tip) lines.add(net.minecraft.text.Text.literal(t).formatted(net.minecraft.util.Formatting.DARK_GRAY));
        });
        // свои реалистичные текстуры 64x — включены по умолчанию, отключаются в «Пакетах ресурсов»
        net.fabricmc.fabric.api.resource.ResourceManagerHelper.registerBuiltinResourcePack(
                Identifier.of(ZomboidMod.MOD_ID, "knox_realistic"),
                net.fabricmc.loader.api.FabricLoader.getInstance().getModContainer(ZomboidMod.MOD_ID).orElseThrow(),
                net.minecraft.text.Text.literal("Knox: реалистичные текстуры"),
                net.fabricmc.fabric.api.resource.ResourcePackActivationType.DEFAULT_ENABLED);
        // мебель с прозрачными деталями (сетка тележки, знак), пятна крови и мусор
        for (net.minecraft.block.Block b : com.example.zomboidmod.block.ZomboidBlocks.FURNITURE.values())
            net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(b, net.minecraft.client.render.RenderLayer.getCutout());
        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(
                com.example.zomboidmod.block.ZomboidBlocks.BLOOD, net.minecraft.client.render.RenderLayer.getTranslucent());
        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(
                com.example.zomboidmod.block.ZomboidBlocks.LITTER, net.minecraft.client.render.RenderLayer.getCutout());
        HudRenderCallback.EVENT.register(ZomboidClient::render);
        ClientTickEvents.END_CLIENT_TICK.register(ZomboidClient::tick);
    }

    private static void parseWounds(String data) {
        try {
            String[] a = data.split(",");
            int n = BodyPart.values().length;
            int[] c = new int[n];
            for (int i = 0; i < n; i++) c[i] = Integer.parseInt(a[i].trim());
            boolean v = a[n].trim().equals("1");
            boolean pk = a[n + 1].trim().equals("1");
            int cap = Integer.parseInt(a[n + 2].trim());
            int pn = Integer.parseInt(a[n + 3].trim());
            int bl = Integer.parseInt(a[n + 4].trim());
            codes = c;
            virus = v;
            painkiller = pk;
            capPercent = cap;
            pain = pn;
            bleedLevel = bl;
            sickLevel = a.length > n + 5 ? Integer.parseInt(a[n + 5].trim()) : 0;
        } catch (Exception ignored) {
        }
    }

    private static void tick(MinecraftClient c) {
        com.example.zomboidmod.vehicle.VehicleClient.tick(c);
        com.example.zomboidmod.backpack.BackpackClient.tick(c);
        com.example.zomboidmod.survival.SurvivalClient.tick(c);
        com.example.zomboidmod.atmosphere.Atmosphere.tick(c);
        // стандартное главное меню заменяется своим
        if (c.currentScreen instanceof net.minecraft.client.gui.screen.TitleScreen) {
            c.setScreen(new PzTitleScreen());
            return;
        }
        if (c.player == null || c.world == null) return;

        // выбор профессии открывается, когда мир загрузился и никакой экран не открыт
        if (promptPending && c.currentScreen == null) {
            promptPending = false;
            c.setScreen(new ProfessionScreen());
            return;
        }

        // R — перезарядка оружия в руке
        while (reloadKey.wasPressed()) {
            if (c.player.getMainHandStack().getItem() instanceof com.example.zomboidmod.gun.GunItem)
                ClientPlayNetworking.send(new com.example.zomboidmod.gun.Guns.ReloadPayload());
        }

        // H открывает панель здоровья
        while (healthKey.wasPressed()) {
            if (c.currentScreen == null) c.setScreen(new HealthScreen());
        }

        // Shift + зажатая ПКМ с пустой рукой, глядя на воду: просим сервер дать попить
        if (c.currentScreen != null) return;
        if (c.player.isCreative() || c.player.isSpectator()) return;
        if (!c.options.useKey.isPressed() || !c.player.isSneaking()) return;
        if (!c.player.getMainHandStack().isEmpty()) return;

        HitResult hit = c.player.raycast(4.0, 1.0f, true);
        if (hit.getType() == HitResult.Type.BLOCK
                && c.world.getFluidState(((BlockHitResult) hit).getBlockPos()).isIn(FluidTags.WATER)) {
            ClientPlayNetworking.send(new DrinkPayload());
        }
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        com.example.zomboidmod.vehicle.VehicleClient.hud(ctx, c);
        com.example.zomboidmod.gun.GunClient.hud(ctx, c);
        if (c.player.isCreative() || c.player.isSpectator()) return;

        com.example.zomboidmod.survival.SurvivalClient.overlay(ctx, c);
        renderMoodles(ctx, c);
        renderHealthIcon(ctx, c);
    }

    // ===== Мудлы: колонка значков справа сверху =====
    private static void renderMoodles(DrawContext ctx, MinecraftClient c) {
        int x = ctx.getScaledWindowWidth() - 26;
        int y = 6;
        RenderSystem.enableBlend();
        for (Moodles.Moodle m : Moodles.current(c)) {
            int bg = Moodles.color(m);
            // рамка, фон с градиентом, значок
            ctx.fill(x - 1, y - 1, x + 21, y + 21, 0xFF101010);
            ctx.fillGradient(x, y, x + 20, y + 20, brighten(bg), bg);
            ctx.drawTexture(GuiUtil.gui("moodle/" + m.icon()), x + 2, y + 2, 0f, 0f, 16, 16, 16, 16);
            // уровень: точки внизу
            for (int i = 0; i < m.level(); i++) ctx.fill(x + 2 + i * 4, y + 17, x + 4 + i * 4, y + 19, 0xFFEFEFEF);
            y += 24;
            if (y + 24 > ctx.getScaledWindowHeight() - 50) {   // много значков — вторая колонка
                y = 6;
                x -= 24;
            }
        }
        RenderSystem.disableBlend();
    }

    private static int brighten(int argb) {
        int r = Math.min(255, ((argb >> 16) & 255) + 45), g = Math.min(255, ((argb >> 8) & 255) + 45),
                b = Math.min(255, (argb & 255) + 45);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    // ===== Сердце (вход в панель здоровья) и куколка, если есть раны =====
    private static void renderHealthIcon(DrawContext ctx, MinecraftClient c) {
        float hp = c.player.getHealth();
        if (lastHp >= 0 && hp < lastHp - 0.01f) hurtFlash = 20;
        lastHp = hp;
        if (hurtFlash > 0) hurtFlash--;

        int x = 6, y = 6;
        // сердце дрожит, когда персонаж теряет здоровье
        int jx = hurtFlash > 0 ? (int) Math.round(Math.sin(hurtFlash * 1.7) * 2) : 0;
        RenderSystem.enableBlend();
        ctx.fill(x - 2, y - 2, x + 22, y + 20, 0x88000000);
        ctx.drawTexture(GuiUtil.HEART, x + 2 + jx, y + 1, 18, 16, 0f, 0f, 9, 8, 9, 8);

        boolean wounded = false;
        for (int code : codes) {
            if ((code & 15) != 0 || (code & (1 << 8)) != 0) {
                wounded = true;
                break;
            }
        }
        if (wounded) {
            int dw = 20, dh = 40, dy = y + 22;
            ctx.fill(x - 2, dy - 2, x + 22, dy + dh + 2, 0x88000000);
            GuiUtil.mask(ctx, GuiUtil.gui("mini_body_fill"), x, dy, dw, dh, 28, 56, 0x66000000);
            for (int i = 0; i < codes.length; i++) {
                int color = GuiUtil.woundColor(codes[i]);
                if (color != 0) GuiUtil.mask(ctx, GuiUtil.part(i, true), x, dy, dw, dh, 28, 56, (color & 0x00FFFFFF) | 0xDD000000);
            }
            GuiUtil.mask(ctx, GuiUtil.gui("mini_body_outline"), x, dy, dw, dh, 28, 56, 0xFFE8E8D8);
        }
        RenderSystem.disableBlend();
    }
}
