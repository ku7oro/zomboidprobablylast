package com.example.zomboidmod;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.Item;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Панель здоровья в стиле Project Zomboid: окно со вкладками, силуэт из 17 частей, шкала здоровья с сердцем. */
public class HealthScreen extends Screen {
    // Рамки частей тела (x1, y1, x2, y2) в координатах текстуры 64x128, в порядке BodyPart.
    private static final int[][] RECTS = {
            {23, 0, 40, 20},   // 0,
            {28, 20, 34, 25},   // 1,
            {17, 26, 46, 45},   // 2,
            {21, 46, 42, 61},   // 3,
            {22, 62, 41, 74},   // 4,
            {47, 27, 55, 47},   // 5,
            {8, 27, 16, 47},   // 6,
            {47, 48, 55, 67},   // 7,
            {8, 48, 16, 67},   // 8,
            {48, 68, 56, 79},   // 9,
            {7, 68, 15, 79},   // 10,
            {33, 71, 42, 97},   // 11,
            {21, 71, 30, 97},   // 12,
            {34, 98, 41, 117},   // 13,
            {22, 98, 29, 117},   // 14,
            {33, 118, 44, 126},   // 15,
            {19, 118, 30, 126},   // 16
    };

    private record MenuEntry(String label, int part, int action, boolean enabled, int x, int y, int w) {}

    private int selected = -1;
    private int tab = 2;                       // 0 Инфо, 1 Навыки, 2 Здоровье
    private final int[][] tabRects = new int[3][4];
    private final List<MenuEntry> menu = new ArrayList<>();
    private int menuX, menuY, menuW, menuH;
    private int btnX, btnW, painY, abY;

    public HealthScreen() {
        super(Text.literal("Здоровье"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ----- статусы (таблица и моодлы из PZ) -----
    public static String statusOf(float pct, int cap) {
        if (pct <= 0f) return "Мёртвый";
        if (pct >= 99.9f && cap >= 100) return "Отличное";
        if (pct >= 90f) return "Очень незначительный урон";
        if (pct >= 80f) return "Незначительный урон";
        if (pct >= 70f) return "Лёгкий урон";
        if (pct >= 60f) return "Умеренный урон";
        if (pct >= 50f) return "Тяжёлый урон";
        if (pct >= 40f) return "Очень тяжёлый урон";
        if (pct >= 20f) return "Критический урон";
        if (pct >= 10f) return "Весьма критический урон";
        return "Смертельный урон";
    }

    /** Моодл "Травмирован": пороги 80 / 60 / 40 / 25. */
    public static String injuredName(float pct) {
        if (pct >= 80f) return "";
        if (pct >= 60f) return "Дискомфорт";
        if (pct >= 40f) return "Травмирован";
        if (pct >= 25f) return "Тяжёлые травмы";
        return "Критические травмы";
    }

    /** Моодл "Боль": пороги 10 / 20 / 50 / 75. */
    public static String painName(int pain) {
        if (pain >= 75) return "Агония";
        if (pain >= 50) return "Сильная боль";
        if (pain >= 20) return "Боль";
        if (pain >= 10) return "Слабая боль";
        return "";
    }

    public static String bleedName(int level) {
        return switch (level) {
            case 1 -> "Лёгкое кровотечение";
            case 2 -> "Кровотечение";
            case 3 -> "Обильная кровопотеря";
            default -> "";
        };
    }

    public static int colorOf(float pct) {
        if (pct >= 70f) return 0x55FF55;
        if (pct >= 40f) return 0xFFFF55;
        if (pct >= 20f) return 0xFFAA33;
        return 0xFF5555;
    }

    // ----- раскладка окна -----
    /** {sc, winW, winH, wx, wy, bx, by} */
    private int[] lay() {
        int sc = this.height >= 330 ? 2 : 1;
        int infoW = 230;
        int winW = 12 + 64 * sc + 8 + 6 + 14 + infoW + 12;
        int winH = Math.max(128 * sc + 52, 230);
        int wx = (this.width - winW) / 2;
        int wy = (this.height - winH) / 2;
        return new int[]{sc, winW, winH, wx, wy, wx + 12, wy + 26};
    }

    private int partAt(double mx, double my) {
        int[] L = lay();
        int sc = L[0], bx = L[5], by = L[6];
        for (int i = 0; i < RECTS.length; i++) {
            int[] r = RECTS[i];
            if (mx >= bx + r[0] * sc && mx < bx + (r[2] + 1) * sc
                    && my >= by + r[1] * sc && my < by + (r[3] + 1) * sc) return i;
        }
        return -1;
    }

    private static int count(Item item) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null) return 0;
        if (c.player.isCreative()) return 99;
        return c.player.getInventory().count(item);
    }

    private static String describe(int code) {
        List<String> parts = new ArrayList<>();
        int type = code & 15;
        if (type != 0) parts.add(WoundType.values()[type].title);
        if ((code & (1 << 11)) != 0) parts.add("кровотечение");
        if ((code & (1 << 4)) != 0) parts.add((code & (1 << 5)) != 0 ? "грязная повязка" : "повязка");
        if ((code & (1 << 10)) != 0) parts.add("обработана");
        if ((code & (1 << 6)) != 0) parts.add("швы");
        if ((code & (1 << 7)) != 0) parts.add("инфекция");
        if ((code & (1 << 8)) != 0) parts.add((code & (1 << 9)) != 0 ? "перелом (шина)" : "перелом");
        return parts.isEmpty() ? "здорова" : String.join(", ", parts);
    }

    private int drawTab(DrawContext ctx, int x, int y, String label, boolean active) {
        int w = this.textRenderer.getWidth(label) + 10;
        int i = label.equals("Инфо") ? 0 : (label.equals("Навыки") ? 1 : 2);
        tabRects[i] = new int[]{x, y, x + w, y + 13};
        ctx.fill(x, y, x + w, y + 13, active ? 0xFF3C3C3C : 0xFF1B1B1B);
        ctx.drawTextWithShadow(this.textRenderer, label, x + 5, y + 3, active ? 0xFFFFFF : 0x777777);
        return x + w + 2;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null) return;

        int[] L = lay();
        int sc = L[0], winW = L[1], winH = L[2], wx = L[3], wy = L[4], bx = L[5], by = L[6];
        int[] codes = ZomboidClient.codes();
        float pct = c.player.getHealth() / c.player.getMaxHealth() * 100f;

        // окно и заголовок
        ctx.fill(wx - 1, wy - 1, wx + winW + 1, wy + winH + 1, 0xFF6E6E6E);
        ctx.fill(wx, wy, wx + winW, wy + winH, 0xF0121212);
        ctx.fill(wx, wy, wx + winW, wy + 16, 0xFF262626);
        ctx.fill(wx + 3, wy + 3, wx + 13, wy + 13, 0xFF505050);
        ctx.drawTextWithShadow(this.textRenderer, "x", wx + 6, wy + 3, 0xFFFFFF);
        int tx = wx + 20;
        tx = drawTab(ctx, tx, wy + 3, "Инфо", tab == 0);
        tx = drawTab(ctx, tx, wy + 3, "Навыки", tab == 1);
        drawTab(ctx, tx, wy + 3, "Здоровье", tab == 2);
        if (tab == 0) {
            renderInfo(ctx, wx, wy, winW, winH);
            return;
        }
        if (tab == 1) {
            renderSkills(ctx, mx, my, wx, wy, winW, winH);
            return;
        }

        // силуэт
        int bw = 64 * sc, bh = 128 * sc;
        ctx.fill(bx - 3, by - 3, bx + bw + 3, by + bh + 3, 0xFF2E2E2E);
        ctx.fill(bx - 2, by - 2, bx + bw + 2, by + bh + 2, 0xFF0A0A0A);
        int hover = partAt(mx, my);

        RenderSystem.enableBlend();
        GuiUtil.mask(ctx, GuiUtil.gui("body_fill"), bx, by, bw, bh, 64, 128, 0x66101010);
        for (int i = 0; i < codes.length; i++) {
            int color = GuiUtil.woundColor(codes[i]);
            if (color != 0) {
                GuiUtil.mask(ctx, GuiUtil.part(i, false), bx, by, bw, bh, 64, 128, (color & 0x00FFFFFF) | 0xC0000000);
            }
        }
        if (hover >= 0) GuiUtil.mask(ctx, GuiUtil.part(hover, false), bx, by, bw, bh, 64, 128, 0x40FFFFFF);
        if (selected >= 0) GuiUtil.mask(ctx, GuiUtil.part(selected, false), bx, by, bw, bh, 64, 128, 0x50FFFFFF);
        GuiUtil.mask(ctx, GuiUtil.gui("body_outline"), bx, by, bw, bh, 64, 128, 0xFFF0F0DC);
        RenderSystem.disableBlend();

        // значки состояния на частях тела
        for (int i = 0; i < codes.length; i++) {
            int code = codes[i];
            int[] r = RECTS[i];
            int cx = bx + (r[0] + r[2] + 1) * sc / 2;
            int cy = by + (r[1] + r[3] + 1) * sc / 2;
            if ((code & (1 << 11)) != 0) ctx.fill(cx - sc, cy - sc, cx + sc, cy + sc, 0xFFFF2020);
            if ((code & (1 << 4)) != 0) {
                int bc = (code & (1 << 5)) != 0 ? 0xFFB08040 : 0xFFFFFFFF;
                ctx.fill(cx - 2 * sc, cy + sc, cx + 2 * sc, cy + 2 * sc, bc);
            }
            if ((code & (1 << 7)) != 0) ctx.fill(cx + sc, cy - 3 * sc, cx + 3 * sc, cy - sc, 0xFFA0FF30);
            if ((code & (1 << 6)) != 0) ctx.fill(cx - 2 * sc, cy - 3 * sc, cx, cy - 2 * sc, 0xFFDDDDDD);
        }

        // вертикальная шкала здоровья с сердцем
        int barX = bx + bw + 10, barW = 6;
        ctx.fill(barX - 1, by - 1, barX + barW + 1, by + bh + 1, 0xFF404040);
        ctx.fill(barX, by, barX + barW, by + bh, 0xFF141414);
        int fh = Math.round(bh * Math.max(0f, Math.min(100f, pct)) / 100f);
        if (fh > 0) ctx.fillGradient(barX, by + bh - fh, barX + barW, by + bh, 0xFFFFFFFF, 0xFF7A7A7A);
        if (ZomboidClient.capPercent() < 100) {
            int capY = by + Math.round(bh * (1f - ZomboidClient.capPercent() / 100f));
            ctx.fill(barX - 2, capY, barX + barW + 2, capY + 1, 0xFFFF5555);
        }
        int hy = Math.max(by, Math.min(by + bh - 8, by + bh - fh - 4));
        RenderSystem.enableBlend();
        ctx.drawTexture(GuiUtil.HEART, barX + barW + 4, hy, 0f, 0f, 9, 8, 9, 8);
        RenderSystem.disableBlend();

        // текстовая часть
        int ix = barX + barW + 20;
        int ty = by - 2;
        ctx.drawTextWithShadow(this.textRenderer, "Нажмите на часть тела:", ix, ty, 0xAAAAAA);
        ctx.drawTextWithShadow(this.textRenderer, "откроется меню лечения", ix, ty + 10, 0xAAAAAA);
        ty += 26;
        ctx.drawTextWithShadow(this.textRenderer, "Общее состояние тела", ix, ty, 0xFFFFFF);
        ty += 11;
        ctx.drawTextWithShadow(this.textRenderer,
                statusOf(pct, ZomboidClient.capPercent()) + " (" + Math.round(pct) + "%)", ix, ty, colorOf(pct));
        ty += 11;
        if (ZomboidClient.capPercent() < 100) {
            ctx.drawTextWithShadow(this.textRenderer,
                    "Максимум из-за травм: " + ZomboidClient.capPercent() + "%", ix, ty, 0xAAAAAA);
            ty += 11;
        }
        // мудлы со значками и описанием
        ty += 3;
        RenderSystem.enableBlend();
        for (Moodles.Moodle m : Moodles.current(c)) {
            int bg = Moodles.color(m);
            ctx.fill(ix - 1, ty - 1, ix + 13, ty + 13, 0xFF101010);
            ctx.fill(ix, ty, ix + 12, ty + 12, bg);
            ctx.drawTexture(GuiUtil.gui("moodle/" + m.icon()), ix, ty, 12, 12, 0f, 0f, 16, 16, 16, 16);
            ctx.drawTextWithShadow(this.textRenderer, m.name(), ix + 17, ty, m.good() ? 0x88EE88 : 0xFFFFFF);
            GuiUtil.smallText(ctx, this.textRenderer, m.desc(), ix + 17, ty + 9, 0xAAAAAA);
            ty += 18;
        }
        RenderSystem.disableBlend();
        if (ZomboidClient.painkiller()) {
            ctx.drawTextWithShadow(this.textRenderer, "Обезболивающее действует", ix, ty, 0x55AAFF);
            ty += 11;
        }

        // выбранная или наведённая часть тела
        ty += 4;
        int idx = hover >= 0 ? hover : selected;
        if (idx >= 0) {
            ctx.drawTextWithShadow(this.textRenderer, BodyPart.values()[idx].title, ix, ty, 0xFFFFFF);
            ctx.drawTextWithShadow(this.textRenderer, describe(codes[idx]), ix, ty + 11, 0xCCCCCC);
        }

        // общие действия
        btnX = ix;
        btnW = 170;
        abY = wy + winH - 20;
        painY = abY - 14;
        drawButton(ctx, mx, my, btnX, painY, btnW,
                "Принять обезболивающее (" + count(ZomboidMod.PAINKILLERS) + ")",
                count(ZomboidMod.PAINKILLERS) > 0);
        drawButton(ctx, mx, my, btnX, abY, btnW,
                "Принять антибиотики (" + count(ZomboidMod.ANTIBIOTICS) + ")",
                count(ZomboidMod.ANTIBIOTICS) > 0);

        // меню лечения
        if (!menu.isEmpty()) {
            ctx.fill(menuX - 1, menuY - 1, menuX + menuW + 1, menuY + menuH + 1, 0xFF8A8A8A);
            ctx.fill(menuX, menuY, menuX + menuW, menuY + menuH, 0xFF1A1A1A);
            for (MenuEntry e : menu) {
                boolean over = mx >= e.x() && mx < e.x() + e.w() && my >= e.y() && my < e.y() + 12;
                if (over && e.enabled()) ctx.fill(e.x(), e.y(), e.x() + e.w(), e.y() + 12, 0xFF3C3C3C);
                ctx.drawTextWithShadow(this.textRenderer, e.label(), e.x() + 3, e.y() + 2,
                        e.enabled() ? 0xFFFFFF : 0x777777);
            }
        }
    }

    private void drawButton(DrawContext ctx, int mx, int my, int x, int y, int w, String label, boolean enabled) {
        boolean over = mx >= x && mx < x + w && my >= y && my < y + 12;
        ctx.fill(x, y, x + w, y + 12, over && enabled ? 0xFF3C3C3C : 0xFF1E1E1E);
        ctx.drawTextWithShadow(this.textRenderer, label, x + 3, y + 2, enabled ? 0xFFFFFF : 0x777777);
    }

    private void openMenu(int part, int mx, int my) {
        selected = part;
        menu.clear();
        int code = ZomboidClient.codes()[part];
        int type = code & 15;
        boolean bandaged = (code & (1 << 4)) != 0, dirty = (code & (1 << 5)) != 0;
        boolean stitched = (code & (1 << 6)) != 0, disinfected = (code & (1 << 10)) != 0;
        boolean fracture = (code & (1 << 8)) != 0, splinted = (code & (1 << 9)) != 0;

        List<String> labels = new ArrayList<>();
        List<Integer> actions = new ArrayList<>();
        List<Boolean> enabled = new ArrayList<>();

        if (type != 0 && (!bandaged || dirty)) {
            int n = count(ZomboidMod.BANDAGE);
            labels.add((dirty ? "Заменить бинт" : "Наложить бинт") + " (" + n + ")");
            actions.add(MedItem.Kind.BANDAGE.ordinal());
            enabled.add(n > 0);
        }
        if (type != 0 && (!bandaged || dirty)) {
            int n = count(ZomboidMod.RAG);
            labels.add((dirty ? "Заменить на тряпку" : "Перевязать тряпкой") + " (" + n + ")");
            actions.add(MedItem.Kind.RAG.ordinal());
            enabled.add(n > 0);
        }
        if (type != 0 && !disinfected) {
            int n = count(ZomboidMod.ANTISEPTIC);
            labels.add("Продезинфицировать рану (" + n + ")");
            actions.add(MedItem.Kind.ANTISEPTIC.ordinal());
            enabled.add(n > 0);
        }
        if (type == WoundType.DEEP.ordinal() && !stitched) {
            int n = count(ZomboidMod.SUTURE_KIT);
            labels.add("Зашить иглой (" + n + ")");
            actions.add(MedItem.Kind.SUTURE.ordinal());
            enabled.add(n > 0);
        }
        if (fracture && !splinted && BodyPart.values()[part].canSplint()) {
            int n = count(ZomboidMod.SPLINT);
            labels.add("Наложить шину (" + n + ")");
            actions.add(MedItem.Kind.SPLINT.ordinal());
            enabled.add(n > 0);
        }
        if (labels.isEmpty() && fracture && !BodyPart.values()[part].canSplint()) {
            labels.add("Перелом торса не зашинировать");
            actions.add(-1);
            enabled.add(false);
        }
        if (labels.isEmpty()) {
            labels.add("Лечить нечего");
            actions.add(-1);
            enabled.add(false);
        }

        int w = 0;
        for (String l : labels) w = Math.max(w, this.textRenderer.getWidth(l));
        w += 8;
        menuW = w;
        menuH = labels.size() * 12;
        menuX = Math.min(mx, this.width - menuW - 4);
        menuY = Math.min(my, this.height - menuH - 4);
        for (int i = 0; i < labels.size(); i++) {
            menu.add(new MenuEntry(labels.get(i), part, actions.get(i), enabled.get(i),
                    menuX, menuY + i * 12, menuW));
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int[] L = lay();
        // кнопка закрытия
        if (mx >= L[3] + 3 && mx < L[3] + 13 && my >= L[4] + 3 && my < L[4] + 13) {
            this.close();
            return true;
        }
        // вкладки
        for (int i = 0; i < 3; i++) {
            int[] r = tabRects[i];
            if (mx >= r[0] && mx < r[2] && my >= r[1] && my < r[3]) {
                tab = i;
                menu.clear();
                return true;
            }
        }
        if (tab != 2) return super.mouseClicked(mx, my, button);
        // пункты меню
        for (MenuEntry e : menu) {
            if (mx >= e.x() && mx < e.x() + e.w() && my >= e.y() && my < e.y() + 12) {
                if (e.enabled() && e.action() >= 0) {
                    ClientPlayNetworking.send(new TreatPayload(e.part(), e.action()));
                }
                menu.clear();
                return true;
            }
        }
        // общие действия
        if (mx >= btnX && mx < btnX + btnW) {
            if (my >= painY && my < painY + 12) {
                if (count(ZomboidMod.PAINKILLERS) > 0) {
                    ClientPlayNetworking.send(new TreatPayload(0, MedItem.Kind.PAINKILLERS.ordinal()));
                }
                return true;
            }
            if (my >= abY && my < abY + 12) {
                if (count(ZomboidMod.ANTIBIOTICS) > 0) {
                    ClientPlayNetworking.send(new TreatPayload(0, MedItem.Kind.ANTIBIOTICS.ordinal()));
                }
                return true;
            }
        }
        // часть тела
        int hit = partAt(mx, my);
        if (hit >= 0) {
            openMenu(hit, (int) mx, (int) my);
            return true;
        }
        menu.clear();
        selected = -1;
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ZomboidClient.healthKey != null && ZomboidClient.healthKey.matchesKey(keyCode, scanCode)) {
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    // ===== вкладка "Инфо": профессия =====
    private void renderInfo(DrawContext ctx, int wx, int wy, int winW, int winH) {
        Profession p = Profession.byIndex(ZomboidClient.profession());
        int x = wx + 14, y = wy + 28, w = winW - 28;
        ctx.drawTextWithShadow(this.textRenderer, "Профессия", x, y, 0xAAAAAA);
        ctx.drawTextWithShadow(this.textRenderer, p.title, x, y + 12, 0xFFD54A);
        y += 30;
        for (var line : this.textRenderer.wrapLines(Text.literal(p.description), w)) {
            ctx.drawTextWithShadow(this.textRenderer, line, x, y, 0xCCCCCC);
            y += 10;
        }
        y += 10;
        ctx.drawTextWithShadow(this.textRenderer, "Стартовые навыки:", x, y, 0xFFFFFF);
        y += 12;
        if (p.levels.isEmpty()) {
            ctx.drawTextWithShadow(this.textRenderer, "нет", x + 6, y, 0x888888);
            y += 11;
        }
        for (var e : p.levels.entrySet()) {
            ctx.drawTextWithShadow(this.textRenderer, e.getKey().title + ": " + e.getValue(), x + 6, y, 0x88EE88);
            y += 11;
        }
        y += 8;
        ctx.drawTextWithShadow(this.textRenderer, "Черты характера:", x, y, 0xFFFFFF);
        y += 12;
        long tr = ZomboidClient.traits();
        boolean any = false;
        for (PzTrait t : PzTrait.values()) {
            if (!PzTrait.has(tr, t)) continue;
            any = true;
            ctx.drawTextWithShadow(this.textRenderer, t.title, x + 6, y, t.positive() ? 0x88EE88 : 0xFF8888);
            GuiUtil.smallText(ctx, this.textRenderer, t.description, x + 120, y + 1, 0xAAAAAA);
            y += 11;
        }
        if (!any) ctx.drawTextWithShadow(this.textRenderer, "нет", x + 6, y, 0x888888);
    }

    // ===== вкладка "Навыки": уровни 0-10 квадратиками, как в PZ =====
    private void renderSkills(DrawContext ctx, int mx, int my, int wx, int wy, int winW, int winH) {
        int colW = (winW - 24) / 2;
        int x = wx + 10, y = wy + 24;
        int col = 0;
        PzSkill.Category last = null;
        PzSkill hover = null;
        int hx = 0, hy = 0;
        for (PzSkill s : PzSkill.ordered()) {
            if (s.category != last) {
                if (last != null) y += 4;
                if (col == 0 && s.category == PzSkill.Category.CRAFTING) {   // вторая колонка
                    col = 1;
                    x = wx + 14 + colW;
                    y = wy + 24;
                }
                last = s.category;
                ctx.drawTextWithShadow(this.textRenderer, s.category.title, x, y, 0x888888);
                y += 11;
            }
            int boost = ZomboidClient.skillBoost(s);
            int nameCol = boost >= 5 ? 0xFFD54A : (boost == 4 ? 0xFFFFFF : (boost == 3 ? 0xBBBBBB : 0x8A8A8A));
            ctx.drawTextWithShadow(this.textRenderer, s.title, x + 2, y + 1, nameCol);
            int lv = ZomboidClient.skillLevel(s);
            int bx0 = x + colW - 10 * 5 - 2;
            for (int i = 0; i < 10; i++) {
                int bx = bx0 + i * 5;
                ctx.fill(bx, y + 1, bx + 4, y + 8, 0xFF2A2A2A);
                if (i < lv) ctx.fill(bx, y + 1, bx + 4, y + 8, 0xFFD8D8D0);
                else if (i == lv && lv < 10) {
                    int fw = Math.round(4 * ZomboidClient.skillProgress(s) / 1000f);
                    if (fw > 0) ctx.fill(bx, y + 1, bx + fw, y + 8, 0xFF7A7A72);
                }
            }
            if (mx >= x && mx < x + colW && my >= y && my < y + 10) {
                hover = s;
                hx = mx;
                hy = my;
            }
            y += 11;
        }
        GuiUtil.smallText(ctx, this.textRenderer, "Цвет названия - множитель опыта: золотой x5, белый x4, серый x3, тёмный x1",
                wx + 10, wy + winH - 12, 0x888888);
        if (hover != null) {
            String t1 = hover.title + " - " + ZomboidClient.skillLevel(hover) + " ур.";
            String t2 = hover.effect();
            String t3 = "Опыт: x" + ZomboidClient.skillBoost(hover) + ", до след. уровня " + ZomboidClient.skillProgress(hover) / 10 + "%";
            int w = Math.max(this.textRenderer.getWidth(t1), Math.max(this.textRenderer.getWidth(t2), this.textRenderer.getWidth(t3))) + 8;
            int tx = Math.min(hx + 8, this.width - w - 4), ty = hy + 8;
            ctx.fill(tx - 1, ty - 1, tx + w + 1, ty + 35, 0xFF8A8A8A);
            ctx.fill(tx, ty, tx + w, ty + 34, 0xF0101010);
            ctx.drawTextWithShadow(this.textRenderer, t1, tx + 4, ty + 3, 0xFFFFFF);
            ctx.drawTextWithShadow(this.textRenderer, t2, tx + 4, ty + 13, 0xBBBBBB);
            ctx.drawTextWithShadow(this.textRenderer, t3, tx + 4, ty + 23, 0x888888);
        }
    }
}
