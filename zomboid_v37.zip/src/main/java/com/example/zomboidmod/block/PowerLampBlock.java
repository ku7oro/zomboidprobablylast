package com.example.zomboidmod.block;

import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.survival.Power;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/**
 * Электрический свет: горит, только пока есть ток (сеть или генератор рядом). После отключения
 * лампы гаснут одна за другой. Потолочную лампу можно выключить выключателем (ПКМ), как в PZ.
 * Невидимый вариант стоит в уличных фонарях.
 */
public class PowerLampBlock extends Block {
    public static final BooleanProperty LIT = Properties.LIT;
    public static final BooleanProperty ON = BooleanProperty.of("on");
    private static final VoxelShape SHAPE = Block.createCuboidShape(5, 7, 5, 11, 16, 11);
    public static Block CEILING_LAMP, POWER_LIGHT;
    private final boolean visible;

    public PowerLampBlock(Settings s, boolean visible) {
        super(s);
        this.visible = visible;
        setDefaultState(getStateManager().getDefaultState().with(LIT, true).with(ON, true));
    }

    public static void register() {
        CEILING_LAMP = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, "ceiling_lamp"),
                new PowerLampBlock(AbstractBlock.Settings.create().strength(0.3f).sounds(BlockSoundGroup.LANTERN).nonOpaque().noCollision()
                        .ticksRandomly().luminance(st -> st.get(LIT) ? 14 : 0), true));
        Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, "ceiling_lamp"), new BlockItem(CEILING_LAMP, new Item.Settings()));
        POWER_LIGHT = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, "power_light"),
                new PowerLampBlock(AbstractBlock.Settings.create().strength(0.1f).noCollision().nonOpaque().replaceable().dropsNothing()
                        .ticksRandomly().luminance(st -> st.get(LIT) ? 13 : 0), false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(LIT, ON);
    }

    @Override
    protected BlockRenderType getRenderType(BlockState state) {
        return visible ? BlockRenderType.MODEL : BlockRenderType.INVISIBLE;
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return visible ? SHAPE : VoxelShapes.empty();
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return VoxelShapes.empty();
    }

    @Override
    protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        update(world, pos, state);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!visible) return ActionResult.PASS;
        if (world instanceof ServerWorld sw) {
            BlockState ns = state.with(ON, !state.get(ON));
            world.setBlockState(pos, ns, Block.NOTIFY_ALL);
            update(sw, pos, ns);
            world.playSound(null, pos, SoundEvents.BLOCK_STONE_BUTTON_CLICK_ON, SoundCategory.BLOCKS, 0.5f, ns.get(ON) ? 1.3f : 1.0f);
            if (ns.get(ON) && !world.getBlockState(pos).get(LIT)) player.sendMessage(net.minecraft.text.Text.literal("Щёлк... Света нет"), true);
        }
        return ActionResult.success(world.isClient);
    }

    public static void update(ServerWorld w, BlockPos pos, BlockState state) {
        if (!(state.getBlock() instanceof PowerLampBlock)) return;
        boolean lit = state.get(ON) && Power.powered(w, pos);
        if (lit != state.get(LIT)) w.setBlockState(pos, state.with(LIT, lit), Block.NOTIFY_ALL);
    }

    /** Генератор включили или он заглох — сразу обновить лампы вокруг. */
    public static void refreshAround(ServerWorld w, BlockPos center, int r) {
        for (BlockPos p : BlockPos.iterate(center.add(-r, -4, -r), center.add(r, 6, r))) {
            BlockState s = w.getBlockState(p);
            if (s.getBlock() instanceof PowerLampBlock) update(w, p.toImmutable(), s);
        }
    }
}
