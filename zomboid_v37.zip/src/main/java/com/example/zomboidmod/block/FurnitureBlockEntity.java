package com.example.zomboidmod.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventories;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.text.Text;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;

/** Инвентарь мебели (холодильник, шкафы, тумбочки, стеллажи). */
public class FurnitureBlockEntity extends LootableContainerBlockEntity {
    private DefaultedList<ItemStack> items;
    // генератор: бензин (л) и включён ли; бочка: вода (порций); холодильник/плита: время последней проверки
    public float fuel, water;
    public boolean on;
    public long lastTime = -1;
    public int clock;

    public FurnitureBlockEntity(BlockPos pos, BlockState state) {
        super(ZomboidBlocks.FURNITURE_BE, pos, state);
        int rows = state.getBlock() instanceof FurnitureBlock fb ? Math.max(1, Math.min(3, fb.rows)) : 3;
        items = DefaultedList.ofSize(rows * 9, ItemStack.EMPTY);
    }

    @Override
    protected DefaultedList<ItemStack> getHeldStacks() {
        return items;
    }

    @Override
    protected void setHeldStacks(DefaultedList<ItemStack> list) {
        items = list;
    }

    @Override
    public int size() {
        return items.size();
    }

    @Override
    protected Text getContainerName() {
        return getCachedState().getBlock().getName();
    }

    public DefaultedList<ItemStack> stacks() {
        return items;
    }

    public static void serverTick(net.minecraft.world.World w, BlockPos pos, BlockState state, FurnitureBlockEntity be) {
        if (w instanceof net.minecraft.server.world.ServerWorld sw) com.example.zomboidmod.survival.Appliances.tick(sw, pos, state, be);
    }

    @Override
    protected ScreenHandler createScreenHandler(int syncId, PlayerInventory inv) {
        // продукты из мебели лежат с первого дня эпидемии
        if (world != null && !world.isClient) com.example.zomboidmod.survival.Food.stampAll(items, 0L);
        int rows = size() / 9;
        ScreenHandlerType<GenericContainerScreenHandler> type = rows == 1 ? ScreenHandlerType.GENERIC_9X1
                : (rows == 2 ? ScreenHandlerType.GENERIC_9X2 : ScreenHandlerType.GENERIC_9X3);
        return new GenericContainerScreenHandler(type, syncId, inv, this, rows);
    }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.readNbt(nbt, lookup);
        items = DefaultedList.ofSize(size(), ItemStack.EMPTY);
        if (!readLootTable(nbt)) Inventories.readNbt(nbt, items, lookup);
        fuel = nbt.getFloat("Fuel");
        water = nbt.getFloat("Water");
        on = nbt.getBoolean("On");
        lastTime = nbt.contains("Last") ? nbt.getLong("Last") : -1;
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.writeNbt(nbt, lookup);
        if (!writeLootTable(nbt)) Inventories.writeNbt(nbt, items, lookup);
        nbt.putFloat("Fuel", fuel);
        nbt.putFloat("Water", water);
        nbt.putBoolean("On", on);
        nbt.putLong("Last", lastTime);
    }
}
