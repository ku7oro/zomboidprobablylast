package com.example.zomboidmod.mixin;

import com.example.zomboidmod.atmosphere.Atmosphere;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Дымка и туман, выцветший цвет тумана и фона. */
@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {
    @Shadow
    private static float red;
    @Shadow
    private static float green;
    @Shadow
    private static float blue;

    @Inject(method = "applyFog", at = @At("TAIL"))
    private static void zomboid$fog(Camera camera, BackgroundRenderer.FogType fogType, float viewDistance, boolean thickFog, float tickDelta,
                                    CallbackInfo ci) {
        Atmosphere.applyFog(camera, fogType, viewDistance);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private static void zomboid$color(Camera camera, float tickDelta, ClientWorld world, int viewDistance, float skyDarkness, CallbackInfo ci) {
        float[] c = Atmosphere.fogColor(camera, red, green, blue);
        if (c == null) return;
        red = c[0];
        green = c[1];
        blue = c[2];
        RenderSystem.clearColor(red, green, blue, 0.0f);
    }
}
