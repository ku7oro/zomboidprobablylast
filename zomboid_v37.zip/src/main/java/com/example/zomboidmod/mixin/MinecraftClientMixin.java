package com.example.zomboidmod.mixin;

import com.example.zomboidmod.gun.GunClient;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** С оружием в руке ЛКМ — выстрел, а не удар и не копание. */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void zomboid$fire(CallbackInfoReturnable<Boolean> cir) {
        MinecraftClient c = (MinecraftClient) (Object) this;
        if (c.player != null && com.example.zomboidmod.parkour.ParkourClient.climbing(c.player)) {   // на заборе не до драки
            cir.setReturnValue(false);
            return;
        }
        if (GunClient.onAttack(c)) cir.setReturnValue(false);
    }

    @Inject(method = "doItemUse", at = @At("HEAD"), cancellable = true)
    private void zomboid$noUseWhileClimbing(CallbackInfo ci) {
        MinecraftClient c = (MinecraftClient) (Object) this;
        if (c.player != null && com.example.zomboidmod.parkour.ParkourClient.climbing(c.player)) ci.cancel();
    }

    @Inject(method = "handleBlockBreaking", at = @At("HEAD"), cancellable = true)
    private void zomboid$noMining(boolean breaking, CallbackInfo ci) {
        MinecraftClient c = (MinecraftClient) (Object) this;
        if (GunClient.holding() || (c.player != null && com.example.zomboidmod.parkour.ParkourClient.climbing(c.player))) ci.cancel();
    }
}
