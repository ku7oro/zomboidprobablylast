package com.example.zomboidmod.mixin;

import com.example.zomboidmod.clothing.ClothingHolder;
import com.example.zomboidmod.clothing.Clothes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Слоты одежды у игрока + сохранение вместе с игроком. */
@Mixin(PlayerEntity.class)
public abstract class PlayerClothesMixin implements ClothingHolder {
    @Unique
    private final ItemStack[] zomboid$worn = Clothes.emptyArray();

    @Override
    public ItemStack[] zomboid$clothes() {
        return zomboid$worn;
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void zomboid$saveClothes(NbtCompound nbt, CallbackInfo ci) {
        Clothes.save((PlayerEntity) (Object) this, nbt);
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void zomboid$loadClothes(NbtCompound nbt, CallbackInfo ci) {
        Clothes.load((PlayerEntity) (Object) this, nbt);
    }
}
