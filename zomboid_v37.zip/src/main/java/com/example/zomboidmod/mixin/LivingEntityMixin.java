package com.example.zomboidmod.mixin;

import com.example.zomboidmod.WeaponKinds;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Длительность взмаха зависит от оружия: кувалдой замахиваются вдвое дольше, чем ножом. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true)
    private void zomboid$swingDuration(CallbackInfoReturnable<Integer> cir) {
        int t = WeaponKinds.swingTicks(((LivingEntity) (Object) this).getMainHandStack());
        if (t > 0) cir.setReturnValue(t);
    }

    /** Свежесть еды: несвежая портит настроение, испорченная отравляет. */
    @Inject(method = "eatFood", at = @At("HEAD"))
    private void zomboid$eat(net.minecraft.world.World world, net.minecraft.item.ItemStack stack,
                             net.minecraft.component.type.FoodComponent food, CallbackInfoReturnable<net.minecraft.item.ItemStack> cir) {
        if (!world.isClient && (Object) this instanceof net.minecraft.server.network.ServerPlayerEntity p)
            com.example.zomboidmod.survival.Survival.onEat(p, stack);
    }
}
