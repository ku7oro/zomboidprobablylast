package com.example.zomboidmod.mixin;

import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Пока лезет сквозь окно или через забор — голова может задеть блок, но не задыхается. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "isInsideWall", at = @At("HEAD"), cancellable = true)
    private void zomboid$climbNoSuffocation(CallbackInfoReturnable<Boolean> cir) {
        if (com.example.zomboidmod.parkour.Parkour.climbing((Entity) (Object) this)) cir.setReturnValue(false);
    }
}
