package com.example.zomboidmod.mixin;

import com.example.zomboidmod.build.Carpentry;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Стройка как в PZ: молоток, гвозди и навык; каждый блок — время, шум и опыт. */
@Mixin(BlockItem.class)
public abstract class BlockItemMixin {
    @Shadow
    public abstract Block getBlock();

    @Inject(method = "place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;", at = @At("HEAD"), cancellable = true)
    private void zomboid$needTools(ItemPlacementContext ctx, CallbackInfoReturnable<ActionResult> cir) {
        String why = Carpentry.placeCheck(ctx.getPlayer(), getBlock());
        if (why == null) return;
        if (!why.isEmpty() && ctx.getWorld().isClient && ctx.getPlayer() != null)
            ctx.getPlayer().sendMessage(Text.literal(why).formatted(Formatting.GRAY), true);
        cir.setReturnValue(ActionResult.FAIL);
    }

    @Inject(method = "place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;", at = @At("RETURN"))
    private void zomboid$built(ItemPlacementContext ctx, CallbackInfoReturnable<ActionResult> cir) {
        if (cir.getReturnValue().isAccepted()) Carpentry.placed(ctx.getPlayer(), ctx.getWorld(), ctx.getBlockPos(), getBlock());
    }
}
