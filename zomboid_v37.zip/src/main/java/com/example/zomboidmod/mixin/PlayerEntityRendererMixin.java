package com.example.zomboidmod.mixin;

import com.example.zomboidmod.clothing.ClothingRenderer;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Одежда от первого лица (рукава, перчатки) и скрытие второго слоя скина под одеждой. */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {
    @Inject(method = "setModelPose", at = @At("TAIL"))
    private void zomboid$hideSkinUnderClothes(AbstractClientPlayerEntity player, CallbackInfo ci) {
        ClothingRenderer.hideSkinLayers(player, ((PlayerEntityRenderer) (Object) this).getModel());
    }

    @Inject(method = "renderArm", at = @At("TAIL"))
    private void zomboid$sleeves(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, AbstractClientPlayerEntity player,
                                 ModelPart arm, ModelPart sleeve, CallbackInfo ci) {
        ClothingRenderer.firstPersonArm(matrices, vertexConsumers, light, player, arm, ((PlayerEntityRenderer) (Object) this).getModel());
    }
}
