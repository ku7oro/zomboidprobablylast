package com.example.zomboidmod.mixin;

import com.example.zomboidmod.atmosphere.Atmosphere;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Небо и облака выцветшие, ночи тёмные. */
@Mixin(ClientWorld.class)
public abstract class ClientWorldMixin {
    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true)
    private void zomboid$sky(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Vec3d> cir) {
        cir.setReturnValue(Atmosphere.sky(cir.getReturnValue()));
    }

    @Inject(method = "getCloudsColor", at = @At("RETURN"), cancellable = true)
    private void zomboid$clouds(float tickDelta, CallbackInfoReturnable<Vec3d> cir) {
        cir.setReturnValue(Atmosphere.clouds(cir.getReturnValue()));
    }

    @Inject(method = "getSkyBrightness", at = @At("RETURN"), cancellable = true)
    private void zomboid$night(float tickDelta, CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(Atmosphere.skyBrightness(cir.getReturnValue()));
    }
}
