package com.example.zomboidmod.mixin;

import com.example.zomboidmod.gun.GunClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Прицеливание сужает обзор: мушка — чуть, коллиматор — немного, оптика — в 4 и 8 раз. */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
    @Inject(method = "getFovMultiplier", at = @At("RETURN"), cancellable = true)
    private void zomboid$aimZoom(CallbackInfoReturnable<Float> cir) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        float m = GunClient.fovMul();
        if (m != 1f) cir.setReturnValue(cir.getReturnValueF() * m);
    }
}
