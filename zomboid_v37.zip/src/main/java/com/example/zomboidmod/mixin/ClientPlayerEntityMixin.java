package com.example.zomboidmod.mixin;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Weight;
import com.example.zomboidmod.ZomboidClient;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.SurvivalClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Без сил (одышка 3+) или с неподъёмным грузом бежать нельзя. */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    /** Перелезает через забор / в окно: персонаж идёт по маршруту паркура, обычное движение отключено. */
    @Inject(method = "tickMovement", at = @At("HEAD"), cancellable = true)
    private void zomboid$parkour(CallbackInfo ci) {
        if (com.example.zomboidmod.parkour.ParkourClient.tickLocal((ClientPlayerEntity) (Object) this)) ci.cancel();
    }

    /** С оружием в прицеле идут медленнее, но не ползут, как с натянутым луком. */
    @Redirect(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z", ordinal = 0))
    private boolean zomboid$aimWalk(ClientPlayerEntity self) {
        if (self.isUsingItem() && self.getActiveItem().getItem() instanceof com.example.zomboidmod.gun.GunItem) {
            self.input.movementForward *= 0.55f;
            self.input.movementSideways *= 0.55f;
            return false;
        }
        return self.isUsingItem();
    }

    @Inject(method = "canSprint", at = @At("HEAD"), cancellable = true)
    private void zomboid$canSprint(CallbackInfoReturnable<Boolean> cir) {
        ClientPlayerEntity p = (ClientPlayerEntity) (Object) this;
        if (p.isCreative() || p.hasVehicle()) return;
        if (Mood.exertion(SurvivalClient.endurance) >= 3) cir.setReturnValue(false);
        else if (Weight.level(Weight.carried(p) / Weight.capacity(ZomboidClient.skillLevel(PzSkill.STRENGTH))) >= 3) cir.setReturnValue(false);
    }
}
