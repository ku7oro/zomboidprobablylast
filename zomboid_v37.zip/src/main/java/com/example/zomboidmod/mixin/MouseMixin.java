package com.example.zomboidmod.mixin;

import com.example.zomboidmod.gun.GunClient;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** В оптике мышь медленнее — прицел не скачет. */
@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Shadow
    private double cursorDeltaX;
    @Shadow
    private double cursorDeltaY;

    @Inject(method = "updateMouse", at = @At("HEAD"))
    private void zomboid$scopeSensitivity(CallbackInfo ci) {
        double k = GunClient.sensitivity();
        if (k != 1.0) {
            cursorDeltaX *= k;
            cursorDeltaY *= k;
        }
    }
}
