package com.example.zomboidmod.clothing;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Клиент одежды: приём надетого, отрисовка на игроках, цвет иконок, окно одежды (O). */
public final class ClothingClient {
    private ClothingClient() {
    }

    private static final Map<Integer, List<ItemStack>> PENDING = new HashMap<>();
    public static KeyBinding key;

    public static void init() {
        key = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.zomboidmod.clothes", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, "category.zomboidmod"));
        ClientPlayNetworking.registerGlobalReceiver(ClothesPayloads.Sync.ID, (pl, ctx) -> apply(ctx.client(), pl));
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> PENDING.clear());
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, ctx) -> {
            if (renderer instanceof PlayerEntityRenderer pr) helper.register(new ClothingRenderer(pr));
        });
        List<Item> tinted = new ArrayList<>();
        for (ClothingItem ci : ClothingItem.ALL) if (ci.def.tinted()) tinted.add(ci);
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> tintIndex == 0 ? 0xFF000000 | ClothingStack.tint(stack) : 0xFFFFFFFF,
                tinted.toArray(new Item[0]));
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            while (key.wasPressed()) {
                if (c.player != null && c.currentScreen == null) c.setScreen(new ClothingScreen());
            }
        });
    }

    private static void apply(MinecraftClient c, ClothesPayloads.Sync pl) {
        if (c.world == null) return;
        Entity e = c.world.getEntityById(pl.entityId());
        if (e instanceof PlayerEntity p) set(p, pl.stacks());
        else PENDING.put(pl.entityId(), pl.stacks());
    }

    public static void applyPending(PlayerEntity p) {
        if (PENDING.isEmpty()) return;
        List<ItemStack> l = PENDING.remove(p.getId());
        if (l != null) set(p, l);
    }

    private static void set(PlayerEntity p, List<ItemStack> l) {
        ItemStack[] w = Clothes.get(p);
        for (int i = 0; i < w.length; i++) w[i] = i < l.size() ? l.get(i) : ItemStack.EMPTY;
    }

    public static void send(int action, int slot, int part, int arg) {
        ClientPlayNetworking.send(new ClothesPayloads.Action(action, slot, part, arg));
    }
}
