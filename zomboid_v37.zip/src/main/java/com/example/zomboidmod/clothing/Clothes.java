package com.example.zomboidmod.clothing;

import com.example.zomboidmod.BodyPart;
import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.Survival;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.EntityTrackingEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.GameRules;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Одежда как в Project Zomboid: слои по частям тела, защита от укусов и царапин (рвётся, когда зомби бьёт),
 * тепло, ветер и влага, штрафы к бегу и ударам, кровь и грязь (грязная одежда над раной — заражение).
 */
public final class Clothes {
    private Clothes() {
    }

    // ===================== хранение =====================
    public static ItemStack[] emptyArray() {
        ItemStack[] a = new ItemStack[ClothingSlot.N];
        java.util.Arrays.fill(a, ItemStack.EMPTY);
        return a;
    }

    public static ItemStack[] get(PlayerEntity p) {
        return ((ClothingHolder) p).zomboid$clothes();
    }

    public static ItemStack worn(PlayerEntity p, ClothingSlot s) {
        return get(p)[s.ordinal()];
    }

    public static void save(PlayerEntity p, NbtCompound nbt) {
        NbtList l = new NbtList();
        ItemStack[] w = get(p);
        for (int i = 0; i < w.length; i++) {
            if (w[i].isEmpty()) continue;
            NbtCompound c = new NbtCompound();
            c.putByte("slot", (byte) i);
            c.put("item", w[i].encode(p.getRegistryManager()));
            l.add(c);
        }
        nbt.put("zomboid_clothes", l);
    }

    public static void load(PlayerEntity p, NbtCompound nbt) {
        ItemStack[] w = get(p);
        java.util.Arrays.fill(w, ItemStack.EMPTY);
        NbtList l = nbt.getList("zomboid_clothes", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < l.size(); i++) {
            NbtCompound c = l.getCompound(i);
            int slot = c.getByte("slot");
            if (slot < 0 || slot >= w.length) continue;
            w[slot] = ItemStack.fromNbt(p.getRegistryManager(), c.get("item")).orElse(ItemStack.EMPTY);
        }
    }

    // ===================== регистрация =====================
    public static void register() {
        for (ClothingDef d : ClothingCatalog.DEFS)
            Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, d.id()), new ClothingItem(d));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> {
            for (ClothingItem it : ClothingItem.ALL) e.add(it);
        });
        Tailoring.registerItems();

        PayloadTypeRegistry.playS2C().register(ClothesPayloads.Sync.ID, ClothesPayloads.Sync.CODEC);
        PayloadTypeRegistry.playC2S().register(ClothesPayloads.Action.ID, ClothesPayloads.Action.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ClothesPayloads.Action.ID,
                (pl, ctx) -> ctx.server().execute(() -> Tailoring.handle(ctx.player(), pl)));

        ServerPlayConnectionEvents.JOIN.register((h, sender, server) -> markDirty(h.getPlayer()));
        ServerPlayConnectionEvents.DISCONNECT.register((h, server) -> DIRTY.remove(h.getPlayer().getUuid()));
        EntityTrackingEvents.START_TRACKING.register((entity, player) -> {
            if (entity instanceof ServerPlayerEntity other) ServerPlayNetworking.send(player, payload(other));
        });
        ServerPlayerEvents.COPY_FROM.register((oldP, newP, alive) -> {
            if (alive || newP.getServerWorld().getGameRules().getBoolean(GameRules.KEEP_INVENTORY)) {
                ItemStack[] a = get(oldP), b = get(newP);
                for (int i = 0; i < a.length; i++) b[i] = a[i];
            }
            markDirty(newP);
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldP, newP, alive) -> markDirty(newP));
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayerEntity p && !p.getServerWorld().getGameRules().getBoolean(GameRules.KEEP_INVENTORY)) {
                ItemStack[] w = get(p);
                for (int i = 0; i < w.length; i++) {
                    if (!w[i].isEmpty()) p.dropItem(w[i], true, false);
                    w[i] = ItemStack.EMPTY;
                }
                markDirty(p);
            }
        });
        // кровь на одежде: бьёшь зомби вплотную — брызги на рукава и грудь
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClient && player instanceof ServerPlayerEntity sp && entity instanceof ZombieEntity) splash(sp, 0.012f);
            return ActionResult.PASS;
        });
        ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((world, killer, killed) -> {
            if (killer instanceof ServerPlayerEntity sp && killed instanceof PzZombieEntity && sp.squaredDistanceTo(killed) < 9) splash(sp, 0.04f);
        });
        ServerTickEvents.END_SERVER_TICK.register(Clothes::tick);
    }

    // ===================== надеть / снять =====================
    /** Слоты, которые придётся освободить, чтобы надеть вещь. */
    private static List<Integer> conflicts(ItemStack[] w, ClothingDef d) {
        List<Integer> out = new ArrayList<>();
        for (int i = 0; i < w.length; i++) {
            ClothingDef o = ClothingStack.def(w[i]);
            if (o == null) continue;
            ClothingSlot s = ClothingSlot.values()[i];
            if (s == d.slot() || d.blocks(s) || o.blocks(d.slot())) out.add(i);
        }
        return out;
    }

    public static void wear(ServerPlayerEntity p, Hand hand) {
        ItemStack held = p.getStackInHand(hand);
        ClothingDef d = ClothingStack.def(held);
        if (d == null) return;
        ItemStack[] w = get(p);
        ItemStack one = held.copyWithCount(1);
        held.decrement(1);
        for (int i : conflicts(w, d)) {
            ItemStack old = w[i];
            w[i] = ItemStack.EMPTY;
            if (!p.getInventory().insertStack(old)) p.dropItem(old, false);
        }
        w[d.slot().ordinal()] = one;
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.ITEM_ARMOR_EQUIP_LEATHER.value(), SoundCategory.PLAYERS, 0.8f, 1.1f);
        p.sendMessage(Text.literal("Надето: " + d.title()).formatted(Formatting.GRAY), true);
        markDirty(p);
    }

    public static void takeOff(ServerPlayerEntity p, int slot) {
        ItemStack[] w = get(p);
        if (slot < 0 || slot >= w.length || w[slot].isEmpty()) return;
        ItemStack old = w[slot];
        w[slot] = ItemStack.EMPTY;
        if (!p.getInventory().insertStack(old)) p.dropItem(old, false);
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.ITEM_ARMOR_EQUIP_LEATHER.value(), SoundCategory.PLAYERS, 0.6f, 0.9f);
        markDirty(p);
    }

    // ===================== синхронизация =====================
    private static final Set<UUID> DIRTY = new HashSet<>();

    public static void markDirty(ServerPlayerEntity p) {
        DIRTY.add(p.getUuid());
    }

    static ClothesPayloads.Sync payload(ServerPlayerEntity p) {
        List<ItemStack> l = new ArrayList<>();
        for (ItemStack s : get(p)) l.add(s.copy());
        return new ClothesPayloads.Sync(p.getId(), l);
    }

    private static void flush(MinecraftServer server) {
        if (DIRTY.isEmpty()) return;
        for (UUID id : DIRTY) {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(id);
            if (p == null) continue;
            ClothesPayloads.Sync pl = payload(p);
            ServerPlayNetworking.send(p, pl);
            for (ServerPlayerEntity o : PlayerLookup.tracking(p)) if (o != p) ServerPlayNetworking.send(o, pl);
        }
        DIRTY.clear();
    }

    // ===================== защита =====================
    /** Суммарная защита части тела: {царапины, укусы, пули}, не больше 100. */
    public static int[] defense(PlayerEntity p, BodyPart part) {
        int sc = 0, bi = 0, bu = 0;
        for (ItemStack s : get(p)) {
            ClothingDef d = ClothingStack.def(s);
            if (d == null) continue;
            int[] df = ClothingStack.defense(d, ClothingStack.read(s), part);
            sc += df[0];
            bi += df[1];
            bu += df[2];
        }
        return new int[]{Math.min(100, sc), Math.min(100, bi), Math.min(100, bu)};
    }

    /** Самый верхний целый слой над частью тела (его и рвёт зомби). */
    private static ItemStack outer(ServerPlayerEntity p, BodyPart part) {
        ItemStack best = ItemStack.EMPTY;
        float dil = -1;
        for (ItemStack s : get(p)) {
            ClothingDef d = ClothingStack.def(s);
            if (d == null || !d.covers(part) || !d.canTear()) continue;
            if (ClothingStack.hole(ClothingStack.read(s), part)) continue;
            if (d.dilation() > dil) {
                dil = d.dilation();
                best = s;
            }
        }
        return best;
    }

    /** Зомби бьёт по части тела: одежда может спасти (и порваться). true — раны не будет. */
    public static boolean blockAttack(ServerPlayerEntity p, BodyPart part, boolean bite, Random r) {
        int[] df = defense(p, part);
        int def = bite ? df[1] : df[0];
        boolean blocked = def > 0 && r.nextInt(100) < def;
        ItemStack out = outer(p, part);
        if (blocked) {
            if (!out.isEmpty() && r.nextFloat() < 0.35f) tear(p, out, part);
            p.sendMessage(Text.literal("Одежда спасла от " + (bite ? "укуса" : "царапины") + " (" + part.title.toLowerCase() + ")")
                    .formatted(Formatting.GREEN), true);
        } else {
            if (!out.isEmpty() && r.nextFloat() < 0.75f) tear(p, out, part);
            bloodOn(p, part, 0.25f);
        }
        markDirty(p);
        return blocked;
    }

    /** Пуля: бронежилет и каска останавливают её на своей части тела. */
    public static boolean blockBullet(ServerPlayerEntity p, BodyPart part, Random r) {
        int bu = defense(p, part)[2];
        if (bu > 0 && r.nextInt(100) < bu) {
            p.sendMessage(Text.literal("Пулю остановил бронежилет").formatted(Formatting.GREEN), true);
            return true;
        }
        bloodOn(p, part, 0.3f);
        return false;
    }

    private static void tear(ServerPlayerEntity p, ItemStack s, BodyPart part) {
        ClothingDef d = ClothingStack.def(s);
        if (d == null) return;
        NbtCompound n = ClothingStack.read(s);
        int pat = ClothingStack.patch(n, part);
        if (pat != 0) {                          // заплатка приняла удар на себя
            ClothingStack.setPatch(s, part, 0);
            if (ClothingStack.patchOverHole(pat)) ClothingStack.setHole(s, part, true);
        } else ClothingStack.setHole(s, part, true);
        p.sendMessage(Text.literal("Порвано: " + d.title().toLowerCase() + " (" + part.title.toLowerCase() + ")").formatted(Formatting.RED), false);
    }

    public static void bloodOn(ServerPlayerEntity p, BodyPart part, float v) {
        for (ItemStack s : get(p)) {
            ClothingDef d = ClothingStack.def(s);
            if (d != null && d.covers(part)) ClothingStack.addBlood(s, v);
        }
        markDirty(p);
    }

    /** Брызги крови на грудь, рукава и перчатки. */
    private static void splash(ServerPlayerEntity p, float v) {
        for (ItemStack s : get(p)) {
            ClothingDef d = ClothingStack.def(s);
            if (d == null) continue;
            if (d.covers(BodyPart.UPPER_TORSO) || d.covers(BodyPart.R_FOREARM) || d.covers(BodyPart.R_HAND)) ClothingStack.addBlood(s, v);
        }
        markDirty(p);
    }

    /** Насколько грязная и окровавленная одежда над раной ускоряет заражение (x1..x2.5). */
    public static double infectionMult(ServerPlayerEntity p, BodyPart part) {
        float v = 0f;
        for (ItemStack s : get(p)) {
            ClothingDef d = ClothingStack.def(s);
            if (d == null || !d.covers(part)) continue;
            NbtCompound n = ClothingStack.read(s);
            v = Math.max(v, ClothingStack.blood(n) * 0.6f + ClothingStack.dirt(n) * 0.8f);
        }
        return 1.0 + 1.5 * Math.min(1f, v);
    }

    // ===================== погода =====================
    private static final float[] AREA = new float[BodyPart.values().length];

    static {
        float[] a = {0.08f, 0.04f, 0.18f, 0.12f, 0.05f, 0.03f, 0.03f, 0.025f, 0.025f, 0.02f, 0.02f, 0.045f, 0.045f, 0.035f, 0.035f, 0.025f, 0.025f};
        float s = 0;
        for (float v : a) s += v;
        for (int i = 0; i < a.length && i < AREA.length; i++) AREA[i] = a[i] / s;
    }

    /** {утепление, ветрозащита, влагозащита} 0..1 по всему телу с учётом дыр. */
    public static float[] climate(PlayerEntity p) {
        float[] out = new float[3];
        BodyPart[] parts = BodyPart.values();
        ItemStack[] w = get(p);
        for (int i = 0; i < parts.length; i++) {
            float ins = 1, wind = 1, wat = 1;
            for (ItemStack s : w) {
                ClothingDef d = ClothingStack.def(s);
                if (d == null || !d.covers(parts[i])) continue;
                if (ClothingStack.hole(ClothingStack.read(s), parts[i])) continue;
                ins *= 1f - 0.9f * d.insulation();
                wind *= 1f - 0.9f * d.wind();
                wat *= 1f - 0.95f * d.water();
            }
            out[0] += (1 - ins) * AREA[i];
            out[1] += (1 - wind) * AREA[i];
            out[2] += (1 - wat) * AREA[i];
        }
        return out;
    }

    /** Насколько игрок заметен: маскхалат прячет, светоотражающий жилет — выдаёт. */
    public static double visibility(PlayerEntity p) {
        double v = 1;
        for (ItemStack s : get(p)) {
            ClothingDef d = ClothingStack.def(s);
            if (d == null || d.stealth() == 0) continue;
            v *= d.stealth() > 0 ? 1 - d.stealth() : 1 - d.stealth();
        }
        return Math.max(0.3, Math.min(1.6, v));
    }

    public static float wornWeight(PlayerEntity p) {
        float w = 0;
        for (ItemStack s : get(p)) {
            ClothingDef d = ClothingStack.def(s);
            if (d != null) w += d.weight();
        }
        return w;
    }

    // ===================== каждый тик =====================
    private static final Identifier RUN = Identifier.of(ZomboidMod.MOD_ID, "clothes_run");
    private static final Identifier HIT = Identifier.of(ZomboidMod.MOD_ID, "clothes_combat");

    private static void setMod(ServerPlayerEntity p, RegistryEntry<EntityAttribute> attr, Identifier id, double value) {
        EntityAttributeInstance inst = p.getAttributeInstance(attr);
        if (inst == null) return;
        EntityAttributeModifier cur = inst.getModifier(id);
        if (cur != null && Math.abs(cur.value() - value) < 1e-4) return;
        inst.removeModifier(id);
        if (Math.abs(value) > 1e-4)
            inst.addTemporaryModifier(new EntityAttributeModifier(id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
    }

    private static void tick(MinecraftServer server) {
        flush(server);
        if (server.getTicks() % 20 != 0) return;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p.isSpectator()) continue;
            ItemStack[] w = get(p);
            float run = 1, hit = 1, worst = 0;
            boolean any = false;
            boolean rain = p.getWorld().hasRain(p.getBlockPos().up()) && p.getWorld().isSkyVisible(p.getBlockPos().up());
            boolean moving = p.getVelocity().horizontalLengthSquared() > 0.003;
            boolean crawl = p.getPose() == EntityPose.SWIMMING && !p.isTouchingWater();
            for (ItemStack s : w) {
                ClothingDef d = ClothingStack.def(s);
                if (d == null) continue;
                any = true;
                run *= d.run();
                hit *= d.combat();
                float dirt = 0.00002f;
                if (rain && moving && (d.slot() == ClothingSlot.SHOES || d.slot() == ClothingSlot.PANTS)) dirt += 0.0008f;
                if (crawl && (d.covers(BodyPart.UPPER_TORSO) || d.covers(BodyPart.L_THIGH))) dirt += 0.004f;
                if (!p.isCreative()) ClothingStack.addDirt(s, dirt);
                if (d.covers(BodyPart.UPPER_TORSO)) {
                    NbtCompound n = ClothingStack.read(s);
                    worst = Math.max(worst, Math.max(ClothingStack.blood(n), ClothingStack.dirt(n)));
                }
            }
            setMod(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, RUN, (run - 1) * (p.isSprinting() ? 1.0 : 0.5));
            setMod(p, EntityAttributes.GENERIC_ATTACK_SPEED, HIT, hit - 1);
            // грязная, окровавленная одежда портит настроение
            if (worst > 0.55f && !p.isCreative()) {
                Mood m = Survival.mood(p);
                m.unhappy = Math.min(100f, m.unhappy + (worst - 0.5f) * 0.06f);
            }
            if (any && server.getTicks() % 600 == 0) markDirty(p);     // кровь и грязь видны другим
        }
    }

    // ===================== стирка =====================
    /** Постирать всё надетое (мыло отмывает начисто, без мыла — наполовину). wetten — промокнуть. */
    public static void washAll(ServerPlayerEntity p, boolean soap, boolean wetten) {
        boolean any = false;
        for (ItemStack s : get(p)) {
            if (ClothingStack.def(s) == null) continue;
            ClothingStack.wash(s, soap ? 0f : 0.5f);
            any = true;
        }
        if (wetten) {
            Mood m = Survival.mood(p);
            m.wet = Math.max(m.wet, 60f);
        }
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.PLAYERS, 0.7f, 1.2f);
        p.sendMessage(Text.literal(any ? (soap ? "Одежда отстирана дочиста" : "Одежда отстирана наполовину (нужно мыло)") : "На вас нечего стирать")
                .formatted(Formatting.GRAY), true);
        markDirty(p);
    }

    public static void washHeld(ServerPlayerEntity p, ItemStack s) {
        boolean soap = p.getInventory().contains(new ItemStack(Tailoring.SOAP));
        if (soap) Tailoring.useSoap(p);
        ClothingStack.wash(s, soap ? 0f : 0.5f);
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.PLAYERS, 0.6f, 1.3f);
        p.sendMessage(Text.literal(soap ? "Постирано с мылом" : "Постирано в холодной воде (без мыла хуже)").formatted(Formatting.GRAY), true);
    }
}
