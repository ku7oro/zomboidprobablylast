package com.example.zomboidmod.clothing;

import net.minecraft.item.ItemStack;

/** Игрок носит одежду в своих слотах (добавлено миксином в PlayerEntity). */
public interface ClothingHolder {
    ItemStack[] zomboid$clothes();
}
