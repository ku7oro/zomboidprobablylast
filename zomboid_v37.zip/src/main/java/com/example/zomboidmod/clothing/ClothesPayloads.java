package com.example.zomboidmod.clothing;

import com.example.zomboidmod.ZomboidMod;
import net.minecraft.item.ItemStack;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.List;

/** Сеть: сервер рассылает надетое (себе и тем, кто видит игрока), клиент шлёт действия из окна одежды. */
public final class ClothesPayloads {
    private ClothesPayloads() {
    }

    public record Sync(int entityId, List<ItemStack> stacks) implements CustomPayload {
        public static final Id<Sync> ID = new Id<>(Identifier.of(ZomboidMod.MOD_ID, "clothes"));
        public static final PacketCodec<RegistryByteBuf, Sync> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, Sync::entityId,
                ItemStack.OPTIONAL_PACKET_CODEC.collect(PacketCodecs.toList()), Sync::stacks,
                Sync::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public record Action(int action, int slot, int part, int arg) implements CustomPayload {
        public static final Id<Action> ID = new Id<>(Identifier.of(ZomboidMod.MOD_ID, "clothes_action"));
        public static final PacketCodec<RegistryByteBuf, Action> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, Action::action, PacketCodecs.VAR_INT, Action::slot,
                PacketCodecs.VAR_INT, Action::part, PacketCodecs.VAR_INT, Action::arg, Action::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }
}
