package com.example.zomboidmod.clothing;

import com.example.zomboidmod.BodyPart;
import com.example.zomboidmod.GuiUtil;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.ZomboidClient;
import com.example.zomboidmod.ZomboidMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Окно одежды (клавиша O), как «Осмотр» и «Защита» в PZ: что надето по слоям, состояние каждой части вещи,
 * заплатки и укрепление, распарывание на лоскуты, таблица защиты тела и рецепты шитья.
 */
public class ClothingScreen extends Screen {
    private int tab = 0;               // 0 Надето, 1 Защита, 2 Шитьё
    private int selected = -1;         // выбранный слот
    private int material = 1;          // материал заплатки: 1 ткань, 2 джинса, 3 кожа
    private int scroll = 0;
    private final List<Btn> btns = new ArrayList<>();

    private record Btn(int x, int y, int w, int h, Runnable action) {
        boolean in(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    public ClothingScreen() {
        super(Text.literal("Одежда"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int[] window() {
        int w = Math.min(this.width - 10, 440), h = Math.min(this.height - 10, 248);
        return new int[]{(this.width - w) / 2, (this.height - h) / 2, w, h};
    }

    private void button(DrawContext ctx, int mx, int my, int x, int y, int w, String label, boolean enabled, Runnable action) {
        boolean over = enabled && mx >= x && mx < x + w && my >= y && my < y + 11;
        ctx.fill(x - 1, y - 1, x + w + 1, y + 12, enabled ? 0xFF7A7A72 : 0xFF3A3A3A);
        ctx.fill(x, y, x + w, y + 11, !enabled ? 0xFF262626 : (over ? 0xFF4A5A3A : 0xFF33402A));
        int tw = this.textRenderer.getWidth(label);
        if (tw > w - 2) GuiUtil.smallText(ctx, this.textRenderer, label, x + 2, y + 3, enabled ? 0xFFFFFF : 0x777777);
        else ctx.drawText(this.textRenderer, label, x + (w - tw) / 2, y + 2, enabled ? 0xFFFFFF : 0x777777, false);
        if (enabled) btns.add(new Btn(x, y, w, 11, action));
    }

    private int tabBtn(DrawContext ctx, int mx, int my, int x, int y, String t, int id) {
        int w = this.textRenderer.getWidth(t) + 10;
        boolean on = tab == id;
        ctx.fill(x, y, x + w, y + 13, on ? 0xFF3C3C3C : 0xFF262626);
        ctx.drawText(this.textRenderer, t, x + 5, y + 3, on ? 0xFFD54A : 0xBBBBBB, false);
        btns.add(new Btn(x, y, w, 13, () -> {
            tab = id;
            scroll = 0;
        }));
        return x + w + 2;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null) return;
        btns.clear();
        int[] wn = window();
        int wx = wn[0], wy = wn[1], ww = wn[2], wh = wn[3];
        ctx.fill(wx - 1, wy - 1, wx + ww + 1, wy + wh + 1, 0xFF6E6E6E);
        ctx.fill(wx, wy, wx + ww, wy + wh, 0xF0121212);
        ctx.fill(wx, wy, wx + ww, wy + 17, 0xFF262626);
        int tx = wx + 4;
        tx = tabBtn(ctx, mx, my, tx, wy + 2, "Надето", 0);
        tx = tabBtn(ctx, mx, my, tx, wy + 2, "Защита", 1);
        tabBtn(ctx, mx, my, tx, wy + 2, "Шитьё", 2);
        String sk = "Шитьё: " + ZomboidClient.skillLevel(PzSkill.TAILORING) + " ур.";
        ctx.drawText(this.textRenderer, sk, wx + ww - 6 - this.textRenderer.getWidth(sk), wy + 5, 0xAAAAAA, false);
        if (tab == 0) renderWorn(ctx, mx, my, p, wx, wy + 20, ww, wh - 20);
        else if (tab == 1) renderProtection(ctx, p, wx, wy + 20, ww, wh - 20);
        else renderSewing(ctx, mx, my, p, wx, wy + 20, ww, wh - 20);
    }

    // ===================== Надето =====================
    private void renderWorn(DrawContext ctx, int mx, int my, ClientPlayerEntity p, int x, int y, int w, int h) {
        ItemStack[] worn = Clothes.get(p);
        int lw = 150;
        int rowH = Math.max(10, Math.min(13, (h - 4) / ClothingSlot.N));
        for (ClothingSlot s : ClothingSlot.values()) {
            int i = s.ordinal();
            int ry = y + 2 + i * rowH;
            ItemStack st = worn[i];
            boolean over = mx >= x + 4 && mx < x + 4 + lw && my >= ry && my < ry + rowH;
            if (i == selected) ctx.fill(x + 4, ry, x + 4 + lw, ry + rowH, 0xFF3C3C3C);
            else if (over) ctx.fill(x + 4, ry, x + 4 + lw, ry + rowH, 0xFF242424);
            GuiUtil.smallText(ctx, this.textRenderer, s.title, x + 6, ry + 2, 0x888888);
            ClothingDef d = ClothingStack.def(st);
            if (d != null) {
                if (d.tinted()) ctx.fill(x + 56, ry + 2, x + 60, ry + rowH - 2, 0xFF000000 | ClothingStack.tint(st));
                String n = d.title();
                while (this.textRenderer.getWidth(n) > lw - 62 && n.length() > 3) n = n.substring(0, n.length() - 2);
                ctx.drawText(this.textRenderer, n, x + 63, ry + Math.max(1, (rowH - 8) / 2), 0xE8E4D8, false);
                NbtCompound nb = ClothingStack.read(st);
                if (ClothingStack.holes(nb) != 0) ctx.fill(x + lw, ry + 3, x + lw + 3, ry + rowH - 3, 0xFFD04040);
            } else GuiUtil.smallText(ctx, this.textRenderer, "-", x + 63, ry + 2, 0x555555);
            final int idx = i;
            btns.add(new Btn(x + 4, ry, lw, rowH, () -> {
                selected = selected == idx ? -1 : idx;
                scroll = 0;
            }));
        }
        // персонаж и общая защита от погоды
        int cx = x + lw + 10, cw = 86;
        ctx.fill(cx, y + 2, cx + cw, y + 122, 0xFF1A1A1A);
        InventoryScreen.drawEntity(ctx, cx + 2, y + 4, cx + cw - 2, y + 120, 44, 0.0625f, mx, my, p);
        float[] cl = Clothes.climate(p);
        int ty = y + 128;
        GuiUtil.smallText(ctx, this.textRenderer, "Тепло: " + Math.round(cl[0] * 100) + "%", cx, ty, 0xE0A060);
        GuiUtil.smallText(ctx, this.textRenderer, "Ветер: " + Math.round(cl[1] * 100) + "%", cx, ty + 8, 0x9AC0E0);
        GuiUtil.smallText(ctx, this.textRenderer, "Влага: " + Math.round(cl[2] * 100) + "%", cx, ty + 16, 0x80A0E0);
        GuiUtil.smallText(ctx, this.textRenderer, String.format("Вес: %.1f", Clothes.wornWeight(p)), cx, ty + 24, 0xCCCCCC);
        double v = Clothes.visibility(p);
        if (Math.abs(v - 1) > 0.02)
            GuiUtil.smallText(ctx, this.textRenderer, v < 1 ? "Маскировка: " + Math.round((1 - v) * 100) + "%" : "Заметность: +" + Math.round((v - 1) * 100) + "%",
                    cx, ty + 32, v < 1 ? 0x80D080 : 0xE08060);
        GuiUtil.smallText(ctx, this.textRenderer, "ПКМ вещью - надеть", cx, y + h - 18, 0x777777);
        GuiUtil.smallText(ctx, this.textRenderer, "Shift+ПКМ по воде - стирка", cx, y + h - 10, 0x777777);
        // выбранная вещь
        int rx = cx + cw + 8, rw = x + w - rx - 6;
        if (selected < 0 || ClothingStack.def(worn[selected]) == null) {
            GuiUtil.smallText(ctx, this.textRenderer, "Выберите вещь слева,", rx, y + 6, 0x888888);
            GuiUtil.smallText(ctx, this.textRenderer, "чтобы осмотреть и залатать её.", rx, y + 14, 0x888888);
            return;
        }
        ItemStack st = worn[selected];
        ClothingDef d = ClothingStack.def(st);
        NbtCompound n = ClothingStack.read(st);
        int yy = y + 2;
        ctx.drawText(this.textRenderer, d.title(), rx, yy, 0xFFD54A, false);
        yy += 11;
        String prot = "Укус " + d.bite() + "%  Царап. " + d.scratch() + "%" + (d.bullet() > 0 ? "  Пули " + d.bullet() + "%" : "");
        GuiUtil.smallText(ctx, this.textRenderer, prot, rx, yy, 0x9AD08A);
        yy += 8;
        GuiUtil.smallText(ctx, this.textRenderer, String.format("Тепло %d%%  Ветер %d%%  Влага %d%%", Math.round(d.insulation() * 100), Math.round(d.wind() * 100),
                Math.round(d.water() * 100)), rx, yy, 0x9AC0E0);
        yy += 8;
        GuiUtil.smallText(ctx, this.textRenderer, String.format("Кровь %d%%  Грязь %d%%  Ткань: %s", Math.round(ClothingStack.blood(n) * 100),
                Math.round(ClothingStack.dirt(n) * 100), d.fabric().title), rx, yy, 0xC0A090);
        yy += 10;
        final int slot = selected;
        button(ctx, mx, my, rx, yy, 50, "Снять", true, () -> ClothingClient.send(Tailoring.A_TAKEOFF, slot, 0, 0));
        button(ctx, mx, my, rx + 54, yy, 70, "Распороть", d.fabric() != Fabric.NONE, () -> {
            ClothingClient.send(Tailoring.A_RIP, slot, 0, 0);
            selected = -1;
        });
        yy += 15;
        if (!d.patchable()) {
            GuiUtil.smallText(ctx, this.textRenderer, d.canTear() ? "Без ткани: заплатку не пришить" : "Не рвётся и не чинится", rx, yy, 0x888888);
            return;
        }
        // материал заплатки
        String[] mats = {"Ткань", "Джинса", "Кожа"};
        int mx0 = rx;
        for (int m = 1; m <= 3; m++) {
            int cnt = Tailoring.count(p, Tailoring.stripOf(m));
            String t = mats[m - 1] + " " + cnt;
            int tw = this.textRenderer.getWidth(t) * 3 / 4 + 6;
            boolean on = material == m;
            ctx.fill(mx0, yy, mx0 + tw, yy + 9, on ? 0xFF5A4A2A : 0xFF262626);
            GuiUtil.smallText(ctx, this.textRenderer, t, mx0 + 3, yy + 2, cnt > 0 ? 0xFFFFFF : 0x777777);
            final int mm = m;
            btns.add(new Btn(mx0, yy, tw, 9, () -> material = mm));
            mx0 += tw + 3;
        }
        yy += 11;
        boolean needle = Tailoring.has(p, Tailoring.NEEDLE);
        int thread = Tailoring.threadLeft(p);
        GuiUtil.smallText(ctx, this.textRenderer, (needle ? "Игла есть" : "Нет иглы") + ", ниток: " + thread, rx, yy, needle && thread > 0 ? 0x9AD08A : 0xD08A8A);
        yy += 9;
        int lv = ZomboidClient.skillLevel(PzSkill.TAILORING);
        int[] b = Tailoring.patchBonus(material, lv);
        GuiUtil.smallText(ctx, this.textRenderer, "Заплатка: +" + b[0] + "% царап., +" + b[1] + "% укус", rx, yy, 0xAAAAAA);
        yy += 10;
        // части тела под вещью
        List<BodyPart> parts = new ArrayList<>();
        for (BodyPart bp : BodyPart.values()) if (d.covers(bp)) parts.add(bp);
        int rows = Math.max(1, (y + h - yy - 2) / 11);
        scroll = Math.max(0, Math.min(scroll, Math.max(0, parts.size() - rows)));
        for (int k = 0; k < Math.min(rows, parts.size() - scroll); k++) {
            BodyPart bp = parts.get(k + scroll);
            int ry = yy + k * 11;
            boolean hole = ClothingStack.hole(n, bp);
            int pat = ClothingStack.patch(n, bp);
            String name = bp.title;
            if (name.length() > 16) name = name.substring(0, 15) + ".";
            GuiUtil.smallText(ctx, this.textRenderer, name, rx, ry + 2, 0xCCCCCC);
            String state;
            int col;
            if (pat != 0) {
                state = Fabric.ofPatch(ClothingStack.patchMat(pat)).title + " +" + ClothingStack.patchScratch(pat) + "/" + ClothingStack.patchBite(pat);
                col = 0xE0C060;
            } else if (hole) {
                state = "ДЫРА";
                col = 0xE05050;
            } else {
                state = "цело";
                col = 0x8AC080;
            }
            GuiUtil.smallText(ctx, this.textRenderer, state, rx + 66, ry + 2, col);
            final int pi = bp.ordinal();
            if (pat != 0) button(ctx, mx, my, rx + rw - 52, ry, 52, "Спороть", needle, () -> ClothingClient.send(Tailoring.A_UNPATCH, slot, pi, 0));
            else button(ctx, mx, my, rx + rw - 52, ry, 52, hole ? "Залатать" : "Укрепить", needle && thread > 0,
                    () -> ClothingClient.send(Tailoring.A_PATCH, slot, pi, material));
        }
        if (parts.size() > rows) GuiUtil.smallText(ctx, this.textRenderer, "колесо мыши - ещё", rx, y + h - 8, 0x666666);
    }

    // ===================== Защита =====================
    private void renderProtection(DrawContext ctx, ClientPlayerEntity p, int x, int y, int w, int h) {
        int[] cols = {x + 8, x + 130, x + 180, x + 240, x + 290};
        String[] head = {"Часть тела", "Укус", "Царап.", "Пули", "Слоёв"};
        for (int i = 0; i < head.length; i++) ctx.drawText(this.textRenderer, head[i], cols[i], y + 2, 0xFFD54A, false);
        int ry = y + 14;
        int rowH = Math.max(8, Math.min(11, (h - 30) / BodyPart.values().length));
        for (BodyPart bp : BodyPart.values()) {
            int[] df = Clothes.defense(p, bp);
            int layers = 0;
            for (ItemStack s : Clothes.get(p)) {
                ClothingDef d = ClothingStack.def(s);
                if (d != null && d.covers(bp)) layers++;
            }
            GuiUtil.smallText(ctx, this.textRenderer, bp.title, cols[0], ry + 1, 0xDDDDDD);
            bar(ctx, cols[1], ry + 1, df[1], 0xFFC05050);
            bar(ctx, cols[2], ry + 1, df[0], 0xFFC0A050);
            bar(ctx, cols[3], ry + 1, df[2], 0xFF5080C0);
            GuiUtil.smallText(ctx, this.textRenderer, String.valueOf(layers), cols[4] + 8, ry + 1, 0xAAAAAA);
            ry += rowH;
        }
        GuiUtil.smallText(ctx, this.textRenderer, "Защита слоёв складывается (до 100%). Дыра снимает защиту вещи с этой части тела.", x + 8, y + h - 18, 0x888888);
        GuiUtil.smallText(ctx, this.textRenderer, "Укусы держит защита от укусов, царапины и рваные раны - защита от царапин.", x + 8, y + h - 10, 0x888888);
    }

    private void bar(DrawContext ctx, int x, int y, int v, int color) {
        ctx.fill(x, y, x + 40, y + 6, 0xFF2A2A2A);
        ctx.fill(x, y, x + Math.round(40 * v / 100f), y + 6, color);
        GuiUtil.smallText(ctx, this.textRenderer, v + "%", x + 43, y, 0xBBBBBB);
    }

    // ===================== Шитьё =====================
    private void renderSewing(DrawContext ctx, int mx, int my, ClientPlayerEntity p, int x, int y, int w, int h) {
        int lv = ZomboidClient.skillLevel(PzSkill.TAILORING);
        boolean needle = Tailoring.has(p, Tailoring.NEEDLE), sc = Tailoring.has(p, Tailoring.SCISSORS);
        GuiUtil.smallText(ctx, this.textRenderer, (needle ? "Игла: есть" : "Игла: нет") + "   Нитки: " + Tailoring.threadLeft(p) + "   Ножницы: " + (sc ? "есть" : "нет")
                        + "   Ткань " + Tailoring.count(p, ZomboidMod.RAG) + ", джинса " + Tailoring.count(p, Tailoring.DENIM_STRIPS) + ", кожа "
                        + Tailoring.count(p, Tailoring.LEATHER_STRIPS), x + 8, y + 2, 0xCCCCCC);
        int ry = y + 14;
        int rowH = 15;
        int rows = Math.max(1, (h - 40) / rowH);
        List<Tailoring.Recipe> rs = Tailoring.RECIPES;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, rs.size() - rows)));
        for (int k = 0; k < Math.min(rows, rs.size() - scroll); k++) {
            int idx = k + scroll;
            Tailoring.Recipe r = rs.get(idx);
            String miss = Tailoring.missing(p, r, lv);
            ctx.fill(x + 6, ry, x + w - 6, ry + rowH - 2, 0xFF1E1E1E);
            ctx.drawText(this.textRenderer, r.title(), x + 10, ry + 3, miss == null ? 0xFFFFFF : 0x9A9A9A, false);
            StringBuilder need = new StringBuilder();
            for (int i = 0; i + 1 < r.input().length; i += 2) {
                String id = (String) r.input()[i];
                String nm = id.equals("#wool") ? "шерсть" : net.minecraft.registry.Registries.ITEM.get(net.minecraft.util.Identifier.of(id)).getName().getString();
                need.append(r.input()[i + 1]).append(" ").append(nm.toLowerCase()).append(", ");
            }
            if (r.needle()) need.append("игла, ");
            if (r.thread() > 0) need.append("нитки x").append(r.thread()).append(", ");
            if (r.scissors()) need.append("ножницы, ");
            if (r.level() > 0) need.append("шитьё ").append(r.level());
            String ns = need.toString();
            if (ns.endsWith(", ")) ns = ns.substring(0, ns.length() - 2);
            GuiUtil.smallText(ctx, this.textRenderer, ns, x + 150, ry + 4, miss == null ? 0x9AD08A : 0xB08080);
            final int ri = idx;
            button(ctx, mx, my, x + w - 60, ry + 1, 50, "Сшить", miss == null, () -> ClothingClient.send(Tailoring.A_CRAFT, 0, 0, ri));
            ry += rowH;
        }
        ItemStack held = p.getMainHandStack();
        ClothingDef hd = ClothingStack.def(held);
        int by = y + h - 16;
        if (hd != null)
            button(ctx, mx, my, x + 8, by, 170, "Распороть в руке: " + hd.title(), hd.fabric() != Fabric.NONE, () -> ClothingClient.send(Tailoring.A_RIP, -1, 0, 0));
        else GuiUtil.smallText(ctx, this.textRenderer, "Возьмите вещь в руку, чтобы распороть её на лоскуты", x + 8, by + 2, 0x777777);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (Btn b : new ArrayList<>(btns)) {
            if (b.in(mx, my)) {
                b.action().run();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = Math.max(0, scroll - (int) Math.signum(v));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ClothingClient.key != null && ClothingClient.key.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
