package com.example.zomboidmod.clothing;

import com.example.zomboidmod.BodyPart;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Вещь одежды. ПКМ — надеть (снятое с того же места уходит в инвентарь), Shift+ПКМ по воде — постирать. */
public class ClothingItem extends Item {
    public static final List<ClothingItem> ALL = new ArrayList<>();
    private static final Map<String, ClothingItem> BY_ID = new HashMap<>();
    public final ClothingDef def;

    public ClothingItem(ClothingDef def) {
        super(new Item.Settings().maxCount(1));
        this.def = def;
        ALL.add(this);
        BY_ID.put(def.id(), this);
    }

    public static ClothingItem of(ClothingDef d) {
        return BY_ID.get(d.id());
    }

    public static ClothingItem byId(String id) {
        return BY_ID.get(id);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack st = user.getStackInHand(hand);
        if (user.isSneaking()) {
            BlockHitResult hit = raycast(world, user, RaycastContext.FluidHandling.SOURCE_ONLY);
            if (hit.getType() == HitResult.Type.BLOCK && world.getFluidState(hit.getBlockPos()).isIn(FluidTags.WATER)) {
                if (!world.isClient && user instanceof ServerPlayerEntity sp) Clothes.washHeld(sp, st);
                return TypedActionResult.success(st, world.isClient);
            }
        }
        if (!world.isClient && user instanceof ServerPlayerEntity sp) Clothes.wear(sp, hand);
        return TypedActionResult.success(st, world.isClient);
    }

    @Override
    public boolean isItemBarVisible(ItemStack stack) {
        return def.canTear() && ClothingStack.holes(ClothingStack.read(stack)) != 0;
    }

    @Override
    public int getItemBarStep(ItemStack stack) {
        return Math.round(13f * ClothingStack.intact(def, ClothingStack.read(stack)));
    }

    @Override
    public int getItemBarColor(ItemStack stack) {
        float f = ClothingStack.intact(def, ClothingStack.read(stack));
        return MathHelper.hsvToRgb(f / 3f, 1f, 1f);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        NbtCompound n = ClothingStack.read(stack);
        tooltip.add(Text.literal(def.slot().title + (def.fabric() != Fabric.NONE ? " · " + def.fabric().title : "")).formatted(Formatting.GRAY));
        if (def.bite() > 0 || def.scratch() > 0)
            tooltip.add(Text.literal("Защита: укус " + def.bite() + "%, царапины " + def.scratch() + "%" + (def.bullet() > 0 ? ", пули " + def.bullet() + "%" : ""))
                    .formatted(Formatting.DARK_GREEN));
        if (def.insulation() > 0 || def.wind() > 0 || def.water() > 0)
            tooltip.add(Text.literal(String.format("Тепло %d%%, ветер %d%%, влага %d%%", Math.round(def.insulation() * 100), Math.round(def.wind() * 100),
                    Math.round(def.water() * 100))).formatted(Formatting.DARK_AQUA));
        if (def.run() < 0.999f || def.combat() < 0.999f)
            tooltip.add(Text.literal(String.format("Бег x%.2f, удары x%.2f", def.run(), def.combat())).formatted(Formatting.GOLD));
        if (def.stealth() > 0) tooltip.add(Text.literal("Маскировка: зомби замечают позже").formatted(Formatting.DARK_GREEN));
        if (def.stealth() < 0) tooltip.add(Text.literal("Яркая: зомби замечают издалека").formatted(Formatting.RED));
        int holes = Integer.bitCount(ClothingStack.holes(n) & def.covers());
        int patches = 0;
        for (BodyPart p : BodyPart.values()) if (ClothingStack.patch(n, p) != 0) patches++;
        if (holes > 0) tooltip.add(Text.literal("Дыр: " + holes).formatted(Formatting.RED));
        if (patches > 0) tooltip.add(Text.literal("Заплаток: " + patches).formatted(Formatting.YELLOW));
        float b = ClothingStack.blood(n), d = ClothingStack.dirt(n);
        if (b > 0.05f) tooltip.add(Text.literal("В крови: " + Math.round(b * 100) + "%").formatted(Formatting.DARK_RED));
        if (d > 0.05f) tooltip.add(Text.literal("Грязь: " + Math.round(d * 100) + "%").formatted(Formatting.DARK_GRAY));
        tooltip.add(Text.literal("ПКМ - надеть, Shift+ПКМ по воде - постирать").formatted(Formatting.DARK_GRAY));
    }
}
