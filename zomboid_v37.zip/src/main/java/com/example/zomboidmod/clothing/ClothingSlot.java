package com.example.zomboidmod.clothing;

/**
 * Места на теле, как Body Location в PZ. dilation — насколько слой отстоит от тела при отрисовке:
 * майка у самой кожи, куртка поверх свитера, жилет поверх куртки. Порядок не менять — он в сохранениях.
 */
public enum ClothingSlot {
    HAT("Головной убор", 0.40f),
    MASK("Лицо", 0.26f),
    EYES("Очки", 0.30f),
    NECK("Шея", 0.35f),
    TANKTOP("Майка", 0.04f),
    TSHIRT("Футболка", 0.07f),
    SHIRT("Рубашка", 0.11f),
    SWEATER("Свитер", 0.16f),
    JACKET("Куртка", 0.23f),
    VEST("Жилет", 0.30f),
    ARMGUARD("Наручи", 0.30f),
    GLOVES("Перчатки", 0.33f),
    PANTS("Штаны", 0.09f),
    LEGGUARD("Поножи", 0.26f),
    SOCKS("Носки", 0.03f),
    SHOES("Обувь", 0.20f);

    public static final int N = values().length;
    public final String title;
    public final float dilation;

    ClothingSlot(String title, float dilation) {
        this.title = title;
        this.dilation = dilation;
    }

    public boolean head() {
        return this == HAT || this == MASK || this == EYES;
    }
}
