package com.example.zomboidmod.clothing;

import com.example.zomboidmod.BodyPart;
import com.example.zomboidmod.ZomboidMod;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Одежда на модели игрока: каждый слой — своя «раздутая» копия тела (майка у кожи, куртка поверх свитера),
 * основа тонируется цветом вещи, детали (пуговицы, молнии, нашивки) — нет. Поверх — кровь, грязь, дыры и заплатки
 * по частям тела. Головные уборы и маски с объёмом — отдельные 3D-модели.
 */
public final class ClothingRenderer extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
    public ClothingRenderer(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> ctx) {
        super(ctx);
    }

    private static final Identifier ATLAS = Identifier.of(ZomboidMod.MOD_ID, "textures/clothing/models3d.png");
    private static final Identifier HOLE = fx("fx_hole");
    private static final Identifier[] BLOOD = {fx("fx_blood_1"), fx("fx_blood_2"), fx("fx_blood_3")};
    private static final Identifier[] DIRT = {fx("fx_dirt_1"), fx("fx_dirt_2"), fx("fx_dirt_3")};
    private static final Identifier[] PATCH = {fx("fx_patch_c"), fx("fx_patch_c"), fx("fx_patch_d"), fx("fx_patch_l")};

    private static Identifier fx(String n) {
        return Identifier.of(ZomboidMod.MOD_ID, "textures/clothing/" + n + ".png");
    }

    // ===================== модели =====================
    public static final int HEAD = 1, BODY = 2, RARM = 4, LARM = 8, RLEG = 16, LLEG = 32, ALL = 63;
    private static final String[] LIMB = {"head", "body", "right_arm", "left_arm", "right_leg", "left_leg"};

    /** Тело одного слоя: 6 частей. */
    private static final class Layer {
        final ModelPart[] parts = new ModelPart[6];
    }

    /** Зоны (17 частей тела) для крови, дыр и заплат. */
    private static final class Zones {
        final ModelPart[] limbs = new ModelPart[6];
        final Map<String, ModelPart> zone = new HashMap<>();
    }

    private static final Map<Integer, Layer> LAYERS = new HashMap<>();
    private static final Map<Integer, Zones> ZONES = new HashMap<>();
    private static ModelPart m3d;

    private static int key(float d, boolean slim) {
        return Math.round(d * 1000) * 2 + (slim ? 1 : 0);
    }

    private static Layer layer(float d, boolean slim) {
        return LAYERS.computeIfAbsent(key(d, slim), k -> {
            ModelData md = new ModelData();
            ModelPartData r = md.getRoot();
            Dilation dl = new Dilation(d);
            r.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-4f, -8f, -4f, 8f, 8f, 8f, dl), ModelTransform.NONE);
            r.addChild("body", ModelPartBuilder.create().uv(16, 16).cuboid(-4f, 0f, -2f, 8f, 12f, 4f, dl), ModelTransform.NONE);
            r.addChild("right_arm", ModelPartBuilder.create().uv(40, 16).cuboid(slim ? -2.5f : -3f, -2f, -2f, 4f, 12f, 4f, dl),
                    ModelTransform.pivot(-5f, 2f, 0f));
            r.addChild("left_arm", ModelPartBuilder.create().uv(32, 48).cuboid(slim ? -1.5f : -1f, -2f, -2f, 4f, 12f, 4f, dl),
                    ModelTransform.pivot(5f, 2f, 0f));
            r.addChild("right_leg", ModelPartBuilder.create().uv(0, 16).cuboid(-2f, 0f, -2f, 4f, 12f, 4f, dl), ModelTransform.pivot(-1.9f, 12f, 0f));
            r.addChild("left_leg", ModelPartBuilder.create().uv(16, 48).cuboid(-2f, 0f, -2f, 4f, 12f, 4f, dl), ModelTransform.pivot(1.9f, 12f, 0f));
            ModelPart root = TexturedModelData.of(md, 64, 64).createModel();
            Layer l = new Layer();
            for (int i = 0; i < 6; i++) l.parts[i] = root.getChild(LIMB[i]);
            return l;
        });
    }

    private static Zones zones(float d, boolean slim) {
        return ZONES.computeIfAbsent(key(d, slim), k -> {
            ModelData md = new ModelData();
            ModelPartData r = md.getRoot();
            Dilation dl = new Dilation(d);
            float rx = slim ? -2.5f : -3f, lx = slim ? -1.5f : -1f;
            ModelPartData head = r.addChild("head", ModelPartBuilder.create(), ModelTransform.NONE);
            head.addChild("HEAD", ModelPartBuilder.create().uv(0, 0).cuboid(-4f, -8f, -4f, 8f, 6f, 8f, dl), ModelTransform.NONE);
            head.addChild("NECK", ModelPartBuilder.create().uv(0, 6).cuboid(-4f, -2f, -4f, 8f, 2f, 8f, dl), ModelTransform.NONE);
            ModelPartData body = r.addChild("body", ModelPartBuilder.create(), ModelTransform.NONE);
            body.addChild("UPPER_TORSO", ModelPartBuilder.create().uv(16, 16).cuboid(-4f, 0f, -2f, 8f, 6f, 4f, dl), ModelTransform.NONE);
            body.addChild("LOWER_TORSO", ModelPartBuilder.create().uv(16, 22).cuboid(-4f, 6f, -2f, 8f, 6f, 4f, dl), ModelTransform.NONE);
            ModelPartData ra = r.addChild("right_arm", ModelPartBuilder.create(), ModelTransform.pivot(-5f, 2f, 0f));
            ra.addChild("R_UPPER_ARM", ModelPartBuilder.create().uv(40, 16).cuboid(rx, -2f, -2f, 4f, 5f, 4f, dl), ModelTransform.NONE);
            ra.addChild("R_FOREARM", ModelPartBuilder.create().uv(40, 21).cuboid(rx, 3f, -2f, 4f, 5f, 4f, dl), ModelTransform.NONE);
            ra.addChild("R_HAND", ModelPartBuilder.create().uv(40, 26).cuboid(rx, 8f, -2f, 4f, 2f, 4f, dl), ModelTransform.NONE);
            ModelPartData la = r.addChild("left_arm", ModelPartBuilder.create(), ModelTransform.pivot(5f, 2f, 0f));
            la.addChild("L_UPPER_ARM", ModelPartBuilder.create().uv(32, 48).cuboid(lx, -2f, -2f, 4f, 5f, 4f, dl), ModelTransform.NONE);
            la.addChild("L_FOREARM", ModelPartBuilder.create().uv(32, 53).cuboid(lx, 3f, -2f, 4f, 5f, 4f, dl), ModelTransform.NONE);
            la.addChild("L_HAND", ModelPartBuilder.create().uv(32, 58).cuboid(lx, 8f, -2f, 4f, 2f, 4f, dl), ModelTransform.NONE);
            ModelPartData rl = r.addChild("right_leg", ModelPartBuilder.create(), ModelTransform.pivot(-1.9f, 12f, 0f));
            rl.addChild("GROIN_R", ModelPartBuilder.create().uv(0, 16).cuboid(-2f, 0f, -2f, 4f, 2f, 4f, dl), ModelTransform.NONE);
            rl.addChild("R_THIGH", ModelPartBuilder.create().uv(0, 18).cuboid(-2f, 2f, -2f, 4f, 5f, 4f, dl), ModelTransform.NONE);
            rl.addChild("R_SHIN", ModelPartBuilder.create().uv(0, 23).cuboid(-2f, 7f, -2f, 4f, 3f, 4f, dl), ModelTransform.NONE);
            rl.addChild("R_FOOT", ModelPartBuilder.create().uv(0, 26).cuboid(-2f, 10f, -2f, 4f, 2f, 4f, dl), ModelTransform.NONE);
            ModelPartData ll = r.addChild("left_leg", ModelPartBuilder.create(), ModelTransform.pivot(1.9f, 12f, 0f));
            ll.addChild("GROIN_L", ModelPartBuilder.create().uv(16, 48).cuboid(-2f, 0f, -2f, 4f, 2f, 4f, dl), ModelTransform.NONE);
            ll.addChild("L_THIGH", ModelPartBuilder.create().uv(16, 50).cuboid(-2f, 2f, -2f, 4f, 5f, 4f, dl), ModelTransform.NONE);
            ll.addChild("L_SHIN", ModelPartBuilder.create().uv(16, 55).cuboid(-2f, 7f, -2f, 4f, 3f, 4f, dl), ModelTransform.NONE);
            ll.addChild("L_FOOT", ModelPartBuilder.create().uv(16, 58).cuboid(-2f, 10f, -2f, 4f, 2f, 4f, dl), ModelTransform.NONE);
            ModelPart root = TexturedModelData.of(md, 64, 64).createModel();
            Zones z = new Zones();
            String[][] kids = {{"HEAD", "NECK"}, {"UPPER_TORSO", "LOWER_TORSO"}, {"R_UPPER_ARM", "R_FOREARM", "R_HAND"},
                    {"L_UPPER_ARM", "L_FOREARM", "L_HAND"}, {"GROIN_R", "R_THIGH", "R_SHIN", "R_FOOT"}, {"GROIN_L", "L_THIGH", "L_SHIN", "L_FOOT"}};
            for (int i = 0; i < 6; i++) {
                z.limbs[i] = root.getChild(LIMB[i]);
                for (String c : kids[i]) z.zone.put(c, z.limbs[i].getChild(c));
            }
            return z;
        });
    }

    private static ModelPart models3d() {
        if (m3d == null) m3d = ClothingModels3D.create().createModel();
        return m3d;
    }

    // ===================== рисование =====================
    private static ModelPart[] src(BipedEntityModel<?> m) {
        return new ModelPart[]{m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg};
    }

    private static List<ItemStack> ordered(AbstractClientPlayerEntity p) {
        List<ItemStack> l = new ArrayList<>();
        for (ItemStack s : Clothes.get(p)) if (ClothingStack.def(s) != null) l.add(s);
        l.sort(Comparator.comparingDouble(s -> ClothingStack.def(s).dilation()));
        return l;
    }

    private static int limbMask(ClothingDef d) {
        if (d.slot().head()) return HEAD;
        int m = 0;
        int c = d.covers();
        if ((c & (bit(BodyPart.HEAD) | bit(BodyPart.NECK))) != 0 || d.slot() == ClothingSlot.NECK) m |= HEAD | BODY;
        if ((c & (bit(BodyPart.UPPER_TORSO) | bit(BodyPart.LOWER_TORSO))) != 0) m |= BODY | HEAD;
        if ((c & (bit(BodyPart.R_UPPER_ARM) | bit(BodyPart.R_FOREARM) | bit(BodyPart.R_HAND))) != 0) m |= RARM;
        if ((c & (bit(BodyPart.L_UPPER_ARM) | bit(BodyPart.L_FOREARM) | bit(BodyPart.L_HAND))) != 0) m |= LARM;
        if ((c & (bit(BodyPart.GROIN) | bit(BodyPart.R_THIGH) | bit(BodyPart.R_SHIN) | bit(BodyPart.R_FOOT))) != 0) m |= RLEG | BODY;
        if ((c & (bit(BodyPart.GROIN) | bit(BodyPart.L_THIGH) | bit(BodyPart.L_SHIN) | bit(BodyPart.L_FOOT))) != 0) m |= LLEG | BODY;
        if (m == 0) m = ALL;
        return m;
    }

    private static int bit(BodyPart p) {
        return 1 << p.ordinal();
    }

    private static void drawLayer(Layer l, ModelPart[] src, int mask, MatrixStack ms, VertexConsumer vc, int light, int overlay, int color) {
        for (int i = 0; i < 6; i++) {
            if ((mask & (1 << i)) == 0) continue;
            l.parts[i].copyTransform(src[i]);
            l.parts[i].render(ms, vc, light, overlay, color);
        }
    }

    /** Зоны: рисуем только выбранные части тела (bitmask по BodyPart). */
    private static void drawZones(Zones z, ModelPart[] src, int limbMask, int partMask, MatrixStack ms, VertexConsumer vc, int light, int overlay) {
        BodyPart[] all = BodyPart.values();
        for (Map.Entry<String, ModelPart> e : z.zone.entrySet()) {
            String n = e.getKey();
            BodyPart bp = n.startsWith("GROIN") ? BodyPart.GROIN : BodyPart.valueOf(n);
            e.getValue().visible = (partMask >> bp.ordinal() & 1) != 0;
        }
        for (int i = 0; i < 6; i++) {
            if ((limbMask & (1 << i)) == 0) continue;
            z.limbs[i].copyTransform(src[i]);
            z.limbs[i].render(ms, vc, light, overlay);
        }
    }

    /** Нарисовать одну вещь на модели (limbs — какие части тела рисовать). */
    public static void drawItem(ItemStack s, BipedEntityModel<?> model, boolean slim, int limbs, MatrixStack ms, VertexConsumerProvider vcp,
                                int light, int overlay) {
        ClothingDef d = ClothingStack.def(s);
        if (d == null) return;
        NbtCompound n = ClothingStack.read(s);
        int var = n.getInt("var");
        int tint = 0xFF000000 | (d.tinted() ? (n.contains("tint") ? n.getInt("tint") : d.tints()[0]) : 0xFFFFFF);
        ModelPart[] src = src(model);
        if (d.model3d() != null) {
            if ((limbs & HEAD) == 0) return;
            ModelPart root = models3d();
            VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(ATLAS));
            if (root.hasChild(d.model3d())) {
                ModelPart main = root.getChild(d.model3d());
                main.copyTransform(model.head);
                main.render(ms, vc, light, overlay, tint);
            }
            if (root.hasChild(d.model3d() + "_d")) {
                ModelPart det = root.getChild(d.model3d() + "_d");
                det.copyTransform(model.head);
                det.render(ms, vc, light, overlay, 0xFFFFFFFF);
            }
            return;
        }
        int mask = limbMask(d) & limbs;
        if (mask == 0) return;
        float dil = d.dilation();
        drawLayer(layer(dil, slim), src, mask, ms, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(d.texture(var))), light, overlay, tint);
        if (d.detail())
            drawLayer(layer(dil + 0.004f, slim), src, mask, ms, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(d.detailTexture(var))), light, overlay,
                    0xFFFFFFFF);
        // кровь, грязь, дыры, заплатки — только там, где вещь лежит на теле
        Zones z = zones(dil + 0.008f, slim);
        int cov = d.covers();
        float blood = ClothingStack.blood(n), dirt = ClothingStack.dirt(n);
        if (dirt > 0.1f)
            drawZones(z, src, mask, cov, ms, vcp.getBuffer(RenderLayer.getEntityTranslucent(DIRT[dirt > 0.7f ? 2 : dirt > 0.35f ? 1 : 0])), light, overlay);
        int holes = ClothingStack.holes(n) & cov;
        if (holes != 0) drawZones(z, src, mask, holes, ms, vcp.getBuffer(RenderLayer.getEntityTranslucent(HOLE)), light, overlay);
        int[] pat = n.getIntArray("pat");
        for (int m = 1; m <= 3; m++) {
            int pm = 0;
            for (int i = 0; i < pat.length; i++) if (pat[i] != 0 && ClothingStack.patchMat(pat[i]) == m) pm |= 1 << i;
            if (pm != 0) drawZones(z, src, mask, pm & cov, ms, vcp.getBuffer(RenderLayer.getEntityTranslucent(PATCH[m])), light, overlay);
        }
        if (blood > 0.06f)
            drawZones(zones(dil + 0.012f, slim), src, mask, cov, ms,
                    vcp.getBuffer(RenderLayer.getEntityTranslucent(BLOOD[blood > 0.7f ? 2 : blood > 0.3f ? 1 : 0])), light, overlay);
    }

    @Override
    public void render(MatrixStack ms, VertexConsumerProvider vcp, int light, AbstractClientPlayerEntity p, float limbAngle, float limbDistance,
                       float tickDelta, float animationProgress, float headYaw, float headPitch) {
        if (p.isInvisible()) return;
        ClothingClient.applyPending(p);
        boolean slim = p.getSkinTextures().model() == SkinTextures.Model.SLIM;
        int overlay = LivingEntityRenderer.getOverlay(p, 0f);
        for (ItemStack s : ordered(p)) drawItem(s, getContextModel(), slim, ALL, ms, vcp, light, overlay);
    }

    // ===================== от первого лица и слой скина =====================
    /** Рукава, перчатки и наручи на руке от первого лица. */
    public static void firstPersonArm(MatrixStack ms, VertexConsumerProvider vcp, int light, AbstractClientPlayerEntity p, ModelPart arm,
                                      PlayerEntityModel<?> model) {
        ClothingClient.applyPending(p);
        boolean right = arm == model.rightArm;
        boolean slim = p.getSkinTextures().model() == SkinTextures.Model.SLIM;
        for (ItemStack s : ordered(p)) {
            ClothingDef d = ClothingStack.def(s);
            if (d == null || d.slot().head()) continue;
            drawItem(s, model, slim, right ? RARM : LARM, ms, vcp, light, OverlayTexture.DEFAULT_UV);
        }
    }

    /** Под одеждой второй слой скина (куртка, рукава, штанины, шапка) прячется — иначе он лезет поверх. */
    public static void hideSkinLayers(AbstractClientPlayerEntity p, PlayerEntityModel<?> m) {
        int cov = 0;
        boolean head = false;
        for (ItemStack s : Clothes.get(p)) {
            ClothingDef d = ClothingStack.def(s);
            if (d == null) continue;
            cov |= d.covers();
            if (d.slot() == ClothingSlot.HAT || d.slot() == ClothingSlot.MASK) head = true;
        }
        if (cov == 0 && !head) return;
        if ((cov & (bit(BodyPart.UPPER_TORSO) | bit(BodyPart.LOWER_TORSO))) != 0) m.jacket.visible = false;
        if ((cov & (bit(BodyPart.R_UPPER_ARM) | bit(BodyPart.R_FOREARM))) != 0) m.rightSleeve.visible = false;
        if ((cov & (bit(BodyPart.L_UPPER_ARM) | bit(BodyPart.L_FOREARM))) != 0) m.leftSleeve.visible = false;
        if ((cov & (bit(BodyPart.R_THIGH) | bit(BodyPart.R_SHIN))) != 0) m.rightPants.visible = false;
        if ((cov & (bit(BodyPart.L_THIGH) | bit(BodyPart.L_SHIN))) != 0) m.leftPants.visible = false;
        if (head || (cov & bit(BodyPart.HEAD)) != 0) m.hat.visible = false;
    }
}
