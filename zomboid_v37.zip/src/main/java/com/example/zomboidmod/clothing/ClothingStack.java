package com.example.zomboidmod.clothing;

import com.example.zomboidmod.BodyPart;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.random.Random;

/**
 * Состояние конкретной вещи (в данных предмета): расцветка, дыры по частям тела, заплатки, кровь и грязь.
 * Заплатка: материал (1-3) | царапины << 2 | укусы << 9 | (заплата на дыре) << 16.
 */
public final class ClothingStack {
    private ClothingStack() {
    }

    public static final int PARTS = BodyPart.values().length;

    public static NbtCompound read(ItemStack s) {
        NbtComponent c = s.get(DataComponentTypes.CUSTOM_DATA);
        return c == null ? new NbtCompound() : c.copyNbt();
    }

    public static void edit(ItemStack s, java.util.function.Consumer<NbtCompound> f) {
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, s, f);
    }

    public static ClothingDef def(ItemStack s) {
        return s.getItem() instanceof ClothingItem ci ? ci.def : null;
    }

    public static int tint(ItemStack s) {
        ClothingDef d = def(s);
        if (d == null || !d.tinted()) return 0xFFFFFF;
        NbtCompound n = read(s);
        return n.contains("tint") ? n.getInt("tint") : d.tints()[0];
    }

    public static int variant(ItemStack s) {
        return read(s).getInt("var");
    }

    public static int holes(NbtCompound n) {
        return n.getInt("holes");
    }

    public static boolean hole(NbtCompound n, BodyPart p) {
        return (n.getInt("holes") >> p.ordinal() & 1) != 0;
    }

    public static int patch(NbtCompound n, BodyPart p) {
        int[] a = n.getIntArray("pat");
        return p.ordinal() < a.length ? a[p.ordinal()] : 0;
    }

    public static int patchMat(int v) {
        return v & 3;
    }

    public static int patchScratch(int v) {
        return v >> 2 & 127;
    }

    public static int patchBite(int v) {
        return v >> 9 & 127;
    }

    public static boolean patchOverHole(int v) {
        return (v >> 16 & 1) != 0;
    }

    public static int packPatch(int mat, int scr, int bite, boolean overHole) {
        return (mat & 3) | (Math.min(127, scr) << 2) | (Math.min(127, bite) << 9) | ((overHole ? 1 : 0) << 16);
    }

    public static float blood(NbtCompound n) {
        return n.getFloat("blood");
    }

    public static float dirt(NbtCompound n) {
        return n.getFloat("dirt");
    }

    /** {царапины, укусы, пули} этой вещи на части тела, с учётом дыр и заплат. */
    public static int[] defense(ClothingDef d, NbtCompound n, BodyPart p) {
        if (!d.covers(p)) {
            if (p == BodyPart.NECK && d.neck() > 0) return new int[]{Math.round(d.scratch() * d.neck()), Math.round(d.bite() * d.neck()), 0};
            return new int[]{0, 0, 0};
        }
        int pat = patch(n, p);
        boolean lost = hole(n, p) || (pat != 0 && patchOverHole(pat));
        int sc = lost ? 0 : d.scratch(), bi = lost ? 0 : d.bite(), bu = lost ? 0 : d.bullet();
        if (pat != 0) {
            sc += patchScratch(pat);
            bi += patchBite(pat);
        }
        return new int[]{Math.min(100, sc), Math.min(100, bi), bu};
    }

    /** Доля целой ткани (дыры не греют и не защищают). */
    public static float intact(ClothingDef d, NbtCompound n) {
        int c = d.coverCount();
        if (c == 0) return 1f;
        return 1f - Integer.bitCount(holes(n) & d.covers()) / (float) c;
    }

    public static void setHole(ItemStack s, BodyPart p, boolean on) {
        edit(s, n -> {
            int h = n.getInt("holes");
            n.putInt("holes", on ? h | (1 << p.ordinal()) : h & ~(1 << p.ordinal()));
        });
    }

    public static void setPatch(ItemStack s, BodyPart p, int value) {
        edit(s, n -> {
            int[] a = n.getIntArray("pat");
            if (a.length < PARTS) a = java.util.Arrays.copyOf(a, PARTS);
            a[p.ordinal()] = value;
            n.putIntArray("pat", a);
        });
    }

    public static void addBlood(ItemStack s, float v) {
        edit(s, n -> n.putFloat("blood", Math.max(0f, Math.min(1f, n.getFloat("blood") + v))));
    }

    public static void addDirt(ItemStack s, float v) {
        edit(s, n -> n.putFloat("dirt", Math.max(0f, Math.min(1f, n.getFloat("dirt") + v))));
    }

    public static void wash(ItemStack s, float keep) {
        edit(s, n -> {
            n.putFloat("blood", n.getFloat("blood") * keep);
            n.putFloat("dirt", n.getFloat("dirt") * keep);
        });
    }

    /** Новая вещь: случайная расцветка и (для готовых расцветок) вариант. */
    public static ItemStack create(ClothingDef d, Random r) {
        ItemStack s = new ItemStack(ClothingItem.of(d));
        edit(s, n -> {
            if (d.tinted()) n.putInt("tint", d.tints()[r.nextInt(d.tints().length)]);
            if (d.variants() > 1) n.putInt("var", r.nextInt(d.variants()));
        });
        return s;
    }

    /** Ношеная вещь с зомби или из развалин: кровь, грязь и дыры. */
    public static void weather(ItemStack s, Random r, float blood, float dirt, int holes) {
        ClothingDef d = def(s);
        if (d == null) return;
        edit(s, n -> {
            n.putFloat("blood", Math.min(1f, blood));
            n.putFloat("dirt", Math.min(1f, dirt));
            if (d.canTear()) {
                int h = 0;
                for (int i = 0; i < holes; i++) {
                    int p = r.nextInt(PARTS);
                    if ((d.covers() >> p & 1) != 0) h |= 1 << p;
                }
                n.putInt("holes", h);
            }
        });
    }
}
