package com.example.zomboidmod.clothing;

import com.example.zomboidmod.BodyPart;
import com.example.zomboidmod.LootItems;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.List;

/**
 * Шитьё по вики PZ: игла + нитки + лоскут = заплатка. На дыру — закрывает её (с навыком 8 и родной тканью — как новая),
 * на целое место — укрепляет. Хлопок до +5% царапин, джинса до +10/+5, кожа до +20/+10 (растёт с навыком).
 * Ткань из одежды: хлопок рвётся руками, джинсу и кожу режут ножницами. Нитки иногда выходят при распарывании.
 */
public final class Tailoring {
    private Tailoring() {
    }

    public static Item NEEDLE, THREAD, SCISSORS, DENIM_STRIPS, LEATHER_STRIPS, SOAP;

    public static final int A_TAKEOFF = 0, A_PATCH = 1, A_UNPATCH = 2, A_RIP = 3, A_CRAFT = 4;

    private static Item reg(String id, Item it) {
        return Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), it);
    }

    static void registerItems() {
        NEEDLE = reg("needle", new Tip(new Item.Settings().maxCount(1), "Шить заплатки и одежду (не ломается)"));
        THREAD = reg("thread", new Tip(new Item.Settings().maxCount(1).maxDamage(10), "Катушка: хватает на 10 стежков"));
        SCISSORS = reg("scissors", new Tip(new Item.Settings().maxCount(1).maxDamage(80), "Резать джинсу и кожу на лоскуты"));
        DENIM_STRIPS = reg("denim_strips", new Tip(new Item.Settings().maxCount(32), "Заплатка: до +10% от царапин и +5% от укусов"));
        LEATHER_STRIPS = reg("leather_strips", new Tip(new Item.Settings().maxCount(32), "Заплатка: до +20% от царапин и +10% от укусов"));
        SOAP = reg("soap", new Soap(new Item.Settings().maxCount(1).maxDamage(10)));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            for (Item i : new Item[]{NEEDLE, THREAD, SCISSORS, DENIM_STRIPS, LEATHER_STRIPS, SOAP, LootItems.BOOK_TAILORING}) if (i != null) e.add(i);
        });
    }

    // ===================== инвентарь =====================
    public static int count(PlayerEntity p, Item it) {
        int n = 0;
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).isOf(it)) n += inv.getStack(i).getCount();
        return n;
    }

    /** Остаток ниток (стежков) во всех катушках. */
    public static int threadLeft(PlayerEntity p) {
        int n = 0;
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(THREAD)) n += s.getMaxDamage() - s.getDamage();
        }
        return n;
    }

    public static boolean has(PlayerEntity p, Item it) {
        return count(p, it) > 0;
    }

    private static void take(PlayerEntity p, Item it, int n) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size() && n > 0; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isOf(it)) continue;
            int k = Math.min(n, s.getCount());
            s.decrement(k);
            n -= k;
        }
        inv.markDirty();
    }

    /** Потратить стежки ниток (пустые катушки исчезают). */
    private static void useThread(ServerPlayerEntity p, int n) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size() && n > 0; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isOf(THREAD)) continue;
            while (n > 0 && !s.isEmpty()) {
                n--;
                s.setDamage(s.getDamage() + 1);
                if (s.getDamage() >= s.getMaxDamage()) s.decrement(1);
            }
        }
    }

    private static void wear(ServerPlayerEntity p, Item tool, int dmg) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(tool)) {
                s.damage(dmg, p.getServerWorld(), p, it -> {
                });
                return;
            }
        }
    }

    static void useSoap(ServerPlayerEntity p) {
        wear(p, SOAP, 1);
    }

    public static Item stripOf(int mat) {
        return mat == 2 ? DENIM_STRIPS : mat == 3 ? LEATHER_STRIPS : ZomboidMod.RAG;
    }

    private static void fail(ServerPlayerEntity p, String msg) {
        p.sendMessage(Text.literal(msg).formatted(Formatting.RED), true);
    }

    // ===================== действия из окна одежды =====================
    public static void handle(ServerPlayerEntity p, ClothesPayloads.Action a) {
        if (p.isSpectator()) return;
        switch (a.action()) {
            case A_TAKEOFF -> Clothes.takeOff(p, a.slot());
            case A_PATCH -> patch(p, a.slot(), a.part(), a.arg());
            case A_UNPATCH -> unpatch(p, a.slot(), a.part());
            case A_RIP -> rip(p, a.slot());
            case A_CRAFT -> craft(p, a.arg());
            default -> {
            }
        }
        Clothes.markDirty(p);
    }

    private static ItemStack wornAt(ServerPlayerEntity p, int slot) {
        ItemStack[] w = Clothes.get(p);
        return slot >= 0 && slot < w.length ? w[slot] : ItemStack.EMPTY;
    }

    /** Бонус заплатки по формуле PZ: макс. значение ткани x навык / 10, не меньше 1%. */
    public static int[] patchBonus(int mat, int level) {
        Fabric f = Fabric.ofPatch(mat);
        int eff = Math.max(1, level);
        int sc = f.maxScratch == 0 ? 0 : Math.max(1, f.maxScratch * eff / 10);
        int bi = f.maxBite == 0 ? 0 : Math.max(1, f.maxBite * eff / 10);
        return new int[]{sc, bi};
    }

    private static void patch(ServerPlayerEntity p, int slot, int partIdx, int mat) {
        ItemStack s = wornAt(p, slot);
        ClothingDef d = ClothingStack.def(s);
        if (d == null || partIdx < 0 || partIdx >= BodyPart.values().length || mat < 1 || mat > 3) return;
        BodyPart part = BodyPart.values()[partIdx];
        if (!d.patchable()) {
            fail(p, "Эту вещь не залатать тканью");
            return;
        }
        if (!d.covers(part)) return;
        NbtCompound n = ClothingStack.read(s);
        if (ClothingStack.patch(n, part) != 0) {
            fail(p, "Здесь уже есть заплатка");
            return;
        }
        if (!has(p, NEEDLE)) {
            fail(p, "Нужна игла");
            return;
        }
        if (threadLeft(p) < 1) {
            fail(p, "Нужны нитки");
            return;
        }
        Item strip = stripOf(mat);
        if (!has(p, strip)) {
            fail(p, "Нужен лоскут: " + strip.getName().getString());
            return;
        }
        int lv = Skills.level(p, PzSkill.TAILORING);
        boolean hole = ClothingStack.hole(n, part);
        take(p, strip, 1);
        useThread(p, 1);
        if (hole && lv >= 8 && Fabric.ofPatch(mat) == d.fabric()) {
            ClothingStack.setHole(s, part, false);
            p.sendMessage(Text.literal("Дыра заштопана как новая").formatted(Formatting.GREEN), true);
        } else {
            int[] b = patchBonus(mat, lv);
            if (hole) ClothingStack.setHole(s, part, false);
            ClothingStack.setPatch(s, part, ClothingStack.packPatch(mat, b[0], b[1], hole));
            p.sendMessage(Text.literal((hole ? "Дыра залатана" : "Пришита укрепляющая заплатка") + String.format(": +%d%% царапины, +%d%% укусы", b[0], b[1]))
                    .formatted(Formatting.GREEN), true);
        }
        Skills.addXp(p, PzSkill.TAILORING, 3f);
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.UI_LOOM_TAKE_RESULT, SoundCategory.PLAYERS, 0.7f, 1.2f);
    }

    private static void unpatch(ServerPlayerEntity p, int slot, int partIdx) {
        ItemStack s = wornAt(p, slot);
        ClothingDef d = ClothingStack.def(s);
        if (d == null || partIdx < 0 || partIdx >= BodyPart.values().length) return;
        BodyPart part = BodyPart.values()[partIdx];
        int pat = ClothingStack.patch(ClothingStack.read(s), part);
        if (pat == 0) return;
        if (!has(p, NEEDLE)) {
            fail(p, "Нужна игла, чтобы аккуратно спороть заплатку");
            return;
        }
        int lv = Skills.level(p, PzSkill.TAILORING);
        ClothingStack.setPatch(s, part, 0);
        if (ClothingStack.patchOverHole(pat)) ClothingStack.setHole(s, part, true);
        if (p.getRandom().nextInt(100) < 10 + 5 * lv) {
            p.getInventory().offerOrDrop(new ItemStack(stripOf(ClothingStack.patchMat(pat))));
            Skills.addXp(p, PzSkill.TAILORING, 3f);
            p.sendMessage(Text.literal("Заплатка спорота, лоскут цел").formatted(Formatting.GRAY), true);
        } else p.sendMessage(Text.literal("Заплатка спорота, лоскут испорчен").formatted(Formatting.GRAY), true);
    }

    /** Распороть на лоскуты (надетую вещь или вещь в руке: slot = -1). */
    private static void rip(ServerPlayerEntity p, int slot) {
        ItemStack s = slot >= 0 ? wornAt(p, slot) : p.getMainHandStack();
        ClothingDef d = ClothingStack.def(s);
        if (d == null) return;
        if (d.fabric() == Fabric.NONE) {
            fail(p, "Из этой вещи лоскутов не выйдет");
            return;
        }
        if (d.fabric() != Fabric.COTTON && !has(p, SCISSORS)) {
            fail(p, "Джинсу и кожу руками не порвать: нужны ножницы");
            return;
        }
        int lv = Skills.level(p, PzSkill.TAILORING);
        float intact = ClothingStack.intact(d, ClothingStack.read(s));
        int n = Math.max(1, Math.round((2 + d.coverCount() / 4f) * intact));
        Item strip = stripOf(d.fabric().patchId());
        if (slot >= 0) Clothes.get(p)[slot] = ItemStack.EMPTY;
        else s.decrement(1);
        p.getInventory().offerOrDrop(new ItemStack(strip, n));
        String extra = "";
        if (p.getRandom().nextFloat() < 0.1f + 0.05f * lv) {
            ItemStack th = new ItemStack(THREAD);
            th.setDamage(th.getMaxDamage() - (1 + p.getRandom().nextInt(3)));
            p.getInventory().offerOrDrop(th);
            extra = " и немного ниток";
        }
        if (d.fabric() != Fabric.COTTON) wear(p, SCISSORS, 1);
        Skills.addXp(p, PzSkill.TAILORING, 1f);
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_SHEEP_SHEAR, SoundCategory.PLAYERS, 0.8f, 1.1f);
        p.sendMessage(Text.literal("Распорото: " + n + " шт. " + strip.getName().getString().toLowerCase() + extra).formatted(Formatting.GRAY), true);
    }

    // ===================== рецепты шитья =====================
    public record Recipe(String title, int level, boolean needle, int thread, boolean scissors, Object[] input, String result, int count, float xp) {
    }

    /** Ингредиенты: пары (предмет-поставщик, количество). result — id одежды или предмета мода/игры. */
    public static final List<Recipe> RECIPES = List.of(
            new Recipe("Нитки из бечёвки", 0, false, 0, false, new Object[]{"minecraft:string", 3}, "zomboidmod:thread", 1, 0.5f),
            new Recipe("Кожаные лоскуты из кожи", 0, false, 0, true, new Object[]{"minecraft:leather", 1}, "zomboidmod:leather_strips", 3, 1f),
            new Recipe("Тряпки из шерсти", 0, false, 0, true, new Object[]{"#wool", 1}, "zomboidmod:rag", 3, 0.5f),
            new Recipe("Бандана из лоскутов", 0, false, 0, false, new Object[]{"zomboidmod:rag", 2}, "bandana_mask", 1, 1f),
            new Recipe("Наручи из журналов", 0, false, 0, false, new Object[]{"zomboidmod:magazine", 2, "zomboidmod:duct_tape", 1}, "magazine_bracers", 1, 2f),
            new Recipe("Шарф из лоскутов", 1, true, 2, false, new Object[]{"zomboidmod:rag", 4}, "scarf", 1, 4f),
            new Recipe("Кожаный воротник", 2, true, 2, false, new Object[]{"zomboidmod:leather_strips", 3}, "leather_neck", 1, 6f),
            new Recipe("Кожаные наручи", 3, true, 3, false, new Object[]{"zomboidmod:leather_strips", 4}, "leather_bracers", 1, 8f),
            new Recipe("Кожаные поножи", 3, true, 3, false, new Object[]{"zomboidmod:leather_strips", 4}, "leather_shinguards", 1, 8f),
            new Recipe("Кожаные перчатки", 4, true, 3, true, new Object[]{"zomboidmod:leather_strips", 3}, "leather_gloves", 1, 8f),
            new Recipe("Кожаная куртка", 6, true, 8, true, new Object[]{"zomboidmod:leather_strips", 12}, "leather_jacket", 1, 20f));

    public static int have(PlayerEntity p, String id) {
        if (id.equals("#wool")) {
            int n = 0;
            var inv = p.getInventory();
            for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).isIn(net.minecraft.registry.tag.ItemTags.WOOL)) n += inv.getStack(i).getCount();
            return n;
        }
        Item it = Registries.ITEM.get(Identifier.of(id));
        return it == Items.AIR ? 0 : count(p, it);
    }

    /** null — можно шить; иначе чего не хватает. */
    public static String missing(PlayerEntity p, Recipe r, int level) {
        if (level < r.level()) return "нужно шитьё " + r.level();
        if (r.needle() && !has(p, NEEDLE)) return "нужна игла";
        if (r.thread() > 0 && threadLeft(p) < r.thread()) return "нужно ниток: " + r.thread();
        if (r.scissors() && !has(p, SCISSORS)) return "нужны ножницы";
        for (int i = 0; i + 1 < r.input().length; i += 2) {
            String id = (String) r.input()[i];
            int n = (Integer) r.input()[i + 1];
            if (have(p, id) < n) return "мало материала";
        }
        return null;
    }

    private static void craft(ServerPlayerEntity p, int idx) {
        if (idx < 0 || idx >= RECIPES.size()) return;
        Recipe r = RECIPES.get(idx);
        int lv = Skills.level(p, PzSkill.TAILORING);
        String miss = missing(p, r, lv);
        if (miss != null) {
            fail(p, "Не выйдет: " + miss);
            return;
        }
        for (int i = 0; i + 1 < r.input().length; i += 2) {
            String id = (String) r.input()[i];
            int n = (Integer) r.input()[i + 1];
            if (id.equals("#wool")) {
                var inv = p.getInventory();
                for (int k = 0; k < inv.size() && n > 0; k++) {
                    ItemStack s = inv.getStack(k);
                    if (!s.isIn(net.minecraft.registry.tag.ItemTags.WOOL)) continue;
                    int t = Math.min(n, s.getCount());
                    s.decrement(t);
                    n -= t;
                }
            } else take(p, Registries.ITEM.get(Identifier.of(id)), n);
        }
        if (r.thread() > 0) useThread(p, r.thread());
        if (r.scissors()) wear(p, SCISSORS, 1);
        ItemStack out;
        ClothingItem ci = ClothingItem.byId(r.result());
        if (ci != null) out = ClothingStack.create(ci.def, p.getRandom());
        else out = new ItemStack(Registries.ITEM.get(Identifier.of(r.result())), r.count());
        if (out.isOf(THREAD)) out.setDamage(5);           // из бечёвки — полкатушки
        p.getInventory().offerOrDrop(out);
        Skills.addXp(p, PzSkill.TAILORING, r.xp());
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.UI_LOOM_TAKE_RESULT, SoundCategory.PLAYERS, 0.8f, 1.0f);
        p.sendMessage(Text.literal("Сшито: " + r.title()).formatted(Formatting.GREEN), true);
    }

    // ===================== предметы =====================
    static class Tip extends Item {
        private final String tip;

        Tip(Settings s, String tip) {
            super(s);
            this.tip = tip;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(tip).formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Шьют в окне одежды (клавиша O)").formatted(Formatting.DARK_GRAY));
        }
    }

    /** Мыло: ПКМ по воде (река, раковина, ванна, бочка) — постирать всё надетое и умыться. */
    static class Soap extends Item {
        Soap(Settings s) {
            super(s);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal("ПКМ по воде или раковине: постирать надетое").formatted(Formatting.GRAY));
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            BlockHitResult hit = raycast(world, user, RaycastContext.FluidHandling.SOURCE_ONLY);
            if (hit.getType() != HitResult.Type.BLOCK || !world.getFluidState(hit.getBlockPos()).isIn(FluidTags.WATER)) {
                return TypedActionResult.pass(st);
            }
            if (!world.isClient && user instanceof ServerPlayerEntity sp) {
                Clothes.washAll(sp, true, true);
                st.damage(1, sp.getServerWorld(), sp, it -> {
                });
            }
            return TypedActionResult.success(st, world.isClient);
        }
    }
}
