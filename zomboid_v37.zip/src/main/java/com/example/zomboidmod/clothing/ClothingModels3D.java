package com.example.zomboidmod.clothing;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;

/** Сгенерировано gen_clothing.py: 3D-головные уборы и маски. "<id>" тонируется, "<id>_d" — нет. */
public final class ClothingModels3D {
    private ClothingModels3D() {
    }

    public static TexturedModelData create() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("baseball_cap", ModelPartBuilder.create().uv(0, 0).cuboid(-4f, -9f, -4f, 8f, 2f, 8f, new Dilation(0.5f)).uv(33, 0).cuboid(-4f, -7.9f, -7.4f, 8f, 0.6f, 3.6f, new Dilation(0f)).uv(58, 0).cuboid(-0.5f, -10.1f, -0.5f, 1f, 0.5f, 1f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("baseball_cap_d", ModelPartBuilder.create().uv(63, 0).cuboid(-1.4f, -9.2f, -4.58f, 2.8f, 1.4f, 0.08f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("cowboy_hat", ModelPartBuilder.create().uv(70, 0).cuboid(-7.5f, -8.3f, -7.5f, 15f, 0.6f, 15f, new Dilation(0f)).uv(131, 0).cuboid(-4f, -11.8f, -4f, 8f, 3.5f, 8f, new Dilation(0.25f)), ModelTransform.NONE);
        root.addChild("cowboy_hat_d", ModelPartBuilder.create().uv(164, 0).cuboid(-4f, -9.0f, -4f, 8f, 0.8f, 8f, new Dilation(0.32f)), ModelTransform.NONE);
        root.addChild("bucket_hat", ModelPartBuilder.create().uv(197, 0).cuboid(-4f, -10.2f, -4f, 8f, 2.4f, 8f, new Dilation(0.4f)).uv(0, 17).cuboid(-6f, -7.9f, -6f, 12f, 0.5f, 12f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("bucket_hat_d", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("fedora", ModelPartBuilder.create().uv(49, 17).cuboid(-3.8f, -11.3f, -3.8f, 7.6f, 3.0f, 7.6f, new Dilation(0.3f)).uv(81, 17).cuboid(-6.2f, -8.3f, -6.2f, 12.4f, 0.5f, 12.4f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("fedora_d", ModelPartBuilder.create().uv(132, 17).cuboid(-3.8f, -8.9f, -3.8f, 7.6f, 0.7f, 7.6f, new Dilation(0.33f)), ModelTransform.NONE);
        root.addChild("straw_hat", ModelPartBuilder.create().uv(164, 17).cuboid(-7f, -8f, -7f, 14f, 1f, 14f, new Dilation(0f)).uv(221, 17).cuboid(-4f, -11f, -4f, 8f, 3f, 8f, new Dilation(0.3f)).uv(0, 33).cuboid(-4f, -9f, -4f, 8f, 1f, 8f, new Dilation(0.45f)), ModelTransform.NONE);
        root.addChild("straw_hat_d", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("chef_hat", ModelPartBuilder.create().uv(33, 33).cuboid(-4f, -9f, -4f, 8f, 1f, 8f, new Dilation(0.6f)).uv(66, 33).cuboid(-4f, -13f, -4f, 8f, 4f, 8f, new Dilation(0.9f)), ModelTransform.NONE);
        root.addChild("chef_hat_d", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("police_cap", ModelPartBuilder.create().uv(99, 33).cuboid(-4f, -10f, -4f, 8f, 2f, 8f, new Dilation(0.5f)).uv(132, 33).cuboid(-4f, -8f, -4f, 8f, 1f, 8f, new Dilation(0.55f)).uv(165, 33).cuboid(-4f, -8f, -7f, 8f, 1f, 3f, new Dilation(0f)).uv(188, 33).cuboid(-1f, -10f, -5f, 2f, 2f, 1f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("police_cap_d", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("beret", ModelPartBuilder.create().uv(195, 33).cuboid(-4.8f, -9.4f, -4.4f, 9.2f, 1.2f, 8.8f, new Dilation(0.2f)).uv(0, 46).cuboid(-4.4f, -8.5f, -4.2f, 8.8f, 0.5f, 8.4f, new Dilation(0.35f)).uv(36, 46).cuboid(-0.3f, -10.1f, -0.3f, 0.6f, 0.6f, 0.6f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("beret_d", ModelPartBuilder.create().uv(40, 46).cuboid(-3.2f, -9.3f, -4.85f, 1.2f, 1.2f, 0.1f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("hard_hat", ModelPartBuilder.create().uv(44, 46).cuboid(-4f, -10f, -4f, 8f, 2f, 8f, new Dilation(0.5f)).uv(77, 46).cuboid(-3f, -11f, -3f, 6f, 1f, 6f, new Dilation(0.3f)).uv(102, 46).cuboid(-5f, -8f, -6.6f, 10f, 0.6f, 11.6f, new Dilation(0f)).uv(147, 46).cuboid(-0.6f, -11.6f, -4.2f, 1.2f, 0.6f, 8.4f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("hard_hat_d", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("army_helmet", ModelPartBuilder.create().uv(168, 46).cuboid(-5f, -10f, -5f, 10f, 3f, 10f, new Dilation(0f)).uv(209, 46).cuboid(-4f, -11f, -4f, 8f, 1f, 8f, new Dilation(0f)).uv(0, 60).cuboid(-5.4f, -7.4f, -5.4f, 10.8f, 0.6f, 10.8f, new Dilation(0f)).uv(45, 60).cuboid(-5.2f, -7f, -0.6f, 0.4f, 4.6f, 1.2f, new Dilation(0f)).uv(50, 60).cuboid(4.8f, -7f, -0.6f, 0.4f, 4.6f, 1.2f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("army_helmet_d", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("fire_helmet", ModelPartBuilder.create().uv(55, 60).cuboid(-5f, -11f, -5f, 10f, 3f, 10f, new Dilation(0f)).uv(96, 60).cuboid(-4f, -12f, -4f, 8f, 1f, 8f, new Dilation(0f)).uv(129, 60).cuboid(-6f, -8f, -6f, 12f, 1f, 13f, new Dilation(0f)).uv(180, 60).cuboid(-2f, -11f, -6f, 4f, 3f, 1f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("fire_helmet_d", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("riot_helmet", ModelPartBuilder.create().uv(191, 60).cuboid(-5f, -10.5f, -5f, 10f, 3.5f, 10f, new Dilation(0f)).uv(0, 75).cuboid(-4f, -11.4f, -4f, 8f, 1f, 8f, new Dilation(0f)).uv(33, 75).cuboid(-5f, -7f, -4.4f, 1f, 4.6f, 9.4f, new Dilation(0f)).uv(55, 75).cuboid(4f, -7f, -4.4f, 1f, 4.6f, 9.4f, new Dilation(0f)).uv(77, 75).cuboid(-4f, -7f, 4f, 8f, 4.6f, 1f, new Dilation(0f)).uv(96, 75).cuboid(-4.6f, -8.2f, -5.7f, 9.2f, 7.2f, 0.6f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("riot_helmet_d", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("moto_helmet", ModelPartBuilder.create().uv(117, 75).cuboid(-5f, -10.4f, -5f, 10f, 3.2f, 10f, new Dilation(0f)).uv(158, 75).cuboid(-5f, -7.2f, -5f, 1f, 7.6f, 10f, new Dilation(0f)).uv(181, 75).cuboid(4f, -7.2f, -5f, 1f, 7.6f, 10f, new Dilation(0f)).uv(204, 75).cuboid(-4f, -7.2f, 4f, 8f, 7.6f, 1f, new Dilation(0f)).uv(223, 75).cuboid(-4f, -2.6f, -5.2f, 8f, 3.0f, 1.2f, new Dilation(0f)).uv(0, 94).cuboid(-4f, -7.2f, -5.2f, 8f, 1.2f, 1.2f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("moto_helmet_d", ModelPartBuilder.create().uv(20, 94).cuboid(-4f, -6.0f, -5.5f, 8f, 3.4f, 0.6f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("gas_mask", ModelPartBuilder.create().uv(39, 94).cuboid(-4f, -6.2f, -4.8f, 8f, 5.6f, 0.8f, new Dilation(0f)).uv(58, 94).cuboid(-3.3f, -5.7f, -5.2f, 2.4f, 2.4f, 0.5f, new Dilation(0f)).uv(65, 94).cuboid(0.9f, -5.7f, -5.2f, 2.4f, 2.4f, 0.5f, new Dilation(0f)).uv(72, 94).cuboid(-1.2f, -2.9f, -6.8f, 2.4f, 2.4f, 2.1f, new Dilation(0f)).uv(82, 94).cuboid(-4.3f, -6.4f, -4.2f, 0.3f, 1.0f, 8.4f, new Dilation(0f)).uv(101, 94).cuboid(4.0f, -6.4f, -4.2f, 0.3f, 1.0f, 8.4f, new Dilation(0f)).uv(120, 94).cuboid(-4f, -8.2f, 3.9f, 8f, 0.8f, 0.4f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("gas_mask_d", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("hockey_mask", ModelPartBuilder.create().uv(138, 94).cuboid(-4f, -8f, -4.9f, 8f, 7.6f, 0.8f, new Dilation(0f)).uv(157, 94).cuboid(-4.2f, -6.2f, -4.2f, 0.3f, 0.6f, 8.4f, new Dilation(0f)).uv(176, 94).cuboid(3.9f, -6.2f, -4.2f, 0.3f, 0.6f, 8.4f, new Dilation(0f)).uv(195, 94).cuboid(-4f, -6.2f, 4.0f, 8f, 0.6f, 0.3f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("hockey_mask_d", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("welding_mask", ModelPartBuilder.create().uv(213, 94).cuboid(-4.4f, -8.6f, -5.6f, 8.8f, 8.4f, 1f, new Dilation(0f)).uv(234, 94).cuboid(-2.4f, -5.6f, -5.9f, 4.8f, 1.7f, 0.4f, new Dilation(0f)).uv(0, 105).cuboid(-4.4f, -7.4f, -4.6f, 0.4f, 1.2f, 9.0f, new Dilation(0f)).uv(20, 105).cuboid(4.0f, -7.4f, -4.6f, 0.4f, 1.2f, 9.0f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("welding_mask_d", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("respirator", ModelPartBuilder.create().uv(40, 105).cuboid(-1.8f, -4.6f, -4.9f, 3.6f, 3.0f, 0.9f, new Dilation(0f)).uv(50, 105).cuboid(-4.0f, -4.0f, -5.6f, 2.2f, 2.2f, 1.6f, new Dilation(0f)).uv(59, 105).cuboid(1.8f, -4.0f, -5.6f, 2.2f, 2.2f, 1.6f, new Dilation(0f)).uv(68, 105).cuboid(-4.2f, -5.6f, -4.2f, 0.3f, 0.5f, 8.4f, new Dilation(0f)).uv(87, 105).cuboid(3.9f, -5.6f, -4.2f, 0.3f, 0.5f, 8.4f, new Dilation(0f)), ModelTransform.NONE);
        root.addChild("respirator_d", ModelPartBuilder.create(), ModelTransform.NONE);
        return TexturedModelData.of(md, 256, 256);
    }
}
