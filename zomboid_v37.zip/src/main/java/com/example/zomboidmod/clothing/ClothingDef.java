package com.example.zomboidmod.clothing;

import com.example.zomboidmod.BodyPart;
import com.example.zomboidmod.ZomboidMod;
import net.minecraft.util.Identifier;

/**
 * Описание вещи: что закрывает и насколько защищает (укус, царапина, пуля), утепление, ветро- и влагозащита,
 * вес, штрафы к бегу и атаке. tints — расцветки (основа серая и тонируется), variants — готовые расцветки текстур.
 */
public record ClothingDef(String id, String title, ClothingSlot slot, int blocks, int covers, int bite, int scratch, int bullet,
                          float insulation, float wind, float water, float weight, float run, float combat, Fabric fabric, int[] tints,
                          String model3d, int variants, boolean detail, float neck, float stealth, float dilationOverride) {

    public boolean covers(BodyPart p) {
        return (covers >> p.ordinal() & 1) != 0;
    }

    public boolean blocks(ClothingSlot s) {
        return (blocks >> s.ordinal() & 1) != 0;
    }

    public int coverCount() {
        return Integer.bitCount(covers);
    }

    public float dilation() {
        return dilationOverride > 0 ? dilationOverride : slot.dilation;
    }

    public boolean tinted() {
        return tints.length > 0;
    }

    /** Можно ли порвать (каски, обувь, очки и бронежилеты не рвутся). */
    public boolean canTear() {
        return model3d == null && slot != ClothingSlot.EYES && slot != ClothingSlot.SHOES && bullet == 0 && covers != 0;
    }

    public boolean patchable() {
        return fabric != Fabric.NONE && canTear();
    }

    public Identifier texture(int variant) {
        return Identifier.of(ZomboidMod.MOD_ID, "textures/clothing/" + (variants > 1 ? id + "_" + Math.floorMod(variant, variants) : id) + ".png");
    }

    public Identifier detailTexture(int variant) {
        return Identifier.of(ZomboidMod.MOD_ID, "textures/clothing/" + (variants > 1 ? id + "_" + Math.floorMod(variant, variants) : id) + "_d.png");
    }
}
