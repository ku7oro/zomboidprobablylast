package com.example.zomboidmod.clothing;

import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Одежда в шкафах, магазинах и на зомби (таблицы — в ClothingCatalog). */
public final class ClothingLoot {
    private ClothingLoot() {
    }

    private record E(ClothingDef def, float chance) {
    }

    private static Map<String, List<E>> loot, zombie;

    private static void init() {
        if (loot != null) return;
        Map<String, ClothingDef> byId = new HashMap<>();
        for (ClothingDef d : ClothingCatalog.DEFS) byId.put(d.id(), d);
        loot = new HashMap<>();
        zombie = new HashMap<>();
        for (Object[] r : ClothingCatalog.LOOT)
            loot.computeIfAbsent((String) r[1], k -> new ArrayList<>()).add(new E(byId.get((String) r[0]), (Float) r[2]));
        for (Object[] r : ClothingCatalog.ZOMBIE)
            zombie.computeIfAbsent((String) r[1], k -> new ArrayList<>()).add(new E(byId.get((String) r[0]), (Float) r[2]));
    }

    /** Добавить одежду в контейнер категории (имя категории Loot). */
    public static void fill(String category, Inventory inv, Random r) {
        init();
        List<E> l = loot.get(category);
        if (l == null || inv.size() == 0) return;
        int max = category.equals("CLOTHES") ? 5 : (category.equals("BEDROOM") ? 3 : 2);
        int put = 0;
        for (int k = 0; k < l.size() * 2 && put < max; k++) {
            E e = l.get(r.nextInt(l.size()));
            if (e.def() == null || r.nextFloat() >= e.chance() * 0.55f) continue;
            ItemStack s = ClothingStack.create(e.def(), r);
            if (!category.equals("CLOTHES") && r.nextFloat() < 0.3f) ClothingStack.weather(s, r, 0f, r.nextFloat() * 0.3f, 0);
            inv.setStack(r.nextInt(inv.size()), s);
            put++;
        }
    }

    /** Что сорвать с убитого зомби: его одежда — в крови, грязи и дырах. */
    public static List<ItemStack> fromZombie(String outfit, Random r) {
        init();
        List<ItemStack> out = new ArrayList<>();
        List<E> l = zombie.get(outfit);
        if (l == null) return out;
        for (E e : l) {
            if (e.def() == null || r.nextFloat() >= e.chance() * 0.22f) continue;
            ItemStack s = ClothingStack.create(e.def(), r);
            ClothingStack.weather(s, r, 0.3f + r.nextFloat() * 0.6f, 0.3f + r.nextFloat() * 0.5f, r.nextInt(4));
            out.add(s);
        }
        return out;
    }
}
