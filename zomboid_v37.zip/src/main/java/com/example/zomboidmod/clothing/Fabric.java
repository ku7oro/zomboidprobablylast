package com.example.zomboidmod.clothing;

/** Ткань вещи: из чего выходят лоскуты и какой заплаткой её чинят (по вики PZ: хлопок 5/0, джинса 10/5, кожа 20/10). */
public enum Fabric {
    COTTON("хлопок", 5, 0),
    DENIM("джинса", 10, 5),
    LEATHER("кожа", 20, 10),
    NONE("синтетика", 0, 0);

    public final String title;
    public final int maxScratch, maxBite;

    Fabric(String title, int maxScratch, int maxBite) {
        this.title = title;
        this.maxScratch = maxScratch;
        this.maxBite = maxBite;
    }

    /** Материал заплатки: 1 хлопок, 2 джинса, 3 кожа. */
    public static Fabric ofPatch(int m) {
        return m == 2 ? DENIM : m == 3 ? LEATHER : COTTON;
    }

    public int patchId() {
        return this == DENIM ? 2 : this == LEATHER ? 3 : 1;
    }
}
