package com.example.zomboidmod.survival;

import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.vehicle.Mechanics;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.List;

/**
 * Фонарик на батарейках, как в PZ: ПКМ — включить/выключить, светит туда, куда смотришь (можно держать во второй руке
 * вместе с оружием). Батарейки садятся и во включённом фонарике в рюкзаке. Замена — скрафтить фонарик с батарейкой.
 * С шейдером Knox Dread — настоящий конус света; без шейдеров — пятно света там, куда направлен луч.
 */
public final class Flashlight {
    public static final int BATTERY = 3600;   // секунд работы (3 игровых дня)
    public static Item FLASHLIGHT, FLASHLIGHT_ON;
    public static Block BEAM;

    private Flashlight() {
    }

    public static void register() {
        FLASHLIGHT = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, "flashlight"),
                new FlashlightItem(new Item.Settings().maxCount(1).maxDamage(BATTERY), false));
        FLASHLIGHT_ON = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, "flashlight_on"),
                new FlashlightItem(new Item.Settings().maxCount(1).maxDamage(BATTERY), true));
        BEAM = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, "flashlight_beam"),
                new Mechanics.GlowBlock(AbstractBlock.Settings.create().noCollision().nonOpaque().replaceable().dropsNothing()
                        .breakInstantly().luminance(st -> 9)));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(FLASHLIGHT));
        ServerTickEvents.END_SERVER_TICK.register(Flashlight::tick);
    }

    public static boolean lit(PlayerEntity p) {
        return p.getMainHandStack().isOf(FLASHLIGHT_ON) || p.getOffHandStack().isOf(FLASHLIGHT_ON);
    }

    private static void tick(MinecraftServer server) {
        int t = server.getTicks();
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (t % 4 == 0 && lit(p) && !p.isSpectator()) beam(p);
            if (t % 20 == 0) drain(p);
        }
    }

    /** Пятно света там, куда смотрит игрок (невидимый светящийся блок, гаснет сам через долю секунды). */
    private static void beam(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Vec3d eye = p.getEyePos();
        Vec3d end = eye.add(p.getRotationVec(1f).multiply(22));
        BlockHitResult hit = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        BlockPos bp = hit.getType() == HitResult.Type.BLOCK ? hit.getBlockPos().offset(hit.getSide()) : BlockPos.ofFloored(end);
        light(w, bp);
        // и немного света прямо перед собой, чтобы видеть под ногами
        light(w, BlockPos.ofFloored(eye.add(p.getRotationVec(1f).multiply(2.5))));
    }

    private static void light(ServerWorld w, BlockPos bp) {
        BlockState s = w.getBlockState(bp);
        if (s.isOf(BEAM)) {
            w.setBlockState(bp, s.with(Mechanics.GlowBlock.AGE, 0), Block.NOTIFY_LISTENERS);
        } else if (s.isAir()) {
            w.setBlockState(bp, BEAM.getDefaultState(), Block.NOTIFY_ALL);
            w.scheduleBlockTick(bp, BEAM, 5);
        }
    }

    /** Раз в секунду: включённые фонарики тратят батарейки, где бы они ни лежали. */
    private static void drain(ServerPlayerEntity p) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack st = inv.getStack(i);
            if (!st.isOf(FLASHLIGHT_ON)) continue;
            st.setDamage(st.getDamage() + 1);
            if (st.getDamage() >= st.getMaxDamage() - 1) {
                inv.setStack(i, st.copyComponentsToNewStack(FLASHLIGHT, 1));
                p.sendMessage(Text.literal("Фонарик сел. Скрафтите его с новой батарейкой").formatted(Formatting.GRAY), true);
                p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.PLAYERS, 0.4f, 0.7f);
            }
        }
    }

    public static class FlashlightItem extends Item {
        private final boolean on;

        public FlashlightItem(Settings s, boolean on) {
            super(s);
            this.on = on;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            if (!world.isClient) {
                if (!on && st.getDamage() >= st.getMaxDamage() - 1) {
                    user.sendMessage(Text.literal("Батарейки сели. Скрафтите фонарик с новой батарейкой"), true);
                    return TypedActionResult.fail(st);
                }
                ItemStack other = st.copyComponentsToNewStack(on ? FLASHLIGHT : FLASHLIGHT_ON, 1);
                user.setStackInHand(hand, other);
                world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.PLAYERS, 0.45f, on ? 1.2f : 1.6f);
                return TypedActionResult.success(other, false);
            }
            return TypedActionResult.success(st, true);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(on ? "Включён — ПКМ, чтобы выключить" : "ПКМ — включить").formatted(on ? Formatting.YELLOW : Formatting.GRAY));
            int left = (stack.getMaxDamage() - stack.getDamage()) * 100 / stack.getMaxDamage();
            tooltip.add(Text.literal("Батарейки: " + left + "%").formatted(Formatting.DARK_GRAY));
            tooltip.add(Text.literal("Можно держать во второй руке вместе с оружием").formatted(Formatting.DARK_GRAY));
        }
    }
}
