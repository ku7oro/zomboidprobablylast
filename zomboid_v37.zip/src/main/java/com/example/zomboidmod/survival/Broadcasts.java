package com.example.zomboidmod.survival;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Телевидение и радио. Все тексты оригинальные. Сюжет развивается по дням:
 * сначала обычные новости и слухи, потом карантин, военные, автоматическое оповещение,
 * а после отключения света эфир пустеет — остаются шипение и редкие голоса выживших.
 * Учебная передача по ТВ даёт опыт (кулинария, первая помощь, фермерство), пока есть ток.
 */
public final class Broadcasts {
    private static final Map<Long, Integer> ACTIVE = new HashMap<>();   // включённые ТВ/радио: позиция -> номер строки
    private static final Map<Long, Boolean> IS_TV = new HashMap<>();
    private static int counter;

    private Broadcasts() {
    }

    // ---------- новости (дни 1-3) ----------
    private static final String[] NEWS_EARLY = {
            "«...больницы округа сообщают о наплыве пациентов с высокой температурой. Власти призывают не паниковать.»",
            "«...на трассе у развязки — затор длиной в несколько миль. Полиция перекрыла выезды из округа.»",
            "«...представитель здравоохранения: это сезонный вирус, тяжёлых случаев единицы. Мойте руки.»",
            "«...сообщения о нападениях в нескольких городках. Очевидцы говорят о странном поведении пострадавших.»",
            "«...школы закрыты до конца недели. Родителей просят забрать детей и оставаться дома.»",
            "«...в супермаркетах очереди, полки с консервами и водой пустеют. Магазины ограничивают продажу в одни руки.»",
    };
    // ---------- карантин (дни 4-7) ----------
    private static final String[] NEWS_QUARANTINE = {
            "«...округ объявлен зоной карантина. Въезд и выезд запрещены. Военные установили посты на всех дорогах.»",
            "«...заражённые агрессивны и не реагируют на боль. Не подходите к ним. Заприте двери, закройте окна.»",
            "«...связь с несколькими городами потеряна. Эвакуация отложена до особого распоряжения.»",
            "«...укус или глубокая царапина приводят к заражению. Лекарства пока нет. Повторяем: лекарства нет.»",
            "«...пункты помощи в школах и церквях больше не работают. Не выходите из дома без крайней необходимости.»",
            "«...вертолёты будут облетать округ в поисках выживших. Подавайте знаки только с безопасного места.»",
    };
    // ---------- автоматическое оповещение ----------
    private static final String[] EMERGENCY = {
            "[Автоматическое оповещение] Это система экстренного оповещения. Округ находится на карантине.",
            "[Автоматическое оповещение] Оставайтесь дома. Не открывайте двери посторонним. Запасите воду.",
            "[Автоматическое оповещение] Наберите воду в ванны и ёмкости, пока водопровод работает.",
            "[Автоматическое оповещение] Шум привлекает заражённых. Соблюдайте тишину, особенно ночью.",
            "[Автоматическое оповещение] Помощь не придёт в ближайшее время. Сообщение будет повторено.",
    };
    // ---------- голоса выживших (поздно) ----------
    private static final String[] SURVIVORS = {
            "...кто-нибудь слышит? Нас трое, мы на ферме к северу от реки. Еды хватит на неделю... приём...",
            "...не ходите к военным постам. Там никого нет. Только они. Много...",
            "...если вы слушаете — не стреляйте. Выстрел слышно на полгорода. Ножом, тихо...",
            "...день какой-то там. Сбился со счёта. Генератор тарахтит, они стоят под окнами. Надо уходить...",
            "...собираю всех, кто жив, у водонапорной башни. Ждём до пятницы. Потом уходим на юг...",
            "...(шипение)... повторяю... дороги на запад перекрыты обломками... (шипение)...",
    };
    // ---------- учебная программа на ТВ ----------
    private static final String[][] LESSONS = {
            {"«Ужин за полчаса»: лук пассеруем до золотистого цвета, затем добавляем всё, что найдётся в шкафу...", "COOKING"},
            {"«Ужин за полчаса»: бульон из костей — это сытно и почти ничего не стоит...", "COOKING"},
            {"«Будь готов»: давящую повязку накладывают выше раны, туго, но так, чтобы пальцы не синели...", "FIRST_AID"},
            {"«Будь готов»: рану сначала промывают, потом дезинфицируют, и только потом перевязывают...", "FIRST_AID"},
            {"«Сад круглый год»: картофель любит рыхлую землю и не любит застоя воды...", "FARMING"},
            {"«Сад круглый год»: семена от урожая храните в сухом прохладном месте...", "FARMING"},
    };
    private static final String[] NEWSPAPERS = {
            "Газета: «ВСПЫШКА ГРИППА? Больницы переполнены, врачи советуют сидеть дома». На второй странице — прогноз погоды на неделю.",
            "Газета: «ДОРОГИ ПЕРЕКРЫТЫ. Губернатор обещает навести порядок». Кто-то обвёл ручкой номер горячей линии.",
            "Газета: «ПОГРОМЫ В МАГАЗИНАХ». Фото разбитой витрины. Внизу — объявление о распродаже газонокосилок.",
            "Газета: старый выпуск с кроссвордом. Половина клеток уже заполнена чьим-то аккуратным почерком.",
            "Газета: «ПРОПАЛИ БЕЗ ВЕСТИ». Целая полоса фотографий. Страница смята, будто её долго держали в руках.",
    };

    public static String newspaper(Random r) {
        return NEWSPAPERS[r.nextInt(NEWSPAPERS.length)];
    }

    /** Строка эфира. tv: телевизор (нужен ток), иначе радио. null — тишина/помехи. */
    static String line(boolean tv, int day, SurvivalState st, int idx, Random r) {
        boolean grid = day < st.powerOffDay;
        if (tv) {
            if (!grid) return null;    // телестанции молчат
            if (idx % 3 == 2) return "ТВ: " + LESSONS[(idx / 3) % LESSONS.length][0];
            if (day <= 3) return "ТВ: Новости. " + NEWS_EARLY[idx % NEWS_EARLY.length];
            if (day <= 7) return "ТВ: Экстренный выпуск. " + NEWS_QUARANTINE[idx % NEWS_QUARANTINE.length];
            return "ТВ: " + EMERGENCY[idx % EMERGENCY.length];
        }
        if (day <= 3) return "Радио: " + NEWS_EARLY[idx % NEWS_EARLY.length];
        if (day <= 7) return "Радио: " + NEWS_QUARANTINE[idx % NEWS_QUARANTINE.length];
        if (day < st.powerOffDay + 3 && r.nextFloat() < 0.75f) return "Радио: " + EMERGENCY[idx % EMERGENCY.length];
        if (day >= 10 && r.nextFloat() < 0.35f) return "Радио (любитель): " + SURVIVORS[r.nextInt(SURVIVORS.length)];
        return null;
    }

    public static void toggle(ServerPlayerEntity p, ServerWorld w, BlockPos pos, boolean tv) {
        long key = pos.asLong();
        if (ACTIVE.remove(key) != null) {
            IS_TV.remove(key);
            p.sendMessage(Text.literal(tv ? "Телевизор выключен" : "Радио выключено"), true);
            return;
        }
        if (!Power.powered(w, pos)) {
            p.sendMessage(Text.literal("Нет электричества"), true);
            return;
        }
        ACTIVE.put(key, counter++ * 7);
        IS_TV.put(key, tv);
        p.sendMessage(Text.literal(tv ? "Телевизор включён" : "Радио включено"), true);
        w.playSound(null, pos, SurvivalSounds.RADIO_STATIC, SoundCategory.BLOCKS, 0.6f, 1f);
    }

    /** Раз в секунду: каждые 12 секунд новая строка эфира. */
    public static void second(MinecraftServer server, SurvivalState st, long now) {
        ServerWorld w = server.getOverworld();
        int day = Clock.day(now);
        boolean speak = server.getTicks() % 240 == 0;
        // стационарные ТВ и радио
        List<Long> off = new ArrayList<>();
        for (Map.Entry<Long, Integer> e : ACTIVE.entrySet()) {
            BlockPos pos = BlockPos.fromLong(e.getKey());
            if (!w.isChunkLoaded(pos)) continue;
            boolean tv = IS_TV.getOrDefault(e.getKey(), true);
            if (!Power.powered(w, pos)) {
                off.add(e.getKey());
                continue;
            }
            if (server.getTicks() % 100 == 0) Noise.emitAt(w, pos, 10);
            if (!speak) continue;
            int idx = e.getValue();
            e.setValue(idx + 1);
            String l = line(tv, day, st, idx, w.random);
            for (ServerPlayerEntity p : w.getPlayers(pl -> pl.getBlockPos().isWithinDistance(pos, 10))) {
                hear(p, st, l, tv, idx);
            }
            if (l == null) w.playSound(null, pos, SurvivalSounds.RADIO_STATIC, SoundCategory.BLOCKS, 0.5f, 1f);
        }
        for (Long k : off) {
            ACTIVE.remove(k);
            IS_TV.remove(k);
        }
        // портативные радио в инвентаре
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            for (ItemStack s : p.getInventory().main) {
                if (!(s.getItem() instanceof SurvivalItems.RadioItem) || !SurvivalItems.RadioItem.on(s)) continue;
                if (!p.isCreative()) s.setDamage(Math.min(s.getMaxDamage() - 1, s.getDamage() + 1));
                if (s.getDamage() >= s.getMaxDamage() - 1) {
                    net.minecraft.component.type.NbtComponent.set(net.minecraft.component.DataComponentTypes.CUSTOM_DATA, s, nbt -> nbt.putBoolean("on", false));
                    p.sendMessage(Text.literal("Радио замолчало: сели батарейки"), true);
                    continue;
                }
                if (server.getTicks() % 100 == 0) Noise.emitFrom(p, 6);
                if (speak) {
                    int idx = (int) (now / 240);
                    String l = line(false, day, st, idx, p.getRandom());
                    hear(p, st, l, false, idx);
                    if (l == null) p.getServerWorld().playSound(null, p.getBlockPos(), SurvivalSounds.RADIO_STATIC, SoundCategory.PLAYERS, 0.4f, 1f);
                }
                break;
            }
        }
    }

    private static void hear(ServerPlayerEntity p, SurvivalState st, String l, boolean tv, int idx) {
        Mood m = st.mood(p.getUuid());
        if (l == null) {
            p.sendMessage(Text.literal(tv ? "ТВ: (рябь на экране)" : "Радио: (шипение)").formatted(Formatting.DARK_GRAY), true);
            return;
        }
        p.sendMessage(Text.literal(l).formatted(Formatting.GRAY, Formatting.ITALIC), false);
        m.boredom = Math.max(0f, m.boredom - (tv ? 4f : 2.5f));
        if (tv && idx % 3 == 2) {
            PzSkill s = PzSkill.valueOf(LESSONS[(idx / 3) % LESSONS.length][1]);
            Skills.addXp(p, s, 6f);
        }
    }
}
