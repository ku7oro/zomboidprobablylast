package com.example.zomboidmod.survival;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

/** Бумажная карта округа: города, деревни, фермы, лесные хижины и шоссе. Тащить мышью, колесо — масштаб. */
public class MapScreen extends Screen {
    private final NbtCompound d;
    private double camX, camZ;
    private float zoom = 0.18f;   // пикселей на блок

    private static final int PAPER = 0xFFE3D5B2, PAPER_D = 0xFFCDBE97, INK = 0xFF3A2E22, ROAD = 0xFF8C7456;

    public MapScreen(NbtCompound d) {
        super(Text.literal("Карта округа"));
        this.d = d;
        camX = d.getInt("px");
        camZ = d.getInt("pz");
        if (d.contains("fx")) {        // открыли карту тайника — сразу на тайнике
            camX = d.getInt("fx");
            camZ = d.getInt("fz");
            zoom = 0.6f;
        }
    }

    /** Значок найденного места: цвет по виду. */
    private static int poiColor(int k) {
        return switch (k) {
            case 3, 4 -> 0xFF4A5A2A;          // военные: вертолёт, лагерь
            case 11 -> 0xFFB8860B;            // тайник
            case 12, 13, 14, 15, 16 -> 0xFF6A4A2A;   // у дороги
            case 17, 18 -> 0xFF2A3A6A;        // кордон, авария
            default -> 0xFF5A3A2A;
        };
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int sx(double x) {
        return (int) Math.round(width / 2.0 + (x - camX) * zoom);
    }

    private int sz(double z) {
        return (int) Math.round(height / 2.0 + (z - camZ) * zoom);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int m = 14, x1 = m, y1 = m, x2 = width - m, y2 = height - m;
        ctx.fill(x1 - 3, y1 - 3, x2 + 3, y2 + 3, 0xFF5A4630);
        ctx.fill(x1, y1, x2, y2, PAPER);
        ctx.enableScissor(x1, y1, x2, y2);
        // бумажные пятна и сетка каждые 256 блоков
        int region = Math.max(64, d.getInt("region") / 2);
        double gx0 = Math.floor((camX - width / 2.0 / zoom) / region) * region;
        double gz0 = Math.floor((camZ - height / 2.0 / zoom) / region) * region;
        for (double gx = gx0; sx(gx) < x2; gx += region) ctx.fill(sx(gx), y1, sx(gx) + 1, y2, PAPER_D);
        for (double gz = gz0; sz(gz) < y2; gz += region) ctx.fill(x1, sz(gz), x2, sz(gz) + 1, PAPER_D);

        // шоссе: ломаные
        int rw = Math.max(2, Math.round(7 * zoom));
        NbtList roads = d.getList("rl", NbtElement.INT_ARRAY_TYPE);
        for (int i = 0; i < roads.size(); i++) {
            int[] pts = roads.getIntArray(i);
            for (int k = 0; k + 3 < pts.length; k += 2) line(ctx, pts[k], pts[k + 1], pts[k + 2], pts[k + 3], rw, ROAD);
        }
        // поселения
        NbtList list = d.getList("s", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < list.size(); i++) {
            NbtCompound s = list.getCompound(i);
            int t = s.getInt("t");
            int[] r = s.getIntArray("r");
            if (t == 0) {          // лес
                int cx = s.getInt("x"), cz = s.getInt("z"), rad = s.getInt("size");
                for (int k = -rad; k <= rad; k += 6) {
                    int half = (int) Math.sqrt(Math.max(0, rad * rad - k * k));
                    ctx.fill(sx(cx - half), sz(cz + k), sx(cx + half), sz(cz + k + 6), 0xFF8FA37A);
                }
                if (r.length >= 4) ctx.fill(sx(r[0]), sz(r[1]), sx(r[2]) + 1, sz(r[3]) + 1, 0xFF6B4E33);
                continue;
            }
            int fill = t == 7 ? 0xFF7E8660 : t == 8 ? 0xFF8E8C88 : t == 9 ? 0xFFB4C2C6 : t == 10 ? 0xFFC4A27C : t == 5 ? 0xFF9C7A60 : t == 4 ? 0xFFA88468 : t == 3 ? 0xFFB8977A : t == 2 ? 0xFFC9AE88 : 0xFFAFBF85;
            for (int k = 0; k + 3 < r.length; k += 4) {
                int ax = sx(r[k]), az = sz(r[k + 1]), bx = sx(r[k + 2] + 1), bz = sz(r[k + 3] + 1);
                ctx.fill(ax, az, bx, bz, fill);
                ctx.drawBorder(ax, az, bx - ax, bz - az, INK);
                // кварталы (у мегаполиса — сетка проспектов)
                if (t == 5) {
                    int g = s.getInt("grid");
                    for (int gx = r[k] + 16; gx <= r[k + 2]; gx += g) ctx.fill(sx(gx), az + 1, sx(gx) + Math.max(1, Math.round(5 * zoom)), bz - 1, 0x60000000);
                    for (int gz = r[k + 1] + 16; gz <= r[k + 3]; gz += g) ctx.fill(ax + 1, sz(gz), bx - 1, sz(gz) + Math.max(1, Math.round(5 * zoom)), 0x60000000);
                } else if (t >= 2 && t <= 4) {
                    int step = Math.max(4, Math.round(36 * zoom));
                    for (int qx = ax + step; qx < bx - 1; qx += step) ctx.fill(qx, az + 1, qx + 1, bz - 1, 0x40000000);
                    for (int qz = az + step; qz < bz - 1; qz += step) ctx.fill(ax + 1, qz, bx - 1, qz + 1, 0x40000000);
                }
            }
        }
        for (int i = 0; i < list.size(); i++) {
            NbtCompound s = list.getCompound(i);
            int t = s.getInt("t");
            if (t == 0 && zoom < 0.3f) continue;
            String kind = switch (t) {
                case 10, 9, 8, 7, 5, 4, 3 -> "";
                case 2 -> " (дер.)";
                case 1 -> " (фермы)";
                default -> " (лес)";
            };
            String name = (t == 4 || t == 5 ? s.getString("n").toUpperCase() : s.getString("n")) + kind;
            if (t == 5) {   // мегаполис — крупно
                ctx.getMatrices().push();
                ctx.getMatrices().translate(sx(s.getInt("x")), sz(s.getInt("z")), 0);
                ctx.getMatrices().scale(2f, 2f, 1f);
                ctx.drawText(textRenderer, name, -textRenderer.getWidth(name) / 2, -4, 0xFF1E140C, false);
                ctx.getMatrices().pop();
                continue;
            }
            int tx = sx(s.getInt("x")) - textRenderer.getWidth(name) / 2, ty = sz(s.getInt("z")) - 4;
            ctx.drawText(textRenderer, name, tx, ty, t >= 3 ? 0xFF1E140C : INK, false);
        }
        // найденные места
        NbtList pois = d.getList("p", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < pois.size(); i++) {
            NbtCompound c = pois.getCompound(i);
            int x = sx(c.getInt("x")), z = sz(c.getInt("z")), col = poiColor(c.getInt("k"));
            ctx.fill(x - 3, z - 3, x + 4, z + 4, 0xFF2A2018);
            ctx.fill(x - 2, z - 2, x + 3, z + 3, col);
            if (zoom >= 0.35f) {
                String nm = c.getString("n");
                ctx.drawText(textRenderer, nm, x - textRenderer.getWidth(nm) / 2, z + 6, 0xFF4A3A2A, false);
            }
        }
        // тайники с карт тайников — красный крестик, как нарисованный от руки
        NbtList marks = d.getList("m", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < marks.size(); i++) {
            NbtCompound c = marks.getCompound(i);
            int x = sx(c.getInt("x")), z = sz(c.getInt("z"));
            for (int k = -4; k <= 4; k++) {
                ctx.fill(x + k, z + k, x + k + 2, z + k + 2, 0xFFB01818);
                ctx.fill(x + k, z - k, x + k + 2, z - k + 2, 0xFFB01818);
            }
            String nm = "Тайник";
            ctx.drawText(textRenderer, nm, x - textRenderer.getWidth(nm) / 2, z + 8, 0xFF8A1010, false);
        }
        // игрок
        int px = sx(d.getInt("px")), pz = sz(d.getInt("pz"));
        float yaw = d.getFloat("yaw") * MathHelper.RADIANS_PER_DEGREE;
        for (int k = 0; k < 7; k++) {
            int ox = (int) Math.round(-MathHelper.sin(yaw) * k), oz = (int) Math.round(MathHelper.cos(yaw) * k);
            ctx.fill(px + ox - 1, pz + oz - 1, px + ox + 2, pz + oz + 2, 0xFFB01818);
        }
        ctx.fill(px - 3, pz - 3, px + 4, pz + 4, 0xFFB01818);
        ctx.fill(px - 2, pz - 2, px + 3, pz + 3, 0xFFF0E0D0);
        ctx.disableScissor();
        // масштаб и подсказка
        int bar = Math.round(256 * zoom);
        ctx.fill(x1 + 8, y2 - 12, x1 + 8 + bar, y2 - 10, INK);
        ctx.drawText(textRenderer, "256 бл.", x1 + 12 + bar, y2 - 15, INK, false);
        String title = "Округ — карта местности";
        ctx.drawText(textRenderer, title, width / 2 - textRenderer.getWidth(title) / 2, y1 + 6, INK, false);
        String hint = "Колесо — масштаб · квадраты — найденные места · крестики — тайники";
        ctx.drawText(textRenderer, hint, x2 - textRenderer.getWidth(hint) - 8, y2 - 15, 0xFF6A5A44, false);
    }

    /** Толстая линия из квадратиков (дорога на карте). */
    private void line(DrawContext ctx, int x1, int z1, int x2, int z2, int w, int col) {
        double len = Math.hypot(x2 - x1, z2 - z1);
        int steps = Math.max(1, (int) Math.ceil(len * zoom / Math.max(1, w / 2.0)));
        for (int i = 0; i <= steps; i++) {
            double f = i / (double) steps;
            int px = sx(x1 + (x2 - x1) * f), pz = sz(z1 + (z2 - z1) * f);
            ctx.fill(px - w / 2, pz - w / 2, px - w / 2 + w, pz - w / 2 + w, col);
        }
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        camX -= deltaX / zoom;
        camZ -= deltaY / zoom;
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        zoom = MathHelper.clamp(zoom * (verticalAmount > 0 ? 1.25f : 0.8f), 0.04f, 2.0f);
        return true;
    }
}
