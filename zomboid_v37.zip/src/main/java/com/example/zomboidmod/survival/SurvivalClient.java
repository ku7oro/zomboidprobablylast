package com.example.zomboidmod.survival;

import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;

/** Клиент: состояние персонажа для мудлов, звук вертолёта, карта, свежесть еды в подсказке, затемнение от усталости. */
public final class SurvivalClient {
    public static float fatigue, endurance = 1f, boredom, unhappy, panic, stress, temp = 37f, wet, felt = 20f, foodSick, drunk;
    public static boolean cold, power = true, water = true;
    public static int day = 1;
    public static float fog;
    private static HeliSound heli;

    private SurvivalClient() {
    }

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(MoodPayload.ID, (payload, ctx) -> ctx.client().execute(() -> read(payload.data())));
        ClientPlayNetworking.registerGlobalReceiver(WorldEvents.HeliPayload.ID, (payload, ctx) -> ctx.client().execute(() -> heli(ctx.client(), payload.data())));
        ClientPlayNetworking.registerGlobalReceiver(WorldEvents.MapPayload.ID,
                (payload, ctx) -> ctx.client().execute(() -> ctx.client().setScreen(new MapScreen(payload.data()))));
        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            MinecraftClient c = MinecraftClient.getInstance();
            if (c.world != null) Food.tooltip(stack, Clock.now(c.world), lines);
        });
    }

    private static void read(NbtCompound n) {
        fatigue = n.getFloat("fat");
        endurance = n.getFloat("end");
        boredom = n.getFloat("bor");
        unhappy = n.getFloat("unh");
        panic = n.getFloat("pan");
        stress = n.getFloat("str");
        temp = n.getFloat("tmp");
        wet = n.getFloat("wet");
        cold = n.getFloat("cold") > 0;
        foodSick = n.getFloat("fsick");
        drunk = n.getFloat("drunk");
        felt = n.getFloat("felt");
        power = n.getBoolean("power");
        water = n.getBoolean("water");
        day = n.getInt("day");
        fog = n.getFloat("fog");
    }

    private static void heli(MinecraftClient c, NbtCompound n) {
        if (!n.getBoolean("on")) {
            if (heli != null) heli.stop = true;
            heli = null;
            return;
        }
        if (heli == null || heli.isDone()) {
            heli = new HeliSound(n.getDouble("x"), n.getDouble("y"), n.getDouble("z"));
            c.getSoundManager().play(heli);
        }
        heli.tx = n.getDouble("x");
        heli.ty = n.getDouble("y");
        heli.tz = n.getDouble("z");
    }

    public static void tick(MinecraftClient c) {
        if (c.player == null || c.player.isCreative()) return;
        // без сил не побежишь
        if (Mood.exertion(endurance) >= 3 && c.player.isSprinting()) c.player.setSprinting(false);
        // сердце колотится от паники
        int pl = Mood.panic(panic);
        if (pl >= 3 && c.player.age % (pl == 4 ? 12 : 18) == 0)
            c.player.playSound(SoundEvents.ENTITY_WARDEN_HEARTBEAT, pl == 4 ? 0.9f : 0.55f, 1.15f);
    }

    /** Затемнение по краям экрана: усталость (веки тяжелеют), переохлаждение (иней), паника. */
    public static void overlay(DrawContext ctx, MinecraftClient c) {
        if (c.player == null || c.player.isCreative() || c.player.isSpectator()) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int tired = Mood.tired(fatigue);
        if (tired >= 2) {
            float pulse = tired >= 4 ? 0.5f + 0.5f * MathHelper.sin(c.player.age * 0.08f) : 1f;
            int a = (int) ((tired - 1) * 40 * pulse);
            vignette(ctx, w, h, a, 0x000000);
        }
        if (Mood.hypo(temp) >= 2) vignette(ctx, w, h, (Mood.hypo(temp) - 1) * 35, 0xA8C8E8);
        if (Mood.panic(panic) >= 3) vignette(ctx, w, h, (Mood.panic(panic) - 2) * 30, 0x400000);
        // часы в инвентаре — видно дату и время, как наручные часы в PZ
        if (c.player.getInventory().contains(new net.minecraft.item.ItemStack(net.minecraft.item.Items.CLOCK)) && c.world != null) {
            String t = "День " + Clock.day(c.world) + " · " + Clock.date(c.world) + String.format(" · %+.0f°C", felt);
            ctx.fill(4, 4, 10 + c.textRenderer.getWidth(t), 16, 0x90101010);
            ctx.drawText(c.textRenderer, t, 7, 6, 0xFFE8E2C8, false);
        }
    }

    public static void vignette(DrawContext ctx, int w, int h, int alpha, int rgb) {
        alpha = MathHelper.clamp(alpha, 0, 200);
        int edge = (alpha << 24) | rgb, clear = rgb;
        int t = h / 4, s = w / 6;
        ctx.fillGradient(0, 0, w, t, edge, clear);
        ctx.fillGradient(0, h - t, w, h, clear, edge);
        for (int i = 0; i < s; i += 2) {
            int a = alpha * (s - i) / s;
            ctx.fill(i, 0, i + 2, h, (a << 24) | rgb);
            ctx.fill(w - i - 2, 0, w - i, h, (a << 24) | rgb);
        }
    }

    /** Гул вертолёта: его никогда не видно, только слышно, и звук идёт с его стороны. */
    static final class HeliSound extends MovingSoundInstance {
        double tx, ty, tz;
        boolean stop;

        HeliSound(double x, double y, double z) {
            super(SurvivalSounds.HELICOPTER, SoundCategory.AMBIENT, SoundInstance.createRandom());
            this.repeat = true;
            this.repeatDelay = 0;
            this.attenuationType = SoundInstance.AttenuationType.NONE;
            this.x = tx = x;
            this.y = ty = y;
            this.z = tz = z;
            this.volume = 0.01f;
        }

        @Override
        public void tick() {
            MinecraftClient c = MinecraftClient.getInstance();
            if (stop || c.player == null) {
                setDone();
                return;
            }
            x += (tx - x) * 0.05;
            y += (ty - y) * 0.05;
            z += (tz - z) * 0.05;
            double d = Math.sqrt(c.player.squaredDistanceTo(x, y, z));
            volume = (float) MathHelper.clamp(1.4 - d / 180.0, 0.0, 1.2);
            pitch = 1f;
        }
    }
}
