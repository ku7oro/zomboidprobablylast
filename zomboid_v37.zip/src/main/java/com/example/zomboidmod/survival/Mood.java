package com.example.zomboidmod.survival;

import net.minecraft.nbt.NbtCompound;

/**
 * Состояние персонажа, как в Project Zomboid: усталость, выносливость, скука, грусть, паника, стресс,
 * температура тела и промокание, простуда, пищевое отравление, опьянение.
 */
public final class Mood {
    public float fatigue;          // 0..1 (0.6 — «Хочется спать»)
    public float endurance = 1f;   // 0..1
    public float boredom;          // 0..100
    public float unhappy;          // 0..100
    public float panic;            // 0..100
    public float stress;           // 0..100
    public float temp = 37f;       // температура тела, °C
    public float wet;              // 0..100
    public float cold;             // простуда: сколько секунд ещё болеть
    public float foodSick;         // пищевое отравление 0..100
    public float drunk;            // опьянение 0..100
    public int kills;              // убито зомби (паника слабеет с опытом)
    // не сохраняется
    public transient long lastFight = -1000;
    public transient long lastTime = -1;
    public transient long sleepApplied;
    public transient float felt = 20f;    // ощущаемая температура воздуха
    public transient float thirstAcc, sneezeIn = 40;

    public NbtCompound write() {
        NbtCompound n = new NbtCompound();
        n.putFloat("fat", fatigue);
        n.putFloat("end", endurance);
        n.putFloat("bor", boredom);
        n.putFloat("unh", unhappy);
        n.putFloat("pan", panic);
        n.putFloat("str", stress);
        n.putFloat("tmp", temp);
        n.putFloat("wet", wet);
        n.putFloat("cold", cold);
        n.putFloat("fsick", foodSick);
        n.putFloat("drunk", drunk);
        n.putInt("kills", kills);
        return n;
    }

    public static Mood read(NbtCompound n) {
        Mood m = new Mood();
        m.fatigue = n.getFloat("fat");
        m.endurance = n.contains("end") ? n.getFloat("end") : 1f;
        m.boredom = n.getFloat("bor");
        m.unhappy = n.getFloat("unh");
        m.panic = n.getFloat("pan");
        m.stress = n.getFloat("str");
        m.temp = n.contains("tmp") ? n.getFloat("tmp") : 37f;
        m.wet = n.getFloat("wet");
        m.cold = n.getFloat("cold");
        m.foodSick = n.getFloat("fsick");
        m.drunk = n.getFloat("drunk");
        m.kills = n.getInt("kills");
        return m;
    }

    // ===== уровни мудлов (0 — нет, 1..4) =====
    public static int tired(float f) {
        return f >= 0.9f ? 4 : f >= 0.8f ? 3 : f >= 0.7f ? 2 : f >= 0.6f ? 1 : 0;
    }

    public static int exertion(float e) {
        return e < 0.1f ? 4 : e < 0.25f ? 3 : e < 0.5f ? 2 : e < 0.75f ? 1 : 0;
    }

    public static int bored(float b) {
        return b >= 90 ? 4 : b >= 75 ? 3 : b >= 50 ? 2 : b >= 25 ? 1 : 0;
    }

    public static int unhappy(float u) {
        return u >= 80 ? 4 : u >= 60 ? 3 : u >= 40 ? 2 : u >= 20 ? 1 : 0;
    }

    public static int panic(float p) {
        return p >= 80 ? 4 : p >= 60 ? 3 : p >= 30 ? 2 : p >= 6 ? 1 : 0;
    }

    public static int stress(float s) {
        return s >= 90 ? 4 : s >= 75 ? 3 : s >= 50 ? 2 : s >= 25 ? 1 : 0;
    }

    public static int wet(float w) {
        return w >= 90 ? 4 : w >= 70 ? 3 : w >= 40 ? 2 : w >= 15 ? 1 : 0;
    }

    /** Переохлаждение: 1 зябко, 2 холодно, 3 замерзает, 4 гипотермия. */
    public static int hypo(float t) {
        return t < 33.5f ? 4 : t < 34.5f ? 3 : t < 35.5f ? 2 : t < 36.5f ? 1 : 0;
    }

    /** Перегрев: 1 тепло, 2 жарко, 3 перегрев, 4 тепловой удар. */
    public static int hyper(float t) {
        return t > 40.5f ? 4 : t > 39.5f ? 3 : t > 38.5f ? 2 : t > 37.5f ? 1 : 0;
    }

    public static int foodSick(float f) {
        return f >= 75 ? 4 : f >= 50 ? 3 : f >= 25 ? 2 : f >= 8 ? 1 : 0;
    }

    public static int drunk(float d) {
        return d >= 80 ? 4 : d >= 55 ? 3 : d >= 30 ? 2 : d >= 10 ? 1 : 0;
    }
}
