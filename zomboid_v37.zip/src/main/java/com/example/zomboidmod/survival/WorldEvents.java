package com.example.zomboidmod.survival;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.ZombieOutfit;
import com.example.zomboidmod.ZomboidEntities;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.vehicle.VehicleEntity;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.List;

/**
 * События мира: бродячие орды раз в 2-3 дня, вертолёт на 6-9 день (его не видно, только слышно; если заметит игрока
 * на улице — летит за ним и стягивает зомби со всей округи), ключи от машин в карманах зомби, карта округа.
 */
public final class WorldEvents {
    private WorldEvents() {
    }

    public record MapPayload(NbtCompound data) implements CustomPayload {
        public static final CustomPayload.Id<MapPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "knox_map"));
        public static final PacketCodec<RegistryByteBuf, MapPayload> CODEC =
                PacketCodec.tuple(PacketCodecs.NBT_COMPOUND, MapPayload::data, MapPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public record HeliPayload(NbtCompound data) implements CustomPayload {
        public static final CustomPayload.Id<HeliPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "heli"));
        public static final PacketCodec<RegistryByteBuf, HeliPayload> CODEC =
                PacketCodec.tuple(PacketCodecs.NBT_COMPOUND, HeliPayload::data, HeliPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    // ===================== орды =====================
    private record Walker(PzZombieEntity z, ServerPlayerEntity target, long until) {}

    private static final List<Walker> HORDE = new ArrayList<>();

    /** Орда из 12+2·день зомби (до 50) выходит из-за горизонта и бредёт к игроку. */
    public static void horde(MinecraftServer server, int day) {
        ServerWorld w = server.getOverworld();
        Random r = w.random;
        for (ServerPlayerEntity p : w.getPlayers(pl -> !pl.isCreative() && !pl.isSpectator() && pl.isAlive())) {
            int size = Math.min(50, 12 + day * 2);
            BlockPos spot = null;
            for (int t = 0; t < 12 && spot == null; t++) {
                double a = r.nextDouble() * Math.PI * 2, d = 44 + r.nextInt(20);
                int x = (int) (p.getX() + Math.cos(a) * d), z = (int) (p.getZ() + Math.sin(a) * d);
                if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
                BlockPos b = new BlockPos(x, y, z);
                if (!w.getFluidState(b.down()).isEmpty()) continue;
                spot = b;
            }
            if (spot == null) continue;
            long until = Clock.now(w) + 4000;
            int made = 0;
            for (int i = 0; i < size; i++) {
                int x = spot.getX() + r.nextInt(13) - 6, z = spot.getZ() + r.nextInt(13) - 6;
                if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
                PzZombieEntity zombie = ZomboidEntities.PZ_ZOMBIE.create(w);
                if (zombie == null) continue;
                zombie.refreshPositionAndAngles(x + 0.5, y, z + 0.5, r.nextFloat() * 360f, 0f);
                zombie.setup(ZombieOutfit.random(r));
                zombie.setPersistent();
                w.spawnEntity(zombie);
                zombie.hear(p.getBlockPos());
                HORDE.add(new Walker(zombie, p, until));
                made++;
            }
            if (made == 0) continue;
            double dx = spot.getX() - p.getX(), dz = spot.getZ() - p.getZ(), len = Math.max(1, Math.hypot(dx, dz));
            w.playSound(null, BlockPos.ofFloored(p.getX() + dx / len * 18, p.getY(), p.getZ() + dz / len * 18),
                    SurvivalSounds.HORDE, SoundCategory.HOSTILE, 4f, 0.9f);
            p.sendMessage(Text.literal("Вдалеке нарастает многоголосый стон... Сюда идёт орда.").formatted(Formatting.DARK_RED), false);
        }
    }

    // ===================== вертолёт =====================
    private static final class Heli {
        double x, z, tx, tz, y;
        ServerPlayerEntity target;
        int ticksLeft;
        boolean spotted;
        int hidden;
    }

    private static Heli heli;

    public static void startHeli(MinecraftServer server, SurvivalState st) {
        ServerWorld w = server.getOverworld();
        List<ServerPlayerEntity> ps = w.getPlayers(pl -> !pl.isSpectator() && pl.isAlive());
        st.heliDone = true;
        st.markDirty();
        if (ps.isEmpty()) return;
        Heli h = new Heli();
        h.target = ps.get(w.random.nextInt(ps.size()));
        double a = w.random.nextDouble() * Math.PI * 2;
        h.x = h.target.getX() + Math.cos(a) * 160;
        h.z = h.target.getZ() + Math.sin(a) * 160;
        h.tx = h.target.getX() + w.random.nextInt(80) - 40;
        h.tz = h.target.getZ() + w.random.nextInt(80) - 40;
        h.ticksLeft = st.heliHours * Clock.HOUR;
        heli = h;
        for (ServerPlayerEntity p : ps)
            p.sendMessage(Text.literal("Где-то высоко над округом гудит вертолёт...").formatted(Formatting.GOLD), false);
    }

    public static void tick(MinecraftServer server) {
        // орда идёт за игроком, даже если тот отошёл
        if (server.getTicks() % 100 == 0 && !HORDE.isEmpty()) {
            long now = Clock.now(server.getOverworld());
            HORDE.removeIf(wk -> wk.z().isRemoved() || !wk.z().isAlive() || wk.target().isRemoved() || now > wk.until());
            for (Walker wk : HORDE) if (wk.z().getTarget() == null) wk.z().hear(wk.target().getBlockPos());
        }
        Heli h = heli;
        if (h == null) return;
        ServerWorld w = server.getOverworld();
        if (h.target == null || h.target.isRemoved() || h.target.getWorld() != w) {
            List<ServerPlayerEntity> ps = w.getPlayers(pl -> !pl.isSpectator() && pl.isAlive());
            if (ps.isEmpty()) {
                endHeli(server);
                return;
            }
            h.target = ps.get(0);
        }
        ServerPlayerEntity t = h.target;
        h.y = t.getY() + 40;
        double dx = h.tx - h.x, dz = h.tz - h.z, d = Math.hypot(dx, dz);
        double speed = h.spotted ? 0.45 : 0.32;
        if (d < 3) {
            if (h.spotted) {
                h.tx = t.getX();
                h.tz = t.getZ();
            } else {
                h.tx = t.getX() + w.random.nextInt(120) - 60;
                h.tz = t.getZ() + w.random.nextInt(120) - 60;
            }
        } else {
            h.x += dx / d * speed;
            h.z += dz / d * speed;
        }
        if (h.spotted && server.getTicks() % 20 == 0) {
            h.tx = t.getX();
            h.tz = t.getZ();
        }
        if (server.getTicks() % 20 == 0) {
            boolean outside = w.isSkyVisible(t.getBlockPos().up());
            double hd = Math.hypot(t.getX() - h.x, t.getZ() - h.z);
            if (!h.spotted && outside && hd < 40 && !t.isCreative()) {
                h.spotted = true;
                h.hidden = 0;
                t.sendMessage(Text.literal("Вертолёт заметил вас! Гул становится всё ближе...").formatted(Formatting.RED), false);
            }
            if (h.spotted) {
                h.hidden = outside ? 0 : h.hidden + 1;
                if (h.hidden > 30) {
                    h.spotted = false;
                    t.sendMessage(Text.literal("Похоже, вертолёт потерял вас из виду").formatted(Formatting.GRAY), true);
                }
            }
            // шум винтов стягивает зомби к точке под вертолётом
            if (server.getTicks() % 40 == 0) {
                BlockPos ground = BlockPos.ofFloored(h.x, t.getY(), h.z);
                Noise.emitAt(w, ground, 60);
            }
            NbtCompound n = new NbtCompound();
            n.putBoolean("on", true);
            n.putDouble("x", h.x);
            n.putDouble("y", h.y);
            n.putDouble("z", h.z);
            for (ServerPlayerEntity p : w.getPlayers()) ServerPlayNetworking.send(p, new HeliPayload(n));
        }
        if (--h.ticksLeft <= 0) endHeli(server);
    }

    private static void endHeli(MinecraftServer server) {
        heli = null;
        NbtCompound n = new NbtCompound();
        n.putBoolean("on", false);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            ServerPlayNetworking.send(p, new HeliPayload(n));
            p.sendMessage(Text.literal("Гул вертолёта стихает вдали.").formatted(Formatting.GRAY), true);
        }
    }

    // ===================== туман =====================
    /** Плотность тумана 0..1 (как погодные туманы PZ): утренний туман, туман в дождь, иногда густой дневной. */
    public static float fog;
    private static float fogTarget;
    private static long fogUntil;
    private static int lastHour = -1;

    public static void forceFog(ServerWorld w, float density, int hours) {
        fogTarget = density;
        fogUntil = Clock.now(w) + (long) hours * Clock.HOUR;
    }

    private static void weather(ServerWorld w, long now, float hour) {
        int h = (int) hour;
        if (h != lastHour) {
            lastHour = h;
            int doy = Clock.dayOfYear(w);
            boolean autumn = doy >= 244 && doy < 335;
            Random r = w.random;
            if (now > fogUntil) {
                if (h >= 3 && h <= 7 && r.nextFloat() < (autumn ? 0.45f : 0.25f)) forceFog(w, 0.55f + r.nextFloat() * 0.45f, 3 + r.nextInt(4));
                else if (r.nextFloat() < (autumn ? 0.05f : 0.025f)) forceFog(w, 0.4f + r.nextFloat() * 0.5f, 2 + r.nextInt(5));
            }
        }
        float target = now < fogUntil ? fogTarget : 0f;
        if (w.isRaining()) target = Math.max(target, w.isThundering() ? 0.5f : 0.3f);
        fog += MathHelper.clamp(target - fog, -0.01f, 0.01f);
    }

    /** Раз в секунду: пора ли орде или вертолёту. */
    public static void second(MinecraftServer server, SurvivalState st, long now) {
        ServerWorld w = server.getOverworld();
        int day = Clock.day(now);
        float hour = Clock.hour(w);
        weather(w, now, hour);
        if (st.nextHordeDay > 0 && (day > st.nextHordeDay || (day == st.nextHordeDay && hour >= st.hordeHour))) {
            horde(server, day);
            st.nextHordeDay = day + 2 + w.random.nextInt(2);
            st.hordeHour = 18 + w.random.nextInt(6);
            st.markDirty();
        }
        if (!st.heliDone && heli == null) {
            if (day > st.heliDay) {
                st.heliDone = true;
                st.markDirty();
            } else if (day == st.heliDay && hour >= st.heliHour && hour < 19) {
                startHeli(server, st);
            }
        }
    }

    // ===================== ключи =====================
    /** У зомби рядом с запертой машиной в кармане может оказаться её ключ. */
    public static void onZombieDeath(PzZombieEntity z) {
        if (!(z.getWorld() instanceof ServerWorld w)) return;
        for (VehicleEntity v : w.getEntitiesByClass(VehicleEntity.class, new Box(z.getBlockPos()).expand(48), e -> e.keyLoc == VehicleEntity.KEY_ZOMBIE)) {
            if (w.random.nextFloat() < 0.3f) {
                z.dropStack(SurvivalItems.CarKeyItem.make(v.keyId, v.type.ru));
                v.keyLoc = VehicleEntity.KEY_NONE;
            }
            return;
        }
    }

    // ===================== карта =====================
    public static void openMap(ServerPlayerEntity p) {
        openMap(p, Integer.MIN_VALUE, 0);
    }

    /** Карта; (fx, fz) — точка, на которой её открыть (тайник с карты тайника). */
    public static void openMap(ServerPlayerEntity p, int fx, int fz) {
        NbtCompound n = com.example.zomboidmod.world.Knox.mapData(p.getServerWorld(), p.getBlockX(), p.getBlockZ(), 3);
        n.putInt("px", p.getBlockX());
        n.putInt("pz", p.getBlockZ());
        n.putFloat("yaw", p.getYaw());
        n.put("m", com.example.zomboidmod.world.Stories.marks(p));
        if (fx != Integer.MIN_VALUE) {
            n.putInt("fx", fx);
            n.putInt("fz", fz);
        }
        ServerPlayNetworking.send(p, new MapPayload(n));
    }
}
