package com.example.zomboidmod.survival;

import com.example.zomboidmod.block.FurnitureBlock;
import com.example.zomboidmod.block.FurnitureBlockEntity;
import net.minecraft.block.AbstractFurnaceBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CampfireBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Электричество и водопровод: работают до дня отключения, дальше — только от генератора (свет) или запасов (вода). */
public final class Power {
    public static final int GEN_RADIUS = 12;

    private Power() {
    }

    public static boolean gridOn(ServerWorld w) {
        return Clock.day(w) < SurvivalState.get(w.getServer()).powerOffDay;
    }

    public static boolean waterOn(ServerWorld w) {
        return Clock.day(w) < SurvivalState.get(w.getServer()).waterOffDay;
    }

    /** Время отключения света в тиках времени суток. */
    public static long powerOffTime(ServerWorld w) {
        return (long) (SurvivalState.get(w.getServer()).powerOffDay - 1) * Clock.DAY - 6000;
    }

    /** Есть ли ток в этой точке: от сети или от работающего генератора рядом. */
    public static boolean powered(ServerWorld w, BlockPos pos) {
        if (w.getRegistryKey() != World.OVERWORLD) return false;
        return gridOn(w) || generatorNear(w, pos);
    }

    public static boolean generatorNear(ServerWorld w, BlockPos pos) {
        SurvivalState st = SurvivalState.get(w.getServer());
        for (long l : st.generators) {
            BlockPos g = BlockPos.fromLong(l);
            if (Math.abs(g.getX() - pos.getX()) > GEN_RADIUS || Math.abs(g.getZ() - pos.getZ()) > GEN_RADIUS
                    || Math.abs(g.getY() - pos.getY()) > 6) continue;
            if (!w.isChunkLoaded(g)) return true;
            if (w.getBlockEntity(g) instanceof FurnitureBlockEntity be && be.on && be.fuel > 0) return true;
        }
        return false;
    }

    /** Источник огня рядом: костёр, печь, коптильня, огонь, лава или плита (у плиты нужен ток — проверяется на сервере). */
    public static boolean heatNear(World w, BlockPos center, int r) {
        for (BlockPos p : BlockPos.iterate(center.add(-r, -1, -r), center.add(r, 1, r))) {
            BlockState s = w.getBlockState(p);
            if (s.getBlock() instanceof CampfireBlock && s.get(CampfireBlock.LIT)) return true;
            if (s.getBlock() instanceof AbstractFurnaceBlock && s.get(AbstractFurnaceBlock.LIT)) return true;
            if (s.isOf(Blocks.FIRE) || s.isOf(Blocks.LAVA) || s.isOf(Blocks.SOUL_FIRE)) return true;
            if (s.getBlock() instanceof FurnitureBlock fb && fb.id.equals("stove")) {
                if (!(w instanceof ServerWorld sw) || powered(sw, p)) return true;
            }
        }
        return false;
    }
}
