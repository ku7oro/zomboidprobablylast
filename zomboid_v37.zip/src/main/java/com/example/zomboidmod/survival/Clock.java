package com.example.zomboidmod.survival;

import net.minecraft.world.World;

/**
 * Игровое время: 1 день Minecraft = 1 сутки PZ (1 час = 1000 тиков, 50 секунд).
 * Начало, как в PZ: 9 июля, лето. Время 0 = 6 утра первого дня.
 */
public final class Clock {
    public static final int HOUR = 1000, DAY = 24000;
    private static final String[] MONTHS = {"января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа",
            "сентября", "октября", "ноября", "декабря"};
    private static final int[] MONTH_LEN = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    private static final int START_DOY = 189;   // 9 июля (0 = 1 января)

    private Clock() {
    }

    public static long now(World w) {
        return w.getTimeOfDay();
    }

    /** Номер дня с начала эпидемии (с 1). День сменяется в полночь. */
    public static int day(World w) {
        return day(now(w));
    }

    public static int day(long time) {
        return (int) Math.floorDiv(time + 6000, DAY) + 1;
    }

    /** Час дня 0..24 (дробный). */
    public static float hour(World w) {
        long t = Math.floorMod(now(w), DAY);
        return ((t / 1000f) + 6f) % 24f;
    }

    /** День года 0..364. */
    public static int dayOfYear(World w) {
        return Math.floorMod(START_DOY + day(w) - 1, 365);
    }

    public static String date(World w) {
        int d = dayOfYear(w), m = 0;
        while (d >= MONTH_LEN[m]) {
            d -= MONTH_LEN[m];
            m++;
        }
        float h = hour(w);
        return String.format("%d %s, %02d:%02d", d + 1, MONTHS[m], (int) h, (int) ((h % 1f) * 60));
    }

    /** Средняя температура воздуха в Кентукки в этот день года, °C (январь ~1°, июль ~26°). */
    public static float seasonTemp(World w) {
        double doy = dayOfYear(w);
        return (float) (13.5 - 12.5 * Math.cos(2 * Math.PI * (doy - 20) / 365.0));
    }

    /** Суточные колебания ±6°: самое холодное перед рассветом, самое тёплое в 15 часов. */
    public static float dayTempOffset(World w) {
        double h = hour(w);
        return (float) (6.0 * Math.cos(2 * Math.PI * (h - 15) / 24.0));
    }
}
