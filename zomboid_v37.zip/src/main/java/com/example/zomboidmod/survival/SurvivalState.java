package com.example.zomboidmod.survival;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Состояние мира выживания: когда отключат воду и свет, когда прилетит вертолёт, когда придёт орда,
 * работающие генераторы, остаток воды в кранах после отключения и состояние каждого игрока.
 */
public class SurvivalState extends PersistentState {
    public int waterOffDay = -1, powerOffDay = -1;
    public int heliDay = -1, heliHour = 12, heliHours = 2;
    public boolean heliDone, waterNotified, powerNotified;
    public int nextHordeDay = -1;
    public float hordeHour = 20;
    public final Map<UUID, Mood> moods = new HashMap<>();
    public final Map<Long, Integer> sinkUses = new HashMap<>();
    public final Set<Long> generators = new HashSet<>();

    private static final PersistentState.Type<SurvivalState> TYPE =
            new PersistentState.Type<>(SurvivalState::new, SurvivalState::fromNbt, null);

    public static SurvivalState get(MinecraftServer server) {
        SurvivalState s = server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, "zomboidmod_survival");
        if (s.waterOffDay < 0) s.init(new Random(server.getOverworld().getSeed() ^ 0x5EEDL));
        return s;
    }

    /** Как в песочнице PZ: вода отключается через 10-25 дней, свет через 12-30, вертолёт на 6-9 день. */
    private void init(Random r) {
        waterOffDay = 10 + r.nextInt(16);
        powerOffDay = 12 + r.nextInt(19);
        heliDay = 6 + r.nextInt(4);
        heliHour = 9 + r.nextInt(8);
        heliHours = 1 + r.nextInt(4);
        nextHordeDay = 3 + r.nextInt(2);
        hordeHour = 18 + r.nextInt(8);
        markDirty();
    }

    public Mood mood(UUID id) {
        return moods.computeIfAbsent(id, k -> new Mood());
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        nbt.putInt("waterOff", waterOffDay);
        nbt.putInt("powerOff", powerOffDay);
        nbt.putInt("heliDay", heliDay);
        nbt.putInt("heliHour", heliHour);
        nbt.putInt("heliHours", heliHours);
        nbt.putBoolean("heliDone", heliDone);
        nbt.putBoolean("waterNote", waterNotified);
        nbt.putBoolean("powerNote", powerNotified);
        nbt.putInt("horde", nextHordeDay);
        nbt.putFloat("hordeHour", hordeHour);
        NbtCompound m = new NbtCompound();
        moods.forEach((id, mood) -> m.put(id.toString(), mood.write()));
        nbt.put("moods", m);
        NbtCompound s = new NbtCompound();
        sinkUses.forEach((pos, n) -> s.putInt(Long.toString(pos), n));
        nbt.put("sinks", s);
        nbt.putLongArray("gens", generators.stream().mapToLong(Long::longValue).toArray());
        return nbt;
    }

    public static SurvivalState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        SurvivalState st = new SurvivalState();
        st.waterOffDay = nbt.contains("waterOff") ? nbt.getInt("waterOff") : -1;
        st.powerOffDay = nbt.getInt("powerOff");
        st.heliDay = nbt.getInt("heliDay");
        st.heliHour = nbt.getInt("heliHour");
        st.heliHours = Math.max(1, nbt.getInt("heliHours"));
        st.heliDone = nbt.getBoolean("heliDone");
        st.waterNotified = nbt.getBoolean("waterNote");
        st.powerNotified = nbt.getBoolean("powerNote");
        st.nextHordeDay = nbt.getInt("horde");
        st.hordeHour = nbt.getFloat("hordeHour");
        NbtCompound m = nbt.getCompound("moods");
        for (String k : m.getKeys()) st.moods.put(UUID.fromString(k), Mood.read(m.getCompound(k)));
        NbtCompound s = nbt.getCompound("sinks");
        for (String k : s.getKeys()) st.sinkUses.put(Long.parseLong(k), s.getInt(k));
        for (long l : nbt.getLongArray("gens")) st.generators.add(l);
        return st;
    }
}
