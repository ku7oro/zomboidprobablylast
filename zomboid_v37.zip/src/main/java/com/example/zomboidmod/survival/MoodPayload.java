package com.example.zomboidmod.survival;

import com.example.zomboidmod.ZomboidMod;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Сервер → клиент: состояние персонажа для мудлов (раз в секунду). */
public record MoodPayload(NbtCompound data) implements CustomPayload {
    public static final CustomPayload.Id<MoodPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "mood"));
    public static final PacketCodec<RegistryByteBuf, MoodPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.NBT_COMPOUND, MoodPayload::data, MoodPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
