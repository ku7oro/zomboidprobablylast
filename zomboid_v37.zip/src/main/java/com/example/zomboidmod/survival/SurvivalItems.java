package com.example.zomboidmod.survival;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.DyedColorComponent;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterials;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.List;

/** Предметы выживания: кастрюля и рагу, чтение, сигареты, кофе, пиво, ключи, карта, радио, тёплая одежда. */
public final class SurvivalItems {
    public static Item COOKING_POT, POT_WATER, POT_WATER_TAINTED, STEW_RAW, STEW;
    public static Item MAGAZINE, COMIC, NEWSPAPER, CIGARETTES, COFFEE, BEER;
    public static Item CAR_KEY, KNOX_MAP, RADIO, BATTERY;
    public static Item WOOL_HAT, WINTER_JACKET, WARM_PANTS, WINTER_BOOTS;
    public static final int MAX_INGREDIENTS = 6;

    private SurvivalItems() {
    }

    private static Item reg(String id, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
    }

    private static Item cloth(String id, ArmorItem.Type type, int color, int durability) {
        return reg(id, new ArmorItem(ArmorMaterials.LEATHER, type, new Item.Settings().maxDamage(type.getMaxDamage(durability))
                .component(DataComponentTypes.DYED_COLOR, new DyedColorComponent(color, false))));
    }

    public static void register() {
        COOKING_POT = reg("cooking_pot", new CookingPotItem(new Item.Settings().maxCount(1)));
        POT_WATER = reg("pot_water", new PotItem(new Item.Settings().maxCount(1).recipeRemainder(COOKING_POT), 0));
        POT_WATER_TAINTED = reg("pot_water_tainted", new PotItem(new Item.Settings().maxCount(1), 1));
        STEW_RAW = reg("stew_raw", new PotItem(new Item.Settings().maxCount(1), 2));
        STEW = reg("stew", new StewItem(new Item.Settings().maxCount(1)));
        MAGAZINE = reg("magazine", new ComfortItem(new Item.Settings().maxCount(1), ComfortItem.Kind.MAGAZINE));
        COMIC = reg("comic", new ComfortItem(new Item.Settings().maxCount(1), ComfortItem.Kind.COMIC));
        NEWSPAPER = reg("newspaper", new ComfortItem(new Item.Settings().maxCount(1), ComfortItem.Kind.NEWSPAPER));
        CIGARETTES = reg("cigarettes", new ComfortItem(new Item.Settings().maxCount(20), ComfortItem.Kind.CIGARETTES));
        COFFEE = reg("coffee", new ComfortItem(new Item.Settings().maxCount(8), ComfortItem.Kind.COFFEE));
        BEER = reg("beer", new ComfortItem(new Item.Settings().maxCount(8), ComfortItem.Kind.BEER));
        CAR_KEY = reg("car_key", new CarKeyItem(new Item.Settings().maxCount(1)));
        KNOX_MAP = reg("knox_map", new KnoxMapItem(new Item.Settings().maxCount(1)));
        RADIO = reg("radio_handheld", new RadioItem(new Item.Settings().maxCount(1).maxDamage(RadioItem.BATTERY)));
        BATTERY = reg("battery", new Hint(new Item.Settings().maxCount(16), "Скрафтите вместе с радио, чтобы заменить батарейки"));
        WOOL_HAT = cloth("wool_hat", ArmorItem.Type.HELMET, 0x8C2A2A, 6);
        WINTER_JACKET = cloth("winter_jacket", ArmorItem.Type.CHESTPLATE, 0x2C3E5C, 8);
        WARM_PANTS = cloth("warm_pants", ArmorItem.Type.LEGGINGS, 0x5A4632, 7);
        WINTER_BOOTS = cloth("winter_boots", ArmorItem.Type.BOOTS, 0x2A2522, 7);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(e -> {
            for (Item i : new Item[]{COOKING_POT, POT_WATER, POT_WATER_TAINTED, STEW_RAW, STEW, COFFEE, BEER, CIGARETTES}) e.add(i);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            for (Item i : new Item[]{MAGAZINE, COMIC, NEWSPAPER, KNOX_MAP, RADIO, BATTERY, CAR_KEY}) e.add(i);
            e.add(com.example.zomboidmod.block.PowerLampBlock.CEILING_LAMP);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> {
            for (Item i : new Item[]{WOOL_HAT, WINTER_JACKET, WARM_PANTS, WINTER_BOOTS}) e.add(i);
        });
    }

    /** Утепление одежды 0..1 (как Insulation в PZ). */
    public static float insulation(ItemStack st) {
        Item i = st.getItem();
        if (i == WINTER_JACKET) return 0.42f;
        if (i == WARM_PANTS) return 0.2f;
        if (i == WOOL_HAT) return 0.12f;
        if (i == WINTER_BOOTS) return 0.12f;
        if (i instanceof com.example.zomboidmod.backpack.BackpackItem) return 0.04f;
        if (i instanceof ArmorItem a) return a.getMaterial() == ArmorMaterials.LEATHER ? 0.08f : 0.03f;
        return 0f;
    }

    /** Защита от промокания 0..1. */
    public static float waterproof(ItemStack st) {
        Item i = st.getItem();
        if (i == WINTER_JACKET) return 0.35f;
        if (i == WOOL_HAT) return 0.05f;
        if (i == WINTER_BOOTS) return 0.1f;
        if (i instanceof ArmorItem) return 0.05f;
        return 0f;
    }

    public static ItemStack cookStew(ItemStack raw, long now, int cooking) {
        NbtCompound d = Food.data(raw);
        float bonus = 1.2f + 0.05f * cooking;           // приготовленное сытнее, умелый повар — ещё сытнее
        ItemStack out = new ItemStack(STEW);
        long born = Math.floorDiv(now, Clock.HOUR) * Clock.HOUR;
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, out, nbt -> {
            nbt.putFloat("n", d.getFloat("n") * bonus);
            nbt.putFloat("s", d.getFloat("s") * bonus);
            nbt.putInt("k", d.getInt("k"));
            nbt.putInt("bad", d.getInt("bad"));
            nbt.putLong("born", born);
            nbt.putLong("cooked", now);
        });
        return out;
    }

    // ===================== классы =====================

    public static class Hint extends Item {
        private final String hint;

        public Hint(Settings s, String hint) {
            super(s);
            this.hint = hint;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(hint).formatted(Formatting.GRAY));
        }
    }

    /** Пустая кастрюля: ПКМ по воде — набрать сырой воды; по крану/бочке — см. Appliances. */
    public static class CookingPotItem extends Item {
        public CookingPotItem(Settings s) {
            super(s);
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            BlockHitResult hit = raycast(world, user, RaycastContext.FluidHandling.SOURCE_ONLY);
            if (hit.getType() != HitResult.Type.BLOCK || !world.getFluidState(hit.getBlockPos()).isIn(FluidTags.WATER))
                return TypedActionResult.pass(st);
            world.playSound(user, user.getBlockPos(), SoundEvents.ITEM_BUCKET_FILL, SoundCategory.PLAYERS, 0.8f, 1.2f);
            if (!world.isClient) user.sendMessage(Text.literal("Сырая вода: вскипятите на огне или плите"), true);
            return TypedActionResult.success(new ItemStack(POT_WATER_TAINTED), world.isClient);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal("Наберите воды: из крана, бочки или водоёма").formatted(Formatting.GRAY));
        }
    }

    /** Кастрюля с водой или сырым рагу. Еда во второй руке + ПКМ — добавить в кастрюлю; у огня ПКМ — варить. */
    public static class PotItem extends Item {
        final int type;   // 0 чистая вода, 1 сырая вода, 2 сырое рагу

        public PotItem(Settings s, int type) {
            super(s);
            this.type = type;
        }

        static boolean ingredient(ItemStack off) {
            return !off.isEmpty() && off.contains(DataComponentTypes.FOOD) && !(off.getItem() instanceof PotItem)
                    && !(off.getItem() instanceof StewItem);
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            if (hand == Hand.MAIN_HAND && ingredient(user.getOffHandStack())) {
                if (!world.isClient) addIngredient(user, st, user.getOffHandStack(), hand);
                return TypedActionResult.success(user.getStackInHand(hand), world.isClient);
            }
            if (type == 0 || Power.heatNear(world, user.getBlockPos(), 2)) {
                user.setCurrentHand(hand);
                return TypedActionResult.consume(st);
            }
            if (!world.isClient) user.sendMessage(Text.literal(type == 2
                    ? "Нужен огонь: костёр, печь или плита со светом рядом. Ингредиенты — еда во второй руке + ПКМ"
                    : "Вскипятите воду: встаньте у костра, печи или плиты со светом"), true);
            return TypedActionResult.fail(st);
        }

        private void addIngredient(PlayerEntity user, ItemStack pot, ItemStack off, Hand hand) {
            NbtCompound d = Food.data(pot);
            int k = type == 2 ? d.getInt("k") : 0;
            if (k >= MAX_INGREDIENTS) {
                user.sendMessage(Text.literal("Кастрюля полна: " + MAX_INGREDIENTS + " ингредиентов"), true);
                return;
            }
            FoodComponent fc = off.get(DataComponentTypes.FOOD);
            if (fc == null) return;
            boolean bad = Food.state(off, Clock.now(user.getWorld())) == Food.ROTTEN;
            float n = (type == 2 ? d.getFloat("n") : 0) + fc.nutrition();
            float s = (type == 2 ? d.getFloat("s") : 0) + fc.saturation();
            int badN = (type == 2 ? d.getInt("bad") : 0) + (bad ? 1 : 0);
            ItemStack res = new ItemStack(STEW_RAW);
            NbtComponent.set(DataComponentTypes.CUSTOM_DATA, res, nbt -> {
                nbt.putFloat("n", n);
                nbt.putFloat("s", s);
                nbt.putInt("k", k + 1);
                nbt.putInt("bad", badN);
            });
            user.setStackInHand(hand, res);
            if (!user.isCreative()) off.decrement(1);
            user.getWorld().playSound(null, user.getBlockPos(), SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.PLAYERS, 0.4f, 1.4f);
            user.sendMessage(Text.literal("В кастрюле " + (k + 1) + "/" + MAX_INGREDIENTS + " ингредиентов"), true);
        }

        @Override
        public UseAction getUseAction(ItemStack stack) {
            return type == 0 ? UseAction.DRINK : UseAction.NONE;
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            return type == 0 ? 32 : 100;
        }

        @Override
        public void usageTick(World world, LivingEntity user, ItemStack stack, int remaining) {
            if (world.isClient && type != 0 && remaining % 4 == 0) {
                Vec3d v = user.getRotationVector().multiply(0.6).add(user.getPos()).add(0, 1.1, 0);
                world.addParticle(remaining % 8 == 0 ? ParticleTypes.CLOUD : ParticleTypes.BUBBLE_POP, v.x, v.y, v.z, 0, 0.04, 0);
            }
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (world.isClient || !(user instanceof ServerPlayerEntity p)) return stack;
            if (type == 0) {
                ZomboidMod.addThirst(p, 50);
                world.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GENERIC_DRINK, SoundCategory.PLAYERS, 0.8f, 1f);
                return p.isCreative() ? stack : new ItemStack(COOKING_POT);
            }
            if (!Power.heatNear(world, p.getBlockPos(), 2)) {
                p.sendMessage(Text.literal("Огонь погас"), true);
                return stack;
            }
            world.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BUBBLE_COLUMN_UPWARDS_AMBIENT, SoundCategory.PLAYERS, 1f, 1f);
            if (type == 1) {
                p.sendMessage(Text.literal("Вода вскипела и теперь безопасна"), true);
                return new ItemStack(POT_WATER);
            }
            int lvl = Skills.level(p, PzSkill.COOKING);
            Skills.addXp(p, PzSkill.COOKING, 4f * Math.max(1, Food.data(stack).getInt("k")));
            p.sendMessage(Text.literal("Рагу готово! Ешьте горячим"), true);
            return cookStew(stack, Clock.now(world), lvl);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType t) {
            if (type == 0) {
                tooltip.add(Text.literal("Чистая вода. ПКМ — выпить, еда во 2-й руке + ПКМ — варить суп").formatted(Formatting.GRAY));
                tooltip.add(Text.literal("Скрафтите с бутылками, чтобы разлить").formatted(Formatting.DARK_GRAY));
            } else if (type == 1) {
                tooltip.add(Text.literal("Сырая вода. Вскипятите: ПКМ у огня или поставьте на плиту").formatted(Formatting.GRAY));
            } else {
                NbtCompound d = Food.data(stack);
                tooltip.add(Text.literal("Ингредиентов: " + d.getInt("k") + "/" + MAX_INGREDIENTS).formatted(Formatting.GRAY));
                tooltip.add(Text.literal("Добавить: еда во 2-й руке + ПКМ. Варить: ПКМ у огня").formatted(Formatting.DARK_GRAY));
            }
        }
    }

    /** Готовое рагу: несколько порций по 6 единиц сытости. Горячее поднимает настроение. */
    public static class StewItem extends Item {
        public StewItem(Settings s) {
            super(s);
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            if (!user.canConsume(false)) return TypedActionResult.fail(user.getStackInHand(hand));
            user.setCurrentHand(hand);
            return TypedActionResult.consume(user.getStackInHand(hand));
        }

        @Override
        public UseAction getUseAction(ItemStack stack) {
            return UseAction.EAT;
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            return 40;
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (world.isClient || !(user instanceof ServerPlayerEntity p)) return stack;
            NbtCompound d = Food.data(stack);
            float n = d.getFloat("n"), s = d.getFloat("s");
            float serv = Math.min(n, 6f), sat = n > 0 ? s * serv / n : 0;
            int food = Math.max(1, Math.round(serv));
            p.getHungerManager().add(food, sat / (2f * food));
            Survival.onEatStew(p, stack);
            world.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GENERIC_EAT, SoundCategory.PLAYERS, 0.8f, 1f);
            float left = n - serv, sLeft = s - sat;
            if (left < 0.5f) return p.isCreative() ? stack : new ItemStack(COOKING_POT);
            NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack, nbt -> {
                nbt.putFloat("n", left);
                nbt.putFloat("s", sLeft);
            });
            return stack;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            NbtCompound d = Food.data(stack);
            tooltip.add(Text.literal("Порций: " + (int) Math.ceil(d.getFloat("n") / 6f) + " (сытость " + Math.round(d.getFloat("n")) + ")")
                    .formatted(Formatting.GRAY));
        }
    }

    /** Чтение, курение, напитки: снимают скуку, грусть, стресс или усталость. */
    public static class ComfortItem extends Item {
        public enum Kind { MAGAZINE, COMIC, NEWSPAPER, CIGARETTES, COFFEE, BEER }

        public final Kind kind;

        public ComfortItem(Settings s, Kind kind) {
            super(s);
            this.kind = kind;
        }

        boolean reading() {
            return kind == Kind.MAGAZINE || kind == Kind.COMIC || kind == Kind.NEWSPAPER;
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            if (reading() && Food.data(st).getBoolean("read")) {
                if (!world.isClient) user.sendMessage(Text.literal("Уже прочитано — второй раз не так интересно"), true);
                return TypedActionResult.fail(st);
            }
            user.setCurrentHand(hand);
            return TypedActionResult.consume(st);
        }

        @Override
        public UseAction getUseAction(ItemStack stack) {
            return switch (kind) {
                case COFFEE, BEER -> UseAction.DRINK;
                case CIGARETTES -> UseAction.TOOT_HORN;
                default -> UseAction.NONE;
            };
        }

        @Override
        public int getMaxUseTime(ItemStack stack, LivingEntity user) {
            return switch (kind) {
                case MAGAZINE, COMIC -> 100;
                case NEWSPAPER -> 80;
                case CIGARETTES -> 70;
                default -> 32;
            };
        }

        @Override
        public void usageTick(World world, LivingEntity user, ItemStack stack, int remaining) {
            if (world.isClient && kind == Kind.CIGARETTES && remaining % 6 == 0) {
                Vec3d v = user.getRotationVector().multiply(0.35).add(user.getEyePos()).add(0, -0.1, 0);
                world.addParticle(ParticleTypes.SMOKE, v.x, v.y, v.z, 0, 0.02, 0);
            }
            if (world.isClient && reading() && remaining % 20 == 0)
                world.playSound(user.getX(), user.getY(), user.getZ(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.PLAYERS, 0.6f, 1f, false);
        }

        @Override
        public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
            if (!world.isClient && user instanceof ServerPlayerEntity p) Survival.comfort(p, kind);
            if (reading()) {
                NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack, nbt -> nbt.putBoolean("read", true));
                return stack;
            }
            stack.decrementUnlessCreative(1, user);
            return stack;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            String t = switch (kind) {
                case MAGAZINE -> "Снимает скуку и грусть";
                case COMIC -> "Сильно снимает скуку и поднимает настроение";
                case NEWSPAPER -> "Немного развлекает. Новости о том, что творится";
                case CIGARETTES -> "Снимает стресс";
                case COFFEE -> "Бодрит: снимает усталость";
                case BEER -> "Поднимает настроение и снимает стресс. Пьянит";
            };
            tooltip.add(Text.literal(t).formatted(Formatting.GRAY));
            if (reading() && Food.data(stack).getBoolean("read")) tooltip.add(Text.literal("Прочитано").formatted(Formatting.DARK_GRAY));
        }
    }

    /** Ключ от конкретной машины. */
    public static class CarKeyItem extends Item {
        public CarKeyItem(Settings s) {
            super(s);
        }

        public static ItemStack make(int keyId, String carName) {
            ItemStack st = new ItemStack(CAR_KEY);
            NbtComponent.set(DataComponentTypes.CUSTOM_DATA, st, nbt -> {
                nbt.putInt("key", keyId);
                nbt.putString("car", carName);
            });
            return st;
        }

        public static int keyId(ItemStack st) {
            return st.isOf(CAR_KEY) ? Food.data(st).getInt("key") : 0;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            NbtCompound d = Food.data(stack);
            String car = d.getString("car");
            tooltip.add(Text.literal("От машины: " + (car.isEmpty() ? "?" : car) + " (№" + (d.getInt("key") % 10000) + ")").formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Держите в инвентаре, чтобы завести").formatted(Formatting.DARK_GRAY));
        }
    }

    public static class KnoxMapItem extends Item {
        public KnoxMapItem(Settings s) {
            super(s);
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            if (!world.isClient && user instanceof ServerPlayerEntity p) WorldEvents.openMap(p);
            world.playSound(user, user.getBlockPos(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.PLAYERS, 1f, 0.8f);
            return TypedActionResult.success(user.getStackInHand(hand), world.isClient);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal("Карта округа: города, деревни и дороги").formatted(Formatting.GRAY));
        }
    }

    /** Портативное радио на батарейках: ловит экстренные передачи, пока они ещё идут. */
    public static class RadioItem extends Item {
        public static final int BATTERY = 2400;   // секунд работы

        public RadioItem(Settings s) {
            super(s);
        }

        public static boolean on(ItemStack st) {
            return Food.data(st).getBoolean("on");
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            if (!world.isClient) {
                boolean now = !on(st);
                if (now && st.getDamage() >= st.getMaxDamage() - 1) {
                    user.sendMessage(Text.literal("Батарейки сели. Скрафтите радио с новой батарейкой"), true);
                    return TypedActionResult.fail(st);
                }
                NbtComponent.set(DataComponentTypes.CUSTOM_DATA, st, nbt -> nbt.putBoolean("on", now));
                user.sendMessage(Text.literal(now ? "Радио включено" : "Радио выключено"), true);
                world.playSound(null, user.getBlockPos(), now ? SurvivalSounds.RADIO_STATIC : SoundEvents.UI_BUTTON_CLICK.value(),
                        SoundCategory.PLAYERS, 0.5f, 1f);
            }
            return TypedActionResult.success(st, world.isClient);
        }

        @Override
        public boolean hasGlint(ItemStack stack) {
            return on(stack);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(on(stack) ? "Включено" : "Выключено").formatted(on(stack) ? Formatting.GREEN : Formatting.GRAY));
            int left = (stack.getMaxDamage() - stack.getDamage()) * 100 / stack.getMaxDamage();
            tooltip.add(Text.literal("Батарейки: " + left + "%").formatted(Formatting.DARK_GRAY));
        }
    }
}
