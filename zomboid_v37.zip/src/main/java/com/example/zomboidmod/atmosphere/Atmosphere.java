package com.example.zomboidmod.atmosphere;

import com.example.zomboidmod.survival.Clock;
import com.example.zomboidmod.survival.SurvivalClient;
import com.example.zomboidmod.survival.SurvivalSounds;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.biome.FoliageColors;
import net.minecraft.world.biome.GrassColors;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Атмосфера зомби-апокалипсиса: дымка и туман (густеет в дождь и в туманные дни), хмурое небо, тёмные ночи,
 * сезонная листва (осенью рыжеет, зимой буреет), ветер и далёкие звуки погибшего мира.
 * Если включён наш шейдерпак (Iris) — цвет неба и тумана рисует он, а мод отдаёт ему только дальность тумана.
 * Сила эффекта: /atmosphere off | normal | strong.
 */
public final class Atmosphere {
    public static int mode = 1;          // 0 — выкл, 1 — обычно, 2 — сильно
    private static float fogSmooth;
    private static Season season = Season.SUMMER;
    private static WindSound wind;
    private static int ambientIn = 600;

    enum Season { SPRING, SUMMER, EARLY_AUTUMN, AUTUMN, LATE_AUTUMN, WINTER }

    private Atmosphere() {
    }

    private static java.lang.reflect.Method irisInUse;
    private static Object irisApi;
    private static boolean irisChecked;

    /** Включён ли сейчас шейдерпак в Iris (если Iris не установлен — нет). */
    public static boolean shaders() {
        if (!irisChecked) {
            irisChecked = true;
            try {
                if (FabricLoader.getInstance().isModLoaded("iris")) {
                    Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
                    irisApi = api.getMethod("getInstance").invoke(null);
                    irisInUse = api.getMethod("isShaderPackInUse");
                }
            } catch (Throwable ignored) {
                irisInUse = null;
            }
        }
        if (irisInUse == null) return false;
        try {
            return (Boolean) irisInUse.invoke(irisApi);
        } catch (Throwable t) {
            irisInUse = null;
            return false;
        }
    }

    public static float strength() {
        return mode == 0 ? 0f : (mode == 1 ? 1f : 1.6f);
    }

    // ===================== регистрация =====================
    public static void init() {
        load();
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> dispatcher.register(ClientCommandManager.literal("atmosphere")
                .then(ClientCommandManager.literal("off").executes(ctx -> set(0)))
                .then(ClientCommandManager.literal("normal").executes(ctx -> set(1)))
                .then(ClientCommandManager.literal("strong").executes(ctx -> set(2)))));
        ColorProviderRegistry.BLOCK.register((state, world, pos, tint) -> grass(world, pos),
                Blocks.GRASS_BLOCK, Blocks.SHORT_GRASS, Blocks.TALL_GRASS, Blocks.FERN, Blocks.LARGE_FERN);
        ColorProviderRegistry.BLOCK.register((state, world, pos, tint) -> foliage(world, pos, false),
                Blocks.OAK_LEAVES, Blocks.DARK_OAK_LEAVES, Blocks.JUNGLE_LEAVES, Blocks.ACACIA_LEAVES, Blocks.MANGROVE_LEAVES, Blocks.VINE);
        ColorProviderRegistry.BLOCK.register((state, world, pos, tint) -> foliage(world, pos, true), Blocks.BIRCH_LEAVES);
    }

    private static int set(int m) {
        mode = m;
        save();
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) c.player.sendMessage(Text.literal("Атмосфера: " + (m == 0 ? "выключена" : m == 1 ? "обычная" : "сильная")), true);
        if (c.worldRenderer != null) c.worldRenderer.reload();
        return 1;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("zomboid_atmosphere.txt");
    }

    private static void load() {
        try {
            if (Files.exists(file())) mode = MathHelper.clamp(Integer.parseInt(Files.readString(file()).trim()), 0, 2);
        } catch (Exception ignored) {
        }
    }

    private static void save() {
        try {
            Files.writeString(file(), Integer.toString(mode));
        } catch (Exception ignored) {
        }
    }

    // ===================== цвет =====================
    private static float lum(float r, float g, float b) {
        return 0.3f * r + 0.59f * g + 0.11f * b;
    }

    /** Насколько сейчас день (1) или ночь (0). */
    private static float daylight(ClientWorld w) {
        float h = Clock.hour(w);
        return MathHelper.clamp((float) Math.sin((h - 6f) / 12f * Math.PI) * 2.2f + 0.2f, 0f, 1f);
    }

    /** Приглушить цвет: выцветание, лёгкий холодно-зелёный оттенок, к туману — к серому. */
    public static float[] grade(float r, float g, float b, float fogAmount) {
        float s = strength();
        float l = lum(r, g, b);
        float desat = Math.min(0.7f, 0.22f * s + 0.3f * fogAmount);
        r += (l - r) * desat;
        g += (l - g) * desat;
        b += (l - b) * desat;
        // туман: серая пелена
        float grey = l * 0.95f + 0.06f;
        float k = fogAmount * 0.5f;
        return new float[]{r + (grey - r) * k, g + (grey * 1.02f - g) * k, b + (grey - b) * k};
    }

    private static int gradeRgb(int rgb, float desat, float r0, float g0, float b0, float mix) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float l = lum(r, g, b);
        r += (l - r) * desat;
        g += (l - g) * desat;
        b += (l - b) * desat;
        r += (r0 - r) * mix;
        g += (g0 - g) * mix;
        b += (b0 - b) * mix;
        return (MathHelper.clamp((int) (r * 255), 0, 255) << 16) | (MathHelper.clamp((int) (g * 255), 0, 255) << 8) | MathHelper.clamp((int) (b * 255), 0, 255);
    }

    // ===================== туман (миксин BackgroundRenderer) =====================
    public static void applyFog(Camera camera, BackgroundRenderer.FogType type, float viewDistance) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (mode == 0 || c.world == null || c.player == null || type != BackgroundRenderer.FogType.FOG_TERRAIN) return;
        if (camera.getSubmersionType() != CameraSubmersionType.NONE) return;
        if (c.player.hasStatusEffect(StatusEffects.BLINDNESS) || c.player.hasStatusEffect(StatusEffects.DARKNESS)) return;
        float rain = c.world.getRainGradient(1f);
        float night = 1f - daylight(c.world);
        float end = 150f - 55f * rain - 40f * night;           // вечная дымка над округом
        end = MathHelper.lerp(fogSmooth, end, 18f);            // в густом тумане видно на 15-20 блоков
        end /= mode == 2 ? 1.35f : 1f;
        end = Math.min(end, viewDistance);
        float start = end * (0.3f - 0.3f * fogSmooth);
        RenderSystem.setShaderFogStart(start);
        RenderSystem.setShaderFogEnd(end);
    }

    /** Цвет тумана и фона: выцветший, к серому в тумане и дождь. */
    public static float[] fogColor(Camera camera, float r, float g, float b) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (mode == 0 || c.world == null || camera.getSubmersionType() != CameraSubmersionType.NONE || shaders()) return null;
        return grade(r, g, b, Math.max(fogSmooth, c.world.getRainGradient(1f) * 0.5f));
    }

    public static Vec3d sky(Vec3d v) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (mode == 0 || c.world == null || shaders()) return v;
        float[] o = grade((float) v.x, (float) v.y, (float) v.z, Math.max(fogSmooth, c.world.getRainGradient(1f) * 0.4f));
        return new Vec3d(o[0], o[1], o[2]);
    }

    public static Vec3d clouds(Vec3d v) {
        if (mode == 0 || shaders()) return v;
        float s = strength();
        double k = 1 - 0.18 * s;
        double l = (v.x + v.y + v.z) / 3;
        return new Vec3d((v.x + (l - v.x) * 0.6) * k, (v.y + (l - v.y) * 0.6) * k, (v.z + (l - v.z) * 0.6) * k);
    }

    /** Ночи темнее (в PZ ночью без фонаря почти ничего не видно). */
    public static float skyBrightness(float v) {
        if (mode == 0 || shaders()) return v;
        float min = mode == 2 ? 0.03f : 0.07f;
        if (v >= 0.999f) return v;
        float t = MathHelper.clamp((v - 0.2f) / 0.8f, 0f, 1f);
        return min + (1f - min) * t;
    }

    // ===================== сезоны: листва и трава =====================
    private static Season seasonOf(ClientWorld w) {
        int d = Clock.dayOfYear(w);
        if (d >= 152 && d < 244) return Season.SUMMER;
        if (d >= 244 && d < 274) return Season.EARLY_AUTUMN;
        if (d >= 274 && d < 305) return Season.AUTUMN;
        if (d >= 305 && d < 335) return Season.LATE_AUTUMN;
        if (d >= 60 && d < 152) return Season.SPRING;
        return Season.WINTER;
    }

    private static int grass(BlockRenderView world, BlockPos pos) {
        int base = world != null && pos != null ? net.minecraft.client.color.world.BiomeColors.getGrassColor(world, pos) : GrassColors.getDefaultColor();
        if (mode == 0) return base;
        return switch (season) {
            case SPRING -> gradeRgb(base, 0.1f, 0.42f, 0.62f, 0.25f, 0.15f);
            case SUMMER -> gradeRgb(base, 0.22f, 0.5f, 0.55f, 0.28f, 0.12f);
            case EARLY_AUTUMN -> gradeRgb(base, 0.25f, 0.62f, 0.58f, 0.3f, 0.3f);
            case AUTUMN -> gradeRgb(base, 0.3f, 0.64f, 0.54f, 0.28f, 0.5f);
            case LATE_AUTUMN -> gradeRgb(base, 0.35f, 0.55f, 0.46f, 0.28f, 0.62f);
            case WINTER -> gradeRgb(base, 0.45f, 0.5f, 0.44f, 0.32f, 0.7f);
        };
    }

    private static final int[][] AUTUMN = {{214, 120, 40}, {222, 176, 52}, {178, 56, 30}, {150, 96, 44}, {200, 92, 36}};

    private static int foliage(BlockRenderView world, BlockPos pos, boolean birch) {
        int base = birch ? FoliageColors.getBirchColor()
                : (world != null && pos != null ? net.minecraft.client.color.world.BiomeColors.getFoliageColor(world, pos) : FoliageColors.getDefaultColor());
        if (mode == 0) return base;
        float turn = switch (season) {
            case EARLY_AUTUMN -> 0.3f;
            case AUTUMN -> 0.75f;
            case LATE_AUTUMN -> 0.9f;
            default -> 0f;
        };
        if (season == Season.WINTER) return gradeRgb(base, 0.6f, 0.42f, 0.33f, 0.22f, 0.75f);   // сухая бурая листва
        int g = gradeRgb(base, 0.2f, 0.4f, 0.48f, 0.25f, 0.1f);
        if (turn <= 0f || pos == null) return g;
        // каждое дерево желтеет по-своему
        int h = (int) (MathHelper.hashCode(pos.getX() >> 2, pos.getY() >> 3, pos.getZ() >> 2) & 0x7fffffff);
        float treeTurn = MathHelper.clamp(turn * (0.6f + (h % 100) / 100f * 0.8f), 0f, 1f);
        int[] c = birch ? AUTUMN[1] : AUTUMN[(h >> 8) % AUTUMN.length];
        if (season == Season.LATE_AUTUMN) c = new int[]{(c[0] + 140) / 2, (c[1] + 96) / 2, (c[2] + 50) / 2};
        return gradeRgb(g, 0f, c[0] / 255f, c[1] / 255f, c[2] / 255f, treeTurn);
    }

    // ===================== раз в тик =====================
    public static void tick(MinecraftClient c) {
        if (c.world == null || c.player == null) {
            wind = null;
            return;
        }
        fogSmooth += (SurvivalClient.fog - fogSmooth) * 0.02f;
        Season s = seasonOf(c.world);
        if (s != season) {
            season = s;
            if (c.worldRenderer != null) c.worldRenderer.reload();   // перекрасить листву
        }
        if (mode == 0) return;
        // ветер на улице
        if (wind == null || wind.isDone()) {
            wind = new WindSound();
            c.getSoundManager().play(wind);
        }
        // далёкие звуки мёртвого мира
        if (--ambientIn <= 0) {
            ambientIn = 900 + c.player.getRandom().nextInt(1800);
            float night = 1f - daylight(c.world);
            SoundEvent ev;
            float vol, pitch;
            float k = c.player.getRandom().nextFloat();
            if (k < 0.45f + 0.2f * night) {
                ev = SurvivalSounds.HORDE;
                vol = 0.5f;
                pitch = 0.65f + c.player.getRandom().nextFloat() * 0.2f;
            } else if (k < 0.7f) {
                ev = c.player.getRandom().nextBoolean() ? com.example.zomboidmod.gun.Guns.RIFLE_SHOT : com.example.zomboidmod.gun.Guns.SHOTGUN_SHOT;
                vol = 0.35f;
                pitch = 0.6f;
            } else if (k < 0.85f) {
                ev = SoundEvents.ENTITY_FOX_SCREECH;
                vol = 0.3f;
                pitch = 0.8f;
            } else {
                ev = com.example.zomboidmod.vehicle.Vehicles.HORN;
                vol = 0.25f;
                pitch = 0.85f;
            }
            double a = c.player.getRandom().nextDouble() * Math.PI * 2;
            c.getSoundManager().play(new PositionedSoundInstance(ev, SoundCategory.AMBIENT, vol, pitch, SoundInstance.createRandom(),
                    c.player.getX() + Math.cos(a) * 14, c.player.getY() + 2, c.player.getZ() + Math.sin(a) * 14));
        }
    }

    /** Ветер: слышен на улице, сильнее в дождь и на высоте. */
    static final class WindSound extends MovingSoundInstance {
        WindSound() {
            super(SurvivalSounds.WIND, SoundCategory.AMBIENT, SoundInstance.createRandom());
            this.repeat = true;
            this.repeatDelay = 0;
            this.relative = true;
            this.attenuationType = SoundInstance.AttenuationType.NONE;
            this.volume = 0.01f;
        }

        @Override
        public void tick() {
            MinecraftClient c = MinecraftClient.getInstance();
            if (c.player == null || c.world == null || mode == 0) {
                setDone();
                return;
            }
            boolean out = c.world.isSkyVisible(c.player.getBlockPos().up());
            float rain = c.world.getRainGradient(1f);
            float height = MathHelper.clamp((float) (c.player.getY() - 70) / 40f, 0f, 1f);
            float target = out ? 0.18f + 0.4f * rain + 0.25f * height + 0.1f * fogSmooth : 0.04f + 0.1f * rain;
            volume += (target - volume) * 0.03f;
            pitch = 0.9f + 0.15f * rain;
        }
    }
}
