package com.example.zomboidmod.atmosphere;

import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;

import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Properties;

/**
 * Наш шейдерпак «Knox Dread» лежит внутри мода. Ещё до запуска игры мод копирует его в папку shaderpacks,
 * а если Iris установлен впервые и шейдер в нём ещё не выбран — один раз выбирает Knox Dread сам.
 * Дальше игрок волен выбрать любой другой пак или выключить шейдеры: мы это больше не трогаем.
 */
public final class ShaderInstaller implements PreLaunchEntrypoint {
    public static final String PACK = "KnoxDread";
    private static final String ROOT = "/assets/zomboidmod/shaderpack/";

    @Override
    public void onPreLaunch() {
        FabricLoader fl = FabricLoader.getInstance();
        if (fl.getEnvironmentType() != EnvType.CLIENT) return;
        try {
            install(fl.getGameDir().resolve("shaderpacks").resolve(PACK));
        } catch (Throwable t) {
            System.err.println("[zomboidmod] не удалось положить шейдерпак: " + t);
        }
        try {
            if (fl.isModLoaded("iris")) selectOnce(fl.getConfigDir());
        } catch (Throwable t) {
            System.err.println("[zomboidmod] не удалось выбрать шейдерпак в Iris: " + t);
        }
    }

    /** Копирует файлы пака; переписывает только изменившиеся (после обновления мода пак тоже обновится). */
    static void install(Path dir) throws Exception {
        String list;
        try (InputStream in = ShaderInstaller.class.getResourceAsStream(ROOT + "files.txt")) {
            if (in == null) return;
            list = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
        for (String line : list.split("\n")) {
            String rel = line.trim();
            if (rel.isEmpty() || rel.contains("..")) continue;
            byte[] data;
            try (InputStream in = ShaderInstaller.class.getResourceAsStream(ROOT + PACK + "/" + rel)) {
                if (in == null) continue;
                data = in.readAllBytes();
            }
            Path out = dir.resolve(rel);
            if (Files.exists(out) && Arrays.equals(Files.readAllBytes(out), data)) continue;
            Files.createDirectories(out.getParent());
            Files.write(out, data);
        }
    }

    /** Один раз: если в Iris ещё не выбран ни один шейдерпак — выбрать наш и включить шейдеры. */
    static void selectOnce(Path config) throws Exception {
        Path mark = config.resolve("zomboid_shaders_selected.txt");
        if (Files.exists(mark)) return;
        Path iris = config.resolve("iris.properties");
        Properties p = new Properties();
        if (Files.exists(iris)) {
            try (Reader r = Files.newBufferedReader(iris, StandardCharsets.UTF_8)) {
                p.load(r);
            }
        }
        String current = p.getProperty("shaderPack", "").trim();
        if (current.isEmpty() || current.equals("(internal)")) {
            p.setProperty("shaderPack", PACK);
            p.setProperty("enableShaders", "true");
            Files.createDirectories(config);
            try (Writer w = Files.newBufferedWriter(iris, StandardCharsets.UTF_8)) {
                p.store(w, "This file stores configuration options for Iris, such as the currently active shaderpack");
            }
        }
        Files.writeString(mark, "Knox Dread выбран автоматически один раз. Удалите этот файл, чтобы мод выбрал его снова.\n");
    }
}
