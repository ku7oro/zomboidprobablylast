package com.example.zomboidmod;

/** Навыки как в Project Zomboid (только те, у которых в Minecraft есть смысл). Порядок не менять: он в сохранениях. */
public enum PzSkill {
    STRENGTH("Сила", Category.PASSIVE),
    FITNESS("Физическая форма", Category.PASSIVE),
    SPRINTING("Бег", Category.AGILITY),
    LIGHTFOOTED("Лёгкая походка", Category.AGILITY),
    NIMBLE("Проворство", Category.AGILITY),
    SNEAKING("Скрытность", Category.AGILITY),
    AXE("Топор", Category.COMBAT),
    LONG_BLUNT("Длинное дробящее", Category.COMBAT),
    SHORT_BLUNT("Короткое дробящее", Category.COMBAT),
    LONG_BLADE("Длинный клинок", Category.COMBAT),
    SHORT_BLADE("Короткий клинок", Category.COMBAT),
    MAINTENANCE("Уход за оружием", Category.COMBAT),
    COOKING("Кулинария", Category.CRAFTING),
    FARMING("Фермерство", Category.CRAFTING),
    FIRST_AID("Первая помощь", Category.CRAFTING),
    AIMING("Меткость", Category.FIREARM),
    FISHING("Рыбалка", Category.SURVIVAL),
    MECHANICS("Механика", Category.VEHICLE),
    CARPENTRY("Плотницкое дело", Category.CRAFTING),
    TAILORING("Шитьё", Category.CRAFTING);

    public enum Category {
        PASSIVE("Пассивные"), AGILITY("Ловкость"), COMBAT("Ближний бой"), CRAFTING("Ремесло"),
        FIREARM("Стрельба"), SURVIVAL("Выживание"), VEHICLE("Техника");

        public final String title;

        Category(String title) {
            this.title = title;
        }
    }

    public final String title;
    public final Category category;

    PzSkill(String title, Category category) {
        this.title = title;
        this.category = category;
    }

    public boolean passive() {
        return category == Category.PASSIVE;
    }

    /** Что даёт навык (кратко, для подсказки). */
    public String effect() {
        return switch (this) {
            case STRENGTH -> "Урон в ближнем бою";
            case FITNESS -> "Меньше жажды при беге, быстрее заживление";
            case SPRINTING -> "Скорость бега";
            case LIGHTFOOTED -> "Тише шаги";
            case NIMBLE -> "Реже хватают зомби";
            case SNEAKING -> "Зомби замечают позже, когда крадёшься";
            case AXE, LONG_BLUNT, SHORT_BLUNT, LONG_BLADE, SHORT_BLADE -> "Урон и скорость атаки этим оружием";
            case MAINTENANCE -> "Оружие медленнее ломается";
            case COOKING -> "Приготовленная еда сытнее";
            case FARMING -> "Больше урожая";
            case FIRST_AID -> "Повязки дольше чистые, переломы срастаются быстрее";
            case AIMING -> "Урон стрел";
            case FISHING -> "Удача на рыбалке";
            case MECHANICS -> "Снимать, ставить и чинить детали машин, заводить без ключа";
            case CARPENTRY -> "Строить быстрее и крепче, двери и люки, меньше испорченных досок при разборке";
            case TAILORING -> "Заплатки крепче, с 8 уровня дыры штопаются как новые, больше ниток при распарывании";
        };
    }

    /** Порядок для экрана навыков: по категориям (в enum новые навыки дописываются в конец ради сохранений). */
    public static PzSkill[] ordered() {
        PzSkill[] a = values().clone();
        java.util.Arrays.sort(a, java.util.Comparator.comparingInt(x -> x.category.ordinal()));   // сортировка устойчивая
        return a;
    }
}
