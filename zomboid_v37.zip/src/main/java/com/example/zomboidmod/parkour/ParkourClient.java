package com.example.zomboidmod.parkour;

import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

/**
 * Паркур на клиенте: «прыжок» у забора или окна — запрос серверу; движение своего персонажа по маршруту;
 * позы рук и ног (у себя от третьего лица, у других игроков и у зомби); подсказка у прицела.
 */
public final class ParkourClient {
    private ParkourClient() {
    }

    private static final Map<Integer, Parkour.Active> ACTIVE = new HashMap<>();
    private static int pending, autoCd, hintCd, scanCd, sinceSprint = 99;
    private static boolean jumpWas;
    private static String prompt;

    public static void init() {
        Parkour.CLIENT = e -> ACTIVE.get(e.getId());
        ClientPlayNetworking.registerGlobalReceiver(Parkour.StartPayload.ID, (pl, ctx) -> ctx.client().execute(() -> start(ctx.client(), pl)));
        ClientTickEvents.START_CLIENT_TICK.register(ParkourClient::tick);
        HudRenderCallback.EVENT.register(ParkourClient::hud);
        BlockRenderLayerMap.INSTANCE.putBlock(Parkour.BROKEN_WINDOW, RenderLayer.getTranslucent());
    }

    private static void start(MinecraftClient c, Parkour.StartPayload pl) {
        boolean self = c.player != null && pl.entity() == c.player.getId();
        if (self) pending = 0;
        if (pl.a() == null) return;
        Parkour.Active a = pl.a();
        if (self) {
            a.local = true;
            a.setStart(c.player.getPos());
            c.player.setSprinting(false);
        }
        ACTIVE.put(pl.entity(), a);
    }

    public static boolean climbing(Entity e) {
        return ACTIVE.containsKey(e.getId());
    }

    private static void tick(MinecraftClient c) {
        if (c.world == null || c.player == null) {
            ACTIVE.clear();
            pending = 0;
            return;
        }
        if (c.isPaused()) return;
        ACTIVE.entrySet().removeIf(en -> {
            Parkour.Active a = en.getValue();
            a.t++;
            return a.t > a.total + (a.local ? 20 : 2);
        });
        if (pending > 0) pending--;
        if (autoCd > 0) autoCd--;
        if (hintCd > 0) hintCd--;

        ClientPlayerEntity p = c.player;
        // игра сбрасывает бег при ударе о препятствие — помним, что только что бежал
        sinceSprint = p.isSprinting() ? 0 : Math.min(99, sinceSprint + 1);
        boolean running = sinceSprint <= 3;
        boolean jump = c.options.jumpKey.isPressed();
        boolean edge = jump && !jumpWas;
        jumpWas = jump;

        // подсказка у прицела (раз в 4 тика)
        if (--scanCd <= 0) {
            scanCd = 4;
            prompt = null;
            if (c.currentScreen == null && canStart(p)) {
                Parkour.Route r = Parkour.plan(c.world, p, Direction.fromRotation(p.getYaw()), false);
                if (r != null && !r.closed) prompt = switch (r.kind) {
                    case VAULT -> "[Пробел] Перемахнуть";
                    case CLIMB -> "[Пробел] Перелезть";
                    case WINDOW -> r.glass ? "[Пробел] Пролезть (осколки!)" : "[Пробел] Пролезть";
                };
            }
        }

        if (c.currentScreen != null || !canStart(p) || !p.isOnGround()) return;
        boolean auto = !edge && running && p.horizontalCollision && autoCd == 0;
        if (!edge && !auto) return;
        Direction d = Direction.fromRotation(p.getYaw());
        Parkour.Route r = Parkour.plan(c.world, p, d, false);
        if (r == null) return;
        if (r.closed) {
            if (edge && hintCd == 0) {
                p.sendMessage(Text.literal("Окно застеклено — сначала разбейте стекло"), true);
                hintCd = 40;
            }
            return;
        }
        if (auto && r.kind == Parkour.Kind.CLIMB) return;   // на высокий забор с разбегу не запрыгнуть — только пробелом
        autoCd = 20;
        pending = 8;
        ClientPlayNetworking.send(new Parkour.RequestPayload(d.ordinal(), running));
    }

    private static boolean canStart(ClientPlayerEntity p) {
        return !p.hasVehicle() && !p.getAbilities().flying && !p.isSpectator() && !ACTIVE.containsKey(p.getId()) && pending <= 0
                && !p.isSneaking() && !p.isTouchingWater() && !p.isClimbing() && !p.isSleeping() && p.isAlive();
    }

    /** Из ClientPlayerEntity.tickMovement: true — обычное движение в этот тик пропустить. */
    public static boolean tickLocal(ClientPlayerEntity p) {
        Parkour.Active a = ACTIVE.get(p.getId());
        if (a == null) {
            if (pending > 0) {   // ждём ответа сервера — стоим на месте, чтобы не прыгнуть
                p.setVelocity(0, Math.min(0, p.getVelocity().y), 0);
                return true;
            }
            return false;
        }
        Vec3d pos = a.sample(a.t);
        p.noClip = true;
        p.setPosition(pos.x, pos.y, pos.z);
        p.setVelocity(Vec3d.ZERO);
        p.fallDistance = 0;
        if (a.t >= a.total) {
            ACTIVE.remove(p.getId());
            p.setOnGround(true);
        }
        return true;
    }

    private static void hud(DrawContext ctx, RenderTickCounter counter) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (prompt == null || c.options.hudHidden || c.currentScreen != null) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        boolean warn = prompt.contains("осколки");
        ctx.drawCenteredTextWithShadow(c.textRenderer, prompt, w / 2, h / 2 + 16, warn ? 0xCCE0A060 : 0xAAD8D0C0);
    }

    // =====================================================================================
    //                                       позы
    // =====================================================================================

    /** Степень «лёжа» для рендера зомби (игрока кладёт сама игра по позе ползком). */
    public static float lie(Entity e, float tickDelta) {
        Parkour.Active a = ACTIVE.get(e.getId());
        if (a == null) return 0f;
        return a.lie(a.t - 1 + tickDelta);
    }

    private static float smooth(float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    private static float key(float s, float[] T, float[] V) {
        if (s <= T[0]) return V[0];
        for (int i = 1; i < T.length; i++) {
            if (s <= T[i]) return V[i - 1] + (V[i] - V[i - 1]) * smooth((s - T[i - 1]) / (T[i] - T[i - 1]));
        }
        return V[V.length - 1];
    }

    /** Колокол 0→1→0 внутри [a, b]. */
    private static float bell(float s, float a, float b) {
        if (s <= a || s >= b) return 0f;
        return MathHelper.sin((s - a) / (b - a) * MathHelper.PI);
    }

    private static void lean(BipedEntityModel<?> m, float bp) {
        m.body.pitch = bp;
        float sz = 12f * MathHelper.sin(bp), cy = 12f * MathHelper.cos(bp);
        m.rightLeg.pivotZ = 0.1f + sz;
        m.leftLeg.pivotZ = 0.1f + sz;
        m.rightLeg.pivotY = cy;
        m.leftLeg.pivotY = cy;
        m.rightArm.pivotZ = 0f;
        m.leftArm.pivotZ = 0f;
    }

    private static final float[] V_T = {0f, 0.3f, 0.62f, 0.85f, 1f};
    private static final float[] V_RA = {-0.2f, -1.15f, -0.45f, -0.5f, -0.2f};
    private static final float[] V_RAR = {0f, 0f, 0.15f, 0.1f, 0f};
    private static final float[] V_LA = {-0.2f, -0.6f, -1.9f, -1.0f, -0.2f};
    private static final float[] V_LAR = {0f, 0f, -0.5f, -0.3f, 0f};
    private static final float[] V_B = {0f, 0.3f, 0.45f, 0.25f, 0f};
    private static final float[] V_RL = {0f, -0.35f, -1.35f, -0.6f, 0f};
    private static final float[] V_RLR = {0f, 0f, 0.4f, 0.1f, 0f};
    private static final float[] V_LL = {0f, -0.15f, -1.15f, -0.2f, 0f};
    private static final float[] V_LLR = {0f, 0f, 0.3f, 0.05f, 0f};

    private static final float[] C_T = {0f, 0.14f, 0.49f, 0.66f, 0.8f, 1f};
    private static final float[] C_A = {-0.2f, -2.8f, -2.95f, -1.5f, -0.7f, -0.2f};
    private static final float[] C_B = {0f, 0.05f, 0.1f, 0.55f, 0.3f, 0f};
    private static final float[] C_RL = {0f, -0.5f, -0.4f, -1.5f, -0.4f, 0f};
    private static final float[] C_LL = {0f, -0.1f, -0.5f, -0.3f, -0.9f, 0f};
    private static final float[] C_RLR = {0f, 0f, 0f, 0.3f, 0.1f, 0f};

    private static final float[] F_T = {0f, 0.18f, 0.6f, 0.78f, 1f};
    private static final float[] F_A = {-0.2f, -2.8f, -2.95f, -2.9f, -0.3f};

    /**
     * Позы перелезания поверх обычных (вызывается в конце setAngles модели).
     * false — эта сущность сейчас не лезет.
     */
    public static boolean pose(BipedEntityModel<?> m, LivingEntity e, float animationProgress) {
        Parkour.Active a = ACTIVE.get(e.getId());
        if (a == null) return false;
        float td = MathHelper.clamp(animationProgress - e.age, 0f, 1f);
        float t = Math.max(0f, a.t - 1 + td);
        if (t > a.total + 1) return false;
        boolean zombie = !(e instanceof PlayerEntity);
        m.rightArm.yaw = 0f;
        m.leftArm.yaw = 0f;
        m.rightArm.roll = 0f;
        m.leftArm.roll = 0f;
        m.rightLeg.yaw = 0f;
        m.leftLeg.yaw = 0f;
        m.rightLeg.roll = 0f;
        m.leftLeg.roll = 0f;
        m.body.yaw = 0f;
        m.body.roll = 0f;
        if (a.proneFrom >= 0 && t >= a.proneFrom - 1) {
            prone(m, (t - a.proneFrom) / Math.max(1f, a.total - a.proneFrom), t, zombie);
        } else {
            float end = a.proneFrom >= 0 ? a.proneFrom : a.total;
            float s = MathHelper.clamp(t / Math.max(1f, end), 0f, 1f);
            switch (a.kindEnum()) {
                case VAULT -> {
                    lean(m, key(s, V_T, V_B));
                    m.rightArm.pitch = key(s, V_T, V_RA);
                    m.rightArm.roll = key(s, V_T, V_RAR);
                    m.leftArm.pitch = key(s, V_T, V_LA);
                    m.leftArm.roll = key(s, V_T, V_LAR);
                    m.rightLeg.pitch = key(s, V_T, V_RL);
                    m.rightLeg.roll = key(s, V_T, V_RLR);
                    m.leftLeg.pitch = key(s, V_T, V_LL);
                    m.leftLeg.roll = key(s, V_T, V_LLR);
                }
                case CLIMB -> {
                    if (a.fail) {
                        float kick = MathHelper.sin(t * 1.2f) * 0.6f * bell(s, 0.18f, 0.78f);
                        lean(m, 0.08f * bell(s, 0.1f, 0.9f));
                        m.rightArm.pitch = key(s, F_T, F_A) + 0.1f * MathHelper.sin(t * 0.9f);
                        m.leftArm.pitch = key(s, F_T, F_A) - 0.1f * MathHelper.sin(t * 0.9f);
                        m.rightArm.roll = 0.15f;
                        m.leftArm.roll = -0.15f;
                        m.rightLeg.pitch = kick;
                        m.leftLeg.pitch = -kick;
                    } else {
                        float alt = MathHelper.sin(t * 0.8f) * bell(s, 0.14f, 0.49f);
                        lean(m, key(s, C_T, C_B));
                        m.rightArm.pitch = key(s, C_T, C_A) + 0.3f * alt;
                        m.leftArm.pitch = key(s, C_T, C_A) - 0.3f * alt;
                        m.rightArm.roll = 0.12f * bell(s, 0.05f, 0.6f);
                        m.leftArm.roll = -0.12f * bell(s, 0.05f, 0.6f);
                        m.rightLeg.pitch = key(s, C_T, C_RL) + 0.45f * alt;
                        m.leftLeg.pitch = key(s, C_T, C_LL) - 0.45f * alt;
                        m.rightLeg.roll = key(s, C_T, C_RLR);
                    }
                }
                case WINDOW -> crawl(m, t, zombie);
            }
        }
        m.hat.copyTransform(m.head);
        return true;
    }

    /** Ползком сквозь окно: руки поочерёдно тянутся вперёд и подтягивают тело. */
    private static void crawl(BipedEntityModel<?> m, float t, boolean zombie) {
        float s = MathHelper.sin(t * 0.55f), c = MathHelper.cos(t * 0.55f);
        lean(m, 0f);
        m.rightArm.pitch = MathHelper.PI + 0.3f + 0.5f * s;
        m.leftArm.pitch = MathHelper.PI + 0.3f - 0.5f * s;
        m.rightArm.yaw = -0.2f + 0.12f * c;
        m.leftArm.yaw = 0.2f + 0.12f * c;
        m.rightArm.roll = 0.1f;
        m.leftArm.roll = -0.1f;
        m.rightLeg.pitch = 0.1f + 0.15f * s;
        m.leftLeg.pitch = 0.1f - 0.15f * s;
        m.rightLeg.roll = 0.1f;
        m.leftLeg.roll = -0.1f;
        if (zombie) {
            m.head.pitch = -1.05f;
            m.head.yaw *= 0.4f;
        }
    }

    /** Лежит после падения; в конце упирается руками и встаёт. */
    private static void prone(BipedEntityModel<?> m, float q, float t, boolean zombie) {
        float up = smooth((q - 0.65f) / 0.35f);
        lean(m, 0f);
        ModelPart ra = m.rightArm, la = m.leftArm;
        ra.pitch = MathHelper.lerp(up, -MathHelper.PI + 0.55f, -1.45f);
        la.pitch = MathHelper.lerp(up, -MathHelper.PI + 0.85f, -1.45f);
        ra.roll = MathHelper.lerp(up, -0.55f, -0.1f);
        la.roll = MathHelper.lerp(up, 0.45f, 0.1f);
        m.rightLeg.pitch = 0.05f;
        m.leftLeg.pitch = MathHelper.lerp(up, -0.35f, -0.9f);
        m.rightLeg.roll = 0.14f;
        m.leftLeg.roll = -0.1f;
        if (zombie) {
            m.head.pitch = -1.0f;
            m.head.roll = 0.45f * (1f - up);
            m.head.yaw = 0f;
            // упавший зомби слабо шевелится
            ra.pitch += 0.12f * MathHelper.sin(t * 0.3f);
        }
    }
}
