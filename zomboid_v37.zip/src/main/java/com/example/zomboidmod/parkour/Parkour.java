package com.example.zomboidmod.parkour;

import com.example.zomboidmod.BodyPart;
import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.PzTrait;
import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.Weight;
import com.example.zomboidmod.WoundType;
import com.example.zomboidmod.Wounds;
import com.example.zomboidmod.ZombieKind;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.Survival;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PaneBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;

/**
 * Паркур как в Project Zomboid: перемахнуть через низкий забор (на бегу — быстрее, но можно споткнуться),
 * перелезть через высокий (долго, тратит силы, можно сорваться), пролезть в окно (если стекло разбито —
 * осколки режут; на бегу — нырок с кувырком). Зомби тоже лезут в окна и переваливаются через заборы.
 *
 * Движение по маршруту ведёт клиент (плавно), сервер проверяет маршрут, считает риски и пропускает
 * игрока сквозь блоки на время перелезания.
 */
public final class Parkour {
    private Parkour() {
    }

    public enum Kind { VAULT, CLIMB, WINDOW }

    public static Block BROKEN_WINDOW;

    // =====================================================================================
    //                                       маршрут
    // =====================================================================================

    /** Что впереди и куда можно перелезть. */
    public static final class Route {
        public Kind kind;
        public Direction dir;
        public boolean closed;   // окно застеклено — сначала разбить
        public boolean glass;    // в раме торчат осколки
        public BlockPos pane;    // где стекло / осколки
        public BlockPos obstacle;
        public double fy, top, ground, face, lat;
        public int depth = 1;    // сколько блоков стены (окно в двойной стене — 2)
    }

    private static double colTop(World w, BlockPos p) {
        VoxelShape s = w.getBlockState(p).getCollisionShape(w, p);
        return s.isEmpty() ? Double.NaN : p.getY() + s.getMax(Direction.Axis.Y);
    }

    private static double colBottom(World w, BlockPos p) {
        VoxelShape s = w.getBlockState(p).getCollisionShape(w, p);
        return s.isEmpty() ? Double.NaN : p.getY() + s.getMin(Direction.Axis.Y);
    }

    public static boolean isGlassPane(BlockState s) {
        return s.getBlock() instanceof PaneBlock && !s.isOf(Blocks.IRON_BARS);
    }

    /** Нижняя граница первой преграды над высотой y в столбце (не считая самого препятствия). */
    private static double ceiling(World w, int x, int z, double y, double max) {
        for (int cy = MathHelper.floor(y - 0.01); cy <= MathHelper.floor(y + max); cy++) {
            BlockPos c = new BlockPos(x, cy, z);
            VoxelShape s = w.getBlockState(c).getCollisionShape(w, c);
            if (s.isEmpty()) continue;
            double t = cy + s.getMax(Direction.Axis.Y);
            if (t <= y + 0.01) continue;
            return Math.max(y, cy + s.getMin(Direction.Axis.Y));
        }
        return y + max;
    }

    private static boolean free(World w, Entity e, double x1, double y1, double z1, double x2, double y2, double z2) {
        return w.isSpaceEmpty(e, new Box(Math.min(x1, x2), y1, Math.min(z1, z2), Math.max(x1, x2), y2, Math.max(z1, z2)));
    }

    /** Мировые координаты точки: a — расстояние за ближнюю грань препятствия по ходу, поперёк — r.lat. */
    private static Vec3d at(Route r, double a, double y) {
        int dx = r.dir.getOffsetX(), dz = r.dir.getOffsetZ();
        double s = dx + dz;
        return new Vec3d(dx != 0 ? r.face + s * a : r.lat, y, dz != 0 ? r.face + s * a : r.lat);
    }

    /** Свободна ли коробка шириной 2·hw поперёк, от a1 до a2 по ходу, от y1 до y2. */
    private static boolean freeSpan(World w, Entity e, Route r, double a1, double a2, double hw, double y1, double y2) {
        Vec3d p = at(r, a1, y1), q = at(r, a2, y2);
        int dx = r.dir.getOffsetX();
        if (dx != 0) return free(w, e, p.x, y1, r.lat - hw, q.x, y2, r.lat + hw);
        return free(w, e, r.lat - hw, y1, p.z, r.lat + hw, y2, q.z);
    }

    /** Самая высокая поверхность в столбце на расстоянии a, где помещается тело высотой h. NaN — негде. */
    private static double landing(World w, Entity e, Route r, double a, double maxY, double minY, double h) {
        Vec3d c = at(r, a, maxY);
        int x = MathHelper.floor(c.x), z = MathHelper.floor(c.z);
        for (int cy = MathHelper.floor(maxY + 0.01); cy >= MathHelper.floor(minY) - 1; cy--) {
            double t = colTop(w, new BlockPos(x, cy, z));
            if (Double.isNaN(t)) continue;
            if (t > maxY + 0.01) return Double.NaN;      // над головой преграда
            if (t < minY) return Double.NaN;             // слишком глубоко
            return freeSpan(w, e, r, a - 0.29, a + 0.29, 0.29, t + 0.01, t + h) ? t : Double.NaN;
        }
        return Double.NaN;
    }

    /**
     * Что можно сделать перед собой в сторону d. null — ничего (или хватит обычного прыжка).
     * zombie — для зомби (немного дальше дотягиваются, по высоким заборам не лазят).
     */
    public static Route plan(World w, Entity e, Direction d, boolean zombie) {
        if (d == null || d.getAxis().isVertical()) return null;
        double fy = e.getY();
        int dx = d.getOffsetX(), dz = d.getOffsetZ();
        BlockPos feet = BlockPos.ofFloored(e.getX(), fy + 0.01, e.getZ());
        BlockPos o = feet.offset(d);
        Route r = new Route();
        r.dir = d;
        r.fy = fy;
        r.obstacle = o;
        r.face = dx > 0 ? o.getX() : dx < 0 ? o.getX() + 1 : dz > 0 ? o.getZ() : o.getZ() + 1;
        double along = dx != 0 ? e.getX() : e.getZ();
        double gap = (r.face - along) * (dx + dz);
        if (gap > (zombie ? 1.0 : 0.85) || gap < -0.05) return null;
        double cellLat = dx != 0 ? o.getZ() : o.getX();
        double eLat = dx != 0 ? e.getZ() : e.getX();

        // ----- высота препятствия, начинающегося на уровне ног -----
        int by = feet.getY();
        double top = Double.NaN;
        double t0 = colTop(w, o.down());
        if (!Double.isNaN(t0) && t0 > fy + 0.05) top = t0;               // забор ниже уровня ног торчит вверх
        BlockState s0 = w.getBlockState(o);
        if (s0.getBlock() instanceof net.minecraft.block.DoorBlock || s0.isIn(net.minecraft.registry.tag.BlockTags.CLIMBABLE)) return null;
        double b1 = colBottom(w, o), t1 = colTop(w, o);
        if (!Double.isNaN(t1) && t1 > fy + 0.05 && b1 <= fy + 0.55) top = Double.isNaN(top) ? t1 : Math.max(top, t1);
        if (Double.isNaN(top)) return null;
        for (int k = 1; k <= 3; k++) {
            BlockPos c = new BlockPos(o.getX(), by + k, o.getZ());
            if (isGlassPane(w.getBlockState(c))) break;
            double b = colBottom(w, c);
            if (Double.isNaN(b) || b > top + 0.05) break;
            top = Math.max(top, colTop(w, c));
        }
        double H = top - fy;
        if (H < 0.3 || H > 2.6) return null;
        r.top = top;

        // что в проёме над препятствием
        BlockPos above = new BlockPos(o.getX(), MathHelper.floor(top + 0.01), o.getZ());
        BlockState as = w.getBlockState(above);
        if (H <= 1.6 && isGlassPane(as)) {
            r.closed = true;
            r.kind = Kind.WINDOW;
            r.pane = above;
            return r;
        }
        if (BROKEN_WINDOW != null && as.isOf(BROKEN_WINDOW)) {
            r.glass = true;
            r.pane = above;
        }
        double ceil = ceiling(w, o.getX(), o.getZ(), top, 2.0) - top;

        if (H <= 1.05) {
            if (ceil >= 1.8 || ceil < 0.62) return null;   // низкое — хватит прыжка; щель — не пролезть
            return window(w, e, r, cellLat, zombie) ? r : null;
        }
        if (H <= 1.6) {
            if (ceil >= 1.8) {
                r.kind = Kind.VAULT;
                r.lat = MathHelper.clamp(eLat, cellLat + 0.3, cellLat + 0.7);
                r.ground = landing(w, e, r, 1.45, top + 0.01, fy - 3.0, 1.8);
                if (Double.isNaN(r.ground)) return null;
                return r;
            }
            if (ceil >= 0.62) return window(w, e, r, cellLat, zombie) ? r : null;
            return null;
        }
        // высокий забор или стена
        if (zombie || ceil < 1.8) return null;
        r.kind = Kind.CLIMB;
        r.lat = MathHelper.clamp(eLat, cellLat + 0.3, cellLat + 0.7);
        // над головой перед стеной должно быть свободно, чтобы подтянуться
        if (!freeSpan(w, e, r, -0.62, -0.02, 0.29, fy + 1.8, top + 1.6)) return null;
        r.ground = landing(w, e, r, 1.45, top + 0.01, fy - 3.0, 1.8);
        if (Double.isNaN(r.ground)) return null;
        return r;
    }

    /** Окно (или узкий проём над препятствием): пролезть ползком над подоконником. */
    private static boolean window(World w, Entity e, Route r, double cellLat, boolean zombie) {
        r.kind = Kind.WINDOW;
        r.lat = cellLat + 0.5;
        double sill = r.top;
        if (!freeSpan(w, e, r, 0.02, 0.98, 0.29, sill + 0.01, sill + 0.6)) return false;
        for (int i = 1; i <= 3; i++) {
            BlockPos ci = r.obstacle.offset(r.dir, i);
            BlockPos ab = new BlockPos(ci.getX(), MathHelper.floor(sill + 0.01), ci.getZ());
            if (!freeSpan(w, e, r, i + 0.02, i + 0.98, 0.29, sill + 0.01, sill + 0.6)) {
                if (!isGlassPane(w.getBlockState(ab))) return false;
                r.closed = true;   // изнутри: стекло во внешней раме ещё целое
                r.pane = ab;
                return true;
            }
            // осколки во второй раме двойной стены
            if (BROKEN_WINDOW != null && w.getBlockState(ab).isOf(BROKEN_WINDOW)) {
                r.glass = true;
                r.pane = ab;
            }
            double g = landing(w, e, r, i + 0.5, sill + 0.01, r.fy - 3.0, 1.8);
            if (Double.isNaN(g)) g = landing(w, e, r, i + 0.5, sill + 0.01, r.fy - 3.0, 0.6);
            if (Double.isNaN(g)) continue;
            // на второй раме (такой же подоконник) встать нельзя — значит, лезем дальше
            if (g > sill - 0.3 && !freeSpan(w, e, r, i + 0.21, i + 0.79, 0.29, g + 0.01, g + 1.8)) continue;
            r.depth = i;
            r.ground = g;
            return true;
        }
        return false;
    }

    // =====================================================================================
    //                                 движение по ключам
    // =====================================================================================

    public static final int E_GRAB = 0, E_LAND = 1, E_GLASS = 2, E_FALL = 3, E_STRAIN = 4;

    /** Идущее перелезание: ключевые точки (моменты в тиках и позиции ног) и состояние. */
    public static final class Active {
        public int kind;
        public int total;
        public int crawlFrom = -1, crawlTo = -1, proneFrom = -1;
        public boolean fail;
        public float[] times;
        public double[] pts;
        public int t;
        public boolean local;
        // только на сервере
        int[] evT = new int[0], evK = new int[0];
        BlockState mat;
        BlockPos at;
        boolean glass;
        float cutChance;

        public Kind kindEnum() {
            return Kind.values()[MathHelper.clamp(kind, 0, Kind.values().length - 1)];
        }

        /** Лежит/ползёт (поза ползком у игрока, наклон у зомби). */
        public boolean lying(int tt) {
            return (crawlTo > crawlFrom && tt >= crawlFrom && tt < crawlTo) || (proneFrom >= 0 && tt >= proneFrom && tt < total);
        }

        /** Плавная степень «лёжа» 0..1 для рисования. */
        public float lie(float tt) {
            float v = 0f;
            if (crawlTo > crawlFrom) v = Math.max(v, ramp(tt, crawlFrom, crawlTo, 4f));
            if (proneFrom >= 0) v = Math.max(v, ramp(tt, proneFrom - 3, total, 4f));
            return v;
        }

        private static float ramp(float t, float a, float b, float r) {
            if (t < a || t > b) return 0f;
            float k = Math.min(1f, Math.min((t - a) / r, (b - t) / r));
            return k * k * (3f - 2f * k);
        }

        /** Позиция ног в момент tt: кривая Эрмита без перелётов (на изломах и в экстремумах — плавная остановка). */
        public Vec3d sample(float tt) {
            int n = times.length;
            if (n == 1 || tt <= times[0]) return p(0);
            if (tt >= times[n - 1]) return p(n - 1);
            int i = 0;
            while (i < n - 2 && tt > times[i + 1]) i++;
            float h = times[i + 1] - times[i];
            float s = h <= 0 ? 1f : (tt - times[i]) / h;
            float s2 = s * s, s3 = s2 * s;
            double[] r = new double[3];
            for (int a = 0; a < 3; a++) {
                double p0 = pts[i * 3 + a], p1 = pts[(i + 1) * 3 + a];
                double m0 = tangent(i, a), m1 = tangent(i + 1, a);
                r[a] = (2 * s3 - 3 * s2 + 1) * p0 + (s3 - 2 * s2 + s) * h * m0 + (-2 * s3 + 3 * s2) * p1 + (s3 - s2) * h * m1;
            }
            return new Vec3d(r[0], r[1], r[2]);
        }

        private double tangent(int i, int a) {
            int n = times.length;
            if (i <= 0 || i >= n - 1) return 0;
            double pp = pts[(i - 1) * 3 + a], p = pts[i * 3 + a], pn = pts[(i + 1) * 3 + a];
            if ((p - pp) * (pn - p) <= 0) return 0;
            double d0 = (p - pp) / Math.max(0.001, times[i] - times[i - 1]);
            double d1 = (pn - p) / Math.max(0.001, times[i + 1] - times[i]);
            double m = (pn - pp) / Math.max(0.001, times[i + 1] - times[i - 1]);
            double lim = 3 * Math.min(Math.abs(d0), Math.abs(d1));
            return Math.abs(m) > lim ? Math.signum(m) * lim : m;
        }

        private Vec3d p(int i) {
            return new Vec3d(pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2]);
        }

        public void setStart(Vec3d v) {
            pts[0] = v.x;
            pts[1] = v.y;
            pts[2] = v.z;
        }
    }

    /** Сборщик ключей. */
    private static final class Keys {
        final java.util.ArrayList<Float> t = new java.util.ArrayList<>();
        final java.util.ArrayList<Vec3d> p = new java.util.ArrayList<>();
        final java.util.ArrayList<int[]> ev = new java.util.ArrayList<>();

        Keys add(float time, Vec3d pos) {
            if (!t.isEmpty() && time <= t.get(t.size() - 1)) time = t.get(t.size() - 1) + 1f;
            t.add(time);
            p.add(pos);
            return this;
        }

        float last() {
            return t.get(t.size() - 1);
        }

        void event(float time, int kind) {
            ev.add(new int[]{Math.max(1, Math.round(time)), kind});
        }

        Active build(Kind kind) {
            Active a = new Active();
            a.kind = kind.ordinal();
            a.times = new float[t.size()];
            a.pts = new double[t.size() * 3];
            for (int i = 0; i < t.size(); i++) {
                a.times[i] = t.get(i);
                a.pts[i * 3] = p.get(i).x;
                a.pts[i * 3 + 1] = p.get(i).y;
                a.pts[i * 3 + 2] = p.get(i).z;
            }
            a.total = Math.round(last());
            a.evT = new int[ev.size()];
            a.evK = new int[ev.size()];
            for (int i = 0; i < ev.size(); i++) {
                a.evT[i] = ev.get(i)[0];
                a.evK[i] = ev.get(i)[1];
            }
            return a;
        }
    }

    /**
     * Маршрут → ключи. speed — множитель длительности (1 — обычно, меньше — быстрее).
     * fail — сорвался с высокого забора; trip — споткнулся/нырок с кувырком (лежит после приземления).
     */
    static Active build(Route r, Entity e, boolean sprint, boolean zombie, boolean fail, boolean trip, float speed) {
        Keys k = new Keys();
        Vec3d cur = e.getPos();
        k.add(0, cur);
        double top = r.top, g = r.ground;
        double drop = Math.max(0, top - g - 1.6);
        int prone = 0;
        switch (r.kind) {
            case VAULT -> {
                float T = (zombie ? (sprint ? 13 : 22) : (sprint ? 9 : 14)) * speed;
                k.add(0.3f * T, at(r, -0.32, top - 0.25));
                k.event(0.3f * T, E_GRAB);
                k.add(0.58f * T, at(r, 0.5, top + 0.12));
                double mid = Math.max(g, top - 0.45);
                k.add(0.82f * T, at(r, trip ? 1.35 : 1.3, mid));
                k.add(T + (float) (2.5 * drop), at(r, trip ? 1.55 : 1.42, g));
                k.event(k.last(), trip ? E_FALL : E_LAND);
                if (trip) prone = zombie ? 26 : 22;
            }
            case CLIMB -> {
                if (fail) {
                    k.add(5 * speed, at(r, -0.32, r.fy + 0.4));
                    k.event(5 * speed, E_GRAB);
                    k.add(17 * speed, at(r, -0.32, top - 1.35));
                    k.event(17 * speed, E_STRAIN);
                    k.add(22 * speed, at(r, -0.34, top - 1.45));
                    k.add(29 * speed, at(r, -0.45, r.fy));
                    k.event(k.last(), E_LAND);
                } else {
                    k.add(5 * speed, at(r, -0.32, r.fy + 0.4));
                    k.event(5 * speed, E_GRAB);
                    k.add(18 * speed, at(r, -0.32, top - 1.05));
                    k.event(18 * speed, E_STRAIN);
                    k.add(23 * speed, at(r, -0.24, top + 0.02));
                    k.add(26 * speed, at(r, 0.2, top + 0.04));
                    k.add(29 * speed, at(r, 0.62, top + 0.04));
                    k.event(29 * speed, E_GRAB);
                    if (g < top - 0.4) k.add(32 * speed, at(r, 1.34, top - 0.3));
                    k.add(36 * speed + (float) (2.5 * drop), at(r, 1.42, g));
                    k.event(k.last(), E_LAND);
                }
            }
            case WINDOW -> {
                int n = r.depth;
                float k1, k2, k3;
                if (zombie) {
                    k1 = 12;
                    k2 = k1 + 12 * n;
                    k3 = k2 + 8;
                    prone = 30;
                } else if (sprint) {
                    k1 = 4;
                    k2 = k1 + 4 * n;
                    k3 = k2 + 4;
                    prone = 24;
                } else {
                    k1 = 8 * speed;
                    k2 = k1 + 7 * n * speed;
                    k3 = k2 + 6;
                }
                k.add(k1, at(r, -0.31, top));
                k.event(k1, E_GRAB);
                k.add(k2, at(r, n + 0.31, top));
                k.event((k1 + k2) / 2f, E_GLASS);
                k.add(k3 + (float) (2.0 * Math.max(0, top - g - 1.0)), at(r, n + 0.45, g));
                k.event(k.last(), prone > 0 ? E_FALL : E_LAND);
            }
        }
        float end = k.last();
        if (prone > 0) k.add(end + prone, k.p.get(k.p.size() - 1));
        Active a = k.build(r.kind);
        if (prone > 0) a.proneFrom = Math.round(end);
        if (r.kind == Kind.WINDOW) {
            a.crawlFrom = zombie ? Math.max(0, Math.round(a.times[1]) - 4) : 0;
            a.crawlTo = Math.round(end);
        }
        a.fail = fail;
        a.glass = r.glass;
        a.at = r.obstacle;
        a.mat = e.getWorld().getBlockState(r.obstacle);
        return a;
    }

    // =====================================================================================
    //                                       сеть
    // =====================================================================================

    /** Игрок нажал «прыжок» у препятствия: dir — сторона света (ordinal), sprint — был на бегу. */
    public record RequestPayload(int dir, boolean sprint) implements CustomPayload {
        public static final CustomPayload.Id<RequestPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "climb_req"));
        public static final PacketCodec<RegistryByteBuf, RequestPayload> CODEC = PacketCodec.of((v, buf) -> {
            buf.writeVarInt(v.dir());
            buf.writeBoolean(v.sprint());
        }, buf -> new RequestPayload(buf.readVarInt(), buf.readBoolean()));

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Начало перелезания (a == null — отказ). */
    public record StartPayload(int entity, Active a) implements CustomPayload {
        public static final CustomPayload.Id<StartPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "climb"));
        public static final PacketCodec<RegistryByteBuf, StartPayload> CODEC = PacketCodec.of(StartPayload::write, StartPayload::read);

        void write(RegistryByteBuf buf) {
            buf.writeVarInt(entity);
            buf.writeBoolean(a != null);
            if (a == null) return;
            buf.writeVarInt(a.kind);
            buf.writeVarInt(a.total);
            buf.writeVarInt(a.crawlFrom);
            buf.writeVarInt(a.crawlTo);
            buf.writeVarInt(a.proneFrom);
            buf.writeBoolean(a.fail);
            buf.writeVarInt(a.times.length);
            for (int i = 0; i < a.times.length; i++) {
                buf.writeFloat(a.times[i]);
                buf.writeDouble(a.pts[i * 3]);
                buf.writeDouble(a.pts[i * 3 + 1]);
                buf.writeDouble(a.pts[i * 3 + 2]);
            }
        }

        static StartPayload read(RegistryByteBuf buf) {
            int id = buf.readVarInt();
            if (!buf.readBoolean()) return new StartPayload(id, null);
            Active a = new Active();
            a.kind = buf.readVarInt();
            a.total = buf.readVarInt();
            a.crawlFrom = buf.readVarInt();
            a.crawlTo = buf.readVarInt();
            a.proneFrom = buf.readVarInt();
            a.fail = buf.readBoolean();
            int n = MathHelper.clamp(buf.readVarInt(), 1, 64);
            a.times = new float[n];
            a.pts = new double[n * 3];
            for (int i = 0; i < n; i++) {
                a.times[i] = buf.readFloat();
                a.pts[i * 3] = buf.readDouble();
                a.pts[i * 3 + 1] = buf.readDouble();
                a.pts[i * 3 + 2] = buf.readDouble();
            }
            return new StartPayload(id, a);
        }

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    // =====================================================================================
    //                                   состояние на сервере
    // =====================================================================================

    private static final Map<UUID, Active> PLAYERS = new HashMap<>();
    private static final Map<UUID, Long> GLASS_STEP = new HashMap<>();

    /** Клиентская сторона подставляет сюда свой поиск (по id сущности). */
    public static Function<Entity, Active> CLIENT = e -> null;

    public static Active active(Entity e) {
        if (!(e instanceof PlayerEntity) && !(e instanceof PzZombieEntity)) return null;
        if (e.getWorld().isClient) return CLIENT.apply(e);
        if (e instanceof PzZombieEntity z) return z.climb;
        return PLAYERS.get(e.getUuid());
    }

    public static boolean climbing(Entity e) {
        return active(e) != null;
    }

    /** Поза игрока на время перелезания (ползком в окне, лёжа после падения) или null. */
    public static EntityPose forcedPose(PlayerEntity p) {
        Active a = active(p);
        if (a == null) return null;
        return a.lying(a.t) ? EntityPose.SWIMMING : (a.t <= a.total ? EntityPose.STANDING : null);
    }

    public static void register() {
        BROKEN_WINDOW = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, "broken_window"),
                new BrokenWindowBlock(AbstractBlock.Settings.create().strength(0.3f).noCollision().nonOpaque()
                        .sounds(BlockSoundGroup.GLASS).dropsNothing()));
        Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, "broken_window"), new BlockItem(BROKEN_WINDOW, new Item.Settings()));

        PayloadTypeRegistry.playC2S().register(RequestPayload.ID, RequestPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(StartPayload.ID, StartPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(RequestPayload.ID, (pl, ctx) -> ctx.server().execute(() -> request(ctx.player(), pl.dir(), pl.sprint())));
        ServerTickEvents.END_SERVER_TICK.register(Parkour::tick);

        // разбил стекло — в раме остаются осколки; голой рукой вынимать их — можно порезаться
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (!(player instanceof ServerPlayerEntity sp) || sp.isCreative()) return;
            if (isGlassPane(state)) shatter(world, pos, state);
            else if (state.isOf(BROKEN_WINDOW) && sp.getMainHandStack().isEmpty() && sp.getRandom().nextFloat() < 0.3f) {
                Wounds.addWound(sp, sp.getMainArm() == net.minecraft.util.Arm.RIGHT ? BodyPart.R_HAND : BodyPart.L_HAND, WoundType.SCRATCH);
            }
        });
    }

    /** Стекло разбито (игроком, зомби или пулей): в раме остаются острые осколки, звон слышно далеко. */
    public static void shatter(World w, BlockPos pos, BlockState old) {
        if (w.isClient || !isGlassPane(old) || BROKEN_WINDOW == null) return;
        Direction.Axis axis = (old.get(PaneBlock.EAST) || old.get(PaneBlock.WEST)) ? Direction.Axis.X
                : (old.get(PaneBlock.NORTH) || old.get(PaneBlock.SOUTH)) ? Direction.Axis.Z : Direction.Axis.X;
        if (w.getBlockState(pos).isAir()) w.setBlockState(pos, BROKEN_WINDOW.getDefaultState().with(BrokenWindowBlock.AXIS, axis));
        if (w instanceof ServerWorld sw) Noise.emitAt(sw, pos, 22);
    }

    private static void reject(ServerPlayerEntity p) {
        ServerPlayNetworking.send(p, new StartPayload(p.getId(), null));
    }

    private static void request(ServerPlayerEntity p, int dirOrd, boolean running) {
        if (dirOrd < 2 || dirOrd > 5 || PLAYERS.containsKey(p.getUuid()) || !p.isAlive() || p.hasVehicle() || p.isSpectator()
                || p.getAbilities().flying || p.isSleeping()) {
            reject(p);
            return;
        }
        Direction d = Direction.values()[dirOrd];
        Route r = plan(p.getWorld(), p, d, false);
        if (r == null || r.closed) {
            reject(p);
            return;
        }
        boolean creative = p.isCreative();
        boolean sprint = (p.isSprinting() || running) && r.kind != Kind.CLIMB;
        Mood m = Survival.mood(p);
        int str = Skills.level(p, PzSkill.STRENGTH), fit = Skills.level(p, PzSkill.FITNESS);
        int nim = Skills.level(p, PzSkill.NIMBLE), spr = Skills.level(p, PzSkill.SPRINTING);
        int wl = Weight.level(Weight.carried(p) / Weight.capacity(str));
        int panic = Mood.panic(m.panic);
        boolean agile = Skills.has(p, PzTrait.ATHLETIC) || Skills.has(p, PzTrait.GYMNAST);
        Random rnd = p.getRandom();
        boolean fail = false, trip = false;
        if (!creative) {
            if (r.kind == Kind.CLIMB) {
                double ch = 0.28 - 0.022 * str - 0.02 * fit + 0.12 * wl + (m.endurance < 0.25f ? 0.25 : 0) + 0.05 * panic - (agile ? 0.08 : 0);
                if (m.endurance < 0.05f || wl >= 3) ch = 1;
                fail = rnd.nextDouble() < MathHelper.clamp(ch, 0.02, 1.0);
            } else if (sprint) {
                double ch = 0.2 - 0.02 * spr - 0.015 * nim + 0.1 * wl + (m.endurance < 0.25f ? 0.2 : 0) + 0.04 * panic - (agile ? 0.06 : 0);
                trip = r.kind == Kind.WINDOW || rnd.nextDouble() < MathHelper.clamp(ch, 0.02, 0.9);
            }
        }
        float speed = creative ? 0.85f : (float) MathHelper.clamp(1.15 - 0.025 * (str + fit) - (agile ? 0.08 : 0) + 0.08 * wl, 0.72, 1.4);
        Active a = build(r, p, sprint, false, fail, trip, speed);
        a.cutChance = creative ? 0f : (float) MathHelper.clamp((sprint ? 0.9 : 0.5) - 0.04 * nim, 0.1, 0.95);

        if (!creative) {
            float cost = switch (r.kind) {
                case VAULT -> sprint ? 0.025f : 0.015f;
                case CLIMB -> 0.07f;
                case WINDOW -> 0.03f;
            };
            m.endurance = Math.max(0f, m.endurance - cost * (1f + 0.25f * wl));
            Skills.addXp(p, PzSkill.NIMBLE, 0.5f);
            if (r.kind == Kind.CLIMB) {
                Skills.addXp(p, PzSkill.FITNESS, 1.5f);
                Skills.addXp(p, PzSkill.STRENGTH, 1f);
            }
            if (sprint) Skills.addXp(p, PzSkill.SPRINTING, 1f);
        }
        PLAYERS.put(p.getUuid(), a);
        p.setSprinting(false);
        broadcast(p, a);
        Noise.emitFrom(p, r.kind == Kind.CLIMB ? 8 : trip ? 12 : 5);
        if (fail) p.sendMessage(Text.literal(m.endurance < 0.05f ? "Нет сил перелезть" : wl >= 3 ? "Слишком тяжело — не перелезть с таким грузом"
                : "Сорвался — не хватило сил"), true);
    }

    private static void broadcast(Entity e, Active a) {
        StartPayload pl = new StartPayload(e.getId(), a);
        if (e instanceof ServerPlayerEntity sp) ServerPlayNetworking.send(sp, pl);
        for (ServerPlayerEntity o : PlayerLookup.tracking(e)) if (o != e) ServerPlayNetworking.send(o, pl);
    }

    private static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Active>> it = PLAYERS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Active> en = it.next();
            Active a = en.getValue();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
            if (p == null || !p.isAlive() || p.isRemoved()) {
                it.remove();
                continue;
            }
            a.t++;
            for (int i = 0; i < a.evT.length; i++) if (a.evT[i] == a.t) event(p, a, a.evK[i]);
            p.fallDistance = 0;
            if (a.t > a.total + 4) {
                it.remove();
                p.noClip = false;
                continue;
            }
            p.noClip = true;   // пакеты движения между тиками принимаются сквозь блоки (сброс — в PlayerEntity.tick)
        }
        if (server.getTicks() % 1200 == 0) GLASS_STEP.clear();
    }

    /** Звуки и последствия по ходу перелезания. */
    private static void event(LivingEntity e, Active a, int kind) {
        World w = e.getWorld();
        BlockSoundGroup g = a.mat != null ? a.mat.getSoundGroup() : BlockSoundGroup.WOOD;
        boolean zombie = e instanceof PzZombieEntity;
        switch (kind) {
            case E_GRAB -> w.playSound(null, e.getX(), e.getY(), e.getZ(), g.getHitSound(), zombie ? SoundCategory.HOSTILE : SoundCategory.PLAYERS,
                    0.8f, g.getPitch() * 0.9f);
            case E_STRAIN -> {
                w.playSound(null, e.getX(), e.getY(), e.getZ(), g.getStepSound(), SoundCategory.PLAYERS, 0.7f, g.getPitch() * 0.8f);
                if (zombie) e.playSound(SoundEvents.ENTITY_ZOMBIE_AMBIENT, 1.0f, 0.7f);
            }
            case E_LAND -> {
                BlockPos below = BlockPos.ofFloored(e.getX(), e.getY() - 0.2, e.getZ());
                BlockSoundGroup lg = w.getBlockState(below).getSoundGroup();
                w.playSound(null, e.getX(), e.getY(), e.getZ(), lg.getFallSound(), SoundCategory.PLAYERS, 0.7f, lg.getPitch());
            }
            case E_FALL -> {
                w.playSound(null, e.getX(), e.getY(), e.getZ(), zombie ? SoundEvents.ENTITY_ZOMBIE_STEP : SoundEvents.ENTITY_PLAYER_BIG_FALL,
                        SoundCategory.PLAYERS, 1.0f, 0.9f);
                if (e instanceof ServerPlayerEntity sp && !sp.isCreative()) {
                    sp.sendMessage(Text.literal(a.kindEnum() == Kind.WINDOW ? "Нырнул в окно и покатился по полу" : "Споткнулся и упал!"), true);
                    if (w instanceof ServerWorld sw) Noise.emitAt(sw, sp.getBlockPos(), 10);
                }
            }
            case E_GLASS -> {
                if (!a.glass) {
                    w.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.BLOCK_WOOD_STEP, SoundCategory.PLAYERS, 0.4f, 1.1f);
                    return;
                }
                w.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.BLOCK_GLASS_STEP, SoundCategory.PLAYERS, 1.0f, 1.2f);
                if (e instanceof ServerPlayerEntity sp && sp.getRandom().nextFloat() < a.cutChance) {
                    BodyPart[] parts = {BodyPart.L_HAND, BodyPart.R_HAND, BodyPart.L_FOREARM, BodyPart.R_FOREARM, BodyPart.L_THIGH,
                            BodyPart.R_THIGH, BodyPart.L_SHIN, BodyPart.R_SHIN, BodyPart.UPPER_TORSO, BodyPart.LOWER_TORSO};
                    BodyPart part = parts[sp.getRandom().nextInt(parts.length)];
                    Wounds.addWound(sp, part, sp.getRandom().nextFloat() < 0.3f ? WoundType.CUT : WoundType.SCRATCH);
                }
            }
            default -> {
            }
        }
    }

    /** Прошёл сквозь раму с осколками (а не перелез): может оцарапать ноги. */
    static void glassStep(ServerPlayerEntity p) {
        if (p.isCreative() || PLAYERS.containsKey(p.getUuid())) return;
        long now = p.getWorld().getTime();
        Long last = GLASS_STEP.get(p.getUuid());
        if (last != null && now - last < 30) return;
        GLASS_STEP.put(p.getUuid(), now);
        p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_GLASS_STEP, SoundCategory.PLAYERS, 0.9f, 1.2f);
        if (p.getRandom().nextFloat() < 0.35f) {
            BodyPart[] legs = {BodyPart.L_SHIN, BodyPart.R_SHIN, BodyPart.L_THIGH, BodyPart.R_THIGH};
            Wounds.addWound(p, legs[p.getRandom().nextInt(legs.length)], WoundType.SCRATCH);
        }
    }

    // =====================================================================================
    //                                         зомби
    // =====================================================================================

    private static Direction horiz(double x, double z) {
        return Math.abs(x) > Math.abs(z) ? (x > 0 ? Direction.EAST : Direction.WEST) : (z > 0 ? Direction.SOUTH : Direction.NORTH);
    }

    private static void face(PzZombieEntity z, Direction d) {
        float yaw = d.asRotation();
        z.setYaw(yaw);
        z.setBodyYaw(yaw);
        z.setHeadYaw(yaw);
    }

    /** Зомби начинает лезть по маршруту. */
    public static void startZombie(PzZombieEntity z, Route r) {
        boolean sprinter = z.kind() == ZombieKind.SPRINTER;
        boolean trip = r.kind == Kind.WINDOW || z.getRandom().nextFloat() < (sprinter ? 0.3f : 0.55f);
        Active a = build(r, z, sprinter, true, false, trip, 1f);
        z.climb = a;
        z.getNavigation().stop();
        z.setAiDisabled(true);
        z.noClip = true;
        z.setNoGravity(true);
        z.setVelocity(Vec3d.ZERO);
        face(z, r.dir);
        broadcast(z, a);
        if (z.getWorld() instanceof ServerWorld sw) Noise.emitAt(sw, z.getBlockPos(), 8);
    }

    /** Каждый тик лезущего зомби (после обычного тика). */
    public static void tickZombie(PzZombieEntity z) {
        Active a = z.climb;
        a.t++;
        for (int i = 0; i < a.evT.length; i++) if (a.evT[i] == a.t) event(z, a, a.evK[i]);
        Vec3d p = a.sample(a.t);
        z.setPosition(p.x, p.y, p.z);
        z.setVelocity(Vec3d.ZERO);
        z.fallDistance = 0;
        if (a.t >= a.total) stopZombie(z);
    }

    public static void stopZombie(PzZombieEntity z) {
        z.climb = null;
        z.noClip = false;
        z.setNoGravity(false);
        z.setAiDisabled(false);
    }

    /**
     * Мозги зомби у препятствий: упёрся в забор — переваливается, в окно — бьёт стекло и лезет,
     * пути к жертве нет — ищет ближайшее окно, ведущее к ней.
     */
    public static void zombieThink(PzZombieEntity z, LivingEntity tgt, BlockPos noise) {
        if (z.climb != null || z.isCrawler() || z.hasVehicle() || !z.isOnGround() || z.isBaby()) return;
        World w = z.getWorld();
        Vec3d goal = tgt != null ? tgt.getPos() : noise != null ? Vec3d.ofBottomCenter(noise) : null;
        if (goal == null) return;
        double gx = goal.x - z.getX(), gz = goal.z - z.getZ();
        double dist = Math.sqrt(gx * gx + gz * gz);
        if (dist < 1.3 && Math.abs(goal.y - z.getY()) < 1.5) return;

        // идёт к выбранному окну
        if (z.winGoal != null) {
            if (z.age > z.winUntil) {
                z.winGoal = null;
            } else {
                Vec3d c = Vec3d.ofBottomCenter(z.winGoal);
                double dd = Math.hypot(c.x - z.getX(), c.z - z.getZ());
                if (dd < 0.8) {
                    face(z, z.winDir);
                    Route r = plan(w, z, z.winDir, true);
                    if (r != null && r.closed) {
                        if (z.age % 20 < 5) z.bash(r.pane);
                        return;
                    }
                    z.winGoal = null;
                    if (r != null && !(r.kind == Kind.WINDOW && z.isBrute())) startZombie(z, r);
                }
                return;   // курс к окну держит steer()
            }
        }

        Path path = z.getNavigation().getCurrentPath();
        boolean stuck = path == null || z.getNavigation().isIdle() || !path.reachesTarget();
        boolean detour = path != null && path.getLength() > 2.2 * dist + 6;
        if (!stuck && !detour && !z.horizontalCollision) return;
        if (dist > 22) return;

        // препятствие прямо на пути к цели
        Direction d1 = horiz(gx, gz);
        Direction d2 = Math.abs(gx) > Math.abs(gz) ? horiz(0, gz) : horiz(gx, 0);
        for (Direction d : new Direction[]{d1, d2}) {
            Route r = plan(w, z, d, true);
            if (r == null) continue;
            if (r.closed) {
                face(z, d);
                z.getNavigation().stop();
                if (z.age % 20 < 5) z.bash(r.pane);
                return;
            }
            if (r.kind == Kind.WINDOW && z.isBrute()) continue;
            if (z.getRandom().nextFloat() < 0.5f) startZombie(z, r);
            return;
        }

        // окно поблизости, через которое ближе к цели
        if ((stuck || detour) && z.age % 40 < 5) {
            BlockPos best = null;
            Direction bestD = null;
            double bestScore = Double.MAX_VALUE;
            BlockPos zp = z.getBlockPos();
            for (int dy = -1; dy <= 1; dy++)
                for (int ox = -8; ox <= 8; ox++)
                    for (int oz = -8; oz <= 8; oz++) {
                        BlockPos f = zp.add(ox, dy, oz);
                        if (!w.getBlockState(f).getCollisionShape(w, f).isEmpty() || !w.getBlockState(f.up()).getCollisionShape(w, f.up()).isEmpty())
                            continue;
                        if (w.getBlockState(f.down()).getCollisionShape(w, f.down()).isEmpty()) continue;
                        for (Direction d : Direction.Type.HORIZONTAL) {
                            BlockPos far = f.offset(d, 2);
                            double before = goal.squaredDistanceTo(Vec3d.ofBottomCenter(f));
                            double after = goal.squaredDistanceTo(Vec3d.ofBottomCenter(far));
                            if (after >= before - 1) continue;
                            if (!windowAhead(w, f, d)) continue;
                            double score = Math.sqrt(zp.getSquaredDistance(f)) + Math.sqrt(after) * 1.4;
                            if (score < bestScore) {
                                bestScore = score;
                                best = f;
                                bestD = d;
                            }
                        }
                    }
            if (best != null && bestScore < dist * 1.4 + 10) {
                z.winGoal = best.toImmutable();
                z.winDir = bestD;
                z.winUntil = z.age + 240;
                return;
            }
        }

        // пути нет — прёт напрямую (упрётся в забор или окно — полезет)
        if (stuck) {
            z.pushTo = goal;
            z.pushUntil = z.age + 6;
        }
    }

    /** Каждый тик: держит курс к выбранному окну или напрямую к цели (обычный ИИ перебивает раз в несколько тиков). */
    public static void steer(PzZombieEntity z) {
        if (z.climb != null) return;
        if (z.winGoal != null && z.age > z.winUntil) z.winGoal = null;
        if (z.winGoal != null) {
            Path p = z.getNavigation().getCurrentPath();
            if (p == null || !z.winGoal.equals(p.getTarget())) {
                Vec3d c = Vec3d.ofBottomCenter(z.winGoal);
                if (!z.getNavigation().startMovingTo(c.x, c.y, c.z, 1.0)) {
                    z.pushTo = c;
                    z.pushUntil = z.age + 10;
                }
            }
        }
        if (z.pushTo != null) {
            if (z.age > z.pushUntil) z.pushTo = null;
            else if (z.getNavigation().isIdle()) z.getMoveControl().moveTo(z.pushTo.x, z.pushTo.y, z.pushTo.z, 1.0);
        }
    }

    /** Быстрая проверка: перед клеткой f в сторону d — окно (подоконник и проём над ним). */
    private static boolean windowAhead(World w, BlockPos f, Direction d) {
        BlockPos s = f.offset(d);
        double t = colTop(w, s);
        double h = t - f.getY();
        if (Double.isNaN(t) || h < 0.3 || h > 1.05) return false;
        BlockPos o = s.up();
        BlockState os = w.getBlockState(o);
        boolean opening = isGlassPane(os) || (BROKEN_WINDOW != null && os.isOf(BROKEN_WINDOW)) || os.getCollisionShape(w, o).isEmpty();
        if (!opening) return false;
        return !w.getBlockState(o.up()).getCollisionShape(w, o.up()).isEmpty();   // перемычка сверху
    }
}
