package com.example.zomboidmod.gun;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Модули для оружия: ставятся в гнёзда через экран модулей (клавиша N с оружием в руке). */
public final class Attachment {
    private Attachment() {
    }

    public enum Slot {
        OPTIC("optic", "Прицел"), MUZZLE("muzzle", "Дуло"), UNDER("under", "Под стволом"), MAG("mag", "Магазин");

        public final String key, ru;

        Slot(String key, String ru) {
            this.key = key;
            this.ru = ru;
        }
    }

    public enum Kind {
        RED_DOT("red_dot", "Коллиматорный прицел", Slot.OPTIC, "Быстрое прицеливание: точка вместо мушки, лёгкое приближение"),
        SCOPE_4X("scope_4x", "Оптический прицел 4x", Slot.OPTIC, "Приближение в 4 раза, точнее на дальней дистанции"),
        SCOPE_8X("scope_8x", "Снайперский прицел 8x", Slot.OPTIC, "Приближение в 8 раз — для винтовок"),
        SUPPRESSOR("suppressor", "Глушитель", Slot.MUZZLE, "Выстрел намного тише: зомби сбегаются с меньшего расстояния"),
        SUPPRESSOR_IMPROVISED("suppressor_improvised", "Самодельный глушитель", Slot.MUZZLE, "Бутылка на изоленте: тише, но ненадолго (≈18 выстрелов)"),
        LASER_SIGHT("laser_sight", "Лазерный целеуказатель", Slot.UNDER, "Точнее при стрельбе от бедра"),
        VERTICAL_GRIP("vertical_grip", "Тактическая рукоять", Slot.UNDER, "Меньше отдача и разброс"),
        EXT_MAG("ext_mag", "Увеличенный магазин", Slot.MAG, "Патронов в магазине больше на две трети");

        public final String id, ru, hint;
        public final Slot slot;
        public Item item;

        Kind(String id, String ru, Slot slot, String hint) {
            this.id = id;
            this.ru = ru;
            this.slot = slot;
            this.hint = hint;
        }

        public static Kind byId(String id) {
            for (Kind k : values()) if (k.id.equals(id)) return k;
            return null;
        }

        /** Во сколько раз сужается поле зрения при прицеливании. */
        public float zoom() {
            return switch (this) {
                case RED_DOT -> 0.8f;
                case SCOPE_4X -> 0.25f;
                case SCOPE_8X -> 0.125f;
                default -> 1f;
            };
        }

        public boolean scope() {
            return this == SCOPE_4X || this == SCOPE_8X;
        }
    }

    public static Kind of(ItemStack st) {
        return st.getItem() instanceof AttachmentItem a ? a.kind : null;
    }

    public static class AttachmentItem extends Item {
        public final Kind kind;

        public AttachmentItem(Kind kind, Settings s) {
            super(s.maxCount(1));
            this.kind = kind;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal("Модуль: " + kind.slot.ru).formatted(Formatting.GOLD));
            tooltip.add(Text.literal(kind.hint).formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Поставить: оружие в руку, клавиша N").formatted(Formatting.DARK_GRAY));
        }
    }
}
