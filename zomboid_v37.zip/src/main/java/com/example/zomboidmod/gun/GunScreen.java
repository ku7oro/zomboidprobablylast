package com.example.zomboidmod.gun;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

/** Модули оружия (клавиша N): что стоит в каждом гнезде, что можно поставить из инвентаря. */
public class GunScreen extends Screen {
    private int ticks;

    public GunScreen() {
        super(Text.literal("Модули оружия"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    protected void init() {
        if (client == null || client.player == null || !(client.player.getMainHandStack().getItem() instanceof GunItem g)) return;
        ItemStack st = client.player.getMainHandStack();
        int y = 46;
        int x = width / 2 - 150;
        for (Attachment.Slot slot : Attachment.Slot.values()) {
            boolean any = false;
            for (Attachment.Kind k : Attachment.Kind.values()) if (k.slot == slot && g.accepts(k)) any = true;
            if (!any) continue;
            Attachment.Kind cur = GunItem.attachment(st, slot);
            if (cur != null) {
                addDrawableChild(ButtonWidget.builder(Text.literal("Снять"), b -> send(slot, -1)).dimensions(x + 230, y - 4, 70, 18).build());
            }
            int bx = x;
            y += 16;
            int n = 0;
            for (int i = 0; i < client.player.getInventory().size(); i++) {
                Attachment.Kind k = Attachment.of(client.player.getInventory().getStack(i));
                if (k == null || k.slot != slot || !g.accepts(k) || k == cur) continue;
                final int inv = i;
                String label = (cur != null ? "Заменить на: " : "Поставить: ") + k.ru;
                int w = Math.min(300, textRenderer.getWidth(label) + 16);
                addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> send(slot, inv)).dimensions(bx, y, w, 18).build());
                y += 20;
                n++;
            }
            if (n == 0) y += 12;
            y += 14;
        }
    }

    private void send(Attachment.Slot slot, int inv) {
        ClientPlayNetworking.send(new Guns.AttachPayload(slot.ordinal(), inv));
        ticks = 0;
    }

    @Override
    public void tick() {
        // после ответа сервера перестраиваем список
        if (++ticks == 4) clearAndInit();
        if (client != null && client.player != null && !(client.player.getMainHandStack().getItem() instanceof GunItem)) close();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        if (client == null || client.player == null || !(client.player.getMainHandStack().getItem() instanceof GunItem g)) return;
        ItemStack st = client.player.getMainHandStack();
        int x = width / 2 - 150;
        ctx.drawCenteredTextWithShadow(textRenderer, g.ru, width / 2, 14, 0xFFF0E6C8);
        ctx.drawCenteredTextWithShadow(textRenderer, "Патроны: " + GunItem.ammo(st) + "/" + g.capacity(st), width / 2, 26, 0xFF9A9284);
        int y = 46;
        for (Attachment.Slot slot : Attachment.Slot.values()) {
            boolean any = false;
            for (Attachment.Kind k : Attachment.Kind.values()) if (k.slot == slot && g.accepts(k)) any = true;
            if (!any) continue;
            Attachment.Kind cur = GunItem.attachment(st, slot);
            ctx.drawTextWithShadow(textRenderer, slot.ru + ": " + (cur != null ? cur.ru : "—"), x, y, cur != null ? 0xFF9FD08A : 0xFFB0A898);
            y += 16;
            int n = 0;
            for (int i = 0; i < client.player.getInventory().size(); i++) {
                Attachment.Kind k = Attachment.of(client.player.getInventory().getStack(i));
                if (k != null && k.slot == slot && g.accepts(k) && k != cur) n++;
            }
            if (n == 0) {
                ctx.drawTextWithShadow(textRenderer, "  (в инвентаре нет подходящих модулей)", x, y, 0xFF6E685E);
                y += 12;
            }
            y += n * 20 + 14;
        }
        // в каком гнезде что стоит — нарисовано; ствол, глушитель и т.п. видны на модели в руке
        ctx.drawCenteredTextWithShadow(textRenderer, "Esc — закрыть", width / 2, height - 20, 0xFF6E685E);
    }
}
