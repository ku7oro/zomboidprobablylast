package com.example.zomboidmod.gun;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PaneBlock;
import net.minecraft.block.TransparentBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.List;
import java.util.function.Supplier;

/**
 * Огнестрел: ЛКМ — выстрел (у автоматического — очередь, пока держишь), ПКМ (держать) — прицелиться через мушку или оптику,
 * R — перезарядка патронами из инвентаря, N — модули (прицелы, глушитель, ЛЦУ, рукоять, увеличенный магазин).
 * Разброс зависит от навыка «Меткость», прицеливания, движения, паники и модулей. В голову — двойной урон.
 * Выстрел очень громкий: на шум сбегаются зомби; глушитель делает тише, но не беззвучно.
 */
public class GunItem extends Item {
    public enum Action { SLIDE, REVOLVER, BOLT_AUTO, BOLT_SEMI, BOLT_MANUAL, PUMP, BREAK }

    public final String id, ru;
    public final Supplier<Item> ammo;
    public final int capacity, fireTicks, reloadTicks, pellets, noise;
    public final float damage, range, spreadHip, spreadAds, recoil, ironZoom;
    public final boolean auto, perShell;
    public final Action action;
    final Supplier<SoundEvent> sound;

    public GunItem(String id, String ru, Supplier<Item> ammo, int capacity, float damage, float range, int pellets, float spreadHip, float spreadAds,
                   int fireTicks, boolean auto, int reloadTicks, boolean perShell, int noise, float recoil, float ironZoom, Action action,
                   Supplier<SoundEvent> sound, Settings settings) {
        super(settings.maxCount(1));
        this.id = id;
        this.ru = ru;
        this.ammo = ammo;
        this.capacity = capacity;
        this.damage = damage;
        this.range = range;
        this.pellets = pellets;
        this.spreadHip = spreadHip;
        this.spreadAds = spreadAds;
        this.fireTicks = fireTicks;
        this.auto = auto;
        this.reloadTicks = reloadTicks;
        this.perShell = perShell;
        this.noise = noise;
        this.recoil = recoil;
        this.ironZoom = ironZoom;
        this.action = action;
        this.sound = sound;
    }

    // ===================== данные в предмете =====================
    public static NbtCompound data(ItemStack st) {
        return st.getOrDefault(DataComponentTypes.CUSTOM_DATA, NbtComponent.DEFAULT).copyNbt();
    }

    static void edit(ItemStack st, java.util.function.Consumer<NbtCompound> f) {
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, st, f);
    }

    public static int ammo(ItemStack st) {
        return data(st).getInt("ammo");
    }

    public static void setAmmo(ItemStack st, int n) {
        edit(st, nbt -> nbt.putInt("ammo", n));
    }

    /** Установленный модуль в гнезде (или null). */
    public static Attachment.Kind attachment(ItemStack st, Attachment.Slot slot) {
        String s = data(st).getString("att_" + slot.key);
        return s.isEmpty() ? null : Attachment.Kind.byId(s);
    }

    public static void setAttachment(ItemStack st, Attachment.Slot slot, Attachment.Kind k) {
        edit(st, nbt -> {
            if (k == null) nbt.remove("att_" + slot.key);
            else nbt.putString("att_" + slot.key, k.id);
            if (slot == Attachment.Slot.MUZZLE) nbt.putInt("mzd", k == Attachment.Kind.SUPPRESSOR_IMPROVISED ? 18 : 0);
        });
    }

    public int capacity(ItemStack st) {
        return attachment(st, Attachment.Slot.MAG) != null ? Math.round(capacity * 1.67f) : capacity;
    }

    /** До какого игрового тика идёт перезарядка. */
    public static long reloadEnd(ItemStack st) {
        return data(st).getLong("rl");
    }

    public static long reloadStart(ItemStack st) {
        return data(st).getLong("rs");
    }

    public static long lastFire(ItemStack st) {
        return data(st).getLong("lf");
    }

    public static boolean aiming(PlayerEntity p) {
        return p.isUsingItem() && p.getActiveItem().getItem() instanceof GunItem;
    }

    /** Какие гнёзда есть у этого оружия. */
    public boolean accepts(Attachment.Kind k) {
        GunGeometry.G g = GunGeometry.ALL.get(id);
        if (g == null) return false;
        String s = g.slots();
        return switch (k.slot) {
            case OPTIC -> s.contains("optic ") || s.endsWith("optic") || (s.contains("optic_rd") && k == Attachment.Kind.RED_DOT);
            case MUZZLE -> s.contains("muzzle");
            case UNDER -> s.contains("under");
            case MAG -> s.contains("mag");
        };
    }

    // ===================== прицеливание (ПКМ) =====================
    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack st = player.getStackInHand(hand);
        if (hand != Hand.MAIN_HAND || world.getTime() < reloadEnd(st)) return TypedActionResult.fail(st);
        player.setCurrentHand(hand);
        return TypedActionResult.consume(st);
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.NONE;
    }

    @Override
    public int getMaxUseTime(ItemStack stack, LivingEntity user) {
        return 72000;
    }

    // ===================== выстрел =====================
    /** Сервер: выстрел по запросу клиента (ЛКМ). */
    public void fire(ServerWorld w, ServerPlayerEntity p, ItemStack st) {
        long now = w.getTime();
        if (now < reloadEnd(st) || now - lastFire(st) < fireTicks) return;
        if (ammo(st) <= 0) {
            if (now - lastFire(st) >= 8) {
                w.playSound(null, p.getBlockPos(), Guns.DRY, SoundCategory.PLAYERS, 0.8f, 1f);
                edit(st, nbt -> nbt.putLong("lf", now));
            }
            return;
        }
        boolean ads = aiming(p);
        Attachment.Kind muzzle = attachment(st, Attachment.Slot.MUZZLE), under = attachment(st, Attachment.Slot.UNDER);
        Attachment.Kind optic = attachment(st, Attachment.Slot.OPTIC);
        boolean quick = now - lastFire(st) < fireTicks + 6;            // очередь — руки не успевают вернуться
        edit(st, nbt -> {
            nbt.putInt("ammo", nbt.getInt("ammo") - 1);
            nbt.putLong("lf", now);
            nbt.putInt("shots", nbt.getInt("shots") + 1);
        });

        int aim = Skills.level(p, PzSkill.AIMING);
        float spread = (ads ? spreadAds : spreadHip) * (1.45f - 0.09f * aim);
        if (ads && optic != null && optic != Attachment.Kind.RED_DOT) spread *= 0.6f;
        if (!ads && under == Attachment.Kind.LASER_SIGHT) spread *= 0.6f;
        if (under == Attachment.Kind.VERTICAL_GRIP) spread *= 0.88f;
        double v = p.getVelocity().horizontalLengthSquared();
        if (p.isSprinting()) spread *= 2.6f;
        else if (v > 0.005) spread *= 1.6f;
        if (p.isSneaking()) spread *= 0.7f;
        if (quick && auto) spread *= 1.35f;
        spread *= com.example.zomboidmod.survival.Survival.gunSpreadMult(p);
        float dmgMult = com.example.zomboidmod.survival.Survival.gunDamageMult(p) * (muzzle == Attachment.Kind.SUPPRESSOR ? 0.95f : 1f);

        Vec3d eye = p.getEyePos();
        boolean hitAny = false;
        for (int i = 0; i < pellets; i++) {
            float yaw = p.getYaw() + (float) p.getRandom().nextGaussian() * spread;
            float pitch = p.getPitch() + (float) p.getRandom().nextGaussian() * spread;
            Vec3d dir = Vec3d.fromPolar(pitch, yaw);
            Vec3d end = eye.add(dir.multiply(range * 1.6));
            BlockHitResult bh = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            Vec3d stop = bh.getType() == HitResult.Type.MISS ? end : bh.getPos();
            EntityHitResult eh = ProjectileUtil.raycast(p, eye, stop, new Box(eye, stop).expand(1.0),
                    e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator() && e != p, eye.squaredDistanceTo(stop));
            if (eh != null && eh.getEntity() instanceof LivingEntity target) {
                Vec3d hp = eh.getPos();
                double dist = eye.distanceTo(hp);
                boolean head = hp.y > target.getEyeY() - 0.28;
                float fall = dist <= range ? 1f : Math.max(0.25f, 1f - (float) (dist - range) / range);
                if (pellets > 1) fall *= Math.max(0.3f, 1f - (float) dist / range);
                float dmg = damage * dmgMult * (head ? 2.2f : 1f) * fall;
                target.timeUntilRegen = 0;
                target.damage(w.getDamageSources().playerAttack(p), dmg);
                target.takeKnockback(pellets > 1 ? 0.22 : (damage > 20 ? 0.6 : 0.35), -dir.x, -dir.z);
                w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.getDefaultState()),
                        hp.x, hp.y, hp.z, head ? 18 : 8, 0.1, 0.1, 0.1, 0.15);
                hitAny = true;
            } else if (bh.getType() == HitResult.Type.BLOCK) {
                BlockState bs = w.getBlockState(bh.getBlockPos());
                Vec3d hp = bh.getPos();
                w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, bs), hp.x, hp.y, hp.z, 6, 0.05, 0.05, 0.05, 0.1);
                w.spawnParticles(ParticleTypes.SMOKE, hp.x, hp.y, hp.z, 2, 0.02, 0.02, 0.02, 0.01);
                if ((bs.getBlock() instanceof PaneBlock && !bs.isOf(Blocks.IRON_BARS)) || bs.getBlock() instanceof TransparentBlock) {
                    w.breakBlock(bh.getBlockPos(), false);
                    com.example.zomboidmod.parkour.Parkour.shatter(w, bh.getBlockPos(), bs);
                }
            }
        }
        Vec3d muzzlePos = eye.add(p.getRotationVector().multiply(1.2)).add(0, -0.12, 0);
        boolean quiet = muzzle != null;
        if (!quiet) w.spawnParticles(ParticleTypes.FLASH, muzzlePos.x, muzzlePos.y, muzzlePos.z, 1, 0, 0, 0, 0);
        w.spawnParticles(ParticleTypes.SMOKE, muzzlePos.x, muzzlePos.y, muzzlePos.z, quiet ? 2 : 6, 0.05, 0.05, 0.05, 0.02);
        // гильза
        if (action != Action.REVOLVER && action != Action.BREAK) {
            Vec3d right = Vec3d.fromPolar(0, p.getYaw() + 90);
            Vec3d sh = eye.add(p.getRotationVector().multiply(0.5)).add(right.multiply(0.25)).add(0, -0.2, 0);
            w.spawnParticles(new net.minecraft.particle.ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(net.minecraft.item.Items.GOLD_NUGGET)),
                    sh.x, sh.y, sh.z, 1, 0.02, 0.02, 0.02, 0.08);
        }
        float vol = quiet ? (muzzle == Attachment.Kind.SUPPRESSOR ? 0.9f : 1.6f) : 4f;
        w.playSound(null, p.getBlockPos(), quiet ? Guns.SUPPRESSED : sound.get(), SoundCategory.PLAYERS, vol, 0.95f + p.getRandom().nextFloat() * 0.1f);
        if (action == Action.BOLT_MANUAL) w.playSound(null, p.getBlockPos(), Guns.BOLT, SoundCategory.PLAYERS, 0.7f, 1f);
        if (action == Action.PUMP) w.playSound(null, p.getBlockPos(), Guns.PUMP, SoundCategory.PLAYERS, 0.8f, 1f);
        int n = quiet ? (muzzle == Attachment.Kind.SUPPRESSOR ? noise / 4 : noise / 2) : noise;
        Noise.emitAt(w, p.getBlockPos(), Math.max(8, n));
        Skills.addXp(p, PzSkill.AIMING, hitAny ? 5f : 1.5f);
        // самодельный глушитель разваливается
        if (muzzle == Attachment.Kind.SUPPRESSOR_IMPROVISED) {
            int left = data(st).getInt("mzd") - 1;
            if (left <= 0) {
                setAttachment(st, Attachment.Slot.MUZZLE, null);
                p.sendMessage(Text.literal("Самодельный глушитель развалился").formatted(Formatting.GRAY), true);
            } else edit(st, nbt -> nbt.putInt("mzd", left));
        }
    }

    // ===================== перезарядка =====================
    /** Перезарядка патронами из инвентаря: время зависит от оружия и навыка; дробовики — по патрону. */
    public boolean reload(ServerPlayerEntity p, ItemStack st) {
        long now = p.getWorld().getTime();
        if (now < reloadEnd(st)) return false;
        int cap = capacity(st);
        int need = cap - ammo(st);
        if (need <= 0) return false;
        int got = 0;
        for (int i = 0; i < p.getInventory().size() && got < need; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isOf(ammo.get())) {
                int k = Math.min(need - got, s.getCount());
                s.decrement(k);
                got += k;
            }
        }
        if (got == 0) {
            p.sendMessage(Text.literal("Нет патронов: " + ammo.get().getName().getString()), true);
            return false;
        }
        int aim = Skills.level(p, PzSkill.AIMING);
        float skill = 1.25f - 0.05f * aim;
        int ticks = Math.round((perShell ? 12 + reloadTicks * got : reloadTicks) * skill);
        if (p.isUsingItem()) p.stopUsingItem();
        int fin = ammo(st) + got;
        edit(st, nbt -> {
            nbt.putInt("ammo", fin);
            nbt.putLong("rs", now);
            nbt.putLong("rl", now + ticks);
        });
        p.getItemCooldownManager().set(this, ticks);
        p.getWorld().playSound(null, p.getBlockPos(), action == Action.BREAK ? Guns.BREAK : Guns.MAG_OUT, SoundCategory.PLAYERS, 0.9f, 1f);
        Guns.later(p, ticks * 6 / 10, Guns.MAG_IN);
        if (action == Action.SLIDE || action == Action.BOLT_AUTO || action == Action.BOLT_SEMI) Guns.later(p, ticks - 4, Guns.BOLT);
        Noise.emitFrom(p, 6);
        return true;
    }

    @Override
    public boolean isItemBarVisible(ItemStack stack) {
        return true;
    }

    @Override
    public int getItemBarStep(ItemStack stack) {
        return Math.round(13f * ammo(stack) / Math.max(1, capacity(stack)));
    }

    @Override
    public int getItemBarColor(ItemStack stack) {
        return 0xE0B040;
    }

    @Override
    public boolean allowComponentsUpdateAnimation(PlayerEntity player, Hand hand, ItemStack oldStack, ItemStack newStack) {
        return false;
    }

    @Override
    public boolean allowContinuingBlockBreaking(PlayerEntity player, ItemStack oldStack, ItemStack newStack) {
        return true;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal("Патроны: " + ammo(stack) + "/" + capacity(stack) + " · " + ammo.get().getName().getString()).formatted(Formatting.GOLD));
        tooltip.add(Text.literal(String.format("Урон %.0f%s · дальность %.0f · %s", damage, pellets > 1 ? "×" + pellets : "", range,
                auto ? "автоматический" : "одиночный")).formatted(Formatting.GRAY));
        for (Attachment.Slot s : Attachment.Slot.values()) {
            Attachment.Kind k = attachment(stack, s);
            if (k != null) tooltip.add(Text.literal("+ " + k.ru).formatted(Formatting.DARK_GREEN));
        }
        tooltip.add(Text.literal("ЛКМ — выстрел, ПКМ — прицелиться, R — перезарядка, N — модули").formatted(Formatting.DARK_GRAY));
        tooltip.add(Text.literal("Очень громко: на выстрел сбегаются зомби").formatted(Formatting.DARK_RED));
    }
}
