package com.example.zomboidmod.gun;

/** Сгенерировано gen_guns.py: точки моделей оружия (в пикселях модели). */
public final class GunGeometry {
    private GunGeometry() {
    }

    public record G(String id, String[] parts, float[] grip, float sightY, float sightZ, float[] rail, float[] muzzle, float[] under,
                    float[] mag, float fp, String slots, String action, float zMin, float zMax, float yMin, float yMax) {}

    public static final java.util.Map<String, G> ALL = java.util.Map.ofEntries(
        java.util.Map.entry("pistol", new G("pistol", new String[]{"body", "slide", "mag"}, new float[]{8f, 3.6f, 3.2f}, 10.6f, 4.0f, new float[]{8f, 10.1f, 1.0f}, new float[]{8f, 8.9f, -4.5f}, new float[]{8f, 5.3f, -2.6f}, new float[]{8f, 5.6f, 2.9f}, 0.62f, "optic_rd muzzle under mag", "slide", -4.5f, 4.5f, 0.6f, 10.7f)),
        java.util.Map.entry("heavy_pistol", new G("heavy_pistol", new String[]{"body", "slide", "mag"}, new float[]{8f, 3.6f, 3.2f}, 10.6f, 3.8f, new float[]{8f, 10.1f, 0.5f}, new float[]{8f, 8.95f, -5.2f}, null, new float[]{8f, 5.6f, 2.9f}, 0.62f, "muzzle mag", "slide", -5.3f, 4.9f, 0.6f, 10.8f)),
        java.util.Map.entry("revolver", new G("revolver", new String[]{"body", "cyl"}, new float[]{8f, 3.8f, 3.6f}, 10.6f, 2.2f, null, null, null, null, 0.6f, "", "revolver", -9.5f, 4.8f, 1.2f, 11.0f)),
        java.util.Map.entry("smg", new G("smg", new String[]{"body", "bolt", "mag"}, new float[]{8f, 5.0f, 4.6f}, 11.35f, 3.4f, new float[]{8f, 10.65f, 0.0f}, new float[]{8f, 8.8f, -12.2f}, new float[]{8f, 7.9f, -8.6f}, new float[]{8f, 6.6f, -2.6f}, 0.5f, "optic muzzle under mag", "bolt_auto", -12.2f, 14.4f, -0.3f, 11.6f)),
        java.util.Map.entry("assault_rifle", new G("assault_rifle", new String[]{"body", "bolt", "mag"}, new float[]{8f, 4.4f, 4.0f}, 11.95f, 4.8f, new float[]{8f, 10.85f, 1.6f}, new float[]{8f, 8.8f, -16.0f}, new float[]{8f, 7.4f, -9.0f}, new float[]{8f, 6.2f, -1.5f}, 0.42f, "optic muzzle under mag", "bolt_auto", -16.0f, 20.6f, -2.4f, 12.1f)),
        java.util.Map.entry("carbine", new G("carbine", new String[]{"body", "bolt", "mag"}, new float[]{8f, 6.4f, 5.0f}, 11.35f, 4.0f, new float[]{8f, 10.4f, 1.4f}, new float[]{8f, 9.6f, -16.0f}, new float[]{8f, 7.2f, -6.0f}, new float[]{8f, 7.4f, -0.8f}, 0.42f, "optic muzzle under mag", "bolt_semi", -16.0f, 21.2f, 3.0f, 11.6f)),
        java.util.Map.entry("hunting_rifle", new G("hunting_rifle", new String[]{"body", "bolt"}, new float[]{8f, 6.8f, 8.6f}, 10.75f, -3.9f, new float[]{8f, 10.6f, 2.0f}, new float[]{8f, 9.8f, -16.0f}, null, null, 0.42f, "optic muzzle", "bolt_manual", -16.0f, 21.8f, 4.2f, 10.9f)),
        java.util.Map.entry("sniper_rifle", new G("sniper_rifle", new String[]{"body", "bolt", "mag"}, new float[]{8f, 5.4f, 7.2f}, 11.35f, 0.0f, new float[]{8f, 11.35f, 1.0f}, new float[]{8f, 9.8f, -16.0f}, null, new float[]{8f, 6.8f, 0.6f}, 0.4f, "optic muzzle mag", "bolt_manual", -16.0f, 21.8f, 3.4f, 11.35f)),
        java.util.Map.entry("shotgun", new G("shotgun", new String[]{"body", "pump"}, new float[]{8f, 7.4f, 8.0f}, 10.75f, 6.0f, new float[]{8f, 10.4f, 2.0f}, null, null, null, 0.42f, "optic_rd", "pump", -16.0f, 21.4f, 4.6f, 10.6f)),
        java.util.Map.entry("double_barrel", new G("double_barrel", new String[]{"body", "barrel"}, new float[]{8f, 7.0f, 6.4f}, 10.3f, 4.4f, null, null, null, null, 0.42f, "", "break", -16.0f, 21.2f, 4.4f, 10.3f)),
        java.util.Map.entry("sawed_off", new G("sawed_off", new String[]{"body", "barrel"}, new float[]{8f, 4.8f, 5.6f}, 10.3f, 4.4f, null, null, null, null, 0.55f, "", "break", -6.5f, 6.8f, 1.6f, 10.3f)));
}
