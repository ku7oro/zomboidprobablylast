package com.example.zomboidmod.gun;

import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Оружие собирается из частей прямо при отрисовке: корпус, затвор/кожух/помпа/барабан/стволы, магазин и модули.
 * Части двигаются: кожух откатывается при выстреле и встаёт на задержку, когда патроны кончились; затвор
 * винтовки передёргивается, помпа ходит, барабан проворачивается, стволы двустволки переламываются при перезарядке,
 * магазин выходит и встаёт на место. От первого лица — свой хват у бедра и вскидка к глазу (мушка ровно по центру).
 * Та же математика проверена в preview_guns.py.
 */
public final class GunRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {
    private static final float KTP_W = 0.60f, KTP_LP = 0.56f, KTP_LL = 0.48f;

    @Override
    public void render(ItemStack stack, ModelTransformationMode mode, MatrixStack m, VertexConsumerProvider vcp, int light, int overlay) {
        if (!(stack.getItem() instanceof GunItem g)) return;
        GunGeometry.G geo = GunGeometry.ALL.get(g.id);
        if (geo == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        float td = mc.getRenderTickCounter().getTickDelta(true);
        long time = mc.world != null ? mc.world.getTime() : 0;
        boolean fp = mode == ModelTransformationMode.FIRST_PERSON_RIGHT_HAND || mode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND;
        boolean own = fp || (mc.player != null && mc.player.getMainHandStack() == stack);
        float since = fp || mode.isFirstPerson() || isHand(mode) ? GunClient.sinceFire(stack, time, td, own) : 999f;
        float reload = reloadProgress(stack, time, td);

        m.push();
        m.translate(0.5f, 0.5f, 0.5f);
        switch (mode) {
            case FIRST_PERSON_RIGHT_HAND, FIRST_PERSON_LEFT_HAND -> firstPerson(m, g, geo, stack, mode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND ? -1f : 1f, td, since, reload);
            case THIRD_PERSON_RIGHT_HAND, THIRD_PERSON_LEFT_HAND -> {
                // пропорции под «кубического» персонажа: толще и чуть длиннее реального масштаба
                boolean pistolTp = geo.fp() >= 0.55f;
                m.scale(KTP_W, KTP_W, pistolTp ? KTP_LP : KTP_LL);
                float[] gr = geo.grip();
                m.translate(-gr[0] / 16f, -gr[1] / 16f, -gr[2] / 16f);
            }
            case GROUND -> {
                float s = fit(geo) * 0.55f;
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-90));
                m.scale(s, s, s);
                center(m, geo);
            }
            default -> {        // интерфейс, рамка, голова
                float s = fit(geo);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(30));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-90));
                m.scale(s, s, s);
                center(m, geo);
            }
        }
        drawGun(m, vcp, light, overlay, stack, g, geo, since, reload, time, td);
        m.pop();
    }

    private static boolean isHand(ModelTransformationMode mode) {
        return mode == ModelTransformationMode.THIRD_PERSON_LEFT_HAND || mode == ModelTransformationMode.THIRD_PERSON_RIGHT_HAND;
    }

    private static float fit(GunGeometry.G geo) {
        float L = Math.max(geo.zMax() - geo.zMin(), (geo.yMax() - geo.yMin()) * 1.25f) / 16f;
        return 0.96f / L;
    }

    private static void center(MatrixStack m, GunGeometry.G geo) {
        m.translate(-0.5f, -(geo.yMin() + geo.yMax()) / 32f, -(geo.zMin() + geo.zMax()) / 32f);
    }

    static float reloadProgress(ItemStack st, long time, float td) {
        long rl = GunItem.reloadEnd(st), rs = GunItem.reloadStart(st);
        if (time >= rl || rl <= rs) return -1f;
        return MathHelper.clamp((time + td - rs) / (float) (rl - rs), 0f, 1f);
    }

    private static float smooth(float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    /** Форма «туда-обратно»: 0 → 1 за up тиков, держится hold, обратно за down. */
    private static float pulse(float t, float start, float up, float hold, float down) {
        t -= start;
        if (t < 0) return 0f;
        if (t < up) return smooth(t / up);
        t -= up;
        if (t < hold) return 1f;
        t -= hold;
        return t < down ? 1f - smooth(t / down) : 0f;
    }

    /** Огибающая перезарядки: опустить/наклонить в начале, вернуть в конце. */
    private static float reloadEnv(float r) {
        if (r < 0) return 0f;
        return smooth(r / 0.15f) * (1f - smooth((r - 0.85f) / 0.15f));
    }

    // ===================== от первого лица =====================
    private void firstPerson(MatrixStack m, GunItem g, GunGeometry.G geo, ItemStack st, float i, float td, float since, float reload) {
        MinecraftClient mc = MinecraftClient.getInstance();
        float a = GunClient.aim(td);
        boolean pistol = geo.fp() >= 0.55f;
        float hx = i * 0.30f, hy = pistol ? -0.28f : -0.30f, hz = pistol ? -0.58f : -0.62f;
        float D = pistol ? 0.30f : 0.13f;
        float px = hx * (1 - a), py = hy * (1 - a), pz = hz + (-D - hz) * a;
        // бег — оружие опущено
        float sprint = mc.player != null && mc.player.isSprinting() ? 1f : 0f;
        // дыхание и покачивание (в прицеле почти не качает)
        float t = (mc.world != null ? mc.world.getTime() : 0) + td;
        float breath = (1f - a * 0.85f);
        px += MathHelper.sin(t * 0.045f) * 0.004f * breath;
        py += MathHelper.sin(t * 0.09f) * 0.004f * breath - sprint * 0.08f;
        if (mc.player != null) {
            // вес оружия: при прыжке отстаёт вниз, при падении всплывает; при ходьбе покачивается восьмёркой
            float vy = (float) mc.player.getVelocity().y;
            py += MathHelper.clamp(-vy, -0.45f, 0.6f) * 0.045f * (1f - a * 0.7f);
            float stride = MathHelper.lerp(td, mc.player.prevStrideDistance, mc.player.strideDistance);
            float walk = mc.player.horizontalSpeed + (mc.player.horizontalSpeed - mc.player.prevHorizontalSpeed) * td;
            float amp = MathHelper.clamp(stride * 3f, 0f, 1f) * (1f - a * 0.85f) * (1f - sprint * 0.5f);
            px += MathHelper.sin(walk * MathHelper.PI) * 0.014f * amp;
            py -= Math.abs(MathHelper.cos(walk * MathHelper.PI)) * 0.012f * amp;
        }
        // отдача: откат назад и подброс
        float k = since < 1 ? since : (float) Math.exp(-(since - 1) * 0.55f);
        if (since > 25) k = 0;
        float rec = g.recoil * (pistol ? 1.3f : 1f) * (1f - 0.45f * a);
        if (GunItem.attachment(st, Attachment.Slot.UNDER) == Attachment.Kind.VERTICAL_GRIP) rec *= 0.7f;
        pz += 0.012f * rec * k;
        m.translate(px - i * 0.56f, py + 0.52f, pz + 0.72f);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * 9f * (1 - a) + i * 25f * sprint));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(3f * (1 - a) + 2.2f * rec * k - 20f * sprint));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-i * 6f * (1 - a)));
        // перезарядка: оружие наклоняется к себе
        float env = reloadEnv(reload);
        if (env > 0) {
            m.translate(0f, -0.05f * env, 0.03f * env);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * (g.perShell ? 38f : 24f) * env));
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(14f * env));
        }
        float s = geo.fp();
        if (pistol) m.scale(s * 1.06f, s * 1.06f, s);
        else m.scale(s * 1.18f, s * 1.18f, s * 1.1f);
        float[] grip = geo.grip();
        float[] sight = sightPoint(st, geo);
        m.translate(-(grip[0] + (sight[0] - grip[0]) * a) / 16f, -(grip[1] + (sight[1] - grip[1]) * a) / 16f, -(grip[2] + (sight[2] - grip[2]) * a) / 16f);
    }

    static float[] sightPoint(ItemStack st, GunGeometry.G geo) {
        Attachment.Kind o = GunItem.attachment(st, Attachment.Slot.OPTIC);
        float[] r = geo.rail();
        if (o == Attachment.Kind.RED_DOT && r != null) return new float[]{8f, r[1] + 1.8f, r[2] + 1.4f};
        if (o != null && o.scope() && r != null) return new float[]{8f, r[1] + 1.9f, r[2] + 6.6f};
        return new float[]{8f, geo.sightY(), geo.sightZ()};
    }

    // ===================== сборка оружия =====================
    private void drawGun(MatrixStack m, VertexConsumerProvider vcp, int light, int overlay, ItemStack st, GunItem g, GunGeometry.G geo,
                         float since, float reload, long time, float td) {
        int ammo = GunItem.ammo(st);
        float env = reloadEnv(reload);
        for (String part : geo.parts()) {
            m.push();
            switch (part) {
                case "slide" -> {        // кожух: откат при выстреле, задержка на пустом магазине
                    float back = ammo <= 0 && reload < 0 ? 1f : pulse(since, 0, 0.8f, 0.4f, 2.5f);
                    if (reload >= 0) back = Math.max(back, reload > 0.8f ? 1f - smooth((reload - 0.8f) / 0.1f) : 1f);
                    m.translate(0, 0, back * 2.2f / 16f);
                }
                case "bolt" -> {
                    if (g.action == GunItem.Action.BOLT_MANUAL) {      // продольно-скользящий затвор: поднять, назад, вперёд, опустить
                        float lift = pulse(since, 3, 3, 6, 3), pull = pulse(since, 5.5f, 3, 1, 3);
                        if (reload >= 0) {
                            lift = Math.max(lift, env);
                            pull = Math.max(pull, env);
                        }
                        float[] gr = geo.grip();
                        m.translate(0, 0, pull * 3.2f / 16f);
                        pivotRotZ(m, 8f, gr[1] + 3.2f, -65f * lift);
                    } else {
                        float back = pulse(since, 0, 0.7f, 0.3f, 1.8f);
                        if (reload >= 0) back = Math.max(back, pulse(reload * 40f, 30f, 2f, 3f, 2f));
                        m.translate(0, 0, back * 1.8f / 16f);
                    }
                }
                case "pump" -> {
                    float back = pulse(since, 3, 3, 1, 4);
                    m.translate(0, 0, back * 3.0f / 16f);
                }
                case "cyl" -> {          // барабан: по 60° на выстрел; при перезарядке откидывается влево
                    int shots = GunItem.data(st).getInt("shots");
                    float turn = shots * 60f + (since < 3 ? 60f * (smooth(since / 3f) - 1f) : 0f);
                    if (env > 0) m.translate(-2.4f * env / 16f, -0.8f * env / 16f, 0);
                    pivotRotZ(m, 8f, 8.4f, turn);
                }
                case "barrel" -> {       // переламывание стволов
                    if (env > 0) {
                        m.translate(0.5f, 7.6f / 16f, 0);
                        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-38f * env));
                        m.translate(-0.5f, -7.6f / 16f, 0);
                    }
                }
                case "mag" -> {          // магазин выходит, пропадает, вставляется новый
                    float[] mp = geo.mag();
                    if (reload >= 0 && mp != null) {
                        float out = reload < 0.45f ? smooth((reload - 0.12f) / 0.2f) : 1f - smooth((reload - 0.5f) / 0.22f);
                        if (reload > 0.32f && reload < 0.5f) {
                            m.pop();
                            continue;    // магазина нет — руки тянутся за новым
                        }
                        m.translate(0, -7f * out / 16f, 1.2f * out / 16f);
                    }
                    if (GunItem.attachment(st, Attachment.Slot.MAG) != null && mp != null) {
                        m.translate(mp[0] / 16f, mp[1] / 16f, mp[2] / 16f);
                        m.scale(1.0f, 1.55f, 1.12f);
                        m.translate(-mp[0] / 16f, -mp[1] / 16f, -mp[2] / 16f);
                    }
                }
                default -> {
                }
            }
            model(m, vcp, light, overlay, st, "item/gun/" + geo.id() + "_" + part);
            m.pop();
        }
        // модули
        for (Attachment.Slot slot : new Attachment.Slot[]{Attachment.Slot.OPTIC, Attachment.Slot.MUZZLE, Attachment.Slot.UNDER}) {
            Attachment.Kind k = GunItem.attachment(st, slot);
            if (k == null) continue;
            float[] pt = slot == Attachment.Slot.OPTIC ? geo.rail() : slot == Attachment.Slot.MUZZLE ? geo.muzzle() : geo.under();
            if (pt == null) continue;
            m.push();
            m.translate((pt[0] - 8f) / 16f, (pt[1] - 8f) / 16f, (pt[2] - 8f) / 16f);
            model(m, vcp, light, overlay, st, "item/att/" + k.id);
            m.pop();
        }
    }

    private static void pivotRotZ(MatrixStack m, float x, float y, float deg) {
        m.translate(x / 16f, y / 16f, 0);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(deg));
        m.translate(-x / 16f, -y / 16f, 0);
    }

    private static void model(MatrixStack m, VertexConsumerProvider vcp, int light, int overlay, ItemStack st, String path) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BakedModel bm = mc.getBakedModelManager().getModel(Identifier.of("zomboidmod", path));
        if (bm == null) return;
        m.push();
        m.translate(0.5f, 0.5f, 0.5f);           // renderItem сдвигает на -0.5 — компенсируем
        mc.getItemRenderer().renderItem(st, ModelTransformationMode.NONE, false, m, vcp, light, overlay, bm);
        m.pop();
    }
}
