package com.example.zomboidmod.gun;

import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Огнестрел: 11 видов оружия, 6 калибров, 8 модулей. */
public final class Guns {
    public static Item AMMO_9MM, AMMO_45, AMMO_357, AMMO_556, RIFLE_ROUNDS, SHOTGUN_SHELLS;
    public static GunItem PISTOL, HEAVY_PISTOL, REVOLVER, SMG, ASSAULT_RIFLE, CARBINE, HUNTING_RIFLE, SNIPER_RIFLE, SHOTGUN, DOUBLE_BARREL, SAWED_OFF;
    public static final List<GunItem> ALL = new ArrayList<>();
    public static SoundEvent PISTOL_SHOT, SHOTGUN_SHOT, RIFLE_SHOT, DRY, RELOAD, SMG_SHOT, AR_SHOT, HEAVY_SHOT, REVOLVER_SHOT, SNIPER_SHOT,
            SUPPRESSED, BOLT, PUMP, MAG_OUT, MAG_IN, BREAK;

    private Guns() {
    }

    // ===================== пакеты =====================
    public record ReloadPayload() implements CustomPayload {
        public static final CustomPayload.Id<ReloadPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "reload"));
        public static final PacketCodec<RegistryByteBuf, ReloadPayload> CODEC = PacketCodec.unit(new ReloadPayload());

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public record FirePayload() implements CustomPayload {
        public static final CustomPayload.Id<FirePayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "fire"));
        public static final PacketCodec<RegistryByteBuf, FirePayload> CODEC = PacketCodec.unit(new FirePayload());

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Поставить модуль из ячейки инвентаря inv (или снять, если inv = -1) в гнездо slot. */
    public record AttachPayload(int slot, int inv) implements CustomPayload {
        public static final CustomPayload.Id<AttachPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "attach"));
        public static final PacketCodec<RegistryByteBuf, AttachPayload> CODEC =
                PacketCodec.tuple(PacketCodecs.VAR_INT, AttachPayload::slot, PacketCodecs.INTEGER, AttachPayload::inv, AttachPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    // ===================== регистрация =====================
    private static SoundEvent sound(String id) {
        Identifier i = Identifier.of(ZomboidMod.MOD_ID, id);
        return Registry.register(Registries.SOUND_EVENT, i, SoundEvent.of(i));
    }

    private static <T extends Item> T item(String id, T it) {
        return Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), it);
    }

    private static GunItem gun(String id, String ru, java.util.function.Supplier<Item> ammo, int cap, float dmg, float range, int pellets,
                               float hip, float ads, int fire, boolean auto, int reload, boolean perShell, int noise, float recoil,
                               GunItem.Action action, java.util.function.Supplier<SoundEvent> snd) {
        GunItem g = item(id, new GunItem(id, ru, ammo, cap, dmg, range, pellets, hip, ads, fire, auto, reload, perShell, noise, recoil,
                0.88f, action, snd, new Item.Settings()));
        ALL.add(g);
        return g;
    }

    public static void register() {
        PISTOL_SHOT = sound("gun_pistol");
        SHOTGUN_SHOT = sound("gun_shotgun");
        RIFLE_SHOT = sound("gun_rifle");
        DRY = sound("gun_dry");
        RELOAD = sound("gun_reload");
        SMG_SHOT = sound("gun_smg");
        AR_SHOT = sound("gun_ar");
        HEAVY_SHOT = sound("gun_heavy");
        REVOLVER_SHOT = sound("gun_revolver");
        SNIPER_SHOT = sound("gun_sniper");
        SUPPRESSED = sound("gun_suppressed");
        BOLT = sound("gun_bolt");
        PUMP = sound("gun_pump");
        MAG_OUT = sound("gun_mag_out");
        MAG_IN = sound("gun_mag_in");
        BREAK = sound("gun_break");

        AMMO_9MM = item("ammo_9mm", new Item(new Item.Settings()));
        AMMO_45 = item("ammo_45", new Item(new Item.Settings()));
        AMMO_357 = item("ammo_357", new Item(new Item.Settings()));
        AMMO_556 = item("ammo_556", new Item(new Item.Settings()));
        RIFLE_ROUNDS = item("rifle_rounds", new Item(new Item.Settings()));
        SHOTGUN_SHELLS = item("shotgun_shells", new Item(new Item.Settings()));

        //                id                 название                     патрон            ёмк урон  даль дроб бедро прицел темп авто перез пошт шум отдача
        PISTOL = gun("pistol", "Пистолет 9 мм", () -> AMMO_9MM, 15, 9f, 40f, 1, 3.2f, 1.0f, 4, false, 34, false, 70, 2.2f, GunItem.Action.SLIDE, () -> PISTOL_SHOT);
        HEAVY_PISTOL = gun("heavy_pistol", "Пистолет .45", () -> AMMO_45, 8, 13f, 42f, 1, 3.5f, 1.0f, 6, false, 36, false, 75, 3.6f, GunItem.Action.SLIDE, () -> HEAVY_SHOT);
        REVOLVER = gun("revolver", "Револьвер .357", () -> AMMO_357, 6, 18f, 45f, 1, 3.4f, 0.8f, 8, false, 14, true, 80, 5f, GunItem.Action.REVOLVER, () -> REVOLVER_SHOT);
        SMG = gun("smg", "Пистолет-пулемёт", () -> AMMO_9MM, 30, 7f, 35f, 1, 3.0f, 1.3f, 2, true, 44, false, 75, 1.2f, GunItem.Action.BOLT_AUTO, () -> SMG_SHOT);
        ASSAULT_RIFLE = gun("assault_rifle", "Штурмовая винтовка", () -> AMMO_556, 30, 12f, 80f, 1, 3.5f, 0.6f, 2, true, 50, false, 100, 1.6f, GunItem.Action.BOLT_AUTO, () -> AR_SHOT);
        CARBINE = gun("carbine", "Самозарядный карабин", () -> AMMO_556, 20, 14f, 85f, 1, 3.2f, 0.5f, 4, false, 48, false, 100, 2.4f, GunItem.Action.BOLT_SEMI, () -> AR_SHOT);
        HUNTING_RIFLE = gun("hunting_rifle", "Охотничья винтовка", () -> RIFLE_ROUNDS, 5, 28f, 110f, 1, 4.5f, 0.3f, 24, false, 12, true, 110, 5f, GunItem.Action.BOLT_MANUAL, () -> RIFLE_SHOT);
        SNIPER_RIFLE = gun("sniper_rifle", "Снайперская винтовка", () -> RIFLE_ROUNDS, 10, 34f, 140f, 1, 6f, 0.15f, 28, false, 56, false, 120, 6f, GunItem.Action.BOLT_MANUAL, () -> SNIPER_SHOT);
        SHOTGUN = gun("shotgun", "Помповое ружьё", () -> SHOTGUN_SHELLS, 6, 5.5f, 22f, 8, 5.5f, 4.5f, 18, false, 11, true, 90, 6f, GunItem.Action.PUMP, () -> SHOTGUN_SHOT);
        DOUBLE_BARREL = gun("double_barrel", "Двустволка", () -> SHOTGUN_SHELLS, 2, 6f, 24f, 9, 5.0f, 4.2f, 5, false, 40, false, 95, 7f, GunItem.Action.BREAK, () -> SHOTGUN_SHOT);
        SAWED_OFF = gun("sawed_off", "Обрез", () -> SHOTGUN_SHELLS, 2, 5.5f, 14f, 9, 8.5f, 7.5f, 5, false, 36, false, 95, 8f, GunItem.Action.BREAK, () -> SHOTGUN_SHOT);

        for (Attachment.Kind k : Attachment.Kind.values()) k.item = item(k.id, new Attachment.AttachmentItem(k, new Item.Settings()));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> {
            for (GunItem g : ALL) e.add(g);
            for (Item a : new Item[]{AMMO_9MM, AMMO_45, AMMO_357, AMMO_556, RIFLE_ROUNDS, SHOTGUN_SHELLS}) e.add(a);
            for (Attachment.Kind k : Attachment.Kind.values()) e.add(k.item);
        });

        PayloadTypeRegistry.playC2S().register(ReloadPayload.ID, ReloadPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(FirePayload.ID, FirePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(AttachPayload.ID, AttachPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ReloadPayload.ID, (payload, ctx) -> ctx.server().execute(() -> {
            var p = ctx.player();
            if (p.getVehicle() instanceof com.example.zomboidmod.vehicle.VehicleEntity v) {
                v.tryHotwire(p);
                return;
            }
            if (p.getMainHandStack().getItem() instanceof GunItem g) g.reload(p, p.getMainHandStack());
        }));
        ServerPlayNetworking.registerGlobalReceiver(FirePayload.ID, (payload, ctx) -> ctx.server().execute(() -> {
            var p = ctx.player();
            if (!p.isAlive() || p.isSpectator() || com.example.zomboidmod.parkour.Parkour.climbing(p)) return;
            if (p.getMainHandStack().getItem() instanceof GunItem g) g.fire(p.getServerWorld(), p, p.getMainHandStack());
        }));
        ServerPlayNetworking.registerGlobalReceiver(AttachPayload.ID, (payload, ctx) -> ctx.server().execute(() -> attach(ctx.player(), payload)));
        ServerTickEvents.END_SERVER_TICK.register(Guns::tick);
    }

    // ===================== модули =====================
    private static void attach(ServerPlayerEntity p, AttachPayload pl) {
        ItemStack gunSt = p.getMainHandStack();
        if (!(gunSt.getItem() instanceof GunItem g) || pl.slot() < 0 || pl.slot() >= Attachment.Slot.values().length) return;
        if (p.getWorld().getTime() < GunItem.reloadEnd(gunSt)) return;
        Attachment.Slot slot = Attachment.Slot.values()[pl.slot()];
        Attachment.Kind old = GunItem.attachment(gunSt, slot);
        Attachment.Kind neu = null;
        if (pl.inv() >= 0) {
            if (pl.inv() >= p.getInventory().size()) return;
            ItemStack a = p.getInventory().getStack(pl.inv());
            Attachment.Kind k = Attachment.of(a);
            if (k == null || k.slot != slot || !g.accepts(k)) return;
            a.decrement(1);
            neu = k;
        } else if (old == null) return;
        GunItem.setAttachment(gunSt, slot, neu);
        if (old != null) give(p, new ItemStack(old.item));
        // сняли увеличенный магазин — лишние патроны в инвентарь
        int cap = g.capacity(gunSt), am = GunItem.ammo(gunSt);
        if (am > cap) {
            GunItem.setAmmo(gunSt, cap);
            give(p, new ItemStack(g.ammo.get(), am - cap));
        }
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.ITEM_ARMOR_EQUIP_IRON.value(), SoundCategory.PLAYERS, 0.7f, 1.3f);
        p.sendMessage(Text.literal(neu != null ? "Установлено: " + neu.ru : "Снято: " + old.ru), true);
    }

    private static void give(ServerPlayerEntity p, ItemStack st) {
        if (!p.getInventory().insertStack(st)) p.dropItem(st, false);
    }

    // ===================== звуки с задержкой (магазин, затвор) =====================
    private record Later(ServerPlayerEntity p, long at, SoundEvent s) {}

    private static final List<Later> LATER = new ArrayList<>();

    static void later(ServerPlayerEntity p, int ticks, SoundEvent s) {
        LATER.add(new Later(p, p.getWorld().getTime() + Math.max(1, ticks), s));
    }

    private static void tick(net.minecraft.server.MinecraftServer server) {
        if (LATER.isEmpty()) return;
        for (Iterator<Later> it = LATER.iterator(); it.hasNext(); ) {
            Later l = it.next();
            if (l.p().isRemoved()) {
                it.remove();
                continue;
            }
            ServerWorld w = l.p().getServerWorld();
            if (w.getTime() >= l.at()) {
                w.playSound(null, l.p().getBlockPos(), l.s(), SoundCategory.PLAYERS, 0.8f, 1f);
                it.remove();
            }
        }
    }
}
