package com.example.zomboidmod.gun;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Клиент: стрельба (ЛКМ, очереди у автоматов), прицеливание с плавным приближением, отдача камеры и модели,
 * оптика с маской прицела, свой прицел-разброс, счётчик патронов, экран модулей (N).
 */
public final class GunClient {
    public static float aim, aimPrev;
    static long localFire = -100, localShot = -100;
    private static boolean wasDown;
    public static KeyBinding modsKey;

    private GunClient() {
    }

    public static void init() {
        modsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.zomboidmod.gun_mods", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_N, "category.zomboidmod"));
        List<Identifier> models = new ArrayList<>();
        for (GunGeometry.G g : GunGeometry.ALL.values())
            for (String p : g.parts()) models.add(Identifier.of("zomboidmod", "item/gun/" + g.id() + "_" + p));
        for (Attachment.Kind k : Attachment.Kind.values()) models.add(Identifier.of("zomboidmod", "item/att/" + k.id));
        ModelLoadingPlugin.register(ctx -> ctx.addModels(models));
        GunRenderer r = new GunRenderer();
        for (GunItem g : Guns.ALL) BuiltinItemRendererRegistry.INSTANCE.register(g, r);
        ClientTickEvents.END_CLIENT_TICK.register(GunClient::tick);
    }

    public static GunItem held(PlayerEntity p) {
        return p != null && p.getMainHandStack().getItem() instanceof GunItem g ? g : null;
    }

    public static boolean holding() {
        MinecraftClient c = MinecraftClient.getInstance();
        return c.player != null && held(c.player) != null && !c.player.isSpectator();
    }

    static float aim(float td) {
        return MathHelper.lerp(td, aimPrev, aim);
    }

    private static void tick(MinecraftClient c) {
        aimPrev = aim;
        ClientPlayerEntity p = c.player;
        if (p == null) {
            aim = 0;
            return;
        }
        GunItem g = held(p);
        float target = g != null && GunItem.aiming(p) ? 1f : 0f;
        aim += (target - aim) * (target > aim ? 0.34f : 0.45f);
        if (Math.abs(target - aim) < 0.01f) aim = target;
        if (g == null) return;
        // очередь — пока зажата ЛКМ; одиночный — по нажатию (в прицеле игра сама «съедает» клики, поэтому ловим здесь)
        boolean down = c.currentScreen == null && c.options.attackKey.isPressed();
        if (down && (g.auto || !wasDown)) tryFire(c, g);
        wasDown = down;
        while (modsKey.wasPressed()) if (c.currentScreen == null) c.setScreen(new GunScreen());
    }

    /** Нажатие ЛКМ с оружием в руке: стреляем вместо удара. */
    public static boolean onAttack(MinecraftClient c) {
        if (c.player == null || c.player.isSpectator()) return false;
        GunItem g = held(c.player);
        if (g == null) return false;
        tryFire(c, g);
        return true;
    }

    private static void tryFire(MinecraftClient c, GunItem g) {
        ClientPlayerEntity p = c.player;
        if (com.example.zomboidmod.parkour.ParkourClient.climbing(p)) return;   // руки заняты — лезет
        ItemStack st = p.getMainHandStack();
        long now = c.world.getTime();
        if (now < GunItem.reloadEnd(st) || now - localFire < g.fireTicks || p.getItemCooldownManager().isCoolingDown(g)) return;
        localFire = now;
        ClientPlayNetworking.send(new Guns.FirePayload());
        if (GunItem.ammo(st) <= 0) return;
        localShot = now;
        // отдача: камеру подбрасывает и ведёт в сторону
        float r = g.recoil * (GunItem.aiming(p) ? 0.65f : 1f);
        if (GunItem.attachment(st, Attachment.Slot.UNDER) == Attachment.Kind.VERTICAL_GRIP) r *= 0.7f;
        p.setPitch(MathHelper.clamp(p.getPitch() - r * (0.75f + 0.5f * p.getRandom().nextFloat()), -90f, 90f));
        p.setYaw(p.getYaw() + (p.getRandom().nextFloat() - 0.5f) * r * 0.7f);
    }

    /** Время последнего выстрела этого оружия (своё — без задержки сети). */
    static float sinceFire(ItemStack st, long worldTime, float td, boolean own) {
        long lf = GunItem.lastFire(st);
        if (own) lf = Math.max(lf, localShot);
        return worldTime + td - lf;
    }

    // ===================== прицел и обзор =====================
    static Attachment.Kind optic() {
        MinecraftClient c = MinecraftClient.getInstance();
        return c.player == null ? null : GunItem.attachment(c.player.getMainHandStack(), Attachment.Slot.OPTIC);
    }

    /** Множитель поля зрения: плавно сужается при прицеливании. */
    public static float fovMul() {
        MinecraftClient c = MinecraftClient.getInstance();
        GunItem g = held(c.player);
        if (g == null) return 1f;
        Attachment.Kind o = optic();
        float z = o != null ? o.zoom() : g.ironZoom;
        float a = aim(c.getRenderTickCounter().getTickDelta(true));
        if (o != null && o.scope()) a = a > 0.85f ? 1f : a * 0.3f;   // оптика «включается» в конце вскидки
        return 1f + (z - 1f) * a;
    }

    public static boolean scoped() {
        Attachment.Kind o = optic();
        return holding() && o != null && o.scope() && aim > 0.9f;
    }

    /** Чувствительность мыши в оптике ниже — иначе прицел скачет. */
    public static double sensitivity() {
        if (!holding()) return 1.0;
        Attachment.Kind o = optic();
        if (o != null && o.scope() && aim > 0.9f) return o.zoom() * 1.6;
        return 1.0 - 0.2 * aim;
    }

    // ===================== интерфейс =====================
    public static void hud(DrawContext ctx, MinecraftClient c) {
        if (c.player == null || c.options.hudHidden) return;
        GunItem g = held(c.player);
        if (g == null) return;
        ItemStack st = c.player.getMainHandStack();
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int cx = w / 2, cy = h / 2;
        float td = c.getRenderTickCounter().getTickDelta(true);
        float a = aim(td);
        Attachment.Kind o = GunItem.attachment(st, Attachment.Slot.OPTIC), under = GunItem.attachment(st, Attachment.Slot.UNDER);
        if (scoped()) scopeOverlay(ctx, w, h, o == Attachment.Kind.SCOPE_8X);
        else if (a > 0.85f && o == Attachment.Kind.RED_DOT) {
            ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, 0xFFFF3020);
            ctx.fill(cx - 2, cy, cx + 2, cy + 1, 0x60FF3020);
        } else if (a < 0.5f && c.options.getPerspective().isFirstPerson()) {
            // прицел-разброс: чем шире расходятся чёрточки, тем хуже точность
            float spread = g.spreadHip * (1.45f - 0.09f * com.example.zomboidmod.ZomboidClient.skillLevel(com.example.zomboidmod.PzSkill.AIMING));
            if (under == Attachment.Kind.LASER_SIGHT) spread *= 0.6f;
            if (c.player.isSprinting()) spread *= 2.6f;
            else if (c.player.getVelocity().horizontalLengthSquared() > 0.005) spread *= 1.6f;
            if (c.player.isSneaking()) spread *= 0.7f;
            float since = sinceFire(st, c.world.getTime(), td, true);
            if (since < 6) spread *= 1f + 0.4f * (1f - since / 6f);
            double fov = c.options.getFov().getValue();
            int gap = (int) Math.max(2, h / 2.0 / Math.tan(Math.toRadians(fov / 2)) * Math.tan(Math.toRadians(spread)));
            int col = 0xC0FFFFFF, al = (int) ((1f - a * 2f) * 192) << 24 | 0xFFFFFF;
            col = al;
            ctx.fill(cx - gap - 5, cy, cx - gap, cy + 1, col);
            ctx.fill(cx + gap + 1, cy, cx + gap + 6, cy + 1, col);
            ctx.fill(cx, cy - gap - 5, cx + 1, cy - gap, col);
            ctx.fill(cx, cy + gap + 1, cx + 1, cy + gap + 6, col);
            if (under == Attachment.Kind.LASER_SIGHT) ctx.fill(cx, cy, cx + 1, cy + 1, 0xFFFF2020);
        }
        // патроны и перезарядка — справа снизу
        int am = GunItem.ammo(st), cap = g.capacity(st);
        int reserve = 0;
        for (int i = 0; i < c.player.getInventory().size(); i++) {
            ItemStack s = c.player.getInventory().getStack(i);
            if (s.isOf(g.ammo.get())) reserve += s.getCount();
        }
        String main = am + " / " + cap;
        String sub = g.ammo.get().getName().getString() + " · запас " + reserve;
        int x = w - 8, y = h - 34;
        ctx.drawTextWithShadow(c.textRenderer, main, x - c.textRenderer.getWidth(main), y, am == 0 ? 0xFFE04030 : 0xFFF0E6C8);
        ctx.drawTextWithShadow(c.textRenderer, sub, x - c.textRenderer.getWidth(sub), y + 11, 0xFF9A9284);
        long now = c.world.getTime();
        long rl = GunItem.reloadEnd(st), rs = GunItem.reloadStart(st);
        if (now < rl && rl > rs) {
            float pr = MathHelper.clamp((now + td - rs) / (float) (rl - rs), 0f, 1f);
            int bw = 70, bx = x - bw, by = y - 8;
            ctx.fill(bx, by, x, by + 3, 0x80000000);
            ctx.fill(bx, by, bx + Math.round(bw * pr), by + 3, 0xFFE0B040);
            String t = "Перезарядка";
            ctx.drawTextWithShadow(c.textRenderer, t, x - c.textRenderer.getWidth(t), by - 10, 0xFFE0B040);
        }
    }

    /** Маска оптики: чёрное вокруг круга, сетка с дальномерными точками. */
    private static void scopeOverlay(DrawContext ctx, int w, int h, boolean eight) {
        int cx = w / 2, cy = h / 2;
        int r = (int) (Math.min(w, h) * 0.46);
        for (int y = 0; y < h; y++) {
            int dy = y - cy;
            if (Math.abs(dy) >= r) {
                ctx.fill(0, y, w, y + 1, 0xFF000000);
                continue;
            }
            int half = (int) Math.sqrt((double) r * r - (double) dy * dy);
            ctx.fill(0, y, cx - half, y + 1, 0xFF000000);
            ctx.fill(cx + half, y, w, y + 1, 0xFF000000);
            // затемнение к краю линзы
            int edge = Math.max(2, r / 14);
            ctx.fill(cx - half, y, cx - half + edge, y + 1, 0x50000000);
            ctx.fill(cx + half - edge, y, cx + half, y + 1, 0x50000000);
        }
        int line = 0xF0101010;
        int thick = Math.max(1, r / 70);
        ctx.fill(cx - r, cy, cx - r / 6, cy + thick, line);
        ctx.fill(cx + r / 6, cy, cx + r, cy + thick, line);
        ctx.fill(cx, cy + r / 6, cx + thick, cy + r, line);
        ctx.fill(cx, cy - r, cx + thick, cy - r / 6, line);
        ctx.fill(cx - r / 6, cy, cx + r / 6, cy + 1, 0xE0101010);
        ctx.fill(cx, cy - r / 6, cx + 1, cy + r / 6, 0xE0101010);
        int step = r / (eight ? 12 : 8);
        for (int k = 1; k <= 5; k++) {
            ctx.fill(cx + k * step - 1, cy - 1, cx + k * step + 1, cy + 2, line);
            ctx.fill(cx - k * step - 1, cy - 1, cx - k * step + 1, cy + 2, line);
            ctx.fill(cx - 1, cy + k * step - 1, cx + 2, cy + k * step + 1, line);
        }
        if (eight) ctx.fill(cx, cy, cx + 1, cy + 1, 0xFFE02020);
    }
}
