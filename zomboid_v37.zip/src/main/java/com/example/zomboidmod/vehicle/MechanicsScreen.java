package com.example.zomboidmod.vehicle;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.ZomboidClient;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;

/**
 * Панель механики (V): схема машины сверху, у каждой детали полоска состояния. Клик по детали — описание,
 * нужные инструменты и уровень, кнопки «Снять», «Поставить», «Починить», «Разобрать на запчасти».
 */
public class MechanicsScreen extends Screen {
    private NbtCompound d;
    private int selected = CarPart.ENGINE.ordinal();
    private static final int W = 320, H = 200;
    // положение деталей на схеме (x, y, w, h) относительно левого верхнего угла схемы 120x170, перед машины сверху
    private static final int[][] BOX = new int[CarPart.values().length][];

    static {
        BOX[CarPart.ENGINE.ordinal()] = new int[]{35, 18, 50, 26};
        BOX[CarPart.BATTERY.ordinal()] = new int[]{88, 20, 20, 14};
        BOX[CarPart.HEADLIGHTS.ordinal()] = new int[]{30, 4, 60, 10};
        BOX[CarPart.WINDSHIELD.ordinal()] = new int[]{30, 50, 60, 12};
        BOX[CarPart.TIRE_FL.ordinal()] = new int[]{4, 26, 18, 30};
        BOX[CarPart.TIRE_FR.ordinal()] = new int[]{98, 26, 18, 30};
        BOX[CarPart.TIRE_RL.ordinal()] = new int[]{4, 116, 18, 30};
        BOX[CarPart.TIRE_RR.ordinal()] = new int[]{98, 116, 18, 30};
        BOX[CarPart.BRAKES.ordinal()] = new int[]{24, 66, 34, 12};
        BOX[CarPart.SUSPENSION.ordinal()] = new int[]{62, 66, 34, 12};
        BOX[CarPart.GAS_TANK.ordinal()] = new int[]{35, 120, 50, 20};
        BOX[CarPart.MUFFLER.ordinal()] = new int[]{40, 148, 40, 12};
    }

    public MechanicsScreen(NbtCompound d) {
        super(Text.literal("Механика"));
        this.d = d;
        if (d.contains("jobPart")) selected = d.getInt("jobPart");
    }

    public int vehicleId() {
        return d.getInt("id");
    }

    public void update(NbtCompound nd) {
        this.d = nd;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int cond(int i) {
        int[] c = d.getIntArray("c");
        return i < c.length ? c[i] : -2;
    }

    private static int color(int c) {
        if (c < 0) return 0xFF505050;
        if (c > 60) return 0xFF4F9A48;
        if (c > 25) return 0xFFC9A23A;
        if (c > 0) return 0xFFC0502E;
        return 0xFF7A1A14;
    }

    private int x0() {
        return (width - W) / 2;
    }

    private int y0() {
        return (height - H) / 2;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int x = x0(), y = y0();
        ctx.fill(x - 2, y - 2, x + W + 2, y + H + 2, 0xFF3A3A36);
        ctx.fill(x, y, x + W, y + H, 0xF0181816);
        ctx.drawText(textRenderer, d.getString("name") + " — механика", x + 8, y + 6, 0xFFE8E2C8, false);
        int skill = ZomboidClient.skillLevel(PzSkill.MECHANICS);
        String sk = "Механика: " + skill;
        ctx.drawText(textRenderer, sk, x + W - 8 - textRenderer.getWidth(sk), y + 6, 0xFFB0AA90, false);

        // схема
        int sx = x + 8, sy = y + 20;
        boolean bike = d.getBoolean("bike");
        int bodyCol = 0xFF2C2C2A;
        if (bike) ctx.fill(sx + 40, sy + 10, sx + 80, sy + 160, bodyCol);
        else ctx.fill(sx + 20, sy + 2, sx + 100, sy + 166, bodyCol);
        for (CarPart p : CarPart.values()) {
            int c = cond(p.ordinal());
            if (c == -2) continue;
            int[] b = BOX[p.ordinal()];
            int bx = sx + b[0], by = sy + b[1];
            boolean sel = p.ordinal() == selected;
            boolean hover = mouseX >= bx && mouseX < bx + b[2] && mouseY >= by && mouseY < by + b[3];
            ctx.fill(bx - 1, by - 1, bx + b[2] + 1, by + b[3] + 1, sel ? 0xFFF0E8C0 : (hover ? 0xFF9A9A90 : 0xFF0C0C0C));
            ctx.fill(bx, by, bx + b[2], by + b[3], c < 0 ? 0xFF262626 : 0xFF3C3C38);
            if (c >= 0) ctx.fill(bx, by + b[3] - 3, bx + Math.max(1, b[2] * c / 100), by + b[3], color(c));
            else ctx.drawText(textRenderer, "—", bx + b[2] / 2 - 2, by + b[3] / 2 - 4, 0xFF888888, false);
        }

        // описание выбранной детали
        CarPart p = CarPart.values()[selected];
        int ix = x + 140, iy = y + 22;
        int c = cond(selected);
        ctx.drawText(textRenderer, p.ru, ix, iy, 0xFFFFFFFF, false);
        iy += 12;
        String st = c == -2 ? "нет у этого транспорта" : (c < 0 ? "отсутствует" : "состояние " + c + "%");
        ctx.drawText(textRenderer, st, ix, iy, color(c) | 0xFF000000, false);
        iy += 12;
        ctx.drawText(textRenderer, "Нужно: " + CarPart.Tools.names(p.tools), ix, iy, toolsOk(p.tools) ? 0xFF9AC08A : 0xFFD07060, false);
        iy += 11;
        int req = p.req;
        ctx.drawText(textRenderer, "Навык: Механика " + req, ix, iy, skill >= req ? 0xFF9AC08A : 0xFFD07060, false);
        iy += 11;
        if (p == CarPart.ENGINE) ctx.drawText(textRenderer, "Ремонт: запчасти, навык 2", ix, iy, 0xFFA0A090, false);
        else if (p.repairable()) ctx.drawText(textRenderer, "Ремонт: изолента (до 70%)", ix, iy, 0xFFA0A090, false);
        else ctx.drawText(textRenderer, "Не чинится, только замена", ix, iy, 0xFFA0A090, false);
        iy += 14;
        // общее
        ctx.drawText(textRenderer, String.format("Кузов: %.0f%%", d.getFloat("body") * 100), ix, iy, 0xFFC8C2A8, false);
        iy += 10;
        ctx.drawText(textRenderer, String.format("Аккумулятор: %.0f%% заряда", d.getFloat("charge") * 100), ix, iy, 0xFFC8C2A8, false);
        iy += 10;
        ctx.drawText(textRenderer, d.getFloat("cap") > 0 ? String.format("Бензин: %.1f / %.0f л", d.getFloat("fuel"), d.getFloat("cap")) : "Бензобака нет",
                ix, iy, 0xFFC8C2A8, false);

        // кнопки
        for (int i = 0; i < 4; i++) {
            String label = label(i, p, c);
            if (label == null) continue;
            int bx = ix + (i % 2) * 88, by = y + H - 46 + (i / 2) * 20;
            boolean hover = mouseX >= bx && mouseX < bx + 84 && mouseY >= by && mouseY < by + 16;
            ctx.fill(bx, by, bx + 84, by + 16, hover ? 0xFF5A5A50 : 0xFF3A3A34);
            ctx.drawBorder(bx, by, 84, 16, 0xFF7A7A6A);
            ctx.drawText(textRenderer, label, bx + 42 - textRenderer.getWidth(label) / 2, by + 4, 0xFFF0EAD0, false);
        }
        if (d.contains("jobPart")) {
            String j = "Идёт работа... не отходите от машины";
            ctx.drawText(textRenderer, j, x + 8, y + H - 12, 0xFFE0C060, false);
        } else {
            ctx.drawText(textRenderer, "Клик по детали — выбрать", x + 8, y + H - 12, 0xFF808070, false);
        }
    }

    private boolean toolsOk(int mask) {
        return client != null && client.player != null && Mechanics.hasTools(client.player, mask);
    }

    /** Подписи кнопок: 0 снять, 1 поставить, 2 починить, 3 разобрать на запчасти. */
    private static String label(int i, CarPart p, int c) {
        if (c == -2) return null;
        return switch (i) {
            case 0 -> p.removable() && c >= 0 ? "Снять" : null;
            case 1 -> p.removable() && c < 0 ? "Поставить" : null;
            case 2 -> p.repairable() && c >= 0 ? "Починить" : null;
            case 3 -> p == CarPart.ENGINE && c >= 10 ? "На запчасти" : null;
            default -> null;
        };
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int x = x0(), y = y0();
        int sx = x + 8, sy = y + 20;
        for (CarPart p : CarPart.values()) {
            if (cond(p.ordinal()) == -2) continue;
            int[] b = BOX[p.ordinal()];
            if (mx >= sx + b[0] && mx < sx + b[0] + b[2] && my >= sy + b[1] && my < sy + b[1] + b[3]) {
                selected = p.ordinal();
                return true;
            }
        }
        CarPart p = CarPart.values()[selected];
        int c = cond(selected);
        int ix = x + 140;
        for (int i = 0; i < 4; i++) {
            if (label(i, p, c) == null) continue;
            int bx = ix + (i % 2) * 88, by = y + H - 46 + (i / 2) * 20;
            if (mx >= bx && mx < bx + 84 && my >= by && my < by + 16) {
                int action = switch (i) {
                    case 0 -> Mechanics.UNINSTALL;
                    case 1 -> Mechanics.INSTALL;
                    case 2 -> Mechanics.REPAIR;
                    default -> Mechanics.TAKE_PARTS;
                };
                ClientPlayNetworking.send(new Mechanics.ActionPayload(vehicleId(), selected, action));
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
