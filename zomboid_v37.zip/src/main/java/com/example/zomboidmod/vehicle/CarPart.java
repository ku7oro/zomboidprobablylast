package com.example.zomboidmod.vehicle;

/**
 * Детали машины, как в механике PZ: у каждой своё состояние 0-100 %, её можно снять, поставить или починить.
 * req — нужный уровень навыка «Механика», tools — нужные инструменты (битовая маска), seconds — время работы.
 */
public enum CarPart {
    ENGINE("Двигатель", 0, Tools.WRENCH, 10),
    BATTERY("Аккумулятор", 0, 0, 3),
    TIRE_FL("Колесо (переднее левое)", 0, Tools.JACK | Tools.WRENCH, 5),
    TIRE_FR("Колесо (переднее правое)", 0, Tools.JACK | Tools.WRENCH, 5),
    TIRE_RL("Колесо (заднее левое)", 0, Tools.JACK | Tools.WRENCH, 5),
    TIRE_RR("Колесо (заднее правое)", 0, Tools.JACK | Tools.WRENCH, 5),
    BRAKES("Тормоза", 2, Tools.JACK | Tools.WRENCH, 8),
    SUSPENSION("Подвеска", 2, Tools.JACK | Tools.WRENCH, 8),
    MUFFLER("Глушитель", 1, Tools.JACK | Tools.WRENCH, 6),
    GAS_TANK("Бензобак", 3, Tools.JACK | Tools.WRENCH, 8),
    WINDSHIELD("Лобовое стекло", 2, Tools.SCREWDRIVER, 8),
    HEADLIGHTS("Фары", 0, Tools.SCREWDRIVER, 4);

    public static final class Tools {
        public static final int WRENCH = 1, JACK = 2, SCREWDRIVER = 4;

        private Tools() {
        }

        public static String names(int mask) {
            StringBuilder sb = new StringBuilder();
            if ((mask & WRENCH) != 0) sb.append("гаечный ключ");
            if ((mask & JACK) != 0) sb.append(sb.length() > 0 ? ", " : "").append("домкрат");
            if ((mask & SCREWDRIVER) != 0) sb.append(sb.length() > 0 ? ", " : "").append("отвёртка");
            return sb.length() == 0 ? "без инструментов" : sb.toString();
        }
    }

    public final String ru;
    public final int req, tools, seconds;

    CarPart(String ru, int req, int tools, int seconds) {
        this.ru = ru;
        this.req = req;
        this.tools = tools;
        this.seconds = seconds;
    }

    public boolean tire() {
        return this == TIRE_FL || this == TIRE_FR || this == TIRE_RL || this == TIRE_RR;
    }

    /** Есть ли такая деталь у этого транспорта (у мотоцикла два колеса и нет лобового стекла). */
    public boolean applies(VehicleType t) {
        if (t.bike()) return this != TIRE_FR && this != TIRE_RR && this != WINDSHIELD;
        return true;
    }

    /** Снимается ли целиком (двигатель только чинят или разбирают на запчасти). */
    public boolean removable() {
        return this != ENGINE;
    }

    /** Чем чинят: двигатель — запчастями, стекло и аккумулятор не чинятся, остальное — изолентой (временно). */
    public boolean repairable() {
        return this != WINDSHIELD && this != BATTERY;
    }
}
