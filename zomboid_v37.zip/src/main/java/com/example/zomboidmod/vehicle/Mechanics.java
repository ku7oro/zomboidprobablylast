package com.example.zomboidmod.vehicle;

import com.example.zomboidmod.LootItems;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Механика машин как в PZ: панель деталей (клавиша V), снять / поставить / починить деталь за время работы,
 * нужные инструменты и уровень навыка «Механика», запчасти от двигателя, фары (L), стекло защищает от зомби.
 */
public final class Mechanics {
    public static Item CAR_BATTERY, TIRE, BRAKES, SUSPENSION, MUFFLER, GAS_TANK, WINDSHIELD, HEADLIGHT;
    public static Item SPARE_ENGINE_PARTS, SCREWDRIVER, JACK;
    public static SoundEvent STARTER, BATTERY_CLICK, WRENCH_WORK;
    public static Block GLOW;
    public static final int UNINSTALL = 0, INSTALL = 1, REPAIR = 2, TAKE_PARTS = 3;

    private Mechanics() {
    }

    // ===================== сеть =====================
    public record OpenPayload(int id) implements CustomPayload {
        public static final Id<OpenPayload> ID = new Id<>(Identifier.of(ZomboidMod.MOD_ID, "mech_open"));
        public static final PacketCodec<RegistryByteBuf, OpenPayload> CODEC = PacketCodec.tuple(PacketCodecs.INTEGER, OpenPayload::id, OpenPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public record ActionPayload(int id, int part, int action) implements CustomPayload {
        public static final Id<ActionPayload> ID = new Id<>(Identifier.of(ZomboidMod.MOD_ID, "mech_action"));
        public static final PacketCodec<RegistryByteBuf, ActionPayload> CODEC = PacketCodec.tuple(PacketCodecs.INTEGER, ActionPayload::id,
                PacketCodecs.INTEGER, ActionPayload::part, PacketCodecs.INTEGER, ActionPayload::action, ActionPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public record PartsPayload(NbtCompound data) implements CustomPayload {
        public static final Id<PartsPayload> ID = new Id<>(Identifier.of(ZomboidMod.MOD_ID, "mech_parts"));
        public static final PacketCodec<RegistryByteBuf, PartsPayload> CODEC = PacketCodec.tuple(PacketCodecs.NBT_COMPOUND, PartsPayload::data, PartsPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public record LightsPayload() implements CustomPayload {
        public static final Id<LightsPayload> ID = new Id<>(Identifier.of(ZomboidMod.MOD_ID, "mech_lights"));
        public static final PacketCodec<RegistryByteBuf, LightsPayload> CODEC = PacketCodec.unit(new LightsPayload());

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    // ===================== предметы =====================
    /** Деталь машины: состояние = 100 - износ; у аккумулятора ещё и заряд. */
    public static class CarPartItem extends Item {
        public final String kind;

        public CarPartItem(Settings s, String kind) {
            super(s.maxDamage(100).maxCount(1));
            this.kind = kind;
        }

        public static int condition(ItemStack st) {
            return st.getMaxDamage() - st.getDamage();
        }

        public static float charge(ItemStack st) {
            NbtComponent c = st.get(DataComponentTypes.CUSTOM_DATA);
            return c == null ? 1f : (c.copyNbt().contains("charge") ? c.copyNbt().getFloat("charge") : 1f);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            int c = condition(stack);
            tooltip.add(Text.literal("Состояние: " + c + "%").formatted(c > 60 ? Formatting.GREEN : c > 25 ? Formatting.YELLOW : Formatting.RED));
            if (kind.equals("battery")) tooltip.add(Text.literal("Заряд: " + Math.round(charge(stack) * 100) + "%").formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Ставится через панель механики (V у машины)").formatted(Formatting.DARK_GRAY));
        }
    }

    public static class ToolItem extends Item {
        private final String hint;

        public ToolItem(Settings s, String hint) {
            super(s);
            this.hint = hint;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(hint).formatted(Formatting.GRAY));
        }
    }

    private static Item reg(String id, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
    }

    private static SoundEvent sound(String id) {
        Identifier i = Identifier.of(ZomboidMod.MOD_ID, id);
        return Registry.register(Registries.SOUND_EVENT, i, SoundEvent.of(i));
    }

    public static String kindOf(CarPart p) {
        return switch (p) {
            case BATTERY -> "battery";
            case TIRE_FL, TIRE_FR, TIRE_RL, TIRE_RR -> "tire";
            case BRAKES -> "brakes";
            case SUSPENSION -> "suspension";
            case MUFFLER -> "muffler";
            case GAS_TANK -> "gas_tank";
            case WINDSHIELD -> "windshield";
            case HEADLIGHTS -> "headlight";
            default -> "";
        };
    }

    public static Item itemFor(CarPart p) {
        return switch (p) {
            case BATTERY -> CAR_BATTERY;
            case TIRE_FL, TIRE_FR, TIRE_RL, TIRE_RR -> TIRE;
            case BRAKES -> BRAKES;
            case SUSPENSION -> SUSPENSION;
            case MUFFLER -> MUFFLER;
            case GAS_TANK -> GAS_TANK;
            case WINDSHIELD -> WINDSHIELD;
            case HEADLIGHTS -> HEADLIGHT;
            default -> null;
        };
    }

    public static ItemStack makePart(CarPart p, float cond, float charge) {
        Item it = itemFor(p);
        if (it == null) return ItemStack.EMPTY;
        ItemStack st = new ItemStack(it);
        st.setDamage(MathHelper.clamp(100 - Math.round(cond), 0, 99));
        if (p == CarPart.BATTERY) NbtComponent.set(DataComponentTypes.CUSTOM_DATA, st, nbt -> nbt.putFloat("charge", charge));
        return st;
    }

    /** Случайное состояние для найденной в луте детали. */
    public static void randomCondition(ItemStack st, Random r) {
        if (st.getItem() instanceof CarPartItem) st.setDamage(r.nextInt(70));
    }

    // ===================== регистрация =====================
    public static void register() {
        STARTER = sound("starter");
        BATTERY_CLICK = sound("battery_click");
        WRENCH_WORK = sound("wrench_work");
        CAR_BATTERY = reg("car_battery", new CarPartItem(new Item.Settings(), "battery"));
        TIRE = reg("tire", new CarPartItem(new Item.Settings(), "tire"));
        BRAKES = reg("brakes", new CarPartItem(new Item.Settings(), "brakes"));
        SUSPENSION = reg("suspension", new CarPartItem(new Item.Settings(), "suspension"));
        MUFFLER = reg("muffler", new CarPartItem(new Item.Settings(), "muffler"));
        GAS_TANK = reg("gas_tank", new CarPartItem(new Item.Settings(), "gas_tank"));
        WINDSHIELD = reg("windshield", new CarPartItem(new Item.Settings(), "windshield"));
        HEADLIGHT = reg("headlight", new CarPartItem(new Item.Settings(), "headlight"));
        SPARE_ENGINE_PARTS = reg("spare_engine_parts", new ToolItem(new Item.Settings().maxCount(16),
                "Чинить двигатель (панель механики). Добываются разборкой двигателей"));
        SCREWDRIVER = reg("screwdriver", new ToolItem(new Item.Settings().maxCount(1), "Нужна для стёкол и фар"));
        JACK = reg("jack", new ToolItem(new Item.Settings().maxCount(1), "Поднять машину: колёса, тормоза, подвеска, глушитель, бак"));
        GLOW = Registry.register(Registries.BLOCK, Identifier.of(ZomboidMod.MOD_ID, "headlight_glow"),
                new GlowBlock(AbstractBlock.Settings.create().noCollision().nonOpaque().replaceable().dropsNothing().breakInstantly()
                        .luminance(st -> 15)));

        PayloadTypeRegistry.playC2S().register(OpenPayload.ID, OpenPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(LightsPayload.ID, LightsPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(PartsPayload.ID, PartsPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(OpenPayload.ID, (pl, ctx) -> ctx.server().execute(() -> {
            if (ctx.player().getWorld().getEntityById(pl.id()) instanceof VehicleEntity v && near(ctx.player(), v)) send(ctx.player(), v);
        }));
        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (pl, ctx) -> ctx.server().execute(() -> {
            if (ctx.player().getWorld().getEntityById(pl.id()) instanceof VehicleEntity v && near(ctx.player(), v)
                    && pl.part() >= 0 && pl.part() < CarPart.values().length)
                start(ctx.player(), v, CarPart.values()[pl.part()], pl.action());
        }));
        ServerPlayNetworking.registerGlobalReceiver(LightsPayload.ID, (pl, ctx) -> ctx.server().execute(() -> {
            ServerPlayerEntity p = ctx.player();
            if (p.getVehicle() instanceof VehicleEntity v && v.getControllingPassenger() == p) toggleLights(p, v);
        }));
        ServerTickEvents.END_SERVER_TICK.register(Mechanics::tick);

        // стекло держит удары зомби, пока не разобьётся (на мотоцикле защиты нет)
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayerEntity p && p.getVehicle() instanceof VehicleEntity v && source.getAttacker() instanceof PzZombieEntity
                    && !v.type.bike() && v.installed(CarPart.WINDSHIELD) && v.partCond(CarPart.WINDSHIELD) > 0) {
                v.damagePart(CarPart.WINDSHIELD, amount * 3f);
                v.getWorld().playSound(null, v.getBlockPos(), SoundEvents.BLOCK_GLASS_HIT, SoundCategory.NEUTRAL, 1f, 0.8f);
                if (v.partCond(CarPart.WINDSHIELD) <= 0) p.sendMessage(Text.literal("Зомби разбили стекло!").formatted(Formatting.RED), true);
                return false;
            }
            return true;
        });
    }

    static boolean near(ServerPlayerEntity p, VehicleEntity v) {
        return p.getVehicle() == v || p.squaredDistanceTo(v) < 6 * 6;
    }

    // ===================== фары =====================
    private static void toggleLights(ServerPlayerEntity p, VehicleEntity v) {
        if (!v.lights()) {
            if (!v.installed(CarPart.HEADLIGHTS) || v.partCond(CarPart.HEADLIGHTS) <= 0) {
                p.sendMessage(Text.literal("Фары разбиты или сняты"), true);
                return;
            }
            if (!v.installed(CarPart.BATTERY) || v.charge() < 0.02f) {
                p.sendMessage(Text.literal("Аккумулятор сел"), true);
                return;
            }
        }
        v.setLights(!v.lights());
        v.getWorld().playSound(null, v.getBlockPos(), SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.NEUTRAL, 0.5f, 1.4f);
    }

    /** Свет фар: невидимые светящиеся блоки впереди машины, сами гаснут, если их не обновлять. */
    static void headlights(ServerWorld w, VehicleEntity v) {
        double rad = Math.toRadians(v.getYaw());
        Vec3d dir = new Vec3d(-Math.sin(rad), 0, Math.cos(rad));
        for (double d : new double[]{4.5, 9.0}) {
            BlockPos base = BlockPos.ofFloored(v.getX() + dir.x * d, v.getY() + 0.6, v.getZ() + dir.z * d);
            for (int dy = 0; dy <= 2; dy++) {
                BlockPos bp = base.up(dy);
                BlockState s = w.getBlockState(bp);
                if (s.isOf(GLOW)) {
                    w.setBlockState(bp, s.with(GlowBlock.AGE, 0), Block.NOTIFY_LISTENERS);
                    break;
                }
                if (s.isAir()) {
                    w.setBlockState(bp, GLOW.getDefaultState(), Block.NOTIFY_ALL);
                    w.scheduleBlockTick(bp, GLOW, 5);
                    break;
                }
            }
        }
        // ночью свет фар привлекает зомби издалека
        if (v.age % 40 == 0 && !w.isDay())
            com.example.zomboidmod.Noise.emitAt(w, BlockPos.ofFloored(v.getX() + dir.x * 9, v.getY(), v.getZ() + dir.z * 9), 18);
    }

    public static class GlowBlock extends Block {
        public static final IntProperty AGE = IntProperty.of("age", 0, 3);

        public GlowBlock(Settings s) {
            super(s);
            setDefaultState(getStateManager().getDefaultState().with(AGE, 0));
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(AGE);
        }

        @Override
        protected BlockRenderType getRenderType(BlockState state) {
            return BlockRenderType.INVISIBLE;
        }

        @Override
        protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            return VoxelShapes.empty();
        }

        @Override
        protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
            int a = state.get(AGE);
            if (a >= 2) world.removeBlock(pos, false);
            else {
                world.setBlockState(pos, state.with(AGE, a + 1), Block.NOTIFY_LISTENERS);
                world.scheduleBlockTick(pos, this, 5);
            }
        }
    }

    // ===================== панель деталей =====================
    static void send(ServerPlayerEntity p, VehicleEntity v) {
        NbtCompound n = new NbtCompound();
        n.putInt("id", v.getId());
        n.putString("name", v.type.ru);
        int[] c = new int[CarPart.values().length];
        for (CarPart cp : CarPart.values()) c[cp.ordinal()] = !cp.applies(v.type) ? -2 : (v.installed(cp) ? Math.round(v.partCond(cp)) : -1);
        n.putIntArray("c", c);
        n.putFloat("charge", v.charge());
        n.putFloat("fuel", v.fuel());
        n.putFloat("cap", v.tankCapacity());
        n.putFloat("body", v.health() / v.type.maxHealth);
        n.putBoolean("bike", v.type.bike());
        Job j = JOBS.get(p.getUuid());
        if (j != null) {
            n.putInt("jobPart", j.part.ordinal());
            n.putFloat("jobProgress", 1f - j.left / (float) j.total);
        }
        ServerPlayNetworking.send(p, new PartsPayload(n));
    }

    public static boolean hasTools(net.minecraft.entity.player.PlayerEntity p, int mask) {
        if ((mask & CarPart.Tools.WRENCH) != 0 && !has(p, ZomboidMod.PIPE_WRENCH)) return false;
        if ((mask & CarPart.Tools.JACK) != 0 && !has(p, JACK)) return false;
        return (mask & CarPart.Tools.SCREWDRIVER) == 0 || has(p, SCREWDRIVER);
    }

    public static boolean has(net.minecraft.entity.player.PlayerEntity p, Item item) {
        for (int i = 0; i < p.getInventory().size(); i++) if (p.getInventory().getStack(i).isOf(item)) return true;
        return false;
    }

    private static int count(ServerPlayerEntity p, Item item) {
        int n = 0;
        for (int i = 0; i < p.getInventory().size(); i++) if (p.getInventory().getStack(i).isOf(item)) n += p.getInventory().getStack(i).getCount();
        return n;
    }

    private static void take(ServerPlayerEntity p, Item item, int n) {
        for (int i = 0; i < p.getInventory().size() && n > 0; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (!st.isOf(item)) continue;
            int k = Math.min(n, st.getCount());
            st.decrement(k);
            n -= k;
        }
    }

    /** Лучшая подходящая деталь в инвентаре (по состоянию). */
    private static int bestPart(ServerPlayerEntity p, CarPart part) {
        Item it = itemFor(part);
        int best = -1, bc = -1;
        for (int i = 0; i < p.getInventory().size(); i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (it != null && st.isOf(it) && CarPartItem.condition(st) > bc) {
                bc = CarPartItem.condition(st);
                best = i;
            }
        }
        return best;
    }

    /** Почему нельзя сделать действие (null — можно). */
    private static String check(ServerPlayerEntity p, VehicleEntity v, CarPart part, int action) {
        if (!part.applies(v.type)) return "У этого транспорта нет такой детали";
        int skill = Skills.level(p, PzSkill.MECHANICS);
        int req = action == REPAIR && part == CarPart.ENGINE ? 2 : part.req;
        if (skill < req) return "Нужна «Механика» " + req + " (у вас " + skill + ")";
        int tools = action == REPAIR && part != CarPart.ENGINE ? 0 : part.tools;
        if (!hasTools(p, tools)) return "Нужны инструменты: " + CarPart.Tools.names(tools);
        if (v.engineOn() && action != REPAIR) return "Сначала заглушите двигатель";
        switch (action) {
            case UNINSTALL -> {
                if (!part.removable()) return "Двигатель не снимается — его чинят или разбирают на запчасти";
                if (!v.installed(part)) return "Детали нет";
            }
            case INSTALL -> {
                if (!part.removable()) return "Двигатель не снимается";
                if (v.installed(part)) return "Деталь уже стоит";
                if (bestPart(p, part) < 0) return "Нет подходящей детали в инвентаре";
            }
            case REPAIR -> {
                if (!part.repairable()) return "Это не чинится — только замена";
                if (!v.installed(part)) return "Детали нет";
                if (part == CarPart.ENGINE) {
                    if (count(p, SPARE_ENGINE_PARTS) <= 0) return "Нужны запчасти для двигателя";
                    if (v.partCond(part) >= 100) return "Двигатель в порядке";
                } else {
                    if (count(p, LootItems.DUCT_TAPE) <= 0) return "Нужна изолента";
                    if (v.partCond(part) >= 70) return "Изолентой лучше не сделать (максимум 70%)";
                }
            }
            case TAKE_PARTS -> {
                if (part != CarPart.ENGINE) return "Разобрать можно только двигатель";
                if (v.partCond(part) < 10) return "Двигатель уже разобран";
            }
            default -> {
                return "?";
            }
        }
        return null;
    }

    // ===================== работа во времени =====================
    private static final class Job {
        final VehicleEntity v;
        final CarPart part;
        final int action, total;
        int left;

        Job(VehicleEntity v, CarPart part, int action, int total) {
            this.v = v;
            this.part = part;
            this.action = action;
            this.total = total;
            this.left = total;
        }
    }

    private static final Map<UUID, Job> JOBS = new HashMap<>();

    static void start(ServerPlayerEntity p, VehicleEntity v, CarPart part, int action) {
        String why = check(p, v, part, action);
        if (why != null) {
            p.sendMessage(Text.literal(why).formatted(Formatting.RED), true);
            return;
        }
        int skill = Skills.level(p, PzSkill.MECHANICS);
        int secs = action == TAKE_PARTS ? 8 : (action == REPAIR && part != CarPart.ENGINE ? 4 : part.seconds);
        int ticks = Math.round(secs * 20 * Math.max(0.4f, 1f - 0.06f * skill));
        JOBS.put(p.getUuid(), new Job(v, part, action, ticks));
        send(p, v);
    }

    private static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Job>> it = JOBS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Job> e = it.next();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
            Job j = e.getValue();
            if (p == null || !p.isAlive() || j.v.isRemoved() || !near(p, j.v)) {
                if (p != null) p.sendMessage(Text.literal("Работа прервана"), true);
                it.remove();
                continue;
            }
            j.left--;
            if (j.left % 10 == 0) {
                int pct = Math.round(100f * (1f - j.left / (float) j.total));
                p.sendMessage(Text.literal(verb(j.action) + ": " + j.part.ru + " — " + pct + "%"), true);
            }
            if (j.left % 25 == 0) p.getWorld().playSound(null, j.v.getBlockPos(), WRENCH_WORK, SoundCategory.PLAYERS, 0.8f,
                    0.9f + p.getRandom().nextFloat() * 0.2f);
            if (j.left <= 0) {
                it.remove();
                finish(p, j.v, j.part, j.action);
                send(p, j.v);
            }
        }
    }

    private static String verb(int a) {
        return switch (a) {
            case UNINSTALL -> "Снимаем";
            case INSTALL -> "Ставим";
            case REPAIR -> "Чиним";
            default -> "Разбираем";
        };
    }

    private static void finish(ServerPlayerEntity p, VehicleEntity v, CarPart part, int action) {
        String why = check(p, v, part, action);
        if (why != null) {
            p.sendMessage(Text.literal(why).formatted(Formatting.RED), true);
            return;
        }
        Random r = p.getRandom();
        int skill = Skills.level(p, PzSkill.MECHANICS);
        float chance = MathHelper.clamp(0.75f + 0.07f * (skill - part.req), 0.3f, 0.97f);
        switch (action) {
            case UNINSTALL -> {
                if (r.nextFloat() > chance) {
                    v.damagePart(part, 5 + r.nextInt(11));
                    p.sendMessage(Text.literal("Сорвалось! Деталь повреждена").formatted(Formatting.RED), true);
                    Skills.addXp(p, PzSkill.MECHANICS, 2f);
                    return;
                }
                ItemStack st = makePart(part, v.partCond(part), v.charge());
                v.setPart(part, -1);
                if (part == CarPart.BATTERY) v.setCharge(0f);
                if (!p.getInventory().insertStack(st)) p.dropItem(st, false);
                Skills.addXp(p, PzSkill.MECHANICS, 6f);
                p.sendMessage(Text.literal("Снято: " + part.ru), true);
            }
            case INSTALL -> {
                int slot = bestPart(p, part);
                ItemStack st = p.getInventory().getStack(slot);
                if (r.nextFloat() > chance) {
                    st.setDamage(Math.min(99, st.getDamage() + 5 + r.nextInt(11)));
                    p.sendMessage(Text.literal("Не встала как надо. Деталь повреждена, попробуйте ещё").formatted(Formatting.RED), true);
                    Skills.addXp(p, PzSkill.MECHANICS, 2f);
                    return;
                }
                v.setPart(part, CarPartItem.condition(st));
                if (part == CarPart.BATTERY) v.setCharge(CarPartItem.charge(st));
                st.decrement(1);
                Skills.addXp(p, PzSkill.MECHANICS, 4f);
                p.sendMessage(Text.literal("Установлено: " + part.ru), true);
            }
            case REPAIR -> {
                if (part == CarPart.ENGINE) {
                    int n = Math.min(3, count(p, SPARE_ENGINE_PARTS));
                    take(p, SPARE_ENGINE_PARTS, n);
                    float add = n * (5f + 3f * skill);
                    v.setPart(part, Math.min(100f, v.partCond(part) + add));
                    p.sendMessage(Text.literal(String.format("Двигатель: %.0f%% (+%.0f)", v.partCond(part), add)), true);
                } else {
                    take(p, LootItems.DUCT_TAPE, 1);
                    float add = 8f + 2f * skill;
                    v.setPart(part, Math.min(70f, v.partCond(part) + add));
                    p.sendMessage(Text.literal(String.format("%s: %.0f%% — замотано изолентой", part.ru, v.partCond(part))), true);
                }
                Skills.addXp(p, PzSkill.MECHANICS, 5f);
            }
            case TAKE_PARTS -> {
                int n = 1 + r.nextInt(1 + skill / 2);
                v.setPart(part, Math.max(0f, v.partCond(part) - 12f * n));
                ItemStack st = new ItemStack(SPARE_ENGINE_PARTS, n);
                if (!p.getInventory().insertStack(st)) p.dropItem(st, false);
                Skills.addXp(p, PzSkill.MECHANICS, 3f);
                p.sendMessage(Text.literal("Получено запчастей: " + n), true);
            }
            default -> {
            }
        }
    }
}
