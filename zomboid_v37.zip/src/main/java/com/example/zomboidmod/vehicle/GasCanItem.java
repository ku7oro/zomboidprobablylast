package com.example.zomboidmod.vehicle;

import com.example.zomboidmod.block.ZomboidBlocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;

import java.util.List;

/** Канистра на 10 литров: заправляется у колонки (ПКМ по колонке), выливается в бак (ПКМ по машине). */
public class GasCanItem extends Item {
    public static final int CAP = 100;   // десятые доли литра; прочность = пустота

    public GasCanItem(Settings settings) {
        super(settings.maxDamage(CAP).maxCount(1));
    }

    public static float liters(ItemStack st) {
        return (CAP - st.getDamage()) / 10f;
    }

    public static void setLiters(ItemStack st, float l) {
        st.setDamage(CAP - Math.round(Math.max(0f, Math.min(10f, l)) * 10f));
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        if (!ctx.getWorld().getBlockState(ctx.getBlockPos()).isOf(ZomboidBlocks.get("gas_pump"))
                && !ctx.getWorld().getBlockState(ctx.getBlockPos().down()).isOf(ZomboidBlocks.get("gas_pump"))) return ActionResult.PASS;
        if (!ctx.getWorld().isClient) {
            setLiters(ctx.getStack(), 10f);
            ctx.getWorld().playSound(null, ctx.getBlockPos(), Vehicles.REFUEL, SoundCategory.BLOCKS, 1f, 1f);
            if (ctx.getPlayer() != null) ctx.getPlayer().sendMessage(Text.literal("Канистра полна: 10 л"), true);
        }
        return ActionResult.success(ctx.getWorld().isClient);
    }

    public static void pourInto(ItemStack st, VehicleEntity v, PlayerEntity p) {
        float have = liters(st);
        if (v.tankCapacity() <= 0f) {
            p.sendMessage(Text.literal("У машины нет бензобака"), true);
            return;
        }
        float room = v.tankCapacity() - v.fuel();
        float n = Math.min(have, room);
        if (n <= 0.05f) {
            p.sendMessage(Text.literal(have <= 0.05f ? "Канистра пуста" : "Бак полон"), true);
            return;
        }
        v.setFuel(v.fuel() + n);
        setLiters(st, have - n);
        v.getWorld().playSound(null, v.getBlockPos(), Vehicles.REFUEL, SoundCategory.NEUTRAL, 1f, 1f);
        p.sendMessage(Text.literal(String.format("Залито %.1f л, в баке %.0f/%.0f л", n, v.fuel(), v.type.fuelCap)), true);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal(String.format("Бензин: %.1f / 10 л", liters(stack))).formatted(Formatting.GRAY));
        tooltip.add(Text.literal("ПКМ по колонке — наполнить, по машине — залить").formatted(Formatting.DARK_GRAY));
    }
}
