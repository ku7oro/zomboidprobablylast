package com.example.zomboidmod;

import net.minecraft.util.math.random.Random;

/** Повадки зомби (как в Project Zomboid): шатун, быстрый шатун, бегун, ползун, громила. */
public enum ZombieKind {
    SHAMBLER("Шатун", 0.17, 0.2, 28, 58),
    FAST_SHAMBLER("Быстрый шатун", 0.2, 0.27, 26, 26),
    SPRINTER("Бегун", 0.18, 0.42, 22, 9),   // идёт шагом, пока не заметил жертву, потом несётся
    CRAWLER("Ползун", 0.05, 0.06, 16, 7),   // ползёт, но хватает за ноги
    BRUTE("Громила", 0.15, 0.23, 90, 1);    // огромный и живучий: бьёт так, что отбрасывает, выносит двери с пары ударов

    public final String title;
    public final double idleSpeed;
    public final double chaseSpeed;
    public final int health;
    public final int weight;

    ZombieKind(String title, double idleSpeed, double chaseSpeed, int health, int weight) {
        this.title = title;
        this.idleSpeed = idleSpeed;
        this.chaseSpeed = chaseSpeed;
        this.health = health;
        this.weight = weight;
    }

    public static ZombieKind random(Random r) {
        int total = 0;
        for (ZombieKind k : values()) total += k.weight;
        int n = r.nextInt(total);
        for (ZombieKind k : values()) {
            n -= k.weight;
            if (n < 0) return k;
        }
        return SHAMBLER;
    }

    /**
     * Повадки с учётом опасности места: чем ценнее лут вокруг (полиция, оружейный, больница, военные),
     * тем больше бегунов и громил. tier 0 — жилой дом, 1 — магазин, 2 — полиция/аптека/оружие, 3 — военные/больница.
     */
    public static ZombieKind forTier(Random r, int tier) {
        float k = r.nextFloat();
        switch (tier) {
            case 1 -> {
                if (k < 0.04f) return BRUTE;
                if (k < 0.12f) return SPRINTER;
                if (k < 0.4f) return FAST_SHAMBLER;
            }
            case 2 -> {
                if (k < 0.12f) return BRUTE;
                if (k < 0.3f) return SPRINTER;
                if (k < 0.55f) return FAST_SHAMBLER;
            }
            case 3 -> {
                if (k < 0.22f) return BRUTE;
                if (k < 0.47f) return SPRINTER;
                if (k < 0.72f) return FAST_SHAMBLER;
            }
            default -> {
            }
        }
        return random(r);
    }
}
