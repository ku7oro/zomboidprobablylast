package com.example.zomboidmod.wildlife;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.EscapeDangerGoal;
import net.minecraft.entity.ai.goal.FleeEntityGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Олень: пугливый, замечает игрока издалека (если тот не крадётся) и убегает, бежит и от зомби.
 * Иногда щиплет траву. Даёт оленину и кожу.
 */
public class DeerEntity extends AnimalEntity {
    private int grazeTicks;
    private float graze, prevGraze;

    public DeerEntity(EntityType<? extends AnimalEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder attributes() {
        return MobEntity.createMobAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 14.0).add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.26);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new EscapeDangerGoal(this, 2.3));
        this.goalSelector.add(2, new FleeEntityGoal<>(this, PlayerEntity.class, 16f, 1.7, 2.4,
                e -> e instanceof PlayerEntity p && !p.isCreative() && !p.isSpectator() && !p.isSneaking()));
        this.goalSelector.add(2, new FleeEntityGoal<>(this, PlayerEntity.class, 6f, 1.7, 2.4,
                e -> e instanceof PlayerEntity p && !p.isCreative() && !p.isSpectator()));
        this.goalSelector.add(3, new FleeEntityGoal<>(this, ZombieEntity.class, 12f, 1.6, 2.2));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.9));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 10f));
        this.goalSelector.add(7, new LookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        prevGraze = graze;
        if (getWorld().isClient) {
            if (grazeTicks > 0) grazeTicks--;
            else if (getVelocity().horizontalLengthSquared() < 1e-4 && random.nextInt(300) == 0) grazeTicks = 60 + random.nextInt(60);
            if (getVelocity().horizontalLengthSquared() > 1e-3) grazeTicks = 0;
            graze += ((grazeTicks > 0 ? 1f : 0f) - graze) * 0.1f;
        }
    }

    public float grazeProgress() {
        return graze;
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return false;
    }

    @Override
    public @Nullable PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null;
    }

    @Override
    protected @Nullable SoundEvent getAmbientSound() {
        return null;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_GOAT_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_GOAT_DEATH;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return true;
    }

    @Override
    public boolean canTarget(LivingEntity target) {
        return false;
    }
}
