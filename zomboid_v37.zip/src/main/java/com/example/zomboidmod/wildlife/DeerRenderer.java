package com.example.zomboidmod.wildlife;

import com.example.zomboidmod.ZomboidMod;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class DeerRenderer extends MobEntityRenderer<DeerEntity, DeerModel> {
    private static final Identifier TEX = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/deer.png");

    public DeerRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new DeerModel(DeerModel.create().createModel()), 0.6f);
    }

    @Override
    public Identifier getTexture(DeerEntity entity) {
        return TEX;
    }
}
