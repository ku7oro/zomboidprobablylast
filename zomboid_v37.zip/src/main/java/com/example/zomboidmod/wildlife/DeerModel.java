package com.example.zomboidmod.wildlife;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/** Модель оленя (сгенерировано gen_deer.py): идёт, щиплет траву, поворачивает голову. */
public class DeerModel extends SinglePartEntityModel<DeerEntity> {
    private final ModelPart root, body, neck, head, leg0, leg1, leg2, leg3;

    public DeerModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.neck = body.getChild("neck");
        this.head = neck.getChild("head");
        this.leg0 = root.getChild("leg0");
        this.leg1 = root.getChild("leg1");
        this.leg2 = root.getChild("leg2");
        this.leg3 = root.getChild("leg3");
    }

    public static TexturedModelData create() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        ModelPartData p_body = root.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-3.5f, -4f, -9f, 7, 8, 18), ModelTransform.of(0f, 8f, 0f, 0f, 0f, 0f));
        ModelPartData p_neck = p_body.addChild("neck", ModelPartBuilder.create().uv(50, 0).cuboid(-1.5f, -9f, -2f, 3, 10, 4), ModelTransform.of(0f, -2f, -8f, 0.5f, 0f, 0f));
        ModelPartData p_head = p_neck.addChild("head", ModelPartBuilder.create().uv(0, 26).cuboid(-2f, -3f, -5f, 4, 4, 6).uv(20, 26).cuboid(-1.5f, -2f, -8f, 3, 3, 3).uv(32, 26).cuboid(-3.5f, -4f, -1f, 2, 1, 1).uv(38, 26).cuboid(1.5f, -4f, -1f, 2, 1, 1).uv(44, 26).cuboid(-2f, -8f, -1f, 1, 5, 1).uv(48, 26).cuboid(1f, -8f, -1f, 1, 5, 1).uv(52, 26).cuboid(-4f, -9f, -1f, 2, 1, 1).uv(58, 26).cuboid(2f, -9f, -1f, 2, 1, 1).uv(0, 36).cuboid(-2f, -7f, -3f, 1, 1, 2).uv(6, 36).cuboid(1f, -7f, -3f, 1, 1, 2), ModelTransform.of(0f, -9f, 0f, -0.5f, 0f, 0f));
        ModelPartData p_tail = p_body.addChild("tail", ModelPartBuilder.create().uv(12, 36).cuboid(-1f, 0f, 0f, 2, 4, 1), ModelTransform.of(0f, -3f, 9f, 0.6f, 0f, 0f));
        ModelPartData p_leg0 = root.addChild("leg0", ModelPartBuilder.create().uv(18, 36).cuboid(-1f, 0f, -1f, 2, 12, 2), ModelTransform.of(-2f, 12f, -7f, 0f, 0f, 0f));
        ModelPartData p_leg1 = root.addChild("leg1", ModelPartBuilder.create().uv(26, 36).cuboid(-1f, 0f, -1f, 2, 12, 2), ModelTransform.of(2f, 12f, -7f, 0f, 0f, 0f));
        ModelPartData p_leg2 = root.addChild("leg2", ModelPartBuilder.create().uv(34, 36).cuboid(-1f, 0f, -1f, 2, 12, 2), ModelTransform.of(-2f, 12f, 7f, 0f, 0f, 0f));
        ModelPartData p_leg3 = root.addChild("leg3", ModelPartBuilder.create().uv(42, 36).cuboid(-1f, 0f, -1f, 2, 12, 2), ModelTransform.of(2f, 12f, 7f, 0f, 0f, 0f));
        return TexturedModelData.of(md, 64, 64);
    }

    @Override
    public ModelPart getPart() {
        return root;
    }

    @Override
    public void setAngles(DeerEntity e, float limbAngle, float limbDistance, float age, float headYaw, float headPitch) {
        float k = 1.2f * limbDistance;
        leg0.pitch = MathHelper.cos(limbAngle * 0.7f) * k;
        leg3.pitch = MathHelper.cos(limbAngle * 0.7f) * k;
        leg1.pitch = MathHelper.cos(limbAngle * 0.7f + MathHelper.PI) * k;
        leg2.pitch = MathHelper.cos(limbAngle * 0.7f + MathHelper.PI) * k;
        float graze = e.grazeProgress();
        neck.pitch = 0.5f + graze * 1.5f + headPitch * MathHelper.RADIANS_PER_DEGREE * 0.4f;
        neck.yaw = headYaw * MathHelper.RADIANS_PER_DEGREE * 0.5f;
        head.pitch = -0.5f + graze * 0.3f + headPitch * MathHelper.RADIANS_PER_DEGREE * 0.4f;
        head.yaw = headYaw * MathHelper.RADIANS_PER_DEGREE * 0.3f;
    }
}
