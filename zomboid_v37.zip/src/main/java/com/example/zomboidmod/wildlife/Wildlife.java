package com.example.zomboidmod.wildlife;

import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.BiomeKeys;

/** Дикая природа: олени в лесах, кролики в полях и лесах. Домашний скот — только на фермах. */
public final class Wildlife {
    public static EntityType<DeerEntity> DEER;
    public static Item VENISON, COOKED_VENISON, DEER_SPAWN_EGG;

    private Wildlife() {
    }

    public static void register() {
        DEER = Registry.register(Registries.ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, "deer"),
                EntityType.Builder.create(DeerEntity::new, SpawnGroup.CREATURE).dimensions(0.9f, 1.6f).maxTrackingRange(10).build("deer"));
        FabricDefaultAttributeRegistry.register(DEER, DeerEntity.attributes());
        VENISON = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, "venison"), new Item(new Item.Settings()
                .food(new FoodComponent.Builder().nutrition(3).saturationModifier(0.3f).build())));
        COOKED_VENISON = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, "cooked_venison"), new Item(new Item.Settings()
                .food(new FoodComponent.Builder().nutrition(8).saturationModifier(0.8f).build())));
        DEER_SPAWN_EGG = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, "deer_spawn_egg"),
                new SpawnEggItem(DEER, 0x8E623E, 0xE0D6C4, new Item.Settings()));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(e -> {
            e.add(VENISON);
            e.add(COOKED_VENISON);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(e -> e.add(DEER_SPAWN_EGG));

        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(BiomeKeys.FOREST, BiomeKeys.BIRCH_FOREST, BiomeKeys.DARK_FOREST, BiomeKeys.FLOWER_FOREST),
                SpawnGroup.CREATURE, DEER, 10, 2, 4);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(BiomeKeys.PLAINS, BiomeKeys.SWAMP),
                SpawnGroup.CREATURE, DEER, 3, 1, 3);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(BiomeKeys.PLAINS, BiomeKeys.FOREST, BiomeKeys.BIRCH_FOREST, BiomeKeys.FLOWER_FOREST),
                SpawnGroup.CREATURE, EntityType.RABBIT, 6, 2, 3);
    }
}
