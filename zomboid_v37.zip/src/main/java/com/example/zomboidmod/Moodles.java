package com.example.zomboidmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.ArrayList;
import java.util.List;

/** Мудлы (значки состояния) как в PZ: у каждого 4 уровня, плохие - от жёлтого к тёмно-красному. */
public final class Moodles {
    public record Moodle(String icon, String name, String desc, int level, boolean good) {}

    private Moodles() {
    }

    public static List<Moodle> current(MinecraftClient c) {
        List<Moodle> out = new ArrayList<>();
        ClientPlayerEntity p = c.player;
        if (p == null) return out;

        // Жажда: пороги PZ 13 / 25 / 70 / 85 %
        int thirst = 100 - ZomboidClient.thirst();
        if (thirst > 85) out.add(new Moodle("thirst", "Умирает от жажды", "Нужна вода. Здоровье падает", 4, false));
        else if (thirst > 70) out.add(new Moodle("thirst", "Сильная жажда", "Слабость и головокружение", 3, false));
        else if (thirst > 25) out.add(new Moodle("thirst", "Жажда", "Нужно попить", 2, false));
        else if (thirst > 13) out.add(new Moodle("thirst", "Сухость во рту", "Скоро захочется пить", 1, false));

        // Голод: пороги PZ 15 / 25 / 45 / 70 %
        int food = p.getHungerManager().getFoodLevel();
        int hunger = (20 - food) * 5;
        if (hunger >= 70) out.add(new Moodle("hunger", "Истощение", "Здоровье скоро начнёт падать", 4, false));
        else if (hunger >= 45) out.add(new Moodle("hunger", "Сильный голод", "Сила снижена", 3, false));
        else if (hunger >= 25) out.add(new Moodle("hunger", "Голод", "Пора поесть", 2, false));
        else if (hunger >= 15) out.add(new Moodle("hunger", "Не прочь перекусить", "Можно бы и поесть", 1, false));
        else if (food >= 20 && p.getHungerManager().getSaturationLevel() >= 5)
            out.add(new Moodle("hunger", "Сыт", "Раны заживают быстрее", 1, true));

        // Кровотечение
        int bleed = ZomboidClient.bleedLevel();
        if (bleed == 3) out.add(new Moodle("bleeding", "Обильная кровопотеря", "Смерть близка. Перевяжите раны!", 4, false));
        else if (bleed == 2) out.add(new Moodle("bleeding", "Кровотечение", "Сила и скорость снижены", 2, false));
        else if (bleed == 1) out.add(new Moodle("bleeding", "Слабое кровотечение", "Нужна повязка", 1, false));

        // Травмы: по общему здоровью, пороги PZ 80 / 60 / 40 / 25 %
        float hp = p.getHealth() / p.getMaxHealth() * 100f;
        if (hp < 25) out.add(new Moodle("injured", "Критические травмы", "Не уйти тихо в эту ночь...", 4, false));
        else if (hp < 40) out.add(new Moodle("injured", "Тяжёлые травмы", "Сила и скорость сильно снижены", 3, false));
        else if (hp < 60) out.add(new Moodle("injured", "Травмирован", "Сила и скорость снижены", 2, false));
        else if (hp < 80) out.add(new Moodle("injured", "Дискомфорт", "Что-то не так...", 1, false));

        // Боль: пороги PZ 10 / 20 / 50 / 75
        int pain = ZomboidClient.pain();
        if (pain >= 75) out.add(new Moodle("pain", "Агония", "Скорость и точность сильно снижены", 4, false));
        else if (pain >= 50) out.add(new Moodle("pain", "Сильная боль", "Скорость и точность снижены", 3, false));
        else if (pain >= 20) out.add(new Moodle("pain", "Боль", "Скорость и точность немного снижены", 2, false));
        else if (pain >= 10) out.add(new Moodle("pain", "Слабая боль", "Немного болит", 1, false));

        // Болезнь: появляется не сразу после укуса
        int sick = ZomboidClient.sickLevel();
        if (sick == 4) out.add(new Moodle("sick", "Лихорадка", "Тело горит. Конец близок", 4, false));
        else if (sick == 3) out.add(new Moodle("sick", "Тошнит", "Очень плохо", 3, false));
        else if (sick == 2) out.add(new Moodle("sick", "Нездоровится", "Озноб и слабость", 2, false));
        else if (sick == 1) out.add(new Moodle("sick", "Подташнивает", "Что-то не так с самочувствием", 1, false));
        survival(out);
        // Тяжёлый груз
        float ratio = Weight.carried(p) / Weight.capacity(ZomboidClient.skillLevel(PzSkill.STRENGTH));
        switch (Weight.level(ratio)) {
            case 4 -> out.add(new Moodle("heavy", "Неподъёмный груз", "Еле передвигаешь ноги", 4, false));
            case 3 -> out.add(new Moodle("heavy", "Очень тяжёлый груз", "Не можешь бежать, быстро устаёшь", 3, false));
            case 2 -> out.add(new Moodle("heavy", "Тяжёлый груз", "Сильно замедляет", 2, false));
            case 1 -> out.add(new Moodle("heavy", "Груз", "Немного замедляет", 1, false));
            default -> {
            }
        }
        return out;
    }

    private static void add(List<Moodle> out, int lvl, String icon, String[] names, String[] descs, boolean good) {
        if (lvl > 0) out.add(new Moodle(icon, names[lvl - 1], descs[lvl - 1], lvl, good));
    }

    /** Мудлы выживания (уровни и эффекты — по вики PZ). */
    private static void survival(List<Moodle> out) {
        float fat = com.example.zomboidmod.survival.SurvivalClient.fatigue, end = com.example.zomboidmod.survival.SurvivalClient.endurance;
        float bor = com.example.zomboidmod.survival.SurvivalClient.boredom, unh = com.example.zomboidmod.survival.SurvivalClient.unhappy;
        float pan = com.example.zomboidmod.survival.SurvivalClient.panic, str = com.example.zomboidmod.survival.SurvivalClient.stress;
        float tmp = com.example.zomboidmod.survival.SurvivalClient.temp, wet = com.example.zomboidmod.survival.SurvivalClient.wet;
        float fs = com.example.zomboidmod.survival.SurvivalClient.foodSick, dr = com.example.zomboidmod.survival.SurvivalClient.drunk;
        add(out, com.example.zomboidmod.survival.Mood.tired(fat), "tired",
                new String[]{"Хочется спать", "Устал", "Очень устал", "Валится с ног"},
                new String[]{"Урон в ближнем бою ниже, силы восстанавливаются медленнее", "Сильно снижен урон. Пора спать",
                        "Почти нет сил драться", "Глаза закрываются сами. Ложитесь спать!"}, false);
        add(out, com.example.zomboidmod.survival.Mood.exertion(end), "endurance",
                new String[]{"Лёгкая одышка", "Одышка", "Сильная одышка", "Изнеможение"},
                new String[]{"Нужно перевести дух", "Удары медленнее", "Нельзя бежать, удары слабее", "Еле стоит на ногах"}, false);
        add(out, com.example.zomboidmod.survival.Mood.bored(bor), "bored",
                new String[]{"Скучно", "Очень скучно", "Тоска", "Невыносимая скука"},
                new String[]{"Займитесь чем-нибудь", "Скука портит настроение", "Настроение быстро падает",
                        "Почитайте, включите ТВ или выйдите на улицу"}, false);
        add(out, com.example.zomboidmod.survival.Mood.unhappy(unh), "unhappy",
                new String[]{"Грустно", "Подавлен", "Уныние", "Депрессия"},
                new String[]{"Всё не очень", "Плохое настроение", "Быстрее устаёте", "Ничего не хочется"}, false);
        add(out, com.example.zomboidmod.survival.Mood.panic(pan), "panic",
                new String[]{"Тревога", "Паника", "Сильная паника", "Ужас"},
                new String[]{"Рядом зомби", "Урон немного ниже", "Руки дрожат: урон и меткость ниже", "Трудно попасть и сильно ударить"}, false);
        add(out, com.example.zomboidmod.survival.Mood.stress(str), "stress",
                new String[]{"Беспокойство", "Взволнован", "Нервный срыв близко", "Сильный стресс"},
                new String[]{"Немного не по себе", "Хуже стреляет", "Портит настроение", "Помогут сигареты или пиво"}, false);
        add(out, com.example.zomboidmod.survival.Mood.hypo(tmp), "cold",
                new String[]{"Зябко", "Холодно", "Замерзает", "Переохлаждение"},
                new String[]{"Оденьтесь теплее", "Медленнее двигается", "Сильный озноб, силы уходят", "Здоровье падает! Нужно тепло"}, false);
        add(out, com.example.zomboidmod.survival.Mood.hyper(tmp), "hot",
                new String[]{"Тепло", "Жарко", "Перегрев", "Тепловой удар"},
                new String[]{"Хочется пить чаще", "Быстрее устаёт", "Тошнит от жары", "Здоровье падает! Снимите одежду, в тень"}, false);
        add(out, com.example.zomboidmod.survival.Mood.wet(wet), "wet",
                new String[]{"Влажный", "Мокрый", "Промок", "Насквозь мокрый"},
                new String[]{"Одежда отсырела", "Холоднее, настроение хуже", "Одежда почти не греет", "Можно простудиться"}, false);
        if (com.example.zomboidmod.survival.SurvivalClient.cold)
            out.add(new Moodle("cold_sick", "Простуда", "Чихает и кашляет — зомби это слышат", 2, false));
        add(out, com.example.zomboidmod.survival.Mood.foodSick(fs), "food_sick",
                new String[]{"Нехорошо", "Отравление", "Сильное отравление", "Тяжёлое отравление"},
                new String[]{"Что-то не то съели", "Тошнит", "Здоровье медленно падает", "Опасно для жизни!"}, false);
        add(out, com.example.zomboidmod.survival.Mood.drunk(dr), "drunk",
                new String[]{"Навеселе", "Пьян", "Сильно пьян", "В стельку"},
                new String[]{"Меньше паники", "Шатает", "Мутит", "Еле держится на ногах"}, false);
    }

    /** Цвет фона значка. */
    public static int color(Moodle m) {
        if (m.good()) return 0xFF3E7D3A;
        return switch (m.level()) {
            case 1 -> 0xFF8A7B2E;
            case 2 -> 0xFFA25A1E;
            case 3 -> 0xFF9A2A1E;
            default -> 0xFF5E0E10;
        };
    }
}
