package com.example.zomboidmod.backpack;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.collection.DefaultedList;

/** Содержимое рюкзака: читается из предмета и записывается обратно при каждом изменении. */
public class BackpackInventory extends SimpleInventory {
    private final ItemStack stack;
    private final PlayerEntity owner;
    private boolean loading = true;

    public BackpackInventory(ItemStack stack, int size, PlayerEntity owner) {
        super(size);
        this.stack = stack;
        this.owner = owner;
        DefaultedList<ItemStack> l = DefaultedList.ofSize(size, ItemStack.EMPTY);
        stack.getOrDefault(DataComponentTypes.CONTAINER, ContainerComponent.DEFAULT).copyTo(l);
        for (int i = 0; i < size; i++) this.getHeldStacks().set(i, l.get(i));
        loading = false;
    }

    private void save() {
        if (loading) return;
        stack.set(DataComponentTypes.CONTAINER, ContainerComponent.fromStacks(this.getHeldStacks()));
    }

    @Override
    public void markDirty() {
        super.markDirty();
        save();
    }

    @Override
    public boolean isValid(int slot, ItemStack s) {
        return !(s.getItem() instanceof BackpackItem);
    }

    @Override
    public boolean canPlayerUse(PlayerEntity p) {
        return !stack.isEmpty() && (p.getEquippedStack(EquipmentSlot.CHEST) == stack || p.getMainHandStack() == stack || p.getOffHandStack() == stack);
    }

    @Override
    public void onClose(PlayerEntity p) {
        // рюкзак в рюкзаке не носят: вынимаем обратно
        for (int i = 0; i < size(); i++) {
            ItemStack s = getStack(i);
            if (s.getItem() instanceof BackpackItem) {
                setStack(i, ItemStack.EMPTY);
                p.getInventory().offerOrDrop(s);
            }
        }
        super.onClose(p);
        save();
    }
}
