package com.example.zomboidmod.backpack;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;

/** Сгенерировано gen_backpacks.py. */
public final class BackpackModels {
    private BackpackModels() {
    }

    public static TexturedModelData create() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        root.addChild("school_backpack", ModelPartBuilder.create().uv(0, 0).cuboid(-3f, 1f, 2f, 6, 8, 3, new Dilation(0f)).uv(19, 0).cuboid(-2f, 5f, 5f, 4, 3, 1, new Dilation(0f)).uv(30, 0).cuboid(-1f, 0f, 3f, 2, 1, 1, new Dilation(0f)).uv(37, 0).cuboid(-3f, 1f, 2f, 6, 1, 3, new Dilation(0.05f)).uv(56, 0).cuboid(-3f, -1f, -2f, 1, 1, 4, new Dilation(0.1f)).uv(67, 0).cuboid(2f, -1f, -2f, 1, 1, 4, new Dilation(0.1f)).uv(78, 0).cuboid(-3f, 0f, -3f, 1, 7, 1, new Dilation(-0.25f)).uv(83, 0).cuboid(2f, 0f, -3f, 1, 7, 1, new Dilation(-0.25f)), ModelTransform.NONE);
        root.addChild("duffel_bag", ModelPartBuilder.create().uv(88, 0).cuboid(-5f, 3f, 2f, 10, 4, 4, new Dilation(0f)).uv(117, 0).cuboid(-5f, 3f, 2f, 1, 4, 4, new Dilation(0.1f)).uv(0, 12).cuboid(4f, 3f, 2f, 1, 4, 4, new Dilation(0.1f)).uv(11, 12).cuboid(-2f, 2f, 4f, 4, 1, 1, new Dilation(0f)).uv(22, 12).cuboid(-4f, -1f, -2f, 1, 1, 5, new Dilation(0.1f)).uv(35, 12).cuboid(-4f, 0f, -3f, 1, 4, 1, new Dilation(-0.25f)).uv(40, 12).cuboid(-3f, 4f, -3f, 1, 4, 1, new Dilation(-0.25f)).uv(45, 12).cuboid(-2f, 7f, -3f, 1, 3, 1, new Dilation(-0.25f)), ModelTransform.NONE);
        root.addChild("hiking_backpack", ModelPartBuilder.create().uv(50, 12).cuboid(-4f, -1f, 2f, 8, 11, 4, new Dilation(0f)).uv(75, 12).cuboid(-4f, -2f, 2f, 8, 2, 5, new Dilation(0.1f)).uv(102, 12).cuboid(-5f, 5f, 3f, 1, 4, 2, new Dilation(0f)).uv(109, 12).cuboid(4f, 5f, 3f, 1, 4, 2, new Dilation(0f)).uv(0, 28).cuboid(-5f, 9f, 2f, 10, 3, 3, new Dilation(0f)).uv(27, 28).cuboid(-3f, 3f, 6f, 6, 4, 1, new Dilation(0f)).uv(42, 28).cuboid(-4f, 9f, -2f, 8, 1, 4, new Dilation(0.25f)).uv(67, 28).cuboid(-1f, 1f, 6f, 2, 1, 1, new Dilation(0.05f)).uv(74, 28).cuboid(-3f, -1f, -2f, 1, 1, 4, new Dilation(0.1f)).uv(85, 28).cuboid(2f, -1f, -2f, 1, 1, 4, new Dilation(0.1f)).uv(96, 28).cuboid(-3f, 0f, -3f, 1, 7, 1, new Dilation(-0.25f)).uv(101, 28).cuboid(2f, 0f, -3f, 1, 7, 1, new Dilation(-0.25f)), ModelTransform.NONE);
        root.addChild("military_backpack", ModelPartBuilder.create().uv(0, 37).cuboid(-4f, 0f, 2f, 8, 9, 4, new Dilation(0f)).uv(25, 37).cuboid(-4f, -1f, 2f, 8, 2, 5, new Dilation(0.1f)).uv(52, 37).cuboid(-4f, 5f, 6f, 2, 3, 2, new Dilation(0f)).uv(61, 37).cuboid(-1f, 5f, 6f, 2, 3, 2, new Dilation(0f)).uv(70, 37).cuboid(2f, 5f, 6f, 2, 3, 2, new Dilation(0f)).uv(79, 37).cuboid(-5f, -3f, 3f, 10, 2, 2, new Dilation(0.1f)).uv(104, 37).cuboid(-4f, 9f, 2f, 8, 1, 1, new Dilation(0f)).uv(0, 51).cuboid(-1f, 1f, 7f, 2, 2, 1, new Dilation(0f)).uv(7, 51).cuboid(-3f, -1f, -2f, 1, 1, 4, new Dilation(0.1f)).uv(18, 51).cuboid(2f, -1f, -2f, 1, 1, 4, new Dilation(0.1f)).uv(29, 51).cuboid(-3f, 0f, -3f, 1, 7, 1, new Dilation(-0.25f)).uv(34, 51).cuboid(2f, 0f, -3f, 1, 7, 1, new Dilation(-0.25f)), ModelTransform.NONE);
        return TexturedModelData.of(md, 128, 128);
    }
}
