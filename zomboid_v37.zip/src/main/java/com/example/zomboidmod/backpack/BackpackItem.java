package com.example.zomboidmod.backpack;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Equipment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/**
 * Рюкзак носится на спине (слот нагрудника): ПКМ — открыть, Shift+ПКМ — надеть, B — открыть надетый.
 * Надетый рюкзак снижает вес вещей внутри; рюкзак в руках или в инвентаре не помогает.
 */
public class BackpackItem extends Item implements Equipment {
    public final String id;
    public final int slots;
    public final float reduction, ownWeight;

    public BackpackItem(String id, int slots, float reduction, float ownWeight, Settings settings) {
        super(settings.maxCount(1).component(DataComponentTypes.CONTAINER, ContainerComponent.DEFAULT));
        this.id = id;
        this.slots = slots;
        this.reduction = reduction;
        this.ownWeight = ownWeight;
    }

    @Override
    public EquipmentSlot getSlotType() {
        return EquipmentSlot.CHEST;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        if (player.isSneaking()) return this.equipAndSwap(this, world, player, hand);
        ItemStack st = player.getStackInHand(hand);
        if (!world.isClient && player instanceof ServerPlayerEntity sp) open(sp, st);
        return TypedActionResult.success(st, world.isClient);
    }

    public static void open(ServerPlayerEntity p, ItemStack st) {
        if (!(st.getItem() instanceof BackpackItem b)) return;
        int rows = Math.max(1, Math.min(6, b.slots / 9));
        ScreenHandlerType<?> type = switch (rows) {
            case 1 -> ScreenHandlerType.GENERIC_9X1;
            case 2 -> ScreenHandlerType.GENERIC_9X2;
            case 3 -> ScreenHandlerType.GENERIC_9X3;
            case 4 -> ScreenHandlerType.GENERIC_9X4;
            case 5 -> ScreenHandlerType.GENERIC_9X5;
            default -> ScreenHandlerType.GENERIC_9X6;
        };
        BackpackInventory inv = new BackpackInventory(st, rows * 9, p);
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, pinv, pl) -> new GenericContainerScreenHandler(type, syncId, pinv, inv, rows), st.getName()));
    }

    /** Вещи внутри. */
    public static List<ItemStack> contents(ItemStack st) {
        return st.getOrDefault(DataComponentTypes.CONTAINER, ContainerComponent.DEFAULT).stream().toList();
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal("Вместимость: " + slots + " ячеек").formatted(Formatting.GRAY));
        tooltip.add(Text.literal("Снижает вес вещей внутри на " + Math.round(reduction * 100) + "% (если надет)").formatted(Formatting.GRAY));
        int n = 0;
        for (ItemStack s : contents(stack)) if (!s.isEmpty()) n++;
        tooltip.add(Text.literal("Внутри: " + n + " стопок").formatted(Formatting.DARK_GRAY));
        tooltip.add(Text.literal("ПКМ — открыть, Shift+ПКМ — надеть, B — открыть надетый").formatted(Formatting.DARK_GRAY));
    }
}
