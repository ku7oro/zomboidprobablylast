package com.example.zomboidmod.backpack;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Weight;
import com.example.zomboidmod.ZomboidClient;
import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/** Клиент: рюкзак на спине игрока, клавиша B, вес в подсказках и в окне инвентаря. */
public final class BackpackClient {
    private static final Identifier TEX = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/backpack/backpacks.png");
    private static KeyBinding key;

    private BackpackClient() {
    }

    public static void init() {
        key = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.zomboidmod.backpack", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "category.zomboidmod"));
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, ctx) -> {
            if (renderer instanceof PlayerEntityRenderer pr) helper.register(new Feature(pr));
        });
        ItemTooltipCallback.EVENT.register((stack, context, tooltipType, lines) -> {
            if (stack.isEmpty()) return;
            float w = Weight.of(stack);
            lines.add(Text.literal(String.format("Вес: %.2f", w)).formatted(Formatting.DARK_AQUA));
        });
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof HandledScreen<?>) || screen instanceof CreativeInventoryScreen) return;
            ScreenEvents.afterRender(screen).register((scr, ctx, mx, my, delta) -> {
                if (client.player == null) return;
                float cw = Weight.carried(client.player), cap = Weight.capacity(ZomboidClient.skillLevel(PzSkill.STRENGTH));
                int color = cw > cap * 1.5f ? 0xFFE05040 : (cw > cap ? 0xFFE0B040 : 0xFFD8D8D0);
                String t = String.format("Вес: %.1f / %.1f", cw, cap);
                ctx.drawText(client.textRenderer, t, scr.width / 2 - client.textRenderer.getWidth(t) / 2, 4, color, true);
            });
        });
    }

    public static void tick(MinecraftClient c) {
        if (c.player == null) return;
        while (key.wasPressed()) {
            if (c.currentScreen == null && c.player.getEquippedStack(EquipmentSlot.CHEST).getItem() instanceof BackpackItem)
                ClientPlayNetworking.send(new Backpacks.OpenPayload());
        }
        // сильно перегруженный не может бежать
        if (!c.player.isCreative() && c.player.isSprinting() && c.player.age % 5 == 0) {
            float ratio = Weight.carried(c.player) / Weight.capacity(ZomboidClient.skillLevel(PzSkill.STRENGTH));
            if (Weight.level(ratio) >= 3) c.player.setSprinting(false);
        }
    }

    /** 3D-рюкзак на спине. */
    static final class Feature extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
        private final Map<String, ModelPart> parts = new HashMap<>();

        Feature(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> ctx) {
            super(ctx);
            ModelPart root = BackpackModels.create().createModel();
            for (String id : new String[]{"school_backpack", "duffel_bag", "hiking_backpack", "military_backpack"}) parts.put(id, root.getChild(id));
        }

        @Override
        public void render(MatrixStack matrices, VertexConsumerProvider vcp, int light, AbstractClientPlayerEntity p, float limbAngle,
                           float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
            ItemStack chest = p.getEquippedStack(EquipmentSlot.CHEST);
            if (!(chest.getItem() instanceof BackpackItem b) || p.isInvisible()) return;
            ModelPart part = parts.get(b.id);
            if (part == null) return;
            part.copyTransform(getContextModel().body);
            part.render(matrices, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX)), light, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
        }
    }
}
