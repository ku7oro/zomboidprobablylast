package com.example.zomboidmod.backpack;

import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/** Рюкзаки: школьный (обычный), спортивная сумка, туристический (редкий), армейский (очень редкий). */
public final class Backpacks {
    public static BackpackItem SCHOOL, DUFFEL, HIKING, MILITARY;

    private Backpacks() {
    }

    public record OpenPayload() implements CustomPayload {
        public static final CustomPayload.Id<OpenPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "open_backpack"));
        public static final PacketCodec<RegistryByteBuf, OpenPayload> CODEC = PacketCodec.unit(new OpenPayload());

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    private static BackpackItem reg(String id, int slots, float reduction, float weight) {
        return Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), new BackpackItem(id, slots, reduction, weight, new Item.Settings()));
    }

    public static void register() {
        SCHOOL = reg("school_backpack", 18, 0.5f, 0.6f);
        DUFFEL = reg("duffel_bag", 27, 0.4f, 1.0f);
        HIKING = reg("hiking_backpack", 36, 0.7f, 1.2f);
        MILITARY = reg("military_backpack", 45, 0.8f, 1.5f);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            e.add(SCHOOL);
            e.add(DUFFEL);
            e.add(HIKING);
            e.add(MILITARY);
        });
        PayloadTypeRegistry.playC2S().register(OpenPayload.ID, OpenPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(OpenPayload.ID, (payload, ctx) -> ctx.server().execute(() ->
                BackpackItem.open(ctx.player(), ctx.player().getEquippedStack(EquipmentSlot.CHEST))));
    }
}
