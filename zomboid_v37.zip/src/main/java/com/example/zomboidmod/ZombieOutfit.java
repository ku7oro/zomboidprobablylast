package com.example.zomboidmod;

import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

/** Одежда зомби (внешний вид + набор вещей в карманах). id совпадает с именем текстуры. */
public enum ZombieOutfit {
    CIVILIAN_TSHIRT("civilian_tshirt", 18, 0, 4),
    CIVILIAN_HOODIE("civilian_hoodie", 10, 0, 4),
    CIVILIAN_JACKET("civilian_jacket", 10, 0, 3),
    CIVILIAN_SHORTS("civilian_shorts", 6, 0, 2),
    BUSINESS("business", 6, 0, 2),
    STUDENT("student", 5, 0, 2),
    TRAILER("trailer", 4, 0, 2),
    MECHANIC("mechanic", 3, 2, 1),
    FARMER("farmer", 4, 0, 2),
    CONSTRUCTION("construction", 4, 2, 2),
    POLICE("police", 4, 4, 1),
    SECURITY("security", 2, 2, 1),
    DOCTOR("doctor", 3, 0, 1),
    NURSE("nurse", 3, 0, 2),
    FIREFIGHTER("firefighter", 2, 4, 1),
    SOLDIER("soldier", 3, 8, 1),
    PRISONER("prisoner", 2, 0, 1),
    BIKER("biker", 3, 2, 1),
    CHEF("chef", 2, 0, 1),
    SURVIVOR("survivor", 2, 2, 1),
    HAZMAT("hazmat", 1, 6, 1),
    PRIEST("priest", 1, 0, 1);

    public final String id;
    public final int weight;
    public final int bonusHealth;
    /** Сколько расцветок у этой одежды (outfit_<id>_<n>.png). */
    public final int variants;
    private Identifier[] tex;

    ZombieOutfit(String id, int weight, int bonusHealth, int variants) {
        this.id = id;
        this.weight = weight;
        this.bonusHealth = bonusHealth;
        this.variants = variants;
    }

    /** Людей (лица, причёски, цвет кожи) — по 3 стадии разложения на каждого. */
    public static final int PEOPLE = 10;
    private static final Identifier[][] BODY = new Identifier[PEOPLE][3];

    static {
        for (int p = 0; p < PEOPLE; p++)
            for (int s = 0; s < 3; s++)
                BODY[p][s] = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/zombie/body_" + p + "_" + s + ".png");
    }

    /** Броня одежды: бронежилеты, каски и защитные костюмы гасят удары (как бронированные зомби PZ). */
    public int armor() {
        return switch (this) {
            case SOLDIER -> 12;
            case POLICE, FIREFIGHTER -> 8;
            case SECURITY, HAZMAT -> 5;
            case CONSTRUCTION, BIKER -> 4;
            default -> 2;
        };
    }

    /** Одежда для громилы: здоровяки — байкеры, строители, заключённые, охранники. */
    public static ZombieOutfit bruteOutfit(Random r) {
        ZombieOutfit[] a = {BIKER, CONSTRUCTION, PRISONER, SECURITY, CIVILIAN_TSHIRT, MECHANIC};
        return a[r.nextInt(a.length)];
    }

    public static ZombieOutfit random(Random r) {
        int total = 0;
        for (ZombieOutfit o : values()) total += o.weight;
        int n = r.nextInt(total);
        for (ZombieOutfit o : values()) {
            n -= o.weight;
            if (n < 0) return o;
        }
        return CIVILIAN_TSHIRT;
    }

    /** Тело (лицо, кожа, раны): человек — по UUID, стадия разложения — по тону. */
    public static Identifier bodyTexture(java.util.UUID uuid, int tone) {
        int person = Math.floorMod((int) (uuid.getMostSignificantBits() ^ (uuid.getMostSignificantBits() >>> 32)), PEOPLE);
        return BODY[person][Math.max(0, Math.min(2, tone))];
    }

    /** Одежда поверх тела; расцветка — по UUID. */
    public Identifier outfitTexture(java.util.UUID uuid) {
        if (tex == null) {
            Identifier[] t = new Identifier[variants];
            for (int i = 0; i < variants; i++)
                t[i] = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/zombie/outfit_" + id + "_" + i + ".png");
            tex = t;
        }
        return tex[Math.floorMod((int) (uuid.getLeastSignificantBits() >>> 17), variants)];
    }
}
