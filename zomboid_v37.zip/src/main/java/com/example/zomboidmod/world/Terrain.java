package com.example.zomboidmod.world;

import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.Heightmap;
import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.noise.NoiseConfig;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Рельеф «по чертежу»: высота земли из шума генератора, без загрузки чанков. Одинаковая для любого порядка
 * стройки — по ней считаются уровни поселений и профиль дорог, поэтому куски дороги всегда стыкуются.
 */
final class Terrain {
    private Terrain() {
    }

    private static final Map<Long, int[]> CACHE = new LinkedHashMap<>(4096, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Long, int[]> e) {
            return size() > 60000;
        }
    };
    private static long cacheSeed = Long.MIN_VALUE;

    /** {верх земли (y верхнего твёрдого блока), верх воды или тот же y, если сухо} в точке, кратной 4. */
    private static int[] column(ServerWorld w, int x, int z) {
        if (w.getSeed() != cacheSeed) {
            CACHE.clear();
            cacheSeed = w.getSeed();
        }
        long key = ((long) x << 32) ^ (z & 0xffffffffL);
        int[] c = CACHE.get(key);
        if (c != null) return c;
        ChunkGenerator gen = w.getChunkManager().getChunkGenerator();
        NoiseConfig nc = w.getChunkManager().getNoiseConfig();
        int top, floor;
        try {
            top = gen.getHeightOnGround(x, z, Heightmap.Type.WORLD_SURFACE_WG, w, nc);
            floor = gen.getHeightOnGround(x, z, Heightmap.Type.OCEAN_FLOOR_WG, w, nc);
        } catch (Throwable t) {          // необычный генератор — берём уровень моря
            top = floor = w.getSeaLevel();
        }
        c = new int[]{floor, Math.max(top, floor)};
        CACHE.put(key, c);
        return c;
    }

    /** Высота земли (под водой — дно). */
    static int ground(ServerWorld w, int x, int z) {
        return column(w, x & ~3, z & ~3)[0];
    }

    /** Есть ли тут вода (река, озеро, море). */
    static boolean wet(ServerWorld w, int x, int z) {
        int[] c = column(w, x & ~3, z & ~3);
        return c[1] > c[0] || c[0] < w.getSeaLevel() - 1;
    }

    /** Сглаженная высота: среднее по крестику с шагом 8 (без мелких бугров). */
    static float smooth(ServerWorld w, int x, int z) {
        return (ground(w, x, z) * 2f + ground(w, x + 8, z) + ground(w, x - 8, z) + ground(w, x, z + 8) + ground(w, x, z - 8)) / 6f;
    }

    /** Медиана высот и доля воды по сетке n×n над прямоугольником. */
    static int[] survey(ServerWorld w, int x1, int z1, int x2, int z2, int n) {
        int[] hs = new int[n * n];
        int wet = 0, k = 0;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++) {
                int x = x1 + (x2 - x1) * i / (n - 1), z = z1 + (z2 - z1) * j / (n - 1);
                hs[k++] = ground(w, x, z);
                if (wet(w, x, z)) wet++;
            }
        java.util.Arrays.sort(hs);
        int spread = hs[hs.length * 9 / 10] - hs[hs.length / 10];
        return new int[]{hs[hs.length / 2], wet * 100 / (n * n), spread};
    }
}
