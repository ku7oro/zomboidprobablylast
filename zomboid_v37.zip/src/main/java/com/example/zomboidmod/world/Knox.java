package com.example.zomboidmod.world;

import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.ZombieOutfit;
import com.example.zomboidmod.ZomboidEntities;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FenceBlock;
import net.minecraft.block.PaneBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.WallBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.PersistentState;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Свой округ в духе Project Zomboid: мир поделён на регионы 512x512, в каждом - город, деревня,
 * фермы или лес, а между ними шоссе. Поселение строится, когда игрок подходит ближе 160 блоков.
 * Стройка идёт порциями, чтобы игра не подвисала.
 */
public final class Knox {
    public static final int REGION = 512;
    private static final int CELL = 36, STREET = 7;
    private static final int TRIGGER = 160, ROAD_TRIGGER = 112;
    public static int BLOCKS_PER_TICK = 6000;
    private static final int FLAGS = Block.NOTIFY_LISTENERS | Block.FORCE_STATE;

    enum Type { FOREST, FARMS, VILLAGE, TOWN, CITY, METRO, NONE, MILITARY, PRISON, LAB, MALL }

    static boolean special(Type t) {
        return t == Type.MILITARY || t == Type.PRISON || t == Type.LAB || t == Type.MALL;
    }

    /** Мир, для которого считаются рельеф и мегаполисы (ставится при запуске сервера). */
    static ServerWorld world;

    public static void start(MinecraftServer server) {
        world = server.getOverworld();
    }

    /** Описание поселения в регионе (детерминировано от сида мира). */
    record Settlement(long key, int rx, int rz, Type type, String name, int cx, int cz, List<int[]> rects, long seed, int size) {}

    private static final ArrayDeque<Job> QUEUE = new ArrayDeque<>();
    static final Set<Long> QUEUED = new HashSet<>();

    static void enqueue(Job j) {
        QUEUE.addLast(j);
    }
    private static final Map<UUID, Long> WHERE = new HashMap<>();
    private static final Set<Long> metroSeen = new HashSet<>();

    private Knox() {
    }

    // ===================== раскладка =====================

    static long regionKey(int rx, int rz) {
        return ((long) rx << 32) | (rz & 0xffffffffL);
    }

    private static final String[] PRE = {"Эш", "Сидар", "Милл", "Грин", "Пайн", "Стоун", "Уиллоу", "Фэйр", "Элк", "Коппер",
            "Ред", "Блэк", "Оук", "Мэйпл", "Ривер", "Хэй", "Брайар", "Холлоу", "Дир", "Клэй"};
    private static final String[] SUF = {"форд", "-Холлоу", "брук", "филд", "-Ридж", "бридж", "-Крик", "вью", "-Ран", "-Спрингс",
            "вуд", "-Фоллс", "вилл", "-Джанкшен", "-Пойнт", "тон", "-Миллс", "дейл"};

    static Settlement settlement(long worldSeed, int rx, int rz) {
        Metro.City mc = Metro.forRegion(worldSeed, rx, rz);
        if (mc != null) return Metro.settlement(mc);
        java.util.Random r = new java.util.Random(worldSeed * 341873128712L + rx * 132897987541L + rz * 42317861L + 7);
        double roll = r.nextDouble();
        Type type = roll < 0.09 ? Type.CITY : (roll < 0.3 ? Type.TOWN : (roll < 0.57 ? Type.VILLAGE : (roll < 0.8 ? Type.FARMS : Type.FOREST)));
        if (rx == 0 && rz == 0) type = Type.TOWN;   // у точки появления - город, как старт в PZ
        // крупные особые места: военная база, тюрьма, исследовательский центр, торговый центр
        java.util.Random r2 = new java.util.Random(worldSeed ^ (rx * 0x9E3779B97F4A7C15L) ^ (rz * 0xC2B2AE3D27D4EB4FL) ^ 0x51ECL);
        if ((type == Type.FARMS || type == Type.FOREST) && r2.nextFloat() < 0.22f) {
            int k = r2.nextInt(10);
            type = k < 3 ? Type.MILITARY : k < 5 ? Type.PRISON : k < 7 ? Type.LAB : Type.MALL;
        }
        if (rx == -1 && rz == 0) type = Type.MILITARY;   // рядом со стартом — по одному каждого
        if (rx == 0 && rz == -1) type = Type.MALL;
        if (rx == -1 && rz == -1) type = Type.PRISON;
        if (rx == -1 && rz == 1) type = Type.LAB;
        int cx = rx * REGION + REGION / 2 + r.nextInt(161) - 80;
        int cz = rz * REGION + REGION / 2 + r.nextInt(161) - 80;
        if (type == Type.CITY) {   // большой город — почти во весь регион, ближе к центру
            cx = rx * REGION + REGION / 2 + r.nextInt(33) - 16;
            cz = rz * REGION + REGION / 2 + r.nextInt(33) - 16;
        }
        String name = PRE[r.nextInt(PRE.length)] + SUF[r.nextInt(SUF.length)];
        if (special(type)) {
            String[][] names = {{"Кэмп-Рейвен", "Форт-Хайленд", "Блэкстоун", "Айрон-Ридж", "Кэмп-Холлис"}, {"Роквуд", "Грейстоун", "Айронгейт", "Кроу-Хилл"},
                    {"Атлас", "Прометей", "Гелиос", "Кеплер", "Орион"}, {"Гранд Плаза", "Ривер-Молл", "Сити Галерея", "Санрайз", "Мэйпл-Центр"}};
            String[] pre = {"База «", "Тюрьма «", "Центр «", "ТЦ «"};
            int t = type.ordinal() - Type.MILITARY.ordinal();
            name = pre[t] + names[t][r2.nextInt(names[t].length)] + "»";
        }
        List<int[]> rects = new ArrayList<>();
        int size = 0;
        switch (type) {
            case CITY -> {
                size = 352 + r.nextInt(4) * 16;
                rects.add(new int[]{cx - size / 2, cz - size / 2, cx - size / 2 + size - 1, cz - size / 2 + size - 1});
            }
            case TOWN -> {
                size = 224 + r.nextInt(5) * 16;
                rects.add(new int[]{cx - size / 2, cz - size / 2, cx - size / 2 + size - 1, cz - size / 2 + size - 1});
            }
            case VILLAGE -> {
                size = 120 + r.nextInt(4) * 12;
                rects.add(new int[]{cx - size / 2, cz - 46, cx - size / 2 + size - 1, cz + 46});
            }
            case FARMS -> {
                int n = 2 + r.nextInt(2);
                int[][] q = {{1, 1}, {-1, 1}, {1, -1}, {-1, -1}};
                for (int i = 0; i < n; i++) {
                    int fx = cx + (q[i][0] > 0 ? 14 + r.nextInt(40) : -14 - 56 - r.nextInt(40));
                    int fz = cz + (q[i][1] > 0 ? 14 + r.nextInt(40) : -14 - 56 - r.nextInt(40));
                    rects.add(new int[]{fx, fz, fx + 55, fz + 55});
                }
            }
            case MILITARY, PRISON, LAB, MALL -> {
                int[][] dims = {{208, 176}, {176, 176}, {144, 128}, {208, 136}};
                int[] dd = dims[type.ordinal() - Type.MILITARY.ordinal()];
                cx = rx * REGION + REGION / 2 + r2.nextInt(81) - 40;
                cz = rz * REGION + REGION / 2 + r2.nextInt(81) - 40;
                size = Math.max(dd[0], dd[1]);
                rects.add(new int[]{cx - dd[0] / 2, cz - dd[1] / 2, cx - dd[0] / 2 + dd[0] - 1, cz - dd[1] / 2 + dd[1] - 1});
            }
            case FOREST -> {
                size = 50 + r.nextInt(30);
                rects.add(new int[]{cx + 20, cz + 20, cx + 31, cz + 31});  // хижина
            }
        }
        return new Settlement(regionKey(rx, rz), rx, rz, type, name, cx, cz, rects, r.nextLong(), size);
    }

    static boolean inside(Settlement s, int x, int z, int margin) {
        for (int[] q : s.rects()) if (x >= q[0] - margin && x <= q[2] + margin && z >= q[1] - margin && z <= q[3] + margin) return true;
        return false;
    }

    static double distTo(Settlement s, double x, double z) {
        double best = Double.MAX_VALUE;
        for (int[] q : s.rects()) {
            double dx = Math.max(Math.max(q[0] - x, 0), x - q[2]);
            double dz = Math.max(Math.max(q[1] - z, 0), z - q[3]);
            best = Math.min(best, Math.hypot(dx, dz));
        }
        if (s.type() == Type.FOREST) best = Math.min(best, Math.max(0, Math.hypot(x - s.cx(), z - s.cz()) - s.size()));
        return best;
    }

    /** Точка въезда шоссе: {x, z, направление наружу dx, dz, длина прямого подъезда}. side: 0 восток, 1 юг, 2 запад, 3 север. */
    static double[] entrance(long seed, Settlement s, int side, double towardX, double towardZ) {
        int[] dir = {1, 0, 0, 1, -1, 0, 0, -1};
        int dx = dir[side * 2], dz = dir[side * 2 + 1];
        switch (s.type()) {
            case METRO -> {
                Metro.City c = Metro.of(seed, Math.floorDiv(s.cx(), Metro.SR), Math.floorDiv(s.cz(), Metro.SR));
                if (c != null) return Metro.entrance(c, side, towardX, towardZ);
            }
            case MILITARY, PRISON, LAB, MALL -> {
                int[] q = s.rects().get(0);
                double mz = s.cz() + 0.5, mx = s.cx() + 0.5;
                return switch (side) {
                    case 0 -> new double[]{q[2] + 1, mz, dx, dz, 40};
                    case 2 -> new double[]{q[0], mz, dx, dz, 40};
                    case 1 -> new double[]{mx, q[3] + 1, dx, dz, 40};
                    default -> new double[]{mx, q[1], dx, dz, 40};
                };
            }
            case TOWN, CITY, VILLAGE -> {
                int[] q = s.rects().get(0);
                int crossX = crossX(s);
                double mz = s.cz() + 0.5, mx = crossX + 0.5;
                return switch (side) {
                    case 0 -> new double[]{q[2] + 1, mz, dx, dz, 40};
                    case 2 -> new double[]{q[0], mz, dx, dz, 40};
                    case 1 -> new double[]{mx, q[3] + 1, dx, dz, 40};
                    default -> new double[]{mx, q[1], dx, dz, 40};
                };
            }
            default -> {
            }
        }
        return new double[]{s.cx() + 0.5, s.cz() + 0.5, dx, dz, 0};
    }

    /** Поперечная улица города (мировая x): продолжение шоссе с севера и юга. */
    static int crossX(Settlement s) {
        int[] q = s.rects().get(0);
        int rcx = s.rx() * REGION + REGION / 2;
        return Math.max(q[0] + 20, Math.min(q[2] - 20, rcx));
    }

    private static final Map<Long, int[]> BASES = new HashMap<>();

    /** Уровень земли поселения и доля воды — по рельефу «из чертежа», одинаково для дорог и стройки. */
    static int[] base(ServerWorld w, Settlement s) {
        return BASES.computeIfAbsent(s.key() ^ w.getSeed(), k -> {
            int[] q = s.rects().get(0);
            int x1 = q[0], z1 = q[1], x2 = q[2], z2 = q[3];
            for (int[] r : s.rects()) {
                x1 = Math.min(x1, r[0]);
                z1 = Math.min(z1, r[1]);
                x2 = Math.max(x2, r[2]);
                z2 = Math.max(z2, r[3]);
            }
            int[] sv = Terrain.survey(w, x1, z1, x2, z2, 5);
            return new int[]{Math.max(w.getSeaLevel() + 1, sv[0]), sv[1]};
        });
    }

    /** Высота дороги у въезда. */
    static float pinHeight(ServerWorld w, Settlement s, double[] node) {
        if (s.type() == Type.METRO) {
            Metro.City c = Metro.of(w.getSeed(), Math.floorDiv(s.cx(), Metro.SR), Math.floorDiv(s.cz(), Metro.SR));
            if (c != null) return c.base();
        }
        if (s.type() == Type.TOWN || s.type() == Type.CITY || s.type() == Type.VILLAGE || special(s.type())) return base(w, s)[0];
        int x = (int) Math.floor(node[0]), z = (int) Math.floor(node[1]);
        if (Terrain.wet(w, x, z)) return w.getSeaLevel() + 2;
        return Math.max(w.getSeaLevel() + 1, Math.round(Terrain.smooth(w, x, z)));
    }

    // ===================== высоты =====================

    /** Уровень земли (без деревьев и травы). Вода считается поверхностью. */
    static int ground(ServerWorld w, int x, int z) {
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
        BlockPos.Mutable m = new BlockPos.Mutable(x, y, z);
        for (int i = 0; i < 40 && y > w.getBottomY(); i++) {
            BlockState s = w.getBlockState(m.setY(y));
            boolean soft = s.isIn(BlockTags.LOGS) || s.isIn(BlockTags.LEAVES) || s.isAir()
                    || (s.isReplaceable() && s.getFluidState().isEmpty());
            if (!soft) break;
            y--;
        }
        return y;
    }

    static boolean water(ServerWorld w, int x, int y, int z) {
        return !w.getBlockState(new BlockPos(x, y, z)).getFluidState().isEmpty();
    }

    // ===================== работы =====================

    interface Job {
        /** Делает часть работы, возвращает потраченный бюджет. */
        int run(ServerWorld w, int budget);

        boolean done();
    }

    /** Разведка: выбирает высоту поселения и ставит в очередь остальное. */
    static final class SurveyJob implements Job {
        final Settlement s;
        boolean finished;

        SurveyJob(Settlement s) {
            this.s = s;
        }

        public int run(ServerWorld w, int budget) {
            finished = true;
            MapState st = MapState.get(w.getServer());
            if (s.type() == Type.FOREST) {
                QUEUE.addLast(new ForestJob(s));
                int[] c = s.rects().get(0);
                int base = ground(w, c[0] + 6, c[1] + 6);
                if (!water(w, c[0] + 6, base, c[1] + 6)) {
                    QUEUE.addLast(new FlattenJob(c[0], c[1], c[2], c[3], base, 4));
                    Plan p = new Plan(12, 12, Random.create(s.seed()));
                    Buildings.cabin(p);
                    QUEUE.addLast(new PlaceJob(p, c[0], base, c[1], BlockRotation.NONE));
                }
                QUEUE.addLast(new DoneJob(s));
                return 40;
            }
            int[] bw = base(w, s);
            if (s.type() == Type.METRO || s.type() == Type.NONE) {   // мегаполис строится кварталами (Metro.tick)
                QUEUED.remove(s.key());
                return 10;
            }
            if (bw[1] > 35) {   // слишком много воды - не строим
                st.done.add(s.key());
                st.markDirty();
                QUEUED.remove(s.key());
                return 100;
            }
            int base = bw[0];
            Random r = Random.create(s.seed());
            switch (s.type()) {
                case TOWN -> town(s, base, r);
                case CITY -> city(s, base, r);
                case VILLAGE -> village(s, base, r);
                case FARMS -> farms(s, base, r);
                case MILITARY, PRISON, LAB, MALL -> Landmarks.build(s, base, r);
                default -> {
                }
            }
            QUEUE.addLast(new DoneJob(s));
            return 200;
        }

        public boolean done() {
            return finished;
        }
    }

    static final class DoneJob implements Job {
        final Settlement s;
        boolean finished;

        DoneJob(Settlement s) {
            this.s = s;
        }

        public int run(ServerWorld w, int budget) {
            MapState st = MapState.get(w.getServer());
            st.done.add(s.key());
            st.markDirty();
            QUEUED.remove(s.key());
            finished = true;
            return 1;
        }

        public boolean done() {
            return finished;
        }
    }

    /** Выравнивание площадки: внутри - ровно на base, по краям - плавный переход к рельефу. */
    static final class FlattenJob implements Job {
        final int x1, z1, x2, z2, base, ix1, iz1, ix2, iz2, mW, mE, mN, mS;
        int cx, cz;

        FlattenJob(int x1, int z1, int x2, int z2, int base, int margin) {
            this(x1, z1, x2, z2, base, margin, margin, margin, margin);
        }

        /** Переход к рельефу только с указанных сторон (для кварталов мегаполиса — наружу). */
        FlattenJob(int x1, int z1, int x2, int z2, int base, int mW, int mE, int mN, int mS) {
            this.ix1 = x1;
            this.iz1 = z1;
            this.ix2 = x2;
            this.iz2 = z2;
            this.x1 = x1 - mW;
            this.z1 = z1 - mN;
            this.x2 = x2 + mE;
            this.z2 = z2 + mS;
            this.mW = mW;
            this.mE = mE;
            this.mN = mN;
            this.mS = mS;
            this.base = base;
            cx = this.x1;
            cz = this.z1;
        }

        public int run(ServerWorld w, int budget) {
            int used = 0;
            BlockPos.Mutable m = new BlockPos.Mutable();
            while (used < budget && cz <= z2) {
                int g = ground(w, cx, cz);
                double tx = cx < ix1 ? (ix1 - cx) / (double) Math.max(1, mW) : cx > ix2 ? (cx - ix2) / (double) Math.max(1, mE) : 0;
                double tz = cz < iz1 ? (iz1 - cz) / (double) Math.max(1, mN) : cz > iz2 ? (cz - iz2) / (double) Math.max(1, mS) : 0;
                double t = Math.min(1.0, Math.max(tx, tz));
                if (t > 0 && Roads.isRoadBlock(w.getBlockState(m.set(cx, g, cz)))) {   // шоссе не трогаем
                    used += 2;
                    if (++cx > x2) {
                        cx = x1;
                        cz++;
                    }
                    continue;
                }
                int h = (int) Math.round(base * (1 - t) + g * t);
                int top = Math.max(g, h) + (t < 1 ? 24 : 0);
                for (int y = h + 1; y <= top; y++) {
                    BlockState s = w.getBlockState(m.set(cx, y, cz));
                    if (!s.isAir()) {
                        w.setBlockState(m, Blocks.AIR.getDefaultState(), FLAGS);
                        used++;
                    }
                }
                w.setBlockState(m.set(cx, h, cz), Blocks.GRASS_BLOCK.getDefaultState(), FLAGS);
                for (int y = h - 1; y > h - 12; y--) {
                    BlockState s = w.getBlockState(m.set(cx, y, cz));
                    if (s.isSolidBlock(w, m) && s.getFluidState().isEmpty()) break;
                    w.setBlockState(m, Blocks.DIRT.getDefaultState(), FLAGS);
                    used++;
                }
                used += 4;
                if (++cx > x2) {
                    cx = x1;
                    cz++;
                }
            }
            return used;
        }

        public boolean done() {
            return cz > z2;
        }
    }

    /** Постройка плана: блоки, затем обновление форм (заборы, стёкла), затем лут, зомби и животные. */
    static final class PlaceJob implements Job {
        Plan p;
        final java.util.function.Supplier<Plan> maker;
        final int ox, oy, oz;
        final BlockRotation rot;
        List<Map.Entry<Long, BlockState>> list;
        final List<BlockPos> post = new ArrayList<>();
        int i = 0, phase = 0;

        PlaceJob(Plan p, int ox, int oy, int oz, BlockRotation rot) {
            this(p, null, ox, oy, oz, rot);
        }

        /** План строится только когда до него дошла очередь — большой город не занимает память целиком. */
        PlaceJob(Plan p, java.util.function.Supplier<Plan> maker, int ox, int oy, int oz, BlockRotation rot) {
            this.p = p;
            this.maker = maker;
            this.ox = ox;
            this.oy = oy;
            this.oz = oz;
            this.rot = rot;
        }

        BlockPos world(long local) {
            int x = BlockPos.unpackLongX(local), y = BlockPos.unpackLongY(local), z = BlockPos.unpackLongZ(local);
            int wx, wz;
            switch (rot) {
                case CLOCKWISE_90 -> {
                    wx = p.d - 1 - z;
                    wz = x;
                }
                case CLOCKWISE_180 -> {
                    wx = p.w - 1 - x;
                    wz = p.d - 1 - z;
                }
                case COUNTERCLOCKWISE_90 -> {
                    wx = z;
                    wz = p.w - 1 - x;
                }
                default -> {
                    wx = x;
                    wz = z;
                }
            }
            return new BlockPos(ox + wx, oy + y, oz + wz);
        }

        /** Дробная точка плана (центр машины) в мировые координаты с учётом поворота. */
        double[] worldD(double x, double z) {
            double wx, wz;
            switch (rot) {
                case CLOCKWISE_90 -> {
                    wx = p.d - z;
                    wz = x;
                }
                case CLOCKWISE_180 -> {
                    wx = p.w - x;
                    wz = p.d - z;
                }
                case COUNTERCLOCKWISE_90 -> {
                    wx = z;
                    wz = p.w - x;
                }
                default -> {
                    wx = x;
                    wz = z;
                }
            }
            return new double[]{ox + wx, oz + wz};
        }

        public int run(ServerWorld w, int budget) {
            int used = 0;
            if (list == null) {
                if (p == null) p = maker.get();
                list = new ArrayList<>(p.blocks.entrySet());
                p.blocks.clear();
                return Math.max(1, list.size() / 20);
            }
            if (phase == 0) {
                while (used < budget && i < list.size()) {
                    Map.Entry<Long, BlockState> e = list.get(i++);
                    BlockPos pos = world(e.getKey());
                    BlockState st = e.getValue().rotate(rot);
                    w.setBlockState(pos, st, FLAGS);
                    Block b = st.getBlock();
                    if (b instanceof FenceBlock || b instanceof PaneBlock || b instanceof WallBlock || b instanceof StairsBlock) post.add(pos);
                    used++;
                }
                if (i >= list.size()) {
                    phase = 1;
                    i = 0;
                }
            } else if (phase == 1) {
                while (used < budget && i < post.size()) {
                    BlockPos pos = post.get(i++);
                    BlockState cur = w.getBlockState(pos);
                    BlockState upd = Block.postProcessState(cur, w, pos);
                    if (upd != cur) w.setBlockState(pos, upd, FLAGS);
                    used += 2;
                }
                if (i >= post.size()) phase = 2;
            } else if (phase == 2) {
                for (long[] l : p.loot) {
                    BlockEntity be = w.getBlockEntity(world(l[0]));
                    if (be instanceof com.example.zomboidmod.block.LootPileBlockEntity pile) {
                        net.minecraft.item.ItemStack st = Loot.values()[(int) l[1]].randomItem(p.r);
                        if (st.isEmpty()) w.removeBlock(world(l[0]), false);
                        else pile.set(st, p.r.nextFloat() * 360f);
                    } else if (be instanceof Inventory inv) {
                        Loot lt = Loot.values()[(int) l[1]];
                        if (lt == Loot.STASH) lt.fillAlways(inv, p.r);
                        else lt.fill(inv, p.r);
                        // в домах и машинах изредка попадаются записки выживших и карты тайников
                        if (lt == Loot.BEDROOM || lt == Loot.LIVING || lt == Loot.OFFICE || lt == Loot.CABIN || lt == Loot.POLICE) {
                            if (p.r.nextFloat() < 0.04f) Stories.put(inv, Stories.note(w, world(l[0]), p.r), p.r);
                            if (p.r.nextFloat() < 0.012f) Stories.put(inv, Stories.stashMap(w, world(l[0]), p.r), p.r);
                        }
                    }
                    used += 3;
                }
                for (long[] ex : p.extras) {
                    BlockPos pos = world(ex[0]);
                    if (w.getBlockEntity(pos) instanceof Inventory inv)
                        Stories.put(inv, ex[1] == 1 ? Stories.stashMap(w, pos, p.r) : Stories.note(w, pos, p.r, (int) ex[2]), p.r);
                }
                for (Object[] z : p.zombies) {
                    PzZombieEntity zombie = ZomboidEntities.PZ_ZOMBIE.create(w);
                    if (zombie == null) continue;
                    BlockPos pos = world((Long) z[0]);
                    zombie.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, p.r.nextFloat() * 360f, 0f);
                    zombie.setup((ZombieOutfit) z[1], p.tierOf(z));
                    zombie.setPersistent();
                    w.spawnEntity(zombie);
                    if (p.r.nextFloat() < 0.2f && w.getBlockState(pos).isAir() && w.getBlockState(pos.down()).isOpaqueFullCube(w, pos.down())) {
                        w.setBlockState(pos, com.example.zomboidmod.block.ZomboidBlocks.BLOOD.getDefaultState()
                                .with(com.example.zomboidmod.block.DecalBlock.VARIANT, p.r.nextInt(4)), FLAGS);
                    }
                    used += 20;
                }
                for (Object[] v : p.vehicles) {
                    com.example.zomboidmod.vehicle.VehicleType t = com.example.zomboidmod.vehicle.VehicleType.byId((String) v[3]);
                    com.example.zomboidmod.vehicle.VehicleEntity car = t.entityType.create(w);
                    if (car == null) continue;
                    double[] wp = worldD((Double) v[0], (Double) v[2]);
                    float yaw = (Float) v[4] + switch (rot) {
                        case CLOCKWISE_90 -> 90f;
                        case CLOCKWISE_180 -> 180f;
                        case COUNTERCLOCKWISE_90 -> 270f;
                        default -> 0f;
                    };
                    car.refreshPositionAndAngles(wp[0], oy + (Integer) v[1], wp[1], yaw, 0f);
                    car.randomize(p.r, (Boolean) v[5]);
                    if (p.r.nextFloat() < 0.45f) Loot.values()[p.r.nextBoolean() ? Loot.GARAGE.ordinal() : Loot.TRASH.ordinal()].fill(car.trunk(), p.r);
                    car.stashKey();
                    w.spawnEntity(car);
                    used += 20;
                }
                for (long a : p.animals) {
                    CowEntity cow = EntityType.COW.create(w);
                    if (cow == null) continue;
                    BlockPos pos = world(a);
                    cow.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, p.r.nextFloat() * 360f, 0f);
                    w.spawnEntity(cow);
                }
                phase = 3;
            }
            return Math.max(1, used);
        }

        public boolean done() {
            return phase == 3;
        }
    }

    /** Лес: деревья по кругу на рельефе. */
    static final class ForestJob implements Job {
        final Settlement s;
        final Random r;
        int planted = 0;
        final int total;

        ForestJob(Settlement s) {
            this.s = s;
            this.r = Random.create(s.seed() ^ 0x5DEECE66DL);
            this.total = s.size() * s.size() / 12;
        }

        public int run(ServerWorld w, int budget) {
            int used = 0;
            while (used < budget && planted < total) {
                planted++;
                double a = r.nextDouble() * Math.PI * 2, d = Math.sqrt(r.nextDouble()) * s.size();
                int x = s.cx() + (int) (Math.cos(a) * d), z = s.cz() + (int) (Math.sin(a) * d);
                if (inside(s, x, z, 3)) continue;
                int g = ground(w, x, z);
                BlockState top = w.getBlockState(new BlockPos(x, g, z));
                if (!top.isOf(Blocks.GRASS_BLOCK) && !top.isOf(Blocks.DIRT) && !top.isOf(Blocks.PODZOL)) continue;
                Plan p = new Plan(1, 1, r);
                int kind = r.nextFloat() < 0.5f ? 0 : (r.nextFloat() < 0.5f ? 1 : 2);
                p.tree(0, 0, 0, kind);
                if (r.nextFloat() < 0.3f) p.set(1, 1, 0, Blocks.FERN);
                for (Map.Entry<Long, BlockState> e : p.blocks.entrySet()) {
                    BlockPos pos = BlockPos.fromLong(e.getKey()).add(x, g, z);
                    if (w.getBlockState(pos).isAir() || w.getBlockState(pos).isReplaceable()) w.setBlockState(pos, e.getValue(), FLAGS);
                    used++;
                }
                used += 10;
            }
            return Math.max(1, used);
        }

        public boolean done() {
            return planted >= total;
        }
    }

    // ===================== поселения =====================

    private static Plan plan(int w, int d, Random r) {
        return new Plan(w, d, Random.create(r.nextLong()));
    }

    static void lot(Plan p, int x, int y, int z, BlockRotation rot) {
        QUEUE.addLast(new PlaceJob(p, x, y, z, rot));
    }

    static void lot(java.util.function.Supplier<Plan> maker, int x, int y, int z, BlockRotation rot) {
        QUEUE.addLast(new PlaceJob(null, maker, x, y, z, rot));
    }

    /** Город: улицы разной длины без сетки (см. TownGen). Главная улица продолжает шоссе. */
    private static void town(Settlement s, int base, Random r) {
        int[] q = s.rects().get(0);
        QUEUE.addLast(new FlattenJob(q[0], q[1], q[2], q[3], base, 12));
        int rcx = s.rx() * REGION + REGION / 2;
        new TownGen(q[0], q[1], q[2] - q[0] + 1, q[3] - q[1] + 1, base, r, false).generate(s.cz() - q[1], rcx - q[0]);
    }

    /** Большой город: несколько проспектов, деловой центр с высотками, больница, торговый центр, блокпосты на въездах. */
    private static void city(Settlement s, int base, Random r) {
        int[] q = s.rects().get(0);
        QUEUE.addLast(new FlattenJob(q[0], q[1], q[2], q[3], base, 14));
        int rcx = s.rx() * REGION + REGION / 2;
        TownGen g = new TownGen(q[0], q[1], q[2] - q[0] + 1, q[3] - q[1] + 1, base, r, false);
        g.city = true;
        g.generate(s.cz() - q[1], rcx - q[0]);
    }

    /** Деревня: дорога насквозь, пара переулков, редкие дома, магазинчик, часовня, поля. */
    private static void village(Settlement s, int base, Random r) {
        int[] q = s.rects().get(0);
        QUEUE.addLast(new FlattenJob(q[0], q[1], q[2], q[3], base, 12));
        new TownGen(q[0], q[1], q[2] - q[0] + 1, q[3] - q[1] + 1, base, r, true).generate(s.cz() - q[1], crossX(s) - q[0]);
    }

    /** Фермы: дом, амбар, силос, поля, пастбище с коровами. */
    private static void farms(Settlement s, int base, Random r) {
        for (int[] q : s.rects()) {
            QUEUE.addLast(new FlattenJob(q[0], q[1], q[2], q[3], base, 10));
            Plan f = plan(56, 56, r);
            Plan h = plan(12, 12, r);
            if (r.nextBoolean()) Buildings.house(h);
            else Buildings.twoStory(h);
            f.embed(h, 2, 2);
            Buildings.barn(f, 18, 2);
            Buildings.silo(f, 42, 8);
            for (int k = 0; k < 2; k++) Buildings.field(f, 26, 22 + k * 16, 53, 35 + k * 16);
            for (int x = 2; x <= 22; x++) {
                f.set(x, 1, 22, Blocks.OAK_FENCE);
                f.set(x, 1, 53, Blocks.OAK_FENCE);
            }
            for (int z = 22; z <= 53; z++) {
                f.set(2, 1, z, Blocks.OAK_FENCE);
                f.set(22, 1, z, Blocks.OAK_FENCE);
            }
            f.set(12, 1, 22, Blocks.OAK_FENCE_GATE);
            for (int k = 0; k < 3 + r.nextInt(3); k++) f.animal(5 + r.nextInt(15), 1, 25 + r.nextInt(25));
            f.zombie(30, 1, 30, ZombieOutfit.FARMER);
            lot(f, q[0], base, q[1], BlockRotation.NONE);
        }
    }

    // ===================== шоссе — см. Roads =====================

    static void sign(ServerWorld w, int x, int z, int rotation, String l1, String l2, String l3, String l4) {
        int g = ground(w, x, z);
        if (water(w, x, g, z)) return;
        BlockPos post = new BlockPos(x, g + 1, z);
        w.setBlockState(post, Blocks.SPRUCE_FENCE.getDefaultState(), FLAGS);
        BlockPos at = post.up();
        BlockState st = Blocks.SPRUCE_SIGN.getDefaultState().with(net.minecraft.block.SignBlock.ROTATION, rotation);
        w.setBlockState(at, st, Block.NOTIFY_ALL);
        if (w.getBlockEntity(at) instanceof net.minecraft.block.entity.SignBlockEntity sign) {
            sign.changeText(t -> t.withMessage(0, Text.literal(l1)).withMessage(1, Text.literal(l2))
                    .withMessage(2, Text.literal(l3)).withMessage(3, Text.literal(l4)), true);
            sign.setWaxed(true);
            sign.markDirty();
            w.updateListeners(at, st, st, Block.NOTIFY_ALL);
        }
    }

    /** Брошенная машина (настоящая: может завестись, в багажнике бывает лут). */
    static void spawnCar(ServerWorld w, double x, double z, float yaw, boolean wreck, long seed) {
        Random rr = Random.create(seed);
        com.example.zomboidmod.vehicle.VehicleType t = com.example.zomboidmod.vehicle.VehicleType.randomCivil(rr);
        com.example.zomboidmod.vehicle.VehicleEntity car = t.entityType.create(w);
        if (car == null) return;
        int g = ground(w, (int) Math.floor(x), (int) Math.floor(z));
        car.refreshPositionAndAngles(x, g + 1, z, yaw, 0f);
        car.randomize(rr, wreck);
        if (rr.nextFloat() < 0.5f) Loot.values()[rr.nextBoolean() ? Loot.GARAGE.ordinal() : Loot.TRASH.ordinal()].fill(car.trunk(), rr);
        car.stashKey();
        w.spawnEntity(car);
    }

    // ===================== тик сервера =====================

    public static void tick(MinecraftServer server) {
        ServerWorld w = server.getOverworld();
        world = w;
        int budget = BLOCKS_PER_TICK;
        while (budget > 0 && !QUEUE.isEmpty()) {
            Job j = QUEUE.peekFirst();
            budget -= j.run(w, budget);
            if (j.done()) QUEUE.pollFirst();
        }
        if (server.getTicks() % 40 != 0) return;

        MapState st = MapState.get(server);
        long seed = w.getSeed();
        for (ServerPlayerEntity p : w.getPlayers()) {
            int prx = Math.floorDiv(p.getBlockX(), REGION), prz = Math.floorDiv(p.getBlockZ(), REGION);
            Settlement here = null;
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++) {
                    Settlement s = settlement(seed, prx + dx, prz + dz);
                    double dist = distTo(s, p.getX(), p.getZ());
                    if (dist <= 0 && s.type() != Type.FOREST && s.type() != Type.NONE) here = s;
                    if (s.type() == Type.METRO) {
                        if (dist < 220 && !metroSeen.contains(s.key())) {
                            metroSeen.add(s.key());
                            Metro.City c = Metro.of(seed, Math.floorDiv(s.cx(), Metro.SR), Math.floorDiv(s.cz(), Metro.SR));
                            if (c != null) Metro.tick(w, p, c, st);
                        }
                    } else if (dist < TRIGGER && !st.done.contains(s.key()) && QUEUED.add(s.key())) {
                        QUEUE.addLast(new SurveyJob(s));
                    }
                }
            metroSeen.clear();
            // шоссе: куски ближе ROAD_TRIGGER
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                    for (int dir = 0; dir < 2; dir++) {
                        Roads.Road rd = Roads.road(seed, prx + dx, prz + dz, dir);
                        if (rd == null) continue;
                        for (int i = 0; i < rd.pieces(); i++) {
                            int t = Math.min(rd.n - 1, i * Roads.PIECE + Roads.PIECE / 2);
                            if (Math.hypot(rd.px[t] - p.getX(), rd.pz[t] - p.getZ()) >= ROAD_TRIGGER) continue;
                            long key = rd.pieceKey(i);
                            if (!st.roads.contains(key) && QUEUED.add(key)) QUEUE.addLast(new Roads.PieceJob(rd, i));
                        }
                    }
            Sites.tick(w, p, st);
            // название места, как при входе в город
            Long prev = WHERE.get(p.getUuid());
            Long now = here == null ? null : here.key();
            if (now != null && !now.equals(prev)) {
                String kind = switch (here.type()) {
                    case MILITARY -> "военная база";
                    case PRISON -> "тюрьма";
                    case LAB -> "исследовательский центр";
                    case MALL -> "торговый центр";
                    case METRO -> "мегаполис";
                    case CITY -> "большой город";
                    case TOWN -> "город";
                    case VILLAGE -> "деревня";
                    default -> "фермы";
                };
                p.sendMessage(Text.literal("— " + here.name() + " (" + kind + ") —"), true);
            }
            if (now == null) WHERE.remove(p.getUuid());
            else WHERE.put(p.getUuid(), now);
        }
    }

    public static void stop() {
        world = null;
        BASES.clear();
        QUEUE.clear();
        QUEUED.clear();
        WHERE.clear();
    }

    /** Информация для команды. */
    public static String info(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        int prx = Math.floorDiv(p.getBlockX(), REGION), prz = Math.floorDiv(p.getBlockZ(), REGION);
        StringBuilder sb = new StringBuilder("Ближайшие места:");
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++) {
                Settlement s = settlement(w.getSeed(), prx + dx, prz + dz);
                String kind = switch (s.type()) {
                    case MILITARY -> "военная база";
                    case PRISON -> "тюрьма";
                    case LAB -> "исследовательский центр";
                    case MALL -> "торговый центр";
                    case METRO -> "мегаполис";
                    case CITY -> "большой город";
                    case TOWN -> "город";
                    case VILLAGE -> "деревня";
                    case FARMS -> "фермы";
                    case NONE -> "глушь";
                    default -> "лес";
                };
                sb.append("\n").append(s.name()).append(" - ").append(kind).append(" (").append(s.cx()).append(", ").append(s.cz())
                        .append("), ").append((int) Math.hypot(s.cx() - p.getX(), s.cz() - p.getZ())).append(" бл.");
            }
        sb.append("\nВ очереди стройки: ").append(QUEUE.size());
        return sb.toString();
    }

    /** Данные для бумажной карты: поселения и шоссе в радиусе radius регионов. */
    public static NbtCompound mapData(ServerWorld w, int x, int z, int radius) {
        long seed = w.getSeed();
        int prx = Math.floorDiv(x, REGION), prz = Math.floorDiv(z, REGION);
        net.minecraft.nbt.NbtList list = new net.minecraft.nbt.NbtList();
        net.minecraft.nbt.NbtList roadList = new net.minecraft.nbt.NbtList();
        Set<Long> seen = new HashSet<>();
        for (int dx = -radius; dx <= radius; dx++)
            for (int dz = -radius; dz <= radius; dz++) {
                Settlement s = settlement(seed, prx + dx, prz + dz);
                for (int dir = 0; dir < 2; dir++) {
                    Roads.Road rd = Roads.road(seed, prx + dx, prz + dz, dir);
                    if (rd != null) roadList.add(new net.minecraft.nbt.NbtIntArray(Roads.polyline(rd, 12)));
                }
                if (!seen.add(s.key()) || s.type() == Type.NONE) continue;
                NbtCompound c = new NbtCompound();
                c.putString("n", s.name());
                c.putInt("t", s.type().ordinal());
                c.putInt("x", s.cx());
                c.putInt("z", s.cz());
                c.putInt("size", s.size());
                int[] r = new int[s.rects().size() * 4];
                for (int i = 0; i < s.rects().size(); i++) System.arraycopy(s.rects().get(i), 0, r, i * 4, 4);
                c.putIntArray("r", r);
                if (s.type() == Type.METRO) c.putInt("grid", Metro.TILE);
                list.add(c);
            }
        NbtCompound n = new NbtCompound();
        n.put("s", list);
        n.put("rl", roadList);
        n.putInt("region", REGION);
        n.put("p", Sites.found(seed, MapState.get(w.getServer()), prx, prz, radius));
        return n;
    }

    // ===================== сохранение =====================

    public static final class MapState extends PersistentState {
        final Set<Long> done = new HashSet<>();
        final Set<Long> roads = new HashSet<>();
        /** Места, до которых игроки уже дошли (видны на карте). */
        final Set<Long> found = new HashSet<>();
        /** Тайники, которые уже нашли (на них больше не рисуют карт). */
        final Set<Long> looted = new HashSet<>();

        private static final PersistentState.Type<MapState> TYPE =
                new PersistentState.Type<>(MapState::new, MapState::fromNbt, null);

        static MapState get(MinecraftServer server) {
            return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, "zomboidmod_map");
        }

        @Override
        public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
            nbt.putLongArray("done", done.stream().mapToLong(Long::longValue).toArray());
            nbt.putLongArray("roads", roads.stream().mapToLong(Long::longValue).toArray());
            nbt.putLongArray("found", found.stream().mapToLong(Long::longValue).toArray());
            nbt.putLongArray("looted", looted.stream().mapToLong(Long::longValue).toArray());
            return nbt;
        }

        static MapState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
            MapState s = new MapState();
            for (long l : nbt.getLongArray("done")) s.done.add(l);
            for (long l : nbt.getLongArray("roads")) s.roads.add(l);
            for (long l : nbt.getLongArray("found")) s.found.add(l);
            for (long l : nbt.getLongArray("looted")) s.looted.add(l);
            return s;
        }
    }
}
