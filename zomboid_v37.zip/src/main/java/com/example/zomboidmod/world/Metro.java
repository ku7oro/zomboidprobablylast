package com.example.zomboidmod.world;

import com.example.zomboidmod.ZombieOutfit;
import com.example.zomboidmod.block.BuildingBlocks;
import com.example.zomboidmod.block.DecalBlock;
import com.example.zomboidmod.block.ZomboidBlocks;
import com.example.zomboidmod.vehicle.VehicleType;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.enums.SlabType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Мегаполисы больше 1000 блоков (как Луисвилл в PZ): по одному на квадрат 2048×2048, первый — рядом со спавном.
 * Сетка проспектов и улиц, бульвар через центр, деловой центр с небоскрёбами, торговые кварталы, жилые районы
 * с таунхаусами и домами, промзона, парки. По периметру — военное ограждение с КПП на въездах.
 * Город огромный, поэтому строится кварталами 64×64 по мере приближения игрока.
 */
final class Metro {
    private Metro() {
    }

    static final int SR = 2048, TILE = 64, EDGE = 16;
    private static final String[] NAMES = {"Ривертон", "Харпер-Сити", "Нью-Эшфорд", "Кингстон-Фоллс", "Лейквью", "Форт-Хейвен", "Блэкуотер",
            "Маунт-Холли", "Гранд-Бэй", "Сильвер-Спрингс", "Норт-Колумбия", "Айронвуд", "Брэдфорд-Сити", "Уэст-Мерсер"};

    record City(long key, String name, int x0, int z0, int K, int L, int base, long seed) {
        int w() {
            return EDGE * 2 + TILE * K;
        }

        int d() {
            return EDGE * 2 + TILE * L;
        }

        int cx() {
            return x0 + w() / 2;
        }

        int cz() {
            return z0 + d() / 2;
        }
    }

    private static final Map<Long, Optional<City>> CACHE = new HashMap<>();
    private static long cacheSeed = Long.MIN_VALUE;

    /** Мегаполис квадрата (srx, srz) или null. Место выбирается по рельефу: ровнее и суше. */
    static synchronized City of(long seed, int srx, int srz) {
        if (seed != cacheSeed) {
            CACHE.clear();
            cacheSeed = seed;
        }
        long k = ((long) srx << 32) ^ (srz & 0xffffffffL);
        Optional<City> o = CACHE.get(k);
        if (o != null) return o.orElse(null);
        ServerWorld w = Knox.world;
        if (w == null) return null;
        java.util.Random r = new java.util.Random(seed * 0x5DEECE66DL + srx * 341873128712L + srz * 132897987541L + 4242);
        boolean home = srx == 0 && srz == 0;
        City c = null;
        if (home || r.nextFloat() < 0.8f) {
            int K = home ? 16 : 16 + 2 * r.nextInt(3), L = home ? 16 : 16 + 2 * r.nextInt(3);
            int cw = EDGE * 2 + TILE * K, cd = EDGE * 2 + TILE * L;
            int bx = srx * SR, bz = srz * SR;
            int spanX = Math.max(0, (SR - 512 - cw) / 64), spanZ = Math.max(0, (SR - 512 - cd) / 64);
            int best = Integer.MAX_VALUE, bx0 = 0, bz0 = 0, bBase = 64, bWet = 100;
            for (int t = 0; t < 5; t++) {
                int x0 = bx + 256 + 64 * r.nextInt(spanX + 1), z0 = bz + 256 + 64 * r.nextInt(spanZ + 1);
                if (home && x0 < 576 && z0 < 576) {   // не налезать на стартовый город
                    if (r.nextBoolean()) x0 = bx + 576;
                    else z0 = bz + 576;
                }
                int[] sv = Terrain.survey(w, x0, z0, x0 + cw, z0 + cd, 6);
                int score = sv[1] * 4 + sv[2];
                if (score < best) {
                    best = score;
                    bx0 = x0;
                    bz0 = z0;
                    bBase = sv[0];
                    bWet = sv[1];
                }
            }
            if (home || bWet <= 45) {
                long key = 0x4D45000000000000L | ((long) (srx & 0xFFFFFF) << 24) | (srz & 0xFFFFFF);
                c = new City(key, NAMES[Math.floorMod((int) (seed ^ (srx * 31L + srz * 17L)), NAMES.length)], bx0, bz0, K, L,
                        Math.max(w.getSeaLevel() + 1, bBase), r.nextLong());
            }
        }
        CACHE.put(k, Optional.ofNullable(c));
        return c;
    }

    /** Регион принадлежит мегаполису, если его центр не дальше 300 блоков от города. */
    static City forRegion(long seed, int rx, int rz) {
        int rcx = rx * Knox.REGION + Knox.REGION / 2, rcz = rz * Knox.REGION + Knox.REGION / 2;
        City c = of(seed, Math.floorDiv(rcx, SR), Math.floorDiv(rcz, SR));
        if (c == null) return null;
        int dx = Math.max(Math.max(c.x0() - rcx, 0), rcx - (c.x0() + c.w() - 1));
        int dz = Math.max(Math.max(c.z0() - rcz, 0), rcz - (c.z0() + c.d() - 1));
        return Math.max(dx, dz) <= 300 ? c : null;
    }

    static Knox.Settlement settlement(City c) {
        List<int[]> rects = new ArrayList<>();
        rects.add(new int[]{c.x0(), c.z0(), c.x0() + c.w() - 1, c.z0() + c.d() - 1});
        return new Knox.Settlement(c.key(), Math.floorDiv(c.cx(), Knox.REGION), Math.floorDiv(c.cz(), Knox.REGION), Knox.Type.METRO, c.name(),
                c.cx(), c.cz(), rects, c.seed(), c.w());
    }

    // =====================================================================================
    //                                    сетка улиц
    // =====================================================================================

    static final byte ROAD = 1, WALK = 2, LOT = 3, BORDER = 4, MEDIAN = 5;

    static int half(City c, int i, boolean vertical) {
        int mid = (vertical ? c.K() : c.L()) / 2;
        if (i == mid) return 7;
        return i % 2 == 0 ? 5 : 3;
    }

    static int outer(City c, int i, boolean vertical) {
        int mid = (vertical ? c.K() : c.L()) / 2;
        return half(c, i, vertical) + (i == mid || i % 2 == 0 ? 3 : 2);
    }

    static boolean gate(City c, int i, boolean vertical) {
        int n = vertical ? c.K() : c.L();
        return i > 0 && i < n && i % 4 == 0;
    }

    /** Что в точке города (локальные координаты): проезжая часть, тротуар, участок, полоса ограждения, газон бульвара. */
    static byte classify(City c, int lx, int lz) {
        int w = c.w(), d = c.d();
        int i = Math.max(0, Math.min(c.K(), Math.round((lx - EDGE) / (float) TILE)));
        int j = Math.max(0, Math.min(c.L(), Math.round((lz - EDGE) / (float) TILE)));
        int dx = lx - (EDGE + TILE * i), dz = lz - (EDGE + TILE * j);
        int hv = half(c, i, true), hh = half(c, j, false);
        boolean roadV = Math.abs(dx) <= hv, roadH = Math.abs(dz) <= hh;
        boolean bandX = lx < 8 || lx >= w - 8, bandZ = lz < 8 || lz >= d - 8;
        if (bandX || bandZ) {
            if (bandX && !bandZ && roadH && gate(c, j, false)) return ROAD;
            if (bandZ && !bandX && roadV && gate(c, i, true)) return ROAD;
            return BORDER;
        }
        if (roadV || roadH) {
            if (roadV && !roadH && i == c.K() / 2 && Math.abs(dx) <= 1) return MEDIAN;
            if (roadH && !roadV && j == c.L() / 2 && Math.abs(dz) <= 1) return MEDIAN;
            return ROAD;
        }
        if (Math.abs(dx) <= outer(c, i, true) || Math.abs(dz) <= outer(c, j, false)) return WALK;
        return LOT;
    }

    /** Въезд для шоссе: конец ближайшего проспекта с КПП на нужной стороне. {x, z, dx, dz, прямой подъезд}. */
    static double[] entrance(City c, int side, double tx, double tz) {
        boolean ew = side == 0 || side == 2;
        int n = ew ? c.L() : c.K();
        double f = ew ? (tz - c.z0() - EDGE) / TILE : (tx - c.x0() - EDGE) / TILE;
        int bestJ = n / 2;
        double bd = Double.MAX_VALUE;
        for (int j = 4; j < n; j += 4)
            if (Math.abs(j - f) < bd) {
                bd = Math.abs(j - f);
                bestJ = j;
            }
        double line = (ew ? c.z0() : c.x0()) + EDGE + TILE * bestJ + 0.5;
        return switch (side) {
            case 0 -> new double[]{c.x0() + c.w(), line, 1, 0, 36};
            case 2 -> new double[]{c.x0(), line, -1, 0, 36};
            case 1 -> new double[]{line, c.z0() + c.d(), 0, 1, 36};
            default -> new double[]{line, c.z0(), 0, -1, 36};
        };
    }

    // =====================================================================================
    //                                     стройка кварталами
    // =====================================================================================

    static long tileKey(City c, int i, int j) {
        return c.key() * 1000003L + i * 1009L + j + 0x7111000000000000L;
    }

    /** Ставит в очередь ближайшие к игроку кварталы. */
    static void tick(ServerWorld w, ServerPlayerEntity p, City c, Knox.MapState st) {
        int pi = Math.floorDiv(p.getBlockX() - c.x0() - EDGE, TILE), pj = Math.floorDiv(p.getBlockZ() - c.z0() - EDGE, TILE);
        List<int[]> want = new ArrayList<>();
        for (int i = pi - 4; i <= pi + 4; i++)
            for (int j = pj - 4; j <= pj + 4; j++) {
                if (i < 0 || j < 0 || i >= c.K() || j >= c.L()) continue;
                double tx = c.x0() + EDGE + TILE * i + TILE / 2.0, tz = c.z0() + EDGE + TILE * j + TILE / 2.0;
                double dist = Math.hypot(tx - p.getX(), tz - p.getZ());
                if (dist > 200) continue;
                long key = tileKey(c, i, j);
                if (st.done.contains(key) || Knox.QUEUED.contains(key)) continue;
                want.add(new int[]{i, j, (int) dist});
            }
        want.sort((a, b) -> Integer.compare(a[2], b[2]));
        for (int k = 0; k < Math.min(6, want.size()); k++) {
            int[] t = want.get(k);
            Knox.QUEUED.add(tileKey(c, t[0], t[1]));
            Knox.enqueue(new TileJob(c, t[0], t[1]));
        }
    }

    static final class TileJob implements Knox.Job {
        final City c;
        final int i, j;
        boolean finished;

        TileJob(City c, int i, int j) {
            this.c = c;
            this.i = i;
            this.j = j;
        }

        public boolean done() {
            return finished;
        }

        public int run(ServerWorld w, int budget) {
            finished = true;
            int tx0 = i == 0 ? 0 : EDGE + TILE * i, tx1 = i == c.K() - 1 ? c.w() : EDGE + TILE * (i + 1);
            int tz0 = j == 0 ? 0 : EDGE + TILE * j, tz1 = j == c.L() - 1 ? c.d() : EDGE + TILE * (j + 1);
            int m = 18;
            Knox.enqueue(new Knox.FlattenJob(c.x0() + tx0, c.z0() + tz0, c.x0() + tx1 - 1, c.z0() + tz1 - 1, c.base(),
                    i == 0 ? m : 0, i == c.K() - 1 ? m : 0, j == 0 ? m : 0, j == c.L() - 1 ? m : 0));
            Random r = Random.create(c.seed() ^ tileKey(c, i, j) * 0x9E3779B97F4A7C15L);
            Plan st = new Plan(tx1 - tx0, tz1 - tz0, Random.create(r.nextLong()));
            List<Lot> lots = new ArrayList<>();
            new Gen(c, i, j, tx0, tz0, st, r, lots).generate();
            Knox.enqueue(new Knox.PlaceJob(st, c.x0() + tx0, c.base(), c.z0() + tz0, BlockRotation.NONE));
            for (Lot l : lots) Knox.enqueue(new Knox.PlaceJob(null, l.maker(), c.x0() + l.x(), c.base(), c.z0() + l.z(), l.rot()));
            final long key = tileKey(c, i, j);
            Knox.enqueue(new Knox.Job() {
                boolean f;

                public int run(ServerWorld w2, int b) {
                    Knox.MapState s = Knox.MapState.get(w2.getServer());
                    s.done.add(key);
                    s.markDirty();
                    Knox.QUEUED.remove(key);
                    f = true;
                    return 1;
                }

                public boolean done() {
                    return f;
                }
            });
            return 200;
        }
    }

    record Lot(Supplier<Plan> maker, int x, int z, BlockRotation rot) {}

    // =====================================================================================
    //                                   наполнение квартала
    // =====================================================================================

    enum District { DOWNTOWN, MIDTOWN, INNER, SUBURB, INDUSTRIAL, PARK }

    static final class Gen {
        final City c;
        final int i, j, tx0, tz0;
        final Plan st;
        final Random r;
        final List<Lot> lots;
        final boolean[][] used;
        int ax, az, bx, bz;   // участок внутри квартала (локальные координаты города, включительно)

        Gen(City c, int i, int j, int tx0, int tz0, Plan st, Random r, List<Lot> lots) {
            this.c = c;
            this.i = i;
            this.j = j;
            this.tx0 = tx0;
            this.tz0 = tz0;
            this.st = st;
            this.r = r;
            this.lots = lots;
            this.used = new boolean[st.w][st.d];
        }

        BlockState b(String id, Block fb) {
            return MetroBuildings.bb(id, fb);
        }

        /** Клетка поверхности (локальные координаты города). */
        void set(int lx, int y, int lz, BlockState s) {
            int x = lx - tx0, z = lz - tz0;
            if (x >= 0 && z >= 0 && x < st.w && z < st.d) st.set(x, y, z, s);
        }

        boolean inTile(int lx, int lz) {
            int x = lx - tx0, z = lz - tz0;
            return x >= 0 && z >= 0 && x < st.w && z < st.d;
        }

        District district() {
            double cxl = (ax + bx) / 2.0, czl = (az + bz) / 2.0;
            double nx = Math.abs(cxl - c.w() / 2.0) / (c.w() / 2.0), nz = Math.abs(czl - c.d() / 2.0) / (c.d() / 2.0);
            double dn = 0.55 * Math.max(nx, nz) + 0.45 * Math.hypot(nx, nz) / Math.sqrt(2) + (r.nextFloat() - 0.5f) * 0.08;
            int q = (int) Math.floorMod(c.seed(), 4L);
            boolean east = cxl > c.w() / 2.0, south = czl > c.d() / 2.0;
            boolean quadrant = switch (q) {
                case 0 -> east && !south;
                case 1 -> east && south;
                case 2 -> !east && south;
                default -> !east && !south;
            };
            if (i == c.K() / 2 + 1 && j == c.L() / 2 + 1) return District.PARK;   // центральный парк
            if (dn < 0.2) return District.DOWNTOWN;
            long h = (i * 73856093L) ^ (j * 19349663L) ^ c.seed();
            if (Math.floorMod(h, 100) < 6) return District.PARK;
            if (quadrant && dn > 0.55) return District.INDUSTRIAL;
            if (dn < 0.42) return District.MIDTOWN;
            if (dn < 0.62) return District.INNER;
            return District.SUBURB;
        }

        void generate() {
            ax = EDGE + TILE * i + outer(c, i, true) + 1;
            bx = EDGE + TILE * (i + 1) - outer(c, i + 1, true) - 1;
            az = EDGE + TILE * j + outer(c, j, false) + 1;
            bz = EDGE + TILE * (j + 1) - outer(c, j + 1, false) - 1;
            District d = district();
            surface(d);
            switch (d) {
                case DOWNTOWN -> downtown();
                case MIDTOWN -> midtown();
                case INNER -> inner();
                case SUBURB -> suburb();
                case INDUSTRIAL -> industrial();
                case PARK -> put(() -> {
                    Plan p = plan(bx - ax + 1, bz - az + 1);
                    MetroBuildings.cityPark(p);
                    return p;
                }, ax, az, bx - ax + 1, bz - az + 1, BlockRotation.NONE);
            }
            leftovers(d);
            streetLife(d);
        }

        Plan plan(int w, int d) {
            return new Plan(w, d, Random.create(r.nextLong()));
        }

        // ----------------------------------- размещение -----------------------------------

        /** Участок w×d плана с поворотом в точке (lx, lz) — угол следа на местности. */
        boolean put(Supplier<Plan> mk, int lx, int lz, int w, int d, BlockRotation rot) {
            boolean turn = rot == BlockRotation.CLOCKWISE_90 || rot == BlockRotation.COUNTERCLOCKWISE_90;
            int fw = turn ? d : w, fd = turn ? w : d;
            if (lx < ax || lz < az || lx + fw - 1 > bx || lz + fd - 1 > bz) return false;
            for (int x = lx; x < lx + fw; x++)
                for (int z = lz; z < lz + fd; z++) if (used[x - tx0][z - tz0]) return false;
            for (int x = lx; x < lx + fw; x++) for (int z = lz; z < lz + fd; z++) used[x - tx0][z - tz0] = true;
            final long seed = r.nextLong();
            lots.add(new Lot(() -> {
                Plan p = mk.get();
                p.r.setSeed(seed);
                return p;
            }, lx, lz, rot));
            return true;
        }

        boolean north(Supplier<Plan> mk, int lx, int w, int d) {
            return put(mk, lx, az, w, d, BlockRotation.NONE);
        }

        boolean south(Supplier<Plan> mk, int lx, int w, int d) {
            return put(mk, lx, bz - d + 1, w, d, BlockRotation.CLOCKWISE_180);
        }

        Supplier<Plan> tower(int w, int d, int floors, MetroBuildings.Use use) {
            return () -> {
                Plan p = plan(w, d);
                MetroBuildings.tower(p, floors, use);
                return p;
            };
        }

        Supplier<Plan> make(int w, int d, java.util.function.Consumer<Plan> f) {
            return () -> {
                Plan p = plan(w, d);
                f.accept(p);
                return p;
            };
        }

        /** Готовые постройки из городов поменьше (магазины, церковь, школа, больница...). */
        Supplier<Plan> classic(String kind, int w, int d) {
            return () -> {
                Plan p = plan(w, d);
                ZombieOutfit local = null;
                switch (kind) {
                    case "grocery" -> { Buildings.grocery(p); p.danger = 1; }
                    case "pharmacy" -> { Buildings.pharmacy(p); p.danger = 2; local = ZombieOutfit.NURSE; }
                    case "hardware" -> { Buildings.hardware(p); p.danger = 1; local = ZombieOutfit.CONSTRUCTION; }
                    case "diner" -> Buildings.diner(p);
                    case "bar" -> Buildings.bar(p);
                    case "office" -> { Buildings.office(p); local = ZombieOutfit.BUSINESS; }
                    case "clothes" -> Buildings.clothes(p);
                    case "bookstore" -> CityBuildings.bookstore(p);
                    case "gunstore" -> { CityBuildings.gunstore(p); p.danger = 2; local = ZombieOutfit.SECURITY; }
                    case "electronics" -> CityBuildings.electronics(p);
                    case "sports" -> CityBuildings.sports(p);
                    case "liquor" -> CityBuildings.liquor(p);
                    case "pizzeria" -> { CityBuildings.pizzeria(p); local = ZombieOutfit.CHEF; }
                    case "army" -> { CityBuildings.armySurplus(p); p.danger = 2; local = ZombieOutfit.SOLDIER; }
                    case "gas" -> Buildings.gasStation(p);
                    case "police" -> { Buildings.police(p); p.danger = 2; local = ZombieOutfit.POLICE; }
                    case "clinic" -> { Buildings.clinic(p); p.danger = 2; local = ZombieOutfit.NURSE; }
                    case "fire" -> { Buildings.fireStation(p); p.danger = 1; local = ZombieOutfit.FIREFIGHTER; }
                    case "school" -> { Buildings.school(p); local = ZombieOutfit.STUDENT; }
                    case "church" -> { Buildings.church(p); local = ZombieOutfit.PRIEST; }
                    case "warehouse" -> { Buildings.warehouse(p); p.danger = 1; }
                    case "hospital" -> { CityBuildings.hospital(p); p.danger = 3; local = ZombieOutfit.DOCTOR; }
                    case "mall" -> CityBuildings.mall(p);
                    case "library" -> CityBuildings.library(p);
                    case "autorepair" -> { CityBuildings.autoRepair(p); local = ZombieOutfit.MECHANIC; }
                    case "apartment" -> Houses.apartment(p);
                    case "house" -> Buildings.house(p);
                    case "two" -> Buildings.twoStory(p);
                    case "ranch" -> Buildings.ranch(p);
                    case "bungalow" -> Houses.bungalow(p);
                    case "colonial" -> Houses.twoFloor(p, false);
                    case "farmhouse" -> Houses.twoFloor(p, true);
                    case "motel" -> Buildings.motel(p);
                    default -> Buildings.emptyLot(p);
                }
                if (kind.equals("house") || kind.equals("two") || kind.equals("ranch") || kind.equals("bungalow") || kind.equals("colonial")
                        || kind.equals("farmhouse")) {
                    p.furn(kind.equals("ranch") ? 11 : w - 1, 1, 0, "mailbox", Direction.NORTH);
                    if (p.r.nextFloat() < 0.5f)
                        for (int z = 4; z < d - 1; z++) {
                            p.set(0, 1, z, Blocks.OAK_FENCE);
                            p.set(w - 1, 1, z, Blocks.OAK_FENCE);
                        }
                    Basements.add(p, 0.45f);
                }
                p.populate(local);
                return p;
            };
        }

        static final String[] SHOPS = {"grocery", "pharmacy", "hardware", "diner", "bar", "office", "clothes", "bookstore", "gunstore",
                "electronics", "sports", "liquor", "pizzeria", "army"};

        String shop() {
            return SHOPS[r.nextInt(SHOPS.length)];
        }

        int iw() {
            return bx - ax + 1;
        }

        int id() {
            return bz - az + 1;
        }

        // ----------------------------------- районы -----------------------------------

        void downtown() {
            float k = r.nextFloat();
            if (k < 0.4f) {
                int s = Math.max(24, Math.min(36, Math.min(iw(), id()) - 8));
                int floors = 16 + r.nextInt(15);
                put(tower(s, s, floors, MetroBuildings.Use.OFFICE), ax + (iw() - s) / 2, az + (id() - s) / 2, s, s, BlockRotation.NONE);
            } else if (k < 0.75f) {
                int w = Math.min(iw(), 30);
                north(tower(w, 22, 10 + r.nextInt(13), r.nextBoolean() ? MetroBuildings.Use.OFFICE : MetroBuildings.Use.HOTEL), ax + (iw() - w) / 2, w, 22);
                south(tower(w, 22, 8 + r.nextInt(10), MetroBuildings.Use.OFFICE), ax + (iw() - w) / 2, w, 22);
            } else {
                north(tower(25, 25, 12 + r.nextInt(9), MetroBuildings.Use.HOTEL), ax, 25, 25);
                south(make(20, 16, MetroBuildings::bank), bx - 19, 20, 16);
                if (iw() >= 47) south(classic(shop(), 25, 12), ax, 25, 12);
            }
        }

        void midtown() {
            float k = r.nextFloat();
            if (k < 0.3f) {
                // магазины на главной стороне, высотка сзади
                int x = ax;
                while (x + 25 <= bx + 1) {
                    north(classic(shop(), 25, 12), x, 25, 12);
                    x += 25;
                }
                if (x + 12 <= bx + 1) north(make(12, 12, r.nextBoolean() ? MetroBuildings::laundromat : MetroBuildings::cornerStore), x, 12, 12);
                int w = Math.min(iw(), 28);
                south(tower(w, 24, 5 + r.nextInt(5), r.nextBoolean() ? MetroBuildings.Use.APARTMENT : MetroBuildings.Use.OFFICE), ax + (iw() - w) / 2, w, 24);
            } else if (k < 0.75f) {
                int pick = r.nextInt(8);
                int w = Math.min(iw(), 44);
                switch (pick) {
                    case 0 -> north(make(w, Math.min(id(), 34), MetroBuildings::departmentStore), ax + (iw() - w) / 2, w, Math.min(id(), 34));
                    case 1 -> north(make(w, Math.min(id(), 40), MetroBuildings::supermarket), ax + (iw() - w) / 2, w, Math.min(id(), 40));
                    case 2 -> {
                        north(make(30, 26, MetroBuildings::cinema), ax, 30, 26);
                        south(make(18, 16, MetroBuildings::fastFood), bx - 17, 18, 16);
                        south(make(12, 12, MetroBuildings::laundromat), ax, 12, 12);
                    }
                    case 3 -> {
                        north(make(30, Math.min(id(), 32), MetroBuildings::precinct), ax, 30, Math.min(id(), 32));
                        south(make(16, 16, MetroBuildings::postOffice), bx - 15, 16, 16);
                    }
                    case 4 -> {
                        north(classic("hospital", 37, 25), ax + (iw() - 37) / 2, 37, 25);
                        south(make(Math.min(iw(), 30), Math.max(12, id() - 27), p -> MetroBuildings.parkingGarage(p, 2 + p.r.nextInt(2))), ax,
                                Math.min(iw(), 30), Math.max(12, id() - 27));
                    }
                    case 5 -> {
                        north(classic("mall", 37, 25), ax + (iw() - 37) / 2, 37, 25);
                        south(make(18, 16, MetroBuildings::fastFood), ax, 18, 16);
                    }
                    case 6 -> {
                        north(classic("library", 25, 25), ax, 25, 25);
                        south(classic("school", 25, 25), bx - 24, 25, 25);
                    }
                    default -> north(make(Math.min(iw(), 30), id(), p -> MetroBuildings.parkingGarage(p, 3 + p.r.nextInt(3))), ax, Math.min(iw(), 30), id());
                }
                if (pick != 6 && iw() >= 46 && r.nextBoolean()) south(classic(r.nextBoolean() ? "fire" : "clinic", 25, 25), bx - 24, 25, 25);
            } else {
                int w = Math.min(iw(), 30);
                north(tower(w, 24, 4 + r.nextInt(5), MetroBuildings.Use.APARTMENT), ax + (iw() - w) / 2, w, 24);
                if (id() >= 50) south(tower(w, 24, 4 + r.nextInt(4), MetroBuildings.Use.APARTMENT), ax + (iw() - w) / 2, w, 24);
                else south(classic(shop(), 25, 12), ax, 25, 12);
            }
        }

        void inner() {
            float k = r.nextFloat();
            if (k < 0.55f) {
                int units = Math.min(iw() / 6, 8);
                int w = units * 6;
                north(make(w, 15, MetroBuildings::townhouses), ax + (iw() - w) / 2, w, 15);
                if (r.nextFloat() < 0.3f) {
                    south(make(12, 12, MetroBuildings::cornerStore), ax, 12, 12);
                    south(make(12, 12, MetroBuildings::laundromat), ax + 13, 12, 12);
                    int w2 = ((iw() - 26) / 6) * 6;
                    if (w2 >= 12) south(make(w2, 15, MetroBuildings::townhouses), ax + 26, w2, 15);
                } else south(make(w, 15, MetroBuildings::townhouses), ax + (iw() - w) / 2, w, 15);
            } else if (k < 0.8f) {
                north(classic("apartment", 25, 20), ax, 25, 20);
                if (iw() >= 50) north(classic("apartment", 25, 20), ax + 25, 25, 20);
                south(make(12, 12, MetroBuildings::cornerStore), bx - 11, 12, 12);
                south(classic(r.nextBoolean() ? "church" : "school", 25, 25), ax, 25, 25);
            } else {
                int w = Math.min(iw(), 30);
                north(tower(w, 24, 3 + r.nextInt(4), MetroBuildings.Use.APARTMENT), ax + (iw() - w) / 2, w, 24);
                south(make(Math.min(iw(), 40), Math.min(22, id() - 26), MetroBuildings::plaza), ax, Math.min(iw(), 40), Math.min(22, id() - 26));
            }
        }

        void suburb() {
            String[] kinds = {"house", "two", "ranch", "bungalow", "colonial", "farmhouse"};
            int[][] size = {{12, 12}, {12, 12}, {18, 12}, {16, 16}, {20, 16}, {20, 18}};
            for (int side = 0; side < 2; side++) {
                int x = ax;
                boolean special = r.nextFloat() < 0.12f;
                while (x < bx - 10) {
                    if (special) {
                        special = false;
                        String s = r.nextFloat() < 0.4f ? "gas" : (r.nextBoolean() ? "church" : "school");
                        int w = 25, d = s.equals("gas") ? 12 : 25;
                        if (x + w - 1 <= bx && (side == 0 ? north(classic(s, w, d), x, w, d) : south(classic(s, w, d), x, w, d))) {
                            x += w + 1;
                            continue;
                        }
                    }
                    int k = r.nextInt(kinds.length);
                    int w = size[k][0], d = size[k][1], set = 2 + r.nextInt(3);
                    if (x + w - 1 > bx) {
                        k = 0;
                        w = 12;
                        d = 12;
                    }
                    if (x + w - 1 > bx) break;
                    boolean ok = side == 0 ? put(classic(kinds[k], w, d), x, az + set, w, d, BlockRotation.NONE)
                            : put(classic(kinds[k], w, d), x, bz - set - d + 1, w, d, BlockRotation.CLOCKWISE_180);
                    if (ok) {   // дорожка к тротуару и подъездная дорожка
                        int door = x + (kinds[k].equals("ranch") ? 5 : kinds[k].equals("colonial") || kinds[k].equals("farmhouse") ? 7 : 5);
                        if (side == 1) door = x + w - 1 - (door - x);
                        for (int s2 = 0; s2 < set; s2++) set(door, 0, side == 0 ? az + s2 : bz - s2, Blocks.DIRT_PATH.getDefaultState());
                        for (int s2 = 0; s2 < set; s2++) {
                            used[Math.min(st.w - 1, door - tx0)][Math.min(st.d - 1, (side == 0 ? az + s2 : bz - s2) - tz0)] = true;
                        }
                    }
                    x += w + 1 + r.nextInt(2);
                }
            }
        }

        void industrial() {
            float k = r.nextFloat();
            if (k < 0.3f && iw() >= 46) {
                int w = Math.min(iw(), 48), d = Math.min(id(), 44);
                north(make(w, d, MetroBuildings::factory), ax + (iw() - w) / 2, w, d);
            } else if (k < 0.6f) {
                int w = Math.min(iw() - 13, 36), d = Math.min(id(), 32);
                north(make(w, d, MetroBuildings::bigWarehouse), ax, w, d);
                south(make(12, 12, MetroBuildings::waterTower), bx - 11, 12, 12);
            } else if (k < 0.8f) {
                north(classic("warehouse", 25, 25), ax, 25, 25);
                south(classic(r.nextBoolean() ? "autorepair" : "warehouse", 25, 25), bx - 24, 25, 25);
            } else {
                int s = Math.min(Math.min(iw(), id()), 34);
                north(make(s, s, MetroBuildings::constructionSite), ax + (iw() - s) / 2, s, s);
            }
        }

        // ----------------------------------- поверхность -----------------------------------

        /** Улицы, тротуары, разметка, переходы, ограждение по периметру. */
        void surface(District dist) {
            BlockState asphalt = b("asphalt", Blocks.BLACK_CONCRETE), cracked = b("asphalt_cracked", Blocks.BLACK_CONCRETE);
            BlockState yellow = b("road_line_yellow", Blocks.YELLOW_CONCRETE), white = b("road_line_white", Blocks.WHITE_CONCRETE);
            BlockState walk = b("sidewalk", Blocks.SMOOTH_STONE);
            BlockState walkSlab = MetroBuildings.slabOf("sidewalk", Blocks.SMOOTH_STONE_SLAB, false);
            for (int x = 0; x < st.w; x++)
                for (int z = 0; z < st.d; z++) {
                    int lx = tx0 + x, lz = tz0 + z;
                    byte k = classify(c, lx, lz);
                    int vi = Math.max(0, Math.min(c.K(), Math.round((lx - EDGE) / (float) TILE)));
                    int hj = Math.max(0, Math.min(c.L(), Math.round((lz - EDGE) / (float) TILE)));
                    int dx = lx - (EDGE + TILE * vi), dz = lz - (EDGE + TILE * hj);
                    int hv = half(c, vi, true), hh = half(c, hj, false);
                    switch (k) {
                        case ROAD -> {
                            boolean v = Math.abs(dx) <= hv, h = Math.abs(dz) <= hh;
                            BlockState s = r.nextFloat() < 0.05f ? cracked : asphalt;
                            if (v && !h) {
                                int adx = Math.abs(dx);
                                boolean onCross = Math.abs(dz) <= outer(c, hj, false);   // переход через поперечный тротуар
                                if (onCross && adx % 2 == 0) s = white;
                                else if (!onCross) {
                                    if (dx == 0 && hv <= 5) s = hv == 5 ? yellow : (Math.floorMod(lz, 6) < 3 ? yellow : s);
                                    else if (hv >= 5 && adx == hv - 2 && Math.floorMod(lz, 6) < 3) s = white;
                                }
                            } else if (h && !v) {
                                int adz = Math.abs(dz);
                                boolean onCross = Math.abs(dx) <= outer(c, vi, true);
                                if (onCross && adz % 2 == 0) s = white;
                                else if (!onCross) {
                                    if (dz == 0 && hh <= 5) s = hh == 5 ? yellow : (Math.floorMod(lx, 6) < 3 ? yellow : s);
                                    else if (hh >= 5 && adz == hh - 2 && Math.floorMod(lx, 6) < 3) s = white;
                                }
                            }
                            st.set(x, 0, z, s);
                        }
                        case MEDIAN -> {
                            st.set(x, 0, z, Blocks.GRASS_BLOCK.getDefaultState());
                            boolean edge = (Math.abs(dx) == 1 && Math.abs(dz) > hh) || (Math.abs(dz) == 1 && Math.abs(dx) > hv);
                            if (edge) st.set(x, 1, z, Blocks.SMOOTH_STONE_SLAB.getDefaultState());
                            else if (Math.floorMod(lx + lz, 9) == 0 && (dx == 0 || dz == 0)) st.tree(x, 0, z, r.nextInt(3));
                        }
                        case WALK -> {
                            st.set(x, 0, z, walk);
                            st.set(x, 1, z, walkSlab);
                        }
                        case BORDER -> border(x, z, lx, lz);
                        default -> {
                        }
                    }
                }
        }

        /** Полоса ограждения: забор из сетки на бетонных столбах, на въездах — КПП. */
        void border(int x, int z, int lx, int lz) {
            int w = c.w(), d = c.d();
            int ex = Math.min(lx, w - 1 - lx), ez = Math.min(lz, d - 1 - lz);
            int e = Math.min(ex, ez);
            st.set(x, 0, z, Blocks.GRASS_BLOCK.getDefaultState());
            if (e != 3) return;
            int along = ex == 3 ? lz : lx;
            // у въезда (проезд по проспекту) — ворота КПП
            boolean nearGate = false;
            for (int g = 4; g < (ex == 3 ? c.L() : c.K()); g += 4) {
                int line = EDGE + TILE * g;
                if (Math.abs(along - line) <= 9) nearGate = true;
            }
            BlockState post = MetroBuildings.bb("concrete_dark", Blocks.GRAY_CONCRETE);
            if (nearGate) {
                st.furn(x, 1, z, "sandbags", ex == 3 ? Direction.EAST : Direction.SOUTH);
                return;
            }
            boolean isPost = Math.floorMod(along, 6) == 0;
            for (int y = 1; y <= 3; y++) st.set(x, y, z, isPost ? post : Blocks.IRON_BARS.getDefaultState());
            if (isPost) st.set(x, 4, z, Blocks.IRON_BARS.getDefaultState());
        }

        /** Свободные клетки участков: в центре — мощение и кадки, в жилых — газон, в промзоне — гравий. */
        void leftovers(District d) {
            for (int lx = ax; lx <= bx; lx++)
                for (int lz = az; lz <= bz; lz++) {
                    if (!inTile(lx, lz) || used[lx - tx0][lz - tz0]) continue;
                    switch (d) {
                        case DOWNTOWN, MIDTOWN -> {
                            set(lx, 0, lz, b("sidewalk", Blocks.SMOOTH_STONE));
                            if (Math.floorMod(lx * 7 + lz * 13, 61) == 0) {
                                set(lx, 0, lz, Blocks.GRASS_BLOCK.getDefaultState());
                                st.tree(lx - tx0, 0, lz - tz0, r.nextInt(3));
                            } else if (Math.floorMod(lx * 5 + lz * 3, 47) == 0) st.furn(lx - tx0, 1, lz - tz0, "bench", Direction.Type.HORIZONTAL.random(r));
                        }
                        case INDUSTRIAL -> set(lx, 0, lz, r.nextFloat() < 0.7f ? Blocks.GRAVEL.getDefaultState() : Blocks.COARSE_DIRT.getDefaultState());
                        default -> {
                            if (r.nextFloat() < 0.012f) {
                                boolean free = true;
                                for (int a = -2; a <= 2 && free; a++)
                                    for (int bb2 = -2; bb2 <= 2 && free; bb2++) {
                                        int qx = lx + a - tx0, qz = lz + bb2 - tz0;
                                        if (qx < 0 || qz < 0 || qx >= st.w || qz >= st.d || used[qx][qz]) free = false;
                                    }
                                if (free) st.tree(lx - tx0, 0, lz - tz0, r.nextInt(3));
                            } else if (r.nextFloat() < 0.05f) st.set(lx - tx0, 1, lz - tz0, Blocks.SHORT_GRASS.getDefaultState());
                        }
                    }
                }
        }

        /** Фонари, светофоры, гидранты, урны, машины у обочин, аварии, баррикады, мусор, кровь и зомби на улицах. */
        void streetLife(District d) {
            for (int x = 0; x < st.w; x++)
                for (int z = 0; z < st.d; z++) {
                    int lx = tx0 + x, lz = tz0 + z;
                    byte k = classify(c, lx, lz);
                    int vi = Math.max(0, Math.min(c.K(), Math.round((lx - EDGE) / (float) TILE)));
                    int hj = Math.max(0, Math.min(c.L(), Math.round((lz - EDGE) / (float) TILE)));
                    int dx = lx - (EDGE + TILE * vi), dz = lz - (EDGE + TILE * hj);
                    int hv = half(c, vi, true), hh = half(c, hj, false);
                    if (k == WALK) {
                        boolean besideV = Math.abs(dx) == hv + 1 && Math.abs(dz) > outer(c, hj, false);
                        boolean besideH = Math.abs(dz) == hh + 1 && Math.abs(dx) > outer(c, vi, true);
                        // фонари вдоль улиц
                        if (besideV && Math.floorMod(lz, 18) == 9 && (dx > 0) == (Math.floorMod(lz / 18, 2) == 0)) {
                            lamp(x, z, dx > 0 ? Direction.WEST : Direction.EAST, dx > 0 ? -1 : 1, 0);
                            continue;
                        }
                        if (besideH && Math.floorMod(lx, 18) == 9 && (dz > 0) == (Math.floorMod(lx / 18, 2) == 0)) {
                            lamp(x, z, dz > 0 ? Direction.NORTH : Direction.SOUTH, 0, dz > 0 ? -1 : 1);
                            continue;
                        }
                        // мёртвые светофоры на углах больших перекрёстков
                        if (Math.abs(dx) == hv + 1 && Math.abs(dz) == hh + 1 && hv >= 5 && hh >= 5) {
                            for (int y = 1; y <= 4; y++) st.set(x, y, z, Blocks.IRON_BARS.getDefaultState());
                            st.set(x, 5, z, Blocks.REDSTONE_LAMP.getDefaultState());
                            continue;
                        }
                        float q = r.nextFloat();
                        if ((besideV || besideH) && q < 0.012f) {
                            String id = q < 0.004f ? "hydrant" : (q < 0.008f ? "trash_can" : "bench");
                            Direction f = besideV ? (dx > 0 ? Direction.WEST : Direction.EAST) : (dz > 0 ? Direction.NORTH : Direction.SOUTH);
                            if (id.equals("trash_can")) st.furnLoot(x, 1, z, id, f, Loot.TRASH);
                            else st.furn(x, 1, z, id, f);
                        }
                    } else if (k == ROAD) {
                        boolean v = Math.abs(dx) <= hv, h = Math.abs(dz) <= hh;
                        // машины у обочины
                        if (v && !h && Math.abs(dx) == hv - 1 && Math.floorMod(lz, 8) == 3 && Math.abs(dz) > outer(c, hj, false) + 4 && r.nextFloat() < 0.16f) {
                            st.vehicle(x + 0.5, 1, z + 0.5, VehicleType.randomCivil(r).id, (dx > 0 ? 0f : 180f) + r.nextFloat() * 8f - 4f, r.nextFloat() < 0.12f);
                        } else if (h && !v && Math.abs(dz) == hh - 1 && Math.floorMod(lx, 8) == 3 && Math.abs(dx) > outer(c, vi, true) + 4 && r.nextFloat() < 0.16f) {
                            st.vehicle(x + 0.5, 1, z + 0.5, VehicleType.randomCivil(r).id, (dz > 0 ? 270f : 90f) + r.nextFloat() * 8f - 4f, r.nextFloat() < 0.12f);
                        } else if (v && h && dx == 0 && dz == 0 && r.nextFloat() < 0.18f) {   // авария на перекрёстке
                            st.vehicle(x + 0.5, 1, z + 0.5, r.nextFloat() < 0.15f ? "police" : VehicleType.randomCivil(r).id, r.nextFloat() * 360f, true);
                            st.vehicle(x + 3.5, 1, z - 1.5, VehicleType.randomCivil(r).id, r.nextFloat() * 360f, true);
                            for (int n = 0; n < 4; n++) st.set(x + r.nextInt(7) - 3, 1, z + r.nextInt(7) - 3, decal(ZomboidBlocks.BLOOD));
                        } else if (v && !h && dx == 0 && Math.floorMod(lz, 64) == 40 && r.nextFloat() < 0.12f) {   // полицейская баррикада
                            for (int o = -hv + 1; o <= hv - 1; o += 2) st.furn(x + o, 1, z, o % 4 == 0 ? "road_barrier" : "traffic_cone", Direction.NORTH);
                        } else if (r.nextFloat() < 0.004f) st.set(x, 1, z, decal(r.nextFloat() < 0.4f ? ZomboidBlocks.BLOOD : ZomboidBlocks.LITTER));
                    }
                }
            // зомби на улицах: в центре гуще и злее
            int n = switch (d) {
                case DOWNTOWN -> 9;
                case MIDTOWN -> 7;
                case INNER -> 5;
                case PARK -> 4;
                default -> 3;
            };
            n += r.nextInt(4);
            for (int k = 0; k < n; k++) {
                int x = r.nextInt(st.w), z = r.nextInt(st.d);
                byte kind = classify(c, tx0 + x, tz0 + z);
                if (kind != ROAD && kind != WALK) continue;
                int tier = d == District.DOWNTOWN ? 2 : d == District.MIDTOWN ? 1 : 0;
                int group = 1 + (r.nextFloat() < 0.35f ? r.nextInt(4) : 0);
                for (int g = 0; g < group; g++) st.zombie(Math.max(0, Math.min(st.w - 1, x + r.nextInt(3) - 1)), kind == WALK ? 2 : 1,
                        Math.max(0, Math.min(st.d - 1, z + r.nextInt(3) - 1)), null, tier);
            }
            // военные у КПП
            for (int x = 0; x < st.w; x += 7)
                for (int z = 0; z < st.d; z += 7) {
                    if (classify(c, tx0 + x, tz0 + z) == ROAD && (tx0 + x < 8 || tz0 + z < 8 || tx0 + x >= c.w() - 8 || tz0 + z >= c.d() - 8)) {
                        st.furn(x, 1, z, "road_barrier", Direction.NORTH);
                        st.zombie(x, 1, Math.min(st.d - 1, z + 2), ZombieOutfit.SOLDIER, 2);
                        if (r.nextFloat() < 0.5f) st.furnLoot(Math.min(st.w - 1, x + 1), 1, z, "army_crate", Direction.NORTH, Loot.ARMY);
                    }
                }
        }

        void lamp(int x, int z, Direction face, int ox, int oz) {
            st.set(x, 1, z, Blocks.IRON_BARS.getDefaultState());
            st.furn(x, 2, z, "street_lamp", face);
            st.set(x + ox, 3, z + oz, com.example.zomboidmod.block.PowerLampBlock.POWER_LIGHT.getDefaultState());
        }

        BlockState decal(Block b) {
            return b.getDefaultState().with(DecalBlock.VARIANT, r.nextInt(4)).with(DecalBlock.FACING, Direction.Type.HORIZONTAL.random(r));
        }
    }
}
