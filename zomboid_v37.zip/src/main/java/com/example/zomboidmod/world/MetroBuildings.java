package com.example.zomboidmod.world;

import com.example.zomboidmod.ZombieOutfit;
import com.example.zomboidmod.block.BuildingBlocks;
import com.example.zomboidmod.block.DecalBlock;
import com.example.zomboidmod.block.ZomboidBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.Direction;

/**
 * Здания мегаполиса (план: x вдоль улицы, z вглубь, улица со стороны z = -1, y = 0 — пол первого этажа).
 * Небоскрёбы с лестничной клеткой на все этажи, отели, жилые дома с пожарными лестницами, таунхаусы,
 * универмаг, супермаркет, многоярусная парковка, кинотеатр, банк с хранилищем, почта, закусочная с окном
 * для машин, прачечная, полицейское управление с камерами и оружейной, завод, большой склад, стройка с краном,
 * площадь с фонтаном, парк, водонапорная башня, магазинчик на углу с квартирой наверху.
 */
final class MetroBuildings {
    private MetroBuildings() {
    }

    static BlockState bb(String id, Block fallback) {
        Block b = BuildingBlocks.get(id);
        return (b != null ? b : fallback).getDefaultState();
    }

    static BlockState slabOf(String id, Block fallback, boolean top) {
        Block b = BuildingBlocks.get(id + "_slab");
        BlockState s = (b != null ? b : fallback).getDefaultState();
        return s.contains(SlabBlock.TYPE) ? s.with(SlabBlock.TYPE, top ? SlabType.TOP : SlabType.BOTTOM) : s;
    }

    static final BlockState AIR = Blocks.AIR.getDefaultState();

    static BlockState stair(Block b, Direction f, boolean top) {
        return b.getDefaultState().with(StairsBlock.FACING, f).with(StairsBlock.HALF, top ? BlockHalf.TOP : BlockHalf.BOTTOM);
    }

    // =====================================================================================
    //                                       детали
    // =====================================================================================

    /** Стены этажа по периметру: pattern 0 — сплошное остекление, 1 — окна через два, 2 — окна парами, 3 — витрина. */
    static void storey(Plan p, int x1, int z1, int x2, int z2, int y, int fh, BlockState wall, BlockState glass, BlockState pillar, int pattern) {
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                boolean edgeX = x == x1 || x == x2, edgeZ = z == z1 || z == z2;
                if (!edgeX && !edgeZ) continue;
                if (edgeX && edgeZ) {
                    p.fill(x, y + 1, z, x, y + fh - 1, z, pillar);
                    continue;
                }
                int k = edgeZ ? x - x1 : z - z1;
                boolean win = switch (pattern) {
                    case 0 -> k % 5 != 0;
                    case 1 -> k % 3 == 1;
                    case 2 -> k % 4 == 1 || k % 4 == 2;
                    default -> k % 6 != 0;
                };
                boolean pil = pattern == 0 ? k % 5 == 0 : (pattern == 3 && k % 6 == 0);
                for (int yy = y + 1; yy <= y + fh - 1; yy++) {
                    BlockState s;
                    if (pil) s = pillar;
                    else if (!win) s = wall;
                    else if (pattern == 0 || pattern == 3) s = yy <= y + fh - 2 ? glass : wall;
                    else s = yy == y + 2 || (fh >= 5 && yy == y + 3) ? glass : wall;
                    p.set(x, yy, z, s);
                }
            }
    }

    /**
     * Лестничная клетка 4×6 с маршами на все этажи (и на крышу): чётные этажи — вдоль +z слева, нечётные — обратно справа.
     * Двери из клетки на каждом этаже — в стене x-1.
     */
    static void stairCore(Plan p, int x, int z, int floors, int fh, Block stairs, BlockState wall, BlockState floor) {
        for (int k = 0; k < floors; k++) {
            int y = k * fh;
            // стены клетки на этаже
            for (int yy = y + 1; yy <= y + fh - 1; yy++) {
                for (int zz = z - 1; zz <= z + 6; zz++) {
                    p.set(x - 1, yy, zz, wall);
                    p.set(x + 4, yy, zz, wall);
                }
                for (int xx = x; xx <= x + 3; xx++) {
                    p.set(xx, yy, z - 1, wall);
                    p.set(xx, yy, z + 6, wall);
                }
                for (int xx = x; xx <= x + 3; xx++) for (int zz = z; zz <= z + 5; zz++) p.set(xx, yy, zz, AIR);
            }
            // проёмы к этажу
            p.set(x - 1, y + 1, z, AIR);
            p.set(x - 1, y + 2, z, AIR);
            p.set(x - 1, y + 1, z + 5, AIR);
            p.set(x - 1, y + 2, z + 5, AIR);
            boolean even = k % 2 == 0;
            int cx = even ? x : x + 2;
            for (int s = 1; s <= fh; s++) {
                int zz = even ? z + s : z + 5 - s;
                if (zz < z + 1 || zz > z + 4) {   // марш длиннее клетки — укоротим подъём на площадке
                    continue;
                }
                for (int xx = cx; xx <= cx + 1; xx++) {
                    p.set(xx, y + s, zz, stair(stairs, even ? Direction.SOUTH : Direction.NORTH, false));
                    for (int yy = y + 1; yy < y + s; yy++) p.set(xx, yy, zz, wall);
                }
            }
            // перекрытие следующего этажа: над маршем — проём
            int ny = y + fh;
            for (int xx = x; xx <= x + 3; xx++)
                for (int zz = z; zz <= z + 5; zz++) {
                    boolean hole = xx >= cx && xx <= cx + 1 && zz >= z + 1 && zz <= z + 4;
                    p.set(xx, ny, zz, hole ? AIR : floor);
                }
            // перила у проёма
            int rx = even ? x + 2 : x + 1;
            for (int zz = z + 1; zz <= z + 4; zz++) if (k + 1 < floors) p.set(rx, ny + 1, zz, Blocks.IRON_BARS.getDefaultState());
        }
    }

    /** Будка выхода на крышу над лестничной клеткой. */
    static void roofHut(Plan p, int x, int z, int y, BlockState wall) {
        for (int yy = y + 1; yy <= y + 3; yy++)
            for (int xx = x - 1; xx <= x + 4; xx++)
                for (int zz = z - 1; zz <= z + 6; zz++) {
                    boolean edge = xx == x - 1 || xx == x + 4 || zz == z - 1 || zz == z + 6;
                    if (edge) p.set(xx, yy, zz, wall);
                    else p.set(xx, yy, zz, AIR);
                }
        p.fill(x - 1, y + 4, z - 1, x + 4, y + 4, z + 6, bb("roof_tar", Blocks.GRAY_CONCRETE));
        p.door(x - 1, y + 1, z + 5, Blocks.IRON_DOOR, Direction.WEST);
        p.set(x - 2, y + 1, z + 5, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.WEST)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        p.set(x - 1, y + 2, z + 4, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.EAST)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
    }

    /** Шахта лифта 2×2 с закрытыми дверями на этажах (лифты не работают). */
    static void elevator(Plan p, int x, int z, int floors, int fh, BlockState wall) {
        for (int k = 0; k < floors; k++) {
            int y = k * fh;
            for (int yy = y; yy <= y + fh; yy++) {
                for (int xx = x - 1; xx <= x + 2; xx++) {
                    p.set(xx, yy, z - 1, wall);
                    p.set(xx, yy, z + 2, wall);
                }
                for (int zz = z; zz <= z + 1; zz++) {
                    p.set(x - 1, yy, zz, wall);
                    p.set(x + 2, yy, zz, wall);
                }
                for (int xx = x; xx <= x + 1; xx++) for (int zz = z; zz <= z + 1; zz++) p.set(xx, yy, zz, yy == 0 ? wall : AIR);
            }
            p.set(x, y + 1, z - 1, Blocks.IRON_BLOCK.getDefaultState());
            p.set(x + 1, y + 1, z - 1, Blocks.IRON_BLOCK.getDefaultState());
            p.set(x, y + 2, z - 1, Blocks.IRON_BLOCK.getDefaultState());
            p.set(x + 1, y + 2, z - 1, Blocks.IRON_BLOCK.getDefaultState());
        }
        // машинное помещение над шахтой
        int top = floors * fh;
        p.fill(x - 1, top, z - 1, x + 2, top + 2, z + 2, wall);
    }

    /** Плоская крыша: рубероид, парапет, вентиляция, кондиционеры, антенна. */
    static void roof(Plan p, int x1, int z1, int x2, int z2, int y, BlockState parapet, boolean helipad) {
        BlockState tar = bb("roof_tar", Blocks.GRAY_CONCRETE);
        p.fill(x1, y, z1, x2, y, z2, tar);
        for (int x = x1; x <= x2; x++) {
            p.set(x, y + 1, z1, parapet);
            p.set(x, y + 1, z2, parapet);
        }
        for (int z = z1; z <= z2; z++) {
            p.set(x1, y + 1, z, parapet);
            p.set(x2, y + 1, z, parapet);
        }
        int n = Math.max(1, (x2 - x1) * (z2 - z1) / 120);
        for (int k = 0; k < n; k++) {
            int x = x1 + 2 + p.r.nextInt(Math.max(1, x2 - x1 - 5)), z = z1 + 2 + p.r.nextInt(Math.max(1, z2 - z1 - 5));
            if (p.get(x, y + 1, z) != null) continue;
            if (p.r.nextBoolean()) {   // кондиционер
                p.fill(x, y + 1, z, x + 1, y + 1, z + 1, Blocks.IRON_BLOCK.getDefaultState());
                p.set(x, y + 2, z, Blocks.IRON_TRAPDOOR.getDefaultState().with(TrapdoorBlock.HALF, BlockHalf.BOTTOM));
                p.set(x + 1, y + 2, z, Blocks.IRON_TRAPDOOR.getDefaultState().with(TrapdoorBlock.HALF, BlockHalf.BOTTOM));
            } else {                   // вытяжка
                p.set(x, y + 1, z, Blocks.SMOOTH_STONE.getDefaultState());
                p.set(x, y + 2, z, Blocks.IRON_BARS.getDefaultState());
                p.set(x, y + 3, z, Blocks.SMOOTH_STONE_SLAB.getDefaultState());
            }
        }
        if (helipad && x2 - x1 >= 14 && z2 - z1 >= 14) {
            int cx = (x1 + x2) / 2, cz = (z1 + z2) / 2;
            for (int x = cx - 5; x <= cx + 5; x++)
                for (int z = cz - 5; z <= cz + 5; z++) {
                    double d = Math.hypot(x - cx, z - cz);
                    p.set(x, y, z, d > 4.4 && d < 5.4 ? Blocks.YELLOW_CONCRETE.getDefaultState() : Blocks.GRAY_CONCRETE.getDefaultState());
                }
            for (int z = cz - 2; z <= cz + 2; z++) {
                p.set(cx - 2, y, z, Blocks.WHITE_CONCRETE.getDefaultState());
                p.set(cx + 2, y, z, Blocks.WHITE_CONCRETE.getDefaultState());
            }
            for (int x = cx - 1; x <= cx + 1; x++) p.set(x, y, cz, Blocks.WHITE_CONCRETE.getDefaultState());
        } else {   // антенна
            int ax = x2 - 3, az = z1 + 3;
            for (int k = 1; k <= 7; k++) p.set(ax, y + k, az, Blocks.IRON_BARS.getDefaultState());
            p.set(ax, y + 8, az, Blocks.LIGHTNING_ROD.getDefaultState());
            p.set(ax, y + 6, az + 1, Blocks.RED_STAINED_GLASS_PANE.getDefaultState());
        }
    }

    static void lamps(Plan p, int x1, int z1, int x2, int z2, int y, int step) {
        for (int x = x1 + 2; x <= x2 - 2; x += step)
            for (int z = z1 + 2; z <= z2 - 2; z += step) if (p.get(x, y, z) == null) Houses.ceilingLamp(p, x, y, z);
    }

    static void decals(Plan p, int x1, int z1, int x2, int z2, int y, float chance) {
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                if (p.r.nextFloat() >= chance || p.get(x, y, z) != null) continue;
                Block b = p.r.nextFloat() < 0.35f ? ZomboidBlocks.BLOOD : ZomboidBlocks.LITTER;
                p.set(x, y, z, b.getDefaultState().with(DecalBlock.VARIANT, p.r.nextInt(4)).with(DecalBlock.FACING, Direction.Type.HORIZONTAL.random(p.r)));
            }
    }

    static void zombies(Plan p, int x1, int z1, int x2, int z2, int y, int n, ZombieOutfit o) {
        for (int k = 0; k < n; k++) {
            int[] c = p.freeFloor(x1, z1, x2, z2, y);
            if (c != null) p.zombie(c[0], y, c[1], p.r.nextFloat() < 0.6f ? o : null);
        }
    }

    static void plant(Plan p, int x, int y, int z) {
        p.set(x, y, z, Blocks.POTTED_FERN.getDefaultState());
    }

    static void restroom(Plan p, int x1, int z1, int x2, int z2, int y, BlockState wall, Direction doorSide) {
        for (int yy = y + 1; yy <= y + 3; yy++) {
            for (int x = x1; x <= x2; x++) {
                p.set(x, yy, z1, wall);
                p.set(x, yy, z2, wall);
            }
            for (int z = z1; z <= z2; z++) {
                p.set(x1, yy, z, wall);
                p.set(x2, yy, z, wall);
            }
        }
        p.fill(x1 + 1, y, z1 + 1, x2 - 1, y, z2 - 1, bb("tile_white", Blocks.WHITE_CONCRETE));
        int dx = doorSide == Direction.WEST ? x1 : x2;
        p.door(dx, y + 1, (z1 + z2) / 2, Blocks.BIRCH_DOOR, doorSide);
        for (int x = x1 + 1; x <= x2 - 1; x += 2) p.furn(x, y + 1, z2 - 1, "toilet", Direction.NORTH);
        p.furnLoot(x1 + 1, y + 1, z1 + 1, "bathroom_sink", Direction.SOUTH, Loot.BATHROOM);
    }

    // =====================================================================================
    //                                    высотные здания
    // =====================================================================================

    enum Use { OFFICE, HOTEL, APARTMENT }

    record Style(BlockState wall, BlockState pillar, BlockState glass, int pattern, BlockState floor, BlockState lobby, BlockState inner) {}

    static Style style(Plan p, Use use) {
        int k = p.r.nextInt(4);
        BlockState carpet = bb("office_carpet", Blocks.GRAY_WOOL), drywall = bb("drywall", Blocks.WHITE_CONCRETE);
        if (use == Use.APARTMENT) {
            BlockState w = switch (k) {
                case 0 -> bb("brick_red", Blocks.BRICKS);
                case 1 -> bb("brick_dark", Blocks.BRICKS);
                case 2 -> bb("brick_old", Blocks.BRICKS);
                default -> bb("stucco_peach", Blocks.TERRACOTTA);
            };
            return new Style(w, bb("trim_white", Blocks.SMOOTH_QUARTZ), Blocks.GLASS_PANE.getDefaultState(), 2,
                    bb("floor_hardwood", Blocks.OAK_PLANKS), bb("floor_tile", Blocks.WHITE_CONCRETE), drywall);
        }
        return switch (k) {
            case 0 -> new Style(bb("concrete_panel", Blocks.LIGHT_GRAY_CONCRETE), bb("concrete_dark", Blocks.GRAY_CONCRETE),
                    Blocks.LIGHT_BLUE_STAINED_GLASS_PANE.getDefaultState(), 0, carpet, bb("floor_marble", Blocks.QUARTZ_BLOCK), drywall);
            case 1 -> new Style(bb("concrete_dark", Blocks.GRAY_CONCRETE), Blocks.POLISHED_DEEPSLATE.getDefaultState(),
                    Blocks.GRAY_STAINED_GLASS_PANE.getDefaultState(), 0, carpet, bb("floor_marble", Blocks.QUARTZ_BLOCK), drywall);
            case 2 -> new Style(bb("stucco_white", Blocks.WHITE_CONCRETE), bb("trim_white", Blocks.SMOOTH_QUARTZ),
                    Blocks.GLASS_PANE.getDefaultState(), 2, use == Use.HOTEL ? bb("floor_carpet_beige", Blocks.BROWN_WOOL) : carpet,
                    bb("floor_marble", Blocks.QUARTZ_BLOCK), drywall);
            default -> new Style(bb("brick_tan", Blocks.SANDSTONE), Blocks.SMOOTH_SANDSTONE.getDefaultState(),
                    Blocks.GLASS_PANE.getDefaultState(), 1, use == Use.HOTEL ? bb("floor_carpet_blue", Blocks.BLUE_WOOL) : carpet,
                    bb("floor_tile", Blocks.WHITE_CONCRETE), drywall);
        };
    }

    /**
     * Многоэтажка во весь план: вестибюль, лестничная клетка и лифты на все этажи, этажи по назначению, крыша.
     * Окна кое-где выбиты, на этажах мусор, кровь и зомби.
     */
    static void tower(Plan p, int floors, Use use) {
        Style s = style(p, use);
        int fh = 4, x1 = 0, z1 = 0, x2 = p.w - 1, z2 = p.d - 1;
        int cx = p.w / 2 - 2, cz = p.d / 2 - 3;
        for (int k = 0; k <= floors; k++) p.fill(x1, k * fh, z1, x2, k * fh, z2, k == 0 ? s.lobby() : s.floor());
        for (int k = 0; k < floors; k++) {
            int y = k * fh;
            storey(p, x1, z1, x2, z2, y, fh, s.wall(), k == 0 && use != Use.APARTMENT ? Blocks.GLASS_PANE.getDefaultState() : s.glass(), s.pillar(),
                    k == 0 && use != Use.APARTMENT ? 3 : s.pattern());
            for (int x = x1 + 1; x < x2; x++) for (int z = z1 + 1; z < z2; z++) for (int yy = y + 1; yy < y + fh; yy++) p.set(x, yy, z, AIR);
        }
        roof(p, x1, z1, x2, z2, floors * fh, s.wall(), use == Use.OFFICE && p.r.nextFloat() < 0.4f);
        stairCore(p, cx, cz, floors, fh, Blocks.STONE_BRICK_STAIRS, s.inner(), s.floor());
        elevator(p, cx + 6, cz + 1, floors, fh, s.inner());
        roofHut(p, cx, cz, floors * fh, s.inner());
        // вестибюль
        int mid = p.w / 2;
        p.air(mid - 1, 1, z1, mid + 1, 2, z1);
        p.door(mid - 1, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.door(mid + 1, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.set(mid, 1, z1, Blocks.GLASS_PANE.getDefaultState());
        p.set(mid, 2, z1, Blocks.GLASS_PANE.getDefaultState());
        lobby(p, s, use, floors);
        // этажи
        for (int k = 1; k < floors; k++) {
            int y = k * fh;
            switch (use) {
                case OFFICE -> officeFloor(p, s, y, cx, cz);
                case HOTEL -> hotelFloor(p, s, y, cx, cz);
                case APARTMENT -> apartmentFloor(p, s, y, cx, cz);
            }
            lamps(p, x1 + 1, z1 + 1, x2 - 1, z2 - 1, y + fh - 1, 6);
            decals(p, x1 + 1, z1 + 1, x2 - 1, z2 - 1, y + 1, 0.012f);
            if (p.r.nextFloat() < 0.45f) zombies(p, x1 + 1, z1 + 1, x2 - 1, z2 - 1, y + 1, 1 + p.r.nextInt(2),
                    use == Use.OFFICE ? ZombieOutfit.BUSINESS : null);
            // выбитые окна
            for (int n = 0; n < 3; n++) {
                int wx = x1 + 1 + p.r.nextInt(Math.max(1, x2 - x1 - 1));
                BlockState g = p.get(wx, y + 2, z1);
                if (g != null && g.getBlock() instanceof net.minecraft.block.PaneBlock && p.r.nextFloat() < 0.4f) p.set(wx, y + 2, z1, AIR);
            }
        }
        p.danger = use == Use.OFFICE ? 1 : 0;
    }

    private static void lobby(Plan p, Style s, Use use, int floors) {
        int x2 = p.w - 1, z2 = p.d - 1, mid = p.w / 2;
        // стойка ресепшн
        for (int x = mid - 3; x <= mid + 3; x++) p.set(x, 1, 6, Blocks.DARK_OAK_PLANKS.getDefaultState());
        p.furnLoot(mid, 1, 7, "desk", Direction.NORTH, Loot.OFFICE);
        p.furn(mid - 2, 1, 7, "chair", Direction.NORTH);
        for (int x : new int[]{2, x2 - 2}) {
            p.furn(x, 1, 3, "sofa", Direction.SOUTH);
            plant(p, x, 1, 1);
        }
        plant(p, 1, 1, z2 - 1);
        plant(p, x2 - 1, 1, z2 - 1);
        if (use == Use.HOTEL) {   // ресторан при отеле
            for (int x = 3; x < x2 - 2; x += 4) {
                if (p.get(x, 1, z2 - 4) != null) continue;
                p.table(x, 1, z2 - 4);
                p.furn(x - 1, 1, z2 - 4, "chair", Direction.EAST);
                p.furn(x + 1, 1, z2 - 4, "chair", Direction.WEST);
            }
            p.furnLoot(x2 - 2, 1, z2 - 1, "fridge", Direction.WEST, Loot.FRIDGE);
            p.furnLoot(x2 - 3, 1, z2 - 1, "stove", Direction.NORTH, Loot.KITCHEN);
        } else if (use == Use.APARTMENT) {
            for (int x = 2; x <= 8 && x < x2; x += 1) p.loot(x, 1, z2 - 1, Blocks.BARREL.getDefaultState(), Loot.TRASH);   // почтовые ящики
        }
        lamps(p, 1, 1, x2 - 1, z2 - 1, 3, 5);
        decals(p, 1, 1, x2 - 1, z2 - 1, 1, 0.02f);
        zombies(p, 1, 1, x2 - 1, z2 - 1, 1, 1 + p.r.nextInt(3), use == Use.OFFICE ? ZombieOutfit.SECURITY : null);
    }

    private static boolean freeCell(Plan p, int x, int y, int z) {
        BlockState a = p.get(x, y, z);
        return a == null || a.isAir();
    }

    /** Офисный этаж: столы рядами, перегородки, переговорная, кухня, туалет. */
    private static void officeFloor(Plan p, Style s, int y, int cx, int cz) {
        int x2 = p.w - 1, z2 = p.d - 1;
        BlockState part = Blocks.LIGHT_GRAY_STAINED_GLASS_PANE.getDefaultState();
        restroom(p, 1, 1, 5, 5, y, s.inner(), Direction.EAST);
        // кухня
        p.furnLoot(x2 - 1, y + 1, 1, "fridge", Direction.WEST, Loot.FRIDGE);
        p.furnLoot(x2 - 2, y + 1, 1, "kitchen_counter", Direction.SOUTH, Loot.KITCHEN);
        p.furnLoot(x2 - 3, y + 1, 1, "kitchen_sink", Direction.SOUTH, Loot.KITCHEN);
        // переговорная у дальней стены
        int mx = 2, mz = z2 - 6;
        for (int x = mx; x <= mx + 7 && x < x2; x++) for (int yy = y + 1; yy <= y + 3; yy++) p.set(x, yy, mz, yy == y + 2 ? part : s.inner());
        p.set(mx + 3, y + 1, mz, AIR);
        p.set(mx + 3, y + 2, mz, AIR);
        for (int x = mx + 2; x <= mx + 5 && x < x2; x++) p.table(x, y + 1, mz + 3);
        // ряды столов
        for (int z = 8; z < z2 - 7; z += 4)
            for (int x = 2; x < x2 - 2; x += 3) {
                if (!freeCell(p, x, y + 1, z) || !freeCell(p, x, y + 1, z + 1)) continue;
                if (x >= cx - 2 && x <= cx + 9 && z >= cz - 2 && z <= cz + 8) continue;
                if (p.r.nextFloat() < 0.85f) p.furnLoot(x, y + 1, z, "desk", Direction.SOUTH, Loot.OFFICE);
                if (p.r.nextFloat() < 0.8f) p.furn(x, y + 1, z + 1, "chair", Direction.NORTH);
                if (freeCell(p, x + 1, y + 1, z)) p.set(x + 1, y + 1, z, part);
            }
        if (p.r.nextFloat() < 0.5f) p.furn(x2 - 2, y + 1, z2 - 2, "floor_lamp", Direction.NORTH);
        if (p.r.nextFloat() < 0.3f) p.loot(x2 - 1, y + 1, z2 - 1, Blocks.BARREL.getDefaultState(), Loot.OFFICE);
    }

    /** Этаж отеля: коридор по центру, номера по обе стороны (кровать, тумбочка, санузел). */
    private static void hotelFloor(Plan p, Style s, int y, int cx, int cz) {
        int x2 = p.w - 1, z2 = p.d - 1;
        int cor1 = cz - 2, cor2 = cz + 7;   // коридор обходит ядро
        rooms(p, s, y, 1, cor1 - 1, x2, true, cx);
        rooms(p, s, y, cor2 + 1, z2 - 1, x2, false, cx);
    }

    /** Ряд комнат между z1 и z2 (номера отеля или квартиры), двери в коридор. */
    private static void rooms(Plan p, Style s, int y, int z1, int z2, int x2, boolean north, int cx) {
        if (z2 - z1 < 4) return;
        int width = 6;
        for (int x = 1; x + width - 1 < x2; x += width) {
            int rx2 = Math.min(x2 - 1, x + width - 1);
            for (int yy = y + 1; yy <= y + 3; yy++) {
                for (int zz = z1; zz <= z2; zz++) p.set(rx2, yy, zz, s.inner());
                for (int xx = x; xx <= rx2; xx++) p.set(xx, yy, north ? z2 : z1, s.inner());
            }
            int dz = north ? z2 : z1;
            int dx = x + 1;
            p.door(dx, y + 1, dz, Blocks.SPRUCE_DOOR, north ? Direction.SOUTH : Direction.NORTH);
            int bz = north ? z1 + 1 : z2 - 2;
            p.bed(x + 3, y + 1, bz, Blocks.WHITE_BED, north ? Direction.NORTH : Direction.SOUTH);
            p.furnLoot(x + 4, y + 1, bz, "nightstand", north ? Direction.SOUTH : Direction.NORTH, Loot.BEDROOM);
            int tz = north ? z2 - 1 : z1 + 1;
            if (freeCell(p, x + 4, y + 1, tz)) p.furnLoot(x + 4, y + 1, tz, "bathroom_sink", Direction.WEST, Loot.BATHROOM);
            if (p.r.nextFloat() < 0.6f) p.furn(x, y + 1, north ? z1 + 1 : z2 - 1, "tv", north ? Direction.SOUTH : Direction.NORTH);
            if (p.r.nextFloat() < 0.3f) p.zombie(x + 2, y + 1, (z1 + z2) / 2, null);
        }
    }

    /** Этаж жилого дома: квартиры с кухней, гостиной, спальней и ванной вдоль коридора. */
    private static void apartmentFloor(Plan p, Style s, int y, int cx, int cz) {
        int x2 = p.w - 1, z2 = p.d - 1;
        int cor1 = cz - 2, cor2 = cz + 7;
        for (boolean north : new boolean[]{true, false}) {
            int z1 = north ? 1 : cor2 + 1, zz2 = north ? cor1 - 1 : z2 - 1;
            if (zz2 - z1 < 4) continue;
            for (int x = 1; x + 7 < x2; x += 8) {
                int rx2 = x + 7;
                for (int yy = y + 1; yy <= y + 3; yy++) {
                    for (int zz = z1; zz <= zz2; zz++) p.set(rx2, yy, zz, s.inner());
                    for (int xx = x; xx <= rx2; xx++) p.set(xx, yy, north ? zz2 : z1, s.inner());
                }
                p.door(x + 1, y + 1, north ? zz2 : z1, Blocks.OAK_DOOR, north ? Direction.SOUTH : Direction.NORTH);
                int back = north ? z1 : zz2, step = north ? 1 : -1;
                p.furnLoot(x + 1, y + 1, back, "fridge", north ? Direction.SOUTH : Direction.NORTH, Loot.FRIDGE);
                p.furnLoot(x + 2, y + 1, back, "stove", north ? Direction.SOUTH : Direction.NORTH, Loot.KITCHEN);
                p.furnLoot(x + 3, y + 1, back, "kitchen_counter", north ? Direction.SOUTH : Direction.NORTH, Loot.KITCHEN);
                p.furn(x + 5, y + 1, back + step, "sofa", north ? Direction.SOUTH : Direction.NORTH);
                p.furn(x + 5, y + 1, back + 3 * step, "tv", north ? Direction.NORTH : Direction.SOUTH);
                if (Math.abs(zz2 - z1) >= 5) p.bed(x + 6, y + 1, back + step, Houses.bed(p.r), north ? Direction.NORTH : Direction.SOUTH);
                p.furnLoot(x + 4, y + 1, back, "wardrobe", north ? Direction.SOUTH : Direction.NORTH, Loot.BEDROOM);
                if (p.r.nextFloat() < 0.5f) p.loot(x + 3, y + 1, back + 2 * step, Blocks.CHEST.getDefaultState(), Loot.LIVING);
                if (p.r.nextFloat() < 0.35f) p.zombie(x + 3, y + 1, back + 2 * step, null);
            }
        }
        fireEscape(p, y);
    }

    /** Пожарная лестница на фасаде: площадка на этаже, дверь к ней, лестница вниз до соседней площадки. */
    private static void fireEscape(Plan p, int y) {
        int x1 = 2, x2 = 7;
        if (p.w < 12 || y < 4) return;
        for (int x = x1; x <= x2; x++) {
            p.set(x, y, -1, Blocks.IRON_TRAPDOOR.getDefaultState().with(TrapdoorBlock.HALF, BlockHalf.TOP));
            p.set(x, y + 1, -2, Blocks.IRON_BARS.getDefaultState());
        }
        p.set(x1 - 1, y + 1, -1, Blocks.IRON_BARS.getDefaultState());
        p.set(x2 + 1, y + 1, -1, Blocks.IRON_BARS.getDefaultState());
        p.door(4, y + 1, 0, Blocks.SPRUCE_DOOR, Direction.NORTH);
        for (int yy = y - 3; yy <= y; yy++) p.set(x2, yy, -1, Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.NORTH));
        p.set(x2, y, -1, Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.NORTH));
    }

    // =====================================================================================
    //                                      таунхаусы и лавки
    // =====================================================================================

    /** Ряд узких трёхэтажных домов (каждый 6 в ширину): крыльцо, гостиная и кухня, спальни наверху. */
    static void townhouses(Plan p) {
        int units = Math.max(1, p.w / 6), fh = 4, depth = Math.min(p.d - 2, 13);
        String[] walls = {"brick_red", "brick_dark", "brick_white", "stucco_peach", "brick_old"};
        for (int u = 0; u < units; u++) {
            int x1 = u * 6, x2 = x1 + 5, z1 = 2, z2 = z1 + depth - 1;
            BlockState wall = bb(walls[p.r.nextInt(walls.length)], Blocks.BRICKS), trim = bb("trim_white", Blocks.SMOOTH_QUARTZ);
            int floors = 2 + p.r.nextInt(2);
            for (int k = 0; k <= floors; k++) p.fill(x1, k * fh, z1, x2, k * fh, z2, k == 0 ? bb("floor_hardwood_dark", Blocks.DARK_OAK_PLANKS) : bb("floor_hardwood", Blocks.OAK_PLANKS));
            for (int k = 0; k < floors; k++) {
                storey(p, x1, z1, x2, z2, k * fh, fh, wall, Blocks.GLASS_PANE.getDefaultState(), wall, 1);
                for (int x = x1 + 1; x < x2; x++) for (int z = z1 + 1; z < z2; z++) for (int yy = k * fh + 1; yy < k * fh + fh; yy++) p.set(x, yy, z, AIR);
                for (int x = x1; x <= x2; x++) p.set(x, k * fh + fh - 1, z1, trim);   // карниз над окнами
            }
            // крыльцо со ступенями
            p.set(x1 + 2, 0, 1, Blocks.STONE_BRICKS.getDefaultState());
            p.set(x1 + 2, 1, 1, stair(Blocks.STONE_BRICK_STAIRS, Direction.SOUTH, false));
            p.set(x1 + 2, 0, 0, stair(Blocks.STONE_BRICK_STAIRS, Direction.SOUTH, false));
            p.door(x1 + 2, 1, z1, Blocks.DARK_OAK_DOOR, Direction.NORTH);
            p.set(x1 + 1, 1, 1, Blocks.IRON_BARS.getDefaultState());
            p.set(x1 + 3, 1, 1, Blocks.IRON_BARS.getDefaultState());
            // лестница вдоль стены
            Houses.staircase(p, x2 - 1, 0, z1 + 3, fh - 1, Direction.SOUTH, Blocks.OAK_STAIRS);
            if (floors > 2) Houses.staircase(p, x1 + 1, fh, z1 + 3, fh - 1, Direction.SOUTH, Blocks.OAK_STAIRS);
            // первый этаж: гостиная спереди, кухня сзади
            p.furn(x1 + 1, 1, z1 + 2, "sofa", Direction.EAST);
            p.furn(x1 + 3, 1, z1 + 2, "tv", Direction.WEST);
            p.furnLoot(x1 + 1, 1, z2 - 1, "fridge", Direction.EAST, Loot.FRIDGE);
            p.furnLoot(x1 + 2, 1, z2 - 1, "stove", Direction.NORTH, Loot.KITCHEN);
            p.furnLoot(x1 + 3, 1, z2 - 1, "kitchen_counter", Direction.NORTH, Loot.KITCHEN);
            p.door(x1 + 4, 1, z2, Blocks.OAK_DOOR, Direction.SOUTH);
            // второй: спальня и ванная
            int y = fh;
            p.bed(x1 + 1, y + 1, z2 - 2, Blocks.BLUE_BED, Direction.SOUTH);
            p.furnLoot(x1 + 2, y + 1, z2 - 1, "nightstand", Direction.NORTH, Loot.BEDROOM);
            p.furnLoot(x1 + 3, y + 1, z1 + 1, "wardrobe", Direction.SOUTH, Loot.BEDROOM);
            p.furn(x1 + 1, y + 1, z1 + 1, "toilet", Direction.SOUTH);
            p.furnLoot(x1 + 2, y + 1, z1 + 1, "bathroom_sink", Direction.SOUTH, Loot.BATHROOM);
            if (floors > 2) {
                y = 2 * fh;
                p.bed(x1 + 3, y + 1, z2 - 2, Blocks.LIGHT_GRAY_BED, Direction.SOUTH);
                p.furnLoot(x1 + 1, y + 1, z1 + 1, "dresser", Direction.SOUTH, Loot.BEDROOM);
                p.furn(x1 + 3, y + 1, z1 + 2, "desk", Direction.NORTH);
            }
            roof(p, x1, z1, x2, z2, floors * fh, trim, false);
            for (int k = 0; k < floors; k++) Houses.ceilingLamp(p, x1 + 2, k * fh + fh - 1, z1 + 5);
            if (p.r.nextFloat() < 0.5f) p.zombie(x1 + 2, 1, z1 + 4, null);
            if (p.r.nextFloat() < 0.25f) p.zombie(x1 + 2, fh + 1, z1 + 4, null);
            // мусорный бак у крыльца
            if (p.r.nextFloat() < 0.4f) p.furnLoot(x1 + 4, 1, 0, "trash_can", Direction.NORTH, Loot.TRASH);
        }
        p.danger = 0;
    }

    /** Магазинчик на углу, сверху — квартира хозяина. */
    static void cornerStore(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 4;
        BlockState wall = bb(p.r.nextBoolean() ? "brick_red" : "stucco_white", Blocks.BRICKS);
        for (int k = 0; k <= 2; k++) p.fill(0, k * fh, 0, x2, k * fh, z2, k == 0 ? bb("floor_linoleum", Blocks.WHITE_CONCRETE) : bb("floor_hardwood", Blocks.OAK_PLANKS));
        storey(p, 0, 0, x2, z2, 0, fh, wall, Blocks.GLASS_PANE.getDefaultState(), wall, 3);
        storey(p, 0, 0, x2, z2, fh, fh, wall, Blocks.GLASS_PANE.getDefaultState(), wall, 1);
        p.air(1, 1, 1, x2 - 1, fh - 1, z2 - 1);
        p.air(1, fh + 1, 1, x2 - 1, 2 * fh - 1, z2 - 1);
        // навес и вывеска
        for (int x = 1; x < x2; x++) p.set(x, 3, 0, (x % 2 == 0 ? Blocks.RED_CONCRETE : Blocks.WHITE_CONCRETE).getDefaultState());
        p.door(2, 1, 0, Blocks.BIRCH_DOOR, Direction.NORTH);
        for (int z = 3; z < z2 - 2; z += 3) {
            p.furnLoot(4, 1, z, "shelf_food", Direction.EAST, Loot.GROCERY);
            p.furnLoot(7, 1, z, "shelf_food", Direction.WEST, Loot.GROCERY);
        }
        p.furnLoot(x2 - 1, 1, 1, "kitchen_counter", Direction.WEST, Loot.LIQUOR);
        p.furnLoot(x2 - 1, 1, 3, "fridge", Direction.WEST, Loot.FRIDGE);
        p.furnLoot(x2 - 1, 1, 4, "fridge", Direction.WEST, Loot.FRIDGE);
        Houses.staircase(p, 1, 0, z2 - 5, fh - 1, Direction.SOUTH, Blocks.SPRUCE_STAIRS);
        p.bed(x2 - 2, fh + 1, z2 - 2, Blocks.GREEN_BED, Direction.SOUTH);
        p.furnLoot(x2 - 1, fh + 1, 1, "wardrobe", Direction.WEST, Loot.BEDROOM);
        p.furnLoot(4, fh + 1, 1, "stove", Direction.SOUTH, Loot.KITCHEN);
        p.furnLoot(5, fh + 1, 1, "fridge", Direction.SOUTH, Loot.FRIDGE);
        p.furn(6, fh + 1, 5, "sofa", Direction.NORTH);
        roof(p, 0, 0, x2, z2, 2 * fh, wall, false);
        Houses.ceilingLamp(p, p.w / 2, 3, p.d / 2);
        Houses.ceilingLamp(p, p.w / 2, fh + 3, p.d / 2);
        p.danger = 1;
        zombies(p, 1, 1, x2 - 1, z2 - 1, 1, 1 + p.r.nextInt(2), null);
    }

    /** Прачечная самообслуживания. */
    static void laundromat(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1;
        BlockState wall = bb("stucco_white", Blocks.WHITE_CONCRETE);
        p.fill(0, 0, 0, x2, 0, z2, bb("floor_linoleum", Blocks.WHITE_CONCRETE));
        storey(p, 0, 0, x2, z2, 0, 5, wall, Blocks.GLASS_PANE.getDefaultState(), wall, 3);
        p.air(1, 1, 1, x2 - 1, 4, z2 - 1);
        p.fill(0, 5, 0, x2, 5, z2, bb("roof_tar", Blocks.GRAY_CONCRETE));
        for (int x = 1; x < x2; x++) p.set(x, 4, 0, (x % 2 == 0 ? Blocks.CYAN_CONCRETE : Blocks.WHITE_CONCRETE).getDefaultState());
        p.door(p.w / 2, 1, 0, Blocks.BIRCH_DOOR, Direction.NORTH);
        for (int z = 3; z < z2; z++) {
            p.furn(1, 1, z, "washing_machine", Direction.EAST);
            p.furn(x2 - 1, 1, z, "washing_machine", Direction.WEST);
        }
        for (int z = 4; z < z2 - 1; z += 2) p.furn(p.w / 2, 1, z, "chair", Direction.EAST);
        p.furnLoot(p.w / 2 + 1, 1, z2 - 1, "kitchen_counter", Direction.NORTH, Loot.CLOTHES);
        Houses.ceilingLamp(p, p.w / 2, 4, p.d / 2);
        zombies(p, 1, 1, x2 - 1, z2 - 1, 1, p.r.nextInt(2), null);
    }

    // =====================================================================================
    //                                    торговля и сервис
    // =====================================================================================

    /** Универмаг в 3 этажа: отделы одежды, электроники, спорта, косметика, фуд-корт наверху, широкие лестницы. */
    static void departmentStore(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 5, floors = 3;
        BlockState wall = bb("concrete_panel", Blocks.LIGHT_GRAY_CONCRETE), pil = bb("concrete_dark", Blocks.GRAY_CONCRETE);
        for (int k = 0; k <= floors; k++) p.fill(0, k * fh, 0, x2, k * fh, z2, k == 0 ? bb("floor_marble", Blocks.QUARTZ_BLOCK) : bb("floor_tile", Blocks.WHITE_CONCRETE));
        for (int k = 0; k < floors; k++) {
            storey(p, 0, 0, x2, z2, k * fh, fh, wall, Blocks.GLASS_PANE.getDefaultState(), pil, k == 0 ? 3 : 1);
            p.air(1, k * fh + 1, 1, x2 - 1, k * fh + fh - 1, z2 - 1);
        }
        // вывеска на фасаде
        for (int x = 4; x <= x2 - 4; x++) p.set(x, fh * floors - 1, 0, (x % 3 == 0 ? Blocks.RED_CONCRETE : Blocks.WHITE_CONCRETE).getDefaultState());
        int mid = p.w / 2;
        for (int x = mid - 2; x <= mid + 2; x++) p.air(x, 1, 0, x, 2, 0);
        p.door(mid - 2, 1, 0, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.door(mid + 2, 1, 0, Blocks.BIRCH_DOOR, Direction.NORTH);
        // широкие лестницы-эскалаторы у задней стены
        for (int k = 0; k < floors - 1; k++) {
            int y = k * fh, ex = k % 2 == 0 ? 3 : x2 - 7;
            for (int xx = ex; xx <= ex + 2; xx++) for (int zz = z2 - 1 - fh; zz <= z2 - 2; zz++) p.set(xx, y + fh, zz, AIR);
            for (int s = 1; s <= fh; s++)
                for (int xx = ex; xx <= ex + 2; xx++) {
                    int zz = z2 - 2 - fh + s;
                    p.set(xx, y + s, zz, stair(Blocks.SMOOTH_QUARTZ_STAIRS, Direction.SOUTH, false));
                    for (int yy = y + 1; yy < y + s; yy++) p.set(xx, yy, zz, Blocks.SMOOTH_QUARTZ.getDefaultState());
                }
            for (int zz = z2 - 1 - fh; zz <= z2 - 2; zz++) {
                p.set(ex - 1, y + fh + 1, zz, Blocks.IRON_BARS.getDefaultState());
                p.set(ex + 3, y + fh + 1, zz, Blocks.IRON_BARS.getDefaultState());
            }
        }
        String[][] dept = {{"dresser", "CLOTHES"}, {"shelf_electronics", "ELECTRONICS"}, {"shelf_tools", "SPORTS"}, {"display_case", "BEDROOM"}};
        for (int k = 0; k < floors; k++) {
            int y = k * fh;
            if (k == floors - 1) {   // фуд-корт
                for (int x = 4; x < x2 - 3; x += 4)
                    for (int z = 4; z < z2 - 8; z += 4) {
                        p.table(x, y + 1, z);
                        p.furn(x - 1, y + 1, z, "chair", Direction.EAST);
                        p.furn(x + 1, y + 1, z, "chair", Direction.WEST);
                    }
                for (int x = 2; x < x2 - 1; x += 2) p.furnLoot(x, y + 1, 1, x % 4 == 0 ? "stove" : "kitchen_counter", Direction.SOUTH, Loot.DINER);
            } else {
                for (int z = 4; z < z2 - 8; z += 3)
                    for (int x = 3; x < x2 - 2; x += 5) {
                        String[] d = dept[(x / 5 + z / 3 + k) % dept.length];
                        if (p.get(x, y + 1, z) == null) p.furnLoot(x, y + 1, z, d[0], Direction.SOUTH, Loot.valueOf(d[1]));
                        if (p.get(x + 1, y + 1, z) == null) p.furnLoot(x + 1, y + 1, z, d[0], Direction.SOUTH, Loot.valueOf(d[1]));
                    }
                // кассы
                for (int x = mid - 6; x <= mid + 6; x += 4) p.furnLoot(x, y + 1, 3, "kitchen_counter", Direction.NORTH, Loot.OFFICE);
            }
            lamps(p, 1, 1, x2 - 1, z2 - 1, y + fh - 1, 5);
            decals(p, 1, 1, x2 - 1, z2 - 1, y + 1, 0.015f);
            zombies(p, 1, 1, x2 - 1, z2 - 1, y + 1, 2 + p.r.nextInt(3), null);
        }
        restroom(p, x2 - 6, 1, x2 - 1, 5, 0, bb("drywall", Blocks.WHITE_CONCRETE), Direction.WEST);
        roof(p, 0, 0, x2, z2, floors * fh, wall, false);
        p.danger = 1;
    }

    /** Супермаркет: стоянка с тележками спереди, зал с рядами полок, холодильники, кассы, склад сзади, аптечный угол. */
    static void supermarket(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, lot = 11, fh = 6;
        // стоянка
        BlockState asphalt = bb("asphalt", Blocks.BLACK_CONCRETE), line = bb("road_line_white", Blocks.WHITE_CONCRETE);
        for (int x = 0; x <= x2; x++) for (int z = 0; z < lot; z++) p.set(x, 0, z, (x % 4 == 0 && z >= 2 && z <= 5) ? line : asphalt);
        for (int x = 1; x + 2 < x2; x += 4) if (p.r.nextFloat() < 0.35f) p.vehicle(x + 2, 1, 4.0, com.example.zomboidmod.vehicle.VehicleType.randomCivil(p.r).id, 0f, p.r.nextFloat() < 0.15f);
        for (int k = 0; k < 4; k++) p.furn(2 + p.r.nextInt(x2 - 3), 1, 7 + p.r.nextInt(3), "shopping_cart", Direction.Type.HORIZONTAL.random(p.r));
        int z1 = lot;
        BlockState wall = bb("stucco_white", Blocks.WHITE_CONCRETE), pil = bb("concrete_dark", Blocks.GRAY_CONCRETE);
        p.fill(0, 0, z1, x2, 0, z2, bb("floor_linoleum", Blocks.WHITE_CONCRETE));
        storey(p, 0, z1, x2, z2, 0, fh, wall, Blocks.GLASS_PANE.getDefaultState(), pil, 1);
        for (int x = 2; x < x2 - 1; x++) for (int y = 1; y <= 3; y++) p.set(x, y, z1, x % 6 == 0 ? pil : Blocks.GLASS_PANE.getDefaultState());
        p.air(1, 1, z1 + 1, x2 - 1, fh - 1, z2 - 1);
        p.fill(0, fh, z1, x2, fh, z2, bb("roof_tar", Blocks.GRAY_CONCRETE));
        for (int x = 3; x <= x2 - 3; x++) p.set(x, fh - 1, z1, (x % 2 == 0 ? Blocks.GREEN_CONCRETE : Blocks.LIME_CONCRETE).getDefaultState());
        int mid = p.w / 2;
        p.air(mid - 1, 1, z1, mid + 1, 2, z1);
        p.door(mid - 1, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.door(mid + 1, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        // кассы
        for (int x = 3; x < x2 - 3; x += 4) {
            p.furnLoot(x, 1, z1 + 3, "kitchen_counter", Direction.NORTH, Loot.GROCERY);
            p.furn(x + 1, 1, z1 + 3, "shopping_cart", Direction.SOUTH);
        }
        // ряды полок
        int store = z2 - 6;
        for (int x = 3; x < x2 - 3; x += 3)
            for (int z = z1 + 6; z < store - 1; z++) {
                if (z == z1 + 6 + (store - z1 - 7) / 2) continue;   // поперечный проход
                p.furnLoot(x, 1, z, "shelf_food", x % 2 == 0 ? Direction.EAST : Direction.WEST, Loot.GROCERY);
            }
        // холодильники вдоль стены
        for (int z = z1 + 6; z < store - 1; z += 1) p.furnLoot(x2 - 1, 1, z, "fridge", Direction.WEST, Loot.FRIDGE);
        // аптечный угол
        for (int z = z1 + 6; z < z1 + 12; z++) p.furnLoot(1, 1, z, "shelf_meds", Direction.EAST, Loot.PHARMACY);
        // склад
        for (int x = 1; x < x2; x++) for (int y = 1; y < fh; y++) p.set(x, y, store, wall);
        p.door(mid, 1, store, Blocks.OAK_DOOR, Direction.NORTH);
        for (int x = 2; x < x2 - 1; x += 2) p.furnLoot(x, 1, z2 - 1, "cardboard_box", Direction.NORTH, Loot.WAREHOUSE);
        p.furnLoot(x2 - 2, 1, store + 2, "dumpster", Direction.WEST, Loot.TRASH);
        lamps(p, 1, z1 + 1, x2 - 1, store - 1, fh - 1, 5);
        decals(p, 1, z1 + 1, x2 - 1, z2 - 1, 1, 0.02f);
        zombies(p, 2, z1 + 2, x2 - 2, z2 - 2, 1, 4 + p.r.nextInt(4), null);
        p.danger = 1;
    }

    /** Многоярусная парковка: открытые бетонные ярусы, пандусы, машины, лестница в углу. */
    static void parkingGarage(Plan p, int levels) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 4;
        BlockState deck = bb("floor_concrete", Blocks.LIGHT_GRAY_CONCRETE), pil = bb("concrete_panel", Blocks.LIGHT_GRAY_CONCRETE);
        BlockState line = bb("road_line_yellow", Blocks.YELLOW_CONCRETE);
        for (int k = 0; k <= levels; k++) {
            int y = k * fh;
            p.fill(0, y, 0, x2, y, z2, deck);
            if (k == 0) continue;
            for (int x = 0; x <= x2; x++) {
                p.set(x, y + 1, 0, pil);
                p.set(x, y + 1, z2, pil);
            }
            for (int z = 0; z <= z2; z++) {
                p.set(0, y + 1, z, pil);
                p.set(x2, y + 1, z, pil);
            }
        }
        for (int k = 0; k < levels; k++) {
            int y = k * fh;
            // пандус вдоль x у одной из длинных сторон, ширина 4
            boolean east = k % 2 == 0;
            int rz1 = east ? z2 - 5 : 1, rz2 = rz1 + 4;
            for (int x = 0; x <= x2; x += 6)
                for (int z = 0; z <= z2; z += 8) {
                    boolean ramp = x >= 1 && x <= 3 + 2 * fh && ((z >= z2 - 6 && z <= z2) || (z >= 0 && z <= 6));
                    if (!ramp) p.fill(x, y + 1, z, x, y + fh - 1, z, pil);
                }
            for (int i = 0; i < 2 * fh; i++) {
                int x = 2 + i;
                int yy = y + i / 2;
                boolean half = i % 2 == 0;
                for (int z = rz1; z <= rz2; z++) {
                    p.set(x, yy + 1, z, half ? slabOf("concrete_panel", Blocks.SMOOTH_STONE_SLAB, false) : deck);
                    for (int c = yy + 2; c <= y + fh; c++) p.set(x, c, z, AIR);
                }
            }
            for (int z = rz1; z <= rz2; z++) p.set(2 + 2 * fh, y + fh, z, deck);
            // разметка мест и машины
            int sz1 = east ? 2 : 7, sz2 = east ? z2 - 7 : z2 - 2;
            for (int x = 14; x < x2 - 8; x += 3) {
                p.set(x, y, sz1, line);
                if (p.r.nextFloat() < 0.4f) p.vehicle(x + 1.5, y + 1, sz1 + 2.5, com.example.zomboidmod.vehicle.VehicleType.randomCivil(p.r).id, 0f,
                        p.r.nextFloat() < 0.1f);
            }
            if (p.r.nextFloat() < 0.5f) zombies(p, 2, 2, x2 - 2, z2 - 2, y + 1, 1 + p.r.nextInt(2), null);
            lamps(p, 2, 2, x2 - 2, z2 - 2, y + fh - 1, 7);
        }
        stairCore(p, x2 - 5, 1, levels, fh, Blocks.STONE_STAIRS, pil, deck);
        p.danger = 0;
    }

    /** Кинотеатр: вывеска с огнями, фойе с буфетом, два зала со ступенчатыми рядами, проекционная. */
    static void cinema(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 8;
        BlockState wall = bb("stucco_peach", Blocks.TERRACOTTA), pil = bb("brick_dark", Blocks.BRICKS);
        p.fill(0, 0, 0, x2, 0, z2, bb("floor_carpet_blue", Blocks.BLUE_WOOL));
        p.walls(0, 1, 0, x2, fh, z2, wall);
        p.air(1, 1, 1, x2 - 1, fh, z2 - 1);
        p.fill(0, fh + 1, 0, x2, fh + 1, z2, bb("roof_tar", Blocks.GRAY_CONCRETE));
        // вывеска-козырёк
        for (int x = 2; x <= x2 - 2; x++) {
            p.set(x, 5, 0, Blocks.YELLOW_CONCRETE.getDefaultState());
            p.set(x, 6, 0, x % 2 == 0 ? Blocks.SEA_LANTERN.getDefaultState() : Blocks.RED_CONCRETE.getDefaultState());
            p.set(x, 7, 0, Blocks.YELLOW_CONCRETE.getDefaultState());
        }
        for (int x = 2; x <= x2 - 2; x += 1) p.set(x, 1, 0, x % 4 == 0 ? pil : Blocks.GLASS_PANE.getDefaultState());
        int mid = p.w / 2;
        p.door(mid - 1, 1, 0, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.door(mid + 1, 1, 0, Blocks.BIRCH_DOOR, Direction.NORTH);
        // фойе 8 в глубину
        int fz = 8;
        for (int x = 1; x < x2; x++) for (int y = 1; y < fh; y++) p.set(x, y, fz, wall);
        for (int x = mid - 3; x <= mid + 3; x++) p.furnLoot(x, 1, fz - 2, x == mid ? "fridge" : "kitchen_counter", Direction.NORTH, Loot.GROCERY);
        for (int x = 2; x < x2 - 1; x += 6) p.furn(x, 1, 2, "bench", Direction.SOUTH);
        // два зала
        int split = p.w / 2;
        for (int z = fz; z < z2; z++) for (int y = 1; y < fh; y++) p.set(split, y, z, wall);
        for (int half = 0; half < 2; half++) {
            int ax = half == 0 ? 1 : split + 1, bx = half == 0 ? split - 1 : x2 - 1;
            p.door(ax + 1, 1, fz, Blocks.DARK_OAK_DOOR, Direction.NORTH);
            // экран у дальней стены
            p.fill(ax + 1, 2, z2 - 1, bx - 1, fh - 2, z2 - 1, Blocks.WHITE_CONCRETE.getDefaultState());
            // ряды: каждые 2 ряда на 1 выше, к фойе
            for (int row = 0; row < (z2 - fz - 6) / 2; row++) {
                int z = z2 - 5 - row * 2, step = row / 2;
                for (int x = ax + 1; x <= bx - 1; x++) {
                    for (int y = 1; y <= step; y++) p.set(x, y, z, Blocks.DARK_OAK_PLANKS.getDefaultState());
                    for (int y = 1; y <= step; y++) p.set(x, y, z - 1, Blocks.DARK_OAK_PLANKS.getDefaultState());
                    if (x != ax + 1) p.set(x, step + 1, z, stair(Blocks.RED_NETHER_BRICK_STAIRS, Direction.NORTH, false));
                }
            }
            zombies(p, ax, fz + 1, bx, z2 - 2, 1, 2 + p.r.nextInt(3), null);
        }
        Houses.ceilingLamp(p, mid, fh - 1, 4);
        decals(p, 1, 1, x2 - 1, fz - 1, 1, 0.03f);
        p.danger = 0;
    }

    /** Банк: колонны, мраморный зал, стойка кассиров за решёткой, хранилище с железной дверью. */
    static void bank(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 6;
        BlockState wall = bb("stucco_white", Blocks.WHITE_CONCRETE);
        p.fill(0, 0, 0, x2, 0, z2, bb("floor_marble", Blocks.QUARTZ_BLOCK));
        p.walls(0, 1, 2, x2, fh, z2, wall);
        p.air(1, 1, 3, x2 - 1, fh, z2 - 1);
        p.fill(0, fh + 1, 0, x2, fh + 1, z2, Blocks.SMOOTH_QUARTZ.getDefaultState());
        for (int x = 1; x <= x2 - 1; x += 3) p.fill(x, 1, 0, x, fh, 0, Blocks.QUARTZ_PILLAR.getDefaultState());
        p.fill(0, fh, 0, x2, fh, 1, Blocks.SMOOTH_QUARTZ.getDefaultState());
        for (int x = 2; x < x2; x += 3) p.set(x, 3, 2, Blocks.GLASS_PANE.getDefaultState());
        p.door(p.w / 2, 1, 2, Blocks.DARK_OAK_DOOR, Direction.NORTH);
        int cz = 9;
        for (int x = 1; x < x2; x++) {
            p.set(x, 1, cz, Blocks.DARK_OAK_PLANKS.getDefaultState());
            p.set(x, 2, cz, Blocks.IRON_BARS.getDefaultState());
        }
        p.set(2, 1, cz, AIR);
        p.set(2, 2, cz, AIR);
        for (int x = 3; x < x2 - 1; x += 3) p.furnLoot(x, 1, cz + 1, "desk", Direction.NORTH, Loot.OFFICE);
        // хранилище
        int vz = z2 - 5;
        for (int x = 1; x < x2; x++) for (int y = 1; y <= 4; y++) p.set(x, y, vz, Blocks.IRON_BLOCK.getDefaultState());
        p.fill(1, 5, vz, x2 - 1, 5, z2 - 1, Blocks.IRON_BLOCK.getDefaultState());
        int vx = p.w / 2;
        p.door(vx, 1, vz, Blocks.IRON_DOOR, Direction.NORTH);
        p.set(vx + 1, 2, vz - 1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        for (int x = 2; x < x2 - 1; x += 2) p.loot(x, 1, z2 - 1, Blocks.BARREL.getDefaultState(), x % 4 == 0 ? Loot.STASH : Loot.LIVING);
        p.furn(1, 1, 4, "sofa", Direction.EAST);
        plant(p, 1, 1, 3);
        plant(p, x2 - 1, 1, 3);
        Houses.ceilingLamp(p, p.w / 2, fh, 5);
        zombies(p, 1, 3, x2 - 1, vz - 1, 1, 2, ZombieOutfit.SECURITY);
        p.danger = 2;
    }

    /** Почта: окно приёма, абонентские ящики, сортировочная с посылками, флаг. */
    static void postOffice(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 5;
        BlockState wall = bb("brick_red", Blocks.BRICKS);
        p.fill(0, 0, 0, x2, 0, z2, bb("floor_tile", Blocks.WHITE_CONCRETE));
        storey(p, 0, 0, x2, z2, 0, fh, wall, Blocks.GLASS_PANE.getDefaultState(), wall, 2);
        p.air(1, 1, 1, x2 - 1, fh - 1, z2 - 1);
        p.fill(0, fh, 0, x2, fh, z2, bb("roof_tar", Blocks.GRAY_CONCRETE));
        p.door(p.w / 2, 1, 0, Blocks.SPRUCE_DOOR, Direction.NORTH);
        for (int x = 2; x < p.w / 2 - 1; x++) for (int y = 1; y <= 3; y++) p.loot(x, y, 1, Blocks.BARREL.getDefaultState(), Loot.OFFICE);
        int cz = 6;
        for (int x = 1; x < x2; x++) if (x != 2) p.set(x, 1, cz, Blocks.SPRUCE_PLANKS.getDefaultState());
        for (int z = cz + 2; z < z2; z += 2)
            for (int x = 2; x < x2 - 1; x += 3) p.furnLoot(x, 1, z, "cardboard_box", Direction.NORTH, p.r.nextBoolean() ? Loot.OFFICE : Loot.WAREHOUSE);
        // флагшток у входа
        for (int y = 1; y <= 7; y++) p.set(1, y, -2, y < 7 ? Blocks.IRON_BARS.getDefaultState() : Blocks.WHITE_BANNER.getDefaultState());
        Houses.ceilingLamp(p, p.w / 2, fh - 1, 4);
        zombies(p, 1, 1, x2 - 1, z2 - 1, 1, 1 + p.r.nextInt(2), null);
        p.danger = 0;
    }

    /** Закусочная быстрого питания: стойка, кухня, кабинки, окно выдачи для машин. */
    static void fastFood(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 5, bx2 = x2 - 4;
        BlockState wall = bb("stucco_white", Blocks.WHITE_CONCRETE);
        // полоса для машин вдоль восточной стороны
        for (int x = bx2 + 1; x <= x2; x++) for (int z = 0; z <= z2; z++) p.set(x, 0, z, bb("asphalt", Blocks.BLACK_CONCRETE));
        p.fill(0, 0, 0, bx2, 0, z2, bb("floor_linoleum", Blocks.WHITE_CONCRETE));
        storey(p, 0, 0, bx2, z2, 0, fh, wall, Blocks.GLASS_PANE.getDefaultState(), Blocks.RED_CONCRETE.getDefaultState(), 3);
        p.air(1, 1, 1, bx2 - 1, fh - 1, z2 - 1);
        p.fill(0, fh, 0, bx2, fh, z2, Blocks.RED_CONCRETE.getDefaultState());
        for (int x = 0; x <= bx2; x++) p.set(x, fh - 1, 0, (x % 2 == 0 ? Blocks.YELLOW_CONCRETE : Blocks.RED_CONCRETE).getDefaultState());
        p.door(3, 1, 0, Blocks.BIRCH_DOOR, Direction.NORTH);
        // окно выдачи
        p.set(bx2, 2, z2 - 3, Blocks.GLASS_PANE.getDefaultState());
        p.set(bx2, 1, z2 - 3, Blocks.SMOOTH_QUARTZ.getDefaultState());
        // меню-стойка
        int cz = z2 - 6;
        for (int x = 1; x < bx2; x++) if (x != 2) p.furnLoot(x, 1, cz, "kitchen_counter", Direction.NORTH, Loot.DINER);
        p.furnLoot(bx2 - 1, 1, z2 - 1, "fridge", Direction.WEST, Loot.FRIDGE);
        p.furnLoot(bx2 - 2, 1, z2 - 1, "stove", Direction.NORTH, Loot.DINER);
        p.furnLoot(bx2 - 3, 1, z2 - 1, "stove", Direction.NORTH, Loot.DINER);
        p.furnLoot(1, 1, z2 - 1, "kitchen_sink", Direction.NORTH, Loot.KITCHEN);
        // кабинки у окон
        for (int z = 2; z < cz - 1; z += 3) {
            p.table(2, 1, z);
            p.set(1, 1, z, stair(Blocks.RED_NETHER_BRICK_STAIRS, Direction.WEST, false));
            p.set(3, 1, z, stair(Blocks.RED_NETHER_BRICK_STAIRS, Direction.EAST, false));
        }
        // столб с вывеской
        for (int y = 1; y <= 9; y++) p.set(x2, y, 0, Blocks.IRON_BARS.getDefaultState());
        p.fill(x2 - 1, 10, 0, x2, 11, 0, Blocks.YELLOW_CONCRETE.getDefaultState());
        Houses.ceilingLamp(p, bx2 / 2, fh - 1, 4);
        zombies(p, 1, 1, bx2 - 1, z2 - 1, 1, 1 + p.r.nextInt(2), ZombieOutfit.CHEF);
        p.danger = 0;
    }

    /** Полицейское управление: дежурная часть, кабинеты, камеры, оружейная за железной дверью, гараж с патрульными машинами. */
    static void precinct(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 4;
        BlockState wall = bb("brick_tan", Blocks.SANDSTONE), pil = bb("concrete_dark", Blocks.GRAY_CONCRETE);
        BlockState inner = bb("drywall", Blocks.WHITE_CONCRETE);
        int bz2 = z2 - 8;   // гараж-стоянка сзади
        for (int k = 0; k <= 2; k++) p.fill(0, k * fh, 0, x2, k * fh, bz2, k == 0 ? bb("floor_linoleum", Blocks.WHITE_CONCRETE) : bb("office_carpet", Blocks.GRAY_WOOL));
        for (int k = 0; k < 2; k++) {
            storey(p, 0, 0, x2, bz2, k * fh, fh, wall, Blocks.GLASS_PANE.getDefaultState(), pil, 1);
            p.air(1, k * fh + 1, 1, x2 - 1, k * fh + fh - 1, bz2 - 1);
        }
        for (int x = 1; x < x2; x++) p.set(x, 3, 0, Blocks.BLUE_CONCRETE.getDefaultState());
        p.door(p.w / 2, 1, 0, Blocks.SPRUCE_DOOR, Direction.NORTH);
        // дежурная стойка
        for (int x = p.w / 2 - 3; x <= p.w / 2 + 3; x++) p.set(x, 1, 5, Blocks.SPRUCE_PLANKS.getDefaultState());
        p.furnLoot(p.w / 2, 1, 6, "desk", Direction.NORTH, Loot.POLICE);
        // камеры вдоль задней стены
        int cz = bz2 - 4;
        for (int x = 1; x < x2 - 8; x++) for (int y = 1; y <= 3; y++) p.set(x, y, cz, Blocks.IRON_BARS.getDefaultState());
        for (int x = 1; x < x2 - 8; x += 4) {
            for (int z = cz + 1; z < bz2; z++) for (int y = 1; y <= 3; y++) p.set(x, y, z, inner);
            p.set(x + 1, 1, cz, AIR);
            p.set(x + 1, 2, cz, AIR);
            p.furn(x + 2, 1, bz2 - 1, "toilet", Direction.NORTH);
            if (p.r.nextFloat() < 0.5f) p.zombie(x + 2, 1, cz + 2, ZombieOutfit.PRISONER);
        }
        // оружейная
        int ax = x2 - 7;
        for (int z = cz; z < bz2; z++) for (int y = 1; y <= 3; y++) p.set(ax, y, z, Blocks.IRON_BLOCK.getDefaultState());
        for (int x = ax; x < x2; x++) for (int y = 1; y <= 3; y++) p.set(x, y, cz, Blocks.IRON_BLOCK.getDefaultState());
        p.door(ax + 3, 1, cz, Blocks.IRON_DOOR, Direction.NORTH);
        p.set(ax + 4, 2, cz - 1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        for (int x = ax + 1; x < x2; x++) p.furnLoot(x, 1, bz2 - 1, "gun_rack", Direction.NORTH, Loot.POLICE);
        p.furnLoot(ax + 1, 1, cz + 1, "army_crate", Direction.EAST, Loot.GUNSTORE);
        // второй этаж: кабинеты детективов
        Houses.staircase(p, 1, 0, 6, fh - 1, Direction.SOUTH, Blocks.STONE_BRICK_STAIRS);
        for (int x = 4; x < x2 - 2; x += 4)
            for (int z = 3; z < bz2 - 2; z += 4) {
                p.furnLoot(x, fh + 1, z, "desk", Direction.SOUTH, Loot.POLICE);
                p.furn(x, fh + 1, z + 1, "chair", Direction.NORTH);
            }
        roof(p, 0, 0, x2, bz2, 2 * fh, wall, false);
        // стоянка с патрульными машинами
        for (int x = 0; x <= x2; x++) for (int z = bz2 + 1; z <= z2; z++) p.set(x, 0, z, bb("asphalt", Blocks.BLACK_CONCRETE));
        for (int x = 3; x < x2 - 2; x += 7) if (p.r.nextFloat() < 0.7f) p.vehicle(x, 1, bz2 + 4.5, "police", 90f, p.r.nextFloat() < 0.2f);
        lamps(p, 1, 1, x2 - 1, bz2 - 1, 3, 6);
        lamps(p, 1, 1, x2 - 1, bz2 - 1, fh + 3, 6);
        zombies(p, 1, 1, x2 - 1, cz - 1, 1, 3 + p.r.nextInt(3), ZombieOutfit.POLICE);
        zombies(p, 1, 1, x2 - 1, bz2 - 1, fh + 1, 1 + p.r.nextInt(2), ZombieOutfit.POLICE);
        p.danger = 2;
    }

    // =====================================================================================
    //                                     промзона
    // =====================================================================================

    /** Завод: высокий цех со станками, конвейером и мостками, кабинеты, погрузочные ворота, дымовая труба, двор с контейнерами. */
    static void factory(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 10, yard = 10;
        int bz2 = z2 - yard;
        BlockState wall = bb("metal_siding", Blocks.LIGHT_GRAY_CONCRETE), base = bb("brick_dark", Blocks.BRICKS);
        p.fill(0, 0, 0, x2, 0, bz2, bb("floor_concrete", Blocks.LIGHT_GRAY_CONCRETE));
        for (int x = 0; x <= x2; x++)
            for (int z = 0; z <= bz2; z++) {
                if (x != 0 && x != x2 && z != 0 && z != bz2) continue;
                for (int y = 1; y <= fh; y++) p.set(x, y, z, y <= 2 ? base : (y == 6 && (x + z) % 3 != 0 ? Blocks.GLASS_PANE.getDefaultState() : wall));
            }
        // пилообразная крыша
        for (int z = 0; z <= bz2; z++) {
            int t = z % 6;
            for (int x = 0; x <= x2; x++) {
                p.set(x, fh + 1 + Math.min(t, 3), z, wall);
                if (t == 4) p.set(x, fh + 4, z, Blocks.GLASS.getDefaultState());
            }
        }
        // ворота и дверь
        for (int x = 4; x <= 8; x++) p.air(x, 1, 0, x, 4, 0);
        p.door(x2 - 4, 1, 0, Blocks.IRON_DOOR, Direction.NORTH);
        // станки рядами
        Block[] machines = {Blocks.BLAST_FURNACE, Blocks.SMOKER, Blocks.ANVIL, Blocks.GRINDSTONE, Blocks.STONECUTTER, Blocks.SMITHING_TABLE};
        for (int z = 6; z < bz2 - 4; z += 5)
            for (int x = 3; x < x2 - 10; x += 3) p.set(x, 1, z, machines[p.r.nextInt(machines.length)].getDefaultState());
        // конвейер
        for (int x = 3; x < x2 - 10; x++) p.set(x, 1, 4, Blocks.SMOOTH_STONE_SLAB.getDefaultState());
        // кабинеты на антресоли и мостки
        int mx = x2 - 9;
        p.fill(mx, 5, 1, x2 - 1, 5, bz2 - 1, Blocks.IRON_BLOCK.getDefaultState());
        for (int z = 1; z < bz2; z++) p.set(mx, 6, z, Blocks.IRON_BARS.getDefaultState());
        p.ladder(mx - 1, 1, 6, 2, Direction.WEST);
        p.set(mx, 6, 2, AIR);
        for (int z = 3; z < bz2 - 2; z += 4) {
            p.furnLoot(mx + 3, 6, z, "desk", Direction.SOUTH, Loot.OFFICE);
            p.furn(mx + 3, 6, z + 1, "chair", Direction.NORTH);
        }
        for (int x = 1; x < mx; x++) {
            p.set(x, 7, 1, Blocks.SMOOTH_STONE_SLAB.getDefaultState().with(SlabBlock.TYPE, SlabType.TOP));
            p.set(x, 8, 2, Blocks.IRON_BARS.getDefaultState());
        }
        for (int z = 6; z < mx - 2; z += 9) p.furnLoot(1, 1, z, "shelf_tools", Direction.EAST, Loot.HARDWARE);
        for (int x = 2; x < 12; x += 2) p.furnLoot(x, 1, bz2 - 1, "cardboard_box", Direction.NORTH, Loot.WAREHOUSE);
        // дымовая труба
        int sx = x2 - 3, sz = bz2 - 3;
        for (int y = 1; y <= fh + 18; y++)
            for (int a = -1; a <= 1; a++)
                for (int b = -1; b <= 1; b++) p.set(sx + a, y, sz + b, a == 0 && b == 0 ? AIR : Blocks.BRICKS.getDefaultState());
        // двор с контейнерами
        for (int x = 0; x <= x2; x++) for (int z = bz2 + 1; z <= z2; z++) p.set(x, 0, z, Blocks.GRAVEL.getDefaultState());
        Block[] cont = {Blocks.RED_CONCRETE, Blocks.BLUE_CONCRETE, Blocks.GREEN_CONCRETE, Blocks.ORANGE_CONCRETE};
        for (int x = 2; x + 6 < x2; x += 9) {
            if (p.r.nextFloat() < 0.3f) continue;
            BlockState c = cont[p.r.nextInt(cont.length)].getDefaultState();
            p.fill(x, 1, bz2 + 3, x + 6, 3, bz2 + 5, c);
            p.fill(x, 2, bz2 + 4, x + 6, 2, bz2 + 4, c);
            p.loot(x + 3, 1, bz2 + 2, Blocks.BARREL.getDefaultState(), Loot.WAREHOUSE);
        }
        p.vehicle(x2 - 6, 1, z2 - 2.5, com.example.zomboidmod.vehicle.VehicleType.randomCivil(p.r).id, 90f, false);
        lamps(p, 1, 1, x2 - 1, bz2 - 1, fh, 6);
        zombies(p, 1, 1, x2 - 1, bz2 - 1, 1, 4 + p.r.nextInt(4), ZombieOutfit.CONSTRUCTION);
        p.danger = 1;
    }

    /** Большой склад: высокие стеллажи с коробками, погрузочные рампы, фуры у ворот. */
    static void bigWarehouse(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 9, dock = 7;
        int bz1 = dock;
        BlockState wall = bb(p.r.nextBoolean() ? "metal_siding_blue" : "metal_siding", Blocks.LIGHT_GRAY_CONCRETE);
        for (int x = 0; x <= x2; x++) for (int z = 0; z < bz1; z++) p.set(x, 0, z, bb("asphalt", Blocks.BLACK_CONCRETE));
        p.fill(0, 0, bz1, x2, 0, z2, bb("floor_concrete", Blocks.LIGHT_GRAY_CONCRETE));
        p.walls(0, 1, bz1, x2, fh, z2, wall);
        p.air(1, 1, bz1 + 1, x2 - 1, fh, z2 - 1);
        p.fill(0, fh + 1, bz1, x2, fh + 1, z2, bb("roof_tar", Blocks.GRAY_CONCRETE));
        // рампы и ворота
        for (int x = 3; x + 4 < x2; x += 8) {
            p.air(x, 1, bz1, x + 3, 4, bz1);
            p.fill(x, 0, bz1 - 3, x + 3, 0, bz1 - 1, Blocks.SMOOTH_STONE.getDefaultState());
            if (p.r.nextFloat() < 0.4f) p.vehicle(x + 2, 1, 2.5, "van", 180f, p.r.nextFloat() < 0.2f);
        }
        p.door(x2 - 2, 1, bz1, Blocks.IRON_DOOR, Direction.NORTH);
        // стеллажи: каркас из решёток, полки из плит, коробки и бочки
        for (int x = 3; x < x2 - 2; x += 5)
            for (int z = bz1 + 4; z < z2 - 2; z++) {
                for (int lvl = 0; lvl < 3; lvl++) {
                    int y = 1 + lvl * 3;
                    if ((z - bz1) % 6 == 4) {
                        p.set(x, y, z, Blocks.IRON_BARS.getDefaultState());
                        p.set(x + 1, y, z, Blocks.IRON_BARS.getDefaultState());
                        continue;
                    }
                    if (lvl == 0) p.furnLoot(x, y, z, "cardboard_box", Direction.EAST, Loot.WAREHOUSE);
                    else if (p.r.nextFloat() < 0.5f) p.set(x, y, z, Blocks.BARREL.getDefaultState());
                    if (lvl == 0 && p.r.nextFloat() < 0.5f) p.loot(x + 1, y, z, Blocks.BARREL.getDefaultState(), Loot.WAREHOUSE);
                    p.set(x, y + 2, z, Blocks.SMOOTH_STONE_SLAB.getDefaultState().with(SlabBlock.TYPE, SlabType.TOP));
                    p.set(x + 1, y + 2, z, Blocks.SMOOTH_STONE_SLAB.getDefaultState().with(SlabBlock.TYPE, SlabType.TOP));
                }
            }
        lamps(p, 1, bz1 + 1, x2 - 1, z2 - 1, fh, 6);
        zombies(p, 1, bz1 + 1, x2 - 1, z2 - 1, 1, 3 + p.r.nextInt(4), ZombieOutfit.CONSTRUCTION);
        p.danger = 1;
    }

    /** Недострой: бетонный каркас, леса, кран, материалы, бытовка. */
    static void constructionSite(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 4;
        int bx1 = 3, bz1 = 4, bx2 = x2 - 8, bz2 = z2 - 3;
        int floors = 4 + p.r.nextInt(4);
        BlockState conc = Blocks.LIGHT_GRAY_CONCRETE.getDefaultState();
        for (int x = 0; x <= x2; x++) for (int z = 0; z <= z2; z++) p.set(x, 0, z, p.r.nextFloat() < 0.3f ? Blocks.COARSE_DIRT.getDefaultState() : Blocks.GRAVEL.getDefaultState());
        // забор стройки
        for (int x = 0; x <= x2; x++) {
            p.set(x, 1, 0, Blocks.ORANGE_WOOL.getDefaultState());
            p.set(x, 1, z2, Blocks.ORANGE_WOOL.getDefaultState());
        }
        for (int z = 0; z <= z2; z++) {
            p.set(0, 1, z, Blocks.ORANGE_WOOL.getDefaultState());
            p.set(x2, 1, z, Blocks.ORANGE_WOOL.getDefaultState());
        }
        p.air(4, 1, 0, 7, 1, 0);
        for (int k = 0; k < floors; k++) {
            int y = k * fh;
            boolean done = k < floors - 2;
            for (int x = bx1; x <= bx2; x += 5) for (int z = bz1; z <= bz2; z += 5) p.fill(x, y + 1, z, x, y + fh, z, conc);
            if (k < floors - 1)
                for (int x = bx1; x <= bx2; x++)
                    for (int z = bz1; z <= bz2; z++) if (done || p.r.nextFloat() < 0.6f) p.set(x, y + fh, z, conc);
            // леса по фасаду
            if (k >= floors - 3) for (int x = bx1 - 1; x <= bx2 + 1; x++) {
                p.set(x, y + fh, bz1 - 1, Blocks.SPRUCE_SLAB.getDefaultState().with(SlabBlock.TYPE, SlabType.TOP));
                if ((x - bx1) % 4 == 0) p.fill(x, y + 1, bz1 - 1, x, y + fh - 1, bz1 - 1, Blocks.SPRUCE_FENCE.getDefaultState());
            }
        }
        for (int y = 1; y <= floors * fh; y++) p.set(bx1 - 1, y, bz1 - 1, Blocks.SCAFFOLDING.getDefaultState());
        // кран
        int cx = x2 - 4, cz = z2 / 2, ch = floors * fh + 12;
        for (int y = 1; y <= ch; y++) {
            p.set(cx, y, cz, Blocks.IRON_BARS.getDefaultState());
            p.set(cx + 1, y, cz, Blocks.IRON_BARS.getDefaultState());
            if (y % 4 == 0) p.set(cx, y, cz + 1, Blocks.YELLOW_CONCRETE.getDefaultState());
        }
        for (int x = cx - 22; x <= cx + 5; x++) {
            p.set(x, ch + 1, cz, Blocks.YELLOW_CONCRETE.getDefaultState());
            if (x % 3 == 0) p.set(x, ch + 2, cz, Blocks.IRON_BARS.getDefaultState());
        }
        p.fill(cx + 3, ch - 1, cz - 1, cx + 5, ch, cz + 1, Blocks.STONE_BRICKS.getDefaultState());   // противовес
        for (int y = ch; y > ch - 10; y--) p.set(cx - 18, y, cz, Blocks.CHAIN.getDefaultState());
        // материалы
        for (int k = 0; k < 4; k++) {
            int x = 2 + p.r.nextInt(Math.max(1, bx1 + 6)), z = z2 - 2;
            p.fill(x, 1, z, x + 1, 1 + p.r.nextInt(2), z, p.r.nextBoolean() ? Blocks.STONE_BRICKS.getDefaultState() : Blocks.OAK_PLANKS.getDefaultState());
        }
        // бытовка
        int hx = 2, hz = 1;
        p.walls(hx, 1, hz, hx + 4, 3, hz + 2, bb("metal_siding", Blocks.WHITE_CONCRETE));
        p.fill(hx, 4, hz, hx + 4, 4, hz + 2, bb("metal_siding", Blocks.WHITE_CONCRETE));
        p.air(hx + 1, 1, hz + 1, hx + 3, 3, hz + 1);
        p.door(hx + 2, 1, hz + 2, Blocks.OAK_DOOR, Direction.SOUTH);
        p.furnLoot(hx + 1, 1, hz + 1, "desk", Direction.EAST, Loot.HARDWARE);
        p.furnLoot(hx + 3, 1, hz + 1, "shelf_tools", Direction.WEST, Loot.HARDWARE);
        zombies(p, 1, 1, x2 - 1, z2 - 1, 1, 3 + p.r.nextInt(3), ZombieOutfit.CONSTRUCTION);
        p.danger = 1;
    }

    /** Водонапорная башня. */
    static void waterTower(Plan p) {
        int cx = p.w / 2, cz = p.d / 2, h = 16;
        for (int y = 0; y <= 0; y++) p.fill(0, 0, 0, p.w - 1, 0, p.d - 1, Blocks.GRAVEL.getDefaultState());
        for (int[] l : new int[][]{{-3, -3}, {3, -3}, {-3, 3}, {3, 3}})
            for (int y = 1; y <= h; y++) p.set(cx + l[0], y, cz + l[1], Blocks.IRON_BARS.getDefaultState());
        for (int y = h + 1; y <= h + 6; y++)
            for (int x = -4; x <= 4; x++)
                for (int z = -4; z <= 4; z++) {
                    double d = Math.hypot(x, z);
                    if (d <= 4.3 && (d > 3.2 || y == h + 1 || y == h + 6)) p.set(cx + x, y, cz + z, Blocks.LIGHT_GRAY_CONCRETE.getDefaultState());
                }
        p.ladder(cx, 1, h + 6, cz + 5, Direction.SOUTH);
        for (int x = -4; x <= 4; x++) p.set(cx + x, h + 3, cz - 5, Blocks.WHITE_CONCRETE.getDefaultState());
    }

    // =====================================================================================
    //                                     площади и парки
    // =====================================================================================

    /** Площадь: плитка, фонтан, деревья в кадках, скамейки, фонари. */
    static void plaza(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, cx = p.w / 2, cz = p.d / 2;
        BlockState tile = bb("sidewalk", Blocks.SMOOTH_STONE);
        for (int x = 0; x <= x2; x++) for (int z = 0; z <= z2; z++) p.set(x, 0, z, (x + z) % 7 == 0 ? Blocks.POLISHED_ANDESITE.getDefaultState() : tile);
        int r = Math.min(4, Math.min(p.w, p.d) / 4);
        for (int x = -r; x <= r; x++)
            for (int z = -r; z <= r; z++) {
                double d = Math.hypot(x, z);
                if (d > r + 0.5) continue;
                if (d > r - 0.5) p.set(cx + x, 1, cz + z, Blocks.STONE_BRICK_SLAB.getDefaultState());
                else p.set(cx + x, 0, cz + z, Blocks.WATER.getDefaultState());
            }
        p.fill(cx, 0, cz, cx, 2, cz, Blocks.STONE_BRICKS.getDefaultState());
        p.set(cx, 3, cz, Blocks.WATER.getDefaultState());
        for (int[] t : new int[][]{{2, 2}, {x2 - 2, 2}, {2, z2 - 2}, {x2 - 2, z2 - 2}}) {
            p.set(t[0], 0, t[1], Blocks.GRASS_BLOCK.getDefaultState());
            p.tree(t[0], 0, t[1], p.r.nextInt(3));
        }
        for (int x = 4; x < x2 - 3; x += 6) {
            p.furn(x, 1, 1, "bench", Direction.SOUTH);
            p.furn(x, 1, z2 - 1, "bench", Direction.NORTH);
        }
        decals(p, 0, 0, x2, z2, 1, 0.02f);
        zombies(p, 0, 0, x2, z2, 1, 1 + p.r.nextInt(3), null);
    }

    /** Городской парк: дорожки, пруд, детская площадка, баскетбольная площадка, деревья, скамейки. */
    static void cityPark(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, cx = p.w / 2, cz = p.d / 2;
        for (int x = 0; x <= x2; x++) for (int z = 0; z <= z2; z++) p.set(x, 0, z, Blocks.GRASS_BLOCK.getDefaultState());
        // дорожки крестом
        for (int x = 0; x <= x2; x++) for (int dz = -1; dz <= 1; dz++) p.set(x, 0, cz + dz, Blocks.DIRT_PATH.getDefaultState());
        for (int z = 0; z <= z2; z++) for (int dx = -1; dx <= 1; dx++) p.set(cx + dx, 0, z, Blocks.DIRT_PATH.getDefaultState());
        // пруд в одной четверти
        int px = cx / 2, pz = cz / 2, pr = Math.max(3, Math.min(px, pz) - 3);
        for (int x = -pr - 1; x <= pr + 1; x++)
            for (int z = -pr - 1; z <= pr + 1; z++) {
                double d = Math.hypot(x, z * 1.3);
                if (d <= pr) {
                    p.set(px + x, 0, pz + z, Blocks.WATER.getDefaultState());
                    p.set(px + x, -1, pz + z, Blocks.WATER.getDefaultState());
                } else if (d <= pr + 1) p.set(px + x, 0, pz + z, Blocks.SAND.getDefaultState());
            }
        p.set(px, 1, pz, Blocks.LILY_PAD.getDefaultState());
        // баскетбольная площадка
        int bx = cx + 3, bz = 2, bw = Math.min(14, x2 - bx - 1), bd = Math.min(9, cz - 4);
        if (bw >= 8 && bd >= 6) {
            for (int x = bx; x < bx + bw; x++)
                for (int z = bz; z < bz + bd; z++) {
                    boolean line = x == bx || z == bz || x == bx + bw - 1 || z == bz + bd - 1 || x == bx + bw / 2;
                    p.set(x, 0, z, line ? Blocks.WHITE_CONCRETE.getDefaultState() : Blocks.GRAY_CONCRETE.getDefaultState());
                }
            for (int hx : new int[]{bx, bx + bw - 1}) {
                for (int y = 1; y <= 3; y++) p.set(hx, y, bz + bd / 2, Blocks.IRON_BARS.getDefaultState());
                p.set(hx, 4, bz + bd / 2, Blocks.WHITE_CONCRETE.getDefaultState());
            }
        }
        // детская площадка
        int gx = cx + 3, gz = cz + 3;
        if (gx + 8 < x2 && gz + 7 < z2) {
            for (int x = gx; x <= gx + 8; x++) for (int z = gz; z <= gz + 7; z++) p.set(x, 0, z, Blocks.SAND.getDefaultState());
            for (int y = 1; y <= 3; y++) {
                p.set(gx + 1, y, gz + 1, Blocks.OAK_FENCE.getDefaultState());
                p.set(gx + 3, y, gz + 1, Blocks.OAK_FENCE.getDefaultState());
            }
            p.set(gx + 1, 4, gz + 1, Blocks.OAK_SLAB.getDefaultState());
            p.set(gx + 2, 4, gz + 1, Blocks.OAK_SLAB.getDefaultState());
            p.set(gx + 3, 4, gz + 1, Blocks.OAK_SLAB.getDefaultState());
            p.set(gx + 2, 3, gz + 1, Blocks.CHAIN.getDefaultState());
            for (int k = 0; k < 3; k++) p.set(gx + 6, 1 + k, gz + 2 + k, stair(Blocks.SMOOTH_QUARTZ_STAIRS, Direction.NORTH, false));
        }
        // деревья и скамейки
        for (int k = 0; k < (p.w * p.d) / 70; k++) {
            int x = 2 + p.r.nextInt(Math.max(1, x2 - 3)), z = 2 + p.r.nextInt(Math.max(1, z2 - 3));
            BlockState g = p.get(x, 0, z);
            if (g == null || !g.isOf(Blocks.GRASS_BLOCK)) continue;
            if (Math.abs(x - cx) < 4 || Math.abs(z - cz) < 4) continue;
            p.tree(x, 0, z, p.r.nextInt(3));
        }
        for (int x = 3; x < x2 - 2; x += 8) p.furn(x, 1, cz - 2, "bench", Direction.SOUTH);
        for (int z = 3; z < z2 - 2; z += 8) p.furn(cx + 2, 1, z, "bench", Direction.WEST);
        for (int z = 6; z < z2 - 3; z += 14) {
            p.set(cx - 2, 1, z, Blocks.IRON_BARS.getDefaultState());
            p.furn(cx - 2, 2, z, "street_lamp", Direction.EAST);
        }
        zombies(p, 0, 0, x2, z2, 1, 2 + p.r.nextInt(4), null);
        decals(p, 0, 0, x2, z2, 1, 0.006f);
    }
}
