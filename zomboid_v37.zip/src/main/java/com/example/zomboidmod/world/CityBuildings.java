package com.example.zomboidmod.world;

import com.example.zomboidmod.ZombieOutfit;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.Direction;

import static com.example.zomboidmod.world.Buildings.BARREL;
import static com.example.zomboidmod.world.Buildings.GLASS;

/**
 * Здания большого города и новые магазины: книжный, оружейный, электроника, спорттовары, алкомаркет, пиццерия,
 * военторг, офисные высотки, многоэтажки, больница, торговый центр, библиотека, автосервис, военный блокпост.
 * Опасность (p.danger) ставится по ценности лута: чем лучше лут, тем сильнее и многочисленнее зомби вокруг.
 */
public final class CityBuildings {
    private CityBuildings() {
    }

    private static BlockState st(Block b) {
        return b.getDefaultState();
    }

    /** Ряд мебели с лутом вдоль x (с проходом у gapX). */
    static void row(Plan p, String id, Loot loot, int x1, int x2, int y, int z, int gapX, Direction facing, float fill) {
        for (int x = x1; x <= x2; x++) {
            if (Math.abs(x - gapX) <= 1) continue;
            if (p.r.nextFloat() < fill) p.furnLoot(x, y, z, id, facing, loot);
            else p.furn(x, y, z, id, facing);
            if (p.r.nextFloat() < 0.08f) p.pile(x, y, z - 1, loot);
        }
    }

    // ===================== магазины 25x12 =====================

    public static void bookstore(Plan p) {
        Buildings.shop(p, 1, 2, 23, 11, 4, st(Blocks.BROWN_TERRACOTTA), st(Blocks.BLUE_CONCRETE), st(Blocks.DARK_OAK_PLANKS));
        for (int z = 5; z <= 8; z += 3) row(p, "shelf_books", Loot.BOOKS, 4, 20, 1, z, 12, Direction.NORTH, 0.6f);
        for (int x = 3; x <= 21; x++) if (x != 12) p.furnLoot(x, 1, 10, "shelf_books", Direction.NORTH, Loot.BOOKS);
        Buildings.counter(p, 2, 4, 4);
        p.furn(18, 1, 3, "armchair", Direction.SOUTH);
        Buildings.lamp(p, 7, 4, 6);
        Buildings.lamp(p, 17, 4, 6);
        p.danger = 1;
        p.zombie(9, 1, 7, null);
    }

    /** Оружейный: решётки вместо витрин, стойки с ружьями, витрины с пистолетами. Самый ценный лут — самые опасные зомби. */
    public static void gunstore(Plan p) {
        Buildings.shop(p, 1, 2, 23, 11, 4, st(Blocks.GRAY_CONCRETE), st(Blocks.RED_CONCRETE), st(Blocks.SPRUCE_PLANKS));
        for (int x = 2; x <= 22; x++) if (Math.abs(x - 12) > 0) p.fill(x, 1, 2, x, 3, 2, Blocks.IRON_BARS);
        p.set(11, 1, 2, Blocks.IRON_BARS);
        p.set(13, 1, 2, Blocks.IRON_BARS);
        for (int x = 3; x <= 21; x++) if (x != 12) p.furnLoot(x, 1, 10, "gun_rack", Direction.NORTH, Loot.GUNSTORE);
        for (int x = 5; x <= 19; x++) if (Math.abs(x - 12) > 1) {
            if (p.r.nextFloat() < 0.7f) p.furnLoot(x, 1, 6, "display_case", Direction.NORTH, Loot.GUNSTORE);
            else p.furn(x, 1, 6, "display_case", Direction.NORTH);
        }
        p.loot(2, 1, 9, Buildings.chest(Direction.EAST), Loot.GUNSTORE);
        p.loot(22, 1, 9, Buildings.chest(Direction.WEST), Loot.GUNSTORE);
        Buildings.lamp(p, 8, 4, 7);
        Buildings.lamp(p, 16, 4, 7);
        p.danger = 3;
        p.zombie(12, 1, 8, ZombieOutfit.SECURITY);
        p.zombie(6, 1, 4, ZombieOutfit.POLICE);
        p.zombie(18, 1, 8, ZombieOutfit.SOLDIER);
    }

    public static void electronics(Plan p) {
        Buildings.shop(p, 1, 2, 23, 11, 4, st(Blocks.WHITE_CONCRETE), st(Blocks.CYAN_CONCRETE), st(Blocks.LIGHT_GRAY_CONCRETE));
        for (int z = 5; z <= 8; z += 3) row(p, "shelf_electronics", Loot.ELECTRONICS, 4, 20, 1, z, 12, Direction.NORTH, 0.55f);
        for (int x = 3; x <= 21; x += 3) if (x != 12) p.furn(x, 1, 10, "tv", Direction.NORTH);
        for (int x = 4; x <= 20; x += 3) if (x != 12 && x != 13) p.furnLoot(x, 1, 10, "cardboard_box", Direction.NORTH, Loot.ELECTRONICS);
        Buildings.counter(p, 2, 4, 4);
        Buildings.lamp(p, 12, 4, 6);
        p.danger = 1;
        p.zombie(10, 1, 7, ZombieOutfit.CIVILIAN_HOODIE);
    }

    public static void sports(Plan p) {
        Buildings.shop(p, 1, 2, 23, 11, 4, st(Blocks.LIME_TERRACOTTA), st(Blocks.GREEN_CONCRETE), st(Blocks.BIRCH_PLANKS));
        for (int x = 4; x <= 20; x += 3) {
            if (x == 13) continue;
            p.loot(x, 1, 6, BARREL, Loot.SPORTS);
            p.set(x + 1, 1, 6, Blocks.OAK_FENCE);
        }
        for (int x = 3; x <= 21; x++) if (x != 12 && x % 2 == 1) p.loot(x, 1, 10, Buildings.chest(Direction.NORTH), Loot.SPORTS);
        Buildings.counter(p, 2, 4, 4);
        Buildings.lamp(p, 12, 4, 6);
        p.danger = 1;
        p.zombie(15, 1, 8, ZombieOutfit.CIVILIAN_SHORTS);
    }

    public static void liquor(Plan p) {
        Buildings.shop(p, 1, 2, 23, 11, 4, st(Blocks.RED_TERRACOTTA), st(Blocks.PURPLE_CONCRETE), st(Blocks.POLISHED_DIORITE));
        for (int z = 5; z <= 8; z += 3) row(p, "shelf_food", Loot.LIQUOR, 4, 20, 1, z, 12, Direction.NORTH, 0.6f);
        for (int x = 3; x <= 21; x++) if (x != 12) p.furnLoot(x, 1, 10, "fridge", Direction.NORTH, Loot.LIQUOR);
        Buildings.counter(p, 2, 5, 4);
        Buildings.lamp(p, 12, 4, 6);
        p.zombie(8, 1, 7, ZombieOutfit.BIKER);
    }

    public static void pizzeria(Plan p) {
        Buildings.shop(p, 1, 2, 23, 11, 4, st(Blocks.WHITE_TERRACOTTA), st(Blocks.RED_CONCRETE), st(Blocks.WHITE_CONCRETE));
        for (int x = 4; x <= 20; x += 4) {
            p.table(x, 1, 5);
            p.furn(x - 1, 1, 5, "chair", Direction.EAST);
            p.furn(x + 1, 1, 5, "chair", Direction.WEST);
        }
        Buildings.counter(p, 2, 22, 7);
        p.air(12, 1, 7, 12, 1, 7);
        for (int x = 3; x <= 21; x += 3) {
            if (x == 12) continue;
            p.furnLoot(x, 1, 10, x % 2 == 0 ? "stove" : "fridge", Direction.NORTH, x % 2 == 0 ? Loot.KITCHEN : Loot.FRIDGE);
            p.furnLoot(x + 1, 1, 10, "kitchen_counter", Direction.NORTH, Loot.DINER);
        }
        Buildings.lamp(p, 12, 4, 5);
        p.zombie(9, 1, 9, ZombieOutfit.CHEF);
        p.zombie(15, 1, 4, null);
    }

    /** Военторг: армейские ящики, снаряжение, тёплая одежда. */
    public static void armySurplus(Plan p) {
        Buildings.shop(p, 1, 2, 23, 11, 4, st(Blocks.GREEN_TERRACOTTA), st(Blocks.BROWN_CONCRETE), st(Blocks.SPRUCE_PLANKS));
        for (int x = 4; x <= 20; x += 2) if (Math.abs(x - 12) > 1) {
            if (p.r.nextFloat() < 0.65f) p.furnLoot(x, 1, 6, "army_crate", Direction.NORTH, Loot.ARMY);
            else p.furn(x, 1, 6, "army_crate", Direction.NORTH);
        }
        for (int x = 3; x <= 21; x += 3) if (x != 12) p.furnLoot(x, 1, 10, "wardrobe", Direction.NORTH, Loot.ARMY);
        for (int x = 2; x <= 22; x += 5) p.furn(x, 1, 3, "sandbags", Direction.NORTH);
        Buildings.counter(p, 18, 21, 4);
        Buildings.lamp(p, 12, 4, 7);
        p.danger = 2;
        p.zombie(10, 1, 8, ZombieOutfit.SOLDIER);
        p.zombie(16, 1, 8, ZombieOutfit.SURVIVOR);
    }

    // ===================== многоэтажки =====================

    /**
     * Коробка в несколько этажей: перекрытия, окна лентой, лестница (стремянка) в углу до крыши.
     * Возвращает высоту этажа; содержимое этажей заполняет вызывающий.
     */
    static void floors(Plan p, int x1, int z1, int x2, int z2, int n, int fh, BlockState wall, BlockState floor, BlockState glass) {
        int top = n * fh;
        p.fill(x1, 0, z1, x2, 0, z2, floor);
        p.walls(x1, 1, z1, x2, top, z2, wall);
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, top, z2 - 1);
        for (int f = 0; f < n; f++) {
            int y = f * fh;
            if (f > 0) p.fill(x1 + 1, y, z1 + 1, x2 - 1, y, z2 - 1, floor);
            for (int wy = y + 2; wy <= y + fh - 1 && wy <= y + 3; wy++) {
                for (int x = x1 + 1; x <= x2 - 1; x++) if ((x - x1) % 3 != 0) {
                    p.set(x, wy, z1, glass);
                    p.set(x, wy, z2, glass);
                }
                for (int z = z1 + 1; z <= z2 - 1; z++) if ((z - z1) % 3 != 0) {
                    p.set(x1, wy, z, glass);
                    p.set(x2, wy, z, glass);
                }
            }
            for (int x = x1; x <= x2; x++) p.set(x, y + fh, z1, wall);
            Buildings.lamp(p, (x1 + x2) / 2, y + fh - 1, (z1 + z2) / 2);
        }
        // лестница на все этажи и на крышу
        int lx = x2 - 2, lz = z2 - 1;
        p.ladder(lx, 1, top + 1, lz, Direction.NORTH);
        for (int f = 1; f <= n; f++) p.set(lx, f * fh, lz, Blocks.LADDER.getDefaultState().with(net.minecraft.block.LadderBlock.FACING, Direction.NORTH));
        Buildings.flatRoof(p, x1, z1, x2, z2, top + 1, st(Blocks.GRAY_CONCRETE), wall);
        p.set(lx, top + 1, lz, Blocks.LADDER.getDefaultState().with(net.minecraft.block.LadderBlock.FACING, Direction.NORTH));
        p.set(lx, top + 2, lz, Blocks.AIR.getDefaultState());
    }

    /** Офисная высотка (25x25), 5-8 этажей: холл, этажи с кабинетами. */
    public static void officeTower(Plan p) {
        BlockState[] walls = {st(Blocks.LIGHT_GRAY_CONCRETE), st(Blocks.CYAN_TERRACOTTA), st(Blocks.GRAY_CONCRETE), st(Blocks.SMOOTH_SANDSTONE),
                st(Blocks.WHITE_CONCRETE)};
        BlockState[] glass = {st(Blocks.LIGHT_BLUE_STAINED_GLASS_PANE), st(Blocks.GRAY_STAINED_GLASS_PANE), st(Blocks.CYAN_STAINED_GLASS_PANE)};
        int n = 5 + p.r.nextInt(4), fh = 4;
        int x1 = 1, x2 = 23, z1 = 2, z2 = 23;
        floors(p, x1, z1, x2, z2, n, fh, walls[p.r.nextInt(walls.length)], st(Blocks.SMOOTH_STONE), glass[p.r.nextInt(glass.length)]);
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.SMOOTH_STONE);
        p.door(12, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.set(11, 1, z1, GLASS);
        p.set(13, 1, z1, GLASS);
        // холл
        Buildings.counter(p, 8, 16, 8);
        p.furn(4, 1, 4, "sofa", Direction.SOUTH);
        p.furn(5, 1, 4, "sofa", Direction.SOUTH);
        p.furnLoot(3, 1, 20, "trash_can", Direction.EAST, Loot.TRASH);
        p.zombie(12, 1, 10, ZombieOutfit.SECURITY);
        // этажи
        for (int f = 1; f < n; f++) {
            int y = f * fh + 1;
            for (int x = 4; x <= 19; x += 5)
                for (int z = 5; z <= 18; z += 6) {
                    p.furnLoot(x, y, z, "desk", Direction.SOUTH, Loot.OFFICE);
                    p.furn(x, y, z + 1, "chair", Direction.NORTH);
                    if (p.r.nextFloat() < 0.3f) p.furnLoot(x + 2, y, z, "cardboard_box", Direction.NORTH, Loot.OFFICE);
                    if (p.r.nextFloat() < 0.25f) p.pile(x + 1, y, z + 2, Loot.OFFICE);
                }
            if (p.r.nextFloat() < 0.3f) p.furn(3, y, 3, "radio", Direction.SOUTH);
            int zs = 1 + p.r.nextInt(2);
            for (int k = 0; k < zs; k++) p.zombie(5 + p.r.nextInt(14), y, 4 + p.r.nextInt(16), ZombieOutfit.BUSINESS);
        }
        p.danger = 1;
    }

    /** Многоэтажный жилой дом (25x25), 4-7 этажей по 4 квартиры. */
    public static void apartmentTower(Plan p) {
        BlockState[] walls = {st(Blocks.BRICKS), st(Blocks.WHITE_TERRACOTTA), st(Blocks.LIGHT_GRAY_TERRACOTTA), st(Blocks.ORANGE_TERRACOTTA)};
        BlockState wall = walls[p.r.nextInt(walls.length)];
        BlockState inner = st(Blocks.WHITE_CONCRETE);
        int n = 4 + p.r.nextInt(4), fh = 4;
        int x1 = 1, x2 = 23, z1 = 2, z2 = 23;
        floors(p, x1, z1, x2, z2, n, fh, wall, st(Blocks.OAK_PLANKS), GLASS);
        p.door(12, 1, z1, Blocks.SPRUCE_DOOR, Direction.NORTH);
        for (int f = 0; f < n; f++) {
            int y = f * fh + 1;
            // коридор по z = 12..13, квартиры по 4 на этаж
            for (int x = x1 + 1; x <= x2 - 1; x++) {
                p.fill(x, y, 11, x, y + fh - 2, 11, inner);
                p.fill(x, y, 14, x, y + fh - 2, 14, inner);
            }
            for (int z = z1 + 1; z <= z2 - 1; z++) if (z < 11 || z > 14) p.fill(12, y, z, 12, y + fh - 2, z, inner);
            if (f == 0) p.air(12, y, z1 + 1, 12, y + 1, 10);           // вход с улицы в коридор
            for (int qx : new int[]{6, 18}) {
                p.door(qx, y, 11, Blocks.OAK_DOOR, Direction.NORTH);
                p.door(qx, y, 14, Blocks.OAK_DOOR, Direction.SOUTH);
            }
            for (int[] a : new int[][]{{x1 + 1, z1 + 1, 11, 10}, {13, z1 + 1, x2 - 1, 10}, {x1 + 1, 15, 11, z2 - 1}, {13, 15, x2 - 1, z2 - 1}}) {
                if (f == 0 && a[1] == z1 + 1 && a[0] == 13) continue;   // на первом этаже — холл
                apartmentRoom(p, a[0], a[1], a[2], a[3], y);
            }
            int zs = p.r.nextInt(3);
            for (int k = 0; k < zs; k++) {
                int[] c = p.freeFloor(x1 + 1, z1 + 1, x2 - 1, z2 - 1, y);
                if (c != null) p.zombie(c[0], y, c[1], null);
            }
        }
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.SMOOTH_STONE);
        p.furnLoot(0, 1, 0, "dumpster", Direction.EAST, Loot.TRASH);
    }

    private static void apartmentRoom(Plan p, int ax1, int az1, int ax2, int az2, int y) {
        int mx = (ax1 + ax2) / 2;
        p.bed(ax1 + 1, y, az1 + 1, Blocks.RED_BED, Direction.SOUTH);
        p.furnLoot(ax1 + 3, y, az1, "wardrobe", Direction.SOUTH, Loot.BEDROOM);
        p.furnLoot(ax2, y, az1 + 1, "fridge", Direction.WEST, Loot.FRIDGE);
        p.furnLoot(ax2, y, az1 + 2, "stove", Direction.WEST, Loot.KITCHEN);
        p.furnLoot(ax2, y, az1 + 3, "kitchen_counter", Direction.WEST, Loot.KITCHEN);
        if (az2 - az1 > 6) {
            p.furn(mx, y, az2 - 1, "sofa", Direction.NORTH);
            if (p.r.nextFloat() < 0.6f) p.furn(mx, y, az2 - 4, "tv", Direction.SOUTH);
            if (p.r.nextFloat() < 0.5f) p.furnLoot(ax1, y, az2, "nightstand", Direction.EAST, Loot.LIVING);
        }
        if (p.r.nextFloat() < 0.3f) p.pile(mx, y, az1 + 3, Loot.LIVING);
    }

    /** Больница (37x25): приёмный покой, палаты на двух этажах, аптека. Опасность 3. */
    public static void hospital(Plan p) {
        BlockState wall = st(Blocks.WHITE_CONCRETE);
        int x1 = 1, x2 = 35, z1 = 2, z2 = 23, fh = 5, n = 2;
        floors(p, x1, z1, x2, z2, n, fh, wall, st(Blocks.WHITE_CONCRETE), GLASS);
        p.door(18, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.door(19, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        // красный крест над входом
        p.fill(17, 7, z1, 21, 7, z1, Blocks.RED_CONCRETE);
        p.fill(19, 5, z1, 19, 9, z1, Blocks.RED_CONCRETE);
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.SMOOTH_STONE);
        Buildings.car(p, 3, 0, false, "ambulance");
        if (p.r.nextBoolean()) Buildings.car(p, 28, 0, false, "ambulance");
        Buildings.counter(p, 14, 23, 6);
        for (int f = 0; f < n; f++) {
            int y = f * fh + 1;
            // палаты вдоль стен, коридор посередине (z 11..14)
            for (int x = x1 + 1; x <= x2 - 1; x++) {
                p.fill(x, y, 10, x, y + fh - 2, 10, wall);
                p.fill(x, y, 15, x, y + fh - 2, 15, wall);
            }
            for (int x = x1 + 6; x <= x2 - 3; x += 7) {
                p.fill(x, y, z1 + 1, x, y + fh - 2, 9, wall);
                p.fill(x, y, 16, x, y + fh - 2, z2 - 1, wall);
            }
            for (int x = x1 + 3; x <= x2 - 3; x += 7) {
                if (f == 0 && x > 12 && x < 26) {
                    p.air(x, y, 10, x + 1, y + 1, 10);
                    continue;
                }
                p.air(x, y, 10, x, y + 1, 10);
                p.air(x, y, 15, x, y + 1, 15);
                p.bed(x - 1, y, z1 + 2, Blocks.WHITE_BED, Direction.SOUTH);
                p.bed(x + 2, y, z2 - 3, Blocks.WHITE_BED, Direction.NORTH);
                p.furnLoot(x + 1, y, z1 + 1, "nightstand", Direction.SOUTH, Loot.HOSPITAL);
                p.furnLoot(x, y, z2 - 1, "nightstand", Direction.NORTH, Loot.HOSPITAL);
                if (p.r.nextFloat() < 0.5f) p.furnLoot(x + 2, y, z1 + 4, "shelf_meds", Direction.WEST, Loot.HOSPITAL);
                if (p.r.nextFloat() < 0.35f) p.pile(x, y, 12 + p.r.nextInt(2), Loot.HOSPITAL);
            }
            // аптека в конце коридора
            for (int z = 11; z <= 14; z++) p.furnLoot(x2 - 1, y, z, "shelf_meds", Direction.WEST, Loot.HOSPITAL);
            for (int k = 0; k < 3 + p.r.nextInt(3); k++) {
                int[] c = p.freeFloor(x1 + 1, z1 + 1, x2 - 1, z2 - 1, y);
                ZombieOutfit o = p.r.nextFloat() < 0.4f ? ZombieOutfit.DOCTOR : (p.r.nextFloat() < 0.5f ? ZombieOutfit.NURSE : null);
                if (c != null) p.zombie(c[0], y, c[1], o);
            }
        }
        p.danger = 3;
    }

    /** Торговый центр (37x25): продукты, одежда, электроника, спорт внизу; книги и фудкорт наверху. Опасность 2, толпы зомби. */
    public static void mall(Plan p) {
        BlockState wall = st(Blocks.SMOOTH_SANDSTONE);
        int x1 = 1, x2 = 35, z1 = 2, z2 = 23, fh = 5, n = 2;
        floors(p, x1, z1, x2, z2, n, fh, wall, st(Blocks.POLISHED_DIORITE), st(Blocks.LIGHT_BLUE_STAINED_GLASS_PANE));
        for (int x = x1 + 1; x <= x2 - 1; x++) p.fill(x, 1, z1, x, 4, z1, Blocks.GLASS_PANE);
        p.door(17, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.door(18, 1, z1, Blocks.BIRCH_DOOR, Direction.NORTH);
        for (int x = x1; x <= x2; x++) p.set(x, 5, z1, Blocks.ORANGE_CONCRETE);
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.SMOOTH_STONE);
        int y = 1;
        // низ: 4 отдела
        row(p, "shelf_food", Loot.GROCERY, 3, 15, y, 6, 9, Direction.NORTH, 0.6f);
        row(p, "shelf_food", Loot.GROCERY, 3, 15, y, 9, 9, Direction.NORTH, 0.6f);
        for (int x = 3; x <= 15; x++) if (x != 9) p.furnLoot(x, y, 12, "fridge", Direction.NORTH, Loot.FRIDGE);
        for (int x = 21; x <= 33; x += 3) {
            p.set(x, y, 6, Blocks.OAK_FENCE);
            p.loot(x + 1, y, 6, Buildings.chest(Direction.NORTH), Loot.CLOTHES);
        }
        row(p, "shelf_electronics", Loot.ELECTRONICS, 3, 15, y, 17, 9, Direction.NORTH, 0.5f);
        row(p, "shelf_electronics", Loot.ELECTRONICS, 3, 15, y, 20, 9, Direction.NORTH, 0.5f);
        for (int x = 21; x <= 33; x += 2) p.loot(x, y, 18, BARREL, Loot.SPORTS);
        for (int x = 21; x <= 33; x += 2) p.loot(x, y, 21, BARREL, Loot.CLOTHES);
        // верх: книги и фудкорт
        y = fh + 1;
        row(p, "shelf_books", Loot.BOOKS, 3, 15, y, 6, 9, Direction.NORTH, 0.55f);
        row(p, "shelf_books", Loot.BOOKS, 3, 15, y, 9, 9, Direction.NORTH, 0.55f);
        for (int x = 20; x <= 32; x += 4) {
            p.table(x, y, 8);
            p.furn(x - 1, y, 8, "chair", Direction.EAST);
            p.furn(x + 1, y, 8, "chair", Direction.WEST);
        }
        for (int x = 20; x <= 32; x += 3) {
            p.furnLoot(x, y, 21, "stove", Direction.NORTH, Loot.KITCHEN);
            p.furnLoot(x + 1, y, 21, "fridge", Direction.NORTH, Loot.DINER);
        }
        row(p, "shelf_tools", Loot.HARDWARE, 3, 15, y, 18, 9, Direction.NORTH, 0.5f);
        for (int f = 0; f < n; f++) {
            int fy = f * fh + 1;
            for (int k = 0; k < 4 + p.r.nextInt(4); k++) {
                int[] c = p.freeFloor(x1 + 1, z1 + 1, x2 - 1, z2 - 1, fy);
                if (c != null) p.zombie(c[0], fy, c[1], null);
            }
        }
        p.danger = 2;
    }

    /** Библиотека (25x25): стеллажи книг навыков, читальный зал. */
    public static void library(Plan p) {
        BlockState wall = st(Blocks.STONE_BRICKS);
        int x1 = 1, x2 = 23, z1 = 2, z2 = 23, fh = 6;
        floors(p, x1, z1, x2, z2, 1, fh, wall, st(Blocks.DARK_OAK_PLANKS), GLASS);
        p.door(12, 1, z1, Blocks.DARK_OAK_DOOR, Direction.NORTH);
        for (int x = x1; x <= x2; x++) p.set(x, fh, z1, Blocks.CHISELED_STONE_BRICKS);
        for (int z = 6; z <= 20; z += 3) row(p, "shelf_books", Loot.BOOKS, 3, 10, 1, z, -9, Direction.NORTH, 0.55f);
        for (int z = 6; z <= 20; z += 4) {
            p.table(16, 1, z);
            p.table(19, 1, z);
            p.furn(17, 1, z, "chair", Direction.WEST);
            p.furn(18, 1, z, "chair", Direction.EAST);
        }
        Buildings.counter(p, 14, 21, 4);
        for (int x = x1 + 1; x <= x2 - 1; x += 2) if (x != 12) p.set(x, 1, z2 - 1, Blocks.BOOKSHELF);
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.SMOOTH_STONE);
        p.zombie(8, 1, 12, null);
        p.zombie(17, 1, 15, ZombieOutfit.CIVILIAN_JACKET);
    }

    /** Автосервис (25x25): мастерская с машиной на ремонте, запчасти, инструменты. */
    public static void autoRepair(Plan p) {
        BlockState wall = st(Blocks.LIGHT_GRAY_CONCRETE);
        int x1 = 1, x2 = 23, z1 = 3, z2 = 22, h = 6;
        p.fill(x1, 0, z1, x2, 0, z2, Blocks.GRAY_CONCRETE);
        p.walls(x1, 1, z1, x2, h, z2, wall);
        p.air(x1 + 1, 1, z1 + 1, x2 - 1, h, z2 - 1);
        p.air(4, 1, z1, 10, 4, z1);                    // ворота открыты
        p.air(14, 1, z1, 20, 4, z1);
        for (int x = x1; x <= x2; x++) p.set(x, h, z1, Blocks.BLUE_CONCRETE);
        Buildings.flatRoof(p, x1, z1, x2, z2, h + 1, st(Blocks.GRAY_CONCRETE), wall);
        p.fill(x1, 0, 0, x2, 0, z1 - 1, Blocks.GRAY_CONCRETE);
        Buildings.car(p, 6, 7, true);
        if (p.r.nextBoolean()) Buildings.car(p, 16, 7, true);
        for (int x = x1 + 1; x <= x2 - 1; x += 2) {
            if (p.r.nextFloat() < 0.6f) p.furnLoot(x, 1, z2 - 1, "shelf_tools", Direction.NORTH, Loot.AUTO);
            else p.furnLoot(x, 1, z2 - 1, "cardboard_box", Direction.NORTH, Loot.AUTO);
        }
        for (int z = z1 + 3; z <= z2 - 3; z += 3) p.loot(x2 - 1, 1, z, BARREL, Loot.AUTO);
        for (int z = z1 + 2; z <= z1 + 4; z++) p.set(x1 + 1, 1, z, Blocks.BLACK_WOOL);   // стопка покрышек
        p.set(x1 + 1, 2, z1 + 3, Blocks.BLACK_WOOL);
        p.set(12, 1, 18, Blocks.CRAFTING_TABLE);
        Buildings.lamp(p, 8, h, 12);
        Buildings.lamp(p, 16, h, 12);
        p.danger = 1;
        p.zombie(8, 1, 15, ZombieOutfit.MECHANIC);
        p.zombie(17, 1, 12, ZombieOutfit.MECHANIC);
    }

    /** Военный блокпост у въезда в город (25x12): мешки с песком, заграждения, палатка, ящики. Опасность 3. */
    public static void checkpoint(Plan p) {
        p.fill(0, 0, 0, 24, 0, 11, Blocks.GRAVEL);
        for (int x = 1; x <= 23; x++) if (x < 10 || x > 14) p.furn(x, 1, 1, x % 3 == 0 ? "road_barrier" : "sandbags", Direction.NORTH);
        for (int z = 2; z <= 9; z += 2) {
            p.furn(1, 1, z, "sandbags", Direction.WEST);
            p.furn(23, 1, z, "sandbags", Direction.EAST);
        }
        for (int x = 10; x <= 14; x += 2) p.furn(x, 1, 2, "traffic_cone", Direction.NORTH);
        // палатка
        BlockState tent = st(Blocks.GREEN_WOOL);
        for (int z = 5; z <= 10; z++) {
            p.set(3, 1, z, tent);
            p.set(9, 1, z, tent);
            p.set(4, 2, z, tent);
            p.set(8, 2, z, tent);
            p.set(5, 3, z, tent);
            p.set(7, 3, z, tent);
            p.set(6, 4, z, tent);
        }
        p.furnLoot(5, 1, 9, "army_crate", Direction.NORTH, Loot.ARMY);
        p.furnLoot(6, 1, 9, "army_crate", Direction.NORTH, Loot.ARMY);
        p.furnLoot(7, 1, 9, "army_crate", Direction.NORTH, Loot.ARMY);
        p.bed(5, 1, 6, Blocks.GREEN_BED, Direction.SOUTH);
        p.furn(16, 1, 9, "generator", Direction.NORTH);
        for (int x = 17; x <= 21; x += 2) p.furnLoot(x, 1, 9, "army_crate", Direction.NORTH, Loot.ARMY);
        p.furn(19, 1, 5, "radio", Direction.SOUTH);
        Buildings.car(p, 12, 6, false, "pickup");
        p.danger = 3;
        for (int k = 0; k < 4 + p.r.nextInt(3); k++) p.zombie(3 + p.r.nextInt(19), 1, 3 + p.r.nextInt(7), ZombieOutfit.SOLDIER);
    }
}
