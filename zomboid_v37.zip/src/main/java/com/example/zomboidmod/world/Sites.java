package com.example.zomboidmod.world;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Места между поселениями — то, ради чего хочется свернуть с шоссе: пожарные вышки, кемпинги, разбитый вертолёт,
 * лагерь эвакуации, кладбище, трейлерный парк, радиовышка, убежища выживших, пепелища, крушение самолёта, тайники;
 * у дорог — заправки, закусочные, мотели, площадки отдыха, полицейские кордоны и аварии.
 * Всё детерминировано от сида мира и строится, когда игрок подходит ближе. Найденные места отмечаются на карте.
 */
public final class Sites {
    public enum Kind {
        CABIN("Охотничий домик", 12, 12, 10),
        TOWER("Пожарная вышка", 9, 9, 7),
        CAMP("Кемпинг", 22, 18, 9),
        HELI("Место крушения вертолёта", 22, 16, 4),
        EVAC("Лагерь эвакуации", 40, 34, 3),
        GRAVEYARD("Кладбище", 30, 24, 6),
        TRAILERS("Трейлерный парк", 38, 30, 5),
        RADIO("Радиовышка", 14, 14, 4),
        SAFEHOUSE("Убежище выжившего", 12, 12, 8),
        BURNT("Пепелище", 14, 14, 7),
        PLANE("Крушение самолёта", 30, 22, 3),
        STASH("Тайник", 5, 5, 0),
        // у дороги (план: улица со стороны z = -1)
        GAS("Заправка у шоссе", 25, 12, 3),
        DINER("Придорожная закусочная", 25, 12, 2),
        MOTEL("Мотель у дороги", 25, 25, 2),
        REST("Площадка отдыха", 22, 14, 3),
        BUSSTOP("Автобусная остановка", 6, 4, 2),
        // прямо на дороге (план: поперёк дороги по x, вдоль — по z)
        ROADBLOCK("Полицейский кордон", 11, 16, 2),
        PILEUP("Авария на шоссе", 9, 16, 3);

        public final String ru;
        public final int w, d, weight;

        Kind(String ru, int w, int d, int weight) {
            this.ru = ru;
            this.w = w;
            this.d = d;
            this.weight = weight;
        }

        boolean onRoad() {
            return this == ROADBLOCK || this == PILEUP;
        }

        boolean roadside() {
            return ordinal() >= GAS.ordinal() && ordinal() <= BUSSTOP.ordinal();
        }
    }

    private static final Kind[] WILD = {Kind.CABIN, Kind.TOWER, Kind.CAMP, Kind.HELI, Kind.EVAC, Kind.GRAVEYARD, Kind.TRAILERS,
            Kind.RADIO, Kind.SAFEHOUSE, Kind.BURNT, Kind.PLANE};
    private static final Kind[] ROADSIDE = {Kind.GAS, Kind.DINER, Kind.MOTEL, Kind.REST, Kind.BUSSTOP};
    private static final Kind[] ONROAD = {Kind.ROADBLOCK, Kind.PILEUP};

    /**
     * Место в мире. (x, z) — угол участка с минимальными координатами, sx × sz — размер на местности (после поворота).
     * roadKey — кусок дороги, после которого можно строить (для мест прямо на дороге), иначе 0.
     */
    public record Site(long key, Kind kind, int x, int z, int sx, int sz, BlockRotation rot, long seed, long roadKey) {
        public int cx() {
            return x + sx / 2;
        }

        public int cz() {
            return z + sz / 2;
        }

        boolean overlaps(int ax1, int az1, int ax2, int az2, int margin) {
            return x - margin <= ax2 && x + sx - 1 + margin >= ax1 && z - margin <= az2 && z + sz - 1 + margin >= az1;
        }
    }

    private static final Map<Long, List<Site>> CACHE = new LinkedHashMap<>(64, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Long, List<Site>> e) {
            return size() > 48;
        }
    };
    private static long cacheSeed;

    private Sites() {
    }

    private static Kind pick(java.util.Random r, Kind[] kinds) {
        int total = 0;
        for (Kind k : kinds) total += k.weight;
        int n = r.nextInt(total);
        for (Kind k : kinds) {
            n -= k.weight;
            if (n < 0) return k;
        }
        return kinds[0];
    }

    /** Все места региона 512x512 (детерминированно от сида). */
    public static synchronized List<Site> region(long seed, int rx, int rz) {
        if (seed != cacheSeed) {
            CACHE.clear();
            cacheSeed = seed;
        }
        long rk = Knox.regionKey(rx, rz);
        List<Site> cached = CACHE.get(rk);
        if (cached != null) return cached;
        List<Site> out = new ArrayList<>();
        Knox.Settlement s = Knox.settlement(seed, rx, rz);
        List<Roads.Road> roads = Roads.around(seed, rx, rz);
        java.util.Random r = new java.util.Random(seed * 6364136223846793005L + rx * 1442695040888963407L + rz * 31337L + 99);
        int x0 = rx * Knox.REGION, z0 = rz * Knox.REGION;

        // ---- у дорог: заправки, закусочные, мотели, площадки отдыха; на дороге — кордоны и аварии (только на прямых участках)
        for (Roads.Road rd : roads) {
            for (int pi = 0; pi < rd.pieces(); pi++) {
                int t = pi * Roads.PIECE + Roads.PIECE / 2;
                if (t >= rd.n) continue;
                int mx = (int) Math.floor(rd.px[t]), mz = (int) Math.floor(rd.pz[t]);
                if (Math.floorDiv(mx, Knox.REGION) != rx || Math.floorDiv(mz, Knox.REGION) != rz) continue;
                long pk = rd.pieceKey(pi);
                java.util.Random pr = new java.util.Random(pk * 0x9E3779B97F4A7C15L + seed);
                float roll = pr.nextFloat();
                int axis = Roads.straight(rd, t, 16);
                if (axis == 0 || Knox.distTo(rd.a, mx, mz) < 40 || Knox.distTo(rd.b, mx, mz) < 40) continue;
                if (Math.abs(mx - x0) < 40 || Math.abs(mx - x0 - Knox.REGION) < 40 || Math.abs(mz - z0) < 40 || Math.abs(mz - z0 - Knox.REGION) < 40) continue;
                boolean alongX = axis == 1;
                Site site = null;
                if (roll < 0.075f) {
                    Kind k = pick(pr, ROADSIDE);
                    site = beside(alongX, k, mx, mz, pr.nextBoolean(), pr.nextLong(), pk);
                } else if (roll < 0.11f) {
                    Kind k = pick(pr, ONROAD);
                    if (alongX) site = new Site(0, k, mx - k.d / 2, mz - k.w / 2, k.d, k.w, BlockRotation.CLOCKWISE_90, pr.nextLong(), pk);
                    else site = new Site(0, k, mx - k.w / 2, mz - k.d / 2, k.w, k.d, BlockRotation.NONE, pr.nextLong(), pk);
                }
                if (site == null) continue;
                site = new Site(siteKey(rk, out.size()), site.kind(), site.x(), site.z(), site.sx(), site.sz(), site.rot(), site.seed(), site.roadKey());
                if (fits(site, s, roads, out, site.kind().onRoad() ? rd : null)) out.add(site);
            }
        }

        // ---- в глуши
        int want = 4 + r.nextInt(3) + (s.type() == Knox.Type.FOREST || s.type() == Knox.Type.FARMS ? 2 : 0);
        int placed = 0;
        for (int t = 0; t < 80 && placed < want; t++) {
            Kind k = pick(r, WILD);
            boolean turn = r.nextBoolean();
            int sx = turn ? k.d : k.w, sz = turn ? k.w : k.d;
            int x = x0 + 30 + r.nextInt(Knox.REGION - 60 - sx), z = z0 + 30 + r.nextInt(Knox.REGION - 60 - sz);
            BlockRotation rot = turn ? (r.nextBoolean() ? BlockRotation.CLOCKWISE_90 : BlockRotation.COUNTERCLOCKWISE_90)
                    : (r.nextBoolean() ? BlockRotation.NONE : BlockRotation.CLOCKWISE_180);
            Site site = new Site(siteKey(rk, out.size()), k, x, z, sx, sz, rot, r.nextLong(), 0);
            if (fits(site, s, roads, out, null)) {
                out.add(site);
                placed++;
            }
        }
        // ---- тайники (на них ведут карты тайников)
        int stashes = 0;
        for (int t = 0; t < 60 && stashes < 3; t++) {
            int x = x0 + 30 + r.nextInt(Knox.REGION - 65), z = z0 + 30 + r.nextInt(Knox.REGION - 65);
            Site site = new Site(siteKey(rk, out.size()), Kind.STASH, x, z, 5, 5, BlockRotation.NONE, r.nextLong(), 0);
            if (fits(site, s, roads, out, null)) {
                out.add(site);
                stashes++;
            }
        }
        CACHE.put(rk, out);
        return out;
    }

    private static long siteKey(long regionKey, int i) {
        return regionKey * 7919L + 0x5173000000000000L + i;
    }

    /** Участок рядом с дорогой: улица плана смотрит на дорогу, отступ 7 блоков от середины дороги. */
    private static Site beside(boolean alongX, Kind k, int mx, int mz, boolean plus, long seed, long roadKey) {
        int off = 7;
        if (alongX) {
            int x = mx - k.w / 2;
            if (plus) return new Site(0, k, x, mz + off, k.w, k.d, BlockRotation.NONE, seed, roadKey);
            return new Site(0, k, x, mz - off - k.d + 1, k.w, k.d, BlockRotation.CLOCKWISE_180, seed, roadKey);
        }
        int z = mz - k.w / 2;
        if (plus) return new Site(0, k, mx + off, z, k.d, k.w, BlockRotation.COUNTERCLOCKWISE_90, seed, roadKey);
        return new Site(0, k, mx - off - k.d + 1, z, k.d, k.w, BlockRotation.CLOCKWISE_90, seed, roadKey);
    }

    private static boolean fits(Site site, Knox.Settlement s, List<Roads.Road> roads, List<Site> others, Roads.Road allowed) {
        int x1 = site.x(), z1 = site.z(), x2 = site.x() + site.sx() - 1, z2 = site.z() + site.sz() - 1;
        // не в поселении
        for (int[] q : s.rects()) if (x1 <= q[2] + 20 && x2 >= q[0] - 20 && z1 <= q[3] + 20 && z2 >= q[1] - 20) return false;
        if (s.type() == Knox.Type.FOREST && Math.hypot(site.cx() - s.cx(), site.cz() - s.cz()) < 24) return false;
        // не на дорогах (кроме своей для кордонов и аварий)
        if (!Roads.clear(roads, x1, z1, x2, z2, 5.0, allowed)) return false;
        for (Site o : others) if (o.overlaps(x1, z1, x2, z2, site.kind() == Kind.STASH || o.kind() == Kind.STASH ? 12 : 24)) return false;
        return true;
    }

    // ===================== тик: стройка и находки =====================
    private static final int TRIGGER = 150;

    static void tick(ServerWorld w, ServerPlayerEntity p, Knox.MapState st) {
        long seed = w.getSeed();
        int prx = Math.floorDiv(p.getBlockX(), Knox.REGION), prz = Math.floorDiv(p.getBlockZ(), Knox.REGION);
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++)
                for (Site s : region(seed, prx + dx, prz + dz)) {
                    double dist = Math.hypot(s.cx() - p.getX(), s.cz() - p.getZ());
                    if (dist < TRIGGER && !st.done.contains(s.key()) && (s.roadKey() == 0 || st.roads.contains(s.roadKey())) && Knox.QUEUED.add(s.key()))
                        Knox.enqueue(new SiteJob(s));
                    int radius = Math.max(s.sx(), s.sz()) / 2 + (s.kind() == Kind.STASH ? 3 : 10);
                    if (dist < radius && st.found.add(s.key())) {
                        st.markDirty();
                        p.sendMessage(Text.literal("Найдено: " + s.kind().ru).formatted(s.kind() == Kind.STASH ? Formatting.GOLD : Formatting.GRAY), true);
                        w.playSound(null, p.getBlockPos(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.PLAYERS, 0.7f, 0.9f);
                        if (s.kind() == Kind.STASH) st.looted.add(s.key());
                    }
                }
    }

    /** Разведка места: высота, вода, затем выравнивание и постройка. */
    static final class SiteJob implements Knox.Job {
        final Site s;
        boolean finished;

        SiteJob(Site s) {
            this.s = s;
        }

        public int run(ServerWorld w, int budget) {
            finished = true;
            int x2 = s.x() + s.sx() - 1, z2 = s.z() + s.sz() - 1;
            List<Integer> hs = new ArrayList<>();
            int wet = 0, n = 0;
            for (int i = 0; i <= 3; i++)
                for (int j = 0; j <= 3; j++) {
                    int x = s.x() + (x2 - s.x()) * i / 3, z = s.z() + (z2 - s.z()) * j / 3;
                    int g = Knox.ground(w, x, z);
                    if (Knox.water(w, x, g, z)) wet++;
                    hs.add(g);
                    n++;
                }
            Knox.MapState st = Knox.MapState.get(w.getServer());
            if (wet > n / 4 && !s.kind().onRoad()) {
                st.done.add(s.key());
                st.markDirty();
                Knox.QUEUED.remove(s.key());
                return 50;
            }
            hs.sort(Integer::compare);
            int base;
            if (s.kind().onRoad()) {
                base = Knox.ground(w, s.cx(), s.cz());           // поверх асфальта
            } else {
                base = Math.max(w.getSeaLevel() + 1, hs.get(hs.size() / 2));
                int margin = s.kind() == Kind.STASH ? 1 : (s.kind().roadside() ? 2 : 6);
                Knox.enqueue(new Knox.FlattenJob(s.x(), s.z(), x2, z2, base, margin));
            }
            Random r = Random.create(s.seed());
            Plan p = new Plan(s.kind().w, s.kind().d, r);
            Wild.build(s.kind(), p);
            Knox.enqueue(new Knox.PlaceJob(p, s.x(), base, s.z(), s.rot()));
            Knox.enqueue(new Knox.Job() {
                boolean f;

                public int run(ServerWorld w2, int b) {
                    st.done.add(s.key());
                    st.markDirty();
                    Knox.QUEUED.remove(s.key());
                    f = true;
                    return 1;
                }

                public boolean done() {
                    return f;
                }
            });
            return 120;
        }

        public boolean done() {
            return finished;
        }
    }

    // ===================== для карты и записок =====================
    /** Найденные места в радиусе (для бумажной карты). */
    static NbtList found(long seed, Knox.MapState st, int prx, int prz, int radius) {
        NbtList list = new NbtList();
        for (int dx = -radius; dx <= radius; dx++)
            for (int dz = -radius; dz <= radius; dz++)
                for (Site s : region(seed, prx + dx, prz + dz)) {
                    if (!st.found.contains(s.key())) continue;
                    NbtCompound c = new NbtCompound();
                    c.putInt("x", s.cx());
                    c.putInt("z", s.cz());
                    c.putInt("k", s.kind().ordinal());
                    c.putString("n", s.kind().ru);
                    list.add(c);
                }
        return list;
    }

    /** Места вокруг точки (для записок и карт тайников), ближние первыми. */
    public static List<Site> near(long seed, int x, int z, Kind only) {
        int prx = Math.floorDiv(x, Knox.REGION), prz = Math.floorDiv(z, Knox.REGION);
        List<Site> out = new ArrayList<>();
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++)
                for (Site s : region(seed, prx + dx, prz + dz)) if (only == null || s.kind() == only) out.add(s);
        out.sort((a, b) -> Double.compare(Math.hypot(a.cx() - x, a.cz() - z), Math.hypot(b.cx() - x, b.cz() - z)));
        return out;
    }

    public static boolean looted(ServerWorld w, Site s) {
        return Knox.MapState.get(w.getServer()).looted.contains(s.key());
    }
}
