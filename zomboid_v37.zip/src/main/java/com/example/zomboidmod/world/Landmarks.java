package com.example.zomboidmod.world;

import com.example.zomboidmod.ZombieOutfit;
import com.example.zomboidmod.block.DecalBlock;
import com.example.zomboidmod.block.ZomboidBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.state.property.Properties;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;

import java.util.function.Consumer;

/**
 * Крупные особые места округа (каждое — на свой регион, шоссе подходят к их воротам):
 * военная база с подземным бункером, тюрьма строгого режима, исследовательский центр с подземными уровнями,
 * огромный торговый центр. Каждое строится несколькими порциями: территория, затем здания.
 */
final class Landmarks {
    private Landmarks() {
    }

    static final BlockState AIR = Blocks.AIR.getDefaultState();

    static BlockState bb(String id, Block fb) {
        return MetroBuildings.bb(id, fb);
    }

    static void build(Knox.Settlement s, int base, Random r) {
        int[] q = s.rects().get(0);
        int W = q[2] - q[0] + 1, D = q[3] - q[1] + 1;
        Knox.enqueue(new Knox.FlattenJob(q[0], q[1], q[2], q[3], base, 14));
        Plan g = new Plan(W, D, Random.create(r.nextLong()));
        Site site = new Site(q[0], q[1], base, r);
        switch (s.type()) {
            case MILITARY -> military(g, site);
            case PRISON -> prison(g, site);
            case LAB -> lab(g, site);
            default -> mall(g, site);
        }
        Knox.lot(g, q[0], base, q[1], BlockRotation.NONE);
        site.flush();
    }

    /** Здания места: ставятся отдельными работами (план собирается, только когда до него дошла очередь). */
    static final class Site {
        final int ox, oz, base;
        final Random r;
        final java.util.List<Runnable> jobs = new java.util.ArrayList<>();

        Site(int ox, int oz, int base, Random r) {
            this.ox = ox;
            this.oz = oz;
            this.base = base;
            this.r = r;
        }

        void put(int x, int z, int w, int d, BlockRotation rot, Consumer<Plan> f) {
            put(x, 0, z, w, d, rot, f);
        }

        void put(int x, int y, int z, int w, int d, BlockRotation rot, Consumer<Plan> f) {
            final long seed = r.nextLong();
            jobs.add(() -> Knox.lot(() -> {
                Plan p = new Plan(w, d, Random.create(seed));
                f.accept(p);
                return p;
            }, ox + x, base + y, oz + z, rot));
        }

        void flush() {
            for (Runnable j : jobs) j.run();
        }
    }

    // =====================================================================================
    //                                       общее
    // =====================================================================================

    static void asphalt(Plan g, int x1, int z1, int x2, int z2) {
        BlockState a = bb("asphalt", Blocks.BLACK_CONCRETE), c = bb("asphalt_cracked", Blocks.BLACK_CONCRETE);
        for (int x = Math.max(0, x1); x <= Math.min(g.w - 1, x2); x++)
            for (int z = Math.max(0, z1); z <= Math.min(g.d - 1, z2); z++) g.set(x, 0, z, g.r.nextFloat() < 0.06f ? c : a);
    }

    /** Ограждение по периметру с отступом inset, проходы шириной 2·gate+1 на осях. */
    static void perimeter(Plan g, int inset, int h, BlockState post, BlockState panel, int gate, int postStep) {
        int x1 = inset, z1 = inset, x2 = g.w - 1 - inset, z2 = g.d - 1 - inset;
        int cx = g.w / 2, cz = g.d / 2;
        for (int x = x1; x <= x2; x++)
            for (int z : new int[]{z1, z2}) {
                if (Math.abs(x - cx) <= gate) continue;
                boolean isPost = (x - x1) % postStep == 0 || x == x2;
                for (int y = 1; y <= h; y++) g.set(x, y, z, isPost ? post : panel);
            }
        for (int z = z1; z <= z2; z++)
            for (int x : new int[]{x1, x2}) {
                if (Math.abs(z - cz) <= gate) continue;
                boolean isPost = (z - z1) % postStep == 0 || z == z2;
                for (int y = 1; y <= h; y++) g.set(x, y, z, isPost ? post : panel);
            }
    }

    /** Колючая проволока: паутина поверх и вдоль забора. */
    static void wire(Plan g, int inset, int y, float chance) {
        int x1 = inset, z1 = inset, x2 = g.w - 1 - inset, z2 = g.d - 1 - inset;
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                if (x != x1 && x != x2 && z != z1 && z != z2) continue;
                if (g.get(x, y - 1, z) == null || g.r.nextFloat() > chance) continue;
                g.set(x, y, z, Blocks.COBWEB.getDefaultState());
            }
    }

    /** Вышка: опоры, лестница, площадка с мешками, прожектор, ящик. */
    static void watchTower(Plan g, int x, int z, int h, ZombieOutfit guard) {
        BlockState post = Blocks.STRIPPED_SPRUCE_LOG.getDefaultState();
        for (int y = 1; y < h; y++) {
            g.set(x, y, z, post);
            g.set(x + 2, y, z, post);
            g.set(x, y, z + 2, post);
            g.set(x + 2, y, z + 2, post);
            g.set(x + 1, y, z + 1, post);   // центральная опора с лестницей
        }
        g.fill(x - 1, h, z - 1, x + 3, h, z + 3, Blocks.SPRUCE_PLANKS.getDefaultState());
        g.ladder(x + 1, 1, h - 1, z, Direction.NORTH);
        g.set(x + 1, h, z, Blocks.SPRUCE_TRAPDOOR.getDefaultState().with(Properties.BLOCK_HALF, BlockHalf.TOP));
        for (int a = -1; a <= 3; a++) {
            g.furn(x + a, h + 1, z - 1, "sandbags", Direction.NORTH);
            g.furn(x + a, h + 1, z + 3, "sandbags", Direction.SOUTH);
        }
        g.fill(x - 1, h + 3, z - 1, x + 3, h + 3, z + 3, Blocks.SPRUCE_SLAB.getDefaultState());
        g.set(x + 1, h + 1, z + 1, Blocks.REDSTONE_LAMP.getDefaultState());
        g.furnLoot(x, h + 1, z + 1, "army_crate", Direction.EAST, guard == ZombieOutfit.SOLDIER ? Loot.ARMY : Loot.POLICE);
        g.zombie(x + 2, h + 1, z + 1, guard, 2);
    }

    /** Будка охраны у ворот со шлагбаумами и мешками. */
    static void gatePost(Plan g, int x, int z, boolean alongX, ZombieOutfit guard) {
        BlockState w = bb("concrete_panel", Blocks.LIGHT_GRAY_CONCRETE);
        g.walls(x, 1, z, x + 3, 3, z + 3, w);
        g.air(x + 1, 1, z + 1, x + 2, 3, z + 2);
        g.fill(x, 4, z, x + 3, 4, z + 3, bb("roof_tar", Blocks.GRAY_CONCRETE));
        g.set(x + 1, 2, z, Blocks.GLASS_PANE.getDefaultState());
        g.set(x + 2, 2, z + 3, Blocks.GLASS_PANE.getDefaultState());
        g.door(x + 3, 1, z + 1, Blocks.SPRUCE_DOOR, Direction.EAST);
        g.furnLoot(x + 1, 1, z + 1, "desk", Direction.NORTH, guard == ZombieOutfit.SOLDIER ? Loot.ARMY : Loot.POLICE);
        g.furn(x + 2, 1, z + 2, "radio", Direction.WEST);
        g.zombie(x + 5, 1, z + 1, guard, 2);
    }

    /** Шлагбаумы поперёк проезда у ворот. */
    static void barriers(Plan g, int c, boolean vertical, int at, int half) {
        for (int o = -half + 1; o <= half - 1; o += 2) {
            int x = vertical ? c + o : at, z = vertical ? at : c + o;
            g.furn(x, 1, z, Math.abs(o) % 4 == 1 ? "road_barrier" : "traffic_cone", vertical ? Direction.NORTH : Direction.EAST);
        }
    }

    static BlockState decal(Plan g, Block b) {
        return b.getDefaultState().with(DecalBlock.VARIANT, g.r.nextInt(4)).with(DecalBlock.FACING, Direction.Type.HORIZONTAL.random(g.r));
    }

    static void scatter(Plan g, int x1, int z1, int x2, int z2, int n, ZombieOutfit o, int tier) {
        for (int k = 0; k < n; k++) {
            int x = x1 + g.r.nextInt(Math.max(1, x2 - x1)), z = z1 + g.r.nextInt(Math.max(1, z2 - z1));
            if (g.get(x, 1, z) != null) continue;
            g.zombie(x, 1, z, g.r.nextFloat() < 0.7f ? o : null, tier);
            if (g.r.nextFloat() < 0.3f) g.set(x, 1, z, decal(g, ZomboidBlocks.BLOOD));
        }
    }

    /** Палатка (белая или защитная) с кроватями. */
    static void tent(Plan g, int x, int z, int w, int d, Block cloth, Loot loot) {
        for (int xx = x; xx < x + w; xx++)
            for (int zz = z; zz < z + d; zz++) {
                boolean edge = xx == x || xx == x + w - 1;
                g.set(xx, 1, zz, edge ? cloth.getDefaultState() : AIR);
                g.set(xx, 2, zz, (xx == x + 1 || xx == x + w - 2) ? cloth.getDefaultState() : AIR);
                g.set(xx, 3, zz, (xx >= x + 2 && xx <= x + w - 3) ? cloth.getDefaultState() : AIR);
                if (zz == z || zz == z + d - 1) {
                    if (Math.abs(xx - (x + w / 2)) > 0) g.set(xx, 1, zz, cloth.getDefaultState());
                    g.set(xx, 2, zz, xx > x && xx < x + w - 1 ? cloth.getDefaultState() : g.get(xx, 2, zz));
                }
            }
        for (int zz = z + 1; zz < z + d - 2; zz += 2) g.bed(x + 1, 1, zz, Blocks.WHITE_BED, Direction.EAST);
        g.furnLoot(x + w - 2, 1, z + d - 2, "army_crate", Direction.WEST, loot);
    }

    /** Лестница вниз прямым маршем (с потолком и стенами в грунте): ступени от (x, yTop, z) в сторону dir, ширина 2. */
    static void descend(Plan p, int x, int z, int yTop, int depth, Direction dir, BlockState wall) {
        int dx = dir.getOffsetX(), dz = dir.getOffsetZ();
        int sx = dz != 0 ? 1 : 0, sz = dx != 0 ? 1 : 0;   // поперёк хода
        for (int k = 0; k < depth; k++) {
            int cx = x + dx * k, cz = z + dz * k, y = yTop - k;
            for (int w = 0; w < 2; w++) {
                int px = cx + sx * w, pz = cz + sz * w;
                p.set(px, y, pz, Blocks.STONE_BRICK_STAIRS.getDefaultState().with(StairsBlock.FACING, dir.getOpposite()));
                p.set(px, y - 1, pz, wall);
                for (int a = 1; a <= 3; a++) p.set(px, y + a, pz, AIR);
                p.set(px, y + 4, pz, wall);
            }
            for (int yy = y - 1; yy <= y + 4; yy++) {
                p.set(cx - sx, yy, cz - sz, wall);
                p.set(cx + sx * 2, yy, cz + sz * 2, wall);
            }
        }
    }

    /** Подземное помещение: пол, стены, потолок, воздух внутри. */
    static void room(Plan p, int x1, int z1, int x2, int z2, int y, int h, BlockState wall, BlockState floor) {
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                boolean edge = x == x1 || x == x2 || z == z1 || z == z2;
                p.set(x, y, z, edge ? wall : floor);
                p.set(x, y + h + 1, z, wall);
                for (int yy = y + 1; yy <= y + h; yy++) p.set(x, yy, z, edge ? wall : AIR);
            }
    }

    static void opening(Plan p, int x, int y, int z) {
        p.set(x, y + 1, z, AIR);
        p.set(x, y + 2, z, AIR);
    }

    static void wallLamp(Plan p, int x, int y, int z) {
        p.set(x, y, z, Blocks.LANTERN.getDefaultState().with(net.minecraft.block.LanternBlock.HANGING, true));
    }

    // =====================================================================================
    //                                    ВОЕННАЯ БАЗА
    // =====================================================================================

    static void military(Plan g, Site s) {
        int W = g.w, D = g.d, cx = W / 2, cz = D / 2;
        BlockState post = bb("concrete_dark", Blocks.GRAY_CONCRETE), bars = Blocks.IRON_BARS.getDefaultState();
        // дороги: крест и кольцо
        asphalt(g, cx - 3, 0, cx + 3, D - 1);
        asphalt(g, 0, cz - 3, W - 1, cz + 3);
        for (int k : new int[]{18, W - 19}) asphalt(g, k - 3, 15, k + 3, D - 16);
        for (int k : new int[]{18, D - 19}) asphalt(g, 15, k - 3, W - 16, k + 3);
        // двойной забор с колючкой
        perimeter(g, 2, 3, post, bars, 5, 5);
        perimeter(g, 7, 3, post, bars, 5, 5);
        wire(g, 2, 4, 0.5f);
        for (int x = 3; x < W - 3; x += 3) if (Math.abs(x - cx) > 5 && g.r.nextFloat() < 0.5f) {
            g.set(x, 1, 4 + g.r.nextInt(2), Blocks.COBWEB.getDefaultState());
            g.set(x, 1, D - 5 - g.r.nextInt(2), Blocks.COBWEB.getDefaultState());
        }
        // ворота с будками и шлагбаумами
        gatePost(g, cx + 6, 9, true, ZombieOutfit.SOLDIER);
        gatePost(g, cx - 10, D - 13, true, ZombieOutfit.SOLDIER);
        gatePost(g, 9, cz + 6, false, ZombieOutfit.SOLDIER);
        gatePost(g, W - 13, cz - 10, false, ZombieOutfit.SOLDIER);
        barriers(g, cx, true, 5, 4);
        barriers(g, cx, true, D - 6, 4);
        barriers(g, cz, false, 5, 4);
        barriers(g, cz, false, W - 6, 4);
        for (int[] t : new int[][]{{4, 4}, {W - 7, 4}, {4, D - 7}, {W - 7, D - 7}}) watchTower(g, t[0] + 1, t[1] + 1, 9, ZombieOutfit.SOLDIER);
        // плац у штаба
        for (int x = 24; x < 56; x++) for (int z = 46; z < 58; z++) g.set(x, 0, z, bb("floor_concrete", Blocks.LIGHT_GRAY_CONCRETE));
        g.fill(39, 1, 51, 39, 9, 51, Blocks.IRON_BARS.getDefaultState());
        g.set(39, 10, 51, Blocks.WHITE_BANNER.getDefaultState());
        // ---- северо-запад: штаб, оружейная, столовая, вход в бункер
        s.put(24, 24, 32, 20, BlockRotation.NONE, Landmarks::hq);
        s.put(62, 24, 22, 16, BlockRotation.NONE, Landmarks::armory);
        s.put(24, 62, 28, 16, BlockRotation.NONE, Landmarks::messHall);
        s.put(60, 46, 40, 36, BlockRotation.NONE, Landmarks::bunker);
        // ---- северо-восток: казармы
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 3; j++) s.put(cx + 8 + i * 40, 24 + j * 20, 32, 14, BlockRotation.NONE, Landmarks::barracks);
        // ---- юго-запад: автопарк, заправка, водонапорная башня
        s.put(24, cz + 8, 34, 22, BlockRotation.NONE, Landmarks::motorPool);
        for (int k = 0; k < 6; k++)
            g.vehicle(26 + k * 5.5, 1, cz + 40, g.r.nextBoolean() ? "pickup" : "van", 0f, g.r.nextFloat() < 0.3f);
        for (int k = 0; k < 2; k++) g.furn(64 + k * 3, 1, cz + 12, "gas_pump", Direction.NORTH);
        for (int y = 1; y <= 4; y++)
            for (int a = 0; a < 3; a++) for (int b = 0; b < 3; b++) g.set(64 + a, y, cz + 16 + b, Blocks.IRON_BLOCK.getDefaultState());
        s.put(62, cz + 30, 12, 12, BlockRotation.NONE, MetroBuildings::waterTower);
        // ---- юго-восток: вертолётная площадка с разбитым вертолётом, полевой госпиталь, стрельбище
        Sites.Kind heli = Sites.Kind.HELI;
        s.put(cx + 10, cz + 8, heli.w, heli.d, BlockRotation.NONE, p -> Wild.build(heli, p));
        for (int k = 0; k < 3; k++) tent(g, cx + 40 + k * 13, cz + 8, 10, 12, Blocks.WHITE_WOOL, Loot.HOSPITAL);
        for (int k = 0; k < 4; k++) scatter(g, cx + 40, cz + 8, cx + 80, cz + 22, 2, ZombieOutfit.HAZMAT, 2);
        int rz = cz + 34;
        for (int x = cx + 10; x < W - 20; x++) g.set(x, 0, rz, Blocks.GRAVEL.getDefaultState());
        for (int x = cx + 12; x < W - 22; x += 6) {
            g.furn(x, 1, rz + 1, "sandbags", Direction.SOUTH);
            g.set(x + 1, 1, rz + 18, Blocks.HAY_BLOCK.getDefaultState());
            g.set(x + 1, 2, rz + 18, Blocks.TARGET.getDefaultState());
        }
        // солдаты по всей территории
        scatter(g, 12, 12, W - 12, D - 12, 22 + g.r.nextInt(10), ZombieOutfit.SOLDIER, 3);
        for (int k = 0; k < 14; k++) {
            int x = 12 + g.r.nextInt(W - 24), z = 12 + g.r.nextInt(D - 24);
            if (g.get(x, 1, z) == null) g.furnLoot(x, 1, z, "army_crate", Direction.Type.HORIZONTAL.random(g.r), g.r.nextFloat() < 0.3f ? Loot.ARMY : Loot.WAREHOUSE);
        }
        g.danger = 3;
    }

    /** Штаб: дежурный, кабинеты, радиорубка, кабинет командира с сейфом, второй этаж. */
    static void hq(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 4;
        BlockState wall = bb("brick_tan", Blocks.SANDSTONE), inner = bb("drywall", Blocks.WHITE_CONCRETE);
        for (int k = 0; k <= 2; k++) p.fill(0, k * fh, 0, x2, k * fh, z2, k == 0 ? bb("floor_linoleum", Blocks.WHITE_CONCRETE) : bb("office_carpet", Blocks.GRAY_WOOL));
        for (int k = 0; k < 2; k++) {
            MetroBuildings.storey(p, 0, 0, x2, z2, k * fh, fh, wall, Blocks.GLASS_PANE.getDefaultState(), wall, 1);
            p.air(1, k * fh + 1, 1, x2 - 1, k * fh + fh - 1, z2 - 1);
        }
        MetroBuildings.roof(p, 0, 0, x2, z2, 2 * fh, wall, false);
        p.door(p.w / 2, 1, 0, Blocks.SPRUCE_DOOR, Direction.NORTH);
        for (int x = p.w / 2 - 3; x <= p.w / 2 + 3; x++) p.set(x, 1, 5, Blocks.SPRUCE_PLANKS.getDefaultState());
        p.furnLoot(p.w / 2, 1, 6, "desk", Direction.NORTH, Loot.ARMY);
        // радиорубка
        for (int z = 1; z < z2; z++) for (int y = 1; y < fh; y++) p.set(8, y, z, inner);
        MetroBuildings.restroom(p, 0, z2 - 6, 7, z2, 0, inner, Direction.EAST);
        p.set(8, 1, 3, AIR);
        p.set(8, 2, 3, AIR);
        for (int z = 2; z < z2 - 7; z += 2) p.furn(1, 1, z, "radio", Direction.EAST);
        p.furnLoot(3, 1, 2, "desk", Direction.WEST, Loot.ELECTRONICS);
        Houses.staircase(p, x2 - 2, 0, 3, fh - 1, Direction.SOUTH, Blocks.SPRUCE_STAIRS);
        // второй этаж: кабинеты, карта, кабинет командира
        int y = fh;
        for (int x = 3; x < x2 - 4; x += 5) {
            p.furnLoot(x, y + 1, 3, "desk", Direction.SOUTH, Loot.OFFICE);
            p.furn(x, y + 1, 4, "chair", Direction.NORTH);
        }
        p.set(p.w / 2, y + 1, p.d / 2, Blocks.CARTOGRAPHY_TABLE.getDefaultState());
        for (int x = 1; x < 10; x++) for (int yy = y + 1; yy < y + fh; yy++) p.set(x, yy, z2 - 7, inner);
        p.door(5, y + 1, z2 - 7, Blocks.DARK_OAK_DOOR, Direction.NORTH);
        p.furnLoot(4, y + 1, z2 - 2, "desk", Direction.NORTH, Loot.ARMY);
        p.loot(1, y + 1, z2 - 1, Blocks.CHEST.getDefaultState(), Loot.STASH);
        p.note(4, y + 1, z2 - 2, Stories.T_MILITARY);
        p.furn(7, y + 1, z2 - 2, "armchair", Direction.NORTH);
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, fh - 1, 6);
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, 2 * fh - 1, 6);
        MetroBuildings.zombies(p, 1, 1, x2 - 1, z2 - 1, 1, 3, ZombieOutfit.SOLDIER);
        MetroBuildings.zombies(p, 1, 1, x2 - 1, z2 - 1, y + 1, 2, ZombieOutfit.SOLDIER);
        p.danger = 3;
    }

    /** Оружейная: бетон, железная дверь с кнопкой, стойки с оружием, ящики с патронами. */
    static void armory(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1;
        BlockState wall = bb("concrete_dark", Blocks.GRAY_CONCRETE);
        p.fill(0, 0, 0, x2, 0, z2, bb("floor_concrete", Blocks.LIGHT_GRAY_CONCRETE));
        p.walls(0, 1, 0, x2, 4, z2, wall);
        p.air(1, 1, 1, x2 - 1, 4, z2 - 1);
        p.fill(0, 5, 0, x2, 5, z2, wall);
        p.door(p.w / 2, 1, 0, Blocks.IRON_DOOR, Direction.NORTH);
        p.set(p.w / 2 + 1, 2, -1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        for (int x = 1; x < x2; x++) p.furnLoot(x, 1, z2 - 1, x % 2 == 0 ? "gun_rack" : "army_crate", Direction.NORTH, Loot.ARMY);
        for (int z = 3; z < z2 - 2; z++) {
            p.furnLoot(1, 1, z, "gun_rack", Direction.EAST, Loot.ARMY);
            p.furnLoot(x2 - 1, 1, z, "army_crate", Direction.WEST, z % 2 == 0 ? Loot.ARMY : Loot.GUNSTORE);
        }
        for (int x = 4; x < x2 - 3; x += 4) p.furnLoot(x, 1, p.d / 2, "display_case", Direction.NORTH, Loot.GUNSTORE);
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, 4, 5);
        p.zombie(3, 1, 3, ZombieOutfit.SOLDIER, 3);
        p.danger = 3;
    }

    /** Казарма: ряды коек, шкафчики, душевая. */
    static void barracks(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1;
        BlockState wall = bb("metal_siding", Blocks.LIGHT_GRAY_CONCRETE);
        p.fill(0, 0, 0, x2, 0, z2, bb("floor_linoleum", Blocks.WHITE_CONCRETE));
        MetroBuildings.storey(p, 0, 0, x2, z2, 0, 4, wall, Blocks.GLASS_PANE.getDefaultState(), wall, 1);
        p.air(1, 1, 1, x2 - 1, 3, z2 - 1);
        p.fill(0, 4, 0, x2, 4, z2, bb("roof_tar", Blocks.GRAY_CONCRETE));
        p.door(2, 1, 0, Blocks.SPRUCE_DOOR, Direction.NORTH);
        p.door(x2 - 2, 1, z2, Blocks.SPRUCE_DOOR, Direction.SOUTH);
        for (int x = 4; x < x2 - 6; x += 3) {
            p.bed(x, 1, 1, Blocks.GREEN_BED, Direction.NORTH);
            p.furnLoot(x + 1, 1, 1, "wardrobe", Direction.SOUTH, p.r.nextFloat() < 0.3f ? Loot.ARMY : Loot.CLOTHES);
            p.bed(x, 1, z2 - 2, Blocks.GREEN_BED, Direction.SOUTH);
            p.furnLoot(x + 1, 1, z2 - 1, "nightstand", Direction.NORTH, Loot.BEDROOM);
        }
        MetroBuildings.restroom(p, x2 - 6, 1, x2 - 1, z2 - 4, 0, bb("tile_white", Blocks.WHITE_CONCRETE), Direction.WEST);
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, 3, 6);
        MetroBuildings.decals(p, 1, 1, x2 - 1, z2 - 1, 1, 0.02f);
        MetroBuildings.zombies(p, 1, 1, x2 - 1, z2 - 1, 1, 2 + p.r.nextInt(3), ZombieOutfit.SOLDIER);
        p.danger = 2;
    }

    /** Столовая: длинные столы, раздача, кухня. */
    static void messHall(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1;
        BlockState wall = bb("brick_tan", Blocks.SANDSTONE);
        p.fill(0, 0, 0, x2, 0, z2, bb("floor_tile", Blocks.WHITE_CONCRETE));
        MetroBuildings.storey(p, 0, 0, x2, z2, 0, 5, wall, Blocks.GLASS_PANE.getDefaultState(), wall, 1);
        p.air(1, 1, 1, x2 - 1, 4, z2 - 1);
        p.fill(0, 5, 0, x2, 5, z2, bb("roof_tar", Blocks.GRAY_CONCRETE));
        p.door(p.w / 2, 1, 0, Blocks.SPRUCE_DOOR, Direction.NORTH);
        for (int z = 3; z < z2 - 5; z += 3)
            for (int x = 3; x < x2 - 2; x++) {
                if (x % 8 == 0) continue;
                p.table(x, 1, z);
                if (p.r.nextFloat() < 0.6f) p.furn(x, 1, z + 1, "chair", Direction.NORTH);
            }
        for (int x = 1; x < x2; x++) p.furnLoot(x, 1, z2 - 1, x % 3 == 0 ? "stove" : (x % 3 == 1 ? "fridge" : "kitchen_counter"), Direction.NORTH,
                x % 3 == 1 ? Loot.FRIDGE : Loot.DINER);
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, 4, 6);
        MetroBuildings.zombies(p, 1, 1, x2 - 1, z2 - 1, 1, 3, ZombieOutfit.SOLDIER);
    }

    /** Автопарк: ангар с воротами, грузовики, верстаки, запчасти. */
    static void motorPool(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1;
        BlockState wall = bb("metal_siding", Blocks.LIGHT_GRAY_CONCRETE);
        p.fill(0, 0, 0, x2, 0, z2, bb("floor_concrete", Blocks.LIGHT_GRAY_CONCRETE));
        p.walls(0, 1, 0, x2, 7, z2, wall);
        p.air(1, 1, 1, x2 - 1, 7, z2 - 1);
        for (int x = 0; x <= x2; x++) p.set(x, 8, 0, wall);
        p.fill(0, 8, 0, x2, 8, z2, wall);
        for (int k = 0; k < 3; k++) {
            int gx = 3 + k * 10;
            if (gx + 5 >= x2) break;
            p.air(gx, 1, 0, gx + 5, 5, 0);
            if (p.r.nextFloat() < 0.6f) p.vehicle(gx + 3, 1, 8.5, p.r.nextBoolean() ? "pickup" : "van", 0f, p.r.nextFloat() < 0.25f);
        }
        for (int x = 2; x < x2 - 1; x += 3) p.furnLoot(x, 1, z2 - 1, x % 2 == 0 ? "shelf_tools" : "cardboard_box", Direction.NORTH, Loot.AUTO);
        p.furn(1, 1, z2 - 3, "generator", Direction.EAST);
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, 7, 7);
        MetroBuildings.zombies(p, 1, 1, x2 - 1, z2 - 1, 1, 2, ZombieOutfit.MECHANIC);
        p.danger = 2;
    }

    /**
     * Бункер: бетонная будка с бронедверью на поверхности, марш вниз на 13 блоков, коридор, командный пункт,
     * спальный блок, склад, генераторная и хранилище оружия.
     */
    static void bunker(Plan p) {
        BlockState conc = bb("concrete_dark", Blocks.GRAY_CONCRETE), floor = bb("floor_concrete", Blocks.LIGHT_GRAY_CONCRETE);
        BlockState inner = bb("concrete_panel", Blocks.LIGHT_GRAY_CONCRETE);
        // будка
        p.walls(0, 1, 0, 9, 4, 6, conc);
        p.air(1, 1, 1, 8, 4, 5);
        p.fill(0, 5, 0, 9, 5, 6, conc);
        p.fill(1, 0, 1, 8, 0, 5, floor);
        p.door(0, 1, 3, Blocks.IRON_DOOR, Direction.WEST);
        p.set(-1, 2, 2, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.WEST)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        p.set(1, 2, 2, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.EAST)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        for (int z = 1; z <= 5; z++) p.set(9, 1, z, conc);
        // марш вниз на восток
        int depth = 13;
        p.air(9, 1, 2, 9, 4, 3);
        descend(p, 9, 2, 0, depth, Direction.EAST, conc);
        int y0 = -depth;          // блок пола бункера: последняя ступень стоит прямо на нём
        // коридор
        int ex = 9 + depth;
        room(p, ex, 0, p.w - 1, 6, y0, 4, conc, floor);
        p.set(ex, y0 + 1, 2, AIR);
        p.set(ex, y0 + 1, 3, AIR);
        p.set(ex, y0 + 2, 2, AIR);
        p.set(ex, y0 + 2, 3, AIR);
        int midX = (ex + p.w) / 2;
        // командный пункт и спальный блок к югу от коридора
        room(p, ex, 6, midX, 20, y0, 4, conc, floor);
        room(p, midX, 6, p.w - 1, 20, y0, 4, conc, floor);
        // склад и генераторная+оружейная ещё южнее
        room(p, ex, 20, midX, p.d - 1, y0, 4, conc, floor);
        room(p, midX, 20, p.w - 1, p.d - 1, y0, 4, conc, floor);
        opening(p, ex + 3, y0, 6);
        opening(p, midX + 3, y0, 6);
        opening(p, ex + 3, y0, 20);
        opening(p, midX + 3, y0, 20);
        opening(p, midX, y0, 13);
        opening(p, midX, y0, 27);
        int y = y0 + 1;
        // командный пункт
        for (int x = ex + 1; x < midX - 1; x += 2) p.furn(x, y, 7, "radio", Direction.SOUTH);
        p.set((ex + midX) / 2, y, 13, Blocks.CARTOGRAPHY_TABLE.getDefaultState());
        p.furnLoot(ex + 1, y, 18, "desk", Direction.NORTH, Loot.ARMY);
        p.note(ex + 1, y, 18, Stories.T_MILITARY);
        for (int x = ex + 3; x < midX - 1; x += 3) p.furn(x, y, 19, "tv", Direction.NORTH);
        // спальный блок
        for (int x = midX + 2; x < p.w - 2; x += 2) {
            p.bed(x, y, 7, Blocks.GREEN_BED, Direction.NORTH);
            p.bed(x, y, 18, Blocks.GREEN_BED, Direction.SOUTH);
        }
        for (int x = midX + 2; x < p.w - 2; x += 4) p.furnLoot(x, y, 13, "wardrobe", Direction.NORTH, Loot.ARMY);
        // склад: стеллажи с припасами
        for (int x = ex + 1; x < midX - 1; x += 2)
            for (int z = 22; z < p.d - 2; z += 3) {
                Loot l = switch ((x + z) % 4) {
                    case 0 -> Loot.ARMY;
                    case 1 -> Loot.HOSPITAL;
                    case 2 -> Loot.GROCERY;
                    default -> Loot.WAREHOUSE;
                };
                p.furnLoot(x, y, z, (x + z) % 2 == 0 ? "army_crate" : "cardboard_box", Direction.NORTH, l);
            }
        // генераторная и хранилище
        p.furn(midX + 2, y, 22, "generator", Direction.EAST);
        p.furn(midX + 2, y, 24, "generator", Direction.EAST);
        for (int z = 22; z < p.d - 2; z++) p.loot(midX + 4, y, z, Blocks.BARREL.getDefaultState(), Loot.GARAGE);
        for (int x = midX + 6; x < p.w - 1; x++) p.furnLoot(x, y, p.d - 2, x % 2 == 0 ? "gun_rack" : "army_crate", Direction.NORTH, Loot.ARMY);
        // свет — редкие фонари
        for (int x = ex + 2; x < p.w - 2; x += 8) {
            wallLamp(p, x, y0 + 4, 3);
            wallLamp(p, x, y0 + 4, 13);
            wallLamp(p, x, y0 + 4, 27);
        }
        MetroBuildings.decals(p, ex, 1, p.w - 2, p.d - 2, y, 0.02f);
        MetroBuildings.zombies(p, ex, 1, p.w - 2, p.d - 2, y, 4 + p.r.nextInt(3), ZombieOutfit.SOLDIER);
        MetroBuildings.zombies(p, ex, 1, p.w - 2, p.d - 2, y, 2, ZombieOutfit.HAZMAT);
        p.danger = 3;
    }

    // =====================================================================================
    //                                       ТЮРЬМА
    // =====================================================================================

    static void prison(Plan g, Site s) {
        int W = g.w, D = g.d, cx = W / 2, cz = D / 2;
        BlockState wall = bb("concrete_panel", Blocks.LIGHT_GRAY_CONCRETE), post = bb("concrete_dark", Blocks.GRAY_CONCRETE);
        BlockState walk = bb("floor_concrete", Blocks.LIGHT_GRAY_CONCRETE);
        // внешний забор, высокая стена с колючкой, дорожки
        perimeter(g, 1, 3, post, Blocks.IRON_BARS.getDefaultState(), 5, 6);
        perimeter(g, 6, 7, post, wall, 4, 8);
        for (int x = 6; x < W - 6; x++)
            for (int z : new int[]{6, D - 7}) if (g.get(x, 7, z) != null) g.set(x, 8, z, Blocks.IRON_BARS.getDefaultState());
        for (int z = 6; z < D - 6; z++)
            for (int x : new int[]{6, W - 7}) if (g.get(x, 7, z) != null) g.set(x, 8, z, Blocks.IRON_BARS.getDefaultState());
        wire(g, 6, 9, 0.4f);
        for (int x = 0; x < W; x++) for (int dz = -3; dz <= 3; dz++) g.set(x, 0, cz + dz, walk);
        for (int z = 0; z < D; z++) for (int dx = -3; dx <= 3; dx++) g.set(cx + dx, 0, z, walk);
        // шлюзы ворот: решётки наполовину открыты
        for (int o : new int[]{-4, -3, -2}) {
            for (int y = 1; y <= 6; y++) {
                g.set(cx + o, y, 6, Blocks.IRON_BARS.getDefaultState());
                g.set(cx - o, y, D - 7, Blocks.IRON_BARS.getDefaultState());
                g.set(6, y, cz + o, Blocks.IRON_BARS.getDefaultState());
                g.set(W - 7, y, cz - o, Blocks.IRON_BARS.getDefaultState());
            }
        }
        gatePost(g, cx + 6, 9, true, ZombieOutfit.POLICE);
        // угловые вышки
        for (int[] t : new int[][]{{7, 7}, {W - 11, 7}, {7, D - 11}, {W - 11, D - 11}}) watchTower(g, t[0] + 1, t[1] + 1, 11, ZombieOutfit.POLICE);
        // корпуса
        s.put(12, 12, 36, 24, BlockRotation.NONE, Landmarks::prisonAdmin);
        s.put(cx + 8, 12, 56, 28, BlockRotation.NONE, p -> cellBlock(p, 3));
        s.put(12, cz + 8, 56, 28, BlockRotation.NONE, p -> cellBlock(p, 2));
        s.put(12, 42, 32, 20, BlockRotation.NONE, Landmarks::cafeteria);
        s.put(cx + 8, cz + 8, 22, 16, BlockRotation.NONE, Landmarks::infirmary);
        s.put(cx + 34, cz + 8, 26, 16, BlockRotation.NONE, Landmarks::workshop);
        // прогулочный двор: баскетбол, турники, трибуны, сетка
        int yx = cx + 8, yz = cz + 30, yw = 50, yd = 36;
        for (int x = yx; x < yx + yw && x < W - 8; x++)
            for (int z = yz; z < yz + yd && z < D - 8; z++) {
                boolean edge = x == yx || z == yz || x == yx + yw - 1 || z == yz + yd - 1;
                g.set(x, 0, z, Blocks.GRAY_CONCRETE.getDefaultState());
                if (edge && !(x == yx && Math.abs(z - (yz + yd / 2)) < 2)) for (int y = 1; y <= 4; y++) g.set(x, y, z, Blocks.IRON_BARS.getDefaultState());
            }
        for (int x = yx + 4; x < yx + 22; x++) g.set(x, 0, yz + 8, Blocks.WHITE_CONCRETE.getDefaultState());
        for (int y = 1; y <= 3; y++) g.set(yx + 4, y, yz + 4, Blocks.IRON_BARS.getDefaultState());
        g.set(yx + 4, 4, yz + 4, Blocks.WHITE_CONCRETE.getDefaultState());
        for (int k = 0; k < 3; k++)
            for (int x = yx + 28; x < yx + 44; x++) g.set(x, 1 + k, yz + 4 + k, MetroBuildings.stair(Blocks.STONE_BRICK_STAIRS, Direction.NORTH, false));
        for (int k = 0; k < 4; k++) g.set(yx + 10 + k * 3, 1, yz + 20, Blocks.ANVIL.getDefaultState());
        // заключённые повсюду, охрана у корпусов
        scatter(g, 10, 10, W - 10, D - 10, 26 + g.r.nextInt(10), ZombieOutfit.PRISONER, 1);
        scatter(g, 10, 10, W - 10, D - 10, 8, ZombieOutfit.POLICE, 2);
        g.danger = 2;
    }

    /** Администрация: проходная, кабинеты, пост видеонаблюдения, оружейная, комната свиданий. */
    static void prisonAdmin(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 4;
        BlockState wall = bb("brick_tan", Blocks.SANDSTONE), inner = bb("drywall", Blocks.WHITE_CONCRETE);
        for (int k = 0; k <= 2; k++) p.fill(0, k * fh, 0, x2, k * fh, z2, bb("floor_linoleum", Blocks.WHITE_CONCRETE));
        for (int k = 0; k < 2; k++) {
            MetroBuildings.storey(p, 0, 0, x2, z2, k * fh, fh, wall, Blocks.GLASS_PANE.getDefaultState(), wall, 1);
            p.air(1, k * fh + 1, 1, x2 - 1, k * fh + fh - 1, z2 - 1);
        }
        MetroBuildings.roof(p, 0, 0, x2, z2, 2 * fh, wall, false);
        p.door(p.w / 2, 1, 0, Blocks.IRON_DOOR, Direction.NORTH);
        p.set(p.w / 2 + 1, 2, -1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        p.set(p.w / 2 - 1, 2, 1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.SOUTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        // проходная с решёткой
        for (int x = 1; x < x2; x++) {
            p.set(x, 1, 6, Blocks.SPRUCE_PLANKS.getDefaultState());
            p.set(x, 2, 6, Blocks.IRON_BARS.getDefaultState());
        }
        p.set(2, 1, 6, AIR);
        p.set(2, 2, 6, AIR);
        p.furnLoot(p.w / 2, 1, 7, "desk", Direction.NORTH, Loot.POLICE);
        // пост видеонаблюдения
        for (int x = 1; x < 12; x++) for (int y = 1; y < fh; y++) p.set(x, y, 14, inner);
        p.set(6, 1, 14, AIR);
        p.set(6, 2, 14, AIR);
        for (int x = 1; x < 11; x++) p.furn(x, 2, z2 - 1, "tv", Direction.NORTH);
        for (int x = 1; x < 11; x++) p.set(x, 1, z2 - 1, Blocks.SPRUCE_PLANKS.getDefaultState());
        // оружейная за железной дверью
        for (int z = 14; z < z2; z++) for (int y = 1; y < fh; y++) p.set(x2 - 9, y, z, Blocks.IRON_BLOCK.getDefaultState());
        for (int x = x2 - 9; x < x2; x++) for (int y = 1; y < fh; y++) p.set(x, y, 14, Blocks.IRON_BLOCK.getDefaultState());
        p.door(x2 - 5, 1, 14, Blocks.IRON_DOOR, Direction.NORTH);
        p.set(x2 - 4, 2, 13, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        for (int x = x2 - 8; x < x2; x++) p.furnLoot(x, 1, z2 - 1, x % 2 == 0 ? "gun_rack" : "army_crate", Direction.NORTH, Loot.POLICE);
        // второй этаж: кабинеты, кабинет начальника
        Houses.staircase(p, x2 - 2, 0, 1, fh - 1, Direction.SOUTH, Blocks.STONE_BRICK_STAIRS);
        int y = fh;
        for (int x = 3; x < x2 - 4; x += 5)
            for (int z = 3; z < z2 - 2; z += 5) {
                p.furnLoot(x, y + 1, z, "desk", Direction.SOUTH, Loot.OFFICE);
                p.furn(x, y + 1, z + 1, "chair", Direction.NORTH);
            }
        p.loot(1, y + 1, z2 - 1, Blocks.CHEST.getDefaultState(), Loot.POLICE);
        p.note(1, y + 1, z2 - 1, Stories.T_PRISON);
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, fh - 1, 6);
        MetroBuildings.zombies(p, 1, 1, x2 - 1, z2 - 1, 1, 3, ZombieOutfit.POLICE);
        MetroBuildings.zombies(p, 1, 1, x2 - 1, z2 - 1, y + 1, 2, ZombieOutfit.POLICE);
        p.danger = 2;
    }

    /** Тюремный корпус: камеры в 2–3 яруса вдоль центрального зала, галереи с перилами, пост охраны. */
    static void cellBlock(Plan p, int tiers) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 4;
        BlockState wall = bb("concrete_panel", Blocks.LIGHT_GRAY_CONCRETE), floor = bb("floor_concrete", Blocks.LIGHT_GRAY_CONCRETE);
        BlockState bars = Blocks.IRON_BARS.getDefaultState(), cellWall = bb("concrete_dark", Blocks.GRAY_CONCRETE);
        p.fill(0, 0, 0, x2, 0, z2, floor);
        p.walls(0, 1, 0, x2, tiers * fh, z2, wall);
        p.air(1, 1, 1, x2 - 1, tiers * fh, z2 - 1);
        p.fill(0, tiers * fh + 1, 0, x2, tiers * fh + 1, z2, wall);
        for (int x = 4; x < x2; x += 6) p.set(x, tiers * fh + 1, p.d / 2, Blocks.GLASS.getDefaultState());   // световые окна
        for (int x = 2; x < x2; x += 4) for (int k = 0; k < tiers; k++) p.set(x, k * fh + 3, 0, bars);       // узкие окна
        p.door(p.w / 2, 1, 0, Blocks.IRON_DOOR, Direction.NORTH);
        p.set(p.w / 2 + 1, 2, -1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        p.set(p.w / 2 - 1, 2, 1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.SOUTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        int cellD = 6, nz1 = 1, nz2 = nz1 + cellD - 1, sz2 = z2 - 1, sz1 = sz2 - cellD + 1;
        for (int k = 0; k < tiers; k++) {
            int y = k * fh;
            if (k > 0) {   // галереи перед камерами и перекрытия камер
                p.fill(1, y, nz1, x2 - 1, y, nz2 + 2, floor);
                p.fill(1, y, sz1 - 2, x2 - 1, y, sz2, floor);
                for (int x = 1; x < x2; x++) {
                    p.set(x, y + 1, nz2 + 3, bars);
                    p.set(x, y + 1, sz1 - 3, bars);
                }
            }
            for (int side = 0; side < 2; side++) {
                int za = side == 0 ? nz1 : sz1, zb = side == 0 ? nz2 : sz2, front = side == 0 ? nz2 + 1 : sz1 - 1;
                for (int x = 1; x + 4 <= x2; x += 4) {
                    for (int yy = y + 1; yy < y + fh; yy++) {
                        for (int z = za; z <= zb; z++) p.set(x, yy, z, cellWall);
                        for (int xx = x; xx <= x + 4; xx++) p.set(xx, yy, front, bars);
                    }
                    boolean open = p.r.nextFloat() < 0.35f;
                    if (open) {
                        p.set(x + 2, y + 1, front, AIR);
                        p.set(x + 2, y + 2, front, AIR);
                    }
                    int back = side == 0 ? za : zb;
                    p.bed(x + 1, y + 1, side == 0 ? za + 1 : zb - 1, Blocks.GRAY_BED, side == 0 ? Direction.NORTH : Direction.SOUTH);
                    p.furn(x + 3, y + 1, back, "toilet", side == 0 ? Direction.SOUTH : Direction.NORTH);
                    p.furnLoot(x + 3, y + 1, side == 0 ? back + 2 : back - 2, "bathroom_sink", Direction.WEST, Loot.BATHROOM);
                    if (p.r.nextFloat() < 0.15f) p.loot(x + 2, y + 1, side == 0 ? back + 1 : back - 1, Blocks.BARREL.getDefaultState(), Loot.LIVING);
                    if (p.r.nextFloat() < 0.45f) p.zombie(x + 2, y + 1, (za + zb) / 2, ZombieOutfit.PRISONER, 1);
                }
            }
        }
        // лестницы на галереи в торцах
        for (int k = 0; k < tiers - 1; k++) {
            int y = k * fh;
            int sx = k % 2 == 0 ? x2 - 2 : 1;
            Houses.staircase(p, sx, y, nz2 + 6, fh - 1, Direction.NORTH, Blocks.STONE_BRICK_STAIRS);       // на северную галерею
            Houses.staircase(p, x2 - 1 - sx, y, sz1 - 6, fh - 1, Direction.SOUTH, Blocks.STONE_BRICK_STAIRS); // на южную
        }
        // пост охраны в центре
        int gx = p.w / 2 - 2, gz = p.d / 2 - 1;
        for (int x = gx; x <= gx + 4; x++) p.set(x, 1, gz, Blocks.SPRUCE_PLANKS.getDefaultState());
        p.furnLoot(gx + 2, 1, gz + 1, "desk", Direction.NORTH, Loot.POLICE);
        p.furn(gx + 1, 2, gz, "tv", Direction.SOUTH);
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, tiers * fh, 6);
        MetroBuildings.decals(p, 1, nz2 + 1, x2 - 1, sz1 - 1, 1, 0.04f);
        MetroBuildings.zombies(p, 1, nz2 + 1, x2 - 1, sz1 - 1, 1, 6 + p.r.nextInt(5), ZombieOutfit.PRISONER);
        MetroBuildings.zombies(p, 1, nz2 + 1, x2 - 1, sz1 - 1, 1, 2, ZombieOutfit.POLICE);
        p.danger = 2;
    }

    static void cafeteria(Plan p) {
        messHall(p);
        p.danger = 1;
        MetroBuildings.zombies(p, 1, 1, p.w - 2, p.d - 2, 1, 4, ZombieOutfit.PRISONER);
    }

    /** Медпункт: койки, шкафы с лекарствами, кабинет врача. */
    static void infirmary(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1;
        BlockState wall = bb("stucco_white", Blocks.WHITE_CONCRETE);
        p.fill(0, 0, 0, x2, 0, z2, bb("tile_white", Blocks.WHITE_CONCRETE));
        MetroBuildings.storey(p, 0, 0, x2, z2, 0, 4, wall, Blocks.GLASS_PANE.getDefaultState(), wall, 1);
        p.air(1, 1, 1, x2 - 1, 3, z2 - 1);
        p.fill(0, 4, 0, x2, 4, z2, bb("roof_tar", Blocks.GRAY_CONCRETE));
        p.door(p.w / 2, 1, 0, Blocks.IRON_DOOR, Direction.NORTH);
        p.set(p.w / 2 + 1, 2, -1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        p.set(p.w / 2 - 1, 2, 1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.SOUTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        for (int x = 2; x < x2 - 1; x += 3) p.bed(x, 1, z2 - 2, Blocks.WHITE_BED, Direction.SOUTH);
        for (int z = 2; z < z2 - 3; z++) p.furnLoot(1, 1, z, "shelf_meds", Direction.EAST, Loot.CLINIC);
        p.furnLoot(x2 - 1, 1, 2, "desk", Direction.WEST, Loot.HOSPITAL);
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, 3, 5);
        MetroBuildings.zombies(p, 1, 1, x2 - 1, z2 - 1, 1, 2, ZombieOutfit.DOCTOR);
        p.danger = 2;
    }

    /** Прачечная и мастерская заключённых. */
    static void workshop(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1;
        BlockState wall = bb("metal_siding", Blocks.LIGHT_GRAY_CONCRETE);
        p.fill(0, 0, 0, x2, 0, z2, bb("floor_concrete", Blocks.LIGHT_GRAY_CONCRETE));
        MetroBuildings.storey(p, 0, 0, x2, z2, 0, 5, wall, Blocks.IRON_BARS.getDefaultState(), wall, 1);
        p.air(1, 1, 1, x2 - 1, 4, z2 - 1);
        p.fill(0, 5, 0, x2, 5, z2, bb("roof_tar", Blocks.GRAY_CONCRETE));
        p.door(3, 1, 0, Blocks.IRON_DOOR, Direction.NORTH);
        p.set(4, 2, -1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        p.set(2, 2, 1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.SOUTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        for (int z = 3; z < z2; z++) p.furn(1, 1, z, "washing_machine", Direction.EAST);
        for (int x = 6; x < x2 - 1; x += 3) {
            p.set(x, 1, 5, Blocks.ANVIL.getDefaultState());
            p.set(x, 1, 9, Blocks.SMITHING_TABLE.getDefaultState());
        }
        for (int x = 6; x < x2; x += 2) p.furnLoot(x, 1, z2 - 1, "shelf_tools", Direction.NORTH, Loot.HARDWARE);
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, 4, 6);
        MetroBuildings.zombies(p, 1, 1, x2 - 1, z2 - 1, 1, 3, ZombieOutfit.PRISONER);
        p.danger = 1;
    }

    // =====================================================================================
    //                                ИССЛЕДОВАТЕЛЬСКИЙ ЦЕНТР
    // =====================================================================================

    static void lab(Plan g, Site s) {
        int W = g.w, D = g.d, cx = W / 2, cz = D / 2;
        BlockState post = Blocks.YELLOW_CONCRETE.getDefaultState();
        // дороги к воротам и стоянка
        asphalt(g, cx - 3, 0, cx + 3, 30);
        asphalt(g, cx - 3, D - 31, cx + 3, D - 1);
        asphalt(g, 0, cz - 3, 30, cz + 3);
        asphalt(g, W - 31, cz - 3, W - 1, cz + 3);
        asphalt(g, 12, 12, W - 13, 30);
        for (int x = 14; x < W - 14; x += 4) for (int z = 14; z <= 19; z++) g.set(x, 0, z, bb("road_line_white", Blocks.WHITE_CONCRETE));
        for (int x = 16; x < W - 16; x += 4) if (g.r.nextFloat() < 0.4f && Math.abs(x - cx) > 5)
            g.vehicle(x + 2, 1, 17, com.example.zomboidmod.vehicle.VehicleType.randomCivil(g.r).id, 0f, g.r.nextFloat() < 0.2f);
        perimeter(g, 2, 3, post, Blocks.IRON_BARS.getDefaultState(), 4, 6);
        wire(g, 2, 4, 0.5f);
        gatePost(g, cx + 6, 6, true, ZombieOutfit.SECURITY);
        barriers(g, cx, true, 4, 4);
        // военный кордон у ворот: тут пытались сдержать заражение
        for (int x = cx - 12; x <= cx + 12; x += 2) if (Math.abs(x - cx) > 4) g.furn(x, 1, 9, "sandbags", Direction.NORTH);
        g.vehicle(cx - 9, 1, 24.5, "police", 90f, true);
        g.vehicle(cx + 10, 1, 25.5, "ambulance", 270f, true);
        scatter(g, cx - 14, 6, cx + 14, 30, 8, ZombieOutfit.SOLDIER, 2);
        // карантинные палатки
        for (int k = 0; k < 4; k++) tent(g, 12 + k * 12, D - 30, 10, 14, Blocks.WHITE_WOOL, Loot.HOSPITAL);
        scatter(g, 10, D - 32, 60, D - 12, 10, ZombieOutfit.HAZMAT, 2);
        // вертолётная площадка
        int hx = W - 30, hz = D - 26;
        for (int x = -6; x <= 6; x++)
            for (int z = -6; z <= 6; z++) {
                double d = Math.hypot(x, z);
                if (d <= 6.4) g.set(hx + x, 0, hz + z, d > 5.4 ? Blocks.YELLOW_CONCRETE.getDefaultState() : Blocks.GRAY_CONCRETE.getDefaultState());
            }
        for (int z = -2; z <= 2; z++) {
            g.set(hx - 2, 0, hz + z, Blocks.WHITE_CONCRETE.getDefaultState());
            g.set(hx + 2, 0, hz + z, Blocks.WHITE_CONCRETE.getDefaultState());
        }
        g.set(hx - 1, 0, hz, Blocks.WHITE_CONCRETE.getDefaultState());
        g.set(hx + 1, 0, hz, Blocks.WHITE_CONCRETE.getDefaultState());
        g.set(hx, 0, hz, Blocks.WHITE_CONCRETE.getDefaultState());
        // главный корпус с подземными уровнями
        int bw = 56, bd = 48;
        s.put(cx - bw / 2, 36, bw, bd, BlockRotation.NONE, Landmarks::labBuilding);
        scatter(g, 10, 30, W - 10, D - 10, 10, ZombieOutfit.DOCTOR, 2);
        g.danger = 3;
    }

    /**
     * Главный корпус: стеклянный вестибюль, охрана, кабинеты, столовая; лестница вниз на два подземных уровня —
     * лаборатории, серверная, душевые обеззараживания, а ниже — изолятор с камерами и «нулевой пациент».
     */
    static void labBuilding(Plan p) {
        int x2 = p.w - 1, z2 = p.d - 1, fh = 5;
        BlockState wall = bb("concrete_panel", Blocks.LIGHT_GRAY_CONCRETE), pil = bb("concrete_dark", Blocks.GRAY_CONCRETE);
        BlockState white = bb("tile_white", Blocks.WHITE_CONCRETE), inner = bb("drywall", Blocks.WHITE_CONCRETE);
        BlockState glass = Blocks.LIGHT_BLUE_STAINED_GLASS_PANE.getDefaultState();
        // ---- наземная часть (2 этажа)
        for (int k = 0; k <= 2; k++) p.fill(0, k * fh, 0, x2, k * fh, z2, k == 0 ? bb("floor_marble", Blocks.QUARTZ_BLOCK) : bb("office_carpet", Blocks.GRAY_WOOL));
        for (int k = 0; k < 2; k++) {
            MetroBuildings.storey(p, 0, 0, x2, z2, k * fh, fh, wall, glass, pil, 0);
            p.air(1, k * fh + 1, 1, x2 - 1, k * fh + fh - 1, z2 - 1);
        }
        MetroBuildings.roof(p, 0, 0, x2, z2, 2 * fh, wall, true);
        int mid = p.w / 2;
        p.air(mid - 1, 1, 0, mid + 1, 2, 0);
        p.door(mid - 1, 1, 0, Blocks.BIRCH_DOOR, Direction.NORTH);
        p.door(mid + 1, 1, 0, Blocks.BIRCH_DOOR, Direction.NORTH);
        // проходная с турникетами
        for (int x = 2; x < x2 - 1; x++) if (Math.abs(x - mid) > 2) p.set(x, 1, 8, Blocks.IRON_BARS.getDefaultState());
        p.furnLoot(mid + 4, 1, 4, "desk", Direction.NORTH, Loot.OFFICE);
        p.furn(mid + 4, 1, 5, "chair", Direction.NORTH);
        for (int x : new int[]{3, x2 - 3}) MetroBuildings.plant(p, x, 1, 2);
        // столовая и кабинеты на первом этаже
        for (int x = 3; x < 20; x += 4)
            for (int z = 12; z < z2 - 4; z += 4) {
                p.table(x, 1, z);
                p.furn(x, 1, z + 1, "chair", Direction.NORTH);
            }
        for (int x = 1; x < 20; x++) p.furnLoot(x, 1, z2 - 1, x % 3 == 0 ? "fridge" : "kitchen_counter", Direction.NORTH, x % 3 == 0 ? Loot.FRIDGE : Loot.DINER);
        for (int x = x2 - 16; x < x2 - 1; x += 4)
            for (int z = 12; z < z2 - 2; z += 5) {
                p.furnLoot(x, 1, z, "desk", Direction.SOUTH, Loot.OFFICE);
                p.furn(x, 1, z + 1, "chair", Direction.NORTH);
            }
        Houses.staircase(p, 22, 0, 10, fh - 1, Direction.SOUTH, Blocks.SMOOTH_QUARTZ_STAIRS);
        for (int x = 3; x < x2 - 3; x += 5)
            for (int z = 3; z < z2 - 3; z += 6) {
                if (Math.abs(x - 23) < 3 && z < 18) continue;
                p.furnLoot(x, fh + 1, z, "desk", Direction.SOUTH, Loot.OFFICE);
                p.furn(x, fh + 1, z + 1, "chair", Direction.NORTH);
            }
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, fh - 1, 6);
        MetroBuildings.lamps(p, 1, 1, x2 - 1, z2 - 1, 2 * fh - 1, 6);
        // ---- спуск на уровень 1 (через грунт, на восток), уровни под всем корпусом
        int sx = 27, sz = 10;
        p.air(sx, 1, sz, sx + 1, 3, sz + 1);
        int L1 = -8, L2 = -16;
        descend(p, sx, sz, 0, 9, Direction.SOUTH, wall);
        // уровень 1: коридор и лаборатории
        room(p, 2, 2, x2 - 2, z2 - 2, L1 - 1, 4, wall, white);
        int y1 = L1;
        // коридор вдоль x посередине, лаборатории по сторонам за стеклом
        int cz1 = p.d / 2 - 1, cz2 = p.d / 2 + 1;
        for (int x = 3; x < x2 - 2; x++)
            for (int yy = y1; yy <= y1 + 3; yy++) {
                p.set(x, yy, cz1 - 1, yy == y1 + 1 ? glass : inner);
                p.set(x, yy, cz2 + 1, yy == y1 + 1 ? glass : inner);
            }
        for (int x = 6; x < x2 - 4; x += 8) {
            opening(p, x, y1 - 1, cz1 - 1);
            opening(p, x, y1 - 1, cz2 + 1);
            for (int yy = y1; yy <= y1 + 3; yy++) {
                for (int z = 3; z < cz1 - 1; z++) p.set(x + 4, yy, z, inner);
                for (int z = cz2 + 2; z < z2 - 2; z++) p.set(x + 4, yy, z, inner);
            }
        }
        // вход с лестницы в коридор
        for (int z = sz + 9; z <= cz1; z++) {
            p.set(sx, y1, z, AIR);
            p.set(sx + 1, y1, z, AIR);
            p.set(sx, y1 + 1, z, AIR);
            p.set(sx + 1, y1 + 1, z, AIR);
            p.set(sx, y1 + 2, z, AIR);
            p.set(sx + 1, y1 + 2, z, AIR);
            p.set(sx, y1 - 1, z, white);
            p.set(sx + 1, y1 - 1, z, white);
        }
        // оборудование лабораторий
        for (int x = 4; x < x2 - 3; x += 2)
            for (int z : new int[]{4, z2 - 4}) {
                float k = p.r.nextFloat();
                if (k < 0.25f) p.set(x, y1, z, Blocks.BREWING_STAND.getDefaultState());
                else if (k < 0.45f) p.set(x, y1, z, Blocks.CAULDRON.getDefaultState());
                else if (k < 0.65f) p.furnLoot(x, y1, z, "desk", Direction.SOUTH, Loot.HOSPITAL);
                else if (k < 0.8f) {   // колба с образцом
                    p.set(x, y1, z, Blocks.GLASS.getDefaultState());
                    p.set(x, y1 + 1, z, Blocks.WATER.getDefaultState());
                    p.set(x, y1 + 2, z, Blocks.GLASS.getDefaultState());
                } else p.furnLoot(x, y1, z, "shelf_meds", Direction.SOUTH, Loot.HOSPITAL);
            }
        // серверная в восточном конце
        for (int z = 4; z < cz1 - 2; z += 2)
            for (int x = x2 - 8; x < x2 - 3; x++) {
                p.set(x, y1, z, Blocks.OBSERVER.getDefaultState());
                p.set(x, y1 + 1, z, Blocks.DROPPER.getDefaultState());
            }
        // душевые обеззараживания
        for (int x = 4; x < 10; x++) p.set(x, y1 + 3, cz2 + 3, Blocks.IRON_BARS.getDefaultState());
        p.furnLoot(4, y1, z2 - 4, "desk", Direction.NORTH, Loot.HOSPITAL);
        p.note(4, y1, z2 - 4, Stories.T_LAB);
        for (int x = 4; x < x2 - 3; x += 10) {
            wallLamp(p, x, y1 + 3, p.d / 2);
            if (p.r.nextBoolean()) p.set(x + 3, y1 + 1, cz1 - 1, com.example.zomboidmod.parkour.Parkour.BROKEN_WINDOW != null
                    ? com.example.zomboidmod.parkour.Parkour.BROKEN_WINDOW.getDefaultState() : AIR);
        }
        MetroBuildings.decals(p, 3, 3, x2 - 3, z2 - 3, y1, 0.04f);
        MetroBuildings.zombies(p, 3, 3, x2 - 3, z2 - 3, y1, 6 + p.r.nextInt(4), ZombieOutfit.DOCTOR);
        MetroBuildings.zombies(p, 3, 3, x2 - 3, z2 - 3, y1, 3, ZombieOutfit.HAZMAT);
        // ---- спуск на уровень 2 из западного конца коридора
        int s2x = 4, s2z = cz2 + 2;
        opening(p, s2x, y1 - 1, cz2 + 1);
        opening(p, s2x + 1, y1 - 1, cz2 + 1);
        descend(p, s2x, s2z, L1 - 1, 8, Direction.SOUTH, wall);
        room(p, 2, 2, x2 - 2, z2 - 2, L2 - 1, 4, wall, white);
        int y2 = L2;
        for (int z = s2z + 8; z <= s2z + 10; z++) {
            p.set(s2x, y2, z, AIR);
            p.set(s2x + 1, y2, z, AIR);
        }
        // изолятор: камеры с железными дверями и окнами вдоль коридора
        for (int x = 8; x < x2 - 4; x += 6) {
            for (int yy = y2; yy <= y2 + 3; yy++)
                for (int z = 3; z <= 10; z++) {
                    p.set(x, yy, z, inner);
                    p.set(x + 6 > x2 - 3 ? x2 - 3 : x + 6, yy, z, inner);
                }
            for (int xx = x; xx <= Math.min(x + 6, x2 - 3); xx++)
                for (int yy = y2; yy <= y2 + 3; yy++) p.set(xx, yy, 11, yy == y2 + 1 ? Blocks.GLASS_PANE.getDefaultState() : inner);
            p.door(x + 3, y2, 11, Blocks.IRON_DOOR, Direction.SOUTH);
            p.set(x + 2, y2 + 1, 12, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.SOUTH)
                    .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
            p.bed(x + 2, y2, 4, Blocks.WHITE_BED, Direction.NORTH);
            p.zombie(x + 4, y2, 6, p.r.nextBoolean() ? ZombieOutfit.HAZMAT : null, 3);
            if (p.r.nextFloat() < 0.4f) p.set(x + 3, y2, 8, Landmarks.decal(p, ZomboidBlocks.BLOOD));
        }
        // «нулевой пациент»: центральная камера-зал с особым ящиком и журналом
        int px1 = p.w / 2 - 6, px2 = p.w / 2 + 6, pz1 = z2 - 16, pz2 = z2 - 4;
        for (int x = px1; x <= px2; x++)
            for (int z = pz1; z <= pz2; z++)
                for (int yy = y2; yy <= y2 + 3; yy++) {
                    boolean edge = x == px1 || x == px2 || z == pz1 || z == pz2;
                    if (edge) p.set(x, yy, z, yy == y2 + 1 && z == pz1 ? Blocks.GLASS_PANE.getDefaultState() : Blocks.IRON_BLOCK.getDefaultState());
                }
        p.door(p.w / 2, y2, pz1, Blocks.IRON_DOOR, Direction.NORTH);
        p.set(p.w / 2 + 1, y2 + 1, pz1 - 1, Blocks.STONE_BUTTON.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH)
                .with(Properties.BLOCK_FACE, net.minecraft.block.enums.BlockFace.WALL));
        p.set(p.w / 2, y2, (pz1 + pz2) / 2, Blocks.CAULDRON.getDefaultState());
        p.loot(p.w / 2 - 3, y2, pz2 - 1, Blocks.CHEST.getDefaultState(), Loot.STASH);
        p.loot(p.w / 2 + 3, y2, pz2 - 1, Blocks.CHEST.getDefaultState(), Loot.HOSPITAL);
        p.note(p.w / 2 + 3, y2, pz2 - 1, Stories.T_LAB);
        p.zombie(p.w / 2, y2, pz2 - 3, ZombieOutfit.HAZMAT, 3);
        p.zombie(p.w / 2 - 2, y2, pz2 - 3, ZombieOutfit.DOCTOR, 3);
        for (int x = 4; x < x2 - 3; x += 9) wallLamp(p, x, y2 + 3, (12 + pz1) / 2);
        MetroBuildings.decals(p, 3, 12, x2 - 3, pz1 - 1, y2, 0.05f);
        MetroBuildings.zombies(p, 3, 12, x2 - 3, pz1 - 1, y2, 4, ZombieOutfit.HAZMAT);
        p.danger = 3;
    }

    // =====================================================================================
    //                                    ТОРГОВЫЙ ЦЕНТР
    // =====================================================================================

    static final String[] MALL_SHOPS = {"clothes", "electronics", "sports", "bookstore", "pharmacy", "gunstore", "pizzeria", "diner",
            "liquor", "hardware", "grocery", "clothes", "electronics", "bar", "office", "army"};

    static void mall(Plan g, Site s) {
        int W = g.w, D = g.d, cx = W / 2, cz = D / 2;
        // стоянка вокруг
        asphalt(g, 0, 0, W - 1, D - 1);
        for (int x = 4; x < W - 4; x += 4) {
            for (int z = 6; z <= 11; z++) g.set(x, 0, z, bb("road_line_white", Blocks.WHITE_CONCRETE));
            for (int z = D - 12; z <= D - 7; z++) g.set(x, 0, z, bb("road_line_white", Blocks.WHITE_CONCRETE));
        }
        for (int x = 6; x < W - 6; x += 4) {
            if (Math.abs(x - cx) < 6) continue;
            if (g.r.nextFloat() < 0.33f) g.vehicle(x + 2, 1, 9, com.example.zomboidmod.vehicle.VehicleType.randomCivil(g.r).id, 0f, g.r.nextFloat() < 0.15f);
            if (g.r.nextFloat() < 0.33f) g.vehicle(x + 2, 1, D - 9, com.example.zomboidmod.vehicle.VehicleType.randomCivil(g.r).id, 180f, g.r.nextFloat() < 0.15f);
        }
        for (int x = 10; x < W - 10; x += 24)
            for (int z : new int[]{18, D - 19}) {
                for (int y = 1; y <= 5; y++) g.set(x, y, z, Blocks.IRON_BARS.getDefaultState());
                g.furn(x, 6, z, "street_lamp", Direction.NORTH);
            }
        for (int k = 0; k < 12; k++) g.furn(6 + g.r.nextInt(W - 12), 1, 3 + g.r.nextInt(14), "shopping_cart", Direction.Type.HORIZONTAL.random(g.r));
        // корпус
        int bx1 = 14, bx2 = W - 15, bz1 = cz - 23, bz2 = cz + 22;     // 46 в глубину
        int fh = 7;
        BlockState wall = bb("stucco_peach", Blocks.TERRACOTTA), pil = bb("concrete_dark", Blocks.GRAY_CONCRETE);
        BlockState floor = bb("floor_marble", Blocks.QUARTZ_BLOCK), glass = Blocks.GLASS_PANE.getDefaultState();
        int ax1 = bx1 + 40, ax2 = bx2 - 40;   // средняя часть между «якорями»
        for (int x = ax1; x <= ax2; x++)
            for (int z = bz1; z <= bz2; z++) {
                boolean edge = z == bz1 || z == bz2;
                g.set(x, 0, z, floor);
                for (int y = 1; y <= 2 * fh; y++) g.set(x, y, z, edge ? (y <= 3 && Math.abs(x - cx) <= 5 ? glass : wall) : AIR);
                g.set(x, 2 * fh + 1, z, wall);
            }
        // вход с севера и юга посередине
        for (int dz : new int[]{bz1, bz2}) {
            g.air(cx - 3, 1, dz, cx + 3, 3, dz);
            g.door(cx - 2, 1, dz, Blocks.BIRCH_DOOR, dz == bz1 ? Direction.NORTH : Direction.SOUTH);
            g.door(cx + 2, 1, dz, Blocks.BIRCH_DOOR, dz == bz1 ? Direction.NORTH : Direction.SOUTH);
            for (int x = cx - 8; x <= cx + 8; x++) g.set(x, 4, dz, x % 2 == 0 ? Blocks.SEA_LANTERN.getDefaultState() : Blocks.RED_CONCRETE.getDefaultState());
        }
        // ряды магазинов в два этажа: 12 в глубину, витрины в галерею
        int shopsN = (ax2 - ax1 + 1) / 25;
        int sx0 = ax1 + ((ax2 - ax1 + 1) - shopsN * 25) / 2;
        int k = 0;
        int galN = bz1 + 13, galS = bz2 - 13;   // границы галереи (за витринами)
        for (int lvl = 0; lvl < 2; lvl++)
            for (int i = 0; i < shopsN; i++) {
                int x = sx0 + i * 25;
                if (lvl == 0 && Math.abs(x + 12 - cx) < 14) continue;   // внизу посередине — входной холл
                String a = MALL_SHOPS[(k++) % MALL_SHOPS.length], b = MALL_SHOPS[(k++) % MALL_SHOPS.length];
                s.put(x, lvl * fh, bz1 + 1, 25, 12, BlockRotation.CLOCKWISE_180, p -> shop(p, a));
                s.put(x, lvl * fh, bz2 - 12, 25, 12, BlockRotation.NONE, p -> shop(p, b));
            }
        // перекрытие второго этажа: галереи вдоль витрин, атриум посередине
        for (int x = ax1 + 1; x < ax2; x++)
            for (int z = bz1 + 1; z < bz2; z++) {
                boolean atrium = z > galN + 4 && z < galS - 4 && x > ax1 + 8 && x < ax2 - 8;
                if (!atrium) g.set(x, fh, z, floor);
                if (!atrium && (z == galN + 4 || z == galS - 4) && x > ax1 + 8 && x < ax2 - 8) g.set(x, fh + 1, z, Blocks.GLASS_PANE.getDefaultState());
                if (z > galN && z < galS) g.set(x, 2 * fh + 1, z, atrium ? Blocks.GLASS.getDefaultState() : wall);
            }
        // эскалаторы
        for (int e = 0; e < 2; e++) {
            int ex = e == 0 ? ax1 + 2 : ax2 - 4;
            for (int st = 1; st <= fh; st++)
                for (int w = 0; w < 3; w++) {
                    int z = galN + 1 + st;
                    g.set(ex + w, st, z, MetroBuildings.stair(Blocks.SMOOTH_QUARTZ_STAIRS, Direction.SOUTH, false));
                    for (int y = 1; y < st; y++) g.set(ex + w, y, z, Blocks.SMOOTH_QUARTZ.getDefaultState());
                    g.set(ex + w, fh, z, AIR);
                }
        }
        // фуд-корт и фонтан в атриуме
        int fx = cx, fz = (galN + galS) / 2;
        for (int x = -3; x <= 3; x++)
            for (int z = -3; z <= 3; z++) {
                double d = Math.hypot(x, z);
                if (d > 3.5) continue;
                if (d > 2.5) g.set(fx + x, 1, fz + z, Blocks.QUARTZ_SLAB.getDefaultState());
                else g.set(fx + x, 0, fz + z, Blocks.WATER.getDefaultState());
            }
        g.fill(fx, 0, fz, fx, 2, fz, Blocks.QUARTZ_PILLAR.getDefaultState());
        for (int x = ax1 + 10; x < ax2 - 10; x += 5) {
            if (Math.abs(x - fx) < 6) continue;
            for (int z = galN + 5; z < galS - 4; z += 4) {
                g.table(x, 1, z);
                g.furn(x - 1, 1, z, "chair", Direction.EAST);
                g.furn(x + 1, 1, z, "chair", Direction.WEST);
            }
        }
        for (int x = ax1 + 8; x < ax2 - 8; x += 12) {
            MetroBuildings.plant(g, x, 1, galN + 2);
            MetroBuildings.plant(g, x, 1, galS - 2);
            g.furn(x + 3, 1, galN + 2, "bench", Direction.SOUTH);
        }
        MetroBuildings.lamps(g, ax1 + 1, bz1 + 1, ax2 - 1, bz2 - 1, fh - 1, 7);
        MetroBuildings.lamps(g, ax1 + 1, bz1 + 1, ax2 - 1, bz2 - 1, 2 * fh, 7);
        // универмаги-«якоря» по концам (фасадом наружу)
        s.put(bx1, bz1, 46, 40, BlockRotation.COUNTERCLOCKWISE_90, Landmarks::anchor);
        s.put(bx2 - 39, bz1, 46, 40, BlockRotation.CLOCKWISE_90, Landmarks::anchor);
        // проходы из галереи в «якоря»
        for (int z = fz - 2; z <= fz + 2; z++) {
            g.set(ax1, 1, z, AIR);
            g.set(ax1, 2, z, AIR);
            g.set(ax2, 1, z, AIR);
            g.set(ax2, 2, z, AIR);
        }
        for (int z = bz1; z <= bz2; z++) for (int y = 1; y <= 2 * fh; y++) {
            if (Math.abs(z - fz) <= 2 && y <= 2) continue;
            g.set(ax1, y, z, wall);
            g.set(ax2, y, z, wall);
        }
        g.loot(cx + 7, 1, galN + 2, Blocks.BARREL.getDefaultState(), Loot.LIVING);
        g.note(cx + 7, 1, galN + 2, Stories.T_MALL);
        scatter(g, ax1 + 2, galN + 1, ax2 - 2, galS - 1, 18 + g.r.nextInt(8), null, 1);
        scatter(g, 4, 4, W - 4, D - 4, 12, null, 0);
        g.danger = 1;
    }

    /** Универмаг-«якорь»: проход в галерею центра через заднюю стену. */
    static void anchor(Plan p) {
        MetroBuildings.departmentStore(p);
        for (int x = p.w / 2 - 2; x <= p.w / 2 + 2; x++) {
            p.set(x, 1, p.d - 1, AIR);
            p.set(x, 2, p.d - 1, AIR);
        }
    }

    /** Магазин внутри торгового центра — из обычных городских. */
    static void shop(Plan p, String kind) {
        ZombieOutfit local = null;
        switch (kind) {
            case "grocery" -> { Buildings.grocery(p); p.danger = 1; }
            case "pharmacy" -> { Buildings.pharmacy(p); p.danger = 2; local = ZombieOutfit.NURSE; }
            case "hardware" -> { Buildings.hardware(p); p.danger = 1; local = ZombieOutfit.CONSTRUCTION; }
            case "diner" -> Buildings.diner(p);
            case "bar" -> Buildings.bar(p);
            case "office" -> { Buildings.office(p); local = ZombieOutfit.BUSINESS; }
            case "bookstore" -> CityBuildings.bookstore(p);
            case "gunstore" -> { CityBuildings.gunstore(p); p.danger = 2; local = ZombieOutfit.SECURITY; }
            case "electronics" -> CityBuildings.electronics(p);
            case "sports" -> CityBuildings.sports(p);
            case "liquor" -> CityBuildings.liquor(p);
            case "pizzeria" -> { CityBuildings.pizzeria(p); local = ZombieOutfit.CHEF; }
            case "army" -> { CityBuildings.armySurplus(p); p.danger = 2; local = ZombieOutfit.SOLDIER; }
            default -> Buildings.clothes(p);
        }
        p.populate(local);
    }
}
