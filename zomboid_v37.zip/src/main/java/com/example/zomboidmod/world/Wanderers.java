package com.example.zomboidmod.world;

import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.ZomboidEntities;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

/**
 * Бродячие зомби: в PZ мёртвые бредут по дорогам и полям и днём. Раз в 10 секунд, если вокруг игрока их мало,
 * за спиной (вне поля зрения) появляется ещё 1-3 шатуна. Ночью их больше. Ушедшие далеко исчезают сами.
 */
public final class Wanderers {
    private Wanderers() {
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(Wanderers::tick);
    }

    private static void tick(MinecraftServer server) {
        if (server.getTicks() % 200 != 37) return;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p.isCreative() || p.isSpectator() || !p.isAlive()) continue;
            ServerWorld w = p.getServerWorld();
            if (w.getRegistryKey() != World.OVERWORLD || w.getDifficulty() == net.minecraft.world.Difficulty.PEACEFUL) continue;
            int want = w.isDay() ? 9 : 14;
            int near = w.getEntitiesByClass(PzZombieEntity.class, new Box(p.getBlockPos()).expand(56, 24, 56), z -> true).size();
            if (near >= want) continue;
            int n = 1 + p.getRandom().nextInt(Math.min(3, want - near));
            for (int i = 0; i < n; i++) spawnBehind(w, p);
        }
    }

    private static void spawnBehind(ServerWorld w, ServerPlayerEntity p) {
        var r = p.getRandom();
        for (int tries = 0; tries < 6; tries++) {
            // направление — за спиной, ±100°
            float yaw = p.getYaw() + 180f + (r.nextFloat() - 0.5f) * 200f;
            double rad = Math.toRadians(yaw);
            double dist = 30 + r.nextDouble() * 18;
            int x = MathHelper.floor(p.getX() - Math.sin(rad) * dist);
            int z = MathHelper.floor(p.getZ() + Math.cos(rad) * dist);
            if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
            int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
            if (Math.abs(y - p.getY()) > 14) continue;
            BlockPos pos = new BlockPos(x, y, z);
            BlockState below = w.getBlockState(pos.down());
            if (!below.isSolidBlock(w, pos.down()) || !w.getFluidState(pos.down()).isEmpty()) continue;
            if (!w.getBlockState(pos).isAir() || !w.getBlockState(pos.up()).isAir()) continue;
            PzZombieEntity zombie = ZomboidEntities.PZ_ZOMBIE.create(w);
            if (zombie == null) return;
            zombie.refreshPositionAndAngles(x + 0.5, y, z + 0.5, r.nextFloat() * 360f, 0f);
            zombie.setup(null, 0);
            w.spawnEntity(zombie);
            return;
        }
    }
}
