package com.example.zomboidmod.world;

import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.survival.WorldEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.WrittenBookContentComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.RawFilteredPair;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * Истории округа: записки и дневники выживших (обычные книги, читаются как книга) с настоящими названиями
 * соседних городов и мест, и карты тайников — по ним можно найти спрятанные припасы.
 */
public final class Stories {
    public static final int T_CABIN = 0, T_TOWER = 1, T_CAMP = 2, T_HELI = 3, T_EVAC = 4, T_GRAVE = 5, T_TRAILERS = 6, T_RADIO = 7,
            T_SAFEHOUSE = 8, T_PLANE = 9, T_STASH = 10, T_ROADBLOCK = 11, T_MILITARY = 12, T_PRISON = 13, T_LAB = 14, T_MALL = 15;

    public static Item STASH_MAP;

    private Stories() {
    }

    public static void register() {
        STASH_MAP = Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, "stash_map"), new StashMapItem(new Item.Settings().maxCount(1)));
        net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(STASH_MAP));
    }

    // ===================== тексты =====================
    private record Note(int topic, String title, String author, String[] pages) {}

    private static Note n(int topic, String title, String author, String... pages) {
        return new Note(topic, title, author, pages);
    }

    private static final Note[] NOTES = {
            // ---- военная база
            n(T_MILITARY, "Журнал дежурного", "Сержант Д. Коул",
                    "День 1.\nПриказ: периметр закрыт. Гражданских разворачивать к пункту эвакуации в {town2}.\nНа воротах очередь из машин до самого поворота.",
                    "День 3.\nТолпа у северных ворот. Часть из них уже не люди. Огонь разрешён.\nРядовой Пирс отказался стрелять. Его увели.",
                    "День 5.\nСвязи со штабом нет. Половина роты в лазарете с жаром.\nКапитан закрылся в бункере с офицерами. Код от двери нам не сказали."),
            n(T_MILITARY, "Приказ №17", "Штаб округа",
                    "СЕКРЕТНО.\n\nОбъект «Атлас» изолировать радиусом 2 км. Персонал объекта на контрольно-пропускных пунктах НЕ пропускать.\n\nПри появлении симптомов у личного состава — изолировать немедленно.",
                    "Вопросы о происхождении инфекции пресекать.\nОфициальная версия для населения: утечка химикатов.\n\nУничтожить после прочтения."),
            // ---- тюрьма
            n(T_PRISON, "Рапорт", "Офицер Т. Мерфи",
                    "Заключённого №4471 вернули из лазарета в блок Б. Укус на руке — говорит, сокамерник.\nК вечеру жар, бредит.\n\nУтром блок Б не ответил на перекличку.",
                    "Начальник приказал запереть всех по камерам и уходить.\nМы не можем бросить их так.\nКлючи и оружие я оставил в оружейной. Кнопка у двери справа."),
            n(T_PRISON, "Письмо", "Ленни",
                    "Мама, тут все говорят, что снаружи творится что-то страшное.\nОхрана не приходит уже второй день. Воды нет.\nЯ слышу, как в соседнем блоке кто-то скребёт решётку всю ночь.",
                    "Если это письмо дойдёт — я тебя люблю.\nПрости за всё."),
            // ---- исследовательский центр
            n(T_LAB, "Лабораторный журнал: образец К-7", "Д-р Э. Варгас",
                    "День 1.\nОбразец К-7 получен. Клеточная активность сохраняется после остановки сердца у подопытных крыс.\nКрысы продолжают двигаться. Агрессивны.",
                    "День 9.\nЛаборант Хейз порезался при вскрытии. Уверяет, что всё в порядке.\n\nДень 12.\nХейз не вышел на смену. Охрана нашла его в изоляторе. Он нас не узнаёт.",
                    "День 14.\nВентиляция уровня 2 общая с городской сетью. Я предупреждала.\n\nЕсли кто-то это найдёт: К-7 передаётся через кровь и слюну. Не через воздух. Пока."),
            n(T_LAB, "Служебная записка", "Совет директоров",
                    "Протокол «Тишина».\n\nНикаких сообщений властям до завершения испытаний.\nЭвакуация персонала — только по личному распоряжению директора.\nИзолятор уровня 2 не открывать ни при каких обстоятельствах.",
                    "Приписка от руки:\n«Директор уехал вчера на вертолёте. Нас заперли снаружи.»"),
            // ---- торговый центр
            n(T_MALL, "Объявление", "Администрация центра",
                    "Уважаемые покупатели!\n\nПо распоряжению властей торговый центр закрывается в 18:00.\nПункт сбора — стоянка, сектор Б. Автобусы до {town2}.\n\nСохраняйте спокойствие."),
            n(T_MALL, "Записка", "Джесс",
                    "Мы прячемся в подсобке универмага. Нас семеро.\nОхранник сказал, что вертолёт заберёт с крыши.\nЭто было три дня назад.\n\nЕда из фуд-корта кончается."),
            // ---- общие (могут попасться где угодно)
            n(-1, "Записка на холодильнике", "К.",
                    "Мама!\n\nМы уехали к тёте Рут в {town2}. Это {dir2}, по шоссе, около {km2} м.\n\nЕсли вернёшься — жди нас там. Никому не открывай. Воду мы набрали в ванну.\n\nЛюблю. К."),
            n(-1, "Список", "Б. Хэнсон",
                    "1. Вода — набрать всё, пока идёт.\n2. Заколотить окна первого этажа.\n3. Бензин из машины Миллеров.\n4. НЕ выходить ночью.\n5. Дозвониться до Сары (третий день не отвечает).",
                    "6. Таблетки для мамы — аптека в {town}.\n7. Не шуметь. Они идут на шум.\n8. Если начнётся жар — ключи от машины на крючке. Уезжайте без меня."),
            n(-1, "Дневник", "Эми",
                    "Сегодня мистер Палмер из дома напротив стоял посреди дороги целый час. Просто стоял. Папа вышел спросить, всё ли в порядке.\n\nПапа вернулся с укушенной рукой.",
                    "Папа заперся в гараже. Мама сказала не подходить к двери.\n\nОн скребётся в дверь всю ночь.\n\nУтром мы уходим в {town2}."),
            n(-1, "Предупреждение", "—",
                    "НЕ ХОДИТЕ В {town}.\n\nИх там сотни. Главная улица — сплошная стена. Мы еле ушли.\n\nОбходите полями. Ночью не жгите огонь.\n\nДа хранит вас Бог."),
            n(-1, "Последняя запись", "Генри",
                    "Меня укусили у аптеки. Жар уже второй час.\n\nЕсли ты это читаешь — не жалей меня. Дверь я запер снаружи.\n\nВ подвале консервы и вода. Бери всё.",
                    "Энни, прости.\nЯ правда думал, что успею."),
            n(-1, "Записка", "Папа",
                    "Солнышко, если мы потеряемся — встречаемся там, где {site}. Это {sitedir} отсюда, примерно {sitekm} м.\n\nЖди меня там. Возьми фонарик и печенье. Я приду. Обещаю."),
            n(-1, "Из блокнота механика", "Р. Дэйл",
                    "Пикап у заправки живой, но аккумулятор сел. Новый — в автомастерских.\n\nБензин сливать шлангом из баков брошенных машин. У половины машин ключи в замке или у хозяина в кармане.",
                    "Хозяин обычно бродит неподалёку."),
            n(-1, "Памятка", "Аптека «Здоровье»",
                    "Укус — не лечится.\nЦарапины и порезы — промыть, обработать, перевязать. Менять повязку.\n\nАнтибиотики — от заражения раны, а не от укуса.\n\nНе верьте слухам про «вакцину»."),
            n(-1, "Объявление", "Окружной шериф",
                    "ВНИМАНИЕ ЖИТЕЛЯМ!\n\nПо распоряжению властей округ закрыт на карантин. Оставайтесь дома. Не приближайтесь к больным. Сборный пункт эвакуации будет объявлен по радио.\n\nСохраняйте спокойствие."),
            n(-1, "Письмо", "Лиза",
                    "Том, мы ждали тебя у школы до темноты. Автобус ушёл без нас.\n\nМы с Беном идём пешком {dir2}, в {town2}. Говорят, там ещё есть военные.\n\nЕсли увидишь эту записку — догоняй."),
            n(-1, "Дневник охотника", "Уолт",
                    "Шум собирает их со всей округи. Выстрел слышно за полкилометра — потом приходят десятками.\n\nЛук. Нож. Тишина. И никогда не беги туда, где не видишь, что за углом."),
            n(-1, "Листок из ежедневника", "—",
                    "Пн — стоматолог, 10:00\nВт — забрать костюм\nСр — ДР Джоша!!!\nЧт —\nПт —\n\n(дальше страницы пустые)"),
            // ---- по местам
            n(T_CABIN, "Охотничий журнал", "Уолт Бреннан",
                    "Отличный сезон. Двое оленей за неделю.\n\nПо радио что-то про эпидемию в {town}. Здесь, в лесу, хоть конец света — не узнаешь.",
                    "Ночью кто-то ходил вокруг домика. Шаги тяжёлые, без фонаря.\n\nНе отозвался.\n\nУтром у двери следы. Босые."),
            n(T_TOWER, "Журнал наблюдателя", "Лесная служба",
                    "8 июля. Дым {dir2}, над {town2}. Сообщил на базу.\n9 июля. Пожаров больше. База не отвечает.\n10 июля. Внизу ходят люди. Медленно. На крики не отвечают.",
                    "12 июля. Их у вышки уже шестеро. Стоят и смотрят вверх.\n13 июля. Вода кончается.\n14 июля. Спускаюсь. Если не вернусь — всё в ящике."),
            n(T_CAMP, "Записка в палатке", "Келли",
                    "Приехали на выходные. Связи нет, новостей нет — красота!\n\nНочью кто-то ходил вокруг палаток. Утром Дэйв ушёл за дровами и не вернулся.",
                    "Ключи от машины у Дэйва.\n\nМы ждём ещё один день, потом идём к шоссе. Если найдёшь Дэйва — скажи, что мы пошли в {town}."),
            n(T_HELI, "Полётный журнал", "Борт 7-Т",
                    "Задача: эвакуация медперсонала из {town}.\n\nНа посадке в {town} сержант Ортис укушен. Скрыл от экипажа.\n\nНад лесом он обратился. Пилот потерял управление.",
                    "Двое живы. Рация разбита. В ящике — аптечка, оружие и карта нашего тайника на маршруте.\n\nКто найдёт — пользуйтесь. Дым видно издалека, к нему сходятся все. Уходите быстро."),
            n(T_EVAC, "Сводка лагеря", "Комендант",
                    "Принято гражданских: 412.\nВ карантине: 37.\nСреди персонала инфицировано: 4 (скрывали укусы).\n\nПродовольствия на 9 дней. Обещанных вертолётов нет третьи сутки.",
                    "02:40. Периметр прорван у восточных ворот.\n02:55. Приказ на эвакуацию отменён.\n\nВсем, кто может идти — уходить {dir2}, к {town2}. Да поможет нам Бог."),
            n(T_GRAVE, "Записка сторожа", "Сторож Эймс",
                    "Хоронить перестали на четвёртый день.\n\nОни не лежат.\n\nЯ слышу, как свежие скребутся изнутри. Не открывай свежие могилы. И не ходи сюда ночью."),
            n(T_TRAILERS, "Записка на двери", "Джо",
                    "Мардж!\n\nПошёл в {town} за лекарствами для мамы. Вернусь до темноты.\n\nРужьё под кроватью, патроны в банке из-под кофе. Никому не открывай. Даже мне, если я буду странный."),
            n(T_RADIO, "Тетрадь радиста", "Сэм, частота 91.4",
                    "Повторяю каждый час: всем выжившим — не идите в лагеря эвакуации. Их больше нет.\n\nДержитесь подальше от больших городов. Ищите высокие места и воду.",
                    "Генератор протянет ещё неделю.\n\nЕсли кто-то слышит — на этой вышке есть еда и батарейки. Карта моего тайника в ящике.\n\nЯ всё ещё здесь. Пока ещё здесь."),
            n(T_SAFEHOUSE, "Дневник", "Дэниел Росс",
                    "День 1. Заколотил окна. Воды и еды — на месяц, если экономить.\nДень 6. Слышу их каждую ночь. Всё ближе.\nДень 12. Разговариваю с собой. Это нормально?",
                    "День 19. Порезался о гвоздь, когда чинил доску. Рука горит.\n\nЭто не укус. Это просто порез. Правда?",
                    "День 21. Если не проснусь — всё в сундуке. Бери.\n\nМне уже не нужно.\n\nИ закрой за собой дверь."),
            n(T_PLANE, "Посадочный талон", "Рейс 302",
                    "Рейс 302. Вылет задержан на 3 часа из-за «санитарной проверки».\n\nМужчина в третьем ряду кашляет без остановки. Стюардессы в перчатках и масках.\n\nНапишу Кэти, когда сядем."),
            n(T_STASH, "Тайник", "Б.",
                    "Всё, что смог унести. Патроны сухие, консервы целые.\n\nЕсли нашёл — бери. Мне уже не нужно.\n\nИ помни: шум — это смерть."),
            n(T_ROADBLOCK, "Рапорт", "Офицер Ли",
                    "Блокпост на шоссе у {town}. Вторые сутки без смены.\n\nС той стороны толпа. Приказ — никого не пропускать. Я видел, как стреляли в людей, которые были ещё живы.",
                    "Патроны на исходе. Если кто-то найдёт — передайте жене, что я пытался.\n\nВ ящике — что осталось. Берите."),
    };

    // ===================== места вокруг =====================
    private static String dirWord(double dx, double dz) {
        double a = Math.toDegrees(Math.atan2(dx, -dz));
        if (a < 0) a += 360;
        String[] w = {"на север", "на северо-восток", "на восток", "на юго-восток", "на юг", "на юго-запад", "на запад", "на северо-запад"};
        return w[(int) Math.round(a / 45.0) % 8];
    }

    private static String dirFrom(double dx, double dz) {
        double a = Math.toDegrees(Math.atan2(dx, -dz));
        if (a < 0) a += 360;
        String[] w = {"к северу", "к северо-востоку", "к востоку", "к юго-востоку", "к югу", "к юго-западу", "к западу", "к северо-западу"};
        return w[(int) Math.round(a / 45.0) % 8];
    }

    private static int round50(double d) {
        return (int) Math.max(50, Math.round(d / 50.0) * 50);
    }

    /** Ближайшие поселения с названиями (без лесов). */
    private static List<Knox.Settlement> towns(long seed, int x, int z) {
        int prx = Math.floorDiv(x, Knox.REGION), prz = Math.floorDiv(z, Knox.REGION);
        List<Knox.Settlement> out = new ArrayList<>();
        java.util.Set<Long> seen = new java.util.HashSet<>();
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++) {
                Knox.Settlement s = Knox.settlement(seed, prx + dx, prz + dz);
                if (s.type() != Knox.Type.FOREST && s.type() != Knox.Type.NONE && !Knox.special(s.type()) && seen.add(s.key())) out.add(s);
            }
        out.sort((a, b) -> Double.compare(Math.hypot(a.cx() - x, a.cz() - z), Math.hypot(b.cx() - x, b.cz() - z)));
        return out;
    }

    private static String fill(String t, ServerWorld w, BlockPos pos, java.util.Random r) {
        long seed = w.getSeed();
        int x = pos.getX(), z = pos.getZ();
        List<Knox.Settlement> ts = towns(seed, x, z);
        Knox.Settlement a = ts.get(0), b = ts.size() > 1 ? ts.get(1 + r.nextInt(Math.min(3, ts.size() - 1))) : ts.get(0);
        t = t.replace("{town}", a.name()).replace("{town2}", b.name())
                .replace("{dir2}", dirWord(b.cx() - x, b.cz() - z)).replace("{km2}", String.valueOf(round50(Math.hypot(b.cx() - x, b.cz() - z))));
        if (t.contains("{site")) {
            List<Sites.Site> sites = Sites.near(seed, x, z, null);
            Sites.Site s = null;
            for (Sites.Site c : sites) {
                double d = Math.hypot(c.cx() - x, c.cz() - z);
                if (c.kind() != Sites.Kind.STASH && !c.kind().onRoad() && d > 60) {
                    s = c;
                    break;
                }
            }
            if (s == null) t = t.replace("{site}", "старая водонапорная башня").replace("{sitedir}", "к востоку").replace("{sitekm}", "300");
            else t = t.replace("{site}", s.kind().ru.toLowerCase()).replace("{sitedir}", dirFrom(s.cx() - x, s.cz() - z))
                    .replace("{sitekm}", String.valueOf(round50(Math.hypot(s.cx() - x, s.cz() - z))));
        }
        return t;
    }

    // ===================== предметы =====================
    public static ItemStack note(ServerWorld w, BlockPos pos, Random rnd) {
        return note(w, pos, rnd, -1);
    }

    /** Записка (книга) нужной темы; -1 — любая из общих. */
    public static ItemStack note(ServerWorld w, BlockPos pos, Random rnd, int topic) {
        java.util.Random r = new java.util.Random(rnd.nextLong());
        List<Note> pool = new ArrayList<>();
        for (Note nt : NOTES) if (nt.topic() == topic) pool.add(nt);
        if (pool.isEmpty()) for (Note nt : NOTES) if (nt.topic() == -1) pool.add(nt);
        Note nt = pool.get(r.nextInt(pool.size()));
        List<RawFilteredPair<Text>> pages = new ArrayList<>();
        for (String pg : nt.pages()) pages.add(RawFilteredPair.of(Text.literal(fill(pg, w, pos, r))));
        ItemStack st = new ItemStack(Items.WRITTEN_BOOK);
        st.set(DataComponentTypes.WRITTEN_BOOK_CONTENT, new WrittenBookContentComponent(RawFilteredPair.of(nt.title()), nt.author(), 0, pages, true));
        return st;
    }

    /** Карта тайника: ведёт к одному из ещё не найденных тайников поблизости. */
    public static ItemStack stashMap(ServerWorld w, BlockPos pos, Random rnd) {
        List<Sites.Site> st = Sites.near(w.getSeed(), pos.getX(), pos.getZ(), Sites.Kind.STASH);
        List<Sites.Site> free = new ArrayList<>();
        for (Sites.Site s : st) if (!Sites.looted(w, s) && Math.hypot(s.cx() - pos.getX(), s.cz() - pos.getZ()) > 40) free.add(s);
        if (free.isEmpty()) return note(w, pos, rnd);
        Sites.Site s = free.get(rnd.nextInt(Math.min(4, free.size())));
        List<Knox.Settlement> ts = towns(w.getSeed(), s.cx(), s.cz());
        Knox.Settlement t = ts.get(0);
        String label = dirFrom(s.cx() - t.cx(), s.cz() - t.cz()) + " от " + t.name() + ", " + round50(Math.hypot(s.cx() - t.cx(), s.cz() - t.cz())) + " м";
        ItemStack it = new ItemStack(STASH_MAP);
        NbtCompound n = new NbtCompound();
        n.putInt("sx", s.cx());
        n.putInt("sz", s.cz());
        n.putString("label", label);
        it.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(n));
        return it;
    }

    /** Положить в контейнер в случайную пустую ячейку. */
    public static void put(Inventory inv, ItemStack st, Random r) {
        if (st.isEmpty()) return;
        for (int k = 0; k < 20; k++) {
            int i = r.nextInt(inv.size());
            if (inv.getStack(i).isEmpty()) {
                inv.setStack(i, st);
                return;
            }
        }
    }

    /** Метки тайников со всех карт тайников в инвентаре игрока (для бумажной карты). */
    public static NbtList marks(ServerPlayerEntity p) {
        NbtList list = new NbtList();
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack st = inv.getStack(i);
            if (!st.isOf(STASH_MAP)) continue;
            NbtComponent c = st.get(DataComponentTypes.CUSTOM_DATA);
            if (c == null) continue;
            NbtCompound n = c.copyNbt();
            NbtCompound m = new NbtCompound();
            m.putInt("x", n.getInt("sx"));
            m.putInt("z", n.getInt("sz"));
            m.putString("l", n.getString("label"));
            list.add(m);
        }
        return list;
    }

    public static class StashMapItem extends Item {
        public StashMapItem(Settings s) {
            super(s);
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack st = user.getStackInHand(hand);
            if (!world.isClient && user instanceof ServerPlayerEntity p) {
                NbtComponent c = st.get(DataComponentTypes.CUSTOM_DATA);
                if (c == null || !c.copyNbt().contains("sx")) {
                    // карта без отметки (например, из творческого режима) — отметить ближайший тайник
                    ItemStack fresh = stashMap(p.getServerWorld(), p.getBlockPos(), p.getRandom());
                    if (fresh.isOf(STASH_MAP)) {
                        user.setStackInHand(hand, fresh);
                        st = fresh;
                        c = st.get(DataComponentTypes.CUSTOM_DATA);
                    }
                }
                if (c != null && c.copyNbt().contains("sx")) {
                    NbtCompound n = c.copyNbt();
                    WorldEvents.openMap(p, n.getInt("sx"), n.getInt("sz"));
                }
            }
            world.playSound(user, user.getBlockPos(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.PLAYERS, 1f, 1.1f);
            return TypedActionResult.success(st, world.isClient);
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            NbtComponent c = stack.get(DataComponentTypes.CUSTOM_DATA);
            if (c != null && c.copyNbt().contains("label"))
                tooltip.add(Text.literal("Тайник: " + c.copyNbt().getString("label")).formatted(Formatting.GOLD));
            tooltip.add(Text.literal("ПКМ — посмотреть, где он на карте").formatted(Formatting.GRAY));
            tooltip.add(Text.literal("Метка у тайника — красная тряпка у каменной пирамидки").formatted(Formatting.DARK_GRAY));
        }
    }
}
