package com.example.zomboidmod.world;

import com.example.zomboidmod.block.FurnitureBlock;
import com.example.zomboidmod.block.FurnitureTopBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.util.math.Direction;

/**
 * Подвалы под жилыми домами (как в PZ): люк в полу и лестница вниз, бетонные стены, стеллажи с консервами,
 * котёл, стиральная машина, верстак, коробки со старьём, иногда оружейный сейф — и иногда кто-то внизу.
 * Работает для любого дома: подвал повторяет форму комнат первого этажа.
 */
final class Basements {
    private Basements() {
    }

    private static boolean solid(BlockState s) {
        return s != null && !s.isAir();
    }

    private static boolean wallCell(Plan p, int x, int z) {
        for (int y = 1; y <= 3; y++) {
            BlockState s = p.get(x, y, z);
            if (!solid(s) || s.getBlock() instanceof FurnitureBlock || s.getBlock() instanceof FurnitureTopBlock || s.getBlock() instanceof DoorBlock)
                return false;
        }
        return true;
    }

    /** Под крышей: есть пол и что-то сверху (потолок, второй этаж, крыша). */
    private static boolean indoor(Plan p, int x, int z) {
        if (!solid(p.get(x, 0, z)) || wallCell(p, x, z)) return false;
        for (int y = 3; y <= 9; y++) if (solid(p.get(x, y, z))) return true;
        return false;
    }

    static void add(Plan p, float chance) {
        if (p.r.nextFloat() >= chance) return;
        int W = p.w, D = p.d;
        boolean[][] in = new boolean[W][D];
        int count = 0;
        for (int x = 0; x < W; x++)
            for (int z = 0; z < D; z++) if (indoor(p, x, z)) {
                in[x][z] = true;
                count++;
            }
        if (count < 16) return;
        BlockState wall = MetroBuildings.bb("foundation", Blocks.STONE_BRICKS), floor = MetroBuildings.bb("floor_concrete", Blocks.SMOOTH_STONE);
        int bottom = -4;
        // внутренние стены дома над подвалом — пустота (с опорами), чтобы подвал был цельным
        boolean[][] room = new boolean[W][D];
        for (int x = 0; x < W; x++)
            for (int z = 0; z < D; z++) {
                if (in[x][z]) room[x][z] = true;
                else if (x > 0 && x < W - 1 && z > 0 && z < D - 1 && ((in[x - 1][z] && in[x + 1][z]) || (in[x][z - 1] && in[x][z + 1]))) room[x][z] = true;
            }
        for (int x = 0; x < W; x++)
            for (int z = 0; z < D; z++) {
                if (room[x][z]) {
                    p.set(x, bottom, z, floor);
                    boolean pillar = !in[x][z] && (x + z) % 3 == 0;
                    for (int y = bottom + 1; y <= -1; y++) p.set(x, y, z, pillar ? wall : Blocks.AIR.getDefaultState());
                    if (!solid(p.get(x, 0, z))) p.set(x, 0, z, floor);
                    continue;
                }
                boolean edge = false;
                for (int a = -1; a <= 1 && !edge; a++)
                    for (int b = -1; b <= 1 && !edge; b++) {
                        int nx = x + a, nz = z + b;
                        if (nx >= 0 && nz >= 0 && nx < W && nz < D && room[nx][nz]) edge = true;
                    }
                if (edge) for (int y = bottom; y <= -1; y++) p.set(x, y, z, wall);
            }
        // люк: свободная клетка пола, рядом — опора для лестницы
        int hx = -1, hz = -1;
        for (int k = 0; k < 200 && hx < 0; k++) {
            int x = 1 + p.r.nextInt(Math.max(1, W - 2)), z = 1 + p.r.nextInt(Math.max(1, D - 2));
            if (!in[x][z] || !in[x + 1][z] || solid(p.get(x, 1, z)) || solid(p.get(x, 2, z))) continue;
            if (p.get(x, 0, z) != null && p.get(x, 0, z).getBlock() instanceof net.minecraft.block.StairsBlock) continue;
            hx = x;
            hz = z;
        }
        if (hx < 0) {   // некуда поставить люк — подвал не делаем
            for (int x = 0; x < W; x++) for (int z = 0; z < D; z++) for (int y = bottom; y <= -1; y++) p.blocks.remove(net.minecraft.util.math.BlockPos.asLong(x, y, z));
            return;
        }
        p.set(hx, 0, hz, Blocks.SPRUCE_TRAPDOOR.getDefaultState().with(TrapdoorBlock.HALF, BlockHalf.TOP).with(TrapdoorBlock.FACING, Direction.WEST));
        for (int y = bottom + 1; y <= -1; y++) {
            p.set(hx + 1, y, hz, wall);
            p.set(hx, y, hz, Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.WEST));
        }
        // обстановка вдоль стен
        int y = bottom + 1;
        int placed = 0;
        String[] stuff = {"shelf_food", "cardboard_box", "washing_machine", "shelf_tools", "cardboard_box", "shelf_food"};
        Loot[] loot = {Loot.GROCERY, Loot.GARAGE, null, Loot.HARDWARE, Loot.LIVING, Loot.KITCHEN};
        for (int x = 0; x < W && placed < 10; x++)
            for (int z = 0; z < D && placed < 10; z++) {
                if (!room[x][z] || Math.abs(x - hx) + Math.abs(z - hz) < 3) continue;
                Direction face = null;
                if (x + 1 < W && !room[x + 1][z]) face = Direction.WEST;
                else if (x > 0 && !room[x - 1][z]) face = Direction.EAST;
                else if (z + 1 < D && !room[x][z + 1]) face = Direction.NORTH;
                else if (z > 0 && !room[x][z - 1]) face = Direction.SOUTH;
                if (face == null || p.r.nextFloat() > 0.3f) continue;
                int k = p.r.nextInt(stuff.length);
                if (loot[k] != null) p.furnLoot(x, y, z, stuff[k], face, loot[k]);
                else p.furn(x, y, z, stuff[k], face);
                placed++;
            }
        int[] c = p.freeFloor(0, 0, W - 1, D - 1, y);
        if (c != null) p.set(c[0], y, c[1], Blocks.FURNACE.getDefaultState());   // котёл
        c = p.freeFloor(0, 0, W - 1, D - 1, y);
        if (c != null) p.set(c[0], y, c[1], Blocks.CRAFTING_TABLE.getDefaultState());
        if (p.r.nextFloat() < 0.15f) {   // оружейный сейф
            c = p.freeFloor(0, 0, W - 1, D - 1, y);
            if (c != null) p.loot(c[0], y, c[1], Blocks.CHEST.getDefaultState(), p.r.nextBoolean() ? Loot.GUNSTORE : Loot.STASH);
        }
        if (p.r.nextFloat() < 0.08f) {   // записка выжившего
            c = p.freeFloor(0, 0, W - 1, D - 1, y);
            if (c != null) {
                p.loot(c[0], y, c[1], Blocks.BARREL.getDefaultState(), Loot.LIVING);
                p.note(c[0], y, c[1], -1);
            }
        }
        for (int k = 0; k < 4; k++) {   // паутина по углам
            c = p.freeFloor(0, 0, W - 1, D - 1, y);
            if (c != null) p.set(c[0], -1, c[1], Blocks.COBWEB.getDefaultState());
        }
        if (p.r.nextFloat() < 0.25f) MetroBuildings.zombies(p, 0, 0, W - 1, D - 1, y, 1 + p.r.nextInt(2), null);
    }
}
