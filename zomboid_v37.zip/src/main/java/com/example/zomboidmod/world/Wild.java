package com.example.zomboidmod.world;

import com.example.zomboidmod.ZombieOutfit;
import com.example.zomboidmod.block.DecalBlock;
import com.example.zomboidmod.block.ZomboidBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.LanternBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.enums.SlabType;
import net.minecraft.util.math.Direction;

import java.util.Map;

/**
 * Постройки мест между поселениями. Координаты плана: x вдоль «улицы», z вглубь, y = 0 — уровень земли.
 * Для мест у дороги дорога со стороны z = -1; для мест на дороге дорога идёт вдоль z, её середина — x = w / 2.
 */
final class Wild {
    private Wild() {
    }

    static void build(Sites.Kind k, Plan p) {
        switch (k) {
            case CABIN -> cabin(p);
            case TOWER -> tower(p);
            case CAMP -> camp(p);
            case HELI -> heli(p);
            case EVAC -> evac(p);
            case GRAVEYARD -> graveyard(p);
            case TRAILERS -> trailers(p);
            case RADIO -> radio(p);
            case SAFEHOUSE -> safehouse(p);
            case BURNT -> burnt(p);
            case PLANE -> plane(p);
            case STASH -> stash(p);
            case GAS -> {
                Buildings.gasStation(p);
                p.note(22, 1, 5, -1);
                Buildings.car(p, 16, 0, false);
            }
            case DINER -> {
                Buildings.diner(p);
                Buildings.car(p, 1, 0, false);
            }
            case MOTEL -> {
                Buildings.motel(p);
                p.danger = 1;
            }
            case REST -> rest(p);
            case BUSSTOP -> busStop(p);
            case ROADBLOCK -> roadblock(p);
            case PILEUP -> pileup(p);
        }
    }

    // ===================== детали =====================
    static void blood(Plan p, int x, int y, int z) {
        if (p.get(x, y, z) == null || p.get(x, y, z).isAir())
            p.set(x, y, z, ZomboidBlocks.BLOOD.getDefaultState().with(DecalBlock.VARIANT, p.r.nextInt(4)));
    }

    static void litter(Plan p, int x, int y, int z) {
        if (p.get(x, y, z) == null || p.get(x, y, z).isAir())
            p.set(x, y, z, ZomboidBlocks.LITTER.getDefaultState().with(DecalBlock.VARIANT, p.r.nextInt(4)));
    }

    static void scatter(Plan p, int x1, int z1, int x2, int z2, int n, boolean bloodToo) {
        for (int i = 0; i < n; i++) {
            int x = x1 + p.r.nextInt(x2 - x1 + 1), z = z1 + p.r.nextInt(z2 - z1 + 1);
            if (bloodToo && p.r.nextFloat() < 0.4f) blood(p, x, 1, z);
            else litter(p, x, 1, z);
        }
    }

    /** Палатка-домик из шерсти: вход со стороны z1. */
    static void tent(Plan p, int x, int z1, int len, Block wool) {
        for (int z = z1; z < z1 + len; z++) {
            p.set(x, 1, z, wool);
            p.set(x + 2, 1, z, wool);
            p.set(x + 1, 2, z, wool);
        }
        p.set(x + 1, 1, z1 + len - 1, wool);
        p.set(x + 1, 1, z1 + 1, Blocks.RED_CARPET);   // спальник
    }

    static void campfire(Plan p, int x, int z, boolean lit) {
        p.set(x, 1, z, Blocks.CAMPFIRE.getDefaultState().with(CampfireBlock.LIT, lit).with(CampfireBlock.SIGNAL_FIRE, lit));
        if (lit) p.set(x, 0, z, Blocks.HAY_BLOCK);    // столб дыма видно издалека
    }

    static void ground(Plan p, int x1, int z1, int x2, int z2, Block a, Block b, float mix) {
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) p.set(x, 0, z, p.r.nextFloat() < mix ? b : a);
    }

    static void fenceLine(Plan p, int x1, int z1, int x2, int z2, Block b, int h, float gaps) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
                if (p.r.nextFloat() < gaps) continue;
                for (int y = 1; y <= h; y++) p.set(x, y, z, b);
            }
    }

    static BlockState slabTop(Block b) {
        return b.getDefaultState().with(SlabBlock.TYPE, SlabType.TOP);
    }

    // ===================== в глуши =====================
    /** Охотничий домик и вышка-засидка рядом. */
    static void cabin(Plan p) {
        Buildings.cabin(p);
        p.note(8, 1, 8, Stories.T_CABIN);
        if (p.r.nextFloat() < 0.35f) p.stashMap(8, 1, 8);
        p.fill(0, 1, 11, 0, 3, 11, Blocks.SPRUCE_LOG);
        p.fill(0, 4, 10, 1, 4, 11, Blocks.SPRUCE_SLAB);
    }

    /** Пожарная вышка: четыре опоры, лестница, будка наверху — с неё видно всю округу. */
    static void tower(Plan p) {
        Block log = Blocks.SPRUCE_LOG, plank = Blocks.SPRUCE_PLANKS;
        int top = 13;
        for (int[] c : new int[][]{{1, 1}, {7, 1}, {1, 7}, {7, 7}}) p.fill(c[0], 1, c[1], c[0], top - 1, c[1], log);
        for (int y : new int[]{4, 8}) {
            for (int x = 2; x <= 6; x++) {
                p.set(x, y, 1, Blocks.SPRUCE_FENCE);
                p.set(x, y, 7, Blocks.SPRUCE_FENCE);
            }
            for (int z = 2; z <= 6; z++) {
                p.set(1, y, z, Blocks.SPRUCE_FENCE);
                p.set(7, y, z, Blocks.SPRUCE_FENCE);
            }
        }
        // лестница по столбу с северной стороны
        p.fill(4, 1, 1, 4, top - 1, 1, plank);
        p.ladder(4, 1, top - 1, 0, Direction.NORTH);
        p.fill(0, top - 1, 0, 8, top - 1, 8, plank);
        p.set(4, top - 1, 0, Blocks.LADDER.getDefaultState().with(net.minecraft.block.LadderBlock.FACING, Direction.NORTH));
        for (int x = 0; x <= 8; x++) {
            p.set(x, top, 0, Blocks.SPRUCE_FENCE);
            p.set(x, top, 8, Blocks.SPRUCE_FENCE);
        }
        for (int z = 0; z <= 8; z++) {
            p.set(0, top, z, Blocks.SPRUCE_FENCE);
            p.set(8, top, z, Blocks.SPRUCE_FENCE);
        }
        p.set(4, top, 0, Blocks.AIR);
        p.set(4, top, 1, Blocks.AIR);
        // будка
        p.walls(2, top, 2, 6, top + 2, 6, plank.getDefaultState());
        for (int i = 3; i <= 5; i++) {
            p.set(i, top + 1, 2, Blocks.GLASS_PANE);
            p.set(i, top + 1, 6, Blocks.GLASS_PANE);
            p.set(2, top + 1, i, Blocks.GLASS_PANE);
            p.set(6, top + 1, i, Blocks.GLASS_PANE);
        }
        p.door(4, top, 2, Blocks.SPRUCE_DOOR, Direction.NORTH);
        p.fill(1, top + 3, 1, 7, top + 3, 7, Blocks.SPRUCE_SLAB);
        p.furn(5, top, 5, "desk", Direction.NORTH);
        p.furn(3, top, 5, "radio", Direction.NORTH);
        p.loot(5, top, 3, Buildings.chest(Direction.WEST), Loot.CABIN);
        p.note(5, top, 3, Stories.T_TOWER);
        if (p.r.nextFloat() < 0.5f) p.stashMap(5, top, 3);
        p.set(3, top + 2, 4, Blocks.LANTERN.getDefaultState().with(LanternBlock.HANGING, true));
        p.zombie(4, top, 4, ZombieOutfit.FARMER, 1);
        p.zombie(3, 1, 3, null, 0);
    }

    /** Кемпинг: палатки вокруг костровища, машина, холодильник-бочка, брошенные рюкзаки. */
    static void camp(Plan p) {
        ground(p, 0, 0, p.w - 1, p.d - 1, Blocks.GRASS_BLOCK, Blocks.COARSE_DIRT, 0.25f);
        Block[] wools = {Blocks.ORANGE_WOOL, Blocks.BLUE_WOOL, Blocks.GREEN_WOOL, Blocks.YELLOW_WOOL, Blocks.RED_WOOL};
        int[][] tents = {{2, 2}, {8, 1}, {15, 3}, {3, 11}};
        for (int i = 0; i < tents.length; i++) {
            if (i == 3 && p.r.nextBoolean()) continue;
            tent(p, tents[i][0], tents[i][1], 4, wools[p.r.nextInt(wools.length)]);
            p.pile(tents[i][0] + 1, 1, tents[i][1] + 2, p.r.nextBoolean() ? Loot.CABIN : Loot.BEDROOM);
        }
        int cx = 11, cz = 10;
        campfire(p, cx, cz, false);
        for (int[] b : new int[][]{{cx - 2, cz}, {cx + 2, cz}, {cx, cz + 2}})
            p.set(b[0], 1, b[1], Blocks.SPRUCE_LOG.getDefaultState().with(net.minecraft.block.PillarBlock.AXIS, b[0] == cx ? Direction.Axis.X : Direction.Axis.Z));
        p.loot(cx + 3, 1, cz - 2, Buildings.BARREL, Loot.FRIDGE);
        p.table(cx - 3, 1, cz - 3);
        p.pile(cx - 3, 3, cz - 3, Loot.DINER);
        p.loot(15, 1, 13, Buildings.chest(Direction.NORTH), Loot.CABIN);
        p.note(15, 1, 13, Stories.T_CAMP);
        Buildings.car(p, 16, 14, false, p.r.nextBoolean() ? "pickup" : "van");
        scatter(p, 1, 1, p.w - 2, p.d - 2, 9, true);
        for (int i = 0; i < 3 + p.r.nextInt(2); i++) p.zombie(5 + p.r.nextInt(12), 1, 6 + p.r.nextInt(8), p.r.nextBoolean() ? ZombieOutfit.CIVILIAN_SHORTS : ZombieOutfit.CIVILIAN_HOODIE, 0);
    }

    /** Разбитый военный вертолёт: обгоревшая земля, фюзеляж, хвост, лопасти, дым от пожара. */
    static void heli(Plan p) {
        p.danger = 3;
        for (int x = 0; x < p.w; x++)
            for (int z = 0; z < p.d; z++) {
                double dd = Math.hypot((x - 10) / 9.0, (z - 8) / 6.0);
                if (dd < 1 && p.r.nextFloat() < 1.1 - dd) p.set(x, 0, z, p.r.nextFloat() < 0.4f ? Blocks.COARSE_DIRT : (p.r.nextFloat() < 0.5f ? Blocks.BLACKSTONE : Blocks.COAL_BLOCK));
            }
        Block body = Blocks.GRAY_CONCRETE, dark = Blocks.BLACK_CONCRETE;
        // фюзеляж 9x4x3 с кабиной
        p.walls(5, 1, 6, 13, 3, 9, body.getDefaultState());
        p.fill(5, 4, 6, 13, 4, 9, Blocks.GRAY_CONCRETE);
        p.air(6, 1, 7, 12, 3, 8);
        for (int z = 7; z <= 8; z++) {
            p.set(5, 2, z, Blocks.GRAY_STAINED_GLASS_PANE);
            p.set(5, 3, z, Blocks.GRAY_STAINED_GLASS_PANE);
        }
        p.air(9, 1, 6, 10, 2, 6);                       // распахнутая дверь
        p.air(8, 1, 9, 9, 2, 9);                        // оторванный борт
        p.fill(6, 0, 7, 12, 0, 8, Blocks.IRON_TRAPDOOR);
        p.set(6, 1, 7, Blocks.IRON_BLOCK);
        // хвост и киль
        p.fill(14, 3, 7, 19, 3, 8, Blocks.GRAY_CONCRETE);
        p.fill(19, 4, 7, 19, 6, 7, Blocks.GRAY_CONCRETE);
        p.fill(20, 5, 6, 20, 5, 9, Blocks.IRON_BARS);
        // несущий винт: одна лопасть сломана и лежит на земле
        p.set(9, 5, 7, Blocks.IRON_BLOCK);
        for (int i = 1; i <= 6; i++) p.set(9 + i, 5, 7, Blocks.SMOOTH_STONE_SLAB);
        for (int i = 1; i <= 4; i++) p.set(9, 5, 7 - i, Blocks.SMOOTH_STONE_SLAB);
        for (int i = 0; i < 7; i++) p.set(1 + i, 1, 12 + (i / 3), Blocks.SMOOTH_STONE_SLAB);
        // пожар: дым виден издалека
        campfire(p, 14, 10, true);
        p.set(3, 1, 4, Blocks.CAMPFIRE.getDefaultState().with(CampfireBlock.LIT, false));
        // груз
        p.furnLoot(7, 1, 8, "army_crate", Direction.EAST, Loot.ARMY);
        p.furnLoot(11, 1, 8, "army_crate", Direction.WEST, Loot.ARMY);
        p.loot(12, 1, 7, Buildings.chest(Direction.WEST), Loot.CLINIC);
        p.note(12, 1, 7, Stories.T_HELI);
        p.stashMap(12, 1, 7);
        p.pile(16, 1, 12, Loot.ARMY);
        p.pile(3, 1, 9, Loot.POLICE);
        scatter(p, 1, 2, p.w - 2, p.d - 2, 10, true);
        for (int i = 0; i < 3; i++) p.zombie(3 + p.r.nextInt(16), 1, 2 + p.r.nextInt(3) + (i == 2 ? 9 : 0), ZombieOutfit.SOLDIER, 3);
        p.zombie(8, 1, 7, ZombieOutfit.SOLDIER, 3);
    }

    /** Брошенный военный лагерь эвакуации: забор, ворота, палатки, медпалатка, склад, вышка. */
    static void evac(Plan p) {
        p.danger = 3;
        int W = p.w - 1, D = p.d - 1;
        ground(p, 0, 0, W, D, Blocks.GRASS_BLOCK, Blocks.COARSE_DIRT, 0.35f);
        for (int x = 1; x < W; x++) for (int z = 14; z <= 16; z++) p.set(x, 0, z, Blocks.GRAVEL);
        for (int z = 1; z < D; z++) for (int x = 18; x <= 20; x++) p.set(x, 0, z, Blocks.GRAVEL);
        // сетчатый забор с проломами
        fenceLine(p, 0, 0, W, 0, Blocks.IRON_BARS, 2, 0.08f);
        fenceLine(p, 0, D, W, D, Blocks.IRON_BARS, 2, 0.08f);
        fenceLine(p, 0, 0, 0, D, Blocks.IRON_BARS, 2, 0.08f);
        fenceLine(p, W, 0, W, D, Blocks.IRON_BARS, 2, 0.08f);
        // ворота и КПП
        for (int x = 17; x <= 21; x++) {
            p.set(x, 1, 0, Blocks.AIR);
            p.set(x, 2, 0, Blocks.AIR);
        }
        p.furn(17, 1, 1, "road_barrier", Direction.NORTH);
        p.furn(21, 1, 1, "road_barrier", Direction.NORTH);
        for (int x = 13; x <= 16; x++) p.furn(x, 1, 2, "sandbags", Direction.NORTH);
        for (int x = 22; x <= 25; x++) p.furn(x, 1, 2, "sandbags", Direction.NORTH);
        // палатки (большие, зелёные) с койками
        int[][] tents = {{3, 3}, {9, 3}, {25, 3}, {31, 3}, {3, 19}, {9, 19}, {25, 19}};
        for (int[] t : tents) bigTent(p, t[0], t[1], Blocks.GREEN_WOOL, Loot.BEDROOM);
        // медицинская палатка
        bigTent(p, 31, 19, Blocks.WHITE_WOOL, Loot.HOSPITAL);
        p.set(33, 4, 23, Blocks.RED_CONCRETE);
        // склад
        for (int i = 0; i < 4; i++) p.furnLoot(23 + i, 1, 12, "army_crate", Direction.NORTH, i % 2 == 0 ? Loot.ARMY : Loot.GROCERY);
        p.furn(22, 1, 12, "generator", Direction.NORTH);
        p.loot(27, 1, 12, Buildings.chest(Direction.NORTH), Loot.ARMY);
        p.note(27, 1, 12, Stories.T_EVAC);
        p.stashMap(27, 1, 12);
        // мешки для тел
        for (int i = 0; i < 6; i++) p.set(4 + i * 2, 1, 30, Blocks.BLACK_CARPET);
        // вышка
        p.fill(36, 1, 31, 36, 5, 31, Blocks.SPRUCE_LOG);
        p.fill(38, 1, 31, 38, 5, 31, Blocks.SPRUCE_LOG);
        p.fill(36, 1, 33, 36, 5, 33, Blocks.SPRUCE_LOG);
        p.fill(38, 1, 33, 38, 5, 33, Blocks.SPRUCE_LOG);
        p.fill(36, 6, 31, 38, 6, 33, Blocks.SPRUCE_PLANKS);
        p.ladder(37, 1, 6, 30, Direction.NORTH);
        p.fill(37, 1, 31, 37, 5, 31, Blocks.SPRUCE_PLANKS);
        p.furn(36, 7, 32, "sandbags", Direction.WEST);
        p.furn(38, 7, 32, "sandbags", Direction.EAST);
        p.pile(37, 7, 32, Loot.ARMY);
        Buildings.car(p, 15, 8, true, "ambulance");
        Buildings.car(p, 29, 26, false, "van");
        scatter(p, 1, 1, W - 1, D - 1, 26, true);
        for (int i = 0; i < 6; i++) p.zombie(2 + p.r.nextInt(W - 4), 1, 5 + p.r.nextInt(D - 8), ZombieOutfit.SOLDIER, 3);
        for (int i = 0; i < 6; i++) p.zombie(2 + p.r.nextInt(W - 4), 1, 5 + p.r.nextInt(D - 8), null, 2);
        p.zombie(33, 1, 22, ZombieOutfit.DOCTOR, 2);
        p.zombie(32, 1, 21, ZombieOutfit.NURSE, 2);
    }

    static void bigTent(Plan p, int x, int z, Block wool, Loot loot) {
        // 5 в ширину, 7 в длину, вход с севера
        for (int zz = z; zz < z + 7; zz++) {
            p.set(x, 1, zz, wool);
            p.set(x + 4, 1, zz, wool);
            p.set(x + 1, 2, zz, wool);
            p.set(x + 3, 2, zz, wool);
            p.set(x + 2, 3, zz, wool);
            p.set(x + 1, 1, zz, Blocks.AIR);
            p.set(x + 2, 1, zz, Blocks.AIR);
            p.set(x + 3, 1, zz, Blocks.AIR);
            p.set(x + 2, 2, zz, Blocks.AIR);
        }
        for (int xx = x; xx <= x + 4; xx++) {
            p.set(xx, 1, z + 6, wool);
            if (xx > x && xx < x + 4) p.set(xx, 2, z + 6, wool);
        }
        p.set(x + 2, 3, z + 6, wool);
        p.bed(x + 1, 1, z + 2, Blocks.WHITE_BED, Direction.SOUTH);
        p.bed(x + 3, 1, z + 2, Blocks.WHITE_BED, Direction.SOUTH);
        p.pile(x + 2, 1, z + 5, loot);
    }

    /** Кладбище с часовней: ряды надгробий, раскопанные могилы, ограда. */
    static void graveyard(Plan p) {
        int W = p.w - 1, D = p.d - 1;
        fenceLine(p, 0, 0, W, 0, Blocks.COBBLESTONE_WALL, 1, 0.05f);
        fenceLine(p, 0, D, W, D, Blocks.COBBLESTONE_WALL, 1, 0.05f);
        fenceLine(p, 0, 0, 0, D, Blocks.COBBLESTONE_WALL, 1, 0.05f);
        fenceLine(p, W, 0, W, D, Blocks.COBBLESTONE_WALL, 1, 0.05f);
        p.set(8, 1, 0, Blocks.AIR);
        p.set(9, 1, 0, Blocks.AIR);
        Block[] stones = {Blocks.POLISHED_ANDESITE, Blocks.STONE_BRICK_WALL, Blocks.MOSSY_STONE_BRICK_WALL, Blocks.CHISELED_STONE_BRICKS};
        for (int row = 3; row < D - 1; row += 4)
            for (int x = 2; x < 16; x += 2) {
                if (p.r.nextFloat() < 0.12f) continue;
                p.set(x, 1, row, stones[p.r.nextInt(stones.length)]);
                boolean open = p.r.nextFloat() < 0.15f;
                if (open) {     // разрытая могила — кто-то выбрался
                    p.set(x, 0, row + 1, Blocks.AIR);
                    p.set(x, 0, row + 2, Blocks.AIR);
                    p.set(x, -1, row + 1, Blocks.DIRT);
                    p.set(x, -1, row + 2, Blocks.DIRT);
                    p.set(x + 1, 1, row + 1, Blocks.COARSE_DIRT);
                } else {
                    p.set(x, 0, row + 1, Blocks.COARSE_DIRT);
                    p.set(x, 0, row + 2, Blocks.COARSE_DIRT);
                    if (p.r.nextFloat() < 0.2f) p.set(x, 1, row + 2, p.r.nextBoolean() ? Blocks.POPPY : Blocks.WITHER_ROSE);
                }
            }
        // часовня
        Plan ch = new Plan(12, 12, p.r);
        Buildings.chapel(ch);
        p.embed(ch, 17, 6);
        for (int[] t : new int[][]{{20, 3}, {26, 20}, {3, 21}}) p.tree(t[0], 1, t[1], 2);
        p.set(5, 1, 1, Blocks.LANTERN);
        p.loot(26, 1, 4, Buildings.BARREL, Loot.TRASH);
        p.note(26, 1, 4, Stories.T_GRAVE);
        for (int i = 0; i < 5; i++) p.zombie(2 + p.r.nextInt(14), 1, 3 + p.r.nextInt(D - 5), p.r.nextBoolean() ? ZombieOutfit.BUSINESS : null, 1);
        p.zombie(22, 1, 12, ZombieOutfit.PRIEST, 1);
    }

    /** Трейлерный парк: несколько трейлеров, гравийный проезд, мусорка, бельё, машины. */
    static void trailers(Plan p) {
        for (int x = 0; x < p.w; x++) for (int z = 13; z <= 16; z++) p.set(x, 0, z, Blocks.GRAVEL);
        for (int i = 0; i < 3; i++) {
            Plan t = new Plan(12, 12, p.r);
            Buildings.trailer(t);
            p.embed(t, 1 + i * 12, 0);
        }
        for (int i = 0; i < 3; i++) {
            if (i == 1 && p.r.nextBoolean()) continue;
            Plan t = new Plan(12, 12, p.r);
            Buildings.trailer(t);
            p.embed(t, 1 + i * 12, 18);
        }
        p.furnLoot(36, 1, 14, "dumpster", Direction.WEST, Loot.TRASH);
        p.furnLoot(0, 1, 15, "trash_can", Direction.EAST, Loot.TRASH);
        p.loot(36, 1, 16, Buildings.BARREL, Loot.LIVING);
        p.note(36, 1, 16, Stories.T_TRAILERS);
        scatter(p, 0, 12, p.w - 1, 17, 8, true);
        for (int i = 0; i < 4; i++) p.zombie(2 + p.r.nextInt(p.w - 4), 1, 14 + p.r.nextInt(3), ZombieOutfit.TRAILER, 0);
    }

    /** Радиовышка: высокая мачта, будка с аппаратурой и генератором, забор. */
    static void radio(Plan p) {
        p.danger = 1;
        int W = p.w - 1, D = p.d - 1;
        ground(p, 0, 0, W, D, Blocks.GRAVEL, Blocks.COARSE_DIRT, 0.2f);
        fenceLine(p, 0, 0, W, 0, Blocks.IRON_BARS, 2, 0.05f);
        fenceLine(p, 0, D, W, D, Blocks.IRON_BARS, 2, 0.05f);
        fenceLine(p, 0, 0, 0, D, Blocks.IRON_BARS, 2, 0.05f);
        fenceLine(p, W, 0, W, D, Blocks.IRON_BARS, 2, 0.05f);
        p.set(6, 1, 0, Blocks.AIR);
        p.set(6, 2, 0, Blocks.AIR);
        p.set(7, 1, 0, Blocks.AIR);
        p.set(7, 2, 0, Blocks.AIR);
        // мачта
        p.fill(9, 1, 9, 10, 1, 10, Blocks.SMOOTH_STONE);
        for (int y = 2; y <= 34; y++) {
            p.set(9, y, 9, Blocks.IRON_BARS);
            p.set(10, y, 10, Blocks.IRON_BARS);
            if (y % 4 == 0) {
                p.set(10, y, 9, Blocks.IRON_BARS);
                p.set(9, y, 10, Blocks.IRON_BARS);
            }
        }
        p.set(9, 35, 9, Blocks.LIGHTNING_ROD);
        p.set(10, 35, 10, Blocks.RED_CONCRETE);
        // будка
        p.fill(1, 0, 2, 6, 0, 7, Blocks.SMOOTH_STONE);
        p.walls(1, 1, 2, 6, 3, 7, Blocks.WHITE_CONCRETE.getDefaultState());
        p.air(2, 1, 3, 5, 3, 6);
        p.fill(1, 4, 2, 6, 4, 7, Blocks.LIGHT_GRAY_CONCRETE);
        p.door(3, 1, 2, Blocks.IRON_DOOR, Direction.NORTH);
        p.set(6, 2, 4, Blocks.GLASS_PANE);
        p.set(6, 2, 5, Blocks.GLASS_PANE);
        p.furn(2, 1, 6, "desk", Direction.NORTH);
        p.furn(3, 1, 6, "radio", Direction.NORTH);
        p.furnLoot(5, 1, 6, "shelf_electronics", Direction.NORTH, Loot.ELECTRONICS);
        p.furn(5, 1, 3, "generator", Direction.WEST);
        p.loot(2, 1, 3, Buildings.chest(Direction.EAST), Loot.OFFICE);
        p.note(2, 1, 3, Stories.T_RADIO);
        p.stashMap(2, 1, 3);
        Houses.ceilingLamp(p, 4, 3, 4);
        p.zombie(3, 1, 4, ZombieOutfit.MECHANIC, 1);
    }

    /** Убежище выжившего: заколоченный дом, внутри тайник и дневник. Сам хозяин, увы, уже здесь. */
    static void safehouse(Plan p) {
        Buildings.house(p);
        for (Map.Entry<Long, BlockState> e : new java.util.ArrayList<>(p.blocks.entrySet())) {
            BlockState s = e.getValue();
            if (s.isOf(Blocks.GLASS_PANE) || s.isOf(Blocks.GLASS)) e.setValue(Blocks.OAK_PLANKS.getDefaultState());   // окна заколочены
        }
        p.zombies.clear();
        int[] c = p.freeFloor(2, 3, 9, 9, 1);
        int x = c != null ? c[0] : 5, z = c != null ? c[1] : 6;
        p.loot(x, 1, z, Buildings.chest(Direction.NORTH), Loot.STASH);
        p.note(x, 1, z, Stories.T_SAFEHOUSE);
        if (p.r.nextBoolean()) p.stashMap(x, 1, z);
        p.zombie(5, 1, 6, ZombieOutfit.SURVIVOR, 1);
        for (int i = 0; i < 4; i++) blood(p, 3 + p.r.nextInt(6), 1, 4 + p.r.nextInt(5));
        // снаружи — следы обороны: мешки, ловушка из досок, тела
        p.furn(1, 1, 1, "sandbags", Direction.NORTH);
        p.furn(2, 1, 1, "sandbags", Direction.NORTH);
        p.zombie(6, 1, 0, null, 0);
        p.zombie(9, 1, 1, null, 0);
    }

    /** Пепелище: фундамент, обгоревшие обломки стен, печная труба, сгоревшая машина. */
    static void burnt(Plan p) {
        Block[] ash = {Blocks.COARSE_DIRT, Blocks.BLACKSTONE, Blocks.GRAY_CONCRETE_POWDER, Blocks.COAL_BLOCK};
        for (int x = 1; x <= 12; x++)
            for (int z = 2; z <= 12; z++) p.set(x, 0, z, ash[p.r.nextInt(ash.length)]);
        for (int x = 2; x <= 11; x++)
            for (int z = 3; z <= 11; z++) {
                boolean edge = x == 2 || x == 11 || z == 3 || z == 11;
                if (!edge) continue;
                int h = p.r.nextFloat() < 0.4f ? 0 : 1 + p.r.nextInt(3);
                for (int y = 1; y <= h; y++) p.set(x, y, z, p.r.nextFloat() < 0.5f ? Blocks.DARK_OAK_PLANKS : (p.r.nextBoolean() ? Blocks.BLACKSTONE : Blocks.COAL_BLOCK));
            }
        p.fill(10, 1, 9, 11, 6, 10, Blocks.COBBLESTONE);
        p.fill(10, 7, 9, 10, 7, 9, Blocks.COBBLESTONE_WALL);
        p.set(6, 1, 7, Blocks.DARK_OAK_FENCE);
        p.set(7, 1, 7, Blocks.DARK_OAK_SLAB);
        p.pile(5, 1, 6, Loot.TRASH);
        p.pile(8, 1, 9, Loot.KITCHEN);
        p.vehicle(4.0, 1, 0.5, "sedan", 90f, true);
        p.zombie(6, 1, 5, ZombieOutfit.CIVILIAN_TSHIRT, 0);
    }

    /** Крушение небольшого самолёта: фюзеляж разломан надвое, крыло отлетело, вещи пассажиров по полю. */
    static void plane(Plan p) {
        p.danger = 1;
        Block body = Blocks.WHITE_CONCRETE, stripe = Blocks.BLUE_CONCRETE;
        // борозда
        for (int x = 2; x <= 27; x++) for (int z = 9; z <= 12; z++) if (p.r.nextFloat() < 0.7f) p.set(x, 0, z, Blocks.COARSE_DIRT);
        // носовая часть
        p.walls(3, 1, 9, 11, 3, 12, body.getDefaultState());
        p.fill(3, 4, 10, 11, 4, 11, body);
        p.air(4, 1, 10, 10, 3, 11);
        for (int x = 3; x <= 11; x++) {
            p.set(x, 2, 9, stripe);
            p.set(x, 2, 12, stripe);
        }
        for (int x = 5; x <= 10; x += 2) {
            p.set(x, 3, 9, Blocks.GLASS_PANE);
            p.set(x, 3, 12, Blocks.GLASS_PANE);
        }
        p.set(3, 2, 10, Blocks.GRAY_STAINED_GLASS_PANE);
        p.set(3, 2, 11, Blocks.GRAY_STAINED_GLASS_PANE);
        p.air(11, 1, 10, 11, 3, 11);                    // разлом
        // хвостовая часть, развёрнута
        p.walls(17, 1, 8, 24, 3, 11, body.getDefaultState());
        p.air(18, 1, 9, 23, 3, 10);
        p.air(17, 1, 9, 17, 3, 10);
        p.fill(24, 4, 9, 24, 6, 9, body);
        p.fill(23, 4, 8, 25, 4, 11, Blocks.WHITE_CONCRETE);
        for (int x = 17; x <= 24; x++) p.set(x, 2, 8, stripe);
        // крыло
        for (int z = 1; z <= 7; z++) p.set(8, 1, z, Blocks.SMOOTH_QUARTZ_SLAB);
        for (int z = 1; z <= 7; z++) p.set(9, 1, z, Blocks.SMOOTH_QUARTZ_SLAB);
        for (int z = 14; z <= 20; z++) {
            p.set(13 + (z - 14) / 3, 1, z, Blocks.SMOOTH_QUARTZ_SLAB);
        }
        // вещи пассажиров
        for (int i = 0; i < 7; i++) p.pile(2 + p.r.nextInt(26), 1, 2 + p.r.nextInt(18), i % 3 == 0 ? Loot.CLOTHES : (i % 3 == 1 ? Loot.BEDROOM : Loot.BATHROOM));
        p.loot(6, 1, 10, Buildings.chest(Direction.EAST), Loot.OFFICE);
        p.note(6, 1, 10, Stories.T_PLANE);
        campfire(p, 13, 11, true);
        scatter(p, 1, 1, p.w - 2, p.d - 2, 14, true);
        for (int i = 0; i < 5; i++) p.zombie(2 + p.r.nextInt(26), 1, 2 + p.r.nextInt(18), p.r.nextBoolean() ? ZombieOutfit.BUSINESS : null, 1);
    }

    /** Тайник: каменная пирамидка-метка, бочка в земле, вокруг — примятая трава. */
    static void stash(Plan p) {
        ground(p, 0, 0, 4, 4, Blocks.GRASS_BLOCK, Blocks.COARSE_DIRT, 0.4f);
        p.fill(1, 1, 1, 1, 2, 1, Blocks.COBBLESTONE);
        p.set(1, 3, 1, Blocks.MOSSY_COBBLESTONE_WALL);
        p.set(2, 1, 1, Blocks.MOSSY_COBBLESTONE);
        p.set(3, 1, 3, Blocks.RED_WOOL);                // красная тряпка — метка
        p.loot(3, 0, 2, Blocks.BARREL.getDefaultState().with(net.minecraft.block.BarrelBlock.FACING, Direction.UP), Loot.STASH);
        p.note(3, 0, 2, Stories.T_STASH);
        p.set(2, 1, 3, Blocks.DEAD_BUSH);
        p.set(2, 0, 3, Blocks.COARSE_DIRT);
    }

    // ===================== у дороги =====================
    /** Площадка отдыха: стоянка, столики, туалеты, торговые автоматы, мусорки. */
    static void rest(Plan p) {
        for (int x = 0; x < p.w; x++) for (int z = 0; z <= 4; z++) p.set(x, 0, z, Blocks.GRAY_CONCRETE);
        for (int x = 2; x < p.w - 2; x += 4) p.set(x, 0, 2, Blocks.WHITE_CONCRETE);
        Buildings.car(p, 3, 1, true);
        if (p.r.nextBoolean()) Buildings.car(p, 11, 1, true);
        for (int[] t : new int[][]{{4, 8}, {9, 8}, {4, 11}}) {
            p.table(t[0], 1, t[1]);
            p.set(t[0] - 1, 1, t[1], Blocks.SPRUCE_SLAB);
            p.set(t[0] + 1, 1, t[1], Blocks.SPRUCE_SLAB);
        }
        // туалеты
        p.fill(14, 0, 7, 20, 0, 12, Blocks.SMOOTH_STONE);
        p.walls(14, 1, 7, 20, 3, 12, Blocks.LIGHT_GRAY_CONCRETE.getDefaultState());
        p.air(15, 1, 8, 19, 3, 11);
        p.fill(17, 1, 8, 17, 3, 11, Blocks.LIGHT_GRAY_CONCRETE);
        p.door(15, 1, 7, Blocks.IRON_DOOR, Direction.NORTH);
        p.door(19, 1, 7, Blocks.IRON_DOOR, Direction.NORTH);
        p.fill(14, 4, 7, 20, 4, 12, Blocks.SMOOTH_STONE_SLAB);
        p.furn(15, 1, 11, "toilet", Direction.NORTH);
        p.furn(19, 1, 11, "toilet", Direction.NORTH);
        p.furnLoot(16, 1, 9, "bathroom_sink", Direction.WEST, Loot.BATHROOM);
        Houses.ceilingLamp(p, 16, 3, 10);
        p.furnLoot(12, 1, 7, "shelf_food", Direction.WEST, Loot.GAS);
        p.furnLoot(1, 1, 6, "trash_can", Direction.EAST, Loot.TRASH);
        p.loot(12, 1, 12, Buildings.BARREL, Loot.LIVING);
        p.note(12, 1, 12, -1);
        scatter(p, 0, 5, p.w - 1, p.d - 1, 6, true);
        for (int i = 0; i < 2 + p.r.nextInt(2); i++) p.zombie(3 + p.r.nextInt(10), 1, 6 + p.r.nextInt(6), null, 0);
    }

    static void busStop(Plan p) {
        p.fill(0, 0, 0, 5, 0, 3, Blocks.SMOOTH_STONE);
        p.fill(0, 1, 3, 5, 2, 3, Blocks.GLASS_PANE);
        p.fill(0, 3, 0, 5, 3, 3, Blocks.SMOOTH_STONE_SLAB);
        p.set(0, 1, 1, Blocks.IRON_BARS);
        p.set(5, 1, 1, Blocks.IRON_BARS);
        p.set(0, 2, 1, Blocks.IRON_BARS);
        p.set(5, 2, 1, Blocks.IRON_BARS);
        p.furn(2, 1, 2, "bench", Direction.NORTH);
        p.furn(3, 1, 2, "bench", Direction.NORTH);
        p.furnLoot(4, 1, 1, "trash_can", Direction.NORTH, Loot.TRASH);
        p.pile(1, 1, 2, Loot.BEDROOM);
        p.zombie(2, 1, 1, null, 0);
    }

    /** Полицейский кордон прямо на шоссе: машины поперёк, заграждения, конусы, мешки с песком. */
    static void roadblock(Plan p) {
        p.danger = 2;
        int mid = p.w / 2;
        for (int x = 0; x < p.w; x++) {
            if (x == mid) continue;
            p.furn(x, 1, 6, x % 3 == 0 ? "traffic_cone" : "road_barrier", Direction.NORTH);
        }
        for (int x = 1; x < p.w - 1; x += 2) p.furn(x, 1, 9, "sandbags", Direction.SOUTH);
        p.vehicle(mid - 2.0, 1, 8.0, "police", 90f + p.r.nextFloat() * 20f, false);
        p.vehicle(mid + 2.5, 1, 11.5, "police", 70f + p.r.nextFloat() * 30f, p.r.nextFloat() < 0.4f);
        p.furnLoot(1, 1, 13, "army_crate", Direction.EAST, Loot.POLICE);
        p.note(1, 1, 13, Stories.T_ROADBLOCK);
        p.pile(p.w - 2, 1, 12, Loot.POLICE);
        for (int z = 0; z < p.d; z++) if (p.r.nextFloat() < 0.35f) blood(p, 1 + p.r.nextInt(p.w - 2), 1, z);
        for (int i = 0; i < 3; i++) p.zombie(1 + p.r.nextInt(p.w - 2), 1, 1 + p.r.nextInt(4), ZombieOutfit.POLICE, 2);
        for (int i = 0; i < 3; i++) p.zombie(1 + p.r.nextInt(p.w - 2), 1, 11 + p.r.nextInt(4), null, 1);
    }

    /** Авария на шоссе: разбитые машины вкривь, стекло, кровь, кто-то так и остался рядом. */
    static void pileup(Plan p) {
        p.danger = 1;
        int n = 3 + p.r.nextInt(3);
        for (int i = 0; i < n; i++) {
            double x = 1.5 + p.r.nextDouble() * (p.w - 3);
            double z = 1.5 + i * (p.d - 3.0) / n;
            float yaw = (p.r.nextBoolean() ? 0f : 180f) + (p.r.nextFloat() - 0.5f) * 110f;
            String[] types = {"sedan", "sedan", "pickup", "van", "ambulance"};
            p.vehicle(x, 1, z, types[p.r.nextInt(types.length)], yaw, p.r.nextFloat() < 0.6f);
        }
        for (int z = 0; z < p.d; z++)
            for (int x = 0; x < p.w; x++) {
                float k = p.r.nextFloat();
                if (k < 0.06f) blood(p, x, 1, z);
                else if (k < 0.12f) litter(p, x, 1, z);
            }
        p.pile(1, 1, p.d / 2, Loot.GARAGE);
        p.pile(p.w - 2, 1, 2, Loot.BEDROOM);
        for (int i = 0; i < 4; i++) p.zombie(p.r.nextInt(p.w), 1, p.r.nextInt(p.d), null, 1);
    }
}
