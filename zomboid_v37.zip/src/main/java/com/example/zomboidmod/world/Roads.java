package com.example.zomboidmod.world;

import com.example.zomboidmod.block.BuildingBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.enums.SlabType;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Шоссе между поселениями соседних регионов. Не «буквой Г» по сетке, а плавной кривой; профиль высоты
 * считается сразу для всей дороги по шуму рельефа (а не по уже построенным кускам), поэтому куски всегда стыкуются.
 * Уклон не круче 1:7, полублоки на подъёмах, насыпи и выемки с откосами, мосты на опорах над водой и оврагами,
 * тоннели сквозь высокие холмы, разметка, отбойники, столбики, брошенные машины и указатели.
 */
final class Roads {
    private Roads() {
    }

    static final int PIECE = 32;
    static final double LANE = 3.5, SHOULDER = 4.5;
    static final int SLOPE = 8;
    private static final int FLAGS = Block.NOTIFY_LISTENERS | Block.FORCE_STATE;

    // =====================================================================================
    //                                       геометрия
    // =====================================================================================

    static final class Road {
        final long key;
        final Knox.Settlement a, b;
        final double[] px, pz;
        final int n;
        final double[] na, nb;
        float pinA, pinB;
        final List<int[]> blockers = new ArrayList<>();
        float[] h;
        boolean[] bridge, tunnel;

        Road(long key, Knox.Settlement a, Knox.Settlement b, List<double[]> line, double[] na, double[] nb) {
            this.key = key;
            this.a = a;
            this.b = b;
            this.n = line.size();
            px = new double[n];
            pz = new double[n];
            for (int i = 0; i < n; i++) {
                px[i] = line.get(i)[0];
                pz[i] = line.get(i)[1];
            }
            this.na = na;
            this.nb = nb;
        }

        int pieces() {
            return (n + PIECE - 1) / PIECE;
        }

        long pieceKey(int i) {
            return key * 97L + i + 0x6A11000000000000L;
        }

        double x(double t) {
            int i = Math.max(0, Math.min(n - 2, (int) Math.floor(t)));
            double f = Math.max(0, Math.min(1, t - i));
            return px[i] + (px[i + 1] - px[i]) * f;
        }

        double z(double t) {
            int i = Math.max(0, Math.min(n - 2, (int) Math.floor(t)));
            double f = Math.max(0, Math.min(1, t - i));
            return pz[i] + (pz[i + 1] - pz[i]) * f;
        }

        /** Единичное направление дороги в точке t. */
        double[] dir(double t) {
            int i = (int) Math.round(t);
            int i0 = Math.max(0, i - 2), i1 = Math.min(n - 1, i + 2);
            double dx = px[i1] - px[i0], dz = pz[i1] - pz[i0];
            double l = Math.max(1e-6, Math.hypot(dx, dz));
            return new double[]{dx / l, dz / l};
        }

        float height(double t) {
            int i = Math.max(0, Math.min(n - 2, (int) Math.floor(t)));
            double f = Math.max(0, Math.min(1, t - i));
            return (float) (h[i] + (h[i + 1] - h[i]) * f);
        }

        boolean bridgeAt(double t) {
            return bridge[Math.max(0, Math.min(n - 1, (int) Math.round(t)))];
        }

        boolean tunnelAt(double t) {
            return tunnel[Math.max(0, Math.min(n - 1, (int) Math.round(t)))];
        }

        boolean blocked(int x, int z) {
            for (int[] q : blockers) if (x >= q[0] && x <= q[2] && z >= q[1] && z <= q[3]) return true;
            return false;
        }

        /** Профиль высоты для всей дороги (один раз): сглаженный рельеф, уклон не круче 1:7, мосты и тоннели. */
        synchronized void profile(ServerWorld w) {
            if (h != null) return;
            pinA = Knox.pinHeight(w, a, na);
            pinB = Knox.pinHeight(w, b, nb);
            final int S = 8;
            int m = (n - 1 + S - 1) / S + 1;   // последний отсчёт — ровно конец дороги
            int[] ts = new int[m];
            for (int i = 0; i < m; i++) ts[i] = Math.min(n - 1, i * S);
            float[] tg = new float[m], gr = new float[m];
            boolean[] wet = new boolean[m];
            int sea = w.getSeaLevel();
            for (int i = 0; i < m; i++) {
                int t = ts[i];
                int x = (int) Math.floor(px[t]), z = (int) Math.floor(pz[t]);
                wet[i] = Terrain.wet(w, x, z);
                gr[i] = Terrain.ground(w, x, z);
                tg[i] = wet[i] ? sea + 2 : Math.max(sea, Terrain.smooth(w, x, z));
            }
            float[] sm = new float[m];
            for (int i = 0; i < m; i++) {
                float s = 0, ws = 0;
                for (int k = -2; k <= 2; k++) {
                    int j = Math.max(0, Math.min(m - 1, i + k));
                    float wk = 3 - Math.abs(k);
                    s += tg[j] * wk;
                    ws += wk;
                }
                sm[i] = s / ws;
                if (wet[i]) sm[i] = Math.max(sm[i], sea + 2);
            }
            sm[0] = pinA;
            sm[m - 1] = pinB;
            for (int rep = 0; rep < 5; rep++) {   // концы закреплены, уклон между соседними отсчётами не круче 1:7
                for (int i = 1; i < m - 1; i++) {
                    float G = (ts[i] - ts[i - 1]) / 7f;
                    sm[i] = Math.max(sm[i - 1] - G, Math.min(sm[i - 1] + G, sm[i]));
                }
                for (int i = m - 2; i >= 1; i--) {
                    float G = (ts[i + 1] - ts[i]) / 7f;
                    sm[i] = Math.max(sm[i + 1] - G, Math.min(sm[i + 1] + G, sm[i]));
                }
                for (int i = 1; i < m - 1; i++) if (wet[i]) sm[i] = Math.max(sm[i], sea + 2);
            }
            sm[0] = pinA;
            sm[m - 1] = pinB;
            h = new float[n];
            bridge = new boolean[n];
            tunnel = new boolean[n];
            for (int t = 0; t < n; t++) {
                int i = Math.min(m - 2, t / S);
                float f = (t - ts[i]) / (float) Math.max(1, ts[i + 1] - ts[i]);
                h[t] = sm[i] + (sm[i + 1] - sm[i]) * Math.max(0f, Math.min(1f, f));
                int k = Math.min(m - 1, Math.round(t / (float) S));
                boolean br = wet[k] || h[t] - gr[k] > 5.5f;
                boolean tn = !wet[k] && gr[k] - h[t] > 10f;
                if (br) for (int d = -3; d <= 3; d++) if (t + d >= 0 && t + d < n) bridge[t + d] = true;
                if (tn) tunnel[t] = true;
            }
            // тоннель — только сплошной участок не короче 16 блоков (иначе выемка)
            int run = 0;
            for (int t = 0; t <= n; t++) {
                if (t < n && tunnel[t]) run++;
                else {
                    if (run > 0 && run < 16) for (int k = t - run; k < t; k++) tunnel[k] = false;
                    run = 0;
                }
            }
        }
    }

    private static final Map<Long, Road> CACHE = new LinkedHashMap<>(64, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Long, Road> e) {
            return size() > 96;
        }
    };
    private static long cacheSeed = Long.MIN_VALUE;
    private static final Road NONE = new Road(0, null, null, List.of(new double[]{0, 0}, new double[]{1, 0}), null, null);

    /** Дорога от региона (rx, rz) к соседу справа (dir 0) или снизу (dir 1); null — её нет. */
    static synchronized Road road(long seed, int rx, int rz, int dir) {
        if (seed != cacheSeed) {
            CACHE.clear();
            cacheSeed = seed;
        }
        long key = (Knox.regionKey(rx, rz) << 1) | dir;
        Road r = CACHE.get(key);
        if (r == null) {
            r = build(seed, rx, rz, dir, key);
            CACHE.put(key, r == null ? NONE : r);
        }
        return r == NONE ? null : r;
    }

    /** Все дороги, касающиеся региона. */
    static List<Road> around(long seed, int rx, int rz) {
        List<Road> out = new ArrayList<>(4);
        for (Road r : new Road[]{road(seed, rx, rz, 0), road(seed, rx, rz, 1), road(seed, rx - 1, rz, 0), road(seed, rx, rz - 1, 1)})
            if (r != null) out.add(r);
        return out;
    }

    private static Road build(long seed, int rx, int rz, int dir, long key) {
        int bx = rx + (dir == 0 ? 1 : 0), bz = rz + (dir == 1 ? 1 : 0);
        Knox.Settlement A = Knox.settlement(seed, rx, rz), B = Knox.settlement(seed, bx, bz);
        if (A.key() == B.key()) return null;   // внутри одного мегаполиса — свои улицы
        // стороны: 0 восток, 1 юг, 2 запад, 3 север
        double[] na = Knox.entrance(seed, A, dir == 0 ? 0 : 1, B.cx(), B.cz());
        double[] nb = Knox.entrance(seed, B, dir == 0 ? 2 : 3, A.cx(), A.cz());
        List<double[]> ctrl = new ArrayList<>();
        ctrl.add(new double[]{na[0], na[1]});
        if (na[4] > 0) ctrl.add(new double[]{na[0] + na[2] * na[4], na[1] + na[3] * na[4]});
        double[] qa = ctrl.get(ctrl.size() - 1);
        double[] qb = nb[4] > 0 ? new double[]{nb[0] + nb[2] * nb[4], nb[1] + nb[3] * nb[4]} : new double[]{nb[0], nb[1]};
        double dx = qb[0] - qa[0], dz = qb[1] - qa[1], dist = Math.hypot(dx, dz);
        java.util.Random r = new java.util.Random(seed ^ key * 0x9E3779B97F4A7C15L);
        if (dist > 90) {
            double ux = -dz / dist, uz = dx / dist;
            for (int k = 1; k <= 2; k++) {
                double f = k / 3.0, off = (r.nextDouble() * 2 - 1) * 0.13 * dist;
                ctrl.add(new double[]{qa[0] + dx * f + ux * off, qa[1] + dz * f + uz * off});
            }
        }
        if (nb[4] > 0) ctrl.add(qb);
        ctrl.add(new double[]{nb[0], nb[1]});
        List<double[]> line = resample(spline(ctrl));
        if (line.size() < 4) return null;
        Road road = new Road(key, A, B, line, na, nb);
        // куда дорога не заходит: поселения вокруг обоих концов
        java.util.Set<Long> seen = new java.util.HashSet<>();
        for (int gx = Math.min(rx, bx) - 1; gx <= Math.max(rx, bx) + 1; gx++)
            for (int gz = Math.min(rz, bz) - 1; gz <= Math.max(rz, bz) + 1; gz++) {
                Knox.Settlement s = Knox.settlement(seed, gx, gz);
                if (!seen.add(s.key()) || s.type() == Knox.Type.NONE) continue;
                for (int[] q : s.rects()) road.blockers.add(new int[]{q[0], q[1], q[2], q[3]});
            }
        return road;
    }

    // ----- кривая Кэтмулла — Рома (центростремительная) и равномерная разбивка -----
    private static double[] cr(double[] p0, double[] p1, double[] p2, double[] p3, double u) {
        double t0 = 0, t1 = t0 + Math.max(1e-3, Math.sqrt(Math.hypot(p1[0] - p0[0], p1[1] - p0[1])));
        double t2 = t1 + Math.max(1e-3, Math.sqrt(Math.hypot(p2[0] - p1[0], p2[1] - p1[1])));
        double t3 = t2 + Math.max(1e-3, Math.sqrt(Math.hypot(p3[0] - p2[0], p3[1] - p2[1])));
        double t = t1 + (t2 - t1) * u;
        double[] out = new double[2];
        for (int k = 0; k < 2; k++) {
            double a1 = (t1 - t) / (t1 - t0) * p0[k] + (t - t0) / (t1 - t0) * p1[k];
            double a2 = (t2 - t) / (t2 - t1) * p1[k] + (t - t1) / (t2 - t1) * p2[k];
            double a3 = (t3 - t) / (t3 - t2) * p2[k] + (t - t2) / (t3 - t2) * p3[k];
            double b1 = (t2 - t) / (t2 - t0) * a1 + (t - t0) / (t2 - t0) * a2;
            double b2 = (t3 - t) / (t3 - t1) * a2 + (t - t1) / (t3 - t1) * a3;
            out[k] = (t2 - t) / (t2 - t1) * b1 + (t - t1) / (t2 - t1) * b2;
        }
        return out;
    }

    private static List<double[]> spline(List<double[]> c) {
        List<double[]> p = new ArrayList<>();
        double[] f = c.get(0), s = c.get(1), l = c.get(c.size() - 1), pl = c.get(c.size() - 2);
        p.add(new double[]{2 * f[0] - s[0], 2 * f[1] - s[1]});
        p.addAll(c);
        p.add(new double[]{2 * l[0] - pl[0], 2 * l[1] - pl[1]});
        List<double[]> out = new ArrayList<>();
        for (int i = 1; i < p.size() - 2; i++) {
            double seg = Math.hypot(p.get(i + 1)[0] - p.get(i)[0], p.get(i + 1)[1] - p.get(i)[1]);
            int steps = Math.max(2, (int) (seg * 2));
            for (int k = 0; k < steps; k++) out.add(cr(p.get(i - 1), p.get(i), p.get(i + 1), p.get(i + 2), k / (double) steps));
        }
        out.add(l);
        return out;
    }

    private static List<double[]> resample(List<double[]> pts) {
        List<double[]> out = new ArrayList<>();
        out.add(pts.get(0));
        double carry = 0;
        for (int i = 1; i < pts.size(); i++) {
            double[] a = pts.get(i - 1), b = pts.get(i);
            double seg = Math.hypot(b[0] - a[0], b[1] - a[1]);
            double pos = 1.0 - carry;
            while (pos <= seg) {
                double f = pos / seg;
                out.add(new double[]{a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f});
                pos += 1.0;
            }
            carry = seg - (pos - 1.0);
        }
        double[] last = pts.get(pts.size() - 1), pl = out.get(out.size() - 1);
        if (Math.hypot(last[0] - pl[0], last[1] - pl[1]) > 0.3) out.add(last);
        return out;
    }

    /** Ломаная для бумажной карты (каждые step блоков). */
    static int[] polyline(Road r, int step) {
        int k = (r.n - 1) / step + 2;
        int[] out = new int[k * 2];
        for (int i = 0; i < k; i++) {
            int t = Math.min(r.n - 1, i * step);
            out[i * 2] = (int) Math.round(r.px[t]);
            out[i * 2 + 1] = (int) Math.round(r.pz[t]);
        }
        return out;
    }

    /** Прямой и почти вдоль оси участок вокруг t (для мест у дороги): 1 — вдоль X, 2 — вдоль Z, 0 — нет. */
    static int straight(Road r, int t, int half) {
        if (t - half < 0 || t + half >= r.n) return 0;
        double dx = r.px[t + half] - r.px[t - half], dz = r.pz[t + half] - r.pz[t - half];
        double l = Math.hypot(dx, dz);
        if (l < 2 * half * 0.98) return 0;               // изогнутый
        if (Math.abs(dx) / l > 0.985) return 1;
        if (Math.abs(dz) / l > 0.985) return 2;
        return 0;
    }

    /** Не задевает ли прямоугольник дорогу (кроме except) с запасом margin. */
    static boolean clear(List<Road> roads, int x1, int z1, int x2, int z2, double margin, Road except) {
        for (Road r : roads) {
            if (r == except) continue;
            for (int t = 0; t < r.n; t += 2) {
                double dx = Math.max(Math.max(x1 - r.px[t], 0), r.px[t] - (x2 + 1));
                double dz = Math.max(Math.max(z1 - r.pz[t], 0), r.pz[t] - (z2 + 1));
                if (Math.hypot(dx, dz) < margin) return false;
            }
        }
        return true;
    }

    static boolean isRoadBlock(BlockState s) {
        if (s.isOf(Blocks.GRAVEL) || s.isOf(Blocks.STONE_BRICKS) || s.isOf(Blocks.BLACK_CONCRETE) || s.isOf(Blocks.YELLOW_CONCRETE)) return true;
        String id = net.minecraft.registry.Registries.BLOCK.getId(s.getBlock()).getPath();
        return id.startsWith("asphalt") || id.startsWith("road_line") || id.startsWith("sidewalk");
    }

    // =====================================================================================
    //                                       стройка куска
    // =====================================================================================

    static final class PieceJob implements Knox.Job {
        final Road rd;
        final int idx;
        List<double[]> cols;   // {x, z, |o|, t}
        List<int[]> protect;
        int i;
        boolean finished;

        PieceJob(Road rd, int idx) {
            this.rd = rd;
            this.idx = idx;
        }

        public boolean done() {
            return finished;
        }

        private void rasterize(ServerWorld w) {
            rd.profile(w);
            int t0 = idx * PIECE, t1 = Math.min(rd.n, t0 + PIECE);
            int a = Math.max(0, t0 - 10), b = Math.min(rd.n - 1, t1 + 10);
            double R = SHOULDER + SLOPE + 0.5;
            Map<Long, double[]> best = new HashMap<>();
            for (double t = a; t <= b; t += 0.5) {
                double cx = rd.x(t), cz = rd.z(t);
                double[] d = rd.dir(t);
                double nx = -d[1], nz = d[0];
                for (double o = -R; o <= R; o += 0.5) {
                    int x = (int) Math.floor(cx + nx * o), z = (int) Math.floor(cz + nz * o);
                    long k = BlockPos.asLong(x, 0, z);
                    if (best.containsKey(k)) continue;
                    // точное расстояние центра клетки до оси (по соседним отрезкам)
                    double bx = x + 0.5, bz = z + 0.5, bd = Double.MAX_VALUE, btt = t;
                    int c = (int) Math.floor(t);
                    for (int j = Math.max(0, c - 4); j < Math.min(rd.n - 1, c + 5); j++) {
                        double ex = rd.px[j + 1] - rd.px[j], ez = rd.pz[j + 1] - rd.pz[j];
                        double l2 = Math.max(1e-9, ex * ex + ez * ez);
                        double u = Math.max(0, Math.min(1, ((bx - rd.px[j]) * ex + (bz - rd.pz[j]) * ez) / l2));
                        double qx = rd.px[j] + ex * u, qz = rd.pz[j] + ez * u;
                        double dd = Math.hypot(bx - qx, bz - qz);
                        if (dd < bd) {
                            bd = dd;
                            btt = j + u;
                        }
                    }
                    best.put(k, new double[]{x, z, bd, btt});
                }
            }
            cols = new ArrayList<>();
            for (double[] v : best.values()) {
                if (v[2] > R) continue;
                boolean mine = v[3] >= t0 && (v[3] < t1 || (t1 == rd.n && v[3] <= t1));
                if (mine && !rd.blocked((int) v[0], (int) v[1])) cols.add(v);
            }
            // сначала откосы, потом полотно (чтобы полотно не испортить)
            cols.sort((p, q) -> Double.compare(q[2], p[2]));
            protect = new ArrayList<>();
            long seed = w.getSeed();
            int cx = (int) rd.x((t0 + t1) / 2.0), cz = (int) rd.z((t0 + t1) / 2.0);
            int rx = Math.floorDiv(cx, Knox.REGION), rz = Math.floorDiv(cz, Knox.REGION);
            for (int gx = rx - 1; gx <= rx + 1; gx++)
                for (int gz = rz - 1; gz <= rz + 1; gz++)
                    for (Sites.Site s : Sites.region(seed, gx, gz))
                        if (!s.kind().onRoad()) protect.add(new int[]{s.x() - 2, s.z() - 2, s.x() + s.sx() + 1, s.z() + s.sz() + 1});
        }

        private boolean protectedCol(int x, int z) {
            for (int[] q : protect) if (x >= q[0] && x <= q[2] && z >= q[1] && z <= q[3]) return true;
            return false;
        }

        public int run(ServerWorld w, int budget) {
            if (cols == null) {
                rasterize(w);
                return 300;
            }
            int used = 0;
            BlockPos.Mutable m = new BlockPos.Mutable();
            while (used < budget && i < cols.size()) {
                double[] c = cols.get(i++);
                used += place(w, m, (int) c[0], (int) c[1], c[2], c[3]);
            }
            if (i >= cols.size()) {
                Knox.MapState st = Knox.MapState.get(w.getServer());
                st.roads.add(rd.pieceKey(idx));
                st.markDirty();
                Knox.QUEUED.remove(rd.pieceKey(idx));
                decorate(w);
                finished = true;
            }
            return Math.max(1, used);
        }

        private static BlockState slabOf(String id) {
            Block b = BuildingBlocks.get(id + "_slab");
            return b == null ? Blocks.SMOOTH_STONE_SLAB.getDefaultState() : b.getDefaultState().with(SlabBlock.TYPE, SlabType.BOTTOM);
        }

        private static BlockState full(String id) {
            Block b = BuildingBlocks.get(id);
            return b == null ? Blocks.BLACK_CONCRETE.getDefaultState() : b.getDefaultState();
        }

        private int set(ServerWorld w, BlockPos.Mutable m, int x, int y, int z, BlockState s) {
            w.setBlockState(m.set(x, y, z), s, FLAGS);
            return 1;
        }

        /** Одна клетка: полотно, обочина, мост, тоннель или откос. */
        private int place(ServerWorld w, BlockPos.Mutable m, int x, int z, double d, double t) {
            int used = 4;
            float y = rd.height(t);
            boolean br = rd.bridgeAt(t), tn = rd.tunnelAt(t);
            int yb = (int) Math.floor(y);
            float fr = y - yb;
            int top;
            if (d <= SHOULDER) {
                String id;
                long hsh = (x * 73856093L) ^ (z * 19349663L);
                if (d < 0.5 && ((int) Math.floor(t / 3.0)) % 2 == 0) id = "road_line_yellow";
                else if (d >= 3.0 && d < LANE) id = "road_line_white";
                else if (d < LANE) id = Math.floorMod(hsh, 23) == 0 ? "asphalt_cracked" : "asphalt";
                else id = null;
                if (id != null) {
                    String slabId = id.equals("asphalt_cracked") ? "asphalt" : id;
                    if (fr < 0.25f) {
                        used += set(w, m, x, yb, z, full(id));
                        top = yb;
                    } else if (fr < 0.75f) {
                        used += set(w, m, x, yb, z, full("asphalt"));
                        used += set(w, m, x, yb + 1, z, slabOf(slabId));
                        top = yb + 1;
                    } else {
                        used += set(w, m, x, yb, z, full("asphalt"));
                        used += set(w, m, x, yb + 1, z, full(id));
                        top = yb + 1;
                    }
                } else {   // обочина: гравий или бетон на мосту
                    top = fr < 0.5f ? yb : yb + 1;
                    used += set(w, m, x, top, z, br ? Blocks.SMOOTH_STONE.getDefaultState() : Blocks.GRAVEL.getDefaultState());
                }
                // над полотном — пусто (деревья, холмы)
                int clear = tn ? 5 : 7;
                for (int k = 1; k <= 16; k++) {
                    BlockState s = w.getBlockState(m.set(x, top + k, z));
                    if (s.isAir()) {
                        if (k > clear) break;
                        continue;
                    }
                    boolean tree = s.isIn(BlockTags.LOGS) || s.isIn(BlockTags.LEAVES);
                    if (k <= clear || tree) used += set(w, m, x, top + k, z, Blocks.AIR.getDefaultState());
                    else break;
                }
                int under = top - (fr >= 0.25f && fr < 0.75f && d <= LANE ? 2 : 1);
                if (br) {
                    used += set(w, m, x, under, z, Blocks.STONE_BRICKS.getDefaultState());
                    if (d > 4.0) used += set(w, m, x, top + 1, z, Blocks.ANDESITE_WALL.getDefaultState());
                    boolean pillar = Math.abs(d - 2.5) < 0.75 && Math.floorMod((int) Math.round(t), 12) == 0;
                    if (pillar) {
                        for (int k = 1; k < 64; k++) {
                            BlockState s = w.getBlockState(m.set(x, under - k, z));
                            if (s.isSolidBlock(w, m) && s.getFluidState().isEmpty()) break;
                            used += set(w, m, x, under - k, z, Blocks.STONE_BRICKS.getDefaultState());
                        }
                    }
                } else {
                    for (int k = 0; k < 14; k++) {
                        BlockState s = w.getBlockState(m.set(x, under - k, z));
                        if (s.isSolidBlock(w, m) && s.getFluidState().isEmpty() && k > 0) break;
                        if (k == 0 && s.isSolidBlock(w, m)) continue;
                        used += set(w, m, x, under - k, z, k < 2 ? Blocks.COARSE_DIRT.getDefaultState() : Blocks.DIRT.getDefaultState());
                    }
                }
                if (tn) {   // свод тоннеля
                    used += set(w, m, x, top + 6, z, Blocks.STONE_BRICKS.getDefaultState());
                    if (d < 0.6 && Math.floorMod((int) Math.round(t), 10) == 0)
                        used += set(w, m, x, top + 5, z, Blocks.LANTERN.getDefaultState().with(net.minecraft.block.LanternBlock.HANGING, true));
                }
                // столбики-отражатели вдоль обочины
                if (!br && !tn && d > 4.0 && Math.floorMod((int) Math.round(t), 24) == 0 && w.getBlockState(m.set(x, top + 1, z)).isAir())
                    used += set(w, m, x, top + 1, z, Blocks.BIRCH_FENCE.getDefaultState());
                return used;
            }
            // ---------- откосы ----------
            int surf = Math.round(y);
            double e = d - SHOULDER;
            if (tn) {
                if (e <= 1.2) for (int k = 1; k <= 6; k++) used += set(w, m, x, surf + k, z, Blocks.STONE_BRICKS.getDefaultState());
                return used;
            }
            if (br || protectedCol(x, z)) return used;
            int g = Knox.ground(w, x, z);
            BlockState gs = w.getBlockState(m.set(x, g, z));
            if (isRoadBlock(gs) || !gs.getFluidState().isEmpty()) return used;
            int maxG = surf + (int) Math.ceil(e), minG = surf - (int) Math.ceil(e);
            if (g > maxG) {        // выемка: срезаем склон
                for (int k = maxG + 1; k <= g + 12; k++) {
                    BlockState s = w.getBlockState(m.set(x, k, z));
                    if (s.isAir() && k > g) break;
                    used += set(w, m, x, k, z, Blocks.AIR.getDefaultState());
                }
                used += set(w, m, x, maxG, z, Blocks.GRASS_BLOCK.getDefaultState());
            } else if (g < minG) { // насыпь
                for (int k = g + 1; k < minG; k++) used += set(w, m, x, k, z, Blocks.DIRT.getDefaultState());
                used += set(w, m, x, minG, z, Blocks.GRASS_BLOCK.getDefaultState());
                BlockState above = w.getBlockState(m.set(x, minG + 1, z));
                if (!above.isAir() && above.isReplaceable()) used += set(w, m, x, minG + 1, z, Blocks.AIR.getDefaultState());
            }
            return used;
        }

        /** Жизнь на дороге: брошенные машины, указатели у въездов в поселения. */
        private void decorate(ServerWorld w) {
            java.util.Random r = new java.util.Random(rd.pieceKey(idx) * 0x2545F4914F6CDD1DL + 17);
            int t0 = idx * PIECE, t1 = Math.min(rd.n - 1, t0 + PIECE - 1);
            if (t1 - t0 < 8) return;
            if (r.nextFloat() < 0.14f) {
                int t = t0 + 2 + r.nextInt(t1 - t0 - 3);
                if (!rd.bridgeAt(t) && !rd.tunnelAt(t)) {
                    double[] d = rd.dir(t);
                    double side = r.nextBoolean() ? 1 : -1, lat = r.nextFloat() < 0.6f ? 4.0 : 1.7;
                    double x = rd.x(t) - d[1] * side * lat, z = rd.z(t) + d[0] * side * lat;
                    float yaw = (float) Math.toDegrees(Math.atan2(-d[0], d[1])) + (side > 0 ? 0 : 180) + (r.nextFloat() - 0.5f) * 40f;
                    Knox.spawnCar(w, x, z, yaw, r.nextFloat() < 0.3f, r.nextLong());
                }
            }
            // указатели: «добро пожаловать» у въезда и расстояние подальше
            for (int end = 0; end < 2; end++) {
                Knox.Settlement s = end == 0 ? rd.a : rd.b;
                if (s.type() == Knox.Type.FOREST || s.type() == Knox.Type.NONE) continue;
                for (int dist : new int[]{22, 170}) {
                    int t = end == 0 ? dist : rd.n - 1 - dist;
                    if (t < t0 || t > t1 || t < 0 || t >= rd.n) continue;
                    double[] d = rd.dir(t);
                    double vx = end == 0 ? -d[0] : d[0], vz = end == 0 ? -d[1] : d[1];   // водитель едет к поселению
                    double rx = -vz, rz = vx;                                                // справа от него
                    int sx = (int) Math.floor(rd.x(t) + rx * 6), sz = (int) Math.floor(rd.z(t) + rz * 6);
                    int rot = Math.floorMod((int) Math.round(Math.atan2(vx, -vz) / (2 * Math.PI) * 16), 16);
                    String kind = switch (s.type()) {
                        case MILITARY -> "военная база";
                        case PRISON -> "тюрьма";
                        case LAB -> "закрытая зона";
                        case MALL -> "торговый центр";
                        case METRO -> "мегаполис";
                        case CITY -> "большой город";
                        case TOWN -> "город";
                        case VILLAGE -> "деревня";
                        default -> "фермы";
                    };
                    if (dist < 100) Knox.sign(w, sx, sz, rot, "Добро пожаловать", s.name(), kind, r.nextFloat() < 0.5f ? "КАРАНТИН!" : "");
                    else Knox.sign(w, sx, sz, rot, s.name(), (int) (Math.round(dist / 50.0) * 50) + " м", kind, "");
                }
            }
        }
    }
}
