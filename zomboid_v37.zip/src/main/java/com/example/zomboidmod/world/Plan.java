package com.example.zomboidmod.world;

import com.example.zomboidmod.ZombieOutfit;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.enums.BedPart;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * План постройки в локальных координатах участка: x вдоль улицы, z вглубь, улица со стороны z = -1 (север).
 * y = 0 - уровень земли (пол первого этажа).
 */
public class Plan {
    public final int w, d;
    public final Random r;
    /** Опасность места (0 жильё, 1 магазин, 2 полиция/аптека/оружие, 3 военные/больница): чем лучше лут, тем сильнее зомби. */
    public int danger;
    final Map<Long, BlockState> blocks = new LinkedHashMap<>();
    final List<long[]> loot = new ArrayList<>();          // {локальная позиция, номер Loot}
    final List<Object[]> zombies = new ArrayList<>();     // {локальная позиция (Long), ZombieOutfit или null, опасность (Integer, -1 = как у плана)}
    final List<Long> animals = new ArrayList<>();         // коровы на пастбище
    final List<Object[]> vehicles = new ArrayList<>();    // {x (Double), y (Integer), z (Double), тип, угол (Float), разбита}
    final List<long[]> extras = new ArrayList<>();        // {позиция контейнера, 0 записка / 1 карта тайника, тема записки (-1 любая)}

    public Plan(int w, int d, Random r) {
        this.w = w;
        this.d = d;
        this.r = r;
    }

    public void set(int x, int y, int z, BlockState s) {
        blocks.put(BlockPos.asLong(x, y, z), s);
    }

    public void set(int x, int y, int z, Block b) {
        set(x, y, z, b.getDefaultState());
    }

    public BlockState get(int x, int y, int z) {
        return blocks.get(BlockPos.asLong(x, y, z));
    }

    public void fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) set(x, y, z, s);
    }

    public void fill(int x1, int y1, int z1, int x2, int y2, int z2, Block b) {
        fill(x1, y1, z1, x2, y2, z2, b.getDefaultState());
    }

    public void air(int x1, int y1, int z1, int x2, int y2, int z2) {
        fill(x1, y1, z1, x2, y2, z2, Blocks.AIR.getDefaultState());
    }

    /** Только стены по периметру. */
    public void walls(int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        for (int y = y1; y <= y2; y++) {
            for (int x = x1; x <= x2; x++) {
                set(x, y, z1, s);
                set(x, y, z2, s);
            }
            for (int z = z1; z <= z2; z++) {
                set(x1, y, z, s);
                set(x2, y, z, s);
            }
        }
    }

    /** Окна в стенах на высоте y: через одну клетку, не у углов. */
    public void windows(int x1, int z1, int x2, int z2, int y, BlockState glass, int skipX) {
        for (int x = x1 + 2; x <= x2 - 2; x += 2) {
            if (Math.abs(x - skipX) > 1) set(x, y, z1, glass);
            set(x, y, z2, glass);
        }
        for (int z = z1 + 2; z <= z2 - 2; z += 2) {
            set(x1, y, z, glass);
            set(x2, y, z, glass);
        }
    }

    public void door(int x, int y, int z, Block door, Direction facing) {
        BlockState s = door.getDefaultState().with(DoorBlock.FACING, facing);
        set(x, y, z, s.with(DoorBlock.HALF, DoubleBlockHalf.LOWER));
        set(x, y + 1, z, s.with(DoorBlock.HALF, DoubleBlockHalf.UPPER));
    }

    /** Кровать: изножье в (x,z), изголовье в сторону facing. */
    public void bed(int x, int y, int z, Block bed, Direction facing) {
        BlockState s = bed.getDefaultState().with(BedBlock.FACING, facing);
        set(x, y, z, s.with(BedBlock.PART, BedPart.FOOT));
        set(x + facing.getOffsetX(), y, z + facing.getOffsetZ(), s.with(BedBlock.PART, BedPart.HEAD));
    }

    public void ladder(int x, int y1, int y2, int z, Direction facing) {
        for (int y = y1; y <= y2; y++) set(x, y, z, Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, facing));
    }

    public BlockState stair(Block b, Direction facing, boolean top) {
        return b.getDefaultState().with(StairsBlock.FACING, facing).with(StairsBlock.HALF, top ? BlockHalf.TOP : BlockHalf.BOTTOM);
    }

    public BlockState slab(Block b, boolean top) {
        return b.getDefaultState().with(SlabBlock.TYPE, top ? SlabType.TOP : SlabType.BOTTOM);
    }

    public void loot(int x, int y, int z, BlockState container, Loot type) {
        set(x, y, z, container);
        loot.add(new long[]{BlockPos.asLong(x, y, z), type.ordinal()});
    }

    /** Записка выжившего в контейнере (topic: тема из Stories, -1 — любая). */
    public void note(int x, int y, int z, int topic) {
        extras.add(new long[]{BlockPos.asLong(x, y, z), 0, topic});
    }

    /** Карта тайника в контейнере. */
    public void stashMap(int x, int y, int z) {
        extras.add(new long[]{BlockPos.asLong(x, y, z), 1, -1});
    }

    /** Вещь, лежащая на полу/столе (ПКМ - подобрать). */
    public void pile(int x, int y, int z, Loot type) {
        set(x, y, z, com.example.zomboidmod.block.ZomboidBlocks.LOOT_PILE.getDefaultState());
        loot.add(new long[]{BlockPos.asLong(x, y, z), type.ordinal()});
    }

    /** Мебель фасадом в сторону facing; высокая ставит невидимую верхнюю часть. */
    public void furn(int x, int y, int z, String id, Direction facing) {
        com.example.zomboidmod.block.FurnitureBlock b = com.example.zomboidmod.block.ZomboidBlocks.get(id);
        set(x, y, z, b.getDefaultState().with(com.example.zomboidmod.block.FurnitureBlock.FACING, facing));
        if (b.tall) set(x, y + 1, z, com.example.zomboidmod.block.ZomboidBlocks.FURNITURE_TOP.getDefaultState());
    }

    /** Мебель с инвентарём и лутом. */
    public void furnLoot(int x, int y, int z, String id, Direction facing, Loot type) {
        furn(x, y, z, id, facing);
        loot.add(new long[]{BlockPos.asLong(x, y, z), type.ordinal()});
    }

    public void zombie(int x, int y, int z, ZombieOutfit outfit) {
        zombies.add(new Object[]{BlockPos.asLong(x, y, z), outfit, -1});
    }

    public void zombie(int x, int y, int z, ZombieOutfit outfit, int tier) {
        zombies.add(new Object[]{BlockPos.asLong(x, y, z), outfit, tier});
    }

    int tierOf(Object[] z) {
        int t = z.length > 2 ? (Integer) z[2] : -1;
        return t < 0 ? danger : t;
    }

    /** Свободная клетка пола на этаже y внутри прямоугольника (или null). */
    public int[] freeFloor(int x1, int z1, int x2, int z2, int y) {
        for (int k = 0; k < 40; k++) {
            int x = x1 + r.nextInt(Math.max(1, x2 - x1 + 1)), z = z1 + r.nextInt(Math.max(1, z2 - z1 + 1));
            BlockState f = get(x, y - 1, z), a = get(x, y, z), b = get(x, y + 1, z);
            boolean floor = f != null && !f.isAir();
            if (floor && (a == null || a.isAir()) && (b == null || b.isAir())) return new int[]{x, z};
        }
        return null;
    }

    /**
     * Зомби по опасности места: внутри здания и на тротуаре перед ним. Возле оружейного или больницы бродят толпы
     * бегунов и громил, у жилого дома — пара шатунов.
     */
    public void populate(ZombieOutfit outfit) {
        int inside = new int[]{0, 2, 4, 7}[Math.max(0, Math.min(3, danger))] + r.nextInt(2 + danger);   // в жилом доме — 0-1, дальше больше
        for (int k = 0; k < inside; k++) {
            int[] c = freeFloor(1, 1, w - 2, d - 2, 1);
            if (c != null) zombie(c[0], 1, c[1], r.nextFloat() < 0.5f ? outfit : null);
        }
        int outside = danger >= 2 ? 1 + r.nextInt(2 + danger) : (danger == 1 && r.nextFloat() < 0.4f ? 1 : 0);
        for (int k = 0; k < outside; k++) zombie(1 + r.nextInt(Math.max(1, w - 2)), 1, -2 - r.nextInt(2), r.nextFloat() < 0.4f ? outfit : null);
    }

    /** Машина: центр в точке (x, z) плана (дробные координаты), угол как у Minecraft: 0 — на юг (+z), 90 — на запад. */
    public void vehicle(double x, int y, double z, String type, float yaw, boolean wreck) {
        vehicles.add(new Object[]{x, y, z, type, yaw, wreck});
    }

    public void animal(int x, int y, int z) {
        animals.add(BlockPos.asLong(x, y, z));
    }

    /** Вставить другой план со смещением (без поворота). */
    public void embed(Plan o, int dx, int dz) {
        for (Map.Entry<Long, BlockState> e : o.blocks.entrySet()) {
            BlockPos p = BlockPos.fromLong(e.getKey());
            set(p.getX() + dx, p.getY(), p.getZ() + dz, e.getValue());
        }
        for (long[] l : o.loot) {
            BlockPos p = BlockPos.fromLong(l[0]);
            loot.add(new long[]{BlockPos.asLong(p.getX() + dx, p.getY(), p.getZ() + dz), l[1]});
        }
        for (Object[] z : o.zombies) {
            BlockPos p = BlockPos.fromLong((Long) z[0]);
            zombies.add(new Object[]{BlockPos.asLong(p.getX() + dx, p.getY(), p.getZ() + dz), z[1], o.tierOf(z)});
        }
        for (Object[] v : o.vehicles) vehicles.add(new Object[]{(Double) v[0] + dx, v[1], (Double) v[2] + dz, v[3], v[4], v[5]});
        animals.addAll(o.animals.stream().map(a -> {
            BlockPos p = BlockPos.fromLong(a);
            return BlockPos.asLong(p.getX() + dx, p.getY(), p.getZ() + dz);
        }).toList());
    }

    /** Стол: забор + нажимная плита. */
    public void table(int x, int y, int z) {
        set(x, y, z, Blocks.OAK_FENCE);
        set(x, y + 1, z, Blocks.OAK_PRESSURE_PLATE);
    }

    /** Дерево (листва не опадает). */
    public void tree(int x, int y, int z, int kind) {
        Block log = kind == 1 ? Blocks.BIRCH_LOG : (kind == 2 ? Blocks.SPRUCE_LOG : Blocks.OAK_LOG);
        Block leaves = kind == 1 ? Blocks.BIRCH_LEAVES : (kind == 2 ? Blocks.SPRUCE_LEAVES : Blocks.OAK_LEAVES);
        BlockState lv = leaves.getDefaultState().with(LeavesBlock.PERSISTENT, true);
        int h = 4 + r.nextInt(3) + (kind == 2 ? 2 : 0);
        if (kind == 2) {
            for (int k = 0; k < h - 1; k++) {
                int rad = Math.max(0, (h - k) / 2 - 1);
                if (k < 2) continue;
                for (int dx = -rad; dx <= rad; dx++)
                    for (int dz = -rad; dz <= rad; dz++)
                        if (Math.abs(dx) + Math.abs(dz) <= rad + 1) set(x + dx, y + k, z + dz, lv);
            }
            set(x, y + h, z, lv);
        } else {
            for (int dy = h - 3; dy <= h; dy++) {
                int rad = dy >= h - 1 ? 1 : 2;
                for (int dx = -rad; dx <= rad; dx++)
                    for (int dz = -rad; dz <= rad; dz++)
                        if (!(Math.abs(dx) == 2 && Math.abs(dz) == 2 && r.nextBoolean())) set(x + dx, y + dy, z + dz, lv);
            }
        }
        for (int k = 1; k < h; k++) set(x, y + k, z, log);
    }
}
