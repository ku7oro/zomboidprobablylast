package com.example.zomboidmod.mixin;

import com.example.zomboidmod.survival.Survival;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Днём уставший персонаж спит, пока не выспится (в ванилле днём сразу будят). */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;isDay()Z"))
    private boolean zomboid$daySleep(World world) {
        return world.isDay() && !Survival.keepSleeping((PlayerEntity) (Object) this);
    }
}
