package com.example.zomboidmod.world;

import com.example.zomboidmod.ZombieOutfit;
import com.example.zomboidmod.block.DecalBlock;
import com.example.zomboidmod.block.ZomboidBlocks;
import com.example.zomboidmod.vehicle.VehicleType;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.LightBlock;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.List;

/**
 * Город без сетки: главная улица (продолжение шоссе), поперечная, боковые улицы разной длины с неровным шагом,
 * переулки, петли и тупики с разворотным кругом. Участки встают вдоль улиц фасадом к дороге с разными отступами:
 * в центре — магазины вплотную к тротуару, вокруг — службы, дальше — жилые кварталы, на окраинах — трейлеры и склады.
 */
final class TownGen {
    static final byte EMPTY = 0, ROAD = 1, WALK = 2, LOT = 3, GREEN = 4, OUT = -1;

    enum Kind { MAIN, CROSS, SIDE, LANE }

    static final class Road {
        final boolean alongX;
        final int c, a, b, half, walk, skip;
        final Kind kind;
        boolean culdesac, joined;

        Road(boolean alongX, int c, int a, int b, int half, int walk, Kind kind, int skip) {
            this.alongX = alongX;
            this.c = c;
            this.a = a;
            this.b = b;
            this.half = half;
            this.walk = walk;
            this.kind = kind;
            this.skip = skip;
        }

        int dir() {
            return b >= a ? 1 : -1;
        }

        int len() {
            return Math.abs(b - a);
        }

        int x(int t, int o) {
            return alongX ? t : c + o;
        }

        int z(int t, int o) {
            return alongX ? c + o : t;
        }
    }

    record Spec(String kind, int w, int d, int set, int gap) {}

    final int W, D, ox, oz, base;
    final Random r;
    final boolean village;
    final byte[] g;
    final List<Road> roads = new ArrayList<>();
    final Plan st;
    int dcx, dcz;
    final List<String> shops = new ArrayList<>(List.of("grocery", "pharmacy", "hardware", "diner", "gunstore", "bookstore", "gas", "bar",
            "clothes", "sports", "liquor", "electronics"));
    /** Большой город: проспекты, высотки, больница, торговый центр, блокпосты. */
    boolean city;
    int towers, specials, checkpoints, autoShops;
    final List<String> civic = new ArrayList<>(List.of("police", "clinic", "square", "fire", "school", "church"));
    int gasCount, motels, warehouses;
    boolean store, chapel;

    TownGen(int ox, int oz, int W, int D, int base, Random r, boolean village) {
        this.ox = ox;
        this.oz = oz;
        this.W = W;
        this.D = D;
        this.base = base;
        this.r = r;
        this.village = village;
        this.g = new byte[W * D];
        this.st = new Plan(W, D, Random.create(r.nextLong()));
    }

    byte at(int x, int z) {
        return x < 0 || z < 0 || x >= W || z >= D ? OUT : g[x * D + z];
    }

    void put(int x, int z, byte v) {
        if (x >= 0 && z >= 0 && x < W && z < D) g[x * D + z] = v;
    }

    // ===================== улицы =====================

    void raster(Road rd) {
        int outer = rd.half + rd.walk;
        for (int i = -rd.walk; i <= rd.len() + rd.walk; i++) {
            int t = rd.a + rd.dir() * i;
            boolean cap = i < 0 || i > rd.len();
            for (int o = -outer; o <= outer; o++) {
                int x = rd.x(t, o), z = rd.z(t, o);
                byte v = at(x, z);
                if (!cap && Math.abs(o) <= rd.half) put(x, z, ROAD);
                else if (v == EMPTY || v == GREEN) put(x, z, WALK);
            }
        }
    }

    boolean free(Road rd, int clear) {
        int outer = rd.half + rd.walk;
        for (int i = rd.skip; i <= rd.len() + rd.walk + 2; i++) {
            int t = rd.a + rd.dir() * i;
            for (int o = -(outer + clear); o <= outer + clear; o++) {
                byte v = at(rd.x(t, o), rd.z(t, o));
                boolean core = Math.abs(o) <= outer && i <= rd.len() + rd.walk;
                if (v == OUT) {
                    if (core) return false;
                    continue;
                }
                if (v == ROAD || v == WALK || v == LOT) return false;
            }
        }
        return true;
    }

    Road branch(Road parent, int t, int dir, Kind kind, int minL, int maxL, int clear) {
        int half = village ? 2 : (kind == Kind.SIDE ? 3 : 2);
        int walk = village ? 1 : (kind == Kind.SIDE ? 2 : 1);
        int skip = parent.half + parent.walk + 1;
        int L = minL + r.nextInt(Math.max(1, maxL - minL + 1));
        for (; L >= minL; L -= 5) {
            Road rd = new Road(!parent.alongX, t, parent.c, parent.c + dir * L, half, walk, kind, skip);
            if (free(rd, clear)) {
                roads.add(rd);
                raster(rd);
                return rd;
            }
        }
        return null;
    }

    /** Переулок от тупика до соседней улицы — получаются кварталы-петли. */
    void tryConnect(Road rd) {
        int[] dirs = r.nextBoolean() ? new int[]{1, -1} : new int[]{-1, 1};
        for (int dir : dirs) {
            Road probe = new Road(!rd.alongX, rd.b, rd.c, rd.c + dir * 70, 2, 1, Kind.LANE, rd.half + rd.walk + 1);
            int hit = -1;
            for (int i = probe.skip; i <= 70; i++) {
                int t = probe.a + dir * i;
                byte v = at(probe.x(t, 0), probe.z(t, 0));
                if (v == OUT || v == LOT) break;
                if (v == ROAD) {
                    hit = i;
                    break;
                }
            }
            if (hit < 0 || hit < 12) continue;
            boolean ok = true;
            for (int i = probe.skip; i < hit && ok; i++) {
                int t = probe.a + dir * i;
                boolean near = i >= hit - 12;
                int lat = i < probe.skip + 10 ? 3 : 10;
                for (int o = -10; o <= 10; o++) {
                    byte v = at(probe.x(t, o), probe.z(t, o));
                    if (Math.abs(o) <= 3 && (v == LOT || v == OUT)) {
                        ok = false;
                        break;
                    }
                    if ((v == ROAD || v == WALK) && !near && Math.abs(o) <= lat) {
                        ok = false;
                        break;
                    }
                }
            }
            if (!ok) continue;
            Road lane = new Road(!rd.alongX, rd.b, rd.c, rd.c + dir * (hit + 1), village ? 2 : 2, 1, Kind.LANE, probe.skip);
            roads.add(lane);
            raster(lane);
            rd.joined = true;
            return;
        }
    }

    void culdesac(Road rd) {
        int R = rd.half + 3, outer = R + rd.walk;
        int cx = rd.x(rd.b, 0), cz = rd.z(rd.b, 0);
        for (int dx = -outer; dx <= outer; dx++)
            for (int dz = -outer; dz <= outer; dz++) {
                byte v = at(cx + dx, cz + dz);
                if (v == OUT || v == LOT) return;
            }
        for (int dx = -outer; dx <= outer; dx++)
            for (int dz = -outer; dz <= outer; dz++) {
                double d = Math.hypot(dx, dz);
                if (d <= R + 0.3) put(cx + dx, cz + dz, ROAD);
                else if (d <= outer + 0.3 && (at(cx + dx, cz + dz) == EMPTY || at(cx + dx, cz + dz) == GREEN)) put(cx + dx, cz + dz, WALK);
            }
        rd.culdesac = true;
        // клумба в центре круга
        if (!village) {
            st.set(cx, 0, cz, Blocks.GRASS_BLOCK);
            st.set(cx, 1, cz, Blocks.OAK_LEAVES.getDefaultState().with(LeavesBlock.PERSISTENT, true));
        }
    }

    void layout(int mainZ, int crossX) {
        mainZ = Math.max(14, Math.min(D - 15, mainZ));
        Road main = new Road(true, mainZ, 0, W - 1, village ? 3 : 4, village ? 1 : 2, Kind.MAIN, 0);
        roads.add(main);
        raster(main);
        Road cross = null;
        if (crossX < 20 || crossX > W - 21) crossX = village ? -1 : 28 + r.nextInt(Math.max(1, W - 56));
        if (crossX >= 0) {
            cross = new Road(false, crossX, 0, D - 1, village ? 2 : 3, village ? 1 : 2, Kind.CROSS, 0);
            roads.add(cross);
            raster(cross);
        }
        dcx = cross != null ? cross.c : W / 2;
        dcz = mainZ;
        if (city) {   // параллельные проспекты
            for (int off : new int[]{-1, 1}) {
                int z2 = mainZ + off * (88 + r.nextInt(28));
                if (z2 > 20 && z2 < D - 21) {
                    Road av = new Road(true, z2, 0, W - 1, 3, 2, Kind.MAIN, 0);
                    roads.add(av);
                    raster(av);
                }
                if (cross != null) {
                    int x2 = cross.c + off * (88 + r.nextInt(28));
                    if (x2 > 20 && x2 < W - 21) {
                        Road av = new Road(false, x2, 0, D - 1, 3, 2, Kind.CROSS, 0);
                        roads.add(av);
                        raster(av);
                    }
                }
            }
        }
        int clear = village ? 30 : (city ? 22 : 32);
        if (village) {
            int want = 2 + r.nextInt(3), made = 0;
            for (int k = 0; k < 30 && made < want; k++) {
                int x = 12 + r.nextInt(Math.max(1, W - 24));
                if (branch(main, x, r.nextBoolean() ? 1 : -1, Kind.SIDE, 22, 40, clear) != null) made++;
            }
        } else {
            for (Road art : new ArrayList<>(roads)) {
                if (art.kind != Kind.MAIN && art.kind != Kind.CROSS) continue;
                for (int dir : new int[]{-1, 1}) {
                    int t = 6 + r.nextInt(16);
                    while (t < art.len() - 8) {
                        boolean nearArt = false;
                        for (Road o : roads)
                            if ((o.kind == Kind.MAIN || o.kind == Kind.CROSS) && o.alongX != art.alongX && Math.abs(t - o.c) <= 22) nearArt = true;
                        if (!nearArt) branch(art, t, dir, Kind.SIDE, 26, city ? 80 : 92, clear);
                        t += (city ? 14 : 16) + r.nextInt(city ? 14 : 20);
                    }
                }
            }
            for (Road s : new ArrayList<>(roads)) {
                if (s.kind == Kind.SIDE && s.len() > 44 && r.nextFloat() < 0.65f) {
                    int t = s.a + s.dir() * (22 + r.nextInt(s.len() - 26));
                    branch(s, t, r.nextBoolean() ? 1 : -1, Kind.LANE, 20, 56, 24);
                }
            }
        }
        if (!village) {   // переулки в пустые места внутри кварталов
            for (Road s : new ArrayList<>(roads)) {
                if ((s.kind == Kind.SIDE || s.kind == Kind.LANE) && s.len() > 30) {
                    for (int i = 14; i < s.len() - 8; i += 12) branch(s, s.a + s.dir() * i, r.nextBoolean() ? 1 : -1, Kind.LANE, 22, 60, city ? 20 : 26);
                }
            }
        }
        for (Road s : new ArrayList<>(roads))
            if ((s.kind == Kind.SIDE || s.kind == Kind.LANE) && r.nextFloat() < (village ? 0.25f : 0.5f)) tryConnect(s);
        for (Road s : roads) if (s.kind == Kind.SIDE && !s.joined && r.nextFloat() < 0.55f) culdesac(s);
    }

    // ===================== участки =====================

    double distNorm(int x, int z) {
        return Math.hypot(x - dcx, z - dcz) / (Math.min(W, D) / 2.0);
    }

    Spec residential(double dist) {
        int set = 1 + r.nextInt(3), gap = village ? 3 + r.nextInt(9) : 1 + r.nextInt(2);
        if (dist > 0.75 && r.nextFloat() < 0.2f) return new Spec("trailer", 12, 12, set, gap);
        if (city && dist < 0.5 && r.nextFloat() < 0.35f) return new Spec("aptower", 25, 25, 1, gap);
        if (!village && dist < (city ? 0.8 : 0.65) && r.nextFloat() < (city ? 0.25f : 0.1f)) return new Spec("apartment", 25, 20, 1, gap);
        float k = r.nextFloat();
        if (k < 0.12f) return new Spec("house", 12, 12, set, gap);
        if (k < 0.22f) return new Spec("two", 12, 12, set, gap);
        if (k < 0.38f) return new Spec("ranch", 18, 12, set, gap);
        if (k < 0.58f) return new Spec("bungalow", 16, 16, set, gap);
        if (k < 0.72f) return new Spec("farmhouse", 20, 18, set, gap);
        if (k < 0.85f) return new Spec("colonial", 20, 16, set, gap);
        if (k < 0.91f) return new Spec("park", 12, 12, 0, gap);
        if (k < 0.96f) return new Spec("trailer", 12, 12, set, gap);
        return new Spec("empty", 12, 12, 0, gap);
    }

    Spec choose(Road rd, int t, int side) {
        int px = rd.alongX ? t : rd.c + side * 12, pz = rd.alongX ? rd.c + side * 12 : t;
        double dist = distNorm(px, pz);
        if (village) {
            if (!store && rd.kind == Kind.MAIN && dist < 0.55) return new Spec("general", 12, 12, 2, 3);
            if (!chapel && dist < 0.7 && r.nextFloat() < 0.25f) return new Spec("chapel", 12, 12, 3, 4);
            return residential(dist);
        }
        boolean arterial = rd.kind == Kind.MAIN || rd.kind == Kind.CROSS;
        if (arterial && dist < (city ? 0.62 : 0.48)) return new Spec("shop", 25, 12, 0, 0);
        if (city && rd.kind == Kind.SIDE && dist < 0.35 && r.nextFloat() < 0.4f) return new Spec("shop", 25, 12, 0, 0);
        if (dist > 0.72 && warehouses < 2 && r.nextFloat() < 0.05f) return new Spec("warehouse", 25, 25, 2, 3);
        if (arterial && dist < 0.65 && r.nextFloat() < 0.3f) return new Spec("shop", 25, 12, 1, 1);
        return residential(dist);
    }

    /** Клетка города для точки плана участка (как в PlaceJob). */
    static int[] cell(BlockRotation rot, int x0, int z0, int w, int d, int lx, int lz) {
        return switch (rot) {
            case CLOCKWISE_90 -> new int[]{x0 + d - 1 - lz, z0 + lx};
            case CLOCKWISE_180 -> new int[]{x0 + w - 1 - lx, z0 + d - 1 - lz};
            case COUNTERCLOCKWISE_90 -> new int[]{x0 + lz, z0 + w - 1 - lx};
            default -> new int[]{x0 + lx, z0 + lz};
        };
    }

    boolean tryPlace(Road rd, int side, int t, Spec s) {
        int e = rd.half + rd.walk + 1;
        int lo = Math.min(t, t + rd.dir() * (s.w() - 1));
        int p1 = side > 0 ? rd.c + e : rd.c - e - s.set() - s.d() + 1;
        int p2 = p1 + s.set() + s.d() - 1;
        for (int a = lo; a < lo + s.w(); a++)
            for (int p = p1; p <= p2; p++) {
                int x = rd.alongX ? a : p, z = rd.alongX ? p : a;
                byte v = at(x, z);
                if (v != EMPTY && v != GREEN) return false;
                if (x < 2 || z < 2 || x > W - 3 || z > D - 3) return false;
            }
        java.util.function.Supplier<Plan> plan = build(s, rd);
        if (plan == null) return false;
        for (int a = lo; a < lo + s.w(); a++)
            for (int p = p1; p <= p2; p++) put(rd.alongX ? a : p, rd.alongX ? p : a, LOT);
        int x0, z0;
        BlockRotation rot;
        if (rd.alongX) {
            x0 = lo;
            z0 = side > 0 ? rd.c + e + s.set() : rd.c - e - s.set() - s.d() + 1;
            rot = side > 0 ? BlockRotation.NONE : BlockRotation.CLOCKWISE_180;
        } else {
            z0 = lo;
            x0 = side > 0 ? rd.c + e + s.set() : rd.c - e - s.set() - s.d() + 1;
            rot = side > 0 ? BlockRotation.COUNTERCLOCKWISE_90 : BlockRotation.CLOCKWISE_90;
        }
        int pw = rd.alongX ? s.w() : s.d(), pd = rd.alongX ? s.d() : s.w();
        // дорожка от крыльца к тротуару через газон
        if (s.set() > 0) {
            int[] lxs = switch (s.kind()) {
                case "house", "two", "trailer", "general", "chapel", "bungalow" -> new int[]{5};
                case "farmhouse", "colonial" -> new int[]{7};
                case "apartment" -> new int[]{11, 12, 13};
                case "ranch" -> new int[]{5, 12, 13, 14, 15, 16};
                case "civic", "motel", "warehouse", "aptower", "hospital", "mall", "library", "autorepair" -> new int[]{11, 12, 13};
                default -> new int[0];
            };
            for (int lx : lxs)
                for (int k = 1; k <= s.set(); k++) {
                    int[] c = cell(rot, x0, z0, s.w(), s.d(), lx, -k);
                    st.set(c[0], 0, c[1], lx > 10 && s.kind().equals("ranch") ? Blocks.LIGHT_GRAY_CONCRETE : Blocks.DIRT_PATH);
                }
        }
        Knox.lot(plan, ox + x0, base, oz + z0, rot);
        return true;
    }

    /**
     * Решает, что строить на участке (сейчас), а сам план строится потом, когда до него дойдёт очередь (экономит память).
     * Возвращает null, если на этом месте строить нечего.
     */
    java.util.function.Supplier<Plan> build(Spec s, Road rd) {
        String kind = s.kind();
        String k = kind;
        switch (kind) {
            case "shop" -> {
                List<String> any = new ArrayList<>(List.of("grocery", "diner", "bar", "office", "clothes", "hardware", "pharmacy", "bookstore",
                        "liquor", "electronics", "sports", "pizzeria"));
                if (city) any.addAll(List.of("gunstore", "army", "pizzeria", "bookstore", "grocery"));
                k = !shops.isEmpty() ? shops.remove(0) : any.get(r.nextInt(any.size()));
                if (k.equals("gas")) gasCount++;
            }
            case "gas" -> gasCount++;
            case "civic" -> {
                if (civic.isEmpty()) return null;
                k = civic.remove(0);
            }
            case "motel" -> motels++;
            case "warehouse" -> warehouses++;
            case "general" -> store = true;
            case "chapel" -> chapel = true;
            case "tower" -> towers++;
            case "hospital", "mall", "library" -> specials++;
            case "autorepair" -> autoShops++;
            default -> {
            }
        }
        final String what = k;
        final boolean shopLot = kind.equals("shop");
        final int w = s.w(), d = s.d();
        final long seed = r.nextLong();
                return () -> {
            Plan p = new Plan(w, d, Random.create(seed));
            ZombieOutfit local = null;
            switch (what) {
                case "grocery" -> { Buildings.grocery(p); p.danger = 1; }
                case "pharmacy" -> { Buildings.pharmacy(p); p.danger = 2; local = ZombieOutfit.NURSE; }
                case "hardware" -> { Buildings.hardware(p); p.danger = 1; local = ZombieOutfit.CONSTRUCTION; }
                case "diner" -> Buildings.diner(p);
                case "gas" -> Buildings.gasStation(p);
                case "bar" -> Buildings.bar(p);
                case "office" -> { Buildings.office(p); local = ZombieOutfit.BUSINESS; }
                case "clothes" -> Buildings.clothes(p);
                case "bookstore" -> CityBuildings.bookstore(p);
                case "gunstore" -> { CityBuildings.gunstore(p); local = ZombieOutfit.SECURITY; }
                case "electronics" -> CityBuildings.electronics(p);
                case "sports" -> CityBuildings.sports(p);
                case "liquor" -> CityBuildings.liquor(p);
                case "pizzeria" -> { CityBuildings.pizzeria(p); local = ZombieOutfit.CHEF; }
                case "army" -> { CityBuildings.armySurplus(p); local = ZombieOutfit.SOLDIER; }
                case "parking" -> Buildings.parkingLot(p);
                case "police" -> { Buildings.police(p); p.danger = 2; local = ZombieOutfit.POLICE; }
                case "clinic" -> { Buildings.clinic(p); p.danger = 2; local = ZombieOutfit.NURSE; }
                case "fire" -> { Buildings.fireStation(p); p.danger = 1; local = ZombieOutfit.FIREFIGHTER; }
                case "school" -> { Buildings.school(p); local = ZombieOutfit.STUDENT; }
                case "church" -> { Buildings.church(p); local = ZombieOutfit.PRIEST; }
                case "square" -> Buildings.park(p);
                case "motel" -> Buildings.motel(p);
                case "warehouse" -> {
                    Buildings.warehouse(p);
                    p.danger = 1;
                    p.furnLoot(1, 1, 1, "dumpster", Direction.EAST, Loot.TRASH);
                }
                case "general" -> Buildings.generalStore(p);
                case "chapel" -> Buildings.chapel(p);
                case "tower" -> { CityBuildings.officeTower(p); local = ZombieOutfit.BUSINESS; }
                case "aptower" -> CityBuildings.apartmentTower(p);
                case "hospital" -> { CityBuildings.hospital(p); local = ZombieOutfit.DOCTOR; }
                case "mall" -> CityBuildings.mall(p);
                case "library" -> CityBuildings.library(p);
                case "checkpoint" -> { CityBuildings.checkpoint(p); local = ZombieOutfit.SOLDIER; }
                case "autorepair" -> { CityBuildings.autoRepair(p); local = ZombieOutfit.MECHANIC; }
                case "house" -> Buildings.house(p);
                case "two" -> Buildings.twoStory(p);
                case "ranch" -> Buildings.ranch(p);
                case "bungalow" -> Houses.bungalow(p);
                case "farmhouse" -> Houses.twoFloor(p, true);
                case "colonial" -> Houses.twoFloor(p, false);
                case "apartment" -> Houses.apartment(p);
                case "trailer" -> Buildings.trailer(p);
                case "park" -> Buildings.park(p);
                default -> Buildings.emptyLot(p);
            }
            if (shopLot) {
                if (p.r.nextFloat() < 0.5f) p.furnLoot(0, 1, 1, "dumpster", Direction.EAST, Loot.TRASH);
                if (p.r.nextFloat() < 0.3f) p.furn(24, 1, 1, "bench", Direction.NORTH);
            }
            // почтовый ящик и забор у жилых домов
            if (what.equals("house") || what.equals("two") || what.equals("ranch") || what.equals("trailer")
                    || what.equals("bungalow") || what.equals("farmhouse") || what.equals("colonial")) {
                p.furn(what.equals("ranch") ? 11 : w - 1, 1, 0, "mailbox", Direction.NORTH);
                if (p.r.nextFloat() < 0.45f) {
                    for (int z = 5; z < d - 1; z++) {
                        p.set(0, 1, z, Blocks.OAK_FENCE);
                        p.set(w - 1, 1, z, Blocks.OAK_FENCE);
                    }
                }
                if (p.r.nextFloat() < 0.25f) p.furnLoot(w - 3, 1, 0, "trash_can", Direction.NORTH, Loot.TRASH);
            }
            p.populate(local);
            return p;
        };
    }

    record Cand(double dist, Road rd, int side, int t) {}

    /** Все места вдоль улиц указанных видов, от центра к окраинам. */
    List<Cand> cands(double maxDist, Kind... kinds) {
        List<Cand> out = new ArrayList<>();
        for (Road rd : roads) {
            boolean ok = false;
            for (Kind k : kinds) if (rd.kind == k) ok = true;
            if (!ok) continue;
            for (int side : new int[]{-1, 1})
                for (int i = 0; i < rd.len(); i += 3) {
                    int t = rd.a + rd.dir() * i;
                    int px = rd.alongX ? t : rd.c + side * 12, pz = rd.alongX ? rd.c + side * 12 : t;
                    double d = distNorm(px, pz);
                    if (d <= maxDist) out.add(new Cand(d, rd, side, t));
                }
        }
        out.sort((a, b) -> Double.compare(a.dist(), b.dist()));
        return out;
    }

    void lots() {
        if (city) {
            shops.addAll(List.of("army", "pizzeria", "gunstore", "bookstore", "grocery", "pharmacy", "hardware", "electronics", "liquor", "sports"));
            civic.addAll(List.of("police", "school", "fire"));
            // 0) деловой центр: высотки вдоль проспектов, больница и торговый центр рядом
            for (Cand c : cands(0.34, Kind.MAIN, Kind.CROSS, Kind.SIDE)) {
                if (r.nextFloat() < 0.75f) tryPlace(c.rd(), c.side(), c.t(), new Spec("tower", 25, 25, 0, 1));
            }
            List<Cand> mid = cands(0.6, Kind.MAIN, Kind.CROSS, Kind.SIDE);
            for (String sp : new String[]{"hospital", "mall", "library", "mall"}) {
                for (Cand c : mid) {
                    if (c.dist() < 0.15) continue;
                    if (tryPlace(c.rd(), c.side(), c.t(), new Spec(sp, sp.equals("library") ? 25 : 37, 25, 2, 2))) break;
                }
            }
            // блокпосты на въездах
            List<Cand> ends = cands(9.0, Kind.MAIN);
            for (int k = ends.size() - 1; k >= 0 && checkpoints < 2; k--) {
                Cand c = ends.get(k);
                if (c.dist() > 0.82 && tryPlace(c.rd(), c.side(), c.t(), new Spec("checkpoint", 25, 12, 0, 2))) checkpoints++;
            }
        }
        if (!village) {
            // 1) центр: магазины вдоль главной и поперечной, иногда парковка
            for (Cand c : cands(city ? 0.62 : 0.48, Kind.MAIN, Kind.CROSS)) {
                if (r.nextFloat() < 0.12f) tryPlace(c.rd(), c.side(), c.t(), new Spec("parking", 12 + 3 * r.nextInt(3), 12, 0, 0));
                else tryPlace(c.rd(), c.side(), c.t(), new Spec("shop", 25, 12, 0, 0));
            }
            // 2) полиция, клиника, сквер, пожарная, школа, церковь — как можно ближе к центру
            List<Cand> civ = cands(0.85, Kind.MAIN, Kind.CROSS, Kind.SIDE);
            while (!civic.isEmpty()) {
                int before = civic.size();
                for (Cand c : civ) if (tryPlace(c.rd(), c.side(), c.t(), new Spec("civic", 25, 25, 2, 2))) break;
                if (civic.size() == before) break;
            }
            // 3) заправки и мотель — у въездов
            List<Cand> edge = cands(9.0, Kind.MAIN, Kind.CROSS);
            for (int k = edge.size() - 1; k >= 0 && gasCount < 2; k--) {
                Cand c = edge.get(k);
                if (c.dist() > 0.6) tryPlace(c.rd(), c.side(), c.t(), new Spec("gas", 25, 12, 1, 3));
            }
            for (int k = edge.size() - 1; k >= 0 && autoShops < (city ? 2 : 1); k--) {
                Cand c = edge.get(k);
                if (c.dist() > 0.45) tryPlace(c.rd(), c.side(), c.t(), new Spec("autorepair", 25, 25, 1, 2));
            }
            for (int k = edge.size() - 1; k >= 0 && motels < 1; k--) {
                Cand c = edge.get(k);
                if (c.dist() > 0.5 && c.rd().kind == Kind.MAIN) tryPlace(c.rd(), c.side(), c.t(), new Spec("motel", 25, 25, 2, 3));
            }
        }
        // 4) остальное — жильё вдоль всех улиц
        for (Road rd : roads) {
            for (int side : new int[]{-1, 1}) {
                int i = 0;
                while (i < rd.len()) {
                    int t = rd.a + rd.dir() * i;
                    Spec sp = choose(rd, t, side);
                    boolean ok = tryPlace(rd, side, t, sp);
                    if (!ok && (sp.w() > 12 || sp.d() > 12)) {
                        double dist = distNorm(rd.alongX ? t : rd.c, rd.alongX ? rd.c : t);
                        Spec small = village || dist > 0.42 || rd.kind == Kind.SIDE || rd.kind == Kind.LANE ? residential(dist) : new Spec("parking", 12, 12, 0, 0);
                        if (small.w() <= sp.w() && small.d() <= sp.d() && !small.equals(sp)) {
                            ok = tryPlace(rd, side, t, small);
                            if (ok) sp = small;
                        }
                    }
                    i += ok ? sp.w() + sp.gap() : 2;
                }
            }
        }
    }

    /** Поля и огороды за деревней. */
    void fields() {
        int made = 0;
        for (int k = 0; k < 80 && made < 4; k++) {
            int x = 2 + r.nextInt(Math.max(1, W - 25)), z = 2 + r.nextInt(Math.max(1, D - 30));
            boolean ok = true;
            for (int a = x - 2; a < x + 23 && ok; a++)
                for (int b = z - 2; b < z + 29 && ok; b++) if (at(a, b) != EMPTY) ok = false;
            if (!ok) continue;
            Plan f = new Plan(21, 27, Random.create(r.nextLong()));
            Buildings.field(f, 0, 0, 20, 12);
            Buildings.field(f, 0, 14, 20, 26);
            if (r.nextFloat() < 0.4f) f.zombie(10, 1, 13, ZombieOutfit.FARMER);
            for (int a = x; a < x + 21; a++) for (int b = z; b < z + 27; b++) put(a, b, LOT);
            Knox.lot(f, ox + x, base, oz + z, BlockRotation.NONE);
            made++;
        }
    }

    // ===================== поверхность и детали улиц =====================

    BlockState decal(Block b) {
        return b.getDefaultState().with(DecalBlock.VARIANT, r.nextInt(4)).with(DecalBlock.FACING, Direction.Type.HORIZONTAL.random(r));
    }

    Direction toward(Road rd, int o) {
        if (rd.alongX) return o > 0 ? Direction.NORTH : Direction.SOUTH;
        return o > 0 ? Direction.WEST : Direction.EAST;
    }

    boolean isJunction(Road rd, int t) {
        return at(rd.x(t, rd.half + 1), rd.z(t, rd.half + 1)) == ROAD || at(rd.x(t, -rd.half - 1), rd.z(t, -rd.half - 1)) == ROAD;
    }

    void surface() {
        for (int x = 0; x < W; x++)
            for (int z = 0; z < D; z++) {
                byte v = at(x, z);
                if (v == ROAD) {
                    float k = r.nextFloat();
                    Block b;
                    if (village) b = k < 0.1f ? Blocks.GRAVEL : (k < 0.16f ? Blocks.COARSE_DIRT : Blocks.BLACK_CONCRETE);
                    else b = k < 0.1f ? Blocks.GRAY_CONCRETE : (k < 0.13f ? Blocks.POLISHED_BLACKSTONE : (k < 0.14f ? Blocks.COARSE_DIRT
                            : (k < 0.145f ? Blocks.COBBLESTONE : Blocks.BLACK_CONCRETE)));
                    st.set(x, 0, z, b);
                } else if (v == WALK) {
                    float k = r.nextFloat();
                    Block b;
                    if (village) b = k < 0.6f ? Blocks.GRAVEL : Blocks.COARSE_DIRT;
                    else b = k < 0.07f ? Blocks.ANDESITE : (k < 0.1f ? Blocks.COBBLESTONE : (k < 0.11f ? Blocks.MOSSY_COBBLESTONE : Blocks.SMOOTH_STONE));
                    st.set(x, 0, z, b);
                    if (r.nextFloat() < (distNorm(x, z) < 0.4 ? 0.04f : 0.012f)) st.set(x, 1, z, decal(ZomboidBlocks.LITTER));
                }
            }
    }

    void streetDetails() {
        for (Road rd : roads) {
            int outer = rd.half + rd.walk;
            int lampStep = 13 + r.nextInt(5);
            for (int i = 0; i <= rd.len(); i++) {
                int t = rd.a + rd.dir() * i;
                boolean junction = isJunction(rd, t) || i < rd.skip;
                // разметка: жёлтая прерывистая по центру, у главной — двойная
                if (!junction && rd.half >= 3) {
                    if (rd.half >= 4 && !village) {
                        st.set(rd.x(t, 0), 0, rd.z(t, 0), Blocks.YELLOW_CONCRETE);
                    } else if ((i % 5) < 3) st.set(rd.x(t, 0), 0, rd.z(t, 0), Blocks.YELLOW_CONCRETE);
                }
                if (junction) continue;
                // фонари по очереди с двух сторон
                if (!village && rd.walk >= 2 && i % lampStep == lampStep / 2) {
                    int sd = (i / lampStep) % 2 == 0 ? 1 : -1;
                    int o = sd * outer;
                    int x = rd.x(t, o), z = rd.z(t, o);
                    if (at(x, z) == WALK) {
                        st.set(x, 1, z, Blocks.IRON_BARS);
                        st.furn(x, 2, z, "street_lamp", toward(rd, o));
                        int o2 = o - sd;
                        st.set(rd.x(t, o2), 3, rd.z(t, o2), com.example.zomboidmod.block.PowerLampBlock.POWER_LIGHT.getDefaultState());
                    }
                } else if (rd.walk >= 1 && r.nextFloat() < (village ? 0.006f : 0.01f)) {
                    int o = (r.nextBoolean() ? 1 : -1) * outer;
                    int x = rd.x(t, o), z = rd.z(t, o);
                    if (at(x, z) == WALK && st.get(x, 1, z) == null) {
                        float k = r.nextFloat();
                        String id = village ? (k < 0.5f ? "mailbox" : "trash_can") : (k < 0.45f ? "hydrant" : (k < 0.7f ? "trash_can" : (k < 0.85f ? "bench" : "traffic_cone")));
                        if (id.equals("trash_can")) st.furnLoot(x, 1, z, id, toward(rd, o), Loot.TRASH);
                        else st.furn(x, 1, z, id, toward(rd, o));
                    }
                }
                // машины у обочины
                if (rd.half >= 3 && i % 6 == 0 && i + 6 < rd.len() && r.nextFloat() < (village ? 0.07f : 0.16f)) {
                    int sd = r.nextBoolean() ? 1 : -1;
                    boolean clear = true;
                    for (int k = 0; k < 6; k++) if (isJunction(rd, t + rd.dir() * k)) clear = false;
                    if (clear) {
                        double along = t + rd.dir() * 3.0 + 0.5, across = rd.c + sd * (rd.half - 1) + 0.5;
                        float yaw = rd.alongX ? (sd > 0 ? 270f : 90f) : (sd > 0 ? 180f : 0f);
                        st.vehicle(rd.alongX ? along : across, 1, rd.alongX ? across : along, VehicleType.randomCivil(r).id,
                                yaw + r.nextFloat() * 6f - 3f, r.nextFloat() < 0.12f);
                    }
                }
            }
            // знак «Стоп» в начале боковой улицы
            if (rd.kind != Kind.MAIN && rd.kind != Kind.CROSS && rd.len() > rd.skip + 2) {
                int t = rd.a + rd.dir() * rd.skip;
                int o = outer;
                int x = rd.x(t, o), z = rd.z(t, o);
                if (at(x, z) == WALK) {
                    Direction face = rd.alongX ? (rd.dir() > 0 ? Direction.EAST : Direction.WEST) : (rd.dir() > 0 ? Direction.SOUTH : Direction.NORTH);
                    st.furn(x, 1, z, "stop_sign", face);
                }
            }
        }
        // аварии на перекрёстках: развёрнутые машины, кровь, ограждения
        for (Road rd : roads) {
            if (rd.kind == Kind.MAIN || rd.kind == Kind.CROSS) continue;
            if (r.nextFloat() < 0.3f) {
                int t = rd.a + rd.dir() * (rd.skip + 3);
                double x = rd.x(t, 0) + 0.5, z = rd.z(t, 0) + 0.5;
                st.vehicle(x, 1, z, VehicleType.randomCivil(r).id, r.nextFloat() * 360f, true);
                for (int k = 0; k < 3; k++) {
                    int bx = (int) x + r.nextInt(5) - 2, bz = (int) z + r.nextInt(5) - 2;
                    if (at(bx, bz) == ROAD) st.set(bx, 1, bz, decal(ZomboidBlocks.BLOOD));
                }
                if (r.nextFloat() < 0.5f) {
                    int o = rd.half + rd.walk;
                    st.furn(rd.x(t + rd.dir() * 4, o - 1), 1, rd.z(t + rd.dir() * 4, o - 1), "traffic_cone", Direction.NORTH);
                    st.furn(rd.x(t + rd.dir() * 4, -o + 1), 1, rd.z(t + rd.dir() * 4, -o + 1), "road_barrier", rd.alongX ? Direction.EAST : Direction.NORTH);
                }
            }
        }
    }

    void nature() {
        for (int x = 1; x < W - 1; x++)
            for (int z = 1; z < D - 1; z++) {
                if (at(x, z) != EMPTY) continue;
                boolean edge = x < 8 || z < 8 || x > W - 9 || z > D - 9;
                float k = r.nextFloat();
                if (k < (edge ? 0.035f : 0.012f)) {
                    boolean ok = true;
                    for (int dx = -2; dx <= 2 && ok; dx++)
                        for (int dz = -2; dz <= 2 && ok; dz++) {
                            byte v = at(x + dx, z + dz);
                            if (v != EMPTY && v != OUT) ok = false;
                        }
                    if (!ok) continue;
                    st.tree(x, 0, z, r.nextInt(3));
                    for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) put(x + dx, z + dz, GREEN);
                } else if (k < 0.06f) {
                    st.set(x, 1, z, r.nextFloat() < 0.3f ? Blocks.OAK_LEAVES.getDefaultState().with(LeavesBlock.PERSISTENT, true)
                            : (r.nextFloat() < 0.7f ? Blocks.SHORT_GRASS.getDefaultState() : (r.nextBoolean() ? Blocks.DANDELION : Blocks.POPPY).getDefaultState()));
                }
            }
    }

    void streetZombies() {
        int n = W * D / (village ? 1400 : (city ? 480 : 520));
        for (int k = 0; k < n; k++) {
            int x = r.nextInt(W), z = r.nextInt(D);
            // гуще в центре
            if (!village && r.nextFloat() < 0.5f) {
                x = Math.max(0, Math.min(W - 1, dcx + r.nextInt(41) - 20));
                z = Math.max(0, Math.min(D - 1, dcz + r.nextInt(41) - 20));
            }
            byte v = at(x, z);
            if (v != ROAD && v != WALK && v != GREEN) continue;
            int group = 1 + (r.nextFloat() < 0.3f ? r.nextInt(4) : 0);
            for (int i = 0; i < group; i++) {
                int zx = x + r.nextInt(3) - 1, zz = z + r.nextInt(3) - 1;
                // в центре большого города зомби сильнее
                int tier = city ? (distNorm(zx, zz) < 0.3 ? 2 : 1) : (!village && distNorm(zx, zz) < 0.25 ? 1 : 0);
                if (at(zx, zz) == ROAD || at(zx, zz) == WALK || at(zx, zz) == GREEN) st.zombie(zx, 1, zz, null, tier);
            }
            if (r.nextFloat() < 0.35f && st.get(x, 1, z) == null) st.set(x, 1, z, decal(ZomboidBlocks.BLOOD));
        }
    }

    void generate(int mainZ, int crossX) {
        layout(mainZ, crossX);
        lots();
        if (village) fields();
        surface();
        streetDetails();
        nature();
        streetZombies();
        Knox.lot(st, ox, base, oz, BlockRotation.NONE);
    }
}
