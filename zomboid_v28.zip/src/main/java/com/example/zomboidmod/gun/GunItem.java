package com.example.zomboidmod.gun;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PaneBlock;
import net.minecraft.block.TransparentBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.List;
import java.util.function.Supplier;

/**
 * Огнестрел как в PZ: ПКМ — выстрел (очень громко, сбегаются зомби со всей округи), R — перезарядка патронами из инвентаря.
 * Разброс зависит от навыка «Меткость», движения и того, крадёшься ли ты. Попадание в голову — двойной урон.
 */
public class GunItem extends Item {
    public final String id;
    final Supplier<Item> ammo;
    public final int capacity, cooldown, reloadTicks, pellets, noise;
    final float damage, range, spreadDeg;
    final Supplier<SoundEvent> sound;

    public GunItem(String id, Supplier<Item> ammo, int capacity, float damage, float range, int pellets, float spreadDeg, int cooldown,
                   int reloadTicks, int noise, Supplier<SoundEvent> sound, Settings settings) {
        super(settings.maxCount(1));
        this.id = id;
        this.ammo = ammo;
        this.capacity = capacity;
        this.damage = damage;
        this.range = range;
        this.pellets = pellets;
        this.spreadDeg = spreadDeg;
        this.cooldown = cooldown;
        this.reloadTicks = reloadTicks;
        this.noise = noise;
        this.sound = sound;
    }

    public static int ammo(ItemStack st) {
        return st.getOrDefault(DataComponentTypes.CUSTOM_DATA, NbtComponent.DEFAULT).copyNbt().getInt("ammo");
    }

    public static void setAmmo(ItemStack st, int n) {
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, st, nbt -> nbt.putInt("ammo", n));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack st = player.getStackInHand(hand);
        if (player.getItemCooldownManager().isCoolingDown(this)) return TypedActionResult.fail(st);
        if (ammo(st) <= 0) {
            if (!world.isClient && player instanceof ServerPlayerEntity sp && !reload(sp, st)) {
                world.playSound(null, player.getBlockPos(), Guns.DRY, SoundCategory.PLAYERS, 1f, 1f);
                player.getItemCooldownManager().set(this, 8);
            }
            return TypedActionResult.consume(st);
        }
        if (!world.isClient && player instanceof ServerPlayerEntity sp) fire((ServerWorld) world, sp, st, hand);
        return TypedActionResult.consume(st);
    }

    private void fire(ServerWorld w, ServerPlayerEntity p, ItemStack st, Hand hand) {
        setAmmo(st, ammo(st) - 1);
        p.getItemCooldownManager().set(this, cooldown);
        int aim = Skills.level(p, PzSkill.AIMING);
        float spread = spreadDeg * (1.5f - 0.1f * aim);
        if (p.getVelocity().horizontalLengthSquared() > 0.005) spread *= 1.6f;
        if (p.isSneaking()) spread *= 0.6f;
        spread *= com.example.zomboidmod.survival.Survival.gunSpreadMult(p);   // паника и стресс трясут руки
        float panicDmg = com.example.zomboidmod.survival.Survival.gunDamageMult(p);
        Vec3d eye = p.getEyePos();
        boolean hitAny = false;
        for (int i = 0; i < pellets; i++) {
            float yaw = p.getYaw() + (float) p.getRandom().nextGaussian() * spread;
            float pitch = p.getPitch() + (float) p.getRandom().nextGaussian() * spread;
            Vec3d dir = Vec3d.fromPolar(pitch, yaw);
            Vec3d end = eye.add(dir.multiply(range));
            BlockHitResult bh = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            Vec3d stop = bh.getType() == HitResult.Type.MISS ? end : bh.getPos();
            EntityHitResult eh = ProjectileUtil.raycast(p, eye, stop, new Box(eye, stop).expand(1.0),
                    e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator() && e != p, eye.squaredDistanceTo(stop));
            if (eh != null && eh.getEntity() instanceof LivingEntity target) {
                Vec3d hp = eh.getPos();
                boolean head = hp.y > target.getEyeY() - 0.28;
                float dmg = damage * panicDmg * (head ? 2.2f : 1f) * (pellets > 1 ? Math.max(0.35f, 1f - (float) eye.distanceTo(hp) / range) : 1f);
                target.timeUntilRegen = 0;   // дробь бьёт всеми дробинками
                target.damage(w.getDamageSources().playerAttack(p), dmg);
                target.takeKnockback(pellets > 1 ? 0.25 : 0.4, -dir.x, -dir.z);
                w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.getDefaultState()),
                        hp.x, hp.y, hp.z, head ? 18 : 8, 0.1, 0.1, 0.1, 0.15);
                hitAny = true;
            } else if (bh.getType() == HitResult.Type.BLOCK) {
                BlockState bs = w.getBlockState(bh.getBlockPos());
                Vec3d hp = bh.getPos();
                w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, bs), hp.x, hp.y, hp.z, 6, 0.05, 0.05, 0.05, 0.1);
                if (bs.getBlock() instanceof PaneBlock || bs.getBlock() instanceof TransparentBlock) w.breakBlock(bh.getBlockPos(), false);
            }
        }
        Vec3d muzzle = eye.add(p.getRotationVector().multiply(1.1)).add(0, -0.15, 0);
        w.spawnParticles(ParticleTypes.FLASH, muzzle.x, muzzle.y, muzzle.z, 1, 0, 0, 0, 0);
        w.spawnParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 6, 0.05, 0.05, 0.05, 0.02);
        w.playSound(null, p.getBlockPos(), sound.get(), SoundCategory.PLAYERS, 4f, 0.95f + p.getRandom().nextFloat() * 0.1f);
        Noise.emitAt(w, p.getBlockPos(), noise);     // выстрел слышно далеко, крадись не крадись
        Skills.addXp(p, PzSkill.AIMING, hitAny ? 5f : 1.5f);
        p.swingHand(hand, true);                     // отдача (анимация)
        // отдача: камеру подбрасывает
        p.setPitch(MathHelper.clamp(p.getPitch() - (pellets > 1 ? 4f : id.equals("hunting_rifle") ? 5f : 2.5f), -90f, 90f));
    }

    /** Перезарядка патронами из инвентаря. */
    public boolean reload(ServerPlayerEntity p, ItemStack st) {
        int need = capacity - ammo(st);
        if (need <= 0) return false;
        int got = 0;
        for (int i = 0; i < p.getInventory().size() && got < need; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isOf(ammo.get())) {
                int n = Math.min(need - got, s.getCount());
                s.decrement(n);
                got += n;
            }
        }
        if (got == 0) {
            p.sendMessage(Text.literal("Нет патронов"), true);
            return false;
        }
        setAmmo(st, ammo(st) + got);
        p.getItemCooldownManager().set(this, reloadTicks);
        p.getWorld().playSound(null, p.getBlockPos(), Guns.RELOAD, SoundCategory.PLAYERS, 1f, 1f);
        Noise.emitFrom(p, 6);
        p.sendMessage(Text.literal("Перезаряжено: " + ammo(st) + "/" + capacity), true);
        return true;
    }

    @Override
    public boolean isItemBarVisible(ItemStack stack) {
        return true;
    }

    @Override
    public int getItemBarStep(ItemStack stack) {
        return Math.round(13f * ammo(stack) / capacity);
    }

    @Override
    public int getItemBarColor(ItemStack stack) {
        return 0xE0B040;
    }

    @Override
    public boolean allowComponentsUpdateAnimation(PlayerEntity player, Hand hand, ItemStack oldStack, ItemStack newStack) {
        return false;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal("Патроны: " + ammo(stack) + "/" + capacity).formatted(Formatting.GOLD));
        tooltip.add(Text.literal("ПКМ — выстрел, R — перезарядка").formatted(Formatting.DARK_GRAY));
        tooltip.add(Text.literal("Очень громко: на выстрел сбегаются зомби").formatted(Formatting.DARK_RED));
    }
}
