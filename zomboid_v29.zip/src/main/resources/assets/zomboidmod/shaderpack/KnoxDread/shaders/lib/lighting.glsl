uniform sampler2DShadow shadowtex0;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

vec3 distortShadow(vec3 p) {
    float d = length(p.xy);
    p.xy /= d * 0.9 + 0.1;
    p.z *= 0.2;
    return p;
}

float shadowAt(vec3 viewPos, vec3 nView, float NdotL) {
    vec4 pp = gbufferModelViewInverse * vec4(viewPos + nView * 0.08, 1.0);
    float pd = length(pp.xyz);
    if (pd > shadowDistance - 2.0) return 1.0;
    vec4 sp = shadowProjection * (shadowModelView * pp);
    float dist = length(sp.xy) * 0.9 + 0.1;
    sp.xyz = distortShadow(sp.xyz);
    vec3 c = sp.xyz * 0.5 + 0.5;
    if (c.x < 0.0 || c.x > 1.0 || c.y < 0.0 || c.y > 1.0) return 1.0;
    float bias = (0.00012 + 0.0006 * (1.0 - NdotL)) * dist * dist * 4.0;
    float px = 1.0 / float(shadowMapResolution);
    float s = 0.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            s += shadow2D(shadowtex0, vec3(c.xy + vec2(float(x), float(y)) * px * 1.3, c.z - bias)).r;
        }
    }
    s /= 9.0;
    float fade = smoothstep(shadowDistance - 20.0, shadowDistance - 2.0, pd);
    return mix(s, 1.0, fade);
}

uniform int heldItemId;
uniform int heldItemId2;
uniform float frameTimeCounter;

vec3 lighting(vec3 albedo, vec2 lm, vec3 nView, vec3 viewPos, bool useShadow) {
    float day = dayFactor();
    float sky = lm.y;
    float skyL = sky * sky;
    vec3 L = normalize(shadowLightPosition);
    float NdotL = max(dot(nView, L), 0.0);
    float sh = 1.0;
    if (useShadow && NdotL > 0.001 && sky > 0.05) sh = shadowAt(viewPos, nView, NdotL);
    float sunH = sunHeight();
    vec3 sunC = mix(vec3(1.0, 0.55, 0.32), vec3(1.0, 0.93, 0.84), smoothstep(0.0, 0.35, sunH)) * 1.0;
    vec3 moonC = vec3(0.13, 0.155, 0.23) * 0.9 * NIGHT_BRIGHTNESS;
    vec3 direct = mix(moonC, sunC, day) * (1.0 - rainStrength * 0.75);
    float up = dot(nView, normalize(upPosition));
    float skyDir = 0.72 + 0.28 * up;
    vec3 amb = mix(vec3(0.065, 0.078, 0.11) * NIGHT_BRIGHTNESS, vec3(0.36, 0.38, 0.42) / SHADOW_DARKNESS, day) * (1.0 - rainStrength * 0.25) * skyDir;
    float bl = lm.x;
    vec3 lamp = vec3(1.0, 0.6, 0.3) * (pow(bl, 3.2) * 1.6);
    float dist = length(viewPos);
    float flick = 0.93 + 0.07 * sin(frameTimeCounter * 9.0) * sin(frameTimeCounter * 5.3 + 1.3);
    float held = float(max(heldBlockLightValue, heldBlockLightValue2));
    float hl = clamp((held - dist * 1.1) / 15.0, 0.0, 1.0);
    lamp += vec3(1.0, 0.68, 0.42) * hl * hl * 1.3 * flick;
    if (heldItemId == 20001 || heldItemId2 == 20001) {
        vec3 dir = viewPos / max(dist, 0.001);
        float cosA = -dir.z;
        float cone = smoothstep(0.905, 0.985, cosA) + 0.16 * smoothstep(0.70, 0.93, cosA);
        float att = (1.0 - smoothstep(24.0, 38.0, dist)) / (1.0 + dist * dist * 0.006);
        float ndl = clamp(dot(nView, -dir), 0.0, 1.0) * 0.85 + 0.15;
        lamp += vec3(0.93, 0.96, 1.0) * cone * att * ndl * FLASHLIGHT_POWER;
    }
    vec3 light = amb * skyL + direct * NdotL * sh * smoothstep(0.2, 0.9, sky) + lamp + vec3(0.005) + vec3(nightVision * 0.45);
    return albedo * light;
}
