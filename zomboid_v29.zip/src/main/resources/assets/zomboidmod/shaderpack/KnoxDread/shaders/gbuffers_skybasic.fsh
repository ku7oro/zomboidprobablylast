#version 120
/* DRAWBUFFERS:0 */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
varying vec4 color;
varying vec3 viewPos;
varying float star;
void main() {
    float day = dayFactor();
    if (star > 0.5) {
        gl_FragData[0] = vec4(color.rgb * 0.5 * (1.0 - rainStrength) * (1.0 - day), color.a);
        return;
    }
    vec3 dir = normalize(viewPos);
    float up = dot(dir, normalize(upPosition));
    vec3 zenith = mix(vec3(0.008, 0.010, 0.016), vec3(0.28, 0.32, 0.37), day);
    zenith = mix(zenith, vec3(0.24, 0.25, 0.26) * day + 0.004, rainStrength);
    vec3 horizon = fogTint(day);
    float sunDot = max(dot(dir, normalize(sunPosition)), 0.0);
    float glow = pow(sunDot, 6.0) * (1.0 - smoothstep(0.0, 0.35, abs(sunHeight()))) * (1.0 - rainStrength);
    vec3 c = mix(horizon, zenith, smoothstep(-0.05, 0.45, up)) + vec3(0.42, 0.18, 0.07) * glow * 0.6;
    gl_FragData[0] = vec4(c, 1.0);
}
