#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;
varying vec2 texcoord;
void main() {
    vec3 c = texture2D(colortex0, texcoord).rgb;
    float day = dayFactor();
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(l), c, COLOR_SATURATION);
    c = max((c - 0.3) * mix(1.0, 1.08, day) + 0.3, c * 0.85);
    c += vec3(-0.010, 0.002, 0.012) * (1.0 - l) + vec3(0.012, 0.004, -0.010) * l;
#ifdef VIGNETTE
    vec2 d = texcoord - 0.5;
    float vig = 1.0 - dot(d, d) * (1.1 + 0.9 * (1.0 - day));
    c *= clamp(vig, 0.0, 1.0);
#endif
#ifdef FILM_GRAIN
    float n = fract(sin(dot(floor(texcoord * vec2(viewWidth, viewHeight)) + floor(frameTimeCounter * 24.0) * 17.0,
                           vec2(12.9898, 78.233))) * 43758.5453);
    c += (n - 0.5) * 0.022;
#endif
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
