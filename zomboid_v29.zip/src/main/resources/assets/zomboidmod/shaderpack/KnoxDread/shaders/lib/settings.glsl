const int shadowMapResolution = 2048;
const float shadowDistance = 112.0;
const bool shadowHardwareFiltering = true;
const float sunPathRotation = -25.0;
const float shadowDistanceRenderMul = 1.0;

#define NIGHT_BRIGHTNESS 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
#define FOG_DENSITY 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0]
#define COLOR_SATURATION 0.74 // [0.5 0.6 0.74 0.85 1.0]
#define SHADOW_DARKNESS 1.0 // [0.6 0.8 1.0 1.2]
#define FLASHLIGHT_POWER 2.4 // [1.2 1.8 2.4 3.2 4.0]
#define WAVING_PLANTS
#define VIGNETTE
#define FILM_GRAIN
