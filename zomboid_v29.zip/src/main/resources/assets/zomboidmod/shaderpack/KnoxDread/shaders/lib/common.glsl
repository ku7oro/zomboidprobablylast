uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 shadowLightPosition;
uniform float rainStrength;
uniform int worldTime;
uniform float nightVision;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform float fogEnd;
uniform float far;
uniform vec3 cameraPosition;
uniform mat4 gbufferModelViewInverse;

float sunHeight() {
    return dot(normalize(sunPosition), normalize(upPosition));
}

float dayFactor() {
    return smoothstep(-0.08, 0.22, sunHeight());
}

vec3 fogTint(float day) {
    vec3 dayC = mix(vec3(0.44, 0.47, 0.48), vec3(0.30, 0.32, 0.33), rainStrength);
    vec3 nightC = vec3(0.026, 0.030, 0.042) * NIGHT_BRIGHTNESS;
    float dusk = (1.0 - smoothstep(0.0, 0.3, abs(sunHeight()))) * (1.0 - rainStrength);
    return mix(nightC, dayC, day) + vec3(0.10, 0.04, 0.01) * dusk * day;
}

vec3 applyFog(vec3 color, vec3 viewPos) {
    float day = dayFactor();
    float dist = length(viewPos);
    float end = far;
    if (fogEnd > 4.0 && fogEnd < far * 1.5) end = min(fogEnd, far);
    float f = clamp(dist / max(end, 8.0), 0.0, 1.0);
    f = 1.0 - exp(-f * f * 4.5 * FOG_DENSITY);
    vec3 wp = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
    float t = float(worldTime);
    float dawn = (t > 21500.0 || t < 2500.0) ? 1.0 : 0.0;
    float mistAmount = (0.22 + 0.45 * rainStrength + 0.4 * dawn) * FOG_DENSITY;
    float mist = exp(-max(wp.y - 62.0, 0.0) / 7.0) * smoothstep(6.0, 40.0, dist) * mistAmount;
    f = clamp(f + mist, 0.0, 1.0);
    return mix(color, fogTint(day), f);
}

vec2 normLightmap(vec2 lm) {
    return clamp((lm - 0.03125) * 1.06667, 0.0, 1.0);
}
