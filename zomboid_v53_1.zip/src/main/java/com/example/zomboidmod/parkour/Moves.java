package com.example.zomboidmod.parkour;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.Survival;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Быстрый паркур: подкат на бегу, нырок с перекатом, бег по стене и прыжок от неё.
 * Двигает игрока его клиент (как и всё движение в Minecraft), сервер знает, что он делает: показывает это другим,
 * гасит урон от падения перекатом, сбивает подкатом зомби с ног, тратит выносливость и шумит.
 */
public final class Moves {
    private Moves() {
    }

    public static final int NONE = 0, SLIDE = 1, DIVE = 2, ROLL = 3, WALL_L = 4, WALL_R = 5, WALL_JUMP = 6;

    /** Что делает сущность на клиенте: id → вид движения (свой игрок тоже здесь). */
    public static final Map<Integer, Integer> CLIENT = new HashMap<>();
    /** Когда началось (по часам мира) — для анимации. */
    public static final Map<Integer, Long> CLIENT_SINCE = new HashMap<>();

    public record MovePayload(int kind) implements CustomPayload {
        public static final CustomPayload.Id<MovePayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "move"));
        public static final PacketCodec<RegistryByteBuf, MovePayload> CODEC = PacketCodec.tuple(PacketCodecs.VAR_INT, MovePayload::kind, MovePayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public record StatePayload(int entity, int kind) implements CustomPayload {
        public static final CustomPayload.Id<StatePayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "move_state"));
        public static final PacketCodec<RegistryByteBuf, StatePayload> CODEC = PacketCodec.tuple(PacketCodecs.VAR_INT, StatePayload::entity,
                PacketCodecs.VAR_INT, StatePayload::kind, StatePayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    private static final class St {
        int kind;
        int ticks;
        long rollUntil;                  // до этого тика мира падение смягчается перекатом
        final Set<Integer> tripped = new HashSet<>();
    }

    private static final Map<UUID, St> SERVER = new HashMap<>();

    public static void register() {
        PayloadTypeRegistry.playC2S().register(MovePayload.ID, MovePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(StatePayload.ID, StatePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(MovePayload.ID, (pl, ctx) -> ctx.server().execute(() -> request(ctx.player(), pl.kind())));
        ServerTickEvents.END_SERVER_TICK.register(Moves::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((h, s) -> SERVER.remove(h.player.getUuid()));
    }

    /** Поза: подкат и перекат — пригнувшись (пролезает под плиту), нырок — плашмя. */
    public static EntityPose forcedPose(PlayerEntity p) {
        int k;
        if (p.getWorld().isClient) k = CLIENT.getOrDefault(p.getId(), NONE);
        else {
            St s = SERVER.get(p.getUuid());
            k = s == null ? NONE : s.kind;
        }
        return k == SLIDE || k == ROLL ? EntityPose.CROUCHING : k == DIVE ? EntityPose.SWIMMING : null;
    }

    public static boolean busy(PlayerEntity p) {
        return forcedPose(p) != null;
    }

    private static void request(ServerPlayerEntity p, int kind) {
        if (kind < NONE || kind > WALL_JUMP || !p.isAlive() || p.isSpectator()) return;
        St s = SERVER.computeIfAbsent(p.getUuid(), k -> new St());
        long now = p.getWorld().getTime();
        boolean free = p.isCreative();
        Mood m = free ? null : Survival.mood(p);
        if (kind != NONE && m != null && Mood.exertion(m.endurance) >= 3) kind = NONE;      // без сил не до акробатики
        int nimble = Skills.level(p, PzSkill.NIMBLE);
        switch (kind) {
            case SLIDE -> {
                s.tripped.clear();
                cost(p, m, 0.030f);
                BlockState ground = p.getWorld().getBlockState(p.getBlockPos().down());
                p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), ground.getSoundGroup().getStepSound(), SoundCategory.PLAYERS, 1.0f, 0.55f);
                Noise.emitFrom(p, 8);
                Skills.addXp(p, PzSkill.NIMBLE, 1.5f);
            }
            case DIVE -> {
                cost(p, m, 0.035f);
                s.rollUntil = now + 60;
            }
            case ROLL -> {
                s.rollUntil = now + 12;
                p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_SMALL_FALL, SoundCategory.PLAYERS, 0.8f, 0.8f);
                Noise.emitFrom(p, 6);
                Skills.addXp(p, PzSkill.NIMBLE, 2.5f);
            }
            case WALL_L, WALL_R -> {
                cost(p, m, 0.025f);
                p.fallDistance = 0f;
                Skills.addXp(p, PzSkill.SPRINTING, 1.5f);
            }
            case WALL_JUMP -> {
                cost(p, m, 0.030f);
                p.fallDistance = 0f;
                p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_STONE_STEP, SoundCategory.PLAYERS, 0.9f, 0.8f);
                Noise.emitFrom(p, 6);
                Skills.addXp(p, PzSkill.NIMBLE, 2f);
                kind = NONE;                                       // сам прыжок — мгновение, дальше обычный полёт
            }
            default -> {
                if (s.kind == DIVE) s.rollUntil = now + 6;          // нырнул и приземлился без переката — всё равно сгруппировался
            }
        }
        s.kind = kind;
        s.ticks = 0;
        StatePayload out = new StatePayload(p.getId(), kind);
        for (ServerPlayerEntity o : PlayerLookup.tracking(p)) if (ServerPlayNetworking.canSend(o, StatePayload.ID)) ServerPlayNetworking.send(o, out);
    }

    private static void cost(ServerPlayerEntity p, Mood m, float v) {
        if (m == null) return;
        int fit = Skills.level(p, PzSkill.FITNESS);
        m.endurance = Math.max(0f, m.endurance - v * (1f - 0.04f * fit));
    }

    private static void tick(MinecraftServer server) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            St s = SERVER.get(p.getUuid());
            if (s == null || s.kind == NONE) continue;
            s.ticks++;
            int max = s.kind == SLIDE ? 34 : s.kind == ROLL ? 18 : s.kind == DIVE ? 80 : 40;
            if (s.ticks > max || !p.isAlive()) {                    // клиент пропал или завис — не оставляем в позе
                request(p, NONE);
                continue;
            }
            if (s.kind == WALL_L || s.kind == WALL_R) p.fallDistance = 0f;
            if (s.kind == SLIDE) trip(p, s);
        }
    }

    /** Подкат в ноги: мертвец, в которого въехали, падает. */
    private static void trip(ServerPlayerEntity p, St s) {
        Vec3d v = p.getVelocity();
        Vec3d look = Vec3d.fromPolar(0, p.getYaw());
        for (PzZombieEntity z : p.getWorld().getEntitiesByClass(PzZombieEntity.class, p.getBoundingBox().expand(0.45, 0.1, 0.45).offset(look.multiply(0.35)),
                e -> e.isAlive() && !e.isDown())) {
            if (!s.tripped.add(z.getId())) continue;
            z.takeKnockback(0.35, p.getX() - z.getX(), p.getZ() - z.getZ());
            if (p.getRandom().nextFloat() < 0.75f + 0.025f * Skills.level(p, PzSkill.NIMBLE))
                z.knockDown(35 + p.getRandom().nextInt(30), z.fallsFaceDown(p.getPos()));
            p.getWorld().playSound(null, z.getX(), z.getY(), z.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, SoundCategory.PLAYERS, 0.9f, 0.8f);
            if (s.tripped.size() >= 2) {                            // двоих сбил — третий уже остановит
                request(p, NONE);
                return;
            }
        }
    }

    /**
     * Урон от падения с учётом переката: сгруппировался и перекатился — высота «короче» на 4 блока
     * (и ещё на полблока за каждые два уровня проворства), остаток бьёт вполсилы.
     */
    public static int fall(LivingEntity e, float distance, float multiplier, int vanilla) {
        if (!(e instanceof ServerPlayerEntity p) || vanilla <= 0) return vanilla;
        St s = SERVER.get(p.getUuid());
        if (s == null || p.getWorld().getTime() > s.rollUntil) return vanilla;
        float spare = 4f + 0.25f * Skills.level(p, PzSkill.NIMBLE);
        float rest = distance - 3f - spare;
        if (rest <= 0f) return 0;
        return Math.max(0, (int) Math.ceil(rest * multiplier * 0.55f));
    }
}
