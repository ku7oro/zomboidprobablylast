package com.example.zomboidmod.parkour;

import com.example.zomboidmod.motion.BodyAnim;
import com.example.zomboidmod.motion.BodySync;
import com.example.zomboidmod.motion.Knockdown;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.SurvivalClient;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Быстрый паркур на клиенте: решает, когда начать подкат, нырок, перекат и бег по стене, двигает своего игрока
 * и рисует позы (свои и чужие).
 *
 * Управление без новых клавиш:
 *  — подкат: на бегу нажать «красться»;
 *  — нырок: в воздухе нажать «красться»; приземление переходит в перекат, который гасит падение;
 *  — бег по стене: в прыжке на бегу вдоль стены; «прыжок» ещё раз — оттолкнуться от стены.
 */
public final class MovesClient {
    private MovesClient() {
    }

    private static int state = Moves.NONE, ticks, cooldown, airTicks, wallUsed;
    private static boolean prevSneak, prevJump, divedThisAir;
    private static double dirX, dirZ, speed;
    private static float tilt, tiltPrev;                 // крен камеры у стены
    private static float dip, dipPrev;                   // кивок камеры в перекате

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(Moves.StatePayload.ID, (pl, ctx) -> ctx.client().execute(() -> {
            if (ctx.client().player != null && pl.entity() == ctx.client().player.getId()) return;   // своё состояние знаем сами
            put(pl.entity(), pl.kind(), ctx.client().world == null ? 0 : ctx.client().world.getTime());
        }));
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> {
            Moves.CLIENT.clear();
            Moves.CLIENT_SINCE.clear();
            state = Moves.NONE;
        });
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            tiltPrev = tilt;
            dipPrev = dip;
            float want = state == Moves.WALL_L ? 1f : state == Moves.WALL_R ? -1f : 0f;
            tilt += (want - tilt) * 0.3f;
            dip += ((state == Moves.ROLL ? 1f : 0f) - dip) * 0.35f;
            if (c.world != null && c.world.getTime() % 100 == 0) {
                long now = c.world.getTime();
                Moves.CLIENT_SINCE.entrySet().removeIf(e -> now - e.getValue() > 200 && (c.player == null || e.getKey() != c.player.getId()));
                Moves.CLIENT.keySet().retainAll(Moves.CLIENT_SINCE.keySet());
            }
        });
    }

    private static void put(int id, int kind, long now) {
        if (kind == Moves.NONE) {
            Moves.CLIENT.remove(id);
            Moves.CLIENT_SINCE.remove(id);
        } else {
            Moves.CLIENT.put(id, kind);
            Moves.CLIENT_SINCE.put(id, now);
        }
    }

    private static void set(ClientPlayerEntity p, int kind) {
        state = kind;
        ticks = 0;
        put(p.getId(), kind, p.getWorld().getTime());
        ClientPlayNetworking.send(new Moves.MovePayload(kind));
    }

    /** Может ли тело сейчас в акробатику: целые ноги, не перегружен, есть силы, не лежит и ничего не тащит. */
    private static boolean able(ClientPlayerEntity p) {
        if (p.getAbilities().flying || p.hasVehicle() || p.isTouchingWater() || p.isClimbing() || p.isFallFlying() || p.isSpectator()
                || p.isSleeping() || p.isUsingItem() || ParkourClient.climbing(p) || Knockdown.down(p)
                || com.example.zomboidmod.drag.DragClient.dragging()) return false;
        if (p.isCreative()) return true;
        int flags = BodyAnim.FLAGS.getOrDefault(p.getId(), 0);
        if ((flags & (BodySync.LIMP_L_BAD | BodySync.LIMP_R_BAD)) != 0) return false;
        if (BodySync.load(flags) >= 2) return false;
        return Mood.exertion(SurvivalClient.endurance) < 3;
    }

    private static boolean solid(World w, double x, double y, double z) {
        BlockPos pos = BlockPos.ofFloored(x, y, z);
        return !w.getBlockState(pos).getCollisionShape(w, pos).isEmpty() && w.getBlockState(pos).isSideSolidFullSquare(w, pos, net.minecraft.util.math.Direction.UP);
    }

    /** Есть ли стена сбоку от направления движения: side +1 — справа, -1 — слева. */
    private static boolean wall(ClientPlayerEntity p, double dx, double dz, int side) {
        double rx = -dz * side, rz = dx * side;
        World w = p.getWorld();
        double x = p.getX() + rx * 0.55, z = p.getZ() + rz * 0.55;
        return solid(w, x, p.getY() + 0.3, z) && solid(w, x, p.getY() + 1.3, z);
    }

    /** Из ClientPlayerEntity.tickMovement сразу после опроса клавиш, до инерции. */
    public static void input(ClientPlayerEntity p) {
        Input in = p.input;
        boolean sneak = in.sneaking, jump = in.jumping;
        boolean sneakHit = sneak && !prevSneak, jumpHit = jump && !prevJump;
        prevSneak = sneak;
        prevJump = jump;
        if (cooldown > 0) cooldown--;
        boolean ground = p.isOnGround();
        if (ground) {
            airTicks = 0;
            wallUsed = 0;
            divedThisAir = false;
        } else airTicks++;
        Vec3d v = p.getVelocity();
        double hs = Math.sqrt(v.x * v.x + v.z * v.z);

        if (state != Moves.NONE && !able(p)) {
            set(p, Moves.NONE);
            return;
        }
        ticks++;
        switch (state) {
            case Moves.SLIDE -> {
                // едет по земле по инерции; можно слегка подруливать взглядом, прыжок — выскочить из подката
                Vec3d look = Vec3d.fromPolar(0, p.getYaw());
                double nx = dirX * 0.94 + look.x * 0.06, nz = dirZ * 0.94 + look.z * 0.06;
                double nl = Math.sqrt(nx * nx + nz * nz);
                if (nl > 1e-4) {
                    dirX = nx / nl;
                    dirZ = nz / nl;
                }
                speed *= ground ? 0.955 : 0.99;
                boolean stop = ticks > 26 || speed < 0.13 || p.horizontalCollision || (!sneak && ticks > 7) || (!ground && airTicks > 8);
                if (jumpHit && ground && ticks > 3) {
                    set(p, Moves.NONE);
                    cooldown = 8;
                    p.setVelocity(dirX * speed, v.y, dirZ * speed);
                    p.setSprinting(true);
                    return;                                        // прыжок обработает сама игра, скорость сохранится
                }
                if (stop) {
                    set(p, Moves.NONE);
                    cooldown = 12;
                    return;
                }
                p.setVelocity(dirX * speed, v.y, dirZ * speed);
                in.movementForward = 0f;
                in.movementSideways = 0f;
                in.sneaking = false;                               // иначе игра не даст съехать с края
                in.jumping = false;
                if (ground && ticks % 2 == 0) dust(p);
            }
            case Moves.DIVE -> {
                in.sneaking = false;
                in.movementForward = 0f;
                in.movementSideways = 0f;
                if (ground) {
                    if (hs > 0.08 || speed > 0.15) {
                        speed = Math.max(Math.min(hs, 0.5), 0.28);
                        if (hs > 0.05) {
                            dirX = v.x / hs;
                            dirZ = v.z / hs;
                        }
                        set(p, Moves.ROLL);
                    } else {
                        set(p, Moves.NONE);
                        cooldown = 10;
                    }
                } else if (ticks > 70) set(p, Moves.NONE);
            }
            case Moves.ROLL -> {
                speed *= 0.93;
                p.setVelocity(dirX * speed, v.y, dirZ * speed);
                in.movementForward = 0f;
                in.movementSideways = 0f;
                in.sneaking = false;
                in.jumping = false;
                if (ticks >= 11 || p.horizontalCollision) {
                    set(p, Moves.NONE);
                    cooldown = 8;
                    p.setSprinting(true);                          // из переката — сразу бегом
                }
            }
            case Moves.WALL_L, Moves.WALL_R -> {
                int side = state == Moves.WALL_R ? 1 : -1;
                if (ground || in.movementForward <= 0f || hs < 0.1 || ticks > 26 || !wall(p, dirX, dirZ, side)) {
                    wallUsed |= side > 0 ? 2 : 1;
                    set(p, Moves.NONE);
                    return;
                }
                if (jumpHit) {
                    // толчок от стены: в сторону от неё, вперёд и вверх
                    double nx = dz(side), nz = dxn(side);
                    Vec3d look = Vec3d.fromPolar(0, p.getYaw());
                    double s = Math.max(hs, 0.26);
                    p.setVelocity(nx * 0.3 + dirX * s * 0.7 + look.x * 0.12, 0.5, nz * 0.3 + dirZ * s * 0.7 + look.z * 0.12);
                    p.fallDistance = 0f;
                    wallUsed |= side > 0 ? 2 : 1;
                    wallUsed &= side > 0 ? ~1 : ~2;                 // от противоположной стены можно снова
                    state = Moves.NONE;
                    put(p.getId(), Moves.NONE, 0);
                    ClientPlayNetworking.send(new Moves.MovePayload(Moves.WALL_JUMP));
                    return;
                }
                // бежит вдоль стены: сначала чуть вверх, потом всё сильнее вниз
                double s = Math.max(hs, 0.24);
                double vy = 0.05 - 0.0095 * ticks + 0.08;           // +0.08 — гравитация, которую игра вычтет в этот же тик
                double push = 0.03;
                p.setVelocity(dirX * s - dz(side) * push, Math.max(v.y * 0.5, vy), dirZ * s - dxn(side) * push);
                p.fallDistance = 0f;
                in.sneaking = false;
            }
            default -> start(p, in, sneakHit, ground, v, hs);
        }
    }

    /** Нормаль от стены наружу (x, z) для стороны side относительно направления бега. */
    private static double dz(int side) {
        return dirZ * side;
    }

    private static double dxn(int side) {
        return -dirX * side;
    }

    private static void start(ClientPlayerEntity p, Input in, boolean sneakHit, boolean ground, Vec3d v, double hs) {
        if (cooldown > 0 || !able(p)) return;
        // подкат
        if (ground && sneakHit && p.isSprinting() && hs > 0.17) {
            dirX = v.x / hs;
            dirZ = v.z / hs;
            speed = Math.min(0.56, Math.max(hs * 1.3, 0.34));
            in.sneaking = false;
            set(p, Moves.SLIDE);
            return;
        }
        // нырок: с разбега — вперёд, а просто в падении — сгруппироваться перед землёй
        if (!ground && sneakHit && !divedThisAir && airTicks > 1 && (p.isSprinting() || p.fallDistance > 1.5f)) {
            divedThisAir = true;
            speed = hs;
            if (p.isSprinting() && hs > 0.12) {
                Vec3d look = Vec3d.fromPolar(0, p.getYaw());
                double s = Math.min(0.62, hs + 0.22);
                p.setVelocity(look.x * s, Math.max(v.y, 0.0) + 0.14, look.z * s);
                speed = s;
            }
            in.sneaking = false;
            set(p, Moves.DIVE);
            return;
        }
        // бег по стене
        if (!ground && airTicks > 3 && p.isSprinting() && in.movementForward > 0f && hs > 0.2 && v.y < 0.3 && v.y > -0.6) {
            double dx = v.x / hs, dzv = v.z / hs;
            World w = p.getWorld();
            if (solid(w, p.getX(), p.getY() - 0.9, p.getZ())) return;          // слишком низко над землёй
            for (int side = -1; side <= 1; side += 2) {
                if ((wallUsed & (side > 0 ? 2 : 1)) != 0) continue;
                if (!wall(p, dx, dzv, side)) continue;
                // выравниваемся вдоль стены: по той оси, вдоль которой движемся сильнее
                if (Math.abs(dx) > Math.abs(dzv)) {
                    dirX = Math.signum(dx);
                    dirZ = 0;
                } else {
                    dirX = 0;
                    dirZ = Math.signum(dzv);
                }
                if (!wall(p, dirX, dirZ, side)) continue;
                set(p, side > 0 ? Moves.WALL_R : Moves.WALL_L);
                return;
            }
        }
    }

    private static void dust(ClientPlayerEntity p) {
        BlockPos below = BlockPos.ofFloored(p.getX(), p.getY() - 0.2, p.getZ());
        var bs = p.getWorld().getBlockState(below);
        if (bs.isAir()) return;
        p.getWorld().addParticle(new BlockStateParticleEffect(ParticleTypes.BLOCK, bs), p.getX() + dirX * 0.5, p.getY() + 0.05, p.getZ() + dirZ * 0.5,
                -dirX * 0.1, 0.05, -dirZ * 0.1);
    }

    // =====================================================================================
    //                                   камера и позы
    // =====================================================================================

    /** Камера от первого лица: крен у стены, кивок в перекате. */
    public static void camera(MatrixStack m, float td) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || !c.options.getPerspective().isFirstPerson()) return;
        float t = MathHelper.lerp(td, tiltPrev, tilt);
        if (Math.abs(t) > 0.01f) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(t * 9f));
        float d = MathHelper.lerp(td, dipPrev, dip);
        if (d > 0.01f) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(d * 14f));
    }

    private static float age(LivingEntity e, float td) {
        Long since = Moves.CLIENT_SINCE.get(e.getId());
        return since == null ? 0f : Math.max(0f, e.getWorld().getTime() - since + td);
    }

    private static float smooth(float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    /** Поворот всего тела (из LivingEntityRenderer.setupTransforms, в конце). Перед — это -Z, верх — +Y, право — +X. */
    public static void transform(LivingEntity e, MatrixStack m, float td) {
        if (!(e instanceof PlayerEntity)) return;
        int k = Moves.CLIENT.getOrDefault(e.getId(), Moves.NONE);
        if (k == Moves.NONE || k == Moves.DIVE) return;
        float t = age(e, td);
        switch (k) {
            case Moves.SLIDE -> {
                float in = smooth(t / 4f);
                m.translate(0f, -0.42f * in, 0.12f * in);
                m.translate(0f, 0.7f, 0f);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(52f * in));      // откинулся назад
                m.translate(0f, -0.7f, 0f);
            }
            case Moves.ROLL -> {
                float p = smooth(t / 11f);
                m.translate(0f, 0.5f, 0f);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-360f * p));     // кувырок вперёд
                m.translate(0f, -0.62f, 0f);
            }
            case Moves.WALL_L, Moves.WALL_R -> {
                float in = smooth(t / 4f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((k == Moves.WALL_R ? 1f : -1f) * 20f * in));   // наклон от стены
            }
            default -> { }
        }
    }

    private static void stand(BipedEntityModel<?> m) {
        // поза «пригнувшись» сдвигает части модели — возвращаем как у стоящего
        m.head.pivotY = 0f;
        m.body.pivotY = 0f;
        m.body.pitch = 0f;
        m.rightArm.pivotY = 2f;
        m.leftArm.pivotY = 2f;
        m.rightLeg.pivotY = 12f;
        m.leftLeg.pivotY = 12f;
        m.rightLeg.pivotZ = 0f;
        m.leftLeg.pivotZ = 0f;
        m.rightArm.yaw = m.leftArm.yaw = 0f;
        m.rightLeg.yaw = m.leftLeg.yaw = 0f;
        m.rightLeg.roll = m.leftLeg.roll = 0f;
    }

    /** Позы рук и ног (из BipedEntityModel.setAngles, в конце). */
    public static void pose(BipedEntityModel<?> m, LivingEntity e, float animationProgress) {
        if (!(e instanceof PlayerEntity) || animationProgress == 0f) return;
        int k = Moves.CLIENT.getOrDefault(e.getId(), Moves.NONE);
        if (k == Moves.NONE) return;
        float td = MathHelper.clamp(animationProgress - e.age, 0f, 1f);
        float t = age(e, td);
        switch (k) {
            case Moves.SLIDE -> {
                stand(m);
                float in = smooth(t / 4f);
                m.rightLeg.pitch = -1.45f * in;                   // одна нога вытянута вперёд
                m.leftLeg.pitch = -0.75f * in;                    // вторая подогнута
                m.leftLeg.roll = -0.12f * in;
                m.rightArm.pitch = 0.75f * in;                    // рука сзади — опора
                m.rightArm.roll = 0.25f * in;
                m.leftArm.pitch = -0.9f * in;                     // вторая вперёд для равновесия
                m.leftArm.roll = -0.3f * in;
                m.head.pitch = -0.75f * in + m.head.pitch * (1f - in);   // смотрит вперёд, а не в небо
            }
            case Moves.DIVE -> {
                m.rightArm.pitch = -3.0f;                          // руки вытянуты вперёд
                m.leftArm.pitch = -3.0f;
                m.rightArm.roll = -0.12f;
                m.leftArm.roll = 0.12f;
                m.rightLeg.pitch = 0.12f;
                m.leftLeg.pitch = -0.08f;
            }
            case Moves.ROLL -> {
                stand(m);
                m.body.pitch = 0.5f;                               // сгруппировался
                m.head.pitch = 0.9f;
                m.rightArm.pitch = -1.3f;
                m.leftArm.pitch = -1.3f;
                m.rightArm.roll = -0.4f;
                m.leftArm.roll = 0.4f;
                m.rightLeg.pitch = -1.7f;
                m.leftLeg.pitch = -1.7f;
                m.rightLeg.pivotZ = 3f;
                m.leftLeg.pivotZ = 3f;
            }
            case Moves.WALL_L, Moves.WALL_R -> {
                boolean right = k == Moves.WALL_R;
                float run = MathHelper.sin(t * 1.3f);
                m.rightLeg.pitch = run * 1.1f;
                m.leftLeg.pitch = -run * 1.1f;
                // рука со стороны стены касается её, другая — в сторону для равновесия
                (right ? m.rightArm : m.leftArm).pitch = -0.5f;
                (right ? m.rightArm : m.leftArm).roll = right ? 1.2f : -1.2f;
                (right ? m.leftArm : m.rightArm).pitch = -run * 0.8f;
                (right ? m.leftArm : m.rightArm).roll = right ? -0.5f : 0.5f;
            }
            default -> { }
        }
        m.hat.copyTransform(m.head);
    }
}
