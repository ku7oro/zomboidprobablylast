package com.example.zomboidmod.collapse;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.ZomboidMod;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * Здания рушатся. У каждой постройки есть опора: блок держится, если стоит на земле или на том, что держится,
 * либо висит сбоку от опоры не дальше нескольких блоков. Выбил или взорвал то, на чём всё держалось, —
 * перекрытие, крыша, лестница летят вниз обломками, калеча всех, кто под ними и на них.
 * Проверяется только то, что держалось до удара: то, что и раньше «висело в воздухе» (широкие пролёты, постройки
 * игрока в обычном стиле Minecraft), не трогается.
 */
public final class Collapse {
    private Collapse() {
    }

    /** На сколько блоков вбок от опоры держится перекрытие. */
    private static final int REACH = 6;
    /** Полуразмеры проверяемой области вокруг места удара. */
    private static final int HX = 12, HY = 10;
    private static final int MAX_FALL = 420, MAX_ENTITIES = 220;
    private static final byte NONE = 0, STRUCT = 1, GROUND = 2;

    public static SoundEvent RUMBLE;
    private static final List<long[]> QUEUE = new ArrayList<>();      // {время, клетка, как падать}
    private static ServerWorld queueWorld;
    private static boolean busy;

    public static void register() {
        Identifier s = Identifier.of(ZomboidMod.MOD_ID, "collapse");
        RUMBLE = Registry.register(Registries.SOUND_EVENT, s, SoundEvent.of(s));
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (world instanceof ServerWorld w && !player.isCreative() && kind(w, pos, state) == STRUCT) removed(w, List.of(pos.toImmutable()));
        });
        ServerTickEvents.END_WORLD_TICK.register(Collapse::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(sv -> QUEUE.clear());
    }

    /** Что это за блок для расчёта: земля (держит всё), часть постройки или ничего. */
    private static byte kind(ServerWorld w, BlockPos p, BlockState st) {
        if (st.isAir() || !st.getFluidState().isEmpty()) return NONE;
        if (st.isIn(BlockTags.DIRT) || st.isIn(BlockTags.BASE_STONE_OVERWORLD) || st.isIn(BlockTags.SAND) || st.isOf(Blocks.GRAVEL)
                || st.isOf(Blocks.CLAY) || st.isOf(Blocks.DIRT_PATH) || st.isOf(Blocks.FARMLAND) || st.isOf(Blocks.SANDSTONE)
                || st.isOf(Blocks.RED_SANDSTONE) || st.isOf(Blocks.BEDROCK) || st.isOf(Blocks.SNOW_BLOCK) || st.isOf(Blocks.ICE)
                || st.isOf(Blocks.PACKED_ICE) || st.isIn(BlockTags.COAL_ORES) || st.isIn(BlockTags.IRON_ORES) || st.isIn(BlockTags.COPPER_ORES))
            return GROUND;
        if (st.getBlock() instanceof LeavesBlock) return NONE;
        if (st.getCollisionShape(w, p).isEmpty()) return NONE;        // трава, факелы, ковры, кучи вещей
        return STRUCT;
    }

    /** Эти блоки только что исчезли (сломаны, взорваны, выбиты): что теперь не на чем держаться — падает. */
    public static void removed(ServerWorld w, Collection<BlockPos> gone) {
        if (gone.isEmpty() || busy) return;
        busy = true;
        try {
            check(w, gone);
        } catch (Throwable t) {
            System.err.println("[zomboidmod] collapse check failed: " + t);
        } finally {
            busy = false;
        }
    }

    private static void check(ServerWorld w, Collection<BlockPos> gone) {
        int x0 = Integer.MAX_VALUE, y0 = Integer.MAX_VALUE, z0 = Integer.MAX_VALUE, x1 = Integer.MIN_VALUE, y1 = Integer.MIN_VALUE, z1 = Integer.MIN_VALUE;
        double cx = 0, cy = 0, cz = 0;
        for (BlockPos p : gone) {
            x0 = Math.min(x0, p.getX());
            y0 = Math.min(y0, p.getY());
            z0 = Math.min(z0, p.getZ());
            x1 = Math.max(x1, p.getX());
            y1 = Math.max(y1, p.getY());
            z1 = Math.max(z1, p.getZ());
            cx += p.getX() + 0.5;
            cy += p.getY() + 0.5;
            cz += p.getZ() + 0.5;
        }
        cx /= gone.size();
        cy /= gone.size();
        cz /= gone.size();
        if (x1 - x0 > 12 || y1 - y0 > 12 || z1 - z0 > 12) return;      // слишком большой взрыв — не считаем
        x0 -= HX;
        x1 += HX;
        z0 -= HX;
        z1 += HX;
        y0 = Math.max(w.getBottomY(), y0 - HY);
        y1 = Math.min(w.getTopY() - 1, y1 + HY);
        int nx = x1 - x0 + 1, ny = y1 - y0 + 1, nz = z1 - z0 + 1, n = nx * ny * nz;
        byte[] kind = new byte[n];
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int y = 0; y < ny; y++)
            for (int z = 0; z < nz; z++)
                for (int x = 0; x < nx; x++) {
                    m.set(x0 + x, y0 + y, z0 + z);
                    kind[(y * nz + z) * nx + x] = kind(w, m, w.getBlockState(m));
                }
        // до удара: выбитые блоки ещё на месте
        byte[] before = kind.clone();
        for (BlockPos p : gone) before[((p.getY() - y0) * nz + (p.getZ() - z0)) * nx + (p.getX() - x0)] = STRUCT;
        byte[] was = support(before, nx, ny, nz), now = support(kind, nx, ny, nz);
        List<long[]> fall = new ArrayList<>();
        for (int y = 0; y < ny; y++)
            for (int z = 0; z < nz; z++)
                for (int x = 0; x < nx; x++) {
                    int i = (y * nz + z) * nx + x;
                    if (kind[i] != STRUCT || was[i] <= 0 || now[i] > 0) continue;
                    double d = Math.sqrt((x0 + x + 0.5 - cx) * (x0 + x + 0.5 - cx) + (y0 + y + 0.5 - cy) * (y0 + y + 0.5 - cy) + (z0 + z + 0.5 - cz) * (z0 + z + 0.5 - cz));
                    fall.add(new long[]{BlockPos.asLong(x0 + x, y0 + y, z0 + z), (long) (d * 100)});
                }
        if (fall.isEmpty()) return;
        fall.sort((a, b) -> Long.compare(a[1], b[1]));
        if (fall.size() > MAX_FALL) fall = fall.subList(0, MAX_FALL);
        // рушится волной от места удара: дальние — на долю секунды позже
        long t = w.getTime();
        int entities = 0;
        if (queueWorld != w) QUEUE.clear();
        queueWorld = w;
        for (long[] f : fall) {
            boolean asEntity = entities < MAX_ENTITIES;
            if (asEntity) entities++;
            QUEUE.add(new long[]{t + 2 + f[1] / 70, f[0], asEntity ? 1 : 0});
        }
        BlockPos at = BlockPos.ofFloored(cx, cy, cz);
        if (fall.size() >= 6) {
            w.playSound(null, at, RUMBLE, SoundCategory.BLOCKS, Math.min(4f, 1.2f + fall.size() / 60f), 0.85f + w.random.nextFloat() * 0.2f);
            Noise.emitAt(w, at, Math.min(60, 20 + fall.size() / 4));
        }
        if (fall.size() >= 14) {
            for (ServerPlayerEntity p : w.getPlayers(pl -> pl.squaredDistanceTo(at.getX(), at.getY(), at.getZ()) < 28 * 28))
                p.sendMessage(Text.literal("Всё рушится!").formatted(Formatting.RED), true);
        }
    }

    /**
     * Насколько держится каждый блок: REACH — стоит на опоре до самой земли, меньше — висит сбоку (каждый блок в сторону — минус один),
     * 0 — не держится. Край области считается опорой: что там дальше, мы не знаем.
     */
    private static byte[] support(byte[] kind, int nx, int ny, int nz) {
        byte[] v = new byte[kind.length];
        @SuppressWarnings("unchecked")
        ArrayDeque<Integer>[] q = new ArrayDeque[REACH + 1];
        for (int i = 0; i <= REACH; i++) q[i] = new ArrayDeque<>();
        int layer = nx * nz;
        for (int y = 0; y < ny; y++)
            for (int z = 0; z < nz; z++)
                for (int x = 0; x < nx; x++) {
                    int i = y * layer + z * nx + x;
                    if (kind[i] != STRUCT) continue;
                    boolean edge = x == 0 || z == 0 || x == nx - 1 || z == nz - 1 || y == 0 || y == ny - 1;
                    boolean grounded = y > 0 && kind[i - layer] == GROUND;
                    if (!edge && !grounded) {                      // прислонён к земле сбоку (подвал, склон)
                        if (kind[i - 1] == GROUND || kind[i + 1] == GROUND || kind[i - nx] == GROUND || kind[i + nx] == GROUND) {
                            v[i] = REACH - 1;
                            q[REACH - 1].add(i);
                        }
                        continue;
                    }
                    v[i] = REACH;
                    q[REACH].add(i);
                }
        int[] dx = {1, -1, 0, 0}, dz = {0, 0, 1, -1};
        for (int val = REACH; val >= 1; val--) {
            ArrayDeque<Integer> cur = q[val];
            while (!cur.isEmpty()) {
                int i = cur.poll();
                if (v[i] != val) continue;
                int y = i / layer, r = i - y * layer, z = r / nx, x = r - z * nx;
                // то, что стоит сверху, держится так же
                if (y + 1 < ny) {
                    int u = i + layer;
                    if (kind[u] == STRUCT && v[u] < val) {
                        v[u] = (byte) val;
                        cur.add(u);
                    }
                }
                if (val == 1) continue;
                // сбоку (и сбоку-сверху: скаты крыш, ступени) и то, что подвешено снизу, — на единицу слабее
                for (int k = 0; k < 4; k++) {
                    int xx = x + dx[k], zz = z + dz[k];
                    if (xx < 0 || zz < 0 || xx >= nx || zz >= nz) continue;
                    for (int yy = y; yy <= y + 1 && yy < ny; yy++) {
                        int j = yy * layer + zz * nx + xx;
                        if (kind[j] == STRUCT && v[j] < val - 1) {
                            v[j] = (byte) (val - 1);
                            q[val - 1].add(j);
                        }
                    }
                }
                if (y > 0) {
                    int d = i - layer;
                    if (kind[d] == STRUCT && v[d] < val - 1) {
                        v[d] = (byte) (val - 1);
                        q[val - 1].add(d);
                    }
                }
            }
        }
        return v;
    }

    private static void tick(ServerWorld w) {
        if (QUEUE.isEmpty() || w != queueWorld) return;
        long now = w.getTime();
        int dust = 0;
        for (Iterator<long[]> it = QUEUE.iterator(); it.hasNext(); ) {
            long[] e = it.next();
            if (e[0] > now) continue;
            it.remove();
            BlockPos p = BlockPos.fromLong(e[1]);
            BlockState st = w.getBlockState(p);
            if (st.isAir() || kind(w, p, st) != STRUCT) continue;
            boolean whole = e[2] == 1 && st.isFullCube(w, p) && !st.hasBlockEntity() && w.random.nextFloat() < 0.8f;
            busy = true;                                              // сами обломки новых обрушений не запускают
            try {
                if (whole) {
                    FallingBlockEntity fb = FallingBlockEntity.spawnFromBlock(w, p, st);
                    fb.setHurtEntities(2.0f, 30);                     // обломок калечит того, на кого упал
                    fb.dropItem = false;
                } else {
                    w.breakBlock(p, st.hasBlockEntity() || w.random.nextFloat() < 0.25f);
                }
            } finally {
                busy = false;
            }
            if (dust++ < 12) w.spawnParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, p.getX() + 0.5, p.getY() + 0.3, p.getZ() + 0.5, 2, 0.4, 0.3, 0.4, 0.01);
        }
    }

    /** Взрыв рядом с постройкой: разносит стены и перекрытия в радиусе, остальное рушится само. */
    public static void blast(ServerWorld w, Vec3d at, float radius) {
        List<BlockPos> gone = new ArrayList<>();
        BlockPos c = BlockPos.ofFloored(at);
        int r = (int) Math.ceil(radius);
        busy = true;
        try {
            for (BlockPos p : BlockPos.iterate(c.add(-r, -r, -r), c.add(r, r, r))) {
                double d = Math.sqrt(p.getSquaredDistance(at.x - 0.5, at.y - 0.5, at.z - 0.5));
                if (d > radius) continue;
                BlockState st = w.getBlockState(p);
                if (kind(w, p, st) != STRUCT) continue;
                float res = st.getBlock().getBlastResistance();
                if (res > 6.5f || st.getHardness(w, p) < 0) continue;      // сталь, обсидиан, бедрок — устоят
                if (w.random.nextFloat() > 1.0 - 0.55 * (d / radius) * (d / radius)) continue;
                BlockPos q = p.toImmutable();
                w.breakBlock(q, w.random.nextFloat() < 0.2f);
                gone.add(q);
            }
        } finally {
            busy = false;
        }
        removed(w, gone);
    }
}
