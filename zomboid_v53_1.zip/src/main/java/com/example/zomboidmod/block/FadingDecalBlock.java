package com.example.zomboidmod.block;

import net.minecraft.block.BlockState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;

/** Пятно, которое со временем исчезает: капли крови подсыхают, отпечатки затираются. Дождь смывает быстрее. */
public class FadingDecalBlock extends DecalBlock {
    private final float chance;

    public FadingDecalBlock(Settings settings, float chance) {
        super(settings);
        this.chance = chance;
    }

    @Override
    protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        float c = world.hasRain(pos) ? Math.min(1f, chance * 3f) : chance;
        if (random.nextFloat() < c) world.removeBlock(pos, false);
    }
}
