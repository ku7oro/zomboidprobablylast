package com.example.zomboidmod.vehicle;

import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.ZomboidClient;
import com.example.zomboidmod.ui.Ui;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;

/**
 * Панель механики (V): схема машины сверху, у каждой детали полоска состояния. Клик по детали — описание,
 * нужные инструменты и уровень, кнопки «Снять», «Поставить», «Починить», «Разобрать на запчасти».
 */
public class MechanicsScreen extends Screen {
    private NbtCompound d;
    private int selected = CarPart.ENGINE.ordinal();
    private static final int W = 332, H = 220;
    // положение деталей на схеме (x, y, w, h) относительно левого верхнего угла схемы 120x170, перед машины сверху
    private static final int[][] BOX = new int[CarPart.values().length][];

    static {
        BOX[CarPart.ENGINE.ordinal()] = new int[]{35, 18, 50, 26};
        BOX[CarPart.BATTERY.ordinal()] = new int[]{88, 20, 20, 14};
        BOX[CarPart.HEADLIGHTS.ordinal()] = new int[]{30, 4, 60, 10};
        BOX[CarPart.WINDSHIELD.ordinal()] = new int[]{30, 50, 60, 12};
        BOX[CarPart.TIRE_FL.ordinal()] = new int[]{4, 26, 18, 30};
        BOX[CarPart.TIRE_FR.ordinal()] = new int[]{98, 26, 18, 30};
        BOX[CarPart.TIRE_RL.ordinal()] = new int[]{4, 116, 18, 30};
        BOX[CarPart.TIRE_RR.ordinal()] = new int[]{98, 116, 18, 30};
        BOX[CarPart.BRAKES.ordinal()] = new int[]{24, 66, 34, 12};
        BOX[CarPart.SUSPENSION.ordinal()] = new int[]{62, 66, 34, 12};
        BOX[CarPart.GAS_TANK.ordinal()] = new int[]{35, 120, 50, 20};
        BOX[CarPart.MUFFLER.ordinal()] = new int[]{40, 148, 40, 12};
    }

    public MechanicsScreen(NbtCompound d) {
        super(Text.literal("Механика"));
        this.d = d;
        if (d.contains("jobPart")) selected = d.getInt("jobPart");
    }

    public int vehicleId() {
        return d.getInt("id");
    }

    public void update(NbtCompound nd) {
        this.d = nd;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int cond(int i) {
        int[] c = d.getIntArray("c");
        return i < c.length ? c[i] : -2;
    }

    private static int color(int c) {
        if (c < 0) return 0xFF505050;
        if (c > 60) return 0xFF4F9A48;
        if (c > 25) return 0xFFC9A23A;
        if (c > 0) return 0xFFC0502E;
        return 0xFF7A1A14;
    }

    private int x0() {
        return (width - W) / 2;
    }

    private int y0() {
        return (height - H) / 2;
    }

    private static final String[] TEX = new String[CarPart.values().length];

    static {
        for (CarPart p : CarPart.values()) TEX[p.ordinal()] = "car_" + p.name().toLowerCase(java.util.Locale.ROOT);
    }

    /** Левый верхний угол схемы 120x170 внутри окошка-чертежа. */
    private int sx() {
        return x0() + 12;
    }

    private int sy() {
        return y0() + 30;
    }

    private int ix() {
        return x0() + 146;
    }

    private int buttonX(int i) {
        return ix() + (i % 2) * 88;
    }

    private int buttonY(int i) {
        return y0() + H - 58 + (i / 2) * 20;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int x = x0(), y = y0();
        Ui.window(ctx, textRenderer, x, y, W, H, d.getString("name") + " — механика");
        int skill = ZomboidClient.skillLevel(PzSkill.MECHANICS);
        String sk = "Механика " + skill;
        ctx.drawText(textRenderer, sk, x + W - 12 - textRenderer.getWidth(sk), y + 10, Ui.ACCENT, true);

        // чертёж: кузов тонкими линиями, детали закрашены по состоянию
        int sx = sx(), sy = sy();
        boolean bike = d.getBoolean("bike");
        Ui.blueprint(ctx, sx - 2, sy - 2, 124, 174);
        Ui.tinted(ctx, Ui.ui(bike ? "bike_base" : "car_base"), sx, sy, 120, 170, 0f, 0f, 240, 340, 240, 340, 0xB0A8CCE8);
        int hoverPart = -1;
        for (CarPart p : CarPart.values()) {
            int c = cond(p.ordinal());
            if (c == -2) continue;
            int[] b = BOX[p.ordinal()];
            int bx = sx + b[0], by = sy + b[1];
            boolean sel = p.ordinal() == selected;
            boolean hover = Ui.over(mouseX, mouseY, bx, by, b[2], b[3]);
            if (hover) hoverPart = p.ordinal();
            String t = TEX[p.ordinal()];
            if (c >= 0) Ui.tinted(ctx, Ui.ui(t + "_fill"), bx, by, b[2], b[3], 0f, 0f, b[2] * 2, b[3] * 2, b[2] * 2, b[3] * 2,
                    (color(c) & 0x00FFFFFF) | (sel || hover ? 0xD0000000 : 0xA0000000));
            int line = c < 0 ? (sel ? 0xC0E2AC48 : hover ? 0xC0FFFFFF : 0x60A8CCE8) : sel ? 0xFFFFE9B0 : hover ? 0xFFFFFFFF : 0xE0E4EEF4;
            Ui.tinted(ctx, Ui.ui(t + "_line"), bx, by, b[2], b[3], 0f, 0f, b[2] * 2, b[3] * 2, b[2] * 2, b[3] * 2, line);
            if (sel) brackets(ctx, bx - 2, by - 2, b[2] + 4, b[3] + 4, Ui.ACCENT);
        }

        // выбранная деталь
        CarPart p = CarPart.values()[selected];
        int ix = ix(), iy = y + 30, iw = W - 146 - 12;
        int c = cond(selected);
        ctx.drawText(textRenderer, p.ru, ix, iy, Ui.TEXT, true);
        iy += 12;
        if (c >= 0) {
            Ui.bar(ctx, ix, iy + 1, 100, 6, c / 100f, color(c));
            ctx.drawText(textRenderer, c + "%", ix + 106, iy, color(c), true);
        } else {
            ctx.drawText(textRenderer, c == -2 ? "нет у этого транспорта" : "снято — место пустует", ix, iy, Ui.DIM, false);
        }
        iy += 14;
        boolean tools = toolsOk(p.tools);
        ctx.drawText(textRenderer, Ui.fit(textRenderer, (tools ? "✔ " : "✘ ") + CarPart.Tools.names(p.tools), iw), ix, iy, tools ? Ui.GOOD : Ui.BAD, false);
        iy += 11;
        int req = p.req;
        ctx.drawText(textRenderer, (skill >= req ? "✔ " : "✘ ") + "навык: механика " + req, ix, iy, skill >= req ? Ui.GOOD : Ui.BAD, false);
        iy += 11;
        ctx.drawText(textRenderer, p == CarPart.ENGINE ? "Ремонт: запчасти, навык 2" : p.repairable() ? "Ремонт: изолента (до 70%)" : "Не чинится, только замена",
                ix, iy, Ui.DIM, false);
        iy += 16;

        // машина в целом
        Ui.section(ctx, textRenderer, "Состояние", ix, iy, iw);
        iy += 13;
        float body = d.getFloat("body"), charge = d.getFloat("charge");
        gauge(ctx, ix, iy, "Кузов", body, body < 0.3f ? Ui.BAD : Ui.GOOD, Math.round(body * 100) + "%");
        iy += 13;
        gauge(ctx, ix, iy, "Заряд", charge, charge < 0.15f ? Ui.BAD : 0xFF7AA8D0, Math.round(charge * 100) + "%");
        iy += 13;
        float cap = d.getFloat("cap"), fuel = d.getFloat("fuel");
        if (cap > 0) gauge(ctx, ix, iy, "Бензин", fuel / cap, fuel / cap < 0.15f ? Ui.BAD : Ui.WARN, String.format("%.0f/%.0f л", fuel, cap));
        else ctx.drawText(textRenderer, "Бензобака нет", ix, iy, Ui.DIM, false);

        // кнопки
        for (int i = 0; i < 4; i++) {
            String label = label(i, p, c);
            if (label == null) continue;
            Ui.button(ctx, textRenderer, mouseX, mouseY, buttonX(i), buttonY(i), 84, 18, label, !d.contains("jobPart"));
        }
        if (d.contains("jobPart")) ctx.drawText(textRenderer, "Идёт работа… не отходите", ix, y + H - 16, Ui.WARN, false);
        else ctx.drawText(textRenderer, "Клик по детали — выбрать", ix, y + H - 16, Ui.FAINT, false);

        if (hoverPart >= 0 && hoverPart != selected) {
            int hc = cond(hoverPart);
            Ui.note(ctx, textRenderer, mouseX, mouseY, width, height, CarPart.values()[hoverPart].ru, hc < 0 ? "снято" : "состояние " + hc + "%");
        }
    }

    /** Строка «подпись — шкала — значение». */
    private void gauge(DrawContext ctx, int x, int y, String label, float f, int color, String value) {
        ctx.drawText(textRenderer, label, x, y, Ui.DIM, false);
        Ui.bar(ctx, x + 44, y + 1, 70, 6, f, color);
        ctx.drawText(textRenderer, value, x + 120, y, Ui.TEXT, false);
    }

    /** Уголки-скобки вокруг выбранной детали. */
    private static void brackets(DrawContext ctx, int x, int y, int w, int h, int col) {
        int l = 4;
        ctx.fill(x, y, x + l, y + 1, col);
        ctx.fill(x, y, x + 1, y + l, col);
        ctx.fill(x + w - l, y, x + w, y + 1, col);
        ctx.fill(x + w - 1, y, x + w, y + l, col);
        ctx.fill(x, y + h - 1, x + l, y + h, col);
        ctx.fill(x, y + h - l, x + 1, y + h, col);
        ctx.fill(x + w - l, y + h - 1, x + w, y + h, col);
        ctx.fill(x + w - 1, y + h - l, x + w, y + h, col);
    }

    private boolean toolsOk(int mask) {
        return client != null && client.player != null && Mechanics.hasTools(client.player, mask);
    }

    /** Подписи кнопок: 0 снять, 1 поставить, 2 починить, 3 разобрать на запчасти. */
    private static String label(int i, CarPart p, int c) {
        if (c == -2) return null;
        return switch (i) {
            case 0 -> p.removable() && c >= 0 ? "Снять" : null;
            case 1 -> p.removable() && c < 0 ? "Поставить" : null;
            case 2 -> p.repairable() && c >= 0 ? "Починить" : null;
            case 3 -> p == CarPart.ENGINE && c >= 10 ? "На запчасти" : null;
            default -> null;
        };
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int sx = sx(), sy = sy();
        for (CarPart p : CarPart.values()) {
            if (cond(p.ordinal()) == -2) continue;
            int[] b = BOX[p.ordinal()];
            if (mx >= sx + b[0] && mx < sx + b[0] + b[2] && my >= sy + b[1] && my < sy + b[1] + b[3]) {
                selected = p.ordinal();
                return true;
            }
        }
        CarPart p = CarPart.values()[selected];
        int c = cond(selected);
        for (int i = 0; i < 4; i++) {
            if (label(i, p, c) == null) continue;
            int bx = buttonX(i), by = buttonY(i);
            if (mx >= bx && mx < bx + 84 && my >= by && my < by + 18) {
                int action = switch (i) {
                    case 0 -> Mechanics.UNINSTALL;
                    case 1 -> Mechanics.INSTALL;
                    case 2 -> Mechanics.REPAIR;
                    default -> Mechanics.TAKE_PARTS;
                };
                ClientPlayNetworking.send(new Mechanics.ActionPayload(vehicleId(), selected, action));
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
