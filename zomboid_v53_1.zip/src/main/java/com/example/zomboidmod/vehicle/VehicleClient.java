package com.example.zomboidmod.vehicle;

import com.example.zomboidmod.ui.Ui;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundCategory;

import java.util.HashSet;
import java.util.Set;

/** Клиент: рендер, звук мотора, гудок на пробел, приборная панель. */
public final class VehicleClient {
    private static final Set<Integer> PLAYING = new HashSet<>();
    private static boolean hornHeld;
    private static net.minecraft.client.option.KeyBinding mechKey, lightsKey;

    private VehicleClient() {
    }

    public static void init() {
        for (VehicleType t : VehicleType.values()) EntityRendererRegistry.register(t.entityType, ctx -> new VehicleRenderer(ctx, t));
        mechKey = net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(new net.minecraft.client.option.KeyBinding(
                "key.zomboidmod.mechanics", net.minecraft.client.util.InputUtil.Type.KEYSYM, org.lwjgl.glfw.GLFW.GLFW_KEY_V, "category.zomboidmod"));
        lightsKey = net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.registerKeyBinding(new net.minecraft.client.option.KeyBinding(
                "key.zomboidmod.lights", net.minecraft.client.util.InputUtil.Type.KEYSYM, org.lwjgl.glfw.GLFW.GLFW_KEY_G, "category.zomboidmod"));
        ClientPlayNetworking.registerGlobalReceiver(Mechanics.PartsPayload.ID, (payload, ctx) -> ctx.client().execute(() -> {
            if (ctx.client().currentScreen instanceof MechanicsScreen ms && ms.vehicleId() == payload.data().getInt("id")) ms.update(payload.data());
            else if (ctx.client().currentScreen == null) ctx.client().setScreen(new MechanicsScreen(payload.data()));
        }));
    }

    /** Машина, с которой работаем: та, в которой сидим, на которую смотрим, или ближайшая рядом. */
    private static VehicleEntity target(MinecraftClient c) {
        if (c.player.getVehicle() instanceof VehicleEntity v) return v;
        if (c.targetedEntity instanceof VehicleEntity v) return v;
        VehicleEntity best = null;
        double bd = 4.5 * 4.5;
        for (Entity e : c.world.getEntities()) {
            if (e instanceof VehicleEntity v && v.squaredDistanceTo(c.player) < bd) {
                bd = v.squaredDistanceTo(c.player);
                best = v;
            }
        }
        return best;
    }

    public static void tick(MinecraftClient c) {
        if (c.world == null || c.player == null) {
            PLAYING.clear();
            return;
        }
        for (Entity e : c.world.getEntities()) {
            if (e instanceof VehicleEntity v && v.engineOn() && !PLAYING.contains(v.getId()) && v.squaredDistanceTo(c.player) < 48 * 48) {
                PLAYING.add(v.getId());
                c.getSoundManager().play(new EngineSound(v));
            }
        }
        while (mechKey.wasPressed()) {
            VehicleEntity v = c.currentScreen == null ? target(c) : null;
            if (v != null) ClientPlayNetworking.send(new Mechanics.OpenPayload(v.getId()));
            else if (c.currentScreen == null) c.player.sendMessage(net.minecraft.text.Text.literal("Рядом нет машины"), true);
        }
        boolean driver = c.player.getVehicle() instanceof VehicleEntity v && v.getControllingPassenger() == c.player;
        // G: за рулём — фары, пешком — режим поиска (собирательство)
        while (lightsKey.wasPressed()) {
            if (driver) ClientPlayNetworking.send(new Mechanics.LightsPayload());
            else if (!c.player.hasVehicle() && c.currentScreen == null) com.example.zomboidmod.forage.ForageClient.toggle();
        }
        boolean down = driver && c.currentScreen == null && c.options.jumpKey.isPressed();
        if (down && !hornHeld) ClientPlayNetworking.send(new HornPayload());
        hornHeld = down;
    }

    /** Приборы: скорость, топливо, состояние. */
    public static void hud(DrawContext ctx, MinecraftClient c) {
        if (!(c.player.getVehicle() instanceof VehicleEntity v)) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int x = w / 2 - 91 - 132, y = h - 58;
        // щиток: спидометр со стрелкой, указатель топлива, три лампы
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        ctx.drawTexture(Ui.DASH, x, y, 124, 52, 0f, 0f, 248, 104, 248, 104);
        int kmh = Math.round(v.clientSpeed * 72f);
        float fuel = v.fuel() / v.type.fuelCap, hp = v.health() / v.type.maxHealth;
        Ui.needle(ctx, x + 27, y + 26, 135f + 270f * Math.min(1f, Math.abs(kmh) / 140f), 18f, 0xFFE8502E);
        String sp = String.valueOf(Math.abs(kmh));
        ctx.drawText(c.textRenderer, sp, x + 27 - c.textRenderer.getWidth(sp) / 2, y + 34, Ui.TEXT, true);
        Ui.needle(ctx, x + 72, y + 30, 160f + 220f * Math.max(0f, Math.min(1f, fuel)), 10f, fuel < 0.15f ? 0xFFE8502E : 0xFFE8E0C8);
        com.example.zomboidmod.GuiUtil.smallText(ctx, c.textRenderer, "0", x + 63, y + 35, fuel < 0.15f ? Ui.BAD : Ui.DIM);
        com.example.zomboidmod.GuiUtil.smallText(ctx, c.textRenderer, "1", x + 78, y + 35, Ui.DIM);
        com.example.zomboidmod.GuiUtil.smallText(ctx, c.textRenderer, Ui.fit(c.textRenderer, v.type.ru, 46), x + 56, y + 6, Ui.DIM);
        Ui.bar(ctx, x + 58, y + 46, 30, 2, hp, hp < 0.3f ? Ui.BAD : Ui.GOOD);
        boolean batBad = v.charge() < 0.15f || !v.clientWorking(CarPart.BATTERY);
        lamp(ctx, x + 100, y + 7, 0, batBad ? 0xFFFF4030 : 0xFF2C2C28);
        lamp(ctx, x + 100, y + 21, 1, v.lights() ? 0xFF9BE860 : 0xFF2C2C28);
        lamp(ctx, x + 100, y + 35, 2, v.broken() ? 0xFFFF4030 : hp < 0.3f ? 0xFFF0B030 : 0xFF2C2C28);
        if (!v.engineOn()) {
            String why = v.broken() ? "Кузов разбит" : (v.fuel() <= 0f ? "Нет топлива" : (!v.ignition() ? "Нет ключа — R: завести без ключа"
                    : (!v.clientWorking(CarPart.BATTERY) || v.charge() < 0.05f ? "Аккумулятор сел или снят" : "W — завести, V — механика")));
            if (!why.isEmpty()) ctx.drawText(c.textRenderer, why, x, y - 10, 0xFFD06050, true);
        }
    }

    /** Лампа на щитке: 0 аккумулятор, 1 фары, 2 двигатель. Погасшая еле видна. */
    private static void lamp(DrawContext ctx, int x, int y, int icon, int argb) {
        Ui.tinted(ctx, Ui.LAMPS, x, y, 12, 9, icon * 12f, 0f, 12, 9, 36, 9, argb);
    }

    static final class EngineSound extends MovingSoundInstance {
        private final VehicleEntity v;

        EngineSound(VehicleEntity v) {
            super(v.type.bike() ? Vehicles.ENGINE_BIKE : Vehicles.ENGINE_CAR, SoundCategory.NEUTRAL, SoundInstance.createRandom());
            this.v = v;
            this.repeat = true;
            this.repeatDelay = 0;
            this.volume = 0.6f;
            this.x = v.getX();
            this.y = v.getY();
            this.z = v.getZ();
        }

        @Override
        public void tick() {
            if (v.isRemoved() || !v.engineOn()) {
                PLAYING.remove(v.getId());
                this.setDone();
                return;
            }
            this.x = v.getX();
            this.y = v.getY();
            this.z = v.getZ();
            float s = Math.min(1f, v.clientSpeed / v.type.maxSpeed);
            this.pitch = 0.7f + s * 1.1f;
            this.volume = (0.45f + s * 0.6f) * (v.clientLoud() ? 1.6f : 1f);
        }
    }
}
