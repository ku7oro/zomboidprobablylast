package com.example.zomboidmod.mixin;

import com.example.zomboidmod.motion.CameraFx;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Камера от первого лица: своё покачивание при ходьбе и всё остальное (крен, дыхание, приземление, встряска, падение). */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
    private void zomboid$bob(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (CameraFx.bob(matrices, tickDelta)) ci.cancel();
    }

    @Inject(method = "tiltViewWhenHurt", at = @At("TAIL"))
    private void zomboid$camera(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        CameraFx.apply(matrices, tickDelta);
        com.example.zomboidmod.parkour.MovesClient.camera(matrices, tickDelta);
    }
}
