package com.example.zomboidmod.mixin;

import com.example.zomboidmod.WeaponAnim;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Хват двумя руками и замах тяжёлым оружием от третьего лица. */
@Mixin(BipedEntityModel.class)
public abstract class BipedEntityModelMixin {
    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void zomboid$weaponPose(LivingEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw,
                                    float headPitch, CallbackInfo ci) {
        com.example.zomboidmod.motion.BodyAnim.apply((BipedEntityModel<?>) (Object) this, entity, limbAngle, limbDistance, animationProgress);
        WeaponAnim.thirdPerson((BipedEntityModel<?>) (Object) this, entity, limbDistance);
        com.example.zomboidmod.parkour.ParkourClient.pose((BipedEntityModel<?>) (Object) this, entity, animationProgress);
        com.example.zomboidmod.parkour.MovesClient.pose((BipedEntityModel<?>) (Object) this, entity, animationProgress);
        com.example.zomboidmod.drag.DragClient.pose((BipedEntityModel<?>) (Object) this, entity, limbAngle, limbDistance, animationProgress);
        com.example.zomboidmod.amputation.AmputationClient.pose((BipedEntityModel<?>) (Object) this, entity);
    }
}
