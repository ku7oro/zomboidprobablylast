package com.example.zomboidmod.mixin;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Мертвец и выживший падают мёртвыми без «красной вспышки смерти» — просто падают. */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "getOverlay", at = @At("HEAD"), cancellable = true)
    private static void zomboid$noDeathRed(LivingEntity entity, float whiteOverlayProgress, CallbackInfoReturnable<Integer> cir) {
        if (entity.deathTime > 0 && (entity instanceof com.example.zomboidmod.PzZombieEntity || entity instanceof com.example.zomboidmod.survivors.SurvivorEntity)
                && com.example.zomboidmod.motion.MotionClient.falls())
            cir.setReturnValue(OverlayTexture.packUv(OverlayTexture.getU(whiteOverlayProgress), OverlayTexture.getV(false)));
    }

    /** Быстрый паркур: в подкате тело откинуто назад, в перекате кувыркается, у стены наклонено. */
    @Inject(method = "setupTransforms", at = @At("TAIL"))
    private void zomboid$moves(LivingEntity entity, net.minecraft.client.util.math.MatrixStack matrices, float animationProgress, float bodyYaw,
                               float tickDelta, float scale, org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        com.example.zomboidmod.parkour.MovesClient.transform(entity, matrices, tickDelta);
    }
}
