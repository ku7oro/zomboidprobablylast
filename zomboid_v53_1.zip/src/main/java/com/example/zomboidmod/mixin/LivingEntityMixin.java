package com.example.zomboidmod.mixin;

import com.example.zomboidmod.WeaponKinds;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Длительность взмаха зависит от оружия: кувалдой замахиваются вдвое дольше, чем ножом. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true)
    private void zomboid$swingDuration(CallbackInfoReturnable<Integer> cir) {
        int t = WeaponKinds.swingTicks(((LivingEntity) (Object) this).getMainHandStack());
        if (t > 0) cir.setReturnValue(t);
    }

    /** Перекат после нырка гасит падение. */
    @Inject(method = "computeFallDamage", at = @At("RETURN"), cancellable = true)
    private void zomboid$rollFall(float fallDistance, float damageMultiplier, CallbackInfoReturnable<Integer> cir) {
        int v = cir.getReturnValueI();
        int r = com.example.zomboidmod.parkour.Moves.fall((LivingEntity) (Object) this, fallDistance, damageMultiplier, v);
        if (r != v) cir.setReturnValue(r);
    }

    /** Свежесть еды: несвежая портит настроение, испорченная отравляет. */
    @Inject(method = "eatFood", at = @At("HEAD"))
    private void zomboid$eat(net.minecraft.world.World world, net.minecraft.item.ItemStack stack,
                             net.minecraft.component.type.FoodComponent food, CallbackInfoReturnable<net.minecraft.item.ItemStack> cir) {
        if (!world.isClient && (Object) this instanceof net.minecraft.server.network.ServerPlayerEntity p)
            com.example.zomboidmod.survival.Survival.onEat(p, stack);
    }
}
