package com.example.zomboidmod.motion;

import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.SurvivalClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Вес тела: с места человек трогается не мгновенно — разгоняется за пару шагов (дольше с грузом и без сил),
 * а останавливается сразу, без скольжения. В прыжке направление почти не сменить (но отпустил клавиши — перестал
 * толкаться); на крутом повороте на бегу теряет скорость; по ступеням вверх идёт тяжелее.
 * Сбитый с ног — не двигается, пока не встанет.
 */
public final class MoveFeel {
    private MoveFeel() {
    }

    private static float f, s;          // сглаженный ввод
    private static float lastYaw;
    private static double lastY;
    private static int climbTicks;

    /** Из ClientPlayerEntity.tickMovement сразу после опроса клавиш. */
    public static void adjust(ClientPlayerEntity p) {
        Input in = p.input;
        // без ноги и без протеза не побежишь
        int amp = com.example.zomboidmod.amputation.Amputation.CLIENT.getOrDefault(p.getId(), 0);
        int legsGone = (amp >> com.example.zomboidmod.amputation.Amputation.SHIFT_LOST) & 12;
        if (legsGone != 0 && ((amp >> com.example.zomboidmod.amputation.Amputation.SHIFT_PROS) & legsGone) != legsGone && !p.isCreative()) p.setSprinting(false);
        if (com.example.zomboidmod.drag.DragClient.dragging()) {   // тащит тяжесть: ни бегом, ни прыжком
            in.jumping = false;
            p.setSprinting(false);
        }
        // сбит с ног: лежит
        Knockdown.Down d = Knockdown.CLIENT.get(p.getId());
        long now = p.getWorld().getTime();
        if (d != null && !d.over(now)) {
            if (d.lying(now)) {
                in.movementForward = 0f;
                in.movementSideways = 0f;
                in.jumping = false;
                in.sneaking = false;
                p.setSprinting(false);
                f = s = 0f;
                return;
            }
            in.movementForward *= 0.25f;   // поднимается
            in.movementSideways *= 0.25f;
            in.jumping = false;
        }
        if (!MotionClient.inertia() || p.getAbilities().flying || p.hasVehicle() || p.isTouchingWater() || p.isClimbing() || p.isFallFlying()
                || p.isSpectator() || com.example.zomboidmod.parkour.ParkourClient.climbing(p)
                || com.example.zomboidmod.parkour.Moves.CLIENT.containsKey(p.getId())) {
            f = in.movementForward;
            s = in.movementSideways;
            lastYaw = p.getYaw();
            lastY = p.getY();
            return;
        }
        int flags = BodyAnim.FLAGS.getOrDefault(p.getId(), 0);
        int load = BodySync.load(flags), ex = Mood.exertion(SurvivalClient.endurance);
        boolean ground = p.isOnGround();
        float tf = in.movementForward, ts = in.movementSideways;

        // по ступеням и склону вверх — медленнее
        if (ground && p.getY() - lastY > 0.05) climbTicks = 6;
        else if (climbTicks > 0) climbTicks--;
        lastY = p.getY();
        if (climbTicks > 0 && !p.isCreative()) {
            tf *= 0.86f;
            ts *= 0.86f;
        }
        // разгон — с весом, торможение — сразу (никакого льда)
        float acc = 0.26f * (1f - 0.12f * load) * (1f - 0.08f * ex);
        if ((flags & (BodySync.LIMP_L_BAD | BodySync.LIMP_R_BAD)) != 0) acc *= 0.8f;
        float dec = 1f;
        if (!ground) acc = 0.08f;                                 // в прыжке направление почти не сменить
        f = approach(f, tf, acc, dec);
        s = approach(s, ts, acc * 1.1f, dec * 1.1f);
        // крутой поворот на бегу — потеря скорости
        float turn = Math.abs(MathHelper.wrapDegrees(p.getYaw() - lastYaw));
        lastYaw = p.getYaw();
        if (p.isSprinting() && ground && turn > 14f) f *= MathHelper.clamp(1f - (turn - 14f) * 0.012f, 0.6f, 1f);
        in.movementForward = f;
        in.movementSideways = s;
    }

    private static float approach(float cur, float target, float acc, float dec) {
        boolean speeding = Math.abs(target) > Math.abs(cur) && Math.signum(target) == Math.signum(cur == 0f ? target : cur);
        float rate = speeding ? acc : dec;
        if (Math.signum(target) != Math.signum(cur) && cur != 0f && target != 0f) rate = dec;   // развернулся — сразу
        float diff = target - cur;
        if (Math.abs(diff) <= rate) return target;
        return cur + Math.signum(diff) * rate;
    }
}
