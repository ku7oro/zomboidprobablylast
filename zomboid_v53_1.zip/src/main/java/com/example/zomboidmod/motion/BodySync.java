package com.example.zomboidmod.motion;

import com.example.zomboidmod.BodyPart;
import com.example.zomboidmod.PartState;
import com.example.zomboidmod.PlayerHealth;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.Weight;
import com.example.zomboidmod.WoundType;
import com.example.zomboidmod.Wounds;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.Survival;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Состояние тела для анимации: хромота, раненая рука, кровящий живот, одышка, холод, груз, опьянение.
 * Сервер раз в полсекунды рассылает его самому игроку и всем, кто его видит, — чтобы все видели, как он идёт.
 */
public final class BodySync {
    private BodySync() {
    }

    // биты состояния
    public static final int LIMP_L = 1, LIMP_L_BAD = 1 << 1, LIMP_R = 1 << 2, LIMP_R_BAD = 1 << 3, ARM_L = 1 << 4, ARM_R = 1 << 5,
            TORSO = 1 << 6, COLD = 1 << 9, DRUNK = 1 << 12, SPLINT_L = 1 << 13, SPLINT_R = 1 << 14, PAIN = 1 << 15;
    private static final int EXERT_SHIFT = 7, LOAD_SHIFT = 10;

    public static int exertion(int flags) {
        return (flags >> EXERT_SHIFT) & 3;
    }

    public static int load(int flags) {
        return (flags >> LOAD_SHIFT) & 3;
    }

    public record StatePayload(int entity, int flags) implements CustomPayload {
        public static final CustomPayload.Id<StatePayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "body_state"));
        public static final PacketCodec<RegistryByteBuf, StatePayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, StatePayload::entity, PacketCodecs.VAR_INT, StatePayload::flags, StatePayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    private static final Map<UUID, Integer> LAST = new HashMap<>();

    public static void register() {
        net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry.playS2C().register(StatePayload.ID, StatePayload.CODEC);
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(BodySync::tick);
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.DISCONNECT.register((h, s) -> LAST.remove(h.player.getUuid()));
    }

    private static void tick(MinecraftServer server) {
        if (server.getTicks() % 10 != 3) return;
        boolean full = server.getTicks() % 100 == 3;   // раз в 5 с — всем заново (кто-то только что подошёл)
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            int f = p.isAlive() && !p.isSpectator() ? compute(p) : 0;
            Integer old = LAST.put(p.getUuid(), f);
            if (!full && old != null && old == f) continue;
            StatePayload pl = new StatePayload(p.getId(), f);
            ServerPlayNetworking.send(p, pl);
            for (ServerPlayerEntity o : PlayerLookup.tracking(p)) if (o != p) ServerPlayNetworking.send(o, pl);
        }
    }

    private static boolean hurt(PartState s) {
        return s.fracture || (s.type != 0 && s.wound().rank >= 2);
    }

    private static boolean leg(PlayerHealth h, boolean left) {
        BodyPart[] parts = left ? new BodyPart[]{BodyPart.L_THIGH, BodyPart.L_SHIN, BodyPart.L_FOOT} : new BodyPart[]{BodyPart.R_THIGH, BodyPart.R_SHIN, BodyPart.R_FOOT};
        for (BodyPart b : parts) if (hurt(h.parts[b.ordinal()])) return true;
        return false;
    }

    private static boolean legBad(PlayerHealth h, boolean left) {
        BodyPart[] parts = left ? new BodyPart[]{BodyPart.L_THIGH, BodyPart.L_SHIN, BodyPart.L_FOOT} : new BodyPart[]{BodyPart.R_THIGH, BodyPart.R_SHIN, BodyPart.R_FOOT};
        for (BodyPart b : parts) {
            PartState s = h.parts[b.ordinal()];
            if ((s.fracture && !s.splinted) || s.wound() == WoundType.DEEP || s.wound() == WoundType.BITE) return true;
        }
        return false;
    }

    private static boolean splint(PlayerHealth h, boolean left) {
        BodyPart[] parts = left ? new BodyPart[]{BodyPart.L_THIGH, BodyPart.L_SHIN} : new BodyPart[]{BodyPart.R_THIGH, BodyPart.R_SHIN};
        for (BodyPart b : parts) if (h.parts[b.ordinal()].fracture && h.parts[b.ordinal()].splinted) return true;
        return false;
    }

    private static boolean arm(PlayerHealth h, boolean left) {
        BodyPart[] parts = left ? new BodyPart[]{BodyPart.L_UPPER_ARM, BodyPart.L_FOREARM, BodyPart.L_HAND}
                : new BodyPart[]{BodyPart.R_UPPER_ARM, BodyPart.R_FOREARM, BodyPart.R_HAND};
        for (BodyPart b : parts) {
            PartState s = h.parts[b.ordinal()];
            if (s.fracture || (s.type != 0 && s.wound().rank >= 3)) return true;
        }
        return false;
    }

    public static int compute(ServerPlayerEntity p) {
        int f = 0;
        if (!p.isCreative()) {
            PlayerHealth h = Wounds.health(p);
            if (leg(h, true)) f |= LIMP_L;
            if (legBad(h, true)) f |= LIMP_L_BAD;
            if (leg(h, false)) f |= LIMP_R;
            if (legBad(h, false)) f |= LIMP_R_BAD;
            if (splint(h, true)) f |= SPLINT_L;
            if (splint(h, false)) f |= SPLINT_R;
            if (arm(h, true)) f |= ARM_L;
            if (arm(h, false)) f |= ARM_R;
            for (BodyPart b : new BodyPart[]{BodyPart.UPPER_TORSO, BodyPart.LOWER_TORSO, BodyPart.GROIN})
                if (h.parts[b.ordinal()].isBleeding()) f |= TORSO;
            Mood m = Survival.mood(p);
            f |= Math.min(3, Mood.exertion(m.endurance)) << EXERT_SHIFT;
            if (Mood.hypo(m.temp) >= 2) f |= COLD;
            if (Mood.drunk(m.drunk) >= 2) f |= DRUNK;
            int load = Weight.level(Weight.carried(p) / Weight.capacity(Skills.level(p, PzSkill.STRENGTH)));
            f |= Math.min(3, load) << LOAD_SHIFT;
            if (p.getHealth() < p.getMaxHealth() * 0.4f) f |= PAIN;
        }
        // ампутации: чего нет и где протезы; без протеза рука не держит прицел, на ногу не опереться
        PlayerHealth ah = Wounds.health(p);
        f |= com.example.zomboidmod.amputation.Amputation.flags(ah);
        int bare = ah.lost & ~ah.prosthetic;
        if ((bare & 1) != 0) f |= ARM_L;
        if ((bare & 2) != 0) f |= ARM_R;
        if ((bare & 4) != 0) f |= LIMP_L | LIMP_L_BAD;
        if ((bare & 8) != 0) f |= LIMP_R | LIMP_R_BAD;
        return f;
    }
}
