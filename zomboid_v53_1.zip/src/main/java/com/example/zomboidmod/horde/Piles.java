package com.example.zomboidmod.horde;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.ZombieKind;
import com.example.zomboidmod.build.BuildState;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Живые пирамиды. Мертвецы, которые не могут добраться до жертвы — она на крыше, на втором этаже, за высокой стеной, —
 * сходятся у стены под ней и лезут друг на друга. Тела складываются в шевелящийся скат: внизу — те, кто держит,
 * выше — те, кто карабкается, наверху — тот, кто тянется к краю. Когда куча дорастает, верхние переваливаются через
 * край (или выбивают окно и лезут внутрь), а следующие ползут по спинам остальных — толпа «переливается» через стену.
 * Убить нижнего — те, кто на нём стоял, рушатся и ломают ноги. Взрыв разносит кучу.
 */
public final class Piles {
    private Piles() {
    }

    /** Выше стольких блоков куча не растёт. */
    public static final int MAX_H = 8;
    /** Толщина слоя тел, расстояние между телами вдоль ската, зазор у стены. */
    static final double LAYER = 0.95, STEP = 0.7, GAP = 0.36;
    /** Роли для отрисовки. */
    public static final int NONE = 0, HOLD = 1, REACH = 2, OVER = 3;
    static final int APPROACH = 0, ATTACHED = 1, CLIMB = 2;

    private static final List<Pile> ALL = new ArrayList<>();

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(Piles::tickWorld);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> ALL.clear());
    }

    /** Одна куча у одной стены. */
    public static final class Pile {
        final ServerWorld w;
        final BlockPos base, entry;
        final Direction face;
        final UUID target;
        final int layers, height;
        final double[][] slot;          // x, y, z
        final int[] layer, depth;
        final float[] lean;
        final PzZombieEntity[] who;
        int empty, over, blockedTries;
        boolean announced, overAnnounced, dead;

        Pile(ServerWorld w, BlockPos base, Direction face, BlockPos entry, UUID target) {
            this.w = w;
            this.base = base.toImmutable();
            this.face = face;
            this.entry = entry.toImmutable();
            this.target = target;
            this.height = entry.getY() - base.getY();
            this.layers = MathHelper.clamp((int) Math.ceil((height - 1.3) / LAYER) + 1, 2, MAX_H);
            // раскладка: слой за слоем снизу, в слое — от стены наружу; в нижнем слое по два тела в ряд
            List<double[]> s = new ArrayList<>();
            List<int[]> info = new ArrayList<>();
            List<Float> leans = new ArrayList<>();
            Direction out = face.getOpposite(), side = face.rotateYClockwise();
            double sx = base.getX() + 0.5 + face.getOffsetX() * 0.5, sz = base.getZ() + 0.5 + face.getOffsetZ() * 0.5;
            for (int L = 0; L < layers; L++) {
                int n = layers - L;
                double[] lat = L == 0 ? new double[]{-0.42, 0.42} : new double[]{0.0};
                for (int k = 0; k < n; k++) {
                    double d = GAP + k * STEP;
                    for (double l : lat) {
                        s.add(new double[]{sx + out.getOffsetX() * d + side.getOffsetX() * l, base.getY() + L * LAYER,
                                sz + out.getOffsetZ() * d + side.getOffsetZ() * l});
                        info.add(new int[]{L, k});
                        // наклон к стене: дальние лежат на скате почти плашмя, ближние прижаты к стене стоя
                        leans.add((float) Math.toDegrees(Math.asin(MathHelper.clamp((d - 0.12) / 1.6, 0.0, 0.87))));
                    }
                }
            }
            // верхний — последним
            int top = 0;
            for (int i = 0; i < info.size(); i++) if (info.get(i)[0] == layers - 1) top = i;
            double[] ts = s.remove(top);
            int[] ti = info.remove(top);
            float tl = leans.remove(top);
            s.add(ts);
            info.add(ti);
            leans.add(tl);
            slot = s.toArray(new double[0][]);
            layer = new int[slot.length];
            depth = new int[slot.length];
            lean = new float[slot.length];
            for (int i = 0; i < slot.length; i++) {
                layer[i] = info.get(i)[0];
                depth[i] = info.get(i)[1];
                lean[i] = leans.get(i);
            }
            who = new PzZombieEntity[slot.length];
        }

        int top() {
            return slot.length - 1;
        }

        /** Свободное место: сначала нижние, верхнее — только когда скат готов. -1 — мест нет. */
        int free() {
            for (int i = 0; i < top(); i++) if (who[i] == null) return i;
            return who[top()] == null ? top() : -1;
        }

        int attached() {
            int n = 0;
            for (PzZombieEntity z : who) if (z != null && z.pileState != APPROACH) n++;
            return n;
        }

        /** Куда подходить: к нижнему краю ската. */
        Vec3d foot() {
            Direction out = face.getOpposite();
            double d = GAP + layers * STEP + 0.4;
            return new Vec3d(base.getX() + 0.5 + face.getOffsetX() * 0.5 + out.getOffsetX() * d, base.getY(),
                    base.getZ() + 0.5 + face.getOffsetZ() * 0.5 + out.getOffsetZ() * d);
        }

        boolean join(PzZombieEntity z) {
            int i = free();
            if (i < 0) return false;
            who[i] = z;
            z.pile = this;
            z.pileSlot = i;
            z.pileState = APPROACH;
            z.pileT = 0;
            empty = 0;
            return true;
        }

        LivingEntity targetEntity() {
            Entity e = w.getEntity(target);
            return e instanceof LivingEntity le && le.isAlive() ? le : null;
        }
    }

    // ======================================================================= начать или присоединиться

    /** Зомби в погоне, которому не пройти к жертве: не пора ли лезть по головам. Каждые 10 тиков. */
    public static void think(PzZombieEntity z) {
        LivingEntity t = z.getTarget();
        if (t == null || !t.isAlive() || z.pile != null || z.climb != null || !z.isOnGround() || z.isCrawler() || z.isDown()
                || z.armsUsable() == 0 || z.hasVehicle() || z.isBaby() || z.kind() == ZombieKind.CARRIER) return;
        if (!(z.getWorld() instanceof ServerWorld w)) return;
        if (t instanceof ServerPlayerEntity sp && (sp.isCreative() || sp.isSpectator())) return;
        double dx = t.getX() - z.getX(), dz = t.getZ() - z.getZ(), hd = Math.sqrt(dx * dx + dz * dz), dy = t.getY() - z.getY();
        if (hd > 16) return;
        Path path = z.getNavigation().getCurrentPath();
        boolean stuck = path == null || !path.reachesTarget() || z.getNavigation().isIdle();
        if (!stuck && !(z.horizontalCollision && dy > 1.5)) return;
        if (hd < 1.5 && Math.abs(dy) < 1.5) return;
        // уже строится куча к той же жертве — туда
        Pile best = null;
        double bd = 14 * 14;
        int forTarget = 0;
        for (Pile p : ALL) {
            if (p.w != w || p.dead || !p.target.equals(t.getUuid())) continue;
            forTarget++;
            if (p.free() < 0) continue;
            double d = z.getPos().squaredDistanceTo(p.foot());
            if (d < bd) {
                bd = d;
                best = p;
            }
        }
        if (best != null) {
            best.join(z);
            return;
        }
        if (forTarget >= 2 || ALL.size() >= 32) return;
        // новая куча: стена прямо на пути к жертве
        Direction d1 = Direction.getFacing(dx, 0, dz);
        Direction d2 = Math.abs(dx) > Math.abs(dz) ? Direction.getFacing(0, 0, dz) : Direction.getFacing(dx, 0, 0);
        for (Direction d : new Direction[]{d1, d2}) {
            if (d.getAxis().isVertical()) continue;
            Pile p = scan(w, z, d, t, dy);
            if (p == null) continue;
            ALL.add(p);
            p.join(z);
            return;
        }
    }

    /** Есть ли у стены перед зомби место для кучи и куда с неё лезть. */
    private static Pile scan(ServerWorld w, PzZombieEntity z, Direction d, LivingEntity t, double dy) {
        BlockPos zp = z.getBlockPos();
        for (int i = 1; i <= 2; i++) {
            BlockPos col = zp.offset(d, i);
            if (!blocking(w, col)) {
                if (free(w, col) && free(w, col.up())) continue;   // ещё не дошёл до стены
                return null;
            }
            if (!blocking(w, col.up())) return null;           // низкая преграда: перелезет и так
            BlockPos base = col.offset(d.getOpposite());
            if (!free(w, base) || !free(w, base.up()) || free(w, base.down())) return null;
            BlockPos entry = null;
            for (int h = 2; h <= MAX_H + 1; h++) {
                BlockPos c = col.up(h);
                if (opening(w, c)) {
                    entry = c;
                    break;
                }
                if (!blocking(w, c)) return null;
            }
            if (entry == null) return null;
            int height = entry.getY() - base.getY();
            if (dy < 1.5) {
                // жертва не выше: лезут только через отдельно стоящую стену — по ту сторону должен быть обрыв вниз
                if (height > 4) return null;
                BlockPos beyond = entry.offset(d);
                if (!free(w, beyond) || !free(w, beyond.down())) return null;
            }
            return new Pile(w, base, d, entry, t.getUuid());
        }
        return null;
    }

    static boolean free(ServerWorld w, BlockPos p) {
        return w.getBlockState(p).getCollisionShape(w, p).isEmpty();
    }

    /** То, что можно выбить: окно, стекло, дверь, люк, забор, баррикада, постройка игрока. */
    static boolean breakable(ServerWorld w, BlockPos p) {
        BlockState st = w.getBlockState(p);
        return PzZombieEntity.thumpable(st) || BuildState.get(w).built.containsKey(p.asLong());
    }

    static boolean blocking(ServerWorld w, BlockPos p) {
        return !free(w, p) && !breakable(w, p);
    }

    static boolean opening(ServerWorld w, BlockPos p) {
        return free(w, p) || breakable(w, p);
    }

    // ======================================================================= член кучи

    /** Тик зомби, который состоит в куче. true — обработан, остальную логику пропустить. */
    public static boolean tickMember(PzZombieEntity z) {
        Pile p = z.pile;
        if (p == null) return false;
        LivingEntity t = p.targetEntity();
        if (p.dead || !z.isAlive() || z.isDown() || z.climb != null || t == null || z.getTarget() == null
                || !z.getTarget().getUuid().equals(p.target) || p.who[z.pileSlot] != z) {
            leave(z, true);
            return false;
        }
        z.pileT++;
        int i = z.pileSlot;
        switch (z.pileState) {
            case APPROACH -> {
                Vec3d foot = p.foot();
                double hd = Math.hypot(foot.x - z.getX(), foot.z - z.getZ());
                double toSlot = z.getPos().distanceTo(new Vec3d(p.slot[i][0], p.slot[i][1], p.slot[i][2]));
                if ((hd < 1.8 && Math.abs(z.getY() - p.base.getY()) < 1.3) || toSlot < 1.1 || nearRamp(z, p)) {
                    z.pileState = ATTACHED;
                    z.pileT = 0;
                    z.pileX = z.getX();
                    z.pileY = z.getY();
                    z.pileZ = z.getZ();
                    z.setNoGravity(true);
                    z.getNavigation().stop();
                    return true;
                }
                if (z.pileT > 240) {                         // так и не дошёл
                    leave(z, false);
                    return false;
                }
                if (z.pileT % 10 == 1) z.getNavigation().startMovingTo(foot.x, foot.y, foot.z, 1.0);
                return false;                                // идёт сам, обычным ходом
            }
            case ATTACHED -> {
                double tx = p.slot[i][0], ty = p.slot[i][1], tz = p.slot[i][2];
                double ddx = tx - z.pileX, ddy = ty - z.pileY, ddz = tz - z.pileZ, len = Math.sqrt(ddx * ddx + ddy * ddy + ddz * ddz);
                boolean moving = len > 0.02;
                if (moving) {
                    double k = Math.min(1.0, 0.13 / len);
                    z.pileX += ddx * k;
                    z.pileY += ddy * k;
                    z.pileZ += ddz * k;
                    if (z.pileT % 9 == 0) z.playSound(SoundEvents.ENTITY_ZOMBIE_STEP, 0.5f, 0.7f + z.getRandom().nextFloat() * 0.2f);
                }
                hold(z, p, moving ? (i == p.top() ? REACH : HOLD) : i == p.top() ? REACH : HOLD, p.lean[i]);
                grab(z, t);
                if (!moving && i == p.top()) tryOver(z, p);
                return true;
            }
            case CLIMB -> {
                climbOver(z, p, t);
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    /** Подошёл к скату сбоку или упёрся в стену рядом — цепляется сразу, не обходя к нижнему краю. */
    private static boolean nearRamp(PzZombieEntity z, Pile p) {
        if (Math.abs(z.getY() - p.base.getY()) > 1.3) return false;
        Direction out = p.face.getOpposite(), side = p.face.rotateYClockwise();
        double sx = p.base.getX() + 0.5 + p.face.getOffsetX() * 0.5, sz = p.base.getZ() + 0.5 + p.face.getOffsetZ() * 0.5;
        double dx = z.getX() - sx, dz = z.getZ() - sz;
        double along = dx * out.getOffsetX() + dz * out.getOffsetZ(), lat = dx * side.getOffsetX() + dz * side.getOffsetZ();
        return along > -0.2 && along < GAP + p.layers * STEP + 0.8 && Math.abs(lat) < 1.7;
    }

    /** Держать тело в точке кучи: без тяжести, лицом к стене. */
    private static void hold(PzZombieEntity z, Pile p, int role, float lean) {
        z.setNoGravity(true);
        z.getNavigation().stop();
        z.setVelocity(Vec3d.ZERO);
        z.fallDistance = 0f;
        z.setPosition(z.pileX, z.pileY, z.pileZ);
        float yaw = p.face.asRotation();
        z.setYaw(yaw);
        z.setBodyYaw(yaw);
        z.setPileLook(role, lean);
    }

    /** Жертва рядом — хватает (за ноги, за край крыши). */
    private static void grab(PzZombieEntity z, LivingEntity t) {
        if (z.pileT % 20 != (z.getId() & 0x7fffffff) % 20) return;
        if (z.squaredDistanceTo(t) > 2.7 * 2.7 || !z.canSee(t)) return;
        z.swingHand(Hand.MAIN_HAND);
        z.tryAttack(t);
    }

    /** Верхний дотянулся: перелезть, если есть куда; окно и баррикаду — выбить. */
    private static void tryOver(PzZombieEntity z, Pile p) {
        BlockPos e = p.entry, in = e.offset(p.face);
        if (!free(p.w, e)) {
            if (z.pileT % 20 == 0 && !z.bash(e)) p.blockedTries++;
            return;
        }
        if (!free(p.w, e.up()) && !free(p.w, in)) {
            if (z.pileT % 20 == 0 && !z.bash(e.up())) p.blockedTries++;
            return;
        }
        Vec3d land = landing(p);
        if (land == null) {
            p.blockedTries++;
            return;
        }
        z.pileState = CLIMB;
        z.pileT = 0;
        z.pileSX = z.pileX;
        z.pileSY = z.pileY;
        z.pileSZ = z.pileZ;
        z.playSound(SoundEvents.ENTITY_ZOMBIE_AMBIENT, 1.0f, 0.75f);
    }

    /** Куда встать за краем: внутрь окна или на верх стены (крышу). */
    private static Vec3d landing(Pile p) {
        BlockPos e = p.entry, in = e.offset(p.face);
        if (free(p.w, in) && free(p.w, in.up()) && !free(p.w, in.down())) return Vec3d.ofBottomCenter(in);
        if (free(p.w, e) && free(p.w, e.up())) return Vec3d.ofBottomCenter(e);
        if (free(p.w, in) && free(p.w, in.up())) return Vec3d.ofBottomCenter(in);   // по ту сторону обрыв — спрыгнет
        return null;
    }

    private static void climbOver(PzZombieEntity z, Pile p, LivingEntity t) {
        Vec3d land = landing(p);
        if (land == null) {
            z.pileState = ATTACHED;
            z.pileT = 0;
            return;
        }
        Direction out = p.face.getOpposite();
        Vec3d edge = new Vec3d(p.entry.getX() + 0.5 + out.getOffsetX() * 0.75, p.entry.getY() + 0.15, p.entry.getZ() + 0.5 + out.getOffsetZ() * 0.75);
        float u = z.pileT / 16f;
        Vec3d at;
        if (u < 0.55f) {
            float k = smooth(u / 0.55f);
            at = new Vec3d(MathHelper.lerp(k, z.pileSX, edge.x), MathHelper.lerp(k, z.pileSY, edge.y), MathHelper.lerp(k, z.pileSZ, edge.z));
        } else {
            float k = smooth(Math.min(1f, (u - 0.55f) / 0.45f));
            at = edge.lerp(land, k);
        }
        z.pileX = at.x;
        z.pileY = at.y;
        z.pileZ = at.z;
        hold(z, p, OVER, u < 0.55f ? 25f : 50f * (1f - u));
        if (z.pileT == 6) z.playSound(SoundEvents.ENTITY_ZOMBIE_STEP, 0.9f, 0.6f);
        if (u < 1f) return;
        // перелез
        p.over++;
        p.who[z.pileSlot] = null;
        release(z);
        z.setPosition(land.x, land.y, land.z);
        if (!p.overAnnounced && t instanceof ServerPlayerEntity sp) {
            p.overAnnounced = true;
            sp.sendMessage(Text.literal("Мертвецы перелезли!").formatted(Formatting.DARK_RED), true);
        }
    }

    private static float smooth(float x) {
        return x * x * (3f - 2f * x);
    }

    private static void release(PzZombieEntity z) {
        z.pile = null;
        z.pileState = APPROACH;
        z.setNoGravity(false);
        z.setPileLook(NONE, 0f);
    }

    /** Ушёл из кучи. collapse — если держал кого-то, те, кто на нём стоял, падают. */
    public static void leave(PzZombieEntity z, boolean collapse) {
        Pile p = z.pile;
        if (p == null) return;
        int i = z.pileSlot;
        boolean held = z.pileState == ATTACHED;
        if (i >= 0 && i < p.who.length && p.who[i] == z) p.who[i] = null;
        release(z);
        if (!collapse || !held) return;
        // кто стоял на нём — летит вниз (и тянет за собой тех, кто стоял на них)
        for (int j = 0; j < p.who.length; j++) {
            PzZombieEntity o = p.who[j];
            if (o == null || o.pileState == APPROACH || p.layer[j] <= p.layer[i] || Math.abs(p.depth[j] - p.depth[i]) > 1) continue;
            tumble(o, p);
        }
    }

    /** Сорвался с кучи. */
    private static void tumble(PzZombieEntity o, Pile p) {
        Direction out = p.face.getOpposite();
        leave(o, true);
        o.setVelocity(out.getOffsetX() * 0.18 + (o.getRandom().nextDouble() - 0.5) * 0.15, 0.1,
                out.getOffsetZ() * 0.18 + (o.getRandom().nextDouble() - 0.5) * 0.15);
        o.velocityModified = true;
        o.knockDown(30 + o.getRandom().nextInt(25), o.getRandom().nextBoolean());
        o.playSound(SoundEvents.ENTITY_PLAYER_BIG_FALL, 0.9f, 0.7f);
    }

    /** Разошлись: жертва ушла или умерла. Висящие наверху падают. */
    private static void disperse(Pile p) {
        p.dead = true;
        for (int j = p.who.length - 1; j >= 0; j--) {
            PzZombieEntity o = p.who[j];
            if (o == null) continue;
            if (o.pileState != APPROACH && p.layer[j] > 0) tumble(o, p);
            else {
                p.who[j] = null;
                release(o);
            }
        }
    }

    // ======================================================================= мир

    private static void tickWorld(ServerWorld w) {
        if (ALL.isEmpty()) return;
        long now = w.getTime();
        for (Iterator<Pile> it = ALL.iterator(); it.hasNext(); ) {
            Pile p = it.next();
            if (p.w != w) continue;
            for (int j = 0; j < p.who.length; j++) {
                PzZombieEntity o = p.who[j];
                if (o != null && (o.isRemoved() || o.pile != p)) p.who[j] = null;   // выгружен или ушёл
            }
            LivingEntity t = p.targetEntity();
            boolean lost = t == null || t.squaredDistanceTo(Vec3d.ofBottomCenter(p.base)) > 30 * 30
                    || (t instanceof ServerPlayerEntity sp && (sp.isCreative() || sp.isSpectator()));
            if (lost || p.blockedTries > 6) {
                disperse(p);
                it.remove();
                continue;
            }
            int n = p.attached();
            boolean any = false;
            for (PzZombieEntity o : p.who) any |= o != null;
            if (!any) {
                if (++p.empty > 120) {
                    p.dead = true;
                    it.remove();
                }
                continue;
            }
            // стон кучи слышно далеко — подтягиваются другие
            if (n >= 3 && (now + p.base.hashCode()) % 50 == 0) {
                w.playSound(null, p.base, SoundEvents.ENTITY_ZOMBIE_AMBIENT, SoundCategory.HOSTILE, 1.6f, 0.55f + w.random.nextFloat() * 0.15f);
                Noise.emitAt(w, p.base, 22);
            }
            if (!p.announced && n >= 4 && t instanceof ServerPlayerEntity sp) {
                p.announced = true;
                sp.sendMessage(Text.literal("Мертвецы лезут друг на друга!").formatted(Formatting.RED), true);
            }
        }
    }
}
