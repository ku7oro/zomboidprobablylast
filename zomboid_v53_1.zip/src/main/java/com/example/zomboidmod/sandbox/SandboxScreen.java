package com.example.zomboidmod.sandbox;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Окно настроек мира: наборы (как в PZ) и отдельные параметры. Клик — следующий вариант, Shift+клик — предыдущий. */
public class SandboxScreen extends Screen {
    private final int[] v;
    private final boolean edit, first;
    private boolean sent;
    private final List<ButtonWidget> valueButtons = new ArrayList<>();

    public SandboxScreen(NbtCompound data) {
        super(Text.literal("Настройки мира"));
        this.v = Sandbox.sanitize(data.getIntArray("v"));
        this.edit = data.getBoolean("edit");
        this.first = data.getBoolean("first");
    }

    private static final int ROWS = (Sandbox.OPTS.length + 1) / 2;

    private int colW() {
        return Math.min(214, (this.width - 24) / 2);
    }

    private int rowH() {
        return Math.max(20, Math.min(25, (this.height - 128) / ROWS));
    }

    private int top() {
        int total = 58 + rowH() * ROWS + 34;
        return Math.max(6, (this.height - total) / 2);
    }

    @Override
    protected void init() {
        valueButtons.clear();
        int cw = colW(), x0 = (this.width - cw * 2 - 8) / 2, y0 = top();
        // наборы
        int pw = Math.min(84, (cw * 2 + 8 - 4 * 4) / 5);
        int px = (this.width - (pw * 5 + 16)) / 2;
        for (int i = 0; i < Sandbox.PRESETS.length; i++) {
            Sandbox.Preset pr = Sandbox.PRESETS[i];
            ButtonWidget b = com.example.zomboidmod.ui.PzButton.create(Text.literal(pr.name()), w -> {
                System.arraycopy(pr.v(), 0, v, 0, v.length);
                refresh();
            }).dimensions(px + i * (pw + 4), y0 + 16, pw, 20).build();
            b.setTooltip(Tooltip.of(Text.literal(pr.desc())));
            b.active = edit;
            addDrawableChild(b);
        }
        // параметры: две колонки по 6
        int rh = rowH(), bw = Math.min(104, cw / 2);
        for (int i = 0; i < Sandbox.OPTS.length; i++) {
            final int idx = i;
            Sandbox.Opt o = Sandbox.OPTS[i];
            int col = i / ROWS, row = i % ROWS;
            int bx = x0 + col * (cw + 8) + cw - bw, by = y0 + 58 + row * rh;
            ButtonWidget b = com.example.zomboidmod.ui.PzButton.create(Text.literal(o.values()[v[i]]), w -> {
                int n = o.values().length;
                v[idx] = Math.floorMod(v[idx] + (Screen.hasShiftDown() ? -1 : 1), n);
                refresh();
            }).dimensions(bx, by, bw, 20).build();
            b.setTooltip(Tooltip.of(Text.literal(o.hint())));
            b.active = edit;
            valueButtons.add(addDrawableChild(b));
        }
        int by = y0 + 58 + rh * ROWS + 8;
        if (edit) {
            addDrawableChild(com.example.zomboidmod.ui.PzButton.create(Text.literal(first ? "Начать" : "Применить"), w -> send(true))
                    .dimensions(this.width / 2 - 104, by, 100, 20).build());
            addDrawableChild(com.example.zomboidmod.ui.PzButton.create(Text.literal(first ? "По умолчанию" : "Отмена"), w -> {
                if (first) {
                    System.arraycopy(Sandbox.defaults(), 0, v, 0, v.length);
                    refresh();
                } else close();
            }).dimensions(this.width / 2 + 4, by, 100, 20).build());
        } else {
            addDrawableChild(com.example.zomboidmod.ui.PzButton.create(Text.literal("Закрыть"), w -> close()).dimensions(this.width / 2 - 50, by, 100, 20).build());
        }
    }

    private void refresh() {
        for (int i = 0; i < valueButtons.size(); i++) valueButtons.get(i).setMessage(Text.literal(Sandbox.OPTS[i].values()[v[i]]));
    }

    private void send(boolean apply) {
        if (sent) return;
        sent = true;
        NbtCompound n = new NbtCompound();
        n.putIntArray("v", v.clone());
        n.putBoolean("apply", apply);
        ClientPlayNetworking.send(new Sandbox.ApplyPayload(n));
        super.close();
    }

    @Override
    public void close() {
        // в первый раз закрытие окна — согласие с выбранным (иначе мир так и останется ненастроенным)
        if (first && edit) send(true);
        else super.close();
    }

    @Override
    public boolean shouldPause() {
        return true;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderBackground(ctx, mouseX, mouseY, delta);
        int pw = colW() * 2 + 8 + 28, px = (this.width - pw) / 2, py = Math.max(2, top() - 8);
        com.example.zomboidmod.ui.Ui.panel(ctx, px, py, pw, this.height - py - 2);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int cw = colW(), x0 = (this.width - cw * 2 - 8) / 2, y0 = top(), rh = rowH();
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(first ? "Настройте мир (песочница)" : "Настройки мира (песочница)")
                .formatted(Formatting.BOLD), this.width / 2, y0 + 2, 0xFFE8D8B0);
        String preset = Sandbox.presetName(v);
        Text sub = Text.literal("Набор: " + preset + (edit ? "" : "   (менять может хозяин мира или оператор)"));
        ctx.drawCenteredTextWithShadow(textRenderer, sub, this.width / 2, y0 + 41, preset.equals("Свой") ? 0xFFC8B070 : 0xFF9FD08A);
        int bw = Math.min(104, cw / 2);
        for (int i = 0; i < Sandbox.OPTS.length; i++) {
            int col = i / ROWS, row = i % ROWS;
            int lx = x0 + col * (cw + 8), ly = y0 + 58 + row * rh + 6;
            String t = Sandbox.OPTS[i].title();
            List<OrderedText> lines = textRenderer.wrapLines(Text.literal(t), cw - bw - 6);
            ctx.drawTextWithShadow(textRenderer, lines.isEmpty() ? Text.literal(t).asOrderedText() : lines.get(0), lx, ly, 0xFFDDDDDD);
        }
        if (edit) ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Клик — следующий вариант, Shift+клик — предыдущий. Позже: команда /sandbox")
                .formatted(Formatting.DARK_GRAY), this.width / 2, y0 + 58 + rh * ROWS + 32, 0xFF888888);
    }
}
