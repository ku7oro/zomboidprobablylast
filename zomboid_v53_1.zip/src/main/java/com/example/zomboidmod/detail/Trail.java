package com.example.zomboidmod.detail;

import net.minecraft.registry.RegistryKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Кровавый след раненого: капли и отпечатки подошв. Мертвец без жертвы, наткнувшись на след,
 * идёт по нему от старых капель к свежим — то есть прямо к тому, кто истекает кровью.
 */
public final class Trail {
    private Trail() {
    }

    /** Сколько живёт запах следа (5 минут). */
    public static final long LIFE = 6000;
    private static final int CAP = 1500;

    public record Pt(BlockPos pos, long t) {
    }

    private static final Map<RegistryKey<World>, ArrayDeque<Pt>> TRAILS = new HashMap<>();

    public static void add(ServerWorld w, BlockPos pos) {
        ArrayDeque<Pt> q = TRAILS.computeIfAbsent(w.getRegistryKey(), k -> new ArrayDeque<>());
        Pt last = q.peekLast();
        long now = w.getTime();
        if (last != null && last.pos.equals(pos) && now - last.t < 40) return;
        q.addLast(new Pt(pos.toImmutable(), now));
        while (q.size() > CAP) q.removeFirst();
    }

    /** Есть ли в мире хоть какой-то свежий след (чтобы мертвецы зря не искали). */
    public static boolean any(ServerWorld w) {
        ArrayDeque<Pt> q = TRAILS.get(w.getRegistryKey());
        if (q == null || q.isEmpty()) return false;
        long now = w.getTime();
        while (!q.isEmpty() && now - q.peekFirst().t > LIFE) q.removeFirst();
        return !q.isEmpty();
    }

    /**
     * Самая свежая точка следа в радиусе r, которая новее after. В out[0] — её время.
     * Мертвец идёт к ней, потом ищет следующую, ещё свежее, и так шаг за шагом.
     */
    public static BlockPos follow(ServerWorld w, Vec3d at, long after, double r, long[] out) {
        ArrayDeque<Pt> q = TRAILS.get(w.getRegistryKey());
        if (q == null) return null;
        long now = w.getTime();
        double r2 = r * r;
        Pt best = null;
        for (Iterator<Pt> it = q.descendingIterator(); it.hasNext(); ) {
            Pt p = it.next();
            if (p.t <= after || now - p.t > LIFE) break;      // дальше только старее
            double dx = p.pos.getX() + 0.5 - at.x, dy = p.pos.getY() - at.y, dz = p.pos.getZ() + 0.5 - at.z;
            if (dx * dx + dz * dz <= r2 && Math.abs(dy) < 5) {
                best = p;
                break;
            }
        }
        if (best == null) return null;
        out[0] = best.t;
        return best.pos;
    }
}
