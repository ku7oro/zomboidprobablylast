package com.example.zomboidmod.detail;

import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;

/**
 * Стреляная гильза: маленький цилиндр (рисуется коробочкой), кувыркается в полёте, отскакивает от пола
 * со звоном, катится и минуту лежит там, где упала.
 */
public class CasingParticle extends SpriteBillboardParticle {
    private final int kind;
    private final float radius, half;
    private float yawR, pitchR, rollR, spinYaw, spinPitch, spinRoll;
    private float pYaw, pPitch, pRoll;
    private int bounces;
    private boolean settled;

    public CasingParticle(ClientWorld world, double x, double y, double z, double vx, double vy, double vz, Sprite sprite, int kind) {
        super(world, x, y, z);
        this.setSprite(sprite);
        this.kind = kind;
        this.velocityX = vx;
        this.velocityY = vy;
        this.velocityZ = vz;
        this.collidesWithWorld = true;
        this.gravityStrength = 0f;
        this.maxAge = 1200 + this.random.nextInt(300);
        // размеры в блоках (1 блок = 1 метр, гильзы чуть крупнее настоящих, иначе их не разглядеть)
        switch (kind) {
            case Details.C_SHELL -> { radius = 0.028f; half = 0.05f; }
            case Details.C_RIFLE -> { radius = 0.016f; half = 0.045f; }
            case Details.C_MAGNUM -> { radius = 0.018f; half = 0.032f; }
            default -> { radius = 0.016f; half = 0.025f; }
        }
        this.setBoundingBoxSpacing(radius * 2.4f, radius * 2.4f);
        this.yawR = this.random.nextFloat() * MathHelper.TAU;
        this.pitchR = this.random.nextFloat() * MathHelper.TAU;
        this.spinYaw = (this.random.nextFloat() - 0.5f) * 0.9f;
        this.spinPitch = 0.5f + this.random.nextFloat() * 0.6f;
        this.pYaw = yawR;
        this.pPitch = pitchR;
    }

    @Override
    public ParticleTextureSheet getType() {
        return ParticleTextureSheet.PARTICLE_SHEET_OPAQUE;
    }

    @Override
    public void tick() {
        this.prevPosX = this.x;
        this.prevPosY = this.y;
        this.prevPosZ = this.z;
        pYaw = yawR;
        pPitch = pitchR;
        pRoll = rollR;
        if (this.age++ >= this.maxAge) {
            this.markDead();
            return;
        }
        if (settled) {
            // пол под гильзой исчез — снова падает
            if (this.age % 10 == 0 && !blocked(0, -0.03, 0)) settled = false;
            else return;
        }
        this.velocityY -= 0.045;
        double vx = this.velocityX, vy = this.velocityY, vz = this.velocityZ;
        Vec3d want = new Vec3d(vx, vy, vz);
        Vec3d got = Entity.adjustMovementForCollisions(null, want, this.getBoundingBox(), this.world, List.of());
        if (got.lengthSquared() > 0) {
            this.setBoundingBox(this.getBoundingBox().offset(got));
            this.repositionFromBoundingBox();
        }
        boolean hitX = Math.abs(got.x - vx) > 1e-7, hitY = Math.abs(got.y - vy) > 1e-7, hitZ = Math.abs(got.z - vz) > 1e-7;
        if (hitX) this.velocityX = -vx * 0.3;
        if (hitZ) this.velocityZ = -vz * 0.3;
        boolean ground = hitY && vy < 0;
        if (ground) {
            if (vy < -0.09 && bounces < 4) {
                // отскок со звоном: каждый следующий ниже и тише
                this.velocityY = -vy * (0.32 + this.random.nextFloat() * 0.12);
                this.velocityX *= 0.55;
                this.velocityZ *= 0.55;
                spinPitch = (this.random.nextFloat() - 0.5f) * 1.2f;
                spinYaw = (this.random.nextFloat() - 0.5f) * 0.8f;
                clink((float) Math.min(1.0, -vy * 3.0), bounces);
                bounces++;
            } else {
                if (bounces == 0) clink(0.35f, 3);
                this.velocityY = 0;
                // ложится на бок и катится поперёк своей оси
                pitchR = MathHelper.lerp(0.5f, pitchR, nearestSide(pitchR));
                spinPitch = 0;
                spinYaw *= 0.6f;
                double sp = Math.sqrt(this.velocityX * this.velocityX + this.velocityZ * this.velocityZ);
                spinRoll = (float) (sp / radius) * 0.5f;
                this.velocityX *= 0.72;
                this.velocityZ *= 0.72;
                if (sp < 0.004) {
                    settled = true;
                    pitchR = nearestSide(pitchR);
                    this.velocityX = this.velocityZ = 0;
                }
            }
        } else if (hitY) {
            this.velocityY = 0;                                  // ударилась о потолок
        } else {
            this.velocityX *= 0.985;
            this.velocityZ *= 0.985;
        }
        yawR += spinYaw;
        pitchR += spinPitch;
        rollR += spinRoll;
    }

    /** Ближайший наклон, при котором ось гильзы горизонтальна (лежит на боку). */
    private static float nearestSide(float a) {
        return Math.round(a / MathHelper.PI) * MathHelper.PI;
    }

    private boolean blocked(double dx, double dy, double dz) {
        Vec3d want = new Vec3d(dx, dy, dz);
        Vec3d got = Entity.adjustMovementForCollisions(null, want, this.getBoundingBox(), this.world, List.of());
        return got.squaredDistanceTo(want) > 1e-9;
    }

    private void clink(float strength, int n) {
        float vol = (kind == Details.C_SHELL ? 0.45f : 0.38f) * Math.max(0.15f, strength) * (n == 0 ? 1f : 0.7f);
        float pitch = (kind == Details.C_SHELL ? 1f : kind == Details.C_RIFLE ? 0.92f : 1.06f) * (0.9f + this.random.nextFloat() * 0.2f);
        this.world.playSound(this.x, this.y, this.z, kind == Details.C_SHELL ? Details.SHELL_SND : Details.CASING_SND,
                SoundCategory.PLAYERS, vol, pitch, false);
    }

    // ===================================== рисование =====================================

    @Override
    public void buildGeometry(VertexConsumer vc, Camera camera, float tickDelta) {
        Vec3d cam = camera.getPos();
        float px = (float) (MathHelper.lerp(tickDelta, this.prevPosX, this.x) - cam.x);
        float py = (float) (MathHelper.lerp(tickDelta, this.prevPosY, this.y) - cam.y) + radius;
        float pz = (float) (MathHelper.lerp(tickDelta, this.prevPosZ, this.z) - cam.z);
        float k = 1f;
        int left = this.maxAge - this.age;
        if (left < 20) k = Math.max(0.05f, left / 20f);              // под конец тихо исчезает
        float r = radius * k, l = half * k;
        Quaternionf q = new Quaternionf().rotateY(MathHelper.lerp(tickDelta, pYaw, yawR))
                .rotateX(MathHelper.lerp(tickDelta, pPitch, pitchR))
                .rotateZ(MathHelper.lerp(tickDelta, pRoll, rollR));
        int light = this.getBrightness(tickDelta);
        float u0 = this.getMinU(), u1 = this.getMaxU(), v0 = this.getMinV(), v1 = this.getMaxV();
        float vRow = (v1 - v0) / 16f;
        // ось гильзы — локальная Z: дульце на +Z, донце на -Z; бока — латунь по всей длине
        Vector3f[] c = new Vector3f[8];
        for (int i = 0; i < 8; i++) {
            Vector3f v = new Vector3f((i & 1) == 0 ? -r : r, (i & 2) == 0 ? -r : r, (i & 4) == 0 ? -l : l);
            q.transform(v);
            c[i] = v.add(px, py, pz);
        }
        // боковые грани: u поперёк, v вдоль (верхний ряд текстуры — тёмное нутро, он только на торце)
        side(vc, c[0], c[1], c[5], c[4], u0, u1, v0 + vRow, v1, light, q, 0, -1, 0);
        side(vc, c[2], c[3], c[7], c[6], u0, u1, v0 + vRow, v1, light, q, 0, 1, 0);
        side(vc, c[0], c[2], c[6], c[4], u0, u1, v0 + vRow, v1, light, q, -1, 0, 0);
        side(vc, c[1], c[3], c[7], c[5], u0, u1, v0 + vRow, v1, light, q, 1, 0, 0);
        // торцы: дульце тёмное (верхний ряд), донце — нижний ряд
        side(vc, c[4], c[5], c[7], c[6], u0, u1, v0, v0 + vRow, light, q, 0, 0, 1);
        side(vc, c[0], c[1], c[3], c[2], u0, u1, v1 - vRow, v1, light, q, 0, 0, -1);
    }

    /**
     * Грань из четырёх углов. Вершины a,b у донца/мутных краёв, c,d — у дульца; рисуем с обеих сторон,
     * чтобы не думать о порядке обхода. Затенение — по тому, куда смотрит грань (у частиц нет нормалей).
     */
    private void side(VertexConsumer vc, Vector3f a, Vector3f b, Vector3f c, Vector3f d, float u0, float u1, float v0, float v1,
                      int light, Quaternionf q, float nx, float ny, float nz) {
        Vector3f n = q.transform(new Vector3f(nx, ny, nz));
        float shade = 0.62f + 0.38f * (n.y * 0.5f + 0.5f) - 0.06f * Math.abs(n.x);
        float rr = this.red * shade, gg = this.green * shade, bb = this.blue * shade;
        // a,b — у одного края (v1), d,c — у другого (v0)
        put(vc, a, u0, v1, rr, gg, bb, light);
        put(vc, b, u1, v1, rr, gg, bb, light);
        put(vc, c, u1, v0, rr, gg, bb, light);
        put(vc, d, u0, v0, rr, gg, bb, light);
        put(vc, d, u0, v0, rr, gg, bb, light);
        put(vc, c, u1, v0, rr, gg, bb, light);
        put(vc, b, u1, v1, rr, gg, bb, light);
        put(vc, a, u0, v1, rr, gg, bb, light);
    }

    private static void put(VertexConsumer vc, Vector3f p, float u, float v, float r, float g, float b, int light) {
        vc.vertex(p.x, p.y, p.z).texture(u, v).color(r, g, b, 1f).light(light);
    }
}
