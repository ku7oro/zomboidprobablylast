package com.example.zomboidmod.detail;

import com.example.zomboidmod.PzAxeItem;
import com.example.zomboidmod.PzWeaponItem;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.block.ZomboidBlocks;
import com.example.zomboidmod.nature.Climate;
import com.example.zomboidmod.survival.SurvivalClient;
import com.example.zomboidmod.survivors.SurvivorEntity;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.item.ModelPredicateProviderRegistry;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Клиентская часть мелочей: гильзы, дыры, трещины, пар изо рта, вид окровавленного оружия. */
public final class DetailsClient {
    private DetailsClient() {
    }

    private static SpriteProvider casings, holes, cracks;

    /** Гильзы, которые вылетят чуть позже (после передёргивания затвора или помпы). */
    private record Pending(int entity, int kind, int mode, int at) {
    }

    private static final List<Pending> PENDING = new ArrayList<>();
    private static int clientTicks;

    public static void init() {
        ParticleFactoryRegistry reg = ParticleFactoryRegistry.getInstance();
        reg.register(Details.BREATH, sprites -> (type, world, x, y, z, vx, vy, vz) -> new BreathParticle(world, x, y, z, vx, vy, vz, sprites));
        // гильзы и наклейки создаются прямо из пакетов; фабрики нужны, чтобы спрайты попали в атлас частиц
        reg.register(Details.CASING, sprites -> {
            casings = sprites;
            return (type, world, x, y, z, vx, vy, vz) -> new CasingParticle(world, x, y, z, vx, vy, vz, sprites.getSprite(0, 3), Details.C_PISTOL);
        });
        reg.register(Details.HOLE, sprites -> {
            holes = sprites;
            return (type, world, x, y, z, vx, vy, vz) -> new DecalParticle(world, new Vec3d(x, y, z), Direction.UP, BlockPos.ofFloored(x, y - 0.5, z),
                    sprites.getSprite(world.random), 0.06f, 3000, 0.95f);
        });
        reg.register(Details.CRACK, sprites -> {
            cracks = sprites;
            return (type, world, x, y, z, vx, vy, vz) -> new DecalParticle(world, new Vec3d(x, y, z), Direction.UP, BlockPos.ofFloored(x, y - 0.5, z),
                    sprites.getSprite(world.random), 0.3f, 24000, 0.85f);
        });

        ClientPlayNetworking.registerGlobalReceiver(Details.ShotPayload.ID, (pl, ctx) -> ctx.client().execute(() -> shot(ctx.client(), pl)));
        ClientPlayNetworking.registerGlobalReceiver(Details.ImpactPayload.ID, (pl, ctx) -> ctx.client().execute(() -> impact(ctx.client(), pl)));
        ClientTickEvents.END_CLIENT_TICK.register(DetailsClient::tick);

        BlockRenderLayerMap.INSTANCE.putBlock(ZomboidBlocks.BLOOD_DROPS, RenderLayer.getTranslucent());
        BlockRenderLayerMap.INSTANCE.putBlock(ZomboidBlocks.BLOOD_PRINT, RenderLayer.getTranslucent());

        // кровь на оружии: три стадии модели
        Identifier blood = Identifier.of(ZomboidMod.MOD_ID, "blood");
        for (Item it : Registries.ITEM) {
            if (it instanceof PzWeaponItem || it instanceof PzAxeItem)
                ModelPredicateProviderRegistry.register(it, blood, (st, world, entity, seed) -> WeaponBlood.level(st) / 3f);
        }
    }

    // =====================================================================================
    //                                      гильзы
    // =====================================================================================

    private static void shot(MinecraftClient mc, Details.ShotPayload pl) {
        if (mc.world == null) return;
        if (pl.mode() == Details.M_LATE) {
            PENDING.add(new Pending(pl.entity(), pl.kind(), Details.M_EJECT, clientTicks + 7));
            return;
        }
        for (int i = 0; i < pl.count(); i++) {
            if (i == 0 || pl.mode() == Details.M_POP) eject(mc, pl.entity(), pl.kind(), pl.mode(), i);
            else PENDING.add(new Pending(pl.entity(), pl.kind(), pl.mode(), clientTicks + i));   // из барабана сыплются по одной
        }
    }

    private static void eject(MinecraftClient mc, int entityId, int kind, int mode, int index) {
        ClientWorld w = mc.world;
        if (w == null || casings == null) return;
        Entity e = w.getEntityById(entityId);
        if (e == null) return;
        Random r = w.random;
        Vec3d look = e.getRotationVec(1f);
        Vec3d right = Vec3d.fromPolar(0, e.getYaw() + 90f);
        boolean firstPerson = e == mc.player && mc.options.getPerspective().isFirstPerson();
        Vec3d eye = e.getEyePos();
        Vec3d pos, vel;
        switch (mode) {
            case Details.M_DUMP -> {                       // открыл барабан: гильзы падают вниз
                pos = eye.add(look.multiply(0.35)).add(right.multiply(0.05)).add(0, -0.35, 0);
                vel = new Vec3d((r.nextFloat() - 0.5) * 0.04, -0.02 - r.nextFloat() * 0.03, (r.nextFloat() - 0.5) * 0.04);
            }
            case Details.M_POP -> {                        // переломил ствол: экстрактор выбрасывает назад и вверх
                pos = eye.add(look.multiply(0.3)).add(right.multiply(0.08 + 0.05 * index)).add(0, -0.3, 0);
                vel = look.multiply(-0.07).add(0, 0.13 + r.nextFloat() * 0.04, 0).add(right.multiply((r.nextFloat() - 0.3) * 0.05));
            }
            default -> {                                   // окно затвора справа: вбок, чуть вверх и назад
                double fwd = firstPerson ? 0.5 : 0.6, side = firstPerson ? 0.2 : 0.28, down = firstPerson ? 0.17 : 0.24;
                pos = eye.add(look.multiply(fwd)).add(right.multiply(side)).add(0, -down, 0);
                double s = kind == Details.C_SHELL ? 0.09 : 0.12;
                vel = right.multiply(s + r.nextFloat() * 0.04).add(0, 0.09 + r.nextFloat() * 0.05, 0)
                        .add(look.multiply(-0.02 - r.nextFloat() * 0.02));
            }
        }
        vel = vel.add(e.getVelocity().multiply(0.8, 0.3, 0.8));
        mc.particleManager.addParticle(new CasingParticle(w, pos.x, pos.y, pos.z, vel.x, vel.y, vel.z, casings.getSprite(kind, 3), kind));
    }

    // =====================================================================================
    //                                 дыры и трещины
    // =====================================================================================

    private static void impact(MinecraftClient mc, Details.ImpactPayload pl) {
        ClientWorld w = mc.world;
        if (w == null) return;
        Direction face = Direction.byId(pl.face());
        BlockPos pos = BlockPos.fromLong(pl.pos());
        Vec3d hit = new Vec3d(pl.x(), pl.y(), pl.z());
        if (pl.kind() == Details.I_CRACK) {
            if (cracks == null) return;
            mc.particleManager.addParticle(new DecalParticle(w, hit, face, pos, cracks.getSprite(w.random), 0.32f + w.random.nextFloat() * 0.08f, 24000, 0.85f));
        } else {
            if (holes == null || w.getBlockState(pos).isAir()) return;
            mc.particleManager.addParticle(new DecalParticle(w, hit, face, pos, holes.getSprite(w.random), 0.055f + w.random.nextFloat() * 0.02f, 3600, 0.95f));
        }
    }

    // =====================================================================================
    //                                  пар изо рта
    // =====================================================================================

    private static void tick(MinecraftClient mc) {
        clientTicks++;
        if (mc.world == null || mc.isPaused()) {
            if (mc.world == null) PENDING.clear();
            return;
        }
        for (Iterator<Pending> it = PENDING.iterator(); it.hasNext(); ) {
            Pending p = it.next();
            if (clientTicks >= p.at) {
                it.remove();
                eject(mc, p.entity, p.kind, p.mode, 1);
            }
        }
        breath(mc);
    }

    private static void breath(MinecraftClient mc) {
        ClientWorld w = mc.world;
        if (mc.player == null || mc.cameraEntity == null) return;
        long time = w.getTime();
        Vec3d cam = mc.cameraEntity.getPos();
        for (Entity e : w.getEntities()) {
            if (!(e instanceof PlayerEntity) && !(e instanceof SurvivorEntity)) continue;   // у мертвецов пара нет
            LivingEntity le = (LivingEntity) e;
            if (!le.isAlive() || le.isInvisible() || le.isSpectator() || le.isSubmergedInWater()) continue;
            if (le.squaredDistanceTo(cam) > 40 * 40) continue;
            boolean self = e == mc.player;
            boolean puffing = le.isSprinting() || (self && SurvivalClient.endurance < 0.6f);
            int period = puffing ? 22 : 64;
            if ((time + e.getId() * 37L) % period != 0) continue;
            float t = Climate.tempAt(w, le.getBlockPos());
            if (t > 6f) continue;
            int n = t < -10f ? 5 : t < 0f ? 4 : 3;
            if (puffing) n++;
            Vec3d look = le.getRotationVec(1f);
            boolean fp = self && mc.options.getPerspective().isFirstPerson();
            Vec3d mouth = le.getEyePos().add(look.multiply(fp ? 0.32 : 0.22)).add(0, fp ? -0.16 : -0.12, 0);
            Vec3d v = le.getVelocity();
            for (int i = 0; i < n; i++) {
                double s = 0.025 + w.random.nextFloat() * 0.02;
                w.addParticle(Details.BREATH, mouth.x, mouth.y, mouth.z,
                        look.x * s + v.x * 0.8 + (w.random.nextFloat() - 0.5) * 0.01,
                        look.y * s * 0.5 - 0.004 + (w.random.nextFloat() - 0.5) * 0.008,
                        look.z * s + v.z * 0.8 + (w.random.nextFloat() - 0.5) * 0.01);
            }
        }
    }
}
