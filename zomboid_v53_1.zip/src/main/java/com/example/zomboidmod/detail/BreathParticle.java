package com.example.zomboidmod.detail;

import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;

/** Облачко пара изо рта на морозе: вылетает вперёд, расплывается, поднимается и тает за секунду-две. */
public class BreathParticle extends SpriteBillboardParticle {
    private final float startScale, endScale, startAlpha;

    public BreathParticle(ClientWorld world, double x, double y, double z, double vx, double vy, double vz, SpriteProvider sprites) {
        super(world, x, y, z);
        this.setSprite(sprites.getSprite(this.random));
        this.velocityX = vx;
        this.velocityY = vy;
        this.velocityZ = vz;
        this.velocityMultiplier = 0.9f;
        this.gravityStrength = -0.006f;                            // тёплый пар чуть всплывает
        this.collidesWithWorld = true;
        this.maxAge = 22 + this.random.nextInt(18);
        this.startScale = 0.05f + this.random.nextFloat() * 0.03f;
        this.endScale = 0.22f + this.random.nextFloat() * 0.12f;
        this.scale = startScale;
        float g = 0.88f + this.random.nextFloat() * 0.1f;
        this.red = g;
        this.green = g;
        this.blue = Math.min(1f, g + 0.03f);
        this.startAlpha = 0.28f + this.random.nextFloat() * 0.12f;
        this.alpha = startAlpha;
        this.angle = this.random.nextFloat() * 6.28f;
        this.prevAngle = this.angle;
    }

    @Override
    public ParticleTextureSheet getType() {
        return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public void tick() {
        super.tick();
        float k = (float) this.age / this.maxAge;
        this.scale = startScale + (endScale - startScale) * (float) Math.sqrt(k);
        this.alpha = startAlpha * (1f - k) * (1f - k * 0.3f);
        this.prevAngle = this.angle;
        this.angle += 0.01f;
    }
}
