package com.example.zomboidmod.detail;

import com.example.zomboidmod.PzAxeItem;
import com.example.zomboidmod.PzWeaponItem;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * Кровь на холодном оружии. Каждый удар по живому (и мёртвому) пачкает клинок или биту, убийство — сильнее.
 * Три стадии видны и в руке, и на иконке. Смывается дождём и водой, оттирается тряпкой.
 */
public final class WeaponBlood {
    private WeaponBlood() {
    }

    public static final int MAX = 14;
    private static final String KEY = "pzBlood";

    public static boolean bloodable(ItemStack st) {
        return !st.isEmpty() && (st.getItem() instanceof PzWeaponItem || st.getItem() instanceof PzAxeItem);
    }

    public static int get(ItemStack st) {
        NbtComponent c = st.get(DataComponentTypes.CUSTOM_DATA);
        return c == null || !c.contains(KEY) ? 0 : c.copyNbt().getInt(KEY);
    }

    public static void set(ItemStack st, int v) {
        int x = Math.max(0, Math.min(MAX, v));
        if (x == get(st)) return;
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, st, nbt -> {
            if (x <= 0) nbt.remove(KEY);
            else nbt.putInt(KEY, x);
        });
    }

    /** 0 — чистое, 1 — брызги, 2 — в крови, 3 — всё залито. */
    public static int level(ItemStack st) {
        int v = get(st);
        return v <= 0 ? 0 : v < 4 ? 1 : v < 9 ? 2 : 3;
    }

    /** Удар по телу: кровь остаётся на оружии; добивающий удар пачкает сильнее. */
    public static void hit(ItemStack st, LivingEntity target) {
        if (!bloodable(st) || target == null || target.getWorld().isClient || target instanceof ArmorStandEntity) return;
        boolean kill = target.isDead() || target.getHealth() <= 0f;
        set(st, get(st) + (kill ? 3 : 1));
    }

    public static void tooltip(ItemStack st, List<Text> tooltip) {
        int l = level(st);
        if (l == 0) return;
        tooltip.add(Text.literal(l == 1 ? "Забрызгано кровью" : l == 2 ? "В крови" : "Всё в запёкшейся крови").formatted(Formatting.DARK_RED));
        tooltip.add(Text.literal("Смоется дождём или водой. Shift+ПКМ с тряпкой во второй руке — оттереть").formatted(Formatting.DARK_GRAY));
    }
}
