package com.example.zomboidmod.detail;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

/**
 * Плоская наклейка на грани блока: выщербина от пули или паутина трещин на стекле.
 * Держится, пока цел блок, на который она легла; под конец жизни бледнеет.
 */
public class DecalParticle extends SpriteBillboardParticle {
    private final BlockPos attached;
    private final Block block;
    private final Vector3f center, ax, bx;
    private final float baseAlpha;

    public DecalParticle(ClientWorld world, Vec3d hit, Direction face, BlockPos attached, Sprite sprite, float size, int life, float alpha) {
        super(world, hit.x, hit.y, hit.z);
        this.setSprite(sprite);
        this.attached = attached;
        BlockState bs = world.getBlockState(attached);
        this.block = bs.getBlock();
        this.maxAge = life;
        this.baseAlpha = alpha;
        this.alpha = alpha;
        this.gravityStrength = 0f;
        this.collidesWithWorld = false;
        this.velocityX = this.velocityY = this.velocityZ = 0;

        Vector3f n = new Vector3f(face.getOffsetX(), face.getOffsetY(), face.getOffsetZ());
        Vector3f a, b;
        if (face.getAxis() == Direction.Axis.Y) {
            a = new Vector3f(1, 0, 0);
            b = new Vector3f(0, 0, 1);
        } else if (face.getAxis() == Direction.Axis.X) {
            a = new Vector3f(0, 0, 1);
            b = new Vector3f(0, 1, 0);
        } else {
            a = new Vector3f(1, 0, 0);
            b = new Vector3f(0, 1, 0);
        }
        // каждая наклейка повёрнута по-своему, чтобы одинаковые дырки не бросались в глаза
        float t = this.random.nextFloat() * MathHelper.TAU;
        float cs = MathHelper.cos(t), sn = MathHelper.sin(t);
        this.ax = new Vector3f(a).mul(cs).add(new Vector3f(b).mul(sn)).mul(size);
        this.bx = new Vector3f(b).mul(cs).sub(new Vector3f(a).mul(sn)).mul(size);

        // не даём наклейке свешиваться с края полного блока
        double cx = hit.x, cy = hit.y, cz = hit.z;
        if (bs.isFullCube(world, attached)) {
            double m = size * 1.05;
            if (face.getAxis() != Direction.Axis.X) cx = MathHelper.clamp(cx, attached.getX() + m, attached.getX() + 1 - m);
            if (face.getAxis() != Direction.Axis.Y) cy = MathHelper.clamp(cy, attached.getY() + m, attached.getY() + 1 - m);
            if (face.getAxis() != Direction.Axis.Z) cz = MathHelper.clamp(cz, attached.getZ() + m, attached.getZ() + 1 - m);
        }
        this.center = new Vector3f((float) cx, (float) cy, (float) cz).add(n.mul(0.006f + this.random.nextFloat() * 0.003f));
        this.setPos(center.x, center.y, center.z);
        this.prevPosX = this.x;
        this.prevPosY = this.y;
        this.prevPosZ = this.z;
    }

    @Override
    public ParticleTextureSheet getType() {
        return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public void tick() {
        if (this.age++ >= this.maxAge) {
            this.markDead();
            return;
        }
        if (this.age % 20 == 0 && !this.world.getBlockState(attached).isOf(block)) {
            this.markDead();                                       // блок разбили или заменили
            return;
        }
        int left = this.maxAge - this.age;
        this.alpha = left < 200 ? baseAlpha * left / 200f : baseAlpha;
    }

    @Override
    public void buildGeometry(VertexConsumer vc, Camera camera, float tickDelta) {
        Vec3d cam = camera.getPos();
        float x = (float) (center.x - cam.x), y = (float) (center.y - cam.y), z = (float) (center.z - cam.z);
        int light = this.getBrightness(tickDelta);
        float u0 = this.getMinU(), u1 = this.getMaxU(), v0 = this.getMinV(), v1 = this.getMaxV();
        float[][] p = {
                {x - ax.x - bx.x, y - ax.y - bx.y, z - ax.z - bx.z, u0, v1},
                {x + ax.x - bx.x, y + ax.y - bx.y, z + ax.z - bx.z, u1, v1},
                {x + ax.x + bx.x, y + ax.y + bx.y, z + ax.z + bx.z, u1, v0},
                {x - ax.x + bx.x, y - ax.y + bx.y, z - ax.z + bx.z, u0, v0}};
        // с обеих сторон: стекло видно и изнутри дома
        for (int i = 0; i < 4; i++) put(vc, p[i], light);
        for (int i = 3; i >= 0; i--) put(vc, p[i], light);
    }

    private void put(VertexConsumer vc, float[] q, int light) {
        vc.vertex(q[0], q[1], q[2]).texture(q[3], q[4]).color(this.red, this.green, this.blue, this.alpha).light(light);
    }
}
