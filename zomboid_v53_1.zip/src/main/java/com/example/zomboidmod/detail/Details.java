package com.example.zomboidmod.detail;

import com.example.zomboidmod.PlayerHealth;
import com.example.zomboidmod.Wounds;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.block.DecalBlock;
import com.example.zomboidmod.block.ZomboidBlocks;
import com.example.zomboidmod.gun.GunItem;
import com.example.zomboidmod.gun.Guns;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PaneBlock;
import net.minecraft.block.TransparentBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Мелочи, из которых складывается мир: гильзы, дыры от пуль и трещины в стёклах, кровь на оружии,
 * капли и кровавые отпечатки за раненым (по ним идут мертвецы). Пар изо рта — на клиенте.
 */
public final class Details {
    private Details() {
    }

    public static SimpleParticleType CASING, BREATH, HOLE, CRACK;
    public static SoundEvent CASING_SND, SHELL_SND, GLASS_CRACK;

    /** Какая гильза: пистолетная, винтовочная, револьверная (никель), дробовая (пластик). */
    public static final int C_PISTOL = 0, C_RIFLE = 1, C_MAGNUM = 2, C_SHELL = 3;
    /** Как вылетает: сразу вбок, с задержкой (затвор, помпа), высыпаются из барабана, выскакивают из ствола. */
    public static final int M_EJECT = 0, M_LATE = 1, M_DUMP = 2, M_POP = 3;
    /** Попадание: дыра в стене, трещина в стекле. */
    public static final int I_HOLE = 0, I_CRACK = 1;

    public record ShotPayload(int entity, int kind, int count, int mode) implements CustomPayload {
        public static final CustomPayload.Id<ShotPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "shot_fx"));
        public static final PacketCodec<RegistryByteBuf, ShotPayload> CODEC = PacketCodec.tuple(PacketCodecs.VAR_INT, ShotPayload::entity,
                PacketCodecs.VAR_INT, ShotPayload::kind, PacketCodecs.VAR_INT, ShotPayload::count, PacketCodecs.VAR_INT, ShotPayload::mode, ShotPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public record ImpactPayload(double x, double y, double z, int face, int kind, long pos) implements CustomPayload {
        public static final CustomPayload.Id<ImpactPayload> ID = new CustomPayload.Id<>(Identifier.of(ZomboidMod.MOD_ID, "impact_fx"));
        public static final PacketCodec<RegistryByteBuf, ImpactPayload> CODEC = PacketCodec.tuple(PacketCodecs.DOUBLE, ImpactPayload::x,
                PacketCodecs.DOUBLE, ImpactPayload::y, PacketCodecs.DOUBLE, ImpactPayload::z, PacketCodecs.VAR_INT, ImpactPayload::face,
                PacketCodecs.VAR_INT, ImpactPayload::kind, PacketCodecs.VAR_LONG, ImpactPayload::pos, ImpactPayload::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    private static SimpleParticleType particle(String id) {
        return Registry.register(Registries.PARTICLE_TYPE, Identifier.of(ZomboidMod.MOD_ID, id), FabricParticleTypes.simple(true));
    }

    private static SoundEvent sound(String id) {
        Identifier i = Identifier.of(ZomboidMod.MOD_ID, id);
        return Registry.register(Registries.SOUND_EVENT, i, SoundEvent.of(i));
    }

    public static void register() {
        CASING = particle("casing");
        BREATH = particle("breath");
        HOLE = particle("bullet_hole");
        CRACK = particle("glass_crack");
        CASING_SND = sound("casing");
        SHELL_SND = sound("shell_drop");
        GLASS_CRACK = sound("glass_crack");
        PayloadTypeRegistry.playS2C().register(ShotPayload.ID, ShotPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ImpactPayload.ID, ImpactPayload.CODEC);
        ServerTickEvents.END_WORLD_TICK.register(Details::tickWorld);
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack st = player.getStackInHand(hand);
            if (wipe(player, hand)) return TypedActionResult.success(st, world.isClient);
            return TypedActionResult.pass(ItemStack.EMPTY);
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> wipe(player, hand) ? ActionResult.success(world.isClient) : ActionResult.PASS);
    }

    // =====================================================================================
    //                                    гильзы
    // =====================================================================================

    public static int casingOf(GunItem g) {
        Item a = g.ammo.get();
        if (a == Guns.SHOTGUN_SHELLS) return C_SHELL;
        if (a == Guns.AMMO_357) return C_MAGNUM;
        if (a == Guns.AMMO_556 || a == Guns.RIFLE_ROUNDS) return C_RIFLE;
        return C_PISTOL;
    }

    /** Выстрел или перезарядка: клиенты сами выбрасывают гильзы, они прыгают по полу и звенят. */
    public static void shot(ServerWorld w, Entity shooter, GunItem g, int count, int mode) {
        if (count <= 0) return;
        ShotPayload pl = new ShotPayload(shooter.getId(), casingOf(g), Math.min(count, 8), mode);
        for (ServerPlayerEntity sp : PlayerLookup.tracking(shooter)) if (ServerPlayNetworking.canSend(sp, ShotPayload.ID)) ServerPlayNetworking.send(sp, pl);
        if (shooter instanceof ServerPlayerEntity self && ServerPlayNetworking.canSend(self, ShotPayload.ID)) ServerPlayNetworking.send(self, pl);
    }

    /** Когда этот ствол выбрасывает гильзу при выстреле: сразу или после передёргивания затвора/помпы. */
    public static int ejectMode(GunItem.Action a) {
        return a == GunItem.Action.BOLT_MANUAL || a == GunItem.Action.PUMP ? M_LATE : M_EJECT;
    }

    // =====================================================================================
    //                            дыры от пуль, трещины в стекле
    // =====================================================================================

    private static final Map<RegistryKey<World>, Map<Long, Long>> CRACKED = new HashMap<>();

    public static boolean glass(BlockState bs) {
        return (bs.getBlock() instanceof PaneBlock && !bs.isOf(Blocks.IRON_BARS)) || bs.getBlock() instanceof TransparentBlock;
    }

    /**
     * Пуля попала в блок. Стекло от первого попадания трескается паутиной, от второго — бьётся.
     * В остальном остаётся выщербина. Возвращает true, если стекло разбилось.
     */
    public static boolean impact(ServerWorld w, BlockHitResult bh, BlockState bs) {
        BlockPos pos = bh.getBlockPos();
        Vec3d hp = bh.getPos();
        if (glass(bs)) {
            Map<Long, Long> m = CRACKED.computeIfAbsent(w.getRegistryKey(), k -> new HashMap<>());
            long now = w.getTime();
            if (m.size() > 4000) m.values().removeIf(t -> now - t > 24000);
            Long was = m.get(pos.asLong());
            if (was != null && now - was < 24000) {
                m.remove(pos.asLong());
                w.breakBlock(pos, false);
                com.example.zomboidmod.parkour.Parkour.shatter(w, pos, bs);
                return true;
            }
            m.put(pos.asLong(), now);
            w.playSound(null, hp.x, hp.y, hp.z, GLASS_CRACK, SoundCategory.BLOCKS, 1.0f, 0.9f + w.random.nextFloat() * 0.2f);
            send(w, new ImpactPayload(hp.x, hp.y, hp.z, bh.getSide().getId(), I_CRACK, pos.asLong()));
            return false;
        }
        if (bs.isAir() || bs.getCollisionShape(w, pos).isEmpty()) return false;
        send(w, new ImpactPayload(hp.x, hp.y, hp.z, bh.getSide().getId(), I_HOLE, pos.asLong()));
        return false;
    }

    private static void send(ServerWorld w, ImpactPayload pl) {
        BlockPos at = BlockPos.ofFloored(pl.x(), pl.y(), pl.z());
        for (ServerPlayerEntity sp : PlayerLookup.around(w, at, 72)) if (ServerPlayNetworking.canSend(sp, ImpactPayload.ID)) ServerPlayNetworking.send(sp, pl);
    }

    // =====================================================================================
    //                         капли крови, отпечатки, мытьё оружия
    // =====================================================================================

    private static final class Steps {
        int left;
        double lx, lz;
        boolean leftFoot;
        BlockPos last = BlockPos.ORIGIN;
    }

    private static final Map<UUID, Steps> STEPS = new HashMap<>();

    private static void tickWorld(ServerWorld w) {
        long t = w.getTime();
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (p.isSpectator() || p.isCreative() || !p.isAlive()) continue;
            if (t % 2 == 0) prints(w, p);
            if (t % 20 == (p.getId() & 15)) {
                drip(w, p);
                wash(w, p);
            }
        }
        if (t % 1200 == 0) STEPS.keySet().removeIf(id -> w.getServer().getPlayerManager().getPlayer(id) == null);
    }

    /** Раненый без повязки роняет капли. Чем сильнее кровотечение, тем чаще. */
    private static void drip(ServerWorld w, ServerPlayerEntity p) {
        PlayerHealth h = Wounds.health(p);
        if (h == null || h.bleedLevel <= 0) return;
        float chance = h.bleedLevel == 1 ? 0.18f : h.bleedLevel == 2 ? 0.4f : 0.85f;
        if (w.random.nextFloat() > chance) return;
        Vec3d at = new Vec3d(p.getX(), p.getY() + 0.9, p.getZ());
        com.example.zomboidmod.combat.Combat.gore(w, at, 2, 0.02);
        BlockPos feet = p.getBlockPos();
        place(w, feet, ZomboidBlocks.BLOOD_DROPS, w.random.nextInt(4), Direction.Type.HORIZONTAL.random(w.random));
        Trail.add(w, feet);
    }

    /** Наступил в лужу крови — несколько шагов оставляет отпечатки подошв, левый-правый. */
    private static void prints(ServerWorld w, ServerPlayerEntity p) {
        if (ZomboidBlocks.BLOOD_PRINT == null) return;
        Steps s = STEPS.computeIfAbsent(p.getUuid(), k -> new Steps());
        BlockPos feet = p.getBlockPos();
        if (p.isOnGround() && w.getBlockState(feet).isOf(ZomboidBlocks.BLOOD)) {
            if (s.left <= 0) {
                s.lx = p.getX();
                s.lz = p.getZ();
            }
            s.left = 9;
            return;
        }
        if (s.left <= 0 || !p.isOnGround() || p.isTouchingWater()) return;
        double dx = p.getX() - s.lx, dz = p.getZ() - s.lz;
        if (dx * dx + dz * dz < 0.8 * 0.8) return;
        s.lx = p.getX();
        s.lz = p.getZ();
        s.leftFoot = !s.leftFoot;
        s.left--;
        if (feet.equals(s.last)) return;
        s.last = feet.toImmutable();
        Direction dir = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? Direction.EAST : Direction.WEST) : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
        int variant = (s.leftFoot ? 0 : 1) + (s.left <= 3 ? 2 : 0);
        if (place(w, feet, ZomboidBlocks.BLOOD_PRINT, variant, dir)) Trail.add(w, feet);
    }

    private static boolean place(ServerWorld w, BlockPos at, Block b, int variant, Direction facing) {
        if (b == null) return false;
        BlockState here = w.getBlockState(at);
        if (!here.isAir()) return false;
        if (!w.getBlockState(at.down()).isSideSolidFullSquare(w, at.down(), Direction.UP)) return false;
        w.setBlockState(at, b.getDefaultState().with(DecalBlock.VARIANT, variant).with(DecalBlock.FACING, facing));
        return true;
    }

    /** Дождь понемногу смывает кровь с того, что в руках; в воде она сходит быстро. */
    private static void wash(ServerWorld w, ServerPlayerEntity p) {
        boolean water = p.isTouchingWater();
        boolean rain = !water && w.hasRain(BlockPos.ofFloored(p.getX(), p.getEyeY(), p.getZ()));
        if (!water && !rain) return;
        for (Hand hand : Hand.values()) {
            ItemStack st = p.getStackInHand(hand);
            int b = WeaponBlood.get(st);
            if (b <= 0) continue;
            if (water) WeaponBlood.set(st, b - 3);
            else if (w.random.nextInt(4) == 0) WeaponBlood.set(st, b - 1);
        }
    }

    /** Shift+ПКМ оружием в крови, когда во второй руке тряпка: оттереть. */
    private static boolean wipe(PlayerEntity p, Hand hand) {
        if (hand != Hand.MAIN_HAND || !p.isSneaking()) return false;
        ItemStack st = p.getMainHandStack();
        if (WeaponBlood.get(st) <= 0 || !p.getOffHandStack().isOf(ZomboidMod.RAG)) return false;
        if (!p.getWorld().isClient) {
            WeaponBlood.set(st, 0);
            Random r = p.getRandom();
            p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ITEM_ARMOR_EQUIP_LEATHER.value(), SoundCategory.PLAYERS, 0.8f, 0.8f + r.nextFloat() * 0.3f);
            if (r.nextFloat() < 0.35f && !p.isCreative()) {
                p.getOffHandStack().decrement(1);
                p.sendMessage(Text.literal("Оттёр кровь. Тряпку пришлось выбросить").formatted(Formatting.GRAY), true);
            } else p.sendMessage(Text.literal("Оттёр кровь").formatted(Formatting.GRAY), true);
        }
        return true;
    }
}
