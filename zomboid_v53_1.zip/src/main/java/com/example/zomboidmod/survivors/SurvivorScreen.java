package com.example.zomboidmod.survivors;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Разговор с выжившим: кто он, как к тебе относится, что можно сделать. */
public class SurvivorScreen extends Screen {
    final int entity;
    private NbtCompound info;
    private static final int W = 300;

    public SurvivorScreen(int entity, NbtCompound info) {
        super(Text.literal(info.getString("name")));
        this.entity = entity;
        this.info = info;
    }

    void update(NbtCompound info) {
        this.info = info;
        clearAndInit();
    }

    private record B(String label, int action) {
    }

    private List<B> buttons() {
        List<B> l = new ArrayList<>();
        int role = info.getInt("role");
        boolean grudge = info.getBoolean("grudge");
        if (role == SurvivorEntity.BANDIT) {
            if (!info.getBoolean("calm")) l.add(new B("Откупиться тем, что в руке", Survivors.A_PAY));
            l.add(new B("Попробовать заговорить", Survivors.A_TALK));
            return l;
        }
        l.add(new B("Поговорить", Survivors.A_TALK));
        if (grudge) return l;
        l.add(new B("Дать то, что в руке (еда, бинт)", Survivors.A_GIVE));
        if (role == SurvivorEntity.TRADER) l.add(new B("Торговать", Survivors.A_TRADE));
        if (info.getBoolean("mine")) {
            l.add(new B("За мной", Survivors.A_FOLLOW));
            l.add(new B("Жди здесь", Survivors.A_WAIT));
            l.add(new B("Охраняй это место", Survivors.A_GUARD));
            l.add(new B("Отдать оружие из руки", Survivors.A_WEAPON));
            if (info.getBoolean("gun")) l.add(new B("Отдать патроны", Survivors.A_AMMO));
            l.add(new B("Отпустить", Survivors.A_DISMISS));
        } else if (!info.getBoolean("follower") && role == SurvivorEntity.NEUTRAL) {
            l.add(new B("Позвать с собой", Survivors.A_RECRUIT));
        }
        return l;
    }

    private int top() {
        return Math.max(10, this.height / 2 - 110);
    }

    @Override
    protected void init() {
        List<B> bs = buttons();
        int x0 = (this.width - W) / 2, y = top() + 92;
        int bw = (W - 30) / 2;
        for (int i = 0; i < bs.size(); i++) {
            B b = bs.get(i);
            int bx = x0 + 10 + (i % 2) * (bw + 10), by = y + (i / 2) * 22;
            addDrawableChild(com.example.zomboidmod.ui.PzButton.create(Text.literal(b.label()), w ->
                    ClientPlayNetworking.send(new Survivors.ActionPayload(entity, b.action()))).dimensions(bx, by, bw, 20).build());
        }
        int by = y + ((bs.size() + 1) / 2) * 22 + 6;
        addDrawableChild(com.example.zomboidmod.ui.PzButton.create(Text.literal("Уйти"), w -> close()).dimensions(x0 + W / 2 - 50, by, 100, 20).build());
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderBackground(ctx, mouseX, mouseY, delta);
        int rows0 = (buttons().size() + 1) / 2;
        com.example.zomboidmod.ui.Ui.panel(ctx, (this.width - W) / 2 - 6, top() - 6, W + 12, 92 + rows0 * 22 + 33 + 12);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int x0 = (this.width - W) / 2, y0 = top();
        int rows = (buttons().size() + 1) / 2;
        int role = info.getInt("role");
        String kind = role == SurvivorEntity.BANDIT ? "Бандит" : role == SurvivorEntity.TRADER ? "Торговец"
                : info.getBoolean("mine") ? "Ваш напарник" : info.getBoolean("follower") ? "Чужой напарник" : "Выживший";
        int col = role == SurvivorEntity.BANDIT ? 0xFF6060 : role == SurvivorEntity.TRADER ? 0xFFC040 : info.getBoolean("mine") ? 0x70E070 : 0xFFE070;
        ctx.drawTextWithShadow(this.textRenderer, info.getString("name") + " — " + kind, x0 + 8, y0 + 6, col);
        float hp = info.getFloat("hp"), max = Math.max(1f, info.getFloat("maxHp"));
        String status = String.format("Здоровье %d%%  ·  %s", Math.round(hp / max * 100), info.getString("weapon"));
        if (info.getBoolean("gun")) status += " (" + info.getInt("ammo") + " пат.)";
        ctx.drawTextWithShadow(this.textRenderer, status, x0 + 8, y0 + 18, 0xBBBBBB);
        String rel;
        if (info.getBoolean("grudge")) rel = "Отношение: враждебное";
        else if (role == SurvivorEntity.BANDIT) rel = info.getBoolean("calm") ? "Пока вас не трогают" : "Требуют плату за проход";
        else rel = "Доверие: " + info.getInt("trust") + "/100";
        if (info.getBoolean("mine")) {
            String[] m = {"идёт за вами", "ждёт на месте", "охраняет место"};
            rel += "  ·  сытость " + Math.round(info.getFloat("food")) + "%  ·  " + m[Math.floorMod(info.getInt("mode"), 3)];
        }
        ctx.drawTextWithShadow(this.textRenderer, rel, x0 + 8, y0 + 30, 0xBBBBBB);
        if (info.getBoolean("sick")) ctx.drawTextWithShadow(this.textRenderer, "Бледный, весь в поту. Похоже на заражение...", x0 + 8, y0 + 42, 0xFF8080);
        String line = info.getString("line");
        int ly = y0 + 56;
        for (OrderedText t : this.textRenderer.wrapLines(Text.literal("«" + line + "»"), W - 16)) {
            ctx.drawTextWithShadow(this.textRenderer, t, x0 + 8, ly, 0xFFFFFF);
            ly += 10;
            if (ly > y0 + 88) break;
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
