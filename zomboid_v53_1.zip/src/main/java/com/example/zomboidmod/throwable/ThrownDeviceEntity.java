package com.example.zomboidmod.throwable;

import com.example.zomboidmod.Noise;
import net.minecraft.block.AbstractFireBlock;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Брошенная самоделка: летит, а потом горит, взрывается, дымит, звенит или трещит. */
public class ThrownDeviceEntity extends ThrownItemEntity {
    private static final TrackedData<Boolean> LANDED = DataTracker.registerData(ThrownDeviceEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    private int timer;

    public ThrownDeviceEntity(EntityType<? extends ThrownItemEntity> type, World world) {
        super(type, world);
    }

    public ThrownDeviceEntity(World world, LivingEntity owner) {
        super(Throwables.DEVICE, owner, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(LANDED, false);
    }

    @Override
    protected Item getDefaultItem() {
        return Throwables.MOLOTOV != null ? Throwables.MOLOTOV : net.minecraft.item.Items.GLASS_BOTTLE;
    }

    public Throwables.Kind kind() {
        return getStack().getItem() instanceof Throwables.Device d ? d.kind : Throwables.Kind.MOLOTOV;
    }

    public boolean landed() {
        return this.dataTracker.get(LANDED);
    }

    @Override
    public void tick() {
        if (landed()) {
            this.baseTick();
            World w = getWorld();
            if (w.isClient) {
                clientLanded();
                return;
            }
            if (!(w instanceof ServerWorld sw)) return;
            serverLanded(sw);
            return;
        }
        super.tick();
        if (getWorld().isClient && kind() == Throwables.Kind.MOLOTOV) {
            getWorld().addParticle(ParticleTypes.FLAME, getX(), getY() + 0.1, getZ(), 0, 0.01, 0);
            getWorld().addParticle(ParticleTypes.SMOKE, getX(), getY() + 0.1, getZ(), 0, 0.02, 0);
        }
    }

    // ====================================== попадание ======================================

    @Override
    protected void onCollision(HitResult hit) {
        super.onCollision(hit);
        if (getWorld().isClient || !(getWorld() instanceof ServerWorld w) || landed() || isRemoved()) return;
        Vec3d at = hit.getPos();
        if (hit instanceof BlockHitResult bh) at = at.add(Vec3d.of(bh.getSide().getVector()).multiply(0.15));
        switch (kind()) {
            case MOLOTOV -> {
                molotov(w, at);
                discard();
            }
            case PIPE_BOMB -> {
                w.createExplosion(this, at.x, at.y + 0.1, at.z, 3.2f, false, World.ExplosionSourceType.NONE);
                com.example.zomboidmod.motion.Knockdown.blast(w, at, 5.5);   // взрывной волной валит с ног
                com.example.zomboidmod.collapse.Collapse.blast(w, at, 2.6f);  // разносит стены; что на них держалось — рушится
                Noise.emitAt(w, BlockPos.ofFloored(at), 80);
                discard();
            }
            case SMOKE -> {
                Throwables.smoke(w, at);
                Noise.emitAt(w, BlockPos.ofFloored(at), 8);
                discard();
            }
            default -> land(at);
        }
    }

    @Override
    protected void onEntityHit(EntityHitResult hit) {
        super.onEntityHit(hit);
        Entity e = hit.getEntity();
        if (kind() == Throwables.Kind.PIPE_BOMB || kind() == Throwables.Kind.MOLOTOV) return;
        e.damage(getDamageSources().thrown(this, getOwner()), 0.5f);   // будильником по голове
    }

    private void land(Vec3d at) {
        BlockPos below = BlockPos.ofFloored(at);
        double y = at.y;
        // на землю: опускаем до ближайшей твёрдой поверхности
        for (int i = 0; i < 4; i++) {
            BlockState s = getWorld().getBlockState(below.down(i));
            if (!s.getCollisionShape(getWorld(), below.down(i)).isEmpty()) {
                y = below.down(i).getY() + s.getCollisionShape(getWorld(), below.down(i)).getMax(net.minecraft.util.math.Direction.Axis.Y) + 0.01;
                break;
            }
        }
        setPosition(at.x, y, at.z);
        setVelocity(Vec3d.ZERO);
        this.velocityDirty = true;
        this.dataTracker.set(LANDED, true);
        timer = switch (kind()) {
            case ALARM_CLOCK -> 300;
            case NOISE_MAKER -> 400;
            default -> 120;
        };
        getWorld().playSound(null, getBlockPos(), SoundEvents.BLOCK_METAL_HIT, SoundCategory.NEUTRAL, 0.6f, 1.6f);
    }

    // ===================================== коктейль Молотова =====================================

    private void molotov(ServerWorld w, Vec3d at) {
        w.playSound(null, at.x, at.y, at.z, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.NEUTRAL, 1.2f, 0.9f);
        w.playSound(null, at.x, at.y, at.z, SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.NEUTRAL, 1.2f, 0.7f);
        w.spawnParticles(ParticleTypes.FLAME, at.x, at.y + 0.3, at.z, 60, 1.2, 0.3, 1.2, 0.05);
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y + 0.5, at.z, 12, 0.8, 0.4, 0.8, 0.02);
        BlockPos c = BlockPos.ofFloored(at);
        boolean fireTick = w.getGameRules().getBoolean(net.minecraft.world.GameRules.DO_FIRE_TICK);
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++) {
                if (dx * dx + dz * dz > 5) continue;
                for (int dy = 1; dy >= -2; dy--) {
                    BlockPos p = c.add(dx, dy, dz);
                    if (!w.getBlockState(p).isAir() || w.getBlockState(p.down()).isAir()) continue;
                    BlockState fire = AbstractFireBlock.getState(w, p);
                    if (fire.canPlaceAt(w, p) && (fireTick || random.nextFloat() < 0.7f)) w.setBlockState(p, fire);
                    break;
                }
            }
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new net.minecraft.util.math.Box(c).expand(2.5), LivingEntity::isAlive)) {
            e.setOnFireFor(8f);
            e.damage(getDamageSources().inFire(), 3f);
        }
        Noise.emitAt(w, c, 24);
    }

    // =================================== будильник, пищалка, петарды ===================================

    private void serverLanded(ServerWorld w) {
        Throwables.Kind k = kind();
        timer--;
        BlockPos p = getBlockPos();
        switch (k) {
            case ALARM_CLOCK -> {
                if (timer % 12 == 0) w.playSound(null, p, Throwables.ALARM_SOUND, SoundCategory.NEUTRAL, 1.6f, 1f);
                if (timer % 20 == 0) Noise.emitAt(w, p, 30);
            }
            case NOISE_MAKER -> {
                if (timer % 20 == 0) {
                    w.playSound(null, p, Throwables.NOISE_SOUND, SoundCategory.NEUTRAL, 2.2f, 1f);
                    Noise.emitAt(w, p, 45);
                }
            }
            default -> {   // петарды
                if (timer % 3 == 0 && random.nextFloat() < 0.75f) {
                    w.playSound(null, p, Throwables.FIRECRACKER_SOUND, SoundCategory.NEUTRAL, 1.8f, 0.85f + random.nextFloat() * 0.35f);
                    w.spawnParticles(ParticleTypes.FIREWORK, getX(), getY() + 0.2, getZ(), 4, 0.25, 0.15, 0.25, 0.08);
                    w.spawnParticles(ParticleTypes.SMOKE, getX(), getY() + 0.1, getZ(), 2, 0.2, 0.05, 0.2, 0.01);
                    setVelocity(0, 0, 0);
                }
                if (timer % 20 == 0) Noise.emitAt(w, p, 35);
            }
        }
        if (timer > 0) return;
        // отработал: будильник и пищалку можно подобрать
        if (k == Throwables.Kind.ALARM_CLOCK) dropStack(getStack().copyWithCount(1), 0.1f);
        else if (k == Throwables.Kind.NOISE_MAKER) {
            ItemStack s = getStack().copyWithCount(1);
            s.setDamage(s.getDamage() + 1);
            if (s.getDamage() < s.getMaxDamage()) dropStack(s, 0.1f);
            else if (com.example.zomboidmod.metal.Metal.ELECTRONICS != null) dropStack(new ItemStack(com.example.zomboidmod.metal.Metal.ELECTRONICS), 0.1f);
        }
        discard();
    }

    private void clientLanded() {
        World w = getWorld();
        Throwables.Kind k = kind();
        if (k == Throwables.Kind.ALARM_CLOCK && age % 6 == 0)
            w.addParticle(ParticleTypes.NOTE, getX(), getY() + 0.35, getZ(), random.nextFloat(), 0, 0);
        else if (k == Throwables.Kind.NOISE_MAKER && age % 20 == 0)
            w.addParticle(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.3, getZ(), 0, 0.05, 0);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("Landed", landed());
        nbt.putInt("Timer", timer);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.dataTracker.set(LANDED, nbt.getBoolean("Landed"));
        timer = nbt.getInt("Timer");
    }
}
