package com.example.zomboidmod;

import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Топоры: сильный медленный удар, рубят деревья. */
public class PzAxeItem extends AxeItem {
    private final boolean heavy;

    public PzAxeItem(ToolMaterial material, float totalDamage, float attackSpeed, int durability, boolean heavy,
                     Settings settings) {
        super(material, settings.maxDamage(durability).attributeModifiers(AxeItem.createAttributeModifiers(
                material, totalDamage - 1 - material.getAttackDamage(), attackSpeed)));
        this.heavy = heavy;
    }

    /** Двуручный топор. */
    public boolean heavy() {
        return heavy;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal(heavy ? "Двуручный: страшный, но медленный удар. Отсекает конечности" : "Рубящее: рубит деревья и конечности")
                .formatted(Formatting.GRAY));
        com.example.zomboidmod.detail.WeaponBlood.tooltip(stack, tooltip);
    }

    @Override
    public boolean postHit(ItemStack stack, net.minecraft.entity.LivingEntity target, net.minecraft.entity.LivingEntity attacker) {
        com.example.zomboidmod.detail.WeaponBlood.hit(stack, target);
        return super.postHit(stack, target, attacker);
    }

    @Override
    public boolean allowComponentsUpdateAnimation(net.minecraft.entity.player.PlayerEntity player, net.minecraft.util.Hand hand, ItemStack oldStack, ItemStack newStack) {
        return false;
    }

    /** Уход за оружием: с шансом удар не отнимает прочность. */
    public void postDamageEntity(ItemStack stack, net.minecraft.entity.LivingEntity target, net.minecraft.entity.LivingEntity attacker) {
        if (Skills.saveDurability(attacker)) return;
        super.postDamageEntity(stack, target, attacker);
    }
}
