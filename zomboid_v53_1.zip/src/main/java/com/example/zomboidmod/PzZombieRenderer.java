package com.example.zomboidmod;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.ZombieBaseEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Зомби: тело (лицо, раны) + одежда вторым слоем, своя анимация, ползун без ног тянется на руках, 3D-детали одежды. */
public class PzZombieRenderer extends ZombieBaseEntityRenderer<ZombieEntity, PzZombieModel> {
    private static final Identifier ACC_TEX = Identifier.of(ZomboidMod.MOD_ID, "textures/entity/zombie/accessories.png");

    public PzZombieRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PzZombieModel(ctx.getPart(EntityModelLayers.ZOMBIE)),
                new PzZombieModel(ctx.getPart(EntityModelLayers.ZOMBIE_INNER_ARMOR)),
                new PzZombieModel(ctx.getPart(EntityModelLayers.ZOMBIE_OUTER_ARMOR)));
        this.addFeature(new OutfitLayer(this));
        this.addFeature(new Accessories(this));
        this.addFeature(new GoreLayer(this));
        this.addFeature(new GlowEyes(this));
    }

    private static Identifier tex(String n) {
        return Identifier.of(ZomboidMod.MOD_ID, "textures/entity/zombie/" + n + ".png");
    }

    private static final Identifier[] SCREAMER = {tex("screamer_0"), tex("screamer_1")};
    private static final Identifier[] BLOATER = {tex("bloater_0"), tex("bloater_1")};
    private static final Identifier CARRIER = tex("carrier");

    @Override
    public Identifier getTexture(ZombieEntity entity) {
        if (entity instanceof PzZombieEntity z) return bodyTex(z.getUuid(), z.tone(), z.kind());
        return super.getTexture(entity);
    }

    /** Текстура тела по внешности (и для лежащих тел). */
    public static Identifier bodyTex(java.util.UUID uuid, int tone, ZombieKind kind) {
        int v = Math.floorMod(uuid.hashCode(), 2);
        return switch (kind) {   // у особых зомби — своё тело
            case SCREAMER -> SCREAMER[v];
            case BLOATER -> BLOATER[v];
            case CARRIER -> CARRIER;
            default -> ZombieOutfit.bodyTexture(uuid, tone);
        };
    }

    /** Раздутый — вширь, Носитель — ещё и раздавшийся в плечах (рост задаёт атрибут размера). */
    @Override
    protected void scale(ZombieEntity entity, MatrixStack matrices, float amount) {
        super.scale(entity, matrices, amount);
        if (entity instanceof PzZombieEntity z) {
            ZombieKind k = z.kind();
            if (k == ZombieKind.BLOATER) matrices.scale(1.34f, 1.0f, 1.34f);
            else if (k == ZombieKind.CARRIER) matrices.scale(1.12f, 1.0f, 1.12f);
        }
    }

    /** Светящиеся в темноте глаза: красные у ярых, жёлтые у Носителя. */
    static final class GlowEyes extends FeatureRenderer<ZombieEntity, PzZombieModel> {
        private static final Identifier FERAL_EYES = tex("eyes_feral"), CARRIER_EYES = tex("eyes_carrier");

        GlowEyes(FeatureRendererContext<ZombieEntity, PzZombieModel> ctx) {
            super(ctx);
        }

        @Override
        public void render(MatrixStack matrices, VertexConsumerProvider vcp, int light, ZombieEntity entity, float limbAngle, float limbDistance,
                           float tickDelta, float animationProgress, float headYaw, float headPitch) {
            if (!(entity instanceof PzZombieEntity z) || entity.isInvisible()) return;
            ZombieKind k = z.kind();
            Identifier t = k == ZombieKind.FERAL ? FERAL_EYES : k == ZombieKind.CARRIER ? CARRIER_EYES : null;
            if (t == null) return;
            VertexConsumer vc = vcp.getBuffer(RenderLayer.getEyes(t));
            getContextModel().render(matrices, vc, 15728640, net.minecraft.client.render.OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
        }
    }

    /** Ванильное «заваливание набок» при смерти отключено: падает по-настоящему (см. ниже). */
    @Override
    protected float getLyingAngle(ZombieEntity entity) {
        return entity instanceof PzZombieEntity ? 0f : super.getLyingAngle(entity);
    }

    static float wide(PzZombieEntity z) {
        return z.kind() == ZombieKind.BLOATER ? 1.34f : z.kind() == ZombieKind.CARRIER ? 1.12f : 1f;
    }

    /** Насколько сейчас лежит (0..1): падает мёртвым или сбит с ног. Модель берёт это же значение для рук и ног. */
    public static float fallAmount(PzZombieEntity z, float tickDelta) {
        if (z.deathTime > 0) return z.isCrawler() ? 1f : com.example.zomboidmod.motion.FallAnim.fall(z.deathTime - 1 + tickDelta);
        float e = z.downElapsed(tickDelta);
        if (e < 0f) return 0f;
        return com.example.zomboidmod.motion.FallAnim.knock(e, z.downLen(), com.example.zomboidmod.motion.Knockdown.Z_GETUP);
    }

    public static boolean fallFace(PzZombieEntity z) {
        return z.deathTime > 0 ? (z.isCrawler() || z.deathFaceDown()) : z.downFace();
    }

    @Override
    protected void setupTransforms(ZombieEntity entity, MatrixStack matrices, float animationProgress, float bodyYaw, float tickDelta, float scale) {
        super.setupTransforms(entity, matrices, animationProgress, bodyYaw, tickDelta, scale);
        if (entity instanceof PzZombieEntity zf && (entity.deathTime > 0 || zf.isDown()) && com.example.zomboidmod.motion.MotionClient.falls()) {
            com.example.zomboidmod.motion.FallAnim.apply(matrices, fallAmount(zf, tickDelta), fallFace(zf), wide(zf));
            return;
        }
        if (entity.deathTime > 0) {   // упрощённый режим: просто лечь, как тело
            if (entity instanceof PzZombieEntity zf2) com.example.zomboidmod.motion.FallAnim.apply(matrices, Math.min(1f, (entity.deathTime + tickDelta) / 10f), fallFace(zf2), wide(zf2));
            return;
        }
        if (entity instanceof PzZombieEntity zp && zp.pileRole() != 0 && !zp.isCrawler()) {
            // в живой пирамиде: навалился на стену и на спины тех, кто ниже
            float lean = zp.pileLean();
            float wob = net.minecraft.util.math.MathHelper.sin((entity.age + tickDelta) * 0.12f + (entity.getId() & 63)) * 2.5f;
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-(lean + wob)));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(((entity.getId() * 37) % 13 - 6) * 0.8f));
            return;
        }
        if (entity instanceof PzZombieEntity z && z.isCrawler() && entity.deathTime <= 0) {
            float lie = z.crawlLie(tickDelta);   // только что лишился ног — валится вперёд
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90f * lie));
            matrices.translate(0f, -1.0f * lie, 0.3f * lie);
        } else if (entity.deathTime <= 0) {
            // ползёт сквозь окно или упал после забора — ложится плашмя
            float lie = com.example.zomboidmod.parkour.ParkourClient.lie(entity, tickDelta);
            if (lie > 0f) {
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90f * lie));
                matrices.translate(0f, -1.0f * lie, 0.3f * lie);
            }
        }
    }

    /** Обрубки на месте отсечённых рук, ног и головы, отвисшая сломанная челюсть. */
    static final class GoreLayer extends FeatureRenderer<ZombieEntity, PzZombieModel> {
        GoreLayer(FeatureRendererContext<ZombieEntity, PzZombieModel> ctx) {
            super(ctx);
        }

        @Override
        public void render(MatrixStack matrices, VertexConsumerProvider vcp, int light, ZombieEntity entity, float limbAngle, float limbDistance,
                           float tickDelta, float animationProgress, float headYaw, float headPitch) {
            if (!(entity instanceof PzZombieEntity z) || entity.isInvisible()) return;
            int l = z.limbs();
            if (l == 0) return;
            ZombieKind k = z.kind();
            Identifier clothes = k == ZombieKind.CARRIER ? null : z.outfit().outfitTexture(z.getUuid());
            com.example.zomboidmod.combat.Gore.render(getContextModel(), l, matrices, vcp, light, LivingEntityRenderer.getOverlay(entity, 0f),
                    0xFFFFFFFF, bodyTex(z.getUuid(), z.tone(), k), clothes);
        }
    }

    /** Одежда — второй слой поверх тела той же модели: дыры и лохмотья показывают раны на теле. */
    static final class OutfitLayer extends FeatureRenderer<ZombieEntity, PzZombieModel> {
        OutfitLayer(FeatureRendererContext<ZombieEntity, PzZombieModel> ctx) {
            super(ctx);
        }

        @Override
        public void render(MatrixStack matrices, VertexConsumerProvider vcp, int light, ZombieEntity entity, float limbAngle, float limbDistance,
                           float tickDelta, float animationProgress, float headYaw, float headPitch) {
            if (!(entity instanceof PzZombieEntity z) || entity.isInvisible()) return;
            if (z.kind() == ZombieKind.CARRIER) return;   // Носитель давно разорвал одежду
            Identifier tex = z.outfit().outfitTexture(z.getUuid());
            VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(tex));
            getContextModel().render(matrices, vc, light, LivingEntityRenderer.getOverlay(entity, 0f), 0xFFFFFFFF);
        }
    }

    /** Каски, фуражки, маски, рюкзаки и лохмотья — по одежде и случайно. */
    static final class Accessories extends FeatureRenderer<ZombieEntity, PzZombieModel> {
        private static final int[] TINTS = {0xFF7A2A24, 0xFF2E3E66, 0xFF3C5A34, 0xFF5A4A3A, 0xFF2A2A2C, 0xFF8A7A50, 0xFF6A6A70};
        private final Map<String, ModelPart> parts = new HashMap<>();
        private final Map<String, String> attach = new HashMap<>();

        Accessories(FeatureRendererContext<ZombieEntity, PzZombieModel> ctx) {
            super(ctx);
            ModelPart root = ZombieAccessoryModels.create().createModel();
            for (String[] p : ZombieAccessoryModels.PARTS) {
                parts.put(p[0], root.getChild(p[0]));
                attach.put(p[0], p[1]);
            }
        }

        static List<String> pick(PzZombieEntity z) {
            java.util.Random r = new java.util.Random(z.getUuid().getLeastSignificantBits() ^ 0x5DEECE66DL);
            List<String> out = new ArrayList<>();
            if (z.kind() == ZombieKind.CARRIER) return out;
            switch (z.outfit()) {
                case RIOT -> {
                    out.add("army_helmet");
                    if (r.nextFloat() < 0.4f) out.add("backpack");
                    return out;
                }
                case POLICE -> { if (r.nextFloat() < 0.7f) out.add("police_cap"); }
                case SECURITY -> { if (r.nextFloat() < 0.7f) out.add("security_cap"); }
                case FIREFIGHTER -> out.add("fire_helmet");
                case CONSTRUCTION -> { if (r.nextFloat() < 0.8f) out.add("hard_hat"); }
                case SOLDIER -> {
                    out.add("army_helmet");
                    if (r.nextFloat() < 0.5f) out.add("backpack");
                    if (r.nextFloat() < 0.3f) out.add("bedroll");
                }
                case CHEF -> out.add("chef_hat");
                case FARMER -> out.add(r.nextFloat() < 0.6f ? "straw_hat" : "baseball_cap");
                case NURSE -> {
                    if (r.nextFloat() < 0.5f) out.add("nurse_cap");
                    if (r.nextFloat() < 0.3f) out.add("surgical_mask");
                }
                case DOCTOR -> { if (r.nextFloat() < 0.6f) out.add("surgical_mask"); }
                case HAZMAT -> out.add("hazmat_hood");
                case BIKER -> { if (r.nextFloat() < 0.6f) out.add("bandana"); }
                case SURVIVOR -> {
                    out.add("backpack");
                    if (r.nextFloat() < 0.5f) out.add("bedroll");
                    if (r.nextFloat() < 0.4f) out.add("baseball_cap");
                }
                case STUDENT -> { if (r.nextFloat() < 0.7f) out.add("backpack"); }
                case MECHANIC -> { if (r.nextFloat() < 0.4f) out.add("baseball_cap"); }
                default -> {
                    if (r.nextFloat() < 0.18f) out.add("baseball_cap");
                    if (r.nextFloat() < 0.1f) out.add("backpack");
                }
            }
            if (z.outfit() != ZombieOutfit.HAZMAT) {
                if (r.nextFloat() < 0.3f) out.add("rag_body");
                if (r.nextFloat() < 0.25f) out.add("rag_arm_r");
                if (r.nextFloat() < 0.25f) out.add("rag_arm_l");
            }
            return out;
        }

        @Override
        public void render(MatrixStack matrices, VertexConsumerProvider vcp, int light, ZombieEntity entity, float limbAngle, float limbDistance,
                           float tickDelta, float animationProgress, float headYaw, float headPitch) {
            if (!(entity instanceof PzZombieEntity z) || entity.isInvisible()) return;
            List<String> list = pick(z);
            if (list.isEmpty()) return;
            PzZombieModel m = getContextModel();
            VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(ACC_TEX));
            int overlay = LivingEntityRenderer.getOverlay(entity, 0f);
            int tint = TINTS[Math.floorMod(entity.getUuid().hashCode(), TINTS.length)];
            for (String id : list) {
                ModelPart p = parts.get(id);
                if (p == null) continue;
                ModelPart src = switch (attach.get(id)) {
                    case "body" -> m.body;
                    case "right_arm" -> m.rightArm;
                    case "left_arm" -> m.leftArm;
                    default -> m.head;
                };
                if (!src.visible) continue;   // шапка улетела вместе с головой, лохмотья — с рукой
                p.copyTransform(src);
                int col = id.equals("baseball_cap") || id.equals("backpack") ? tint : 0xFFFFFFFF;
                if (id.equals("army_helmet") && z.outfit() == ZombieOutfit.RIOT) col = 0xFF3A3D44;   // чёрный шлем спецназа
                p.render(matrices, vc, light, overlay, col);
            }
        }
    }
}
