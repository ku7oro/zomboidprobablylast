package com.example.zomboidmod.ui;

import com.example.zomboidmod.ZomboidMod;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/**
 * Единый стиль интерфейса мода — «полевой планшет выжившего»: потёртая стальная рамка с заклёпками,
 * штампованные кнопки, утопленные окошки, бумажные записки для меню и подсказок.
 * Все экраны рисуются через эти помощники, поэтому выглядят одинаково.
 */
public final class Ui {
    private Ui() {
    }

    // палитра
    public static final int TEXT = 0xFFE8E0C8, DIM = 0xFF9A9482, FAINT = 0xFF6C6858, ACCENT = 0xFFE2AC48;
    public static final int GOOD = 0xFF8DB870, WARN = 0xFFE0B040, BAD = 0xFFD05040, INK = 0xFF2A2218, INK_DIM = 0xFF7A6A50;

    private static Identifier tex(String n) {
        return Identifier.of(ZomboidMod.MOD_ID, "textures/gui/ui/" + n + ".png");
    }

    public static final Identifier PANEL = tex("panel"), HEADER = tex("header"), INSET = tex("inset"), BUTTON = tex("button"),
            TAB = tex("tab"), PAPER = tex("paper"), BLUEPRINT = tex("blueprint"), WOUND_ICONS = tex("wound_icons"),
            PIPS = tex("pips"), SLOT = tex("slot"), DASH = tex("dash"), LAMPS = tex("lamps");

    public static Identifier ui(String name) {
        return tex(name);
    }

    // =====================================================================================
    //                                   девять кусков
    // =====================================================================================

    /** Кусок текстуры, замощённый (не растянутый) по прямоугольнику. */
    private static void tile(DrawContext ctx, Identifier t, int x, int y, int w, int h, int u, int v, int rw, int rh, int tw, int th) {
        if (w <= 0 || h <= 0 || rw <= 0 || rh <= 0) return;
        for (int yy = 0; yy < h; yy += rh) {
            int hh = Math.min(rh, h - yy);
            for (int xx = 0; xx < w; xx += rw) {
                int ww = Math.min(rw, w - xx);
                ctx.drawTexture(t, x + xx, y + yy, ww, hh, (float) u, (float) v, ww, hh, tw, th);
            }
        }
    }

    /**
     * Рамка из девяти кусков: углы как есть, стороны и середина мостятся.
     * (u0, v0, rw, rh) — область в текстуре tw x th, c — размер угла.
     */
    public static void nine(DrawContext ctx, Identifier t, int x, int y, int w, int h, int u0, int v0, int rw, int rh, int c, int tw, int th) {
        RenderSystem.enableBlend();
        int cx = Math.min(c, w / 2), cy = Math.min(c, h / 2);
        int mw = rw - 2 * c, mh = rh - 2 * c;
        // углы
        ctx.drawTexture(t, x, y, cx, cy, (float) u0, (float) v0, cx, cy, tw, th);
        ctx.drawTexture(t, x + w - cx, y, cx, cy, (float) (u0 + rw - cx), (float) v0, cx, cy, tw, th);
        ctx.drawTexture(t, x, y + h - cy, cx, cy, (float) u0, (float) (v0 + rh - cy), cx, cy, tw, th);
        ctx.drawTexture(t, x + w - cx, y + h - cy, cx, cy, (float) (u0 + rw - cx), (float) (v0 + rh - cy), cx, cy, tw, th);
        // стороны
        tile(ctx, t, x + cx, y, w - 2 * cx, cy, u0 + c, v0, mw, cy, tw, th);
        tile(ctx, t, x + cx, y + h - cy, w - 2 * cx, cy, u0 + c, v0 + rh - cy, mw, cy, tw, th);
        tile(ctx, t, x, y + cy, cx, h - 2 * cy, u0, v0 + c, cx, mh, tw, th);
        tile(ctx, t, x + w - cx, y + cy, cx, h - 2 * cy, u0 + rw - cx, v0 + c, cx, mh, tw, th);
        // середина
        tile(ctx, t, x + cx, y + cy, w - 2 * cx, h - 2 * cy, u0 + c, v0 + c, mw, mh, tw, th);
    }

    // =====================================================================================
    //                                      детали
    // =====================================================================================

    /** Окно: стальная рамка с заклёпками и тёмное поле. */
    public static void panel(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x + 3, y + 4, x + w + 3, y + h + 4, 0x50000000);          // тень под окном
        nine(ctx, PANEL, x, y, w, h, 0, 0, 64, 64, 10, 64, 64);
    }

    /** Окно с заголовком на стальной планке. Содержимое начинается с y + 26. */
    public static void window(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h, String title) {
        panel(ctx, x, y, w, h);
        plate(ctx, x + 6, y + 6, w - 12, 15);
        if (title != null) ctx.drawText(tr, title, x + 12, y + 10, TEXT, true);
    }

    /** Стальная планка (заголовки, подписи разделов). */
    public static void plate(DrawContext ctx, int x, int y, int w, int h) {
        nine(ctx, HEADER, x, y, w, h, 0, 0, 32, 16, 4, 32, 16);
    }

    /** Утопленное окошко: под силуэт, список, схему. */
    public static void inset(DrawContext ctx, int x, int y, int w, int h) {
        nine(ctx, INSET, x, y, w, h, 0, 0, 32, 32, 4, 32, 32);
    }

    /** Утопленное окошко с синькой чертежа внутри. */
    public static void blueprint(DrawContext ctx, int x, int y, int w, int h) {
        inset(ctx, x, y, w, h);
        tile(ctx, BLUEPRINT, x + 2, y + 2, w - 4, h - 4, 0, 0, 40, 40, 40, 40);
    }

    /** Бумажная записка: меню лечения, подсказки. Текст на ней — тёмными чернилами (INK), без тени. */
    public static void paper(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x + 2, y + 3, x + w + 2, y + h + 3, 0x60000000);
        nine(ctx, PAPER, x, y, w, h, 0, 0, 48, 48, 8, 48, 48);
    }

    public static boolean over(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Штампованная кнопка. Возвращает true, если курсор над ней и она доступна. */
    public static boolean button(DrawContext ctx, TextRenderer tr, double mx, double my, int x, int y, int w, int h, String label, boolean enabled) {
        boolean hover = enabled && over(mx, my, x, y, w, h);
        int st = !enabled ? 2 : hover ? 1 : 0;
        nine(ctx, BUTTON, x, y, w, h, 0, st * 18, 32, 18, 4, 32, 54);
        if (label != null) {
            String s = fit(tr, label, w - 6);
            ctx.drawText(tr, s, x + (w - tr.getWidth(s)) / 2, y + (h - 8) / 2 + (hover ? 0 : 0), enabled ? (hover ? 0xFFFFF6DC : TEXT) : FAINT, enabled);
        }
        return hover;
    }

    /** Кнопка с текстом слева (строки списков, пункты настроек). */
    public static boolean rowButton(DrawContext ctx, TextRenderer tr, double mx, double my, int x, int y, int w, int h, String label, boolean enabled) {
        boolean hover = enabled && over(mx, my, x, y, w, h);
        int st = !enabled ? 2 : hover ? 1 : 0;
        nine(ctx, BUTTON, x, y, w, h, 0, st * 18, 32, 18, 4, 32, 54);
        if (label != null) ctx.drawText(tr, fit(tr, label, w - 8), x + 5, y + (h - 8) / 2, enabled ? (hover ? 0xFFFFF6DC : TEXT) : FAINT, enabled);
        return hover;
    }

    /** Вкладка. Возвращает ширину. */
    public static int tab(DrawContext ctx, TextRenderer tr, double mx, double my, int x, int y, String label, boolean active) {
        int w = tr.getWidth(label) + 14;
        boolean hover = !active && over(mx, my, x, y, w, 15);
        nine(ctx, TAB, x, y, w, 15, 0, active ? 0 : 16, 32, 16, 3, 32, 32);
        ctx.drawText(tr, label, x + 7, y + 4, active ? TEXT : hover ? 0xFFC8C2A8 : DIM, active);
        return w;
    }

    /** Обрезает строку по ширине, добавляя многоточие. */
    public static String fit(TextRenderer tr, String s, int w) {
        if (tr.getWidth(s) <= w) return s;
        return tr.trimToWidth(s, Math.max(0, w - tr.getWidth("…"))) + "…";
    }

    /** Горизонтальная шкала в рамке: жёлоб, заливка с бликом, деления через каждые 10 %. */
    public static void bar(DrawContext ctx, int x, int y, int w, int h, float frac, int color) {
        float f = Math.max(0f, Math.min(1f, frac));
        ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF090908);
        ctx.fill(x, y, x + w, y + h, 0xFF1A1A17);
        ctx.fill(x, y, x + w, y + 1, 0xFF0E0E0C);
        int fw = Math.round(w * f);
        if (fw > 0) {
            ctx.fill(x, y, x + fw, y + h, color);
            ctx.fill(x, y, x + fw, y + 1, lighten(color, 0.35f));
            if (h > 2) ctx.fill(x, y + h - 1, x + fw, y + h, darken(color, 0.3f));
        }
        if (w >= 30) for (int i = 1; i < 10; i++) {
            int tx = x + w * i / 10;
            ctx.fill(tx, y, tx + 1, y + h, 0x70000000);
        }
        ctx.fill(x - 1, y + h + 1, x + w + 1, y + h + 2, 0x30FFFFFF);       // светлая кромка снизу: шкала утоплена
    }

    /** Вертикальная шкала в рамке (заполняется снизу). */
    public static void vbar(DrawContext ctx, int x, int y, int w, int h, float frac, int color) {
        float f = Math.max(0f, Math.min(1f, frac));
        ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF090908);
        ctx.fill(x, y, x + w, y + h, 0xFF1A1A17);
        int fh = Math.round(h * f);
        if (fh > 0) {
            ctx.fill(x, y + h - fh, x + w, y + h, color);
            ctx.fill(x, y + h - fh, x + 1, y + h, lighten(color, 0.35f));
            if (w > 2) ctx.fill(x + w - 1, y + h - fh, x + w, y + h, darken(color, 0.3f));
        }
        for (int i = 1; i < 10; i++) {
            int ty = y + h * i / 10;
            ctx.fill(x, ty, x + w, ty + 1, 0x70000000);
        }
        ctx.fill(x + w + 1, y - 1, x + w + 2, y + h + 1, 0x30FFFFFF);
    }

    /** Тонкая выбитая линия-разделитель. */
    public static void divider(DrawContext ctx, int x, int y, int w) {
        ctx.fill(x, y, x + w, y + 1, 0xFF0A0A09);
        ctx.fill(x, y + 1, x + w, y + 2, 0x28FFFFFF);
    }

    /** Заголовок раздела: янтарный текст и линия до края. */
    public static void section(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w) {
        ctx.drawText(tr, label, x, y, ACCENT, true);
        int tw = tr.getWidth(label) + 5;
        if (w > tw) divider(ctx, x + tw, y + 4, w - tw);
    }

    /** Рамка-значок 20x20 (или другого размера), залитая цветом состояния. */
    public static void slot(DrawContext ctx, int x, int y, int size, int argb) {
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, 1f);
        ctx.drawTexture(SLOT, x, y, size, size, 0f, 0f, 20, 20, 20, 20);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    /** Значок состояния раны: 0 кровь, 1 повязка, 2 грязная повязка, 3 заражение, 4 швы, 5 шина. */
    public static void woundIcon(DrawContext ctx, int icon, int x, int y, int size) {
        RenderSystem.enableBlend();
        ctx.drawTexture(WOUND_ICONS, x, y, size, size, icon * 8f, 0f, 8, 8, 48, 8);
    }

    /** Деление шкалы навыка: 0 пусто, 1 полно, 2 наполовину. */
    public static void pip(DrawContext ctx, int x, int y, int state) {
        ctx.drawTexture(PIPS, x, y, 4, 8, state * 5f, 0f, 4, 8, 15, 8);
    }

    /** Текстура-маска, окрашенная в цвет argb. */
    public static void tinted(DrawContext ctx, Identifier t, int x, int y, int w, int h, float u, float v, int rw, int rh, int tw, int th, int argb) {
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, ((argb >>> 24) & 255) / 255f);
        ctx.drawTexture(t, x, y, w, h, u, v, rw, rh, tw, th);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    /** Стрелка прибора: из точки (cx, cy) под углом deg (0 — вправо, по часовой), длиной len. */
    public static void needle(DrawContext ctx, float cx, float cy, float deg, float len, int color) {
        var m = ctx.getMatrices();
        m.push();
        m.translate(cx, cy, 0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(deg));
        ctx.fill(-3, -1, Math.round(len), 1, 0x90000000);
        m.translate(0f, -0.5f, 0f);
        ctx.fill(-3, 0, Math.round(len), 1, color);
        m.pop();
        ctx.fill(Math.round(cx) - 1, Math.round(cy) - 1, Math.round(cx) + 2, Math.round(cy) + 2, 0xFF2A2A26);
        ctx.fill(Math.round(cx), Math.round(cy), Math.round(cx) + 1, Math.round(cy) + 1, 0xFF8A887A);
    }

    /** Подсказка на бумажке у курсора; сама следит, чтобы не вылезти за экран. */
    public static void note(DrawContext ctx, TextRenderer tr, int mx, int my, int screenW, int screenH, String... lines) {
        int w = 0;
        for (String s : lines) w = Math.max(w, tr.getWidth(s));
        w += 14;
        int h = lines.length * 10 + 10;
        int x = Math.min(mx + 10, screenW - w - 4), y = Math.min(my + 10, screenH - h - 4);
        var m = ctx.getMatrices();
        m.push();
        m.translate(0f, 0f, 300f);
        paper(ctx, x, y, w, h);
        for (int i = 0; i < lines.length; i++) ctx.drawText(tr, lines[i], x + 7, y + 6 + i * 10, i == 0 ? INK : INK_DIM, false);
        m.pop();
    }

    public static int lighten(int argb, float k) {
        int r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        r += (int) ((255 - r) * k);
        g += (int) ((255 - g) * k);
        b += (int) ((255 - b) * k);
        return (argb & 0xFF000000) | (r << 16) | (g << 8) | b;
    }

    public static int darken(int argb, float k) {
        int r = (int) (((argb >> 16) & 255) * (1 - k)), g = (int) (((argb >> 8) & 255) * (1 - k)), b = (int) ((argb & 255) * (1 - k));
        return (argb & 0xFF000000) | (r << 16) | (g << 8) | b;
    }
}
