package com.example.zomboidmod.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Обычная кнопка Minecraft, но нарисованная в стиле мода: штампованная стальная пластина. */
public class PzButton extends ButtonWidget {
    public PzButton(int x, int y, int w, int h, Text message, PressAction onPress) {
        super(x, y, w, h, message, onPress, DEFAULT_NARRATION_SUPPLIER);
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        boolean hover = this.active && this.isSelected();
        int st = !this.active ? 2 : hover ? 1 : 0;
        Ui.nine(ctx, Ui.BUTTON, getX(), getY(), getWidth(), getHeight(), 0, st * 18, 32, 18, 4, 32, 54);
        String s = Ui.fit(tr, getMessage().getString(), getWidth() - 6);
        ctx.drawText(tr, s, getX() + (getWidth() - tr.getWidth(s)) / 2, getY() + (getHeight() - 8) / 2,
                this.active ? (hover ? 0xFFFFF6DC : Ui.TEXT) : Ui.FAINT, this.active);
    }

    public static PzBuilder create(Text message, PressAction onPress) {
        return new PzBuilder(message, onPress);
    }

    /** Повторяет привычную цепочку ButtonWidget.builder(...).dimensions(...).build(). */
    public static final class PzBuilder {
        private final Text message;
        private final PressAction onPress;
        private int x, y, w = 150, h = 20;

        private PzBuilder(Text message, PressAction onPress) {
            this.message = message;
            this.onPress = onPress;
        }

        public PzBuilder dimensions(int x, int y, int w, int h) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            return this;
        }

        public PzButton build() {
            return new PzButton(x, y, w, h, message, onPress);
        }
    }
}
