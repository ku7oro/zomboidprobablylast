package com.example.zomboidmod.amputation;

import com.example.zomboidmod.combat.Gore;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Как выглядит игрок без руки или ноги: отнятое скрыто, на его месте — обрубок с раной или протез. */
public final class AmputationClient {
    private AmputationClient() {
    }

    public static void init() {
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, ctx) -> {
            if (renderer instanceof PlayerEntityRenderer pr) helper.register(new Feature(pr));
        });
    }

    /** Из setAngles модели: скрыть отнятые части (рендер игрока каждый кадр снова делает видимым всё). */
    public static void pose(BipedEntityModel<?> m, LivingEntity e) {
        if (!(e instanceof PlayerEntity p) || Amputation.CLIENT.isEmpty()) return;
        int lost = Amputation.lostBits(p);
        if (lost == 0) return;
        PlayerEntityModel<?> pm = m instanceof PlayerEntityModel<?> x ? x : null;
        if ((lost & 1) != 0) {
            m.leftArm.visible = false;
            if (pm != null) pm.leftSleeve.visible = false;
        }
        if ((lost & 2) != 0) {
            m.rightArm.visible = false;
            if (pm != null) pm.rightSleeve.visible = false;
        }
        if ((lost & 4) != 0) {
            m.leftLeg.visible = false;
            if (pm != null) pm.leftPants.visible = false;
        }
        if ((lost & 8) != 0) {
            m.rightLeg.visible = false;
            if (pm != null) pm.rightPants.visible = false;
        }
    }

    static final class Feature extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
        Feature(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> ctx) {
            super(ctx);
        }

        @Override
        public void render(MatrixStack matrices, VertexConsumerProvider vcp, int light, AbstractClientPlayerEntity player, float limbAngle,
                           float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
            int lost = Amputation.lostBits(player);
            if (lost == 0 || player.isInvisible()) return;
            Gore.renderPlayer(getContextModel(), lost, Amputation.prosBits(player), matrices, vcp, light, OverlayTexture.DEFAULT_UV,
                    player.getSkinTextures().texture());
        }
    }
}
