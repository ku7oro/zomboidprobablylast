package com.example.zomboidmod.amputation;

import com.example.zomboidmod.BodyPart;
import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PartState;
import com.example.zomboidmod.PlayerHealth;
import com.example.zomboidmod.PzAxeItem;
import com.example.zomboidmod.PzWeaponItem;
import com.example.zomboidmod.WoundType;
import com.example.zomboidmod.Wounds;
import com.example.zomboidmod.ZomboidMod;
import com.example.zomboidmod.build.CarpentryItems;
import com.example.zomboidmod.combat.Combat;
import com.example.zomboidmod.combat.Limbs;
import com.example.zomboidmod.gun.GunItem;
import com.example.zomboidmod.motion.Knockdown;
import com.example.zomboidmod.survival.Mood;
import com.example.zomboidmod.survival.Survival;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Ампутация. Укус в руку или ногу — ещё не конец: пока зараза не ушла дальше (около двух игровых часов),
 * конечность можно отнять пилой, топором или тесаком. Без обезболивающего и выпивки от боли теряешь сознание,
 * культя сильно кровит, пока её не зашьёшь. Дальше живёшь без руки (одна рука: вторая не держит ничего,
 * двуручное оружие почти бесполезно, прицел гуляет) или без ноги (ковыляешь, не бегаешь; костыль помогает).
 * Когда культя заживёт, на неё можно надеть самодельный протез.
 * Конечности: 0 — левая рука, 1 — правая рука, 2 — левая нога, 3 — правая нога.
 */
public final class Amputation {
    private Amputation() {
    }

    /** Сколько игровых часов после укуса ещё можно успеть. */
    public static final float WINDOW = 2.0f;
    /** Действия из панели здоровья (обычные действия — номера лекарств). */
    public static final int CUT = 100, ATTACH = 101, DETACH = 102;
    /** Биты состояния тела для клиента: чего нет и где протез. */
    public static final int SHIFT_LOST = 16, SHIFT_PROS = 20;

    public static Item CRUTCH, PROSTHETIC_ARM, PROSTHETIC_LEG;
    public static SoundEvent SAW_SOUND;
    /** Клиент: у кого чего нет (id сущности игрока → биты состояния тела). */
    public static final Map<Integer, Integer> CLIENT = new ConcurrentHashMap<>();

    private static final Identifier SPEED = Identifier.of(ZomboidMod.MOD_ID, "amp_speed"), ATTACK = Identifier.of(ZomboidMod.MOD_ID, "amp_attack"),
            DAMAGE = Identifier.of(ZomboidMod.MOD_ID, "amp_damage");

    public static void register() {
        CRUTCH = reg("crutch", new Tip(new Item.Settings().maxCount(1), "Без ноги с ним идёшь заметно быстрее. Держать в руке"));
        PROSTHETIC_ARM = reg("prosthetic_arm", new Tip(new Item.Settings().maxCount(1), "Крюк на культю руки: надеть в панели здоровья, когда культя заживёт"));
        PROSTHETIC_LEG = reg("prosthetic_leg", new Tip(new Item.Settings().maxCount(1), "Протез ноги: надеть в панели здоровья, когда культя заживёт"));
        Identifier s = Identifier.of(ZomboidMod.MOD_ID, "bone_saw");
        SAW_SOUND = Registry.register(Registries.SOUND_EVENT, s, SoundEvent.of(s));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
            e.add(CRUTCH);
            e.add(PROSTHETIC_ARM);
            e.add(PROSTHETIC_LEG);
        });
    }

    private static Item reg(String id, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(ZomboidMod.MOD_ID, id), item);
    }

    static class Tip extends Item {
        private final String tip;

        Tip(Settings settings, String tip) {
            super(settings);
            this.tip = tip;
        }

        @Override
        public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
            tooltip.add(Text.literal(tip).formatted(Formatting.GRAY));
        }
    }

    // ------------------------------------------------------------------ части тела и конечности

    /** К какой конечности относится часть тела; -1 — голова или туловище. */
    public static int limbOf(BodyPart p) {
        return switch (p) {
            case L_UPPER_ARM, L_FOREARM, L_HAND -> 0;
            case R_UPPER_ARM, R_FOREARM, R_HAND -> 1;
            case L_THIGH, L_SHIN, L_FOOT -> 2;
            case R_THIGH, R_SHIN, R_FOOT -> 3;
            default -> -1;
        };
    }

    public static BodyPart[] partsOf(int limb) {
        return switch (limb) {
            case 0 -> new BodyPart[]{BodyPart.L_UPPER_ARM, BodyPart.L_FOREARM, BodyPart.L_HAND};
            case 1 -> new BodyPart[]{BodyPart.R_UPPER_ARM, BodyPart.R_FOREARM, BodyPart.R_HAND};
            case 2 -> new BodyPart[]{BodyPart.L_THIGH, BodyPart.L_SHIN, BodyPart.L_FOOT};
            default -> new BodyPart[]{BodyPart.R_THIGH, BodyPart.R_SHIN, BodyPart.R_FOOT};
        };
    }

    public static String name(int limb) {
        return switch (limb) {
            case 0 -> "левая рука";
            case 1 -> "правая рука";
            case 2 -> "левая нога";
            default -> "правая нога";
        };
    }

    public static boolean lost(PlayerHealth h, int limb) {
        return limb >= 0 && (h.lost & (1 << limb)) != 0;
    }

    /** Рана пришлась бы в отнятую конечность — достаётся туловищу. */
    public static BodyPart redirect(PlayerHealth h, BodyPart part) {
        int limb = limbOf(part);
        if (!lost(h, limb)) return part;
        return limb < 2 ? BodyPart.UPPER_TORSO : BodyPart.GROIN;
    }

    /** Биты для отрисовки и движений: чего нет (16..19) и где протезы (20..23). */
    public static int flags(PlayerHealth h) {
        return ((h.lost & 15) << SHIFT_LOST) | ((h.prosthetic & h.lost & 15) << SHIFT_PROS);
    }

    /** Чего у игрока нет: на сервере — из его здоровья, на клиенте — из присланного состояния. */
    public static int lostBits(PlayerEntity p) {
        if (p instanceof ServerPlayerEntity sp) {
            if (sp.getServer() == null) return 0;
            return Wounds.health(sp).lost & 15;
        }
        if (CLIENT.isEmpty()) return 0;
        return (CLIENT.getOrDefault(p.getId(), 0) >> SHIFT_LOST) & 15;
    }

    public static int prosBits(PlayerEntity p) {
        if (p instanceof ServerPlayerEntity sp) {
            if (sp.getServer() == null) return 0;
            PlayerHealth h = Wounds.health(sp);
            return h.prosthetic & h.lost & 15;
        }
        return (CLIENT.getOrDefault(p.getId(), 0) >> SHIFT_PROS) & 15;
    }

    /** Сколько секунд осталось, чтобы успеть отнять укушенную конечность (0 — нечего или поздно). */
    public static int windowSeconds(PlayerHealth h) {
        if (!h.zombieInfected || h.infectLimb < 0 || h.infectLimb > 3 || lost(h, h.infectLimb)) return 0;
        return Math.max(0, Math.round((WINDOW - h.zombieHours) * Wounds.hourSeconds));
    }

    // ------------------------------------------------------------------ действия из панели здоровья

    public static void menu(ServerPlayerEntity p, int part, int action) {
        int limb = limbOf(BodyPart.values()[part]);
        if (limb < 0 || !p.isAlive() || p.isSpectator()) return;
        switch (action) {
            case CUT -> cut(p, limb);
            case ATTACH -> attach(p, limb);
            case DETACH -> detach(p, limb);
            default -> {
            }
        }
    }

    /** Чем резать: 2 — пила, 1 — топор или тесак (грубо), 0 — нечем. */
    public static int tool(PlayerEntity p) {
        int best = 0;
        for (int i = 0; i < p.getInventory().size(); i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (st.isEmpty()) continue;
            if (st.isOf(CarpentryItems.SAW)) return 2;
            if (st.getItem() instanceof PzAxeItem || (st.getItem() instanceof PzWeaponItem w && w.hitKind() == Limbs.Hit.BLADE && !w.shortBlade())) best = 1;
        }
        return best;
    }

    private static void say(ServerPlayerEntity p, String s, Formatting f) {
        p.sendMessage(Text.literal(s).formatted(f), true);
    }

    private static void cut(ServerPlayerEntity p, int limb) {
        PlayerHealth h = Wounds.health(p);
        if (lost(h, limb)) return;
        boolean arm = limb < 2;
        int other = limb ^ 1;
        if (lost(h, other)) {
            say(p, arm ? "Одной рукой себе руку не отнять" : "Вторую ногу не отнять — не на чем будет стоять", Formatting.RED);
            return;
        }
        if (Knockdown.down(p) || p.hasVehicle()) {
            say(p, "Сейчас не выйдет", Formatting.RED);
            return;
        }
        int tool = p.isCreative() ? 2 : tool(p);
        if (tool == 0) {
            say(p, "Нужна пила, топор или тесак", Formatting.RED);
            return;
        }
        // пила тупится
        if (tool == 2 && !p.isCreative()) {
            for (int i = 0; i < p.getInventory().size(); i++) {
                ItemStack st = p.getInventory().getStack(i);
                if (st.isOf(CarpentryItems.SAW)) {
                    st.setDamage(st.getDamage() + 25);
                    if (st.getDamage() >= st.getMaxDamage()) st.decrement(1);
                    break;
                }
            }
        }
        // конечности больше нет; на её месте — культя
        boolean bitten = false;
        for (BodyPart b : partsOf(limb)) {
            PartState s = h.parts[b.ordinal()];
            if (s.wound() == WoundType.BITE) bitten = true;
            s.clearWound();
            s.fracture = false;
            s.splinted = false;
            s.herbs = 0;
        }
        h.lost |= 1 << limb;
        h.prosthetic &= ~(1 << limb);
        PartState stump = h.parts[partsOf(limb)[0].ordinal()];
        stump.type = WoundType.DEEP.ordinal();
        stump.healLeft = WoundType.DEEP.rollHours(p.getRandom()) * 1.5f;
        // успел ли
        String result;
        if (h.zombieInfected && h.infectLimb == limb) {
            if (h.zombieHours <= WINDOW) {
                h.zombieInfected = false;
                h.zombieHours = 0;
                h.infectLimb = -1;
                result = "Успел. Зараза осталась в отрезанной " + (arm ? "руке" : "ноге") + ".";
            } else result = "Поздно: зараза уже пошла по телу.";
        } else if (bitten) result = "Укушенной " + (arm ? "руки" : "ноги") + " больше нет.";
        else result = (arm ? "Руки" : "Ноги") + " больше нет.";
        // кровь, боль, крик
        ServerWorld w = (ServerWorld) p.getWorld();
        Vec3d at = p.getPos().add(0, arm ? 1.2 : 0.5, 0);
        Combat.gore(w, at, 40, 0.2);
        Combat.stain(w, p.getBlockPos(), p.getRandom());
        w.playSound(null, p.getBlockPos(), SAW_SOUND, SoundCategory.PLAYERS, 1.0f, tool == 2 ? 1.0f : 0.8f);
        w.playSound(null, p.getBlockPos(), Combat.CHOP, SoundCategory.PLAYERS, 1.0f, 0.9f);
        boolean numb = h.painLeft > 0f || Mood.drunk(Survival.mood(p).drunk) >= 2;
        if (!p.isCreative()) {
            float dmg = Math.min(tool == 2 ? 7f : 10f, Math.max(0f, p.getHealth() - 2f));
            if (dmg > 0f) p.damage(p.getDamageSources().generic(), dmg);
            if (!numb) {
                w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_HURT, SoundCategory.PLAYERS, 1.4f, 0.7f);
                Noise.emitAt(w, p.getBlockPos(), 30);                     // крик слышно далеко
                Knockdown.knock(p, false, 120, "Ты теряешь сознание от боли");
                result += " От боли темнеет в глазах.";
            } else Noise.emitAt(w, p.getBlockPos(), 10);
        }
        if (arm) emptyOffhand(p);
        Wounds.changed(p);
        apply(p);
        say(p, result + " Зашей культю, пока не истёк кровью.", Formatting.RED);
    }

    private static void attach(ServerPlayerEntity p, int limb) {
        PlayerHealth h = Wounds.health(p);
        if (!lost(h, limb) || (h.prosthetic & (1 << limb)) != 0) return;
        if (h.parts[partsOf(limb)[0].ordinal()].wound() != WoundType.NONE) {
            say(p, "Культя ещё не зажила — протез не надеть", Formatting.RED);
            return;
        }
        Item item = limb < 2 ? PROSTHETIC_ARM : PROSTHETIC_LEG;
        if (!p.isCreative()) {
            boolean found = false;
            for (int i = 0; i < p.getInventory().size() && !found; i++) {
                ItemStack st = p.getInventory().getStack(i);
                if (st.isOf(item)) {
                    st.decrement(1);
                    found = true;
                }
            }
            if (!found) {
                say(p, "Нет протеза", Formatting.RED);
                return;
            }
        }
        h.prosthetic |= 1 << limb;
        p.getWorld().playSound(null, p.getBlockPos(), SoundEvents.ITEM_ARMOR_EQUIP_IRON.value(), SoundCategory.PLAYERS, 0.9f, 0.9f);
        Wounds.changed(p);
        apply(p);
        say(p, limb < 2 ? "Крюк надет: вторая рука снова при деле" : "Протез надет: можно ходить без костыля", Formatting.GREEN);
    }

    private static void detach(ServerPlayerEntity p, int limb) {
        PlayerHealth h = Wounds.health(p);
        if ((h.prosthetic & (1 << limb)) == 0) return;
        h.prosthetic &= ~(1 << limb);
        ItemStack st = new ItemStack(limb < 2 ? PROSTHETIC_ARM : PROSTHETIC_LEG);
        if (!p.getInventory().insertStack(st)) p.dropItem(st, false);
        Wounds.changed(p);
        apply(p);
        say(p, "Протез снят", Formatting.GRAY);
    }

    // ------------------------------------------------------------------ жизнь без конечности

    private static void emptyOffhand(ServerPlayerEntity p) {
        ItemStack off = p.getOffHandStack();
        if (off.isEmpty()) return;
        ItemStack st = off.copy();
        p.getInventory().offHand.set(0, ItemStack.EMPTY);
        if (!p.getInventory().insertStack(st)) p.dropItem(st, false);
        say(p, "Вторую руку занять нечем — вещь убрана", Formatting.GRAY);
    }

    /** Оружие, которому нужны обе руки. */
    public static boolean twoHanded(ItemStack st) {
        Item i = st.getItem();
        if (i instanceof PzAxeItem a) return a.heavy();
        if (i instanceof PzWeaponItem w) return w.twoHanded();
        if (i instanceof GunItem g) return g.action != GunItem.Action.SLIDE && g.action != GunItem.Action.REVOLVER;
        return false;
    }

    private static void mod(ServerPlayerEntity p, RegistryEntry<EntityAttribute> attr, Identifier id, double value) {
        EntityAttributeInstance inst = p.getAttributeInstance(attr);
        if (inst == null) return;
        EntityAttributeModifier cur = inst.getModifier(id);
        if (cur != null && Math.abs(cur.value() - value) < 1e-6) return;
        if (cur != null) inst.removeModifier(id);
        if (value != 0) inst.addTemporaryModifier(new EntityAttributeModifier(id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
    }

    /** Раз в секунду: что даётся труднее без руки или ноги. */
    public static void apply(ServerPlayerEntity p) {
        PlayerHealth h = Wounds.health(p);
        int lost = h.lost & 15, pros = h.prosthetic & lost;
        double speed = 0, attack = 0, damage = 0;
        if (lost != 0 && !p.isCreative()) {
            int arms = lost & 3, legs = lost & 12;
            if (arms != 0) {
                boolean hook = (pros & arms) == arms;
                if (!hook) emptyOffhand(p);
                attack = hook ? -0.12 : -0.30;
                if (twoHanded(p.getMainHandStack())) damage = hook ? -0.15 : -0.40;
            }
            if (legs != 0) {
                boolean peg = (pros & legs) == legs;
                boolean crutch = p.getMainHandStack().isOf(CRUTCH) || p.getOffHandStack().isOf(CRUTCH);
                speed = peg ? (crutch ? -0.10 : -0.15) : crutch ? -0.30 : -0.55;
            }
        }
        mod(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, SPEED, speed);
        mod(p, EntityAttributes.GENERIC_ATTACK_SPEED, ATTACK, attack);
        mod(p, EntityAttributes.GENERIC_ATTACK_DAMAGE, DAMAGE, damage);
    }
}
