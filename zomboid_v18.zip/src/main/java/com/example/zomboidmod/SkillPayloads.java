package com.example.zomboidmod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Сетевые пакеты навыков. */
public final class SkillPayloads {
    private SkillPayloads() {
    }

    /** Сервер -> клиент: "профессия;выбрана;ур:прогресс_‰:множитель,..." */
    public record Sync(String data) implements CustomPayload {
        public static final Id<Sync> ID = new Id<>(Identifier.of(ZomboidMod.MOD_ID, "skills"));
        public static final PacketCodec<RegistryByteBuf, Sync> CODEC =
                PacketCodec.tuple(PacketCodecs.STRING, Sync::data, Sync::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Сервер -> клиент: открыть выбор профессии. */
    public record Prompt() implements CustomPayload {
        public static final Id<Prompt> ID = new Id<>(Identifier.of(ZomboidMod.MOD_ID, "choose_profession"));
        public static final PacketCodec<RegistryByteBuf, Prompt> CODEC = PacketCodec.unit(new Prompt());

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    /** Клиент -> сервер: выбранная профессия. */
    public record Choose(int profession, long traits) implements CustomPayload {
        public static final Id<Choose> ID = new Id<>(Identifier.of(ZomboidMod.MOD_ID, "set_profession"));
        public static final PacketCodec<RegistryByteBuf, Choose> CODEC =
                PacketCodec.tuple(PacketCodecs.INTEGER, Choose::profession, PacketCodecs.VAR_LONG, Choose::traits, Choose::new);

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }
}
