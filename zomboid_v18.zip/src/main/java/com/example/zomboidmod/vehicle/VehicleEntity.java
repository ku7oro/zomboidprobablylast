package com.example.zomboidmod.vehicle;

import com.example.zomboidmod.Noise;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Машина или мотоцикл. Едет тот, кто сидит за рулём (W/S — газ и тормоз/задний ход, A/D — руль, пробел — гудок).
 * Топливо, прочность, багажник (Shift+ПКМ), сбивает зомби, разбивается о стены.
 */
public class VehicleEntity extends Entity {
    private static final TrackedData<Float> FUEL = DataTracker.registerData(VehicleEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Float> HEALTH = DataTracker.registerData(VehicleEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Integer> COLOR = DataTracker.registerData(VehicleEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Boolean> ENGINE = DataTracker.registerData(VehicleEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    public static final int[] COLORS = {0x8A1E22, 0x1F3550, 0xD8D6CC, 0x9EA2A6, 0x2E4A34, 0x5A3C28, 0x1C1C20, 0xC9B98E, 0x2F6F78,
            0x6E2A4A, 0xB45A1E, 0x44484E};

    public final VehicleType type;
    private final SimpleInventory trunk;
    private float speed;
    private float yawVelocity;
    // визуал (клиент)
    public float wheelAngle, prevWheelAngle, steer, prevSteer, clientSpeed;
    // сервер: расчёт реальной скорости и ударов
    private double lastX = Double.NaN, lastZ;
    private float lastSpeed;
    private int crashCooldown, hornCooldown;
    // плавное движение у остальных игроков
    private int lerpTicks;
    private double lerpX, lerpY, lerpZ;
    private float lerpYaw;

    public VehicleEntity(EntityType<? extends VehicleEntity> entityType, World world) {
        super(entityType, world);
        this.type = VehicleType.of(entityType);
        this.trunk = new SimpleInventory(Math.max(9, this.type.trunk));
        this.intersectionChecked = true;
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(FUEL, 0f);
        builder.add(HEALTH, 100f);
        builder.add(COLOR, 0xD8D6CC);
        builder.add(ENGINE, false);
    }

    // ===== состояние =====
    public float fuel() {
        return this.dataTracker.get(FUEL);
    }

    public void setFuel(float f) {
        this.dataTracker.set(FUEL, MathHelper.clamp(f, 0f, type.fuelCap));
    }

    public float health() {
        return this.dataTracker.get(HEALTH);
    }

    public void setHealth(float h) {
        this.dataTracker.set(HEALTH, MathHelper.clamp(h, 0f, type.maxHealth));
    }

    public int color() {
        return this.dataTracker.get(COLOR);
    }

    public void setColor(int c) {
        this.dataTracker.set(COLOR, c);
    }

    public boolean engineOn() {
        return this.dataTracker.get(ENGINE);
    }

    public boolean broken() {
        return health() <= 0f;
    }

    /** Настройка при появлении в городе: цвет, немного топлива, износ, вещи в багажнике. */
    public void randomize(Random r, boolean wreck) {
        if (type == VehicleType.POLICE) setColor(0x1C1C20);
        else if (type == VehicleType.AMBULANCE) setColor(0xEEEEEA);
        else setColor(COLORS[r.nextInt(COLORS.length)]);
        setFuel(wreck ? 0f : type.fuelCap * (r.nextFloat() < 0.25f ? 0f : 0.05f + r.nextFloat() * 0.55f));
        setHealth(type.maxHealth * (wreck ? 0.05f + r.nextFloat() * 0.2f : 0.35f + r.nextFloat() * 0.6f));
    }

    public SimpleInventory trunk() {
        return trunk;
    }

    // ===== физика =====
    @Override
    public float getStepHeight() {
        return 1.0f;
    }

    @Override
    public boolean isCollidable() {
        return true;
    }

    @Override
    public boolean canHit() {
        return !this.isRemoved();
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public EntityDimensions getDimensions(EntityPose pose) {
        return EntityDimensions.changing(type.width, type.height);
    }

    private float grip(BlockState s) {
        if (s.isOf(Blocks.ICE) || s.isOf(Blocks.PACKED_ICE) || s.isOf(Blocks.BLUE_ICE)) return 0.9f;
        if (s.isIn(BlockTags.SAND) || s.isOf(Blocks.SNOW_BLOCK) || s.isOf(Blocks.MUD) || s.isOf(Blocks.FARMLAND)) return 0.45f;
        if (s.isOf(Blocks.GRASS_BLOCK) || s.isIn(BlockTags.DIRT) || s.isOf(Blocks.GRAVEL) || s.isOf(Blocks.COARSE_DIRT)
                || s.isOf(Blocks.DIRT_PATH) || s.isIn(BlockTags.LEAVES)) return 0.7f;
        return 1.0f;
    }

    private boolean canDrive() {
        return fuel() > 0f && !broken();
    }

    private void physics() {
        LivingEntity d = getControllingPassenger();
        float throttle = 0f, steerIn = 0f;
        if (d instanceof PlayerEntity p && canDrive()) {
            throttle = p.forwardSpeed;
            steerIn = p.sidewaysSpeed;
        }
        boolean ground = this.isOnGround();
        BlockState under = getWorld().getBlockState(BlockPos.ofFloored(getX(), getY() - 0.2, getZ()));
        float g = grip(under);
        float max = type.maxSpeed * (type.offroad ? Math.max(g, 0.9f) : g) * (health() < type.maxHealth * 0.25f ? 0.6f : 1f);
        if (ground) {
            if (throttle > 0.05f) speed += type.accel * throttle * (speed < 0 ? 3f : 1f);
            else if (throttle < -0.05f) speed += speed > 0.02f ? -0.045f : type.accel * 0.6f * throttle;
            speed *= Math.abs(throttle) < 0.05f ? 0.982f : 0.996f;
            if (g < 0.8f) speed *= 0.992f;
            speed = MathHelper.clamp(speed, -max * 0.35f, max);
            if (Math.abs(speed) < 0.003f && Math.abs(throttle) < 0.05f) speed = 0f;
            float k = MathHelper.clamp(Math.abs(speed) / 0.16f, 0f, 1f) * Math.signum(speed);
            float hi = 1.15f - 0.45f * Math.abs(speed) / type.maxSpeed;
            yawVelocity = -steerIn * type.turn * k * hi;
        } else {
            speed *= 0.995f;
            yawVelocity *= 0.85f;
        }
        setYaw(getYaw() + yawVelocity);
        double rad = Math.toRadians(getYaw());
        double vy = ground ? -0.05 : getVelocity().y - 0.08;
        if (isTouchingWater()) {
            speed *= 0.85f;
            vy = Math.max(vy, -0.06);
        }
        setVelocity(-Math.sin(rad) * speed, Math.max(vy, -3.0), Math.cos(rad) * speed);
    }

    @Override
    public void tick() {
        super.tick();
        prevWheelAngle = wheelAngle;
        prevSteer = steer;
        lerpStep();
        if (this.isLogicalSideForUpdatingMovement()) {
            physics();
            this.move(MovementType.SELF, this.getVelocity());
            if (this.horizontalCollision && Math.abs(speed) > 0.06f) speed *= -0.3f;
        } else {
            this.setVelocity(Vec3d.ZERO);
        }
        this.tickBlockCollision();

        if (getWorld().isClient) clientVisuals();
        else serverTick();
    }

    private void clientVisuals() {
        double dx = getX() - prevX, dz = getZ() - prevZ;
        double rad = Math.toRadians(getYaw());
        double fwd = -Math.sin(rad) * dx + Math.cos(rad) * dz;
        clientSpeed = (float) Math.sqrt(dx * dx + dz * dz);
        wheelAngle += (float) (fwd * 32.0 / type.wheelRadius);
        float yawRate = MathHelper.wrapDegrees(getYaw() - prevYaw);
        float target = MathHelper.clamp(-yawRate / type.turn, -1f, 1f);
        steer += (target - steer) * 0.35f;
        // выхлоп и дым от разбитой машины
        if (engineOn() && age % 3 == 0) {
            Vec3d back = new Vec3d(type.bike() ? -0.25 : -0.5, 0.25, -(type.bike() ? 1.4 : 2.4)).rotateY(-getYaw() * MathHelper.RADIANS_PER_DEGREE);
            getWorld().addParticle(ParticleTypes.SMOKE, getX() + back.x, getY() + back.y, getZ() + back.z, 0, 0.02, 0);
        }
        if (health() < type.maxHealth * 0.3f && age % 4 == 0) {
            Vec3d front = new Vec3d(0, type.height * 0.6, type.bike() ? 0.6 : 1.8).rotateY(-getYaw() * MathHelper.RADIANS_PER_DEGREE);
            getWorld().addParticle(broken() ? ParticleTypes.LARGE_SMOKE : ParticleTypes.SMOKE,
                    getX() + front.x, getY() + front.y, getZ() + front.z, 0, 0.05, 0);
        }
    }

    private void serverTick() {
        if (Double.isNaN(lastX)) {
            lastX = getX();
            lastZ = getZ();
        }
        double dx = getX() - lastX, dz = getZ() - lastZ;
        lastX = getX();
        lastZ = getZ();
        float spd = (float) Math.sqrt(dx * dx + dz * dz);
        if (spd > 4f) spd = 0f;
        boolean driven = getControllingPassenger() != null;
        boolean run = driven && canDrive();
        if (run != engineOn()) {
            this.dataTracker.set(ENGINE, run);
            if (run) getWorld().playSound(null, getBlockPos(), Vehicles.ENGINE_START, SoundCategory.NEUTRAL, 1f, type.bike() ? 1.3f : 1f);
        }
        if (run) setFuel(fuel() - 0.0004f - spd * type.fuelPerBlock());
        if (crashCooldown > 0) crashCooldown--;
        if (hornCooldown > 0) hornCooldown--;

        // удар о препятствие: резкая потеря скорости
        if (lastSpeed > 0.3f && spd < lastSpeed * 0.4f && crashCooldown == 0) {
            float impact = lastSpeed - spd;
            setHealth(health() - impact * 55f);
            for (Entity p : getPassengerList()) p.damage(getDamageSources().flyIntoWall(), impact * (type.bike() ? 18f : 10f));
            getWorld().playSound(null, getBlockPos(), Vehicles.CRASH, SoundCategory.NEUTRAL, 1.2f, 0.9f + random.nextFloat() * 0.2f);
            if (getWorld() instanceof ServerWorld sw) Noise.emitAt(sw, getBlockPos(), 45);
            crashCooldown = 20;
        }
        // сбивает тех, кто на дороге
        if (spd > 0.12f) {
            Box box = getBoundingBox().expand(0.25, 0.0, 0.25);
            List<Entity> hit = getWorld().getOtherEntities(this, box,
                    e -> e instanceof LivingEntity && e.isAlive() && !this.hasPassenger(e) && !(e.getVehicle() instanceof VehicleEntity));
            LivingEntity driver = getControllingPassenger();
            for (Entity e : hit) {
                DamageSource src = driver instanceof PlayerEntity pl ? getDamageSources().playerAttack(pl) : getDamageSources().generic();
                e.damage(src, spd * 32f);
                Vec3d push = new Vec3d(dx, 0, dz).normalize().multiply(spd * 1.8);
                e.addVelocity(push.x, 0.25 + spd * 0.4, push.z);
                e.velocityModified = true;
                setHealth(health() - spd * 3f);
                getWorld().playSound(null, e.getBlockPos(), Vehicles.CRASH, SoundCategory.NEUTRAL, 0.6f, 1.4f);
            }
        }
        lastSpeed = spd;
        if (run && age % 20 == 0 && getWorld() instanceof ServerWorld sw) Noise.emitAt(sw, getBlockPos(), 26 + (int) (spd * 40));
    }

    /** Гудок: громко, зомби слышат издалека (как в PZ). */
    public void honk() {
        if (hornCooldown > 0 || broken()) return;
        hornCooldown = 12;
        getWorld().playSound(null, getBlockPos(), Vehicles.HORN, SoundCategory.NEUTRAL, 2.5f, type.bike() ? 1.25f : 1f);
        if (getWorld() instanceof ServerWorld sw) Noise.emitAt(sw, getBlockPos(), 70);
    }

    // ===== плавность у наблюдателей =====
    @Override
    public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int interpolationSteps) {
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYaw = yaw;
        this.lerpTicks = 10;
    }

    private void lerpStep() {
        if (this.isLogicalSideForUpdatingMovement()) {
            this.lerpTicks = 0;
            this.updateTrackedPosition(this.getX(), this.getY(), this.getZ());
        }
        if (this.lerpTicks > 0) {
            double t = 1.0 / this.lerpTicks;
            this.setPosition(getX() + (lerpX - getX()) * t, getY() + (lerpY - getY()) * t, getZ() + (lerpZ - getZ()) * t);
            this.setYaw(getYaw() + MathHelper.wrapDegrees(lerpYaw - getYaw()) * (float) t);
            this.lerpTicks--;
        }
    }

    // ===== пассажиры =====
    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return this.getPassengerList().size() < type.seats.length;
    }

    @Override
    public @Nullable LivingEntity getControllingPassenger() {
        return this.getFirstPassenger() instanceof PlayerEntity p ? p : null;
    }

    @Override
    protected Vec3d getPassengerAttachmentPos(Entity passenger, EntityDimensions dimensions, float scaleFactor) {
        int i = Math.max(0, this.getPassengerList().indexOf(passenger));
        float[] s = type.seats[Math.min(i, type.seats.length - 1)];
        return new Vec3d(s[0], s[1], s[2]).rotateY(-this.getYaw() * MathHelper.RADIANS_PER_DEGREE);
    }

    @Override
    protected void updatePassengerPosition(Entity passenger, Entity.PositionUpdater positionUpdater) {
        super.updatePassengerPosition(passenger, positionUpdater);
        passenger.setYaw(passenger.getYaw() + this.yawVelocity);
        passenger.setHeadYaw(passenger.getHeadYaw() + this.yawVelocity);
        clampPassenger(passenger);
    }

    private void clampPassenger(Entity passenger) {
        passenger.setBodyYaw(this.getYaw());
        float f = MathHelper.wrapDegrees(passenger.getYaw() - this.getYaw());
        float g = MathHelper.clamp(f, -120f, 120f);
        passenger.prevYaw += g - f;
        passenger.setYaw(passenger.getYaw() + g - f);
        passenger.setHeadYaw(passenger.getYaw());
    }

    @Override
    public void onPassengerLookAround(Entity passenger) {
        clampPassenger(passenger);
    }

    @Override
    public Vec3d updatePassengerForDismount(LivingEntity passenger) {
        int i = Math.max(0, this.getPassengerList().indexOf(passenger));
        float[] s = type.seats[Math.min(i, type.seats.length - 1)];
        double side = (s[0] >= 0 ? 1 : -1) * (type.width * 0.5 + 0.55);
        for (double sd : new double[]{side, -side}) {
            Vec3d off = new Vec3d(sd, 0, s[2]).rotateY(-this.getYaw() * MathHelper.RADIANS_PER_DEGREE);
            Vec3d target = this.getPos().add(off);
            Box b = passenger.getDimensions(EntityPose.STANDING).getBoxAt(target);
            if (getWorld().isSpaceEmpty(passenger, b)) return target;
        }
        return super.updatePassengerForDismount(passenger);
    }

    // ===== взаимодействие =====
    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        ItemStack st = player.getStackInHand(hand);
        if (st.getItem() instanceof GasCanItem) {
            if (!getWorld().isClient) GasCanItem.pourInto(st, this, player);
            return ActionResult.success(getWorld().isClient);
        }
        if (player.shouldCancelInteraction()) {
            if (type.trunk <= 0) return ActionResult.PASS;
            if (!getWorld().isClient) {
                int rows = Math.max(1, Math.min(4, type.trunk / 9));
                ScreenHandlerType<?> ht = rows == 1 ? ScreenHandlerType.GENERIC_9X1 : rows == 2 ? ScreenHandlerType.GENERIC_9X2
                        : rows == 3 ? ScreenHandlerType.GENERIC_9X3 : ScreenHandlerType.GENERIC_9X4;
                player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                        (syncId, inv, p) -> new GenericContainerScreenHandler(ht, syncId, inv, trunk, rows),
                        Text.translatable("container.zomboidmod.trunk")));
            }
            return ActionResult.success(getWorld().isClient);
        }
        if (!getWorld().isClient) return player.startRiding(this) ? ActionResult.CONSUME : ActionResult.PASS;
        return ActionResult.SUCCESS;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (this.isInvulnerableTo(source) || getWorld().isClient || this.isRemoved()) return false;
        if (source.getAttacker() instanceof PlayerEntity p && p.getAbilities().creativeMode && p.isSneaking()) {
            ItemScatterer.spawn(getWorld(), this, trunk);
            this.discard();
            return true;
        }
        setHealth(health() - amount * 0.4f);
        this.scheduleVelocityUpdate();
        return true;
    }

    // ===== сохранение =====
    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        setFuel(nbt.getFloat("Fuel"));
        setHealth(nbt.contains("Health") ? nbt.getFloat("Health") : type.maxHealth);
        if (nbt.contains("Color")) setColor(nbt.getInt("Color"));
        trunk.getHeldStacks().clear();
        Inventories.readNbt(nbt, trunk.getHeldStacks(), this.getRegistryManager());
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putFloat("Fuel", fuel());
        nbt.putFloat("Health", health());
        nbt.putInt("Color", color());
        Inventories.writeNbt(nbt, trunk.getHeldStacks(), this.getRegistryManager());
    }
}
