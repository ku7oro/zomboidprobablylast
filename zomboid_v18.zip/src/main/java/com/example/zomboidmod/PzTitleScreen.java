package com.example.zomboidmod;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.SharedConstants;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

/** Главное меню в мрачном стиле: ночной городок, ползущий туман, список пунктов слева. Арт оригинальный. */
public class PzTitleScreen extends Screen {
    private static final Identifier BG = GuiUtil.gui("menu/menu_background");
    private static final Identifier FOG = GuiUtil.gui("menu/menu_fog");
    private static final Identifier TITLE = GuiUtil.gui("menu/menu_title");

    private static final String[] ITEMS = {"Одиночная игра", "Сетевая игра", "Настройки", "Выход"};
    private static final float ITEM_SCALE = 1.5f;
    private final long start = Util.getMeasuringTimeMs();
    private int itemX, itemY0, itemStep, itemW;

    public PzTitleScreen() {
        super(Text.literal("Zomboid Survival"));
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        float t = (Util.getMeasuringTimeMs() - start) / 1000f;
        RenderSystem.enableBlend();

        // фон: заполняет экран (16:9), медленно «дышит» и смещается
        float zoom = 1.06f + 0.02f * (float) Math.sin(t * 0.05);
        int bw = (int) (Math.max(this.width, this.height * 16 / 9f) * zoom);
        int bh = bw * 9 / 16;
        int bx = (this.width - bw) / 2 + (int) (Math.sin(t * 0.03) * bw * 0.01);
        int by = (this.height - bh) / 2;
        ctx.drawTexture(BG, bx, by, bw, bh, 0f, 0f, 1280, 720, 1280, 720);

        // туман ползёт по земле в две стороны
        int fh = (int) (this.height * 0.45);
        int fy = this.height - fh;
        int fw = fh * 4;
        int off1 = (int) ((t * 9) % fw), off2 = (int) ((t * 5) % fw);
        RenderSystem.setShaderColor(1f, 1f, 1f, 0.8f);
        for (int x = -off1; x < this.width; x += fw) ctx.drawTexture(FOG, x, fy, fw, fh, 0f, 0f, 1024, 256, 1024, 256);
        RenderSystem.setShaderColor(1f, 1f, 1f, 0.5f);
        for (int x = -fw + off2; x < this.width; x += fw) ctx.drawTexture(FOG, x, fy + fh / 6, fw, fh, 0f, 0f, 1024, 256, 1024, 256);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        // лёгкое мерцание, как у старого фонаря
        float flick = (float) (Math.sin(t * 7.3) * Math.sin(t * 2.1));
        if (flick > 0.85f) ctx.fill(0, 0, this.width, this.height, 0x18000000);
        RenderSystem.disableBlend();
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        RenderSystem.enableBlend();

        // заголовок
        int tw = Math.min(260, this.width / 2 - 20);
        int th = tw / 4;
        int tx = Math.max(16, this.width / 20), ty = Math.max(10, this.height / 10);
        ctx.drawTexture(TITLE, tx, ty, tw, th, 0f, 0f, 1024, 256, 1024, 256);
        ctx.drawTextWithShadow(this.textRenderer, "Здесь не выживают. Здесь тянут время.", tx + 4, ty + th + 6, 0xAAA096);

        // пункты меню
        itemX = tx;
        itemY0 = ty + th + 34;
        itemStep = (int) (14 * ITEM_SCALE);
        itemW = 170;
        for (int i = 0; i < ITEMS.length; i++) {
            int y = itemY0 + i * itemStep;
            boolean over = mx >= itemX && mx < itemX + itemW && my >= y - 3 && my < y + itemStep - 3;
            if (over) ctx.fill(itemX - 4, y - 3, itemX + itemW, y + itemStep - 4, 0xC0781412);
            MatrixStack m = ctx.getMatrices();
            m.push();
            m.translate(itemX + 4, y, 0);
            m.scale(ITEM_SCALE, ITEM_SCALE, 1f);
            ctx.drawTextWithShadow(this.textRenderer, ITEMS[i], 0, 0, over ? 0xFFFFFF : 0xC8C4BC);
            m.pop();
        }

        ctx.drawTextWithShadow(this.textRenderer, "Minecraft " + SharedConstants.getGameVersion().getName() + " · Zomboid Survival",
                4, this.height - 12, 0x787878);
        RenderSystem.disableBlend();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = 0; i < ITEMS.length; i++) {
            int y = itemY0 + i * itemStep;
            if (mx >= itemX && mx < itemX + itemW && my >= y - 3 && my < y + itemStep - 3) {
                MinecraftClient c = MinecraftClient.getInstance();
                switch (i) {
                    case 0 -> c.setScreen(new SelectWorldScreen(this));
                    case 1 -> c.setScreen(new MultiplayerScreen(this));
                    case 2 -> c.setScreen(new OptionsScreen(this, c.options));
                    default -> c.scheduleStop();
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
