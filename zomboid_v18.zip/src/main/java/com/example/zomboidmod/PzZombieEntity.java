package com.example.zomboidmod;

import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** Зомби в духе Project Zomboid: одежда, повадки (шатун, бегун, ползун), шум, вещи в карманах. */
public class PzZombieEntity extends ZombieEntity {
    private static final TrackedData<Integer> VARIANT =
            DataTracker.registerData(PzZombieEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private BlockPos noisePos;
    private int noiseTicks;
    private boolean lootRolled;

    public PzZombieEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(VARIANT, -1);
    }

    // ----- вариант: одежда | тон << 8 | повадки << 16 -----
    public int rawVariant() {
        return this.getDataTracker().get(VARIANT);
    }

    public ZombieOutfit outfit() {
        int v = rawVariant();
        ZombieOutfit[] a = ZombieOutfit.values();
        return v < 0 ? a[0] : a[Math.min(v & 255, a.length - 1)];
    }

    public int tone() {
        int v = rawVariant();
        return v < 0 ? 0 : (v >> 8) & 255;
    }

    public ZombieKind kind() {
        int v = rawVariant();
        ZombieKind[] a = ZombieKind.values();
        return v < 0 ? a[0] : a[Math.min((v >> 16) & 255, a.length - 1)];
    }

    public boolean isCrawler() {
        return this.getDataTracker() != null && kind() == ZombieKind.CRAWLER;
    }

    private void assign() {
        Random r = this.getRandom();
        ZombieOutfit outfit = ZombieOutfit.random(r);
        ZombieKind kind = ZombieKind.random(r);
        int tone = r.nextInt(3);
        this.getDataTracker().set(VARIANT, outfit.ordinal() | (tone << 8) | (kind.ordinal() << 16));

        setAttr(EntityAttributes.GENERIC_MAX_HEALTH, kind.health + outfit.bonusHealth);
        this.setHealth(this.getMaxHealth());
        setAttr(EntityAttributes.GENERIC_MOVEMENT_SPEED, kind.idleSpeed);
        setAttr(EntityAttributes.GENERIC_FOLLOW_RANGE, 20.0); // видят хуже ванильных
        if (kind == ZombieKind.CRAWLER) this.calculateDimensions();
    }

    /** Настроить зомби при спавне в здании: одежда по месту (полицейский в участке и т.п.), остальное случайно. */
    public void setup(ZombieOutfit outfit) {
        assign();
        if (outfit == null) return;
        int v = rawVariant();
        this.getDataTracker().set(VARIANT, (v & ~255) | outfit.ordinal());
        setAttr(EntityAttributes.GENERIC_MAX_HEALTH, kind().health + outfit.bonusHealth);
        this.setHealth(this.getMaxHealth());
    }

    private void setAttr(RegistryEntry<EntityAttribute> attr, double value) {
        EntityAttributeInstance inst = this.getAttributeInstance(attr);
        if (inst != null) inst.setBaseValue(value);
    }

    /** Зомби услышал шум в этой точке. */
    public void hear(BlockPos pos) {
        this.noisePos = pos.toImmutable();
        this.noiseTicks = 200;
    }

    @Override
    public void tick() {
        super.tick();

        if (!this.getWorld().isClient) {
            if (rawVariant() < 0) assign();
            ZombieKind kind = kind();

            // бегун: идёт шагом, пока не заметил жертву; иногда спотыкается
            if (kind == ZombieKind.SPRINTER && this.age % 10 == 0) {
                boolean chasing = this.getTarget() != null;
                setAttr(EntityAttributes.GENERIC_MOVEMENT_SPEED, chasing ? kind.chaseSpeed : kind.idleSpeed);
                if (chasing && this.getRandom().nextInt(60) == 0) {
                    this.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 6, false, false));
                }
            }

            // скрытность: крадущегося игрока замечают только вблизи
            if (this.age % 10 == 0 && this.getTarget() instanceof net.minecraft.server.network.ServerPlayerEntity sp
                    && sp.isSneaking() && this.getAttacker() != sp
                    && this.squaredDistanceTo(sp) > Math.pow(Skills.sneakDetectRange(sp), 2)) {
                this.setTarget(null);
            }
            if (this.age % 10 == 5 && this.getTarget() instanceof net.minecraft.server.network.ServerPlayerEntity sp2
                    && this.getAttacker() != sp2
                    && this.squaredDistanceTo(sp2) > Math.pow(Skills.inconspicuousRange(sp2), 2)) {
                this.setTarget(null);
            }

            // идёт на шум, если жертвы не видно
            if (noiseTicks > 0) {
                noiseTicks--;
                if (this.getTarget() == null && noisePos != null && this.age % 20 == 0) {
                    double nx = noisePos.getX() + 0.5, ny = noisePos.getY(), nz = noisePos.getZ() + 0.5;
                    if (this.squaredDistanceTo(nx, ny, nz) > 4.0) {
                        this.getNavigation().startMovingTo(nx, ny, nz, 1.0);
                    } else {
                        noiseTicks = 0;
                    }
                }
            }
        }

        // ползун ползёт по земле
        if (isCrawler()) this.setPose(EntityPose.SWIMMING);
    }

    @Override
    public EntityDimensions getBaseDimensions(EntityPose pose) {
        if (this.getDataTracker() != null && isCrawler()) return EntityDimensions.changing(0.7f, 0.6f);
        return super.getBaseDimensions(pose);
    }

    // Зомби не горят на солнце (как в PZ). Без @Override: сработает, если такие методы есть у родителя.
    public boolean isAffectedByDaylight() {
        return false;
    }

    public boolean burnsInDaylight() {
        return false;
    }

    public boolean shouldBurnInDay() {
        return false;
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        if (!this.getWorld().isClient && !lootRolled) {
            lootRolled = true;
            ZombieLoot.drop(this, outfit(), this.getRandom());
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("PzVariant", rawVariant());
        nbt.putBoolean("PzLootRolled", lootRolled);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("PzVariant")) this.getDataTracker().set(VARIANT, nbt.getInt("PzVariant"));
        lootRolled = nbt.getBoolean("PzLootRolled");
        if (isCrawler()) this.calculateDimensions();
    }
}
