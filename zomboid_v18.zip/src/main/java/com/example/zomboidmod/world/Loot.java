package com.example.zomboidmod.world;

import com.example.zomboidmod.LootItems;
import com.example.zomboidmod.ZomboidMod;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.random.Random;

import java.util.List;
import java.util.function.Supplier;

/** Лут по типу комнаты, как в PZ: на кухне еда и ножи, в ванной лекарства, в полиции оружие. */
public enum Loot {
    KITCHEN(2, 5, e(() -> Items.BREAD, 1, 2, .35f), e(() -> Items.APPLE, 1, 3, .3f), e(() -> Items.POTATO, 1, 4, .3f),
            e(() -> Items.CARROT, 1, 4, .25f), e(() -> Items.SUGAR, 1, 3, .2f), e(() -> Items.COOKIE, 2, 6, .15f),
            e(() -> ZomboidMod.KITCHEN_KNIFE, 1, 1, .2f), e(() -> ZomboidMod.FRYING_PAN, 1, 1, .1f),
            e(() -> ZomboidMod.CLEAN_WATER, 1, 2, .25f), e(() -> Items.GLASS_BOTTLE, 1, 3, .3f), e(() -> Items.BOWL, 1, 2, .2f),
            e(() -> LootItems.CANNED_BEANS, 1, 3, .35f), e(() -> LootItems.CANNED_SOUP, 1, 2, .3f), e(() -> LootItems.CANNED_TUNA, 1, 2, .25f),
            e(() -> LootItems.CAN_OPENER, 1, 1, .2f), e(() -> LootItems.CEREAL, 1, 2, .25f), e(() -> LootItems.CHIPS, 1, 3, .2f),
            e(() -> LootItems.BOOK_COOKING, 1, 1, .04f)),
    FRIDGE(1, 4, e(() -> Items.COOKED_BEEF, 1, 2, .2f), e(() -> Items.COOKED_CHICKEN, 1, 2, .2f), e(() -> Items.MILK_BUCKET, 1, 1, .15f),
            e(() -> Items.EGG, 2, 6, .3f), e(() -> Items.MELON_SLICE, 2, 5, .25f), e(() -> Items.ROTTEN_FLESH, 1, 3, .35f),
            e(() -> ZomboidMod.CLEAN_WATER, 1, 3, .4f), e(() -> Items.CARROT, 1, 3, .2f), e(() -> LootItems.SODA, 1, 4, .4f),
            e(() -> LootItems.WATER_BOTTLE, 1, 3, .35f), e(() -> LootItems.CHOCOLATE, 1, 2, .2f)),
    BEDROOM(1, 4, e(() -> ZomboidMod.RAG, 1, 3, .3f), e(() -> Items.LEATHER_CHESTPLATE, 1, 1, .08f), e(() -> Items.LEATHER_BOOTS, 1, 1, .08f),
            e(() -> Items.BOOK, 1, 2, .2f), e(() -> Items.CLOCK, 1, 1, .06f), e(() -> Items.STRING, 1, 3, .2f),
            e(() -> ZomboidMod.BASEBALL_BAT, 1, 1, .05f), e(() -> Items.WHITE_WOOL, 1, 3, .2f), e(() -> Items.PAPER, 1, 4, .2f),
            e(() -> LootItems.CHOCOLATE, 1, 2, .15f), e(() -> LootItems.BOOK_FISHING, 1, 1, .04f), e(() -> LootItems.BOOK_FIRST_AID, 1, 1, .04f)),
    BATHROOM(1, 4, e(() -> ZomboidMod.BANDAGE, 1, 3, .4f), e(() -> ZomboidMod.PAINKILLERS, 1, 2, .3f), e(() -> ZomboidMod.ANTISEPTIC, 1, 1, .25f),
            e(() -> ZomboidMod.ANTIBIOTICS, 1, 1, .06f), e(() -> ZomboidMod.RAG, 1, 3, .3f), e(() -> ZomboidMod.SUTURE_KIT, 1, 1, .06f)),
    LIVING(1, 3, e(() -> Items.BOOK, 1, 3, .3f), e(() -> Items.PAPER, 1, 5, .3f), e(() -> Items.CANDLE, 1, 3, .2f),
            e(() -> Items.TORCH, 2, 6, .2f), e(() -> Items.COOKIE, 1, 4, .15f), e(() -> Items.MAP, 1, 1, .05f),
            e(() -> LootItems.CHIPS, 1, 3, .3f), e(() -> LootItems.SODA, 1, 2, .25f), e(() -> LootItems.BOOK_COOKING, 1, 1, .05f),
            e(() -> LootItems.BOOK_FARMING, 1, 1, .04f), e(() -> LootItems.DUCT_TAPE, 1, 1, .08f)),
    GROCERY(3, 7, e(() -> Items.BREAD, 2, 5, .5f), e(() -> Items.DRIED_KELP, 3, 9, .35f), e(() -> Items.COOKIE, 3, 8, .35f),
            e(() -> Items.SUGAR, 2, 5, .3f), e(() -> Items.APPLE, 2, 6, .35f), e(() -> Items.POTATO, 2, 6, .3f),
            e(() -> Items.HONEY_BOTTLE, 1, 3, .2f), e(() -> Items.PUMPKIN_PIE, 1, 2, .15f), e(() -> ZomboidMod.CLEAN_WATER, 2, 5, .45f),
            e(() -> Items.WHEAT_SEEDS, 2, 8, .15f), e(() -> Items.ROTTEN_FLESH, 1, 4, .3f),
            e(() -> LootItems.CANNED_BEANS, 2, 6, .45f), e(() -> LootItems.CANNED_SOUP, 2, 5, .4f), e(() -> LootItems.CANNED_TUNA, 2, 5, .35f),
            e(() -> LootItems.CHIPS, 2, 6, .4f), e(() -> LootItems.CHOCOLATE, 2, 6, .35f), e(() -> LootItems.CEREAL, 1, 3, .3f),
            e(() -> LootItems.SODA, 2, 6, .4f), e(() -> LootItems.WATER_BOTTLE, 2, 6, .45f), e(() -> LootItems.CAN_OPENER, 1, 1, .15f)),
    PHARMACY(3, 7, e(() -> ZomboidMod.BANDAGE, 2, 5, .6f), e(() -> ZomboidMod.PAINKILLERS, 1, 4, .55f), e(() -> ZomboidMod.ANTIBIOTICS, 1, 3, .35f),
            e(() -> ZomboidMod.ANTISEPTIC, 1, 3, .45f), e(() -> ZomboidMod.SUTURE_KIT, 1, 2, .3f), e(() -> ZomboidMod.SPLINT, 1, 2, .2f),
            e(() -> ZomboidMod.CLEAN_WATER, 1, 3, .3f), e(() -> Items.SUGAR, 1, 3, .15f)),
    HARDWARE(3, 6, e(() -> ZomboidMod.HAMMER, 1, 1, .3f), e(() -> ZomboidMod.CROWBAR, 1, 1, .2f), e(() -> ZomboidMod.HAND_AXE, 1, 1, .2f),
            e(() -> Items.IRON_NUGGET, 4, 16, .45f), e(() -> Items.IRON_INGOT, 1, 4, .3f), e(() -> Items.OAK_PLANKS, 8, 32, .35f),
            e(() -> Items.STRING, 2, 8, .3f), e(() -> Items.SHEARS, 1, 1, .15f), e(() -> Items.BUCKET, 1, 1, .2f),
            e(() -> Items.FLINT_AND_STEEL, 1, 1, .15f), e(() -> Items.LANTERN, 1, 2, .2f), e(() -> Items.IRON_SHOVEL, 1, 1, .1f),
            e(() -> LootItems.DUCT_TAPE, 1, 3, .45f), e(() -> LootItems.CAN_OPENER, 1, 1, .2f)),
    DINER(2, 5, e(() -> Items.COOKED_BEEF, 1, 3, .3f), e(() -> Items.COOKED_PORKCHOP, 1, 3, .3f), e(() -> Items.BREAD, 1, 4, .4f),
            e(() -> Items.BAKED_POTATO, 1, 4, .3f), e(() -> ZomboidMod.KITCHEN_KNIFE, 1, 1, .25f), e(() -> ZomboidMod.FRYING_PAN, 1, 1, .2f),
            e(() -> Items.SUGAR, 1, 3, .2f), e(() -> Items.ROTTEN_FLESH, 1, 4, .35f), e(() -> ZomboidMod.CLEAN_WATER, 1, 3, .3f)),
    GAS(2, 5, e(() -> Items.COOKIE, 2, 6, .35f), e(() -> Items.DRIED_KELP, 2, 6, .3f), e(() -> ZomboidMod.CLEAN_WATER, 1, 3, .4f),
            e(() -> Items.COAL, 2, 8, .3f), e(() -> Items.FLINT_AND_STEEL, 1, 1, .15f), e(() -> Items.MAP, 1, 1, .2f),
            e(() -> Items.COMPASS, 1, 1, .1f), e(() -> ZomboidMod.CROWBAR, 1, 1, .06f), e(() -> Items.TORCH, 2, 8, .25f),
            e(() -> LootItems.CHIPS, 2, 5, .4f), e(() -> LootItems.SODA, 2, 5, .4f), e(() -> LootItems.CHOCOLATE, 1, 4, .35f),
            e(() -> LootItems.WATER_BOTTLE, 1, 4, .35f), e(() -> LootItems.DUCT_TAPE, 1, 1, .1f)),
    BAR(2, 5, e(() -> Items.GLASS_BOTTLE, 2, 6, .5f), e(() -> Items.HONEY_BOTTLE, 1, 3, .3f), e(() -> Items.COOKED_CHICKEN, 1, 2, .2f),
            e(() -> ZomboidMod.BASEBALL_BAT, 1, 1, .12f), e(() -> Items.BREAD, 1, 2, .2f)),
    OFFICE(1, 4, e(() -> Items.PAPER, 3, 12, .5f), e(() -> Items.BOOK, 1, 3, .35f), e(() -> Items.WRITABLE_BOOK, 1, 1, .15f),
            e(() -> Items.CLOCK, 1, 1, .1f), e(() -> Items.COMPASS, 1, 1, .08f), e(() -> Items.COOKIE, 1, 3, .2f), e(() -> ZomboidMod.PAINKILLERS, 1, 1, .1f),
            e(() -> LootItems.SODA, 1, 2, .25f), e(() -> LootItems.CHOCOLATE, 1, 2, .2f), e(() -> LootItems.BOOK_FIRST_AID, 1, 1, .06f),
            e(() -> LootItems.DUCT_TAPE, 1, 1, .1f)),
    CLOTHES(3, 6, e(() -> Items.LEATHER_HELMET, 1, 1, .3f), e(() -> Items.LEATHER_CHESTPLATE, 1, 1, .3f), e(() -> Items.LEATHER_LEGGINGS, 1, 1, .3f),
            e(() -> Items.LEATHER_BOOTS, 1, 1, .35f), e(() -> Items.WHITE_WOOL, 2, 8, .4f), e(() -> ZomboidMod.RAG, 2, 6, .4f), e(() -> Items.STRING, 2, 6, .3f)),
    POLICE(2, 6, e(() -> Items.CROSSBOW, 1, 1, .25f), e(() -> Items.ARROW, 6, 20, .5f), e(() -> ZomboidMod.CROWBAR, 1, 1, .2f),
            e(() -> Items.SHIELD, 1, 1, .2f), e(() -> Items.CHAINMAIL_CHESTPLATE, 1, 1, .12f), e(() -> Items.CHAINMAIL_HELMET, 1, 1, .12f),
            e(() -> ZomboidMod.BANDAGE, 1, 3, .35f), e(() -> ZomboidMod.PAINKILLERS, 1, 2, .2f), e(() -> Items.TRIPWIRE_HOOK, 1, 3, .3f)),
    FIRE(2, 5, e(() -> ZomboidMod.FIRE_AXE, 1, 1, .45f), e(() -> ZomboidMod.CROWBAR, 1, 1, .25f), e(() -> ZomboidMod.BANDAGE, 1, 4, .4f),
            e(() -> ZomboidMod.SPLINT, 1, 2, .2f), e(() -> ZomboidMod.CLEAN_WATER, 2, 4, .4f), e(() -> Items.IRON_HELMET, 1, 1, .12f),
            e(() -> Items.LEATHER_BOOTS, 1, 1, .2f), e(() -> Items.BUCKET, 1, 1, .25f)),
    CLINIC(2, 6, e(() -> ZomboidMod.BANDAGE, 2, 6, .6f), e(() -> ZomboidMod.ANTIBIOTICS, 1, 3, .4f), e(() -> ZomboidMod.ANTISEPTIC, 1, 3, .45f),
            e(() -> ZomboidMod.SUTURE_KIT, 1, 3, .4f), e(() -> ZomboidMod.SPLINT, 1, 2, .35f), e(() -> ZomboidMod.PAINKILLERS, 1, 3, .45f),
            e(() -> ZomboidMod.CLEAN_WATER, 1, 3, .3f), e(() -> LootItems.BOOK_FIRST_AID, 1, 1, .2f)),
    SCHOOL(1, 4, e(() -> Items.PAPER, 3, 10, .5f), e(() -> Items.BOOK, 1, 4, .4f), e(() -> Items.APPLE, 1, 2, .2f),
            e(() -> Items.COOKIE, 1, 4, .25f), e(() -> ZomboidMod.BASEBALL_BAT, 1, 1, .1f), e(() -> ZomboidMod.BANDAGE, 1, 2, .12f),
            e(() -> LootItems.BOOK_COOKING, 1, 1, .12f), e(() -> LootItems.BOOK_FARMING, 1, 1, .12f), e(() -> LootItems.BOOK_FIRST_AID, 1, 1, .12f),
            e(() -> LootItems.BOOK_FISHING, 1, 1, .12f), e(() -> LootItems.CHIPS, 1, 2, .2f), e(() -> LootItems.SODA, 1, 2, .2f)),
    CHURCH(1, 3, e(() -> Items.CANDLE, 1, 4, .5f), e(() -> Items.BREAD, 1, 3, .3f), e(() -> Items.BOOK, 1, 2, .3f),
            e(() -> Items.GOLD_NUGGET, 1, 4, .2f), e(() -> ZomboidMod.CLEAN_WATER, 1, 2, .3f)),
    WAREHOUSE(2, 6, e(() -> Items.OAK_PLANKS, 8, 32, .4f), e(() -> Items.IRON_INGOT, 1, 4, .25f), e(() -> Items.DRIED_KELP, 4, 16, .3f),
            e(() -> Items.STRING, 4, 12, .3f), e(() -> Items.WHITE_WOOL, 2, 8, .3f), e(() -> Items.COAL, 4, 12, .3f),
            e(() -> ZomboidMod.CROWBAR, 1, 1, .12f), e(() -> ZomboidMod.CLEAN_WATER, 2, 6, .25f)),
    BARN(2, 5, e(() -> Items.WHEAT_SEEDS, 4, 16, .45f), e(() -> Items.CARROT, 2, 6, .3f), e(() -> Items.POTATO, 2, 6, .3f),
            e(() -> Items.WHEAT, 3, 10, .35f), e(() -> Items.IRON_HOE, 1, 1, .2f), e(() -> Items.SHEARS, 1, 1, .2f),
            e(() -> Items.BUCKET, 1, 1, .25f), e(() -> Items.LEAD, 1, 2, .2f), e(() -> ZomboidMod.HAND_AXE, 1, 1, .15f), e(() -> Items.EGG, 2, 6, .2f),
            e(() -> LootItems.BOOK_FARMING, 1, 1, .15f), e(() -> LootItems.DUCT_TAPE, 1, 1, .15f)),
    CABIN(2, 5, e(() -> Items.BOW, 1, 1, .25f), e(() -> Items.ARROW, 4, 16, .45f), e(() -> Items.COOKED_PORKCHOP, 1, 3, .3f),
            e(() -> ZomboidMod.HUNTING_KNIFE, 1, 1, .3f), e(() -> ZomboidMod.RAG, 1, 4, .35f), e(() -> ZomboidMod.CLEAN_WATER, 1, 3, .35f),
            e(() -> Items.LEATHER, 1, 4, .3f), e(() -> ZomboidMod.HAND_AXE, 1, 1, .2f), e(() -> ZomboidMod.BANDAGE, 1, 2, .2f),
            e(() -> LootItems.BOOK_FISHING, 1, 1, .2f), e(() -> LootItems.CANNED_BEANS, 1, 3, .3f), e(() -> LootItems.CAN_OPENER, 1, 1, .2f)),
    GARAGE(2, 5, e(() -> ZomboidMod.CROWBAR, 1, 1, .25f), e(() -> ZomboidMod.HAMMER, 1, 1, .3f), e(() -> Items.IRON_NUGGET, 4, 12, .4f),
            e(() -> Items.IRON_INGOT, 1, 3, .2f), e(() -> Items.BUCKET, 1, 1, .2f), e(() -> Items.COAL, 2, 8, .3f), e(() -> Items.STRING, 2, 6, .25f),
            e(() -> LootItems.DUCT_TAPE, 1, 2, .3f)),
    TRASH(1, 3, e(() -> Items.ROTTEN_FLESH, 1, 3, .5f), e(() -> Items.PAPER, 1, 4, .4f), e(() -> Items.GLASS_BOTTLE, 1, 2, .3f),
            e(() -> Items.BONE, 1, 2, .2f), e(() -> LootItems.CHIPS, 1, 1, .1f), e(() -> ZomboidMod.RAG, 1, 2, .2f), e(() -> Items.STRING, 1, 2, .15f));

    private record E(Supplier<Item> item, int min, int max, float chance) {}

    private static E e(Supplier<Item> item, int min, int max, float chance) {
        return new E(item, min, max, chance);
    }

    private final int minRolls, maxRolls;
    private final List<E> entries;

    Loot(int minRolls, int maxRolls, E... entries) {
        this.minRolls = minRolls;
        this.maxRolls = maxRolls;
        this.entries = List.of(entries);
    }

    /** Одна случайная вещь (для предметов, лежащих на виду). */
    public ItemStack randomItem(Random r) {
        for (int k = 0; k < 30; k++) {
            E en = entries.get(r.nextInt(entries.size()));
            if (r.nextFloat() >= en.chance()) continue;
            Item item = en.item().get();
            if (item == null) continue;
            ItemStack st = new ItemStack(item, Math.min(1 + r.nextInt(Math.max(1, Math.min(en.max(), 3))), item.getMaxCount()));
            LootItems.randomVolume(st, r);
            return st;
        }
        return ItemStack.EMPTY;
    }

    /** Наполняет контейнер: несколько попыток, каждая кладёт вещь в случайный слот. */
    public void fill(Inventory inv, Random r) {
        if (r.nextFloat() < 0.15f) return;   // иногда уже обчищено
        int rolls = minRolls + r.nextInt(maxRolls - minRolls + 1);
        for (int k = 0; k < rolls * 3 && rolls > 0; k++) {
            E en = entries.get(r.nextInt(entries.size()));
            if (r.nextFloat() >= en.chance()) continue;
            Item item = en.item().get();
            if (item == null) continue;
            int n = en.min() + (en.max() > en.min() ? r.nextInt(en.max() - en.min() + 1) : 0);
            ItemStack st = new ItemStack(item, Math.min(n, item.getMaxCount()));
            LootItems.randomVolume(st, r);
            inv.setStack(r.nextInt(inv.size()), st);
            rolls--;
        }
    }
}
