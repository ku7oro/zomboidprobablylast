package com.example.zomboidmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** Медицинский предмет. Применяется из панели здоровья (H) или ПКМ (на самую срочную рану). */
public class MedItem extends Item {
    /** Порядок не менять: номер передаётся по сети. Новые виды добавлять в конец. */
    public enum Kind {
        BANDAGE(false, "Останавливает кровь, защищает рану"),
        ANTISEPTIC(true, "Обеззараживает рану"),
        SUTURE(false, "Зашивает глубокую рану"),
        SPLINT(false, "Фиксирует перелом руки или ноги"),
        PAINKILLERS(true, "Снимает боль на 2 часа"),
        ANTIBIOTICS(true, "Лечат заражённые раны"),
        RAG(false, "Повязка на скорую руку, быстро грязнится");

        final boolean drinkSound;
        final String hint;

        Kind(boolean drinkSound, String hint) {
            this.drinkSound = drinkSound;
            this.hint = hint;
        }
    }

    private final Kind kind;

    public MedItem(Settings settings, Kind kind) {
        super(settings);
        this.kind = kind;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal(kind.hint).formatted(Formatting.GRAY));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.pass(stack);

        if (user instanceof ServerPlayerEntity p && Wounds.treat(p, kind)) {
            if (kind.drinkSound) {
                world.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GENERIC_DRINK,
                        SoundCategory.PLAYERS, 0.8f, 1.0f);
            }
            stack.decrementUnlessCreative(1, user);
            return TypedActionResult.success(stack);
        }
        return TypedActionResult.fail(stack);
    }
}
