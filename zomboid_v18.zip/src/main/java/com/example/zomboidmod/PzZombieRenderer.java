package com.example.zomboidmod;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ZombieEntityRenderer;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

/** Выбирает скин по одежде и виду зомби. */
public class PzZombieRenderer extends ZombieEntityRenderer {
    public PzZombieRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
    }

    public Identifier getTexture(ZombieEntity entity) {
        if (entity instanceof PzZombieEntity z) {
            return ZombieOutfit.texture(z.outfit(), z.tone(), z.kind());
        }
        return super.getTexture(entity);
    }
}
