package com.example.zomboidmod.vehicle;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundCategory;

import java.util.HashSet;
import java.util.Set;

/** Клиент: рендер, звук мотора, гудок на пробел, приборная панель. */
public final class VehicleClient {
    private static final Set<Integer> PLAYING = new HashSet<>();
    private static boolean hornHeld;

    private VehicleClient() {
    }

    public static void init() {
        for (VehicleType t : VehicleType.values()) EntityRendererRegistry.register(t.entityType, ctx -> new VehicleRenderer(ctx, t));
    }

    public static void tick(MinecraftClient c) {
        if (c.world == null || c.player == null) {
            PLAYING.clear();
            return;
        }
        for (Entity e : c.world.getEntities()) {
            if (e instanceof VehicleEntity v && v.engineOn() && !PLAYING.contains(v.getId()) && v.squaredDistanceTo(c.player) < 48 * 48) {
                PLAYING.add(v.getId());
                c.getSoundManager().play(new EngineSound(v));
            }
        }
        boolean driver = c.player.getVehicle() instanceof VehicleEntity v && v.getControllingPassenger() == c.player;
        boolean down = driver && c.currentScreen == null && c.options.jumpKey.isPressed();
        if (down && !hornHeld) ClientPlayNetworking.send(new HornPayload());
        hornHeld = down;
    }

    /** Приборы: скорость, топливо, состояние. */
    public static void hud(DrawContext ctx, MinecraftClient c) {
        if (!(c.player.getVehicle() instanceof VehicleEntity v)) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int x = w / 2 - 91 - 108, y = h - 46;
        ctx.fill(x, y, x + 100, y + 40, 0xA0101010);
        ctx.drawBorder(x, y, 100, 40, 0xFF4A4A44);
        int kmh = Math.round(v.clientSpeed * 72f);
        ctx.drawText(c.textRenderer, kmh + " км/ч", x + 6, y + 5, 0xFFE8E2C8, false);
        ctx.drawText(c.textRenderer, v.type.ru, x + 6, y + 5 + 10, 0xFF9A968A, false);
        float fuel = v.fuel() / v.type.fuelCap, hp = v.health() / v.type.maxHealth;
        bar(ctx, x + 6, y + 27, 40, fuel, fuel < 0.15f ? 0xFFD04030 : 0xFFE0B040);
        bar(ctx, x + 54, y + 27, 40, hp, hp < 0.3f ? 0xFFD04030 : 0xFF60B060);
        if (!v.engineOn()) {
            String why = v.broken() ? "Двигатель разбит" : (v.fuel() <= 0f ? "Нет топлива" : (!v.ignition() ? "Нет ключа — R: завести без ключа" : ""));
            if (!why.isEmpty()) ctx.drawText(c.textRenderer, why, x, y - 10, 0xFFD06050, true);
        }
    }

    private static void bar(DrawContext ctx, int x, int y, int w, float f, int color) {
        ctx.fill(x, y, x + w, y + 5, 0xFF202020);
        ctx.fill(x, y, x + Math.round(w * Math.max(0f, Math.min(1f, f))), y + 5, color);
    }

    static final class EngineSound extends MovingSoundInstance {
        private final VehicleEntity v;

        EngineSound(VehicleEntity v) {
            super(v.type.bike() ? Vehicles.ENGINE_BIKE : Vehicles.ENGINE_CAR, SoundCategory.NEUTRAL, SoundInstance.createRandom());
            this.v = v;
            this.repeat = true;
            this.repeatDelay = 0;
            this.volume = 0.6f;
            this.x = v.getX();
            this.y = v.getY();
            this.z = v.getZ();
        }

        @Override
        public void tick() {
            if (v.isRemoved() || !v.engineOn()) {
                PLAYING.remove(v.getId());
                this.setDone();
                return;
            }
            this.x = v.getX();
            this.y = v.getY();
            this.z = v.getZ();
            float s = Math.min(1f, v.clientSpeed / v.type.maxSpeed);
            this.pitch = 0.7f + s * 1.1f;
            this.volume = 0.45f + s * 0.6f;
        }
    }
}
