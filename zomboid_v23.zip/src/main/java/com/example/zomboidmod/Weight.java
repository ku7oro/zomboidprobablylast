package com.example.zomboidmod;

import com.example.zomboidmod.backpack.BackpackItem;
import com.example.zomboidmod.block.ZomboidBlocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.PotionItem;
import net.minecraft.item.SwordItem;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.Map;

/**
 * Вес как в PZ: у каждой вещи свой вес, предел зависит от силы (8 + 0,6 за уровень).
 * Перегруз — мудл «Тяжёлый груз»: медленнее ходишь, быстрее устаёшь, сильно перегруженный не может бежать.
 */
public final class Weight {
    private static final Identifier MOD = Identifier.of(ZomboidMod.MOD_ID, "heavy_load");
    private static final Map<String, Float> W = Map.ofEntries(
            Map.entry("baseball_bat", 1.5f), Map.entry("spiked_bat", 1.8f), Map.entry("crowbar", 2.0f), Map.entry("frying_pan", 1.5f),
            Map.entry("hammer", 1.0f), Map.entry("kitchen_knife", 0.3f), Map.entry("hunting_knife", 0.5f), Map.entry("machete", 1.0f),
            Map.entry("hand_axe", 1.5f), Map.entry("fire_axe", 3.0f), Map.entry("sledgehammer", 5.0f), Map.entry("shovel", 2.0f),
            Map.entry("golf_club", 1.0f), Map.entry("pipe_wrench", 1.5f), Map.entry("nightstick", 0.7f), Map.entry("meat_cleaver", 0.6f),
            Map.entry("katana", 1.4f), Map.entry("pistol", 1.0f), Map.entry("shotgun", 3.5f), Map.entry("hunting_rifle", 3.8f),
            Map.entry("ammo_9mm", 0.02f), Map.entry("shotgun_shells", 0.04f), Map.entry("rifle_rounds", 0.03f),
            Map.entry("clean_water", 0.8f), Map.entry("water_bottle", 0.6f), Map.entry("soda", 0.4f), Map.entry("canned_beans", 0.5f),
            Map.entry("canned_soup", 0.5f), Map.entry("canned_tuna", 0.3f), Map.entry("can_opener", 0.2f), Map.entry("duct_tape", 0.1f),
            Map.entry("bandage", 0.05f), Map.entry("rag", 0.05f), Map.entry("splint", 0.4f), Map.entry("suture_kit", 0.1f),
            Map.entry("antiseptic", 0.2f), Map.entry("painkillers", 0.1f), Map.entry("antibiotics", 0.1f),
            Map.entry("cooking_pot", 1.0f), Map.entry("pot_water", 3.0f), Map.entry("pot_water_tainted", 3.0f), Map.entry("stew_raw", 2.5f),
            Map.entry("stew", 2.5f), Map.entry("magazine", 0.1f), Map.entry("comic", 0.1f), Map.entry("newspaper", 0.1f),
            Map.entry("cigarettes", 0.02f), Map.entry("coffee", 0.3f), Map.entry("beer", 0.4f), Map.entry("car_key", 0.01f),
            Map.entry("knox_map", 0.05f), Map.entry("radio_handheld", 0.6f), Map.entry("battery", 0.05f), Map.entry("wool_hat", 0.2f),
            Map.entry("winter_jacket", 1.5f), Map.entry("warm_pants", 0.8f), Map.entry("winter_boots", 1.0f),
            Map.entry("generator", 25f), Map.entry("rain_barrel", 4f));

    private Weight() {
    }

    /** Вес одной штуки. */
    public static float unit(ItemStack st) {
        Item it = st.getItem();
        Identifier id = Registries.ITEM.getId(it);
        if (id.getNamespace().equals(ZomboidMod.MOD_ID)) {
            Float w = W.get(id.getPath());
            if (w != null) return w;
            if (id.getPath().startsWith("book_")) return 0.5f;
        }
        if (it instanceof BackpackItem b) return b.ownWeight;
        if (it instanceof com.example.zomboidmod.vehicle.GasCanItem) return 0.6f + com.example.zomboidmod.vehicle.GasCanItem.liters(st) * 0.7f;
        if (it instanceof BlockItem bi) return ZomboidBlocks.FURNITURE.containsValue(bi.getBlock()) ? 5f : 0.4f;
        if (it instanceof ArmorItem a) {
            float base = switch (a.getSlotType()) {
                case CHEST -> 3f;
                case LEGS -> 2f;
                default -> 1f;
            };
            String m = Registries.ITEM.getId(it).getPath();
            return m.startsWith("leather") ? base * 0.5f : (m.startsWith("iron") || m.startsWith("chainmail") ? base * 1.4f : base * 1.6f);
        }
        if (it instanceof SwordItem || it instanceof MiningToolItem) return 1.5f;
        if (it instanceof BowItem || it instanceof CrossbowItem) return 1.2f;
        if (it instanceof PotionItem) return 0.4f;
        if (st.contains(DataComponentTypes.FOOD)) return 0.25f;
        return 0.1f;
    }

    /** Вес стопки; рюкзак — вместе с содержимым (полным, не надетый). */
    public static float of(ItemStack st) {
        if (st.isEmpty()) return 0f;
        float w = unit(st) * st.getCount();
        if (st.getItem() instanceof BackpackItem) for (ItemStack s : BackpackItem.contents(st)) w += unit(s) * s.getCount();
        return w;
    }

    public static float carried(PlayerEntity p) {
        float w = 0f;
        for (ItemStack s : p.getInventory().main) w += of(s);
        for (ItemStack s : p.getInventory().offHand) w += of(s);
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.LEGS, EquipmentSlot.FEET}) w += of(p.getEquippedStack(slot)) * 0.5f;
        ItemStack chest = p.getEquippedStack(EquipmentSlot.CHEST);
        if (chest.getItem() instanceof BackpackItem b) {
            w += b.ownWeight;
            float in = 0f;
            for (ItemStack s : BackpackItem.contents(chest)) in += unit(s) * s.getCount();
            w += in * (1f - b.reduction);
        } else w += of(chest) * 0.5f;      // надетая одежда весит вдвое меньше
        return w;
    }

    public static float capacity(int strength) {
        return 8f + 0.6f * strength;
    }

    /** Уровень перегруза 0..4. */
    public static int level(float ratio) {
        if (ratio > 1.75f) return 4;
        if (ratio > 1.5f) return 3;
        if (ratio > 1.25f) return 2;
        if (ratio > 1.0f) return 1;
        return 0;
    }

    /** Раз в секунду на сервере: замедление, усталость, прокачка силы. */
    public static void tick(ServerPlayerEntity p) {
        if (p.isCreative() || p.isSpectator()) return;
        float ratio = carried(p) / capacity(Skills.level(p, PzSkill.STRENGTH));
        int lvl = level(ratio);
        double slow = switch (lvl) {
            case 1 -> -0.1;
            case 2 -> -0.25;
            case 3 -> -0.45;
            case 4 -> -0.7;
            default -> 0.0;
        };
        EntityAttributeInstance inst = p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (inst != null) {
            EntityAttributeModifier cur = inst.getModifier(MOD);
            if (cur == null || Math.abs(cur.value() - slow) > 1e-6) {
                inst.removeModifier(MOD);
                if (slow != 0) inst.addTemporaryModifier(new EntityAttributeModifier(MOD, slow, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
            }
        }
        boolean moving = p.getVelocity().horizontalLengthSquared() > 0.002;
        if (lvl >= 3) p.setSprinting(false);
        if (lvl > 0 && moving) p.addExhaustion(0.04f * lvl);
        if (ratio > 0.75f && moving) Skills.addXp(p, PzSkill.STRENGTH, 0.4f + 0.5f * lvl);
    }
}
