package com.example.zomboidmod.survival;

import com.example.zomboidmod.Noise;
import com.example.zomboidmod.PlayerHealth;
import com.example.zomboidmod.Profession;
import com.example.zomboidmod.PzSkill;
import com.example.zomboidmod.PzTrait;
import com.example.zomboidmod.PzZombieEntity;
import com.example.zomboidmod.Skills;
import com.example.zomboidmod.Weight;
import com.example.zomboidmod.Wounds;
import com.example.zomboidmod.ZomboidMod;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Выживание по правилам Project Zomboid: усталость и сон, выносливость, скука и грусть, паника и стресс,
 * температура тела, промокание, простуда, пищевое отравление, опьянение.
 * Все скорости заданы «в игровой час» (1000 тиков = 50 секунд).
 */
public final class Survival {
    private static final Identifier MOD_DMG = Identifier.of(ZomboidMod.MOD_ID, "survival_damage");
    private static final Identifier MOD_ASPD = Identifier.of(ZomboidMod.MOD_ID, "survival_attack_speed");
    private static final Identifier MOD_MOVE = Identifier.of(ZomboidMod.MOD_ID, "survival_move");
    private static final Map<UUID, Long> SLEEP_START = new HashMap<>();
    // множитель урона в ближнем бою от усталости (по вики PZ)
    private static final float[] TIRED_DMG = {1f, 0.5f, 0.2f, 0.1f, 0.05f};
    private static final float[] TIRED_REGEN = {1f, 0.8f, 0.6f, 0.4f, 0.2f};
    private static final float[] PANIC_DMG = {1f, 1f, 0.9f, 0.8f, 0.7f};

    private Survival() {
    }

    public static Mood mood(ServerPlayerEntity p) {
        return SurvivalState.get(p.getServer()).mood(p.getUuid());
    }

    // ===================== регистрация =====================
    public static void register() {
        SurvivalSounds.register();
        SurvivalItems.register();
        com.example.zomboidmod.block.PowerLampBlock.register();
        Food.init();
        PayloadTypeRegistry.playS2C().register(MoodPayload.ID, MoodPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(WorldEvents.MapPayload.ID, WorldEvents.MapPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(WorldEvents.HeliPayload.ID, WorldEvents.HeliPayload.CODEC);

        // Днём можно лечь спать, только если сильно устал (как в PZ)
        EntitySleepEvents.ALLOW_SLEEP_TIME.register((player, pos, vanilla) -> {
            if (vanilla || !(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;
            if (mood(sp).fatigue >= 0.45f) return ActionResult.SUCCESS;
            sp.sendMessage(Text.literal("Спать не хочется"), true);
            return ActionResult.PASS;
        });
        // днём спящий не «перематывает» сутки целиком — время ускоряется плавно (daySleep)
        EntitySleepEvents.ALLOW_RESETTING_TIME.register(player -> !player.getWorld().isDay());
        EntitySleepEvents.START_SLEEPING.register((entity, pos) -> {
            if (entity instanceof ServerPlayerEntity p) {
                SLEEP_START.put(p.getUuid(), Clock.now(p.getWorld()));
                mood(p).sleepApplied = 0;
            }
        });
        EntitySleepEvents.STOP_SLEEPING.register((entity, pos) -> {
            if (!(entity instanceof ServerPlayerEntity p)) return;
            Long start = SLEEP_START.remove(p.getUuid());
            Mood m = mood(p);
            if (start != null) {
                long rest = Clock.now(p.getWorld()) - start - m.sleepApplied;
                if (rest > 0) sleepRecover(m, rest);
                long total = Clock.now(p.getWorld()) - start;
                if (total > 2000) p.sendMessage(Text.literal(String.format("Вы проспали %.1f ч. %s", total / 1000f,
                        m.fatigue < 0.2f ? "Отлично выспались" : "Всё ещё хочется спать")), true);
            }
            m.sleepApplied = 0;
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClient && player instanceof ServerPlayerEntity sp && !sp.isCreative()) {
                Mood m = mood(sp);
                float w = Weight.unit(sp.getMainHandStack());
                m.endurance = Math.max(0f, m.endurance - (0.006f + 0.006f * w));
                m.lastFight = Clock.now(world);
            }
            return ActionResult.PASS;
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof PzZombieEntity z) {
                if (source.getAttacker() instanceof ServerPlayerEntity p) mood(p).kills++;
                WorldEvents.onZombieDeath(z);
            }
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (!alive) {
                SurvivalState st = SurvivalState.get(newPlayer.getServer());
                st.moods.remove(newPlayer.getUuid());
                st.markDirty();
            }
        });
        // продукты в сундуках и бочках домов тоже лежат с первого дня эпидемии
        net.fabricmc.fabric.api.event.player.UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.isClient && world.getBlockEntity(hit.getBlockPos()) instanceof net.minecraft.inventory.Inventory inv
                    && !(inv instanceof com.example.zomboidmod.block.FurnitureBlockEntity)) {
                List<ItemStack> l = new ArrayList<>();
                for (int i = 0; i < inv.size(); i++) l.add(inv.getStack(i));
                Food.stampAll(l, 0L);
            }
            return ActionResult.PASS;
        });
        ServerTickEvents.END_SERVER_TICK.register(Survival::tick);
        registerCommands();
    }

    // ===================== тик сервера =====================
    private static void tick(MinecraftServer server) {
        ServerWorld w = server.getOverworld();
        daySleep(w);
        WorldEvents.tick(server);
        if (server.getTicks() % 20 != 0) return;
        SurvivalState st = SurvivalState.get(server);
        long now = Clock.now(w);
        int day = Clock.day(now);
        if (!st.waterNotified && day >= st.waterOffDay) {
            st.waterNotified = true;
            broadcast(server, "Из кранов больше не течёт вода. Водопровод отключён.");
        }
        if (!st.powerNotified && day >= st.powerOffDay) {
            st.powerNotified = true;
            broadcast(server, "Свет моргнул и погас. Электричество отключили — похоже, навсегда.");
        }
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (!p.isAlive() || p.isSpectator()) continue;
            if (!p.isCreative()) second(p, st.mood(p.getUuid()), now);
            sync(p, st);
        }
        WorldEvents.second(server, st, now);
        Broadcasts.second(server, st, now);
        st.markDirty();
    }

    private static void broadcast(MinecraftServer server, String msg) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList())
            p.sendMessage(Text.literal(msg).formatted(Formatting.GOLD), false);
    }

    /** Если все игроки спят днём — время идёт в 40 раз быстрее, как ускорение во сне в PZ. */
    private static void daySleep(ServerWorld w) {
        List<ServerPlayerEntity> ps = w.getPlayers(p -> !p.isSpectator());
        if (ps.isEmpty() || !w.isDay()) return;
        for (ServerPlayerEntity p : ps) if (!p.isSleeping() || p.getSleepTimer() < 60) return;
        w.setTimeOfDay(w.getTimeOfDay() + 39);
    }

    /** Не будить днём, пока игрок не выспался (вызывается из миксина). */
    public static boolean keepSleeping(PlayerEntity player) {
        if (!(player instanceof ServerPlayerEntity p) || p.getServer() == null) return false;
        return mood(p).fatigue > 0.03f;
    }

    private static void sleepRecover(Mood m, long dt) {
        float h = dt / (float) Clock.HOUR;
        m.fatigue = Math.max(0f, m.fatigue - 0.13f * h);          // 8 часов сна снимают всю усталость
        m.endurance = Math.min(1f, m.endurance + 0.3f * h);
        m.panic = Math.max(0f, m.panic - 30f * h);
        m.stress = Math.max(0f, m.stress - 2f * h);
        m.drunk = Math.max(0f, m.drunk - 15f * h);
    }

    // ===================== раз в секунду на игрока =====================
    private static void second(ServerPlayerEntity p, Mood m, long now) {
        ServerWorld w = p.getServerWorld();
        long dt = m.lastTime < 0 ? 20 : now - m.lastTime;
        m.lastTime = now;
        if (p.isSleeping()) {
            if (dt > 0 && dt < 4000) {
                sleepRecover(m, dt);
                m.sleepApplied += dt;
            }
            if (m.fatigue <= 0.03f && w.isDay()) p.wakeUp(false, true);
            temperature(p, m, w, 20, true);
            return;
        }
        if (dt <= 0 || dt > 200) dt = 20;          // скачок времени (сон, /time) — считаем как секунду
        float sec = dt / 20f, h = dt / (float) Clock.HOUR;
        Random r = p.getRandom();
        BlockPos head = p.getBlockPos().up();
        boolean indoors = !w.isSkyVisible(head);
        boolean moving = p.getVelocity().horizontalLengthSquared() > 0.003;
        boolean sprint = p.isSprinting();
        boolean fighting = now - m.lastFight < 200;
        int weightLvl = Weight.level(Weight.carried(p) / Weight.capacity(Skills.level(p, PzSkill.STRENGTH)));
        int fit = Skills.level(p, PzSkill.FITNESS);

        // --- усталость ---
        float fm = 1f;
        if (weightLvl >= 2) fm *= 1.3f;
        if (m.endurance < 0.05f) fm *= 3f;
        if (Mood.unhappy(m.unhappy) >= 3) fm *= 1.2f;
        if (Mood.drunk(m.drunk) >= 2) fm *= 1.3f;
        m.fatigue = Math.min(1f, m.fatigue + 0.04f * h * fm);   // ~16 часов бодрствования до «Хочется спать»
        int tired = Mood.tired(m.fatigue);

        // --- выносливость ---
        if (sprint) {
            m.endurance -= 0.0125f * sec * (1f - 0.05f * fit) * (1f + 0.15f * weightLvl);
        } else if (p.isSwimming()) {
            m.endurance -= 0.006f * sec;
        } else {
            float regen = (moving ? 0.005f : 0.01f) * sec * TIRED_REGEN[tired] * (1f + 0.05f * fit);
            if (Mood.hypo(m.temp) >= 3) regen *= 0.5f;
            if (Mood.hyper(m.temp) >= 2) regen *= 0.7f;
            if (Mood.unhappy(m.unhappy) >= 3) regen *= 0.8f;
            if (m.cold > 0) regen *= 0.8f;
            if (moving && weightLvl >= 2) regen -= 0.002f * weightLvl * sec;
            m.endurance += regen;
        }
        m.endurance = MathHelper.clamp(m.endurance, 0f, 1f);
        int exert = Mood.exertion(m.endurance);

        // --- паника: зомби на виду, а за спиной — ещё страшнее ---
        int front = 0, behind = 0;
        Vec3d look = p.getRotationVec(1f);
        for (PzZombieEntity z : w.getEntitiesByClass(PzZombieEntity.class, p.getBoundingBox().expand(16), e -> e.isAlive())) {
            Vec3d to = z.getPos().subtract(p.getPos());
            double d = to.length();
            if (d < 0.1) continue;
            if (to.normalize().dotProduct(look) > 0.25 && p.canSee(z)) front++;
            else if (d < 6) behind++;
        }
        boolean veteran = Profession.byIndex(Skills.of(p).profession) == Profession.VETERAN;
        if (front + behind > 0 && !veteran) {
            float mult = Math.max(0.25f, 1f - m.kills / 300f) * (Mood.drunk(m.drunk) >= 2 ? 0.5f : 1f);
            float cap = Math.min(100f, (front + behind) * 22f);
            if (m.panic < cap) m.panic = Math.min(cap, m.panic + (front * 2.5f + behind * 4f) * sec * mult);
        } else {
            m.panic = Math.max(0f, m.panic - (indoors ? 2.5f : 1.5f) * sec);
        }
        int panic = Mood.panic(m.panic);

        // --- скука ---
        float b;
        if (fighting || panic >= 1) b = -12f;
        else if (p.hasVehicle()) b = -3f;
        else if (!indoors) b = moving ? -3f : 0.5f;
        else b = moving ? 3f : 6f;
        m.boredom = MathHelper.clamp(m.boredom + b * h, 0f, 100f);
        int bored = Mood.bored(m.boredom);

        // --- грусть ---
        float u = bored >= 4 ? 5f : bored == 3 ? 3f : bored == 2 ? 1.5f : 0f;
        if (Mood.wet(m.wet) >= 2) u += 2f;
        if (Mood.stress(m.stress) >= 3) u += 1.5f;
        if (Mood.hypo(m.temp) >= 2) u += 1f;
        if (Mood.foodSick(m.foodSick) >= 2) u += 2f;
        if (u == 0f && bored == 0) u = -0.5f;
        m.unhappy = MathHelper.clamp(m.unhappy + u * h, 0f, 100f);

        // --- стресс тянется к «фону»: паника, заражение, боль, голод ---
        PlayerHealth hp = Wounds.health(p);
        float target = m.panic * 0.5f + (hp.zombieInfected ? 45f : 0f) + (hp.painValue >= 50 ? 15f : 0f)
                + (p.getHungerManager().getFoodLevel() <= 11 ? 10f : 0f);
        if (m.stress < target) m.stress = Math.min(target, m.stress + 6f * h + (m.panic > 30 ? 0.3f * sec : 0f));
        else m.stress = Math.max(target, m.stress - 3f * h);
        m.stress = MathHelper.clamp(m.stress, 0f, 100f);

        // --- температура и промокание ---
        temperature(p, m, w, dt, false);
        int hypo = Mood.hypo(m.temp), hyper = Mood.hyper(m.temp);

        // жара — пить хочется чаще
        float extra = hyper >= 3 ? 1f : hyper == 2 ? 0.5f : hyper == 1 ? 0.25f : 0f;
        if (extra > 0) {
            m.thirstAcc += extra * sec / 20f;
            if (m.thirstAcc >= 1f) {
                m.thirstAcc -= 1f;
                ZomboidMod.addThirst(p, -1);
            }
        }

        // --- простуда: холод и сырость ---
        if (m.cold <= 0 && (hypo >= 2 || (Mood.wet(m.wet) >= 2 && m.felt < 15f))) {
            float chance = 0.12f * h * (Skills.has(p, PzTrait.PRONE_TO_ILLNESS) ? 1.7f : 1f) * (Skills.has(p, PzTrait.RESILIENT) ? 0.55f : 1f);
            if (r.nextFloat() < chance) {
                m.cold = 2400 + r.nextInt(2400);
                p.sendMessage(Text.literal("Знобит, щиплет в горле... Похоже, вы простыли").formatted(Formatting.YELLOW), false);
            }
        }
        if (m.cold > 0) {
            m.cold -= sec;
            m.sneezeIn -= sec;
            if (m.sneezeIn <= 0) {
                m.sneezeIn = 30 + r.nextInt(60);
                boolean sneeze = r.nextBoolean();
                w.playSound(null, p.getBlockPos(), sneeze ? SurvivalSounds.SNEEZE : SurvivalSounds.COUGH, SoundCategory.PLAYERS, 1f,
                        0.9f + r.nextFloat() * 0.2f);
                p.sendMessage(Text.literal(sneeze ? "*Апчхи!*" : "*Кхе-кхе*"), true);
                Noise.emitAt(w, p.getBlockPos(), 14);          // чих слышат зомби
            }
        }

        // --- пищевое отравление ---
        if (m.foodSick > 0) {
            int fs = Mood.foodSick(m.foodSick);
            m.foodSick = Math.max(0f, m.foodSick - 0.3f * sec);
            int s = (int) (now / 20);
            if (fs >= 2 && s % 20 == 0) effect(p, StatusEffects.NAUSEA, 120, 0);
            if (fs >= 2) effect(p, StatusEffects.HUNGER, 40, 0);
            if (fs >= 3 && s % 10 == 0) p.damage(p.getDamageSources().starve(), fs >= 4 ? 1.5f : 0.5f);
        }

        // --- опьянение ---
        if (m.drunk > 0) {
            m.drunk = Math.max(0f, m.drunk - 0.4f * sec);
            if (Mood.drunk(m.drunk) >= 2 && r.nextInt(15) == 0) effect(p, StatusEffects.NAUSEA, 100, 0);
        }

        // --- переохлаждение и перегрев ---
        int s = (int) (now / 20);
        if (hypo >= 4 && s % 10 == 0) p.damage(p.getDamageSources().freeze(), 1f);
        if (hyper >= 4 && s % 10 == 0) p.damage(p.getDamageSources().starve(), 1f);
        if (hyper >= 3) effect(p, StatusEffects.NAUSEA, 60, 0);
        if (tired >= 4 && r.nextInt(20) == 0) {
            effect(p, StatusEffects.BLINDNESS, 30, 0);
            p.sendMessage(Text.literal("Глаза слипаются..."), true);
        }
        if (exert >= 3) p.setSprinting(false);

        // --- модификаторы боя и скорости ---
        float dmg = TIRED_DMG[tired] * PANIC_DMG[panic] * (exert >= 4 ? 0.75f : exert == 3 ? 0.9f : 1f);
        float aspd = (exert >= 4 ? 0.6f : exert == 3 ? 0.75f : exert == 2 ? 0.9f : 1f) * (1f - 0.05f * hypo);
        float move = 1f;
        if (exert == 3) move -= 0.1f;
        if (exert == 4) move -= 0.25f;
        move -= switch (hypo) {
            case 2 -> 0.05f;
            case 3 -> 0.15f;
            case 4 -> 0.3f;
            default -> 0f;
        };
        if (hyper >= 3) move -= 0.1f;
        if (Mood.foodSick(m.foodSick) >= 3) move -= 0.1f;
        if (tired >= 4) move -= 0.1f;
        setMod(p, EntityAttributes.GENERIC_ATTACK_DAMAGE, MOD_DMG, dmg - 1f);
        setMod(p, EntityAttributes.GENERIC_ATTACK_SPEED, MOD_ASPD, aspd - 1f);
        setMod(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, MOD_MOVE, Math.max(-0.6f, move - 1f));

        // --- продукты в инвентаре получают дату, радио ловит передачи ---
        Food.stampAll(p.getInventory().main, now);
        Food.stampAll(p.getInventory().offHand, now);
    }

    /** Ощущаемая температура воздуха и температура тела; намокание под дождём и в воде, высыхание. */
    private static void temperature(ServerPlayerEntity p, Mood m, ServerWorld w, long dt, boolean sleeping) {
        float sec = dt / 20f, h = dt / (float) Clock.HOUR;
        BlockPos pos = p.getBlockPos(), head = pos.up();
        boolean indoors = !w.isSkyVisible(head);
        boolean rain = w.hasRain(head);
        float air = Clock.seasonTemp(w) + Clock.dayTempOffset(w);
        air += (w.getBiome(pos).value().getTemperature() - 0.8f) * 15f;
        if (p.getY() > 90) air -= (float) (p.getY() - 90) * 0.08f;
        if (w.isRaining()) air -= 3f;
        if (indoors) air += (20f - air) * 0.55f;                    // дом держит тепло
        boolean heat = Power.heatNear(w, pos, 3);
        if (heat) air += indoors ? 12f : 8f;
        if (p.isTouchingWater()) air = Math.min(air, 14f);

        float ins = 0f, proof = 0f;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack st = p.getEquippedStack(slot);
            ins += SurvivalItems.insulation(st);
            proof += SurvivalItems.waterproof(st);
        }
        if (sleeping) ins += 0.35f;                                  // одеяло
        ins = Math.min(0.9f, ins) * (1f - m.wet / 150f);
        proof = Math.min(0.8f, proof);
        float felt = air + ins * 25f - m.wet * 0.08f + (p.isSprinting() ? 4f : (p.getVelocity().horizontalLengthSquared() > 0.003 ? 1.5f : 0f));
        m.felt = felt;

        if (felt < 18f) m.temp -= (18f - felt) * 0.04f * h;
        else if (felt > 27f) m.temp += (felt - 27f) * 0.05f * h;
        if (felt >= 18f && m.temp < 37f) m.temp = Math.min(37f, m.temp + (heat ? 1.5f : 0.6f) * h);
        if (felt <= 27f && m.temp > 37f) m.temp = Math.max(37f, m.temp - 0.6f * h);
        m.temp = MathHelper.clamp(m.temp, 30f, 42f);

        if (p.isSubmergedInWater()) m.wet = 100f;
        else if (p.isTouchingWater()) m.wet += 4f * sec;
        else if (rain && !p.hasVehicle()) m.wet += 0.6f * sec * (1f - proof);   // под ливнем промокаешь за пару минут
        else {
            float dry = (indoors ? 0.35f : 0.2f) * (heat ? 4f : 1f) * (felt > 25f ? 1.5f : 1f);
            m.wet -= dry * sec;
        }
        if (Mood.hyper(m.temp) >= 1 && p.isSprinting() && m.wet < 40f) m.wet += 0.15f * sec;   // пот
        m.wet = MathHelper.clamp(m.wet, 0f, 100f);
    }

    private static void effect(ServerPlayerEntity p, RegistryEntry<net.minecraft.entity.effect.StatusEffect> e, int ticks, int amp) {
        p.addStatusEffect(new StatusEffectInstance(e, ticks, amp, true, false, true));
    }

    private static void setMod(ServerPlayerEntity p, RegistryEntry<EntityAttribute> attr, Identifier id, double value) {
        EntityAttributeInstance inst = p.getAttributeInstance(attr);
        if (inst == null) return;
        EntityAttributeModifier cur = inst.getModifier(id);
        if (cur != null && Math.abs(cur.value() - value) < 1e-4) return;
        inst.removeModifier(id);
        if (Math.abs(value) > 1e-4)
            inst.addTemporaryModifier(new EntityAttributeModifier(id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
    }

    /** Огнестрел: при сильной панике урон -40% / -60%, пока Меткость ниже 6 (вики PZ). */
    public static float gunDamageMult(ServerPlayerEntity p) {
        if (Skills.level(p, PzSkill.AIMING) >= 6) return 1f;
        int pl = Mood.panic(mood(p).panic);
        return pl >= 4 ? 0.4f : pl == 3 ? 0.6f : 1f;
    }

    /** Разброс выстрела: паника и стресс трясут руки. */
    public static float gunSpreadMult(ServerPlayerEntity p) {
        Mood m = mood(p);
        return 1f + 0.15f * Mood.panic(m.panic) + 0.1f * Math.max(0, Mood.stress(m.stress) - 1) + 0.1f * Mood.drunk(m.drunk);
    }

    // ===================== еда и предметы =====================
    private static float stomach(ServerPlayerEntity p) {
        return (Skills.has(p, PzTrait.IRON_GUT) ? 0.5f : 1f) * (Skills.has(p, PzTrait.WEAK_STOMACH) ? 2f : 1f);
    }

    /** Вызывается миксином при поедании любой еды. */
    public static void onEat(ServerPlayerEntity p, ItemStack st) {
        if (p.isCreative() || st.getItem() instanceof SurvivalItems.StewItem) return;
        Mood m = mood(p);
        int s = Food.state(st, Clock.now(p.getWorld()));
        if (s == Food.STALE) {
            m.unhappy = Math.min(100f, m.unhappy + 10f);
            m.boredom = Math.min(100f, m.boredom + 10f);
            p.sendMessage(Text.literal("Несвежее... невкусно").formatted(Formatting.YELLOW), true);
        } else if (s == Food.ROTTEN) {
            m.unhappy = Math.min(100f, m.unhappy + 20f);
            m.boredom = Math.min(100f, m.boredom + 20f);
            m.foodSick = Math.min(100f, m.foodSick + 30f * stomach(p));
            p.sendMessage(Text.literal("Фу! Это было испорчено").formatted(Formatting.RED), true);
        }
        float[] c = Food.comfort(st.getItem());
        if (c != null) {
            m.unhappy = MathHelper.clamp(m.unhappy + c[0], 0f, 100f);
            m.boredom = MathHelper.clamp(m.boredom + c[1], 0f, 100f);
        }
    }

    public static void onEatStew(ServerPlayerEntity p, ItemStack st) {
        Mood m = mood(p);
        long now = Clock.now(p.getWorld());
        NbtCompound d = Food.data(st);
        int s = Food.state(st, now);
        if (now - d.getLong("cooked") < 3000 && s == Food.FRESH) {
            m.unhappy = Math.max(0f, m.unhappy - 10f);
            m.boredom = Math.max(0f, m.boredom - 8f);
            p.sendMessage(Text.literal("Горячая еда! Настроение лучше"), true);
        }
        if (s == Food.STALE) m.unhappy = Math.min(100f, m.unhappy + 5f);
        if (s == Food.ROTTEN || d.getInt("bad") > 0) {
            m.foodSick = Math.min(100f, m.foodSick + (s == Food.ROTTEN ? 25f : 8f * d.getInt("bad")) * stomach(p));
            p.sendMessage(Text.literal("Что-то в этом рагу было испорчено...").formatted(Formatting.RED), true);
        }
    }

    public static void comfort(ServerPlayerEntity p, SurvivalItems.ComfortItem.Kind kind) {
        Mood m = mood(p);
        switch (kind) {
            case MAGAZINE -> {
                m.boredom -= 30;
                m.unhappy -= 15;
                m.stress -= 5;
                p.sendMessage(Text.literal("Полистали журнал. Немного отвлеклись"), true);
            }
            case COMIC -> {
                m.boredom -= 45;
                m.unhappy -= 25;
                p.sendMessage(Text.literal("Хороший комикс! На время забыли обо всём"), true);
            }
            case NEWSPAPER -> {
                m.boredom -= 15;
                m.unhappy -= 5;
                p.sendMessage(Text.literal(Broadcasts.newspaper(p.getRandom())).formatted(Formatting.GRAY, Formatting.ITALIC), false);
            }
            case CIGARETTES -> {
                m.stress -= 30;
                m.unhappy -= 5;
                m.panic -= 10;
            }
            case COFFEE -> {
                m.fatigue = Math.max(0f, m.fatigue - 0.15f);
                m.boredom -= 5;
                ZomboidMod.addThirst(p, 10);
            }
            case BEER -> {
                m.drunk = Math.min(100f, m.drunk + 25f);
                m.unhappy -= 15;
                m.stress -= 15;
                m.boredom -= 10;
                ZomboidMod.addThirst(p, 10);
            }
        }
        m.boredom = MathHelper.clamp(m.boredom, 0f, 100f);
        m.unhappy = MathHelper.clamp(m.unhappy, 0f, 100f);
        m.stress = MathHelper.clamp(m.stress, 0f, 100f);
        m.panic = MathHelper.clamp(m.panic, 0f, 100f);
    }

    /** Глоток сырой воды: шанс отравиться. */
    public static void taintedSip(ServerPlayerEntity p, float chance) {
        if (p.getRandom().nextFloat() < chance * Skills.poisonMult(p)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 160, 0));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 0));
            Mood m = mood(p);
            m.foodSick = Math.min(100f, m.foodSick + 15f * stomach(p));
            p.sendMessage(Text.literal("Вода была грязной, вам нехорошо"), false);
        }
    }

    // ===================== синхронизация =====================
    private static void sync(ServerPlayerEntity p, SurvivalState st) {
        Mood m = st.mood(p.getUuid());
        ServerWorld w = p.getServerWorld();
        NbtCompound n = m.write();
        n.putFloat("felt", m.felt);
        n.putBoolean("power", Power.gridOn(w));
        n.putBoolean("water", Power.waterOn(w));
        n.putInt("day", Clock.day(w));
        ServerPlayNetworking.send(p, new MoodPayload(n));
    }

    // ===================== команды =====================
    private static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, access, env) -> {
            dispatcher.register(CommandManager.literal("status").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                ServerWorld w = p.getServerWorld();
                SurvivalState st = SurvivalState.get(p.getServer());
                Mood m = st.mood(p.getUuid());
                List<String> l = new ArrayList<>();
                l.add("День " + Clock.day(w) + ", " + Clock.date(w));
                l.add("Свет: " + (Power.gridOn(w) ? "есть" : "отключён") + ", вода: " + (Power.waterOn(w) ? "есть" : "отключена"));
                l.add(String.format("Воздух ощущается как %.0f°C, тело %.1f°C, промокание %.0f%%", m.felt, m.temp, m.wet));
                l.add(String.format("Усталость %.0f%%, выносливость %.0f%%", m.fatigue * 100, m.endurance * 100));
                l.add(String.format("Скука %.0f, грусть %.0f, паника %.0f, стресс %.0f", m.boredom, m.unhappy, m.panic, m.stress));
                String text = String.join("\n", l);
                ctx.getSource().sendFeedback(() -> Text.literal(text), false);
                return 1;
            }));
            dispatcher.register(CommandManager.literal("pzworld").requires(src -> src.hasPermissionLevel(2))
                    .then(CommandManager.literal("power_off").executes(ctx -> {
                        SurvivalState st = SurvivalState.get(ctx.getSource().getServer());
                        st.powerOffDay = Clock.day(ctx.getSource().getWorld());
                        st.waterOffDay = Math.min(st.waterOffDay, st.powerOffDay);
                        st.markDirty();
                        return 1;
                    }))
                    .then(CommandManager.literal("heli").executes(ctx -> {
                        WorldEvents.startHeli(ctx.getSource().getServer(), SurvivalState.get(ctx.getSource().getServer()));
                        return 1;
                    }))
                    .then(CommandManager.literal("horde").executes(ctx -> {
                        WorldEvents.horde(ctx.getSource().getServer(), Clock.day(ctx.getSource().getWorld()));
                        return 1;
                    }))
                    .then(CommandManager.literal("fatigue").then(CommandManager.argument("pct", IntegerArgumentType.integer(0, 100)).executes(ctx -> {
                        mood(ctx.getSource().getPlayerOrThrow()).fatigue = IntegerArgumentType.getInteger(ctx, "pct") / 100f;
                        return 1;
                    })))
                    .then(CommandManager.literal("info").executes(ctx -> {
                        SurvivalState st = SurvivalState.get(ctx.getSource().getServer());
                        String t = "Вода отключится в день " + st.waterOffDay + ", свет — " + st.powerOffDay + ", вертолёт — день "
                                + st.heliDay + " в " + st.heliHour + ":00, следующая орда — день " + st.nextHordeDay;
                        ctx.getSource().sendFeedback(() -> Text.literal(t), false);
                        return 1;
                    })));
        });
    }
}
