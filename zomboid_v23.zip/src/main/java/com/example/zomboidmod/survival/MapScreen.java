package com.example.zomboidmod.survival;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

/** Бумажная карта округа: города, деревни, фермы, лесные хижины и шоссе. Тащить мышью, колесо — масштаб. */
public class MapScreen extends Screen {
    private final NbtCompound d;
    private double camX, camZ;
    private float zoom = 0.18f;   // пикселей на блок

    private static final int PAPER = 0xFFE3D5B2, PAPER_D = 0xFFCDBE97, INK = 0xFF3A2E22, ROAD = 0xFF8C7456;

    public MapScreen(NbtCompound d) {
        super(Text.literal("Карта округа"));
        this.d = d;
        camX = d.getInt("px");
        camZ = d.getInt("pz");
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int sx(double x) {
        return (int) Math.round(width / 2.0 + (x - camX) * zoom);
    }

    private int sz(double z) {
        return (int) Math.round(height / 2.0 + (z - camZ) * zoom);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int m = 14, x1 = m, y1 = m, x2 = width - m, y2 = height - m;
        ctx.fill(x1 - 3, y1 - 3, x2 + 3, y2 + 3, 0xFF5A4630);
        ctx.fill(x1, y1, x2, y2, PAPER);
        ctx.enableScissor(x1, y1, x2, y2);
        // бумажные пятна и сетка каждые 256 блоков
        int region = Math.max(64, d.getInt("region") / 2);
        double gx0 = Math.floor((camX - width / 2.0 / zoom) / region) * region;
        double gz0 = Math.floor((camZ - height / 2.0 / zoom) / region) * region;
        for (double gx = gx0; sx(gx) < x2; gx += region) ctx.fill(sx(gx), y1, sx(gx) + 1, y2, PAPER_D);
        for (double gz = gz0; sz(gz) < y2; gz += region) ctx.fill(x1, sz(gz), x2, sz(gz) + 1, PAPER_D);

        // шоссе
        int[] rd = d.getIntArray("rd");
        int rw = Math.max(1, Math.round(7 * zoom));
        for (int i = 0; i + 3 < rd.length; i += 4) {
            int x = rd[i], z = rd[i + 1], len = rd[i + 3];
            if (rd[i + 2] == 1) ctx.fill(sx(x), sz(z) - rw / 2, sx(x + len) + 1, sz(z) - rw / 2 + rw, ROAD);
            else ctx.fill(sx(x) - rw / 2, sz(z), sx(x) - rw / 2 + rw, sz(z + len) + 1, ROAD);
        }
        // поселения
        NbtList list = d.getList("s", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < list.size(); i++) {
            NbtCompound s = list.getCompound(i);
            int t = s.getInt("t");
            int[] r = s.getIntArray("r");
            if (t == 0) {          // лес
                int cx = s.getInt("x"), cz = s.getInt("z"), rad = s.getInt("size");
                for (int k = -rad; k <= rad; k += 6) {
                    int half = (int) Math.sqrt(Math.max(0, rad * rad - k * k));
                    ctx.fill(sx(cx - half), sz(cz + k), sx(cx + half), sz(cz + k + 6), 0xFF8FA37A);
                }
                if (r.length >= 4) ctx.fill(sx(r[0]), sz(r[1]), sx(r[2]) + 1, sz(r[3]) + 1, 0xFF6B4E33);
                continue;
            }
            int fill = t == 3 ? 0xFFB8977A : t == 2 ? 0xFFC9AE88 : 0xFFAFBF85;
            for (int k = 0; k + 3 < r.length; k += 4) {
                int ax = sx(r[k]), az = sz(r[k + 1]), bx = sx(r[k + 2] + 1), bz = sz(r[k + 3] + 1);
                ctx.fill(ax, az, bx, bz, fill);
                ctx.drawBorder(ax, az, bx - ax, bz - az, INK);
                // кварталы
                if (t >= 2) {
                    int step = Math.max(4, Math.round(36 * zoom));
                    for (int qx = ax + step; qx < bx - 1; qx += step) ctx.fill(qx, az + 1, qx + 1, bz - 1, 0x40000000);
                    for (int qz = az + step; qz < bz - 1; qz += step) ctx.fill(ax + 1, qz, bx - 1, qz + 1, 0x40000000);
                }
            }
        }
        for (int i = 0; i < list.size(); i++) {
            NbtCompound s = list.getCompound(i);
            int t = s.getInt("t");
            if (t == 0 && zoom < 0.3f) continue;
            String kind = switch (t) {
                case 3 -> "";
                case 2 -> " (дер.)";
                case 1 -> " (фермы)";
                default -> " (лес)";
            };
            String name = s.getString("n") + kind;
            int tx = sx(s.getInt("x")) - textRenderer.getWidth(name) / 2, ty = sz(s.getInt("z")) - 4;
            ctx.drawText(textRenderer, name, tx, ty, t == 3 ? 0xFF1E140C : INK, false);
        }
        // игрок
        int px = sx(d.getInt("px")), pz = sz(d.getInt("pz"));
        float yaw = d.getFloat("yaw") * MathHelper.RADIANS_PER_DEGREE;
        for (int k = 0; k < 7; k++) {
            int ox = (int) Math.round(-MathHelper.sin(yaw) * k), oz = (int) Math.round(MathHelper.cos(yaw) * k);
            ctx.fill(px + ox - 1, pz + oz - 1, px + ox + 2, pz + oz + 2, 0xFFB01818);
        }
        ctx.fill(px - 3, pz - 3, px + 4, pz + 4, 0xFFB01818);
        ctx.fill(px - 2, pz - 2, px + 3, pz + 3, 0xFFF0E0D0);
        ctx.disableScissor();
        // масштаб и подсказка
        int bar = Math.round(256 * zoom);
        ctx.fill(x1 + 8, y2 - 12, x1 + 8 + bar, y2 - 10, INK);
        ctx.drawText(textRenderer, "256 бл.", x1 + 12 + bar, y2 - 15, INK, false);
        String title = "Округ — карта местности";
        ctx.drawText(textRenderer, title, width / 2 - textRenderer.getWidth(title) / 2, y1 + 6, INK, false);
        String hint = "Мышь — двигать, колесо — масштаб, Esc — закрыть";
        ctx.drawText(textRenderer, hint, x2 - textRenderer.getWidth(hint) - 8, y2 - 15, 0xFF6A5A44, false);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        camX -= deltaX / zoom;
        camZ -= deltaY / zoom;
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        zoom = MathHelper.clamp(zoom * (verticalAmount > 0 ? 1.25f : 0.8f), 0.04f, 2.0f);
        return true;
    }
}
