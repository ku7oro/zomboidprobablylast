package com.example.zomboidmod.survival;

import com.example.zomboidmod.ZomboidMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Звуки выживания (синтезированы gen_survival.py). */
public final class SurvivalSounds {
    public static SoundEvent GENERATOR, HELICOPTER, RADIO_STATIC, SNEEZE, COUGH, HORDE;

    private SurvivalSounds() {
    }

    private static SoundEvent reg(String id) {
        Identifier i = Identifier.of(ZomboidMod.MOD_ID, id);
        return Registry.register(Registries.SOUND_EVENT, i, SoundEvent.of(i));
    }

    public static void register() {
        GENERATOR = reg("generator");
        HELICOPTER = reg("helicopter");
        RADIO_STATIC = reg("radio_static");
        SNEEZE = reg("sneeze");
        COUGH = reg("cough");
        HORDE = reg("horde");
    }
}
