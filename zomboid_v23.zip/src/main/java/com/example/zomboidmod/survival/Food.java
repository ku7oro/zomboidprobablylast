package com.example.zomboidmod.survival;

import com.example.zomboidmod.LootItems;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Свежесть еды как в PZ: у каждого продукта есть срок «свежий» и срок «испорчен» (в игровых днях).
 * Несвежая еда портит настроение, испорченная — ещё и вызывает пищевое отравление.
 * Продукты из домов «родились» в первый день эпидемии, поэтому через неделю-две в холодильниках без света всё сгнило.
 */
public final class Food {
    public record Life(float fresh, float rotten) {}

    public static final int FRESH = 0, STALE = 1, ROTTEN = 2;
    private static final Map<Item, Life> LIFE = new HashMap<>();

    private Food() {
    }

    private static void put(Item i, float fresh, float rotten) {
        if (i != null) LIFE.put(i, new Life(fresh, rotten));
    }

    /** Сроки по вики PZ (дни). Вызывается после регистрации предметов. */
    public static void init() {
        put(Items.APPLE, 5, 8);
        put(Items.BREAD, 3, 6);
        put(Items.MELON_SLICE, 3, 6);
        put(Items.SWEET_BERRIES, 3, 5);
        put(Items.GLOW_BERRIES, 3, 5);
        put(Items.CARROT, 14, 21);
        put(Items.POTATO, 28, 280);
        put(Items.BEETROOT, 14, 21);
        put(Items.BAKED_POTATO, 3, 6);
        put(Items.BEEF, 2, 4);
        put(Items.PORKCHOP, 2, 4);
        put(Items.CHICKEN, 2, 4);
        put(Items.MUTTON, 2, 4);
        put(Items.RABBIT, 2, 4);
        put(Items.COD, 2, 4);
        put(Items.SALMON, 2, 4);
        put(Items.TROPICAL_FISH, 2, 4);
        put(Items.COOKED_BEEF, 3, 6);
        put(Items.COOKED_PORKCHOP, 3, 6);
        put(Items.COOKED_CHICKEN, 3, 6);
        put(Items.COOKED_MUTTON, 3, 6);
        put(Items.COOKED_RABBIT, 3, 6);
        put(Items.COOKED_COD, 3, 6);
        put(Items.COOKED_SALMON, 3, 6);
        put(Items.MUSHROOM_STEW, 2, 4);
        put(Items.RABBIT_STEW, 2, 4);
        put(Items.BEETROOT_SOUP, 2, 4);
        put(Items.PUMPKIN_PIE, 3, 6);
        put(Items.COOKIE, 30, 60);
        put(LootItems.OPEN_BEANS, 2, 4);
        put(LootItems.OPEN_SOUP, 2, 4);
        put(LootItems.OPEN_TUNA, 2, 4);
        put(SurvivalItems.STEW, 2, 4);
        put(SurvivalItems.STEW_RAW, 1, 2);
    }

    public static Life life(ItemStack st) {
        return st.isEmpty() ? null : LIFE.get(st.getItem());
    }

    public static boolean perishable(ItemStack st) {
        return life(st) != null;
    }

    public static boolean stamped(ItemStack st) {
        NbtComponent c = st.get(DataComponentTypes.CUSTOM_DATA);
        return c != null && c.copyNbt().contains("born");
    }

    public static long born(ItemStack st) {
        NbtComponent c = st.get(DataComponentTypes.CUSTOM_DATA);
        return c == null ? 0L : c.copyNbt().getLong("born");
    }

    public static void setBorn(ItemStack st, long born) {
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, st, nbt -> nbt.putLong("born", born));
    }

    /** Ставит дату только тем продуктам, у которых её ещё нет. Округление до часа: стопки одного часа складываются. */
    public static void stampAll(List<ItemStack> stacks, long born) {
        long b = Math.floorDiv(born, Clock.HOUR) * Clock.HOUR;
        for (ItemStack st : stacks) if (perishable(st) && !stamped(st)) setBorn(st, b);
    }

    /** Холодильник: сдвигает дату, будто продукты старели медленнее. */
    public static void shift(List<ItemStack> stacks, long dt) {
        if (dt <= 0) return;
        for (ItemStack st : stacks) if (perishable(st) && stamped(st)) setBorn(st, born(st) + dt);
    }

    public static float ageDays(ItemStack st, long now) {
        return stamped(st) ? (now - born(st)) / (float) Clock.DAY : 0f;
    }

    /** -1 не портится, 0 свежее, 1 несвежее, 2 испорченное. */
    public static int state(ItemStack st, long now) {
        Life l = life(st);
        if (l == null) return -1;
        float age = ageDays(st, now);
        return age >= l.rotten() ? ROTTEN : age >= l.fresh() ? STALE : FRESH;
    }

    public static void tooltip(ItemStack st, long now, List<Text> lines) {
        Life l = life(st);
        if (l == null) return;
        float age = ageDays(st, now);
        int s = state(st, now);
        if (s == FRESH) {
            lines.add(Text.literal("Свежее").formatted(Formatting.GREEN));
            lines.add(Text.literal(String.format("Начнёт портиться через %s", days(l.fresh() - age))).formatted(Formatting.DARK_GRAY));
        } else if (s == STALE) {
            lines.add(Text.literal("Несвежее").formatted(Formatting.YELLOW));
            lines.add(Text.literal(String.format("Испортится через %s", days(l.rotten() - age))).formatted(Formatting.DARK_GRAY));
        } else {
            lines.add(Text.literal("Испорченное! Можно отравиться").formatted(Formatting.RED));
        }
    }

    private static String days(float d) {
        if (d < 1f) return Math.max(1, Math.round(d * 24)) + " ч";
        return String.format("%.1f дн.", d);
    }

    /** Комфортная еда: сладкое поднимает настроение, как в PZ (unhappy, boredom). */
    public static float[] comfort(Item i) {
        if (i == LootItems.CHOCOLATE) return new float[]{-10, -5};
        if (i == Items.COOKIE || i == Items.PUMPKIN_PIE || i == Items.HONEY_BOTTLE) return new float[]{-6, -4};
        if (i == LootItems.CHIPS) return new float[]{-3, -6};
        if (i == Items.ROTTEN_FLESH) return new float[]{15, 10};
        return null;
    }

    public static NbtCompound data(ItemStack st) {
        NbtComponent c = st.get(DataComponentTypes.CUSTOM_DATA);
        return c == null ? new NbtCompound() : c.copyNbt();
    }
}
